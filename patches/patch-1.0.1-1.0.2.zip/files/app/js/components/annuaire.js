/**
 * Calulis — Annuaire (Phase 6)
 * Annuaire complet : élèves, adultes intervenants, établissements
 * Recherche rapide cross-catégories
 */
const Annuaire = {
    _eleves: [],
    _adultes: [],
    _etablissements: [],
    _searchTerm: '',
    _activeTab: 'eleves',
    _debounceTimer: null,

    async render(options = {}) {
        const view = document.getElementById('view-annuaire');

        // Chargement
        view.innerHTML = '<div class="placeholder-view"><div class="placeholder-icon">⏳</div><div class="placeholder-title">Chargement de l\'annuaire…</div></div>';

        // Charger données
        try {
            const [eleves, adultes, etablissements] = await Promise.all([
                API.get('eleves.php'),
                API.get('adultes.php'),
                API.get('etablissements.php'),
            ]);
            this._eleves = eleves || [];
            this._adultes = adultes || [];
            this._etablissements = etablissements || [];
        } catch (e) {
            view.innerHTML = `<div class="placeholder-view">
                <div class="placeholder-icon">⚠️</div>
                <div class="placeholder-title">Erreur de chargement</div>
                <div class="placeholder-text">Impossible de charger l'annuaire : ${escapeHtml(e.message)}</div>
            </div>`;
            return;
        }

        this._searchTerm = (options && options.search) || '';
        this._activeTab = (options && options.defaultTab) || 'eleves';

        // Construire la vue
        view.innerHTML = this._buildHTML();
        this._renderActiveTab();
        this._bindEvents();
        this._updateBadges();
    },

    _buildHTML() {
        const q = this._searchTerm;
        return `
            <div class="toolbar" data-help="Annuaire général|Recherchez un élève, un adulte ou un établissement en tapant son nom dans la barre de recherche. Les résultats s'affichent instantanément, tous types confondus. Cliquez sur Fiche pour voir les informations complètes. Pratique pour retrouver rapidement un contact sans savoir dans quel module il se trouve.">
                <span class="view-toggle" id="annuaire-tabs">
                    <button class="view-toggle-btn active" data-tab="eleves">
                        👤 Élèves <span class="badge" id="badge-eleves">0</span>
                    </button>
                    <button class="view-toggle-btn" data-tab="adultes">
                        👩‍🏫 Adultes <span class="badge" id="badge-adultes">0</span>
                    </button>
                    <button class="view-toggle-btn" data-tab="etablissements">
                        🏫 Établissements <span class="badge" id="badge-etablissements">0</span>
                    </button>
                </span>
                <span style="position:relative;margin-left:12px;flex:1;max-width:350px">
                    <input type="text" id="annuaire-search" class="filter-input"
                           placeholder="Rechercher nom, prénom, classe, rôle, établissement…"
                           style="width:100%;font-size:13px;padding-right:28px" value="${escapeHtml(q)}">
                    <button class="filter-clear" id="annuaire-clear"
                            style="${q ? '' : 'display:none'};position:absolute;right:4px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:14px;color:var(--text-muted);padding:2px 6px">✕</button>
                </span>
            </div>
            <div class="card" style="flex:1;overflow:auto;padding:0" id="annuaire-content">
                <!-- Rempli par _renderActiveTab() -->
            </div>`;
    },

    _bindEvents() {
        // Tabs
        document.querySelectorAll('#annuaire-tabs .view-toggle-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                this._activeTab = btn.dataset.tab;
                document.querySelectorAll('#annuaire-tabs .view-toggle-btn').forEach(b =>
                    b.classList.toggle('active', b.dataset.tab === this._activeTab));
                this._renderActiveTab();
            });
        });

        // Search (debounced)
        const input = document.getElementById('annuaire-search');
        if (input) {
            input.addEventListener('input', () => {
                clearTimeout(this._debounceTimer);
                this._debounceTimer = setTimeout(() => {
                    this._searchTerm = input.value;
                    this._renderActiveTab();
                    this._updateBadges();
                    const clearBtn = document.getElementById('annuaire-clear');
                    if (clearBtn) clearBtn.style.display = this._searchTerm ? '' : 'none';
                }, 200);
            });
        }

        // Clear button
        const clearBtn = document.getElementById('annuaire-clear');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => {
                this._searchTerm = '';
                const inp = document.getElementById('annuaire-search');
                if (inp) inp.value = '';
                clearBtn.style.display = 'none';
                this._renderActiveTab();
                this._updateBadges();
            });
        }
    },

    _filterData(q) {
        const term = q.toLowerCase().trim();
        const allEtablissements = this._etablissements || [];

        if (!term) {
            return {
                eleves: this._eleves,
                adultes: this._adultes,
                etablissements: allEtablissements,
            };
        }

        // Filtrer élèves
        const eleves = this._eleves.filter(e => {
            const champs = [
                e.nom, e.prenom, e.classe,
                e.telephone, e.email, e.adresse, e.ecole_origine,
                e.transport, e.suivi_par,
            ];
            return champs.some(c => c && c.toLowerCase().includes(term));
        });

        // Filtrer adultes
        const adultes = this._adultes.filter(a => {
            const etabText = (a.liens_etablissements || []).map(et =>
                (et.nom || '') + ' ' + (et.ville || '')
            ).join(' ');
            const champs = [
                a.nom, a.prenom, a.role, a.telephone, a.email, a.commentaires, etabText,
            ];
            return champs.some(c => c && c.toLowerCase().includes(term));
        });

        // Filtrer établissements
        const etablissements = allEtablissements.filter(et => {
            const champs = [et.nom, et.ville, et.type, et.telephone, et.email];
            return champs.some(c => c && c.toLowerCase().includes(term));
        });

        return { eleves, adultes, etablissements };
    },

    _renderActiveTab() {
        const container = document.getElementById('annuaire-content');
        if (!container) return;
        const filtered = this._filterData(this._searchTerm);

        switch (this._activeTab) {
            case 'eleves':
                container.innerHTML = this._renderElevesTable(filtered.eleves);
                break;
            case 'adultes':
                container.innerHTML = this._renderAdultesTable(filtered.adultes);
                break;
            case 'etablissements':
                container.innerHTML = this._renderEtablissementsList(filtered.etablissements);
                break;
        }
        this._bindRowEvents();
    },

    _renderElevesTable(eleves) {
        if (eleves.length === 0) {
            return `<p class="text-muted" style="text-align:center;padding:32px">
                ${this._searchTerm
                    ? 'Aucun élève ne correspond à « ' + escapeHtml(this._searchTerm) + ' ».' + this._otherResultsHint()
                    : 'Aucun élève dans l\'annuaire.'}
            </p>`;
        }
        return `<table class="data-table">
            <thead><tr>
                <th>Nom</th><th>Prénom</th><th>Classe</th><th>École d'origine</th><th>Téléphone</th><th>Email</th><th>ULIS</th><th style="width:60px"></th>
            </tr></thead>
            <tbody>${eleves.map(e => `
                <tr data-id="${e.id}">
                    <td><strong>${escapeHtml(e.nom || '')}</strong></td>
                    <td>${escapeHtml(e.prenom || '')}</td>
                    <td>${escapeHtml(e.classe || '')}</td>
                    <td class="small">${escapeHtml(e.ecole_origine || '') || '<span class="text-muted">—</span>'}</td>
                    <td>${escapeHtml(e.telephone || '')}</td>
                    <td><span class="text-muted small">${escapeHtml(e.email || '')}</span></td>
                    <td>${e.ulis ? '<span class="badge badge-ulis">ULIS</span>' : '<span class="text-muted">—</span>'}</td>
                    <td><button class="btn-sm btn-view" data-type="eleve" data-id="${e.id}" title="Fiche élève">📋</button></td>
                </tr>
            `).join('')}</tbody>
        </table>`;
    },

    _renderAdultesTable(adultes) {
        if (adultes.length === 0) {
            return `<p class="text-muted" style="text-align:center;padding:32px">
                ${this._searchTerm
                    ? 'Aucun adulte ne correspond à « ' + escapeHtml(this._searchTerm) + ' ».' + this._otherResultsHint()
                    : 'Aucun adulte dans l\'annuaire.'}
            </p>`;
        }
        return `<table class="data-table">
            <thead><tr>
                <th>Nom</th><th>Prénom</th><th>Rôle</th><th>Téléphone</th><th>Email</th><th>Établissements</th><th style="width:60px"></th>
            </tr></thead>
            <tbody>${adultes.map(a => {
                const etabs = a.liens_etablissements || [];
                const etabStr = etabs.length > 0
                    ? etabs.map(et => {
                        const nom = et.nom || '';
                        const ville = et.ville ? ' (' + escapeHtml(et.ville) + ')' : '';
                        return nom ? escapeHtml(nom) + ville : '(id ' + et.etablissement_id + ')';
                      }).join(', ')
                    : '<span class="text-muted">—</span>';
                return `<tr data-id="${a.id}">
                    <td><strong>${escapeHtml(a.nom || '')}</strong></td>
                    <td>${escapeHtml(a.prenom || '')}</td>
                    <td><span class="badge">${escapeHtml(a.role || '')}</span></td>
                    <td>${escapeHtml(a.telephone || '')}</td>
                    <td><span class="text-muted small">${escapeHtml(a.email || '')}</span></td>
                    <td class="small">${etabStr}</td>
                    <td><button class="btn-sm btn-view" data-type="adulte" data-id="${a.id}" title="Fiche adulte">📋</button></td>
                </tr>`;
            }).join('')}</tbody>
        </table>`;
    },

    _renderEtablissementsList(etablissements) {
        if (etablissements.length === 0) {
            return `<p class="text-muted" style="text-align:center;padding:32px">
                ${this._searchTerm
                    ? 'Aucun établissement ne correspond à « ' + escapeHtml(this._searchTerm) + ' ».' + this._otherResultsHint()
                    : 'Aucun établissement dans l\'annuaire.'}
            </p>`;
        }
        return `<table class="data-table">
            <thead><tr>
                <th>Établissement</th><th>Type</th><th>Ville</th><th>Contact</th><th style="width:60px"></th>
            </tr></thead>
            <tbody>${etablissements.map(et => `
                <tr>
                    <td><strong>${escapeHtml(et.nom)}</strong></td>
                    <td>
                        <span class="badge">${escapeHtml(ETABLISSEMENT_TYPE_LABELS[et.type] || et.type || '—')}</span>
                        ${et.secteur ? `<br><span class="badge-secteur secteur-${escapeHtml(et.secteur)}">${escapeHtml(SECTEUR_LABELS[et.secteur] || et.secteur)}</span>` : ''}
                    </td>
                    <td>${escapeHtml(et.ville || '') || '<span class="text-muted">—</span>'}</td>
                    <td class="small">
                        ${et.telephone ? '📞 ' + escapeHtml(et.telephone) : ''}
                        ${et.email ? (et.telephone ? '<br>' : '') + '✉ ' + escapeHtml(et.email) : ''}
                        ${!et.telephone && !et.email ? '<span class="text-muted">—</span>' : ''}
                    </td>
                    <td><button class="btn-sm btn-view" data-type="etablissement" data-id="${et.id}" title="Fiche établissement">📋</button></td>
                </tr>
            `).join('')}</tbody>
        </table>`;
    },

    _updateBadges() {
        const filtered = this._filterData(this._searchTerm);
        const el = document.getElementById('badge-eleves');
        if (el) el.textContent = filtered.eleves.length;
        const ad = document.getElementById('badge-adultes');
        if (ad) ad.textContent = filtered.adultes.length;
        const et = document.getElementById('badge-etablissements');
        if (et) et.textContent = filtered.etablissements.length;
    },

    _otherResultsHint() {
        const filtered = this._filterData(this._searchTerm);
        const others = [];
        if (filtered.eleves.length && this._activeTab !== 'eleves') others.push({ tab: 'eleves', label: 'Élèves', count: filtered.eleves.length });
        if (filtered.adultes.length && this._activeTab !== 'adultes') others.push({ tab: 'adultes', label: 'Adultes', count: filtered.adultes.length });
        if (filtered.etablissements.length && this._activeTab !== 'etablissements') others.push({ tab: 'etablissements', label: 'Établissements', count: filtered.etablissements.length });
        if (others.length === 0) return '';
        return '<br><span style="font-size:13px">Résultats dans : '
            + others.map(o =>
                `<a href="#" class="hint-tab-link" data-hint-tab="${o.tab}" style="text-decoration:underline;cursor:pointer;font-weight:600">${o.label} (${o.count})</a>`
            ).join(' · ')
            + '</span>';
    },

    _bindRowEvents() {
        document.querySelectorAll('#annuaire-content [data-type="eleve"]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                this._openEleve(parseInt(btn.dataset.id));
            });
        });
        document.querySelectorAll('#annuaire-content [data-type="adulte"]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                this._openAdulte(parseInt(btn.dataset.id));
            });
        });
        document.querySelectorAll('#annuaire-content [data-type="etablissement"]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                this._openEtablissement(parseInt(btn.dataset.id));
            });
        });

        // Clic sur les liens "Voir les résultats dans..."
        document.querySelectorAll('#annuaire-content .hint-tab-link').forEach(link => {
            link.addEventListener('click', (e) => {
                e.preventDefault();
                const tab = link.dataset.hintTab;
                if (tab) {
                    this._activeTab = tab;
                    document.querySelectorAll('#annuaire-tabs .view-toggle-btn').forEach(b =>
                        b.classList.toggle('active', b.dataset.tab === tab));
                    this._renderActiveTab();
                }
            });
        });
    },

    _openEleve(id) {
        const e = this._eleves.find(el => el.id === id);
        if (e) FicheEleve.open(e, true);
    },

    _openAdulte(id) {
        const a = this._adultes.find(ad => ad.id === id);
        if (a) FicheAdulte.open(a, true);
    },

    _openEtablissement(id) {
        const e = this._etablissements.find(et => et.id === id);
        if (e) FicheEtablissement.open(e, true);
    },
};
