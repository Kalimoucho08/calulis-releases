/**
 * Calulis — Composant Fiche Élève (formulaire à onglets)
 */
const FicheEleve = {
    _eleve: null,
    _isNew: false,
    _readonly: false,

    /* ---- Helpers (partagés avec les sous-fichiers via Object.assign) ---- */

    /** Helper input texte */
    _f(name, val = '') {
        const e = this._eleve;
        const ro = this._readonly ? 'disabled' : '';
        return `<input type="text" id="f-${name}" value="${escapeHtml(val || e[name] || '')}" ${ro}>`;
    },

    /** Helper input date */
    _d(name, val = '') {
        const e = this._eleve;
        const ro = this._readonly ? 'disabled' : '';
        return `<input type="date" id="f-${name}" value="${escapeHtml(val || e[name] || '')}" ${ro}>`;
    },

    /** Helper select */
    _s(name, options) {
        const e = this._eleve;
        const ro = this._readonly ? 'disabled' : '';
        const opts = options.map(o => `<option value="${o}" ${e[name] === o ? 'selected' : ''}>${o}</option>`).join('');
        return `<select id="f-${name}" ${ro}><option value="">—</option>${opts}</select>`;
    },

    /** Sanitize URL: bloque javascript:, data:, vbscript: */
    _safeUrl(url) {
        if (!url) return '';
        const u = url.trim().toLowerCase();
        if (/^(javascript|data|vbscript|jar):/.test(u)) return '#';
        return url;
    },

    /** Ouvre la fiche (création si data est vide, édition sinon, readonly si demandé) */
    open(data = {}, readonly = false) {
        this._isNew = !data || !data.id;
        this._eleve = this._isNew ? {} : { ...data };
        this._readonly = readonly;

        Modal.open({
            title: this._isNew ? 'Nouvel élève' : (readonly ? 'Fiche : ' : 'Modifier : ') + (data.prenom || '') + ' ' + (data.nom || ''),
            body: this._buildHTML(),
            footer: readonly ? '<button class="btn btn-secondary" onclick="Modal.close()">Fermer</button>' :
                `<button class="btn btn-secondary" onclick="Modal.close()">Annuler</button>
                 <button class="btn btn-primary" id="btn-save-eleve">Enregistrer</button>`,
        });

        // Tabs (toujours actifs, y compris en lecture seule)
        document.querySelectorAll('#modal .tab').forEach(tab => {
            tab.addEventListener('click', () => this._switchTab(tab.dataset.tab));
        });

        if (!readonly) {
            document.getElementById('btn-save-eleve').addEventListener('click', () => this._save());
            // Toggle affichage lien PAI
            const cbPai = document.getElementById('f-pai');
            const groupLien = document.getElementById('group-lien-pai');
            if (cbPai && groupLien) {
                cbPai.addEventListener('change', () => {
                    groupLien.style.display = cbPai.checked ? '' : 'none';
                });
            }
            // Toggle affichage précautions médicales
            const cbSuivi = document.getElementById('f-suivi_medical');
            const groupPrecautions = document.getElementById('group-precautions');
            if (cbSuivi && groupPrecautions) {
                cbSuivi.addEventListener('change', () => {
                    groupPrecautions.style.display = cbSuivi.checked ? '' : 'none';
                });
            }
            // Toggle affichage détails ASE
            const cbAse = document.getElementById('f-ase_place');
            const groupAse = document.getElementById('group-ase-details');
            if (cbAse && groupAse) {
                cbAse.addEventListener('change', () => {
                    groupAse.style.display = cbAse.checked ? '' : 'none';
                });
            }
            // Bouton "+ Créer" pour l'école d'origine
            const btnCreateEcole = document.getElementById('btn-create-ecole-origine');
            if (btnCreateEcole) {
                btnCreateEcole.addEventListener('click', () => {
                    const handler = () => {
                        this._loadEtablissements();
                        State.off('etablissements:changed', handler);
                    };
                    State.on('etablissements:changed', handler);
                    FicheEtablissement.open({}, false);
                });
            }
            // Bouton "+ Créer" pour l'établissement actuel
            const btnCreateEtablissement = document.getElementById('btn-create-etablissement');
            if (btnCreateEtablissement) {
                btnCreateEtablissement.addEventListener('click', () => {
                    const handler = () => {
                        this._loadEtablissements();
                        State.off('etablissements:changed', handler);
                    };
                    State.on('etablissements:changed', handler);
                    FicheEtablissement.open({}, false);
                });
            }
            // Toggle liens MDPH sur checkboxes notif
            document.querySelectorAll('.f-notif').forEach(cb => {
                cb.addEventListener('change', function() {
                    const liensDiv = this.closest('.notif-row')?.querySelector('.liens-mdph');
                    if (liensDiv) liensDiv.style.display = this.checked ? '' : 'none';
                });
            });
            // Ajouter un lien MDPH
            document.querySelectorAll('.add-lien-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const liensDiv = this.closest('.liens-mdph');
                    const subRow = document.createElement('div');
                    subRow.className = 'sub-row';
                    subRow.style.marginBottom = '4px';
                    subRow.innerHTML = `
                        <input type="text" class="lien-label" placeholder="Libellé" style="flex:1;font-size:13px;padding:4px 8px;border:1px solid var(--border);border-radius:4px">
                        <input type="text" class="lien-url" placeholder="Lien ou chemin du document" style="flex:2;font-size:13px;padding:4px 8px;border:1px solid var(--border);border-radius:4px">
                        <button class="btn-sm btn-del" onclick="this.closest('.sub-row').remove()">x</button>
                    `;
                    liensDiv.insertBefore(subRow, this);
                });
            });
        }

        // Charger la liste des établissements pour le select
        this._loadEtablissements();
    },

    _switchTab(name) {
        document.querySelectorAll('#modal .tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
        document.querySelectorAll('#modal .tab-panel').forEach(p => {
            p.style.display = p.dataset.tab === name ? '' : 'none';
        });
        if (name === 'aeshpec' && this._eleve && this._eleve.id) {
            this._loadAESH();
            this._loadPEC();
        }
        if (name === 'representants' && this._eleve && this._eleve.id) {
            this._loadRepresentants();
        }
        if (name === 'mdph' && this._eleve && this._eleve.id) {
            this._loadReunions();
        }
    },

    /* ---- AESH, PEC, Représentants, MDPH → sous-fichiers fiche-eleve-*.js ---- */

    _buildHTML() {
        const e = this._eleve;
        const ro = this._readonly ? 'disabled' : '';
        const f = (name, val = '') => `<input type="text" id="f-${name}" value="${escapeHtml(val || e[name] || '')}" ${ro}>`;
        const d = (name, val = '') => `<input type="date" id="f-${name}" value="${escapeHtml(val || e[name] || '')}" ${ro}>`;
        const c = (name) => `<input type="checkbox" id="f-${name}" ${e[name] ? 'checked' : ''} ${ro}>`;
        const s = (name, options) => {
            const opts = options.map(o => `<option value="${o}" ${e[name] === o ? 'selected' : ''}>${o}</option>`).join('');
            return `<select id="f-${name}" ${ro}><option value="">—</option>${opts}</select>`;
        };
        const txt = (name) => `<textarea id="f-${name}" rows="2" ${ro}>${escapeHtml(e[name] || '')}</textarea>`;

        return `
        <div class="tabs">
            <button class="tab active" data-tab="identite">Identité</button>
            <button class="tab" data-tab="scolarite">Scolarité</button>
            <button class="tab" data-tab="aeshpec">AESH & PEC</button>
            <button class="tab" data-tab="mdph">MDPH & Plans</button>
            <button class="tab" data-tab="medical">Médical</button>
            <button class="tab" data-tab="representants">Repr&eacute;sentants l&eacute;gaux</button>
        </div>

        <div class="tab-panel active" data-tab="identite" data-help="Identité|Coordonnées de l'élève. Le téléphone est celui de la famille. Le téléphone urgence vient des Représentants légaux. Le transport (bus scolaire, taxi...) détermine l'organisation des sorties. Décocher Élève actif = il quitte le dispositif (reste en base, n'apparaît plus par défaut).">
            <div class="form-row">
                <div class="form-group"><label>Nom *</label>${f('nom')}</div>
                <div class="form-group"><label>Prénom *</label>${f('prenom')}</div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Date de naissance</label>${d('date_naissance')}</div>
                <div class="form-group"><label>INE (Identifiant National Élève)</label>${f('ine')}</div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>T&eacute;l&eacute;phone urgence</label>
                    ${f('telephone_urgence')}
                    <small style="color:var(--text-muted)">Auto-rempli depuis l'onglet Repr&eacute;sentants l&eacute;gaux (contact &laquo;&nbsp;Urgence&nbsp;&raquo;).</small>
                </div>
                <div class="form-group"><label>Langue parlée à la maison</label>${f('langue_maison')}</div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Téléphone</label>${f('telephone')}</div>
                <div class="form-group"><label>Email (optionnel)</label>${f('email')}</div>
            </div>
            <div class="form-group"><label>Adresse</label>${txt('adresse')}</div>
            <div class="form-row">
                <div class="form-group"><label>Transport</label>${s('transport', ['Bus','Taxi','Bus scolaire','Bus de ville','Train','Autre','Aucun','Véhicule familial'])}</div>
                <div class="form-group"><label>Régime scolaire</label>${s('regime_scolaire', ['Demi-pensionnaire','Externe','Interne'])}</div>
            </div>
            <div class="form-row">
                <div class="form-group"><label style="display:flex;align-items:center;gap:8px;margin-top:4px">${c('cantine')} Cantine</label></div>
                <div class="form-group"><label style="display:flex;align-items:center;gap:8px;margin-top:4px">${c('bourse')} Boursier(e)</label></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Photo (chemin ou URL)</label>${f('photo_path')}</div>
                <div class="form-group"><label style="display:flex;align-items:center;gap:8px">${c('actif')} Élève actif</label></div>
            </div>
            <div class="form-section" style="margin-top:12px">
                <div class="form-section-title">Champs personnalisables</div>
                <div class="form-row">
                    <div class="form-group"><label>Champ libre 1</label>${f('champ_perso_1')}</div>
                    <div class="form-group"><label>Champ libre 2</label>${f('champ_perso_2')}</div>
                </div>
            </div>
        </div>

        <div class="tab-panel" data-tab="scolarite" style="display:none" data-help="Scolarité|Classe de référence = classe administrative (radar). École d'origine = établissement précédent. Date entrée ULIS = date notification MDPH ou arrivée effective. Section ASE = élève placé Aide Sociale à l'Enfance.">
            <div class="form-row">
                <div class="form-group"><label>Classe de r&eacute;f&eacute;rence</label>
                    <select id="f-classe_id" ${ro} style="width:100%">
                        <option value="">— Sélectionner —</option>
                    </select>
                    <input type="hidden" id="f-classe" value="${escapeHtml(e.classe || '')}">
                </div>
                <div class="form-group"><label style="display:flex;align-items:center;gap:8px;margin-top:20px">${c('ulis')} Élève ULIS</label></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label style="display:flex;align-items:center;gap:6px">Établissement actuel${this._readonly ? '' : ' <button class="btn-xs btn-outline" id="btn-create-etablissement" title="Créer un établissement">+ Créer</button>'}</label>
                    <select id="f-etablissement_id" ${ro} style="width:100%">
                        <option value="">— Sélectionner —</option>
                    </select>
                    <div id="f-etablissement-hint" class="text-muted small" style="display:none;margin-top:4px;color:#e65100">
                        ⚠️ Aucun établissement enregistré. Clique « + Créer » pour ajouter ton établissement, puis sélectionne-le ici.
                    </div>
                </div>
                <div class="form-group"><label style="display:flex;align-items:center;gap:6px">École d'origine${this._readonly ? '' : ' <button class="btn-xs btn-outline" id="btn-create-ecole-origine" title="Créer un établissement">+ Créer</button>'}</label>
                    <div style="display:flex;gap:4px">
                        <select id="f-ecole_origine_id" ${ro} style="flex:1">
                            <option value="">— Sélectionner —</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Date entrée ULIS</label>${d('date_entree_ulis')}</div>
            </div>
            <div class="form-group"><label>Remarques</label>${txt('remarques')}</div>
            <div class="form-section" style="margin-top:16px">
                <div class="form-section-title">Placement ASE</div>
                <label style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
                    ${c('ase_place')} &Eacute;l&egrave;ve plac&eacute; ASE (Aide Sociale &agrave; l'Enfance)
                </label>
                <div id="group-ase-details" style="${e.ase_place ? '' : 'display:none'}">
                    <div class="form-section-title" style="font-size:13px;margin:4px 0">Lieu de vie</div>
                    <div class="form-row">
                        <div class="form-group"><label>Foyer / Famille d'accueil</label>${f('ase_structure_nom')}</div>
                        <div class="form-group"><label>Téléphone</label>${f('ase_structure_telephone')}</div>
                    </div>
                    <div class="form-group"><label>Adresse</label>${f('ase_structure_adresse')}</div>
                    <div class="form-section-title" style="font-size:13px;margin:8px 0 4px">Référent ASE</div>
                    <div class="form-row">
                        <div class="form-group"><label>Nom</label>${f('ase_referent_nom')}</div>
                        <div class="form-group"><label>Téléphone</label>${f('ase_referent_telephone')}</div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label>Email</label>${f('ase_referent_email')}</div>
                        <div class="form-group"><label>Lien PPE</label>
                            <div style="display:flex;align-items:center;gap:8px">
                                <input type="text" id="f-ase_lien_ppe" value="${escapeHtml(e.ase_lien_ppe || '')}" placeholder="Lien ou chemin du PPE..." style="flex:1" ${ro}>
                                ${e.ase_lien_ppe ? `<a href="${escapeHtml(this._safeUrl(e.ase_lien_ppe))}" target="_blank" rel="noopener" title="Ouvrir">📄</a>` : ''}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        ${this._buildAeshPecTab()}

        ${this._buildMdphTab()}

        <div class="tab-panel" data-tab="medical" style="display:none" data-help="Médical|Fiche urgence : coche PAI si l'élève a un Projet d'Accueil Individualisé, ajoute le lien du document. Suivi médical : allergies connues, régime particulier, précautions médicales utiles au quotidien (précautions pour la vie scolaire uniquement, pas de diagnostic).">
            <div class="form-section">
                <div class="form-section-title">Fiche urgence</div>
                <label style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
                    ${c('pai')} PAI (Projet d'Accueil Individualisé)
                </label>
                <div class="form-group" id="group-lien-pai" style="${e.pai ? '' : 'display:none'}">
                    <label>Lien du document PAI</label>
                    <div style="display:flex;align-items:center;gap:8px">
                        <input type="text" id="f-lien_pai" value="${escapeHtml(e.lien_pai || '')}" ${ro}
                               placeholder="Lien ou chemin du document…" style="flex:1">
                        ${!ro && e.lien_pai ? `<a href="${escapeHtml(this._safeUrl(e.lien_pai))}" target="_blank" rel="noopener" title="Ouvrir le document">📄</a>` : ''}
                        ${ro && e.lien_pai ? `<a href="${escapeHtml(this._safeUrl(e.lien_pai))}" target="_blank" rel="noopener" class="btn btn-sm btn-secondary" style="margin-left:4px">📄 Ouvrir le PAI</a>` : ''}
                    </div>
                </div>
            </div>
            <div class="form-section">
                <div class="form-section-title">Suivi médical</div>
                <div class="form-group"><label>Allergies</label>${txt('allergies')}</div>
                <div class="form-group"><label>Régime alimentaire</label>${f('regime_alimentaire')}</div>
                <label style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
                    ${c('suivi_medical')} Suivi médical en cours (dossier médical école)
                </label>
                <div class="form-group" id="group-precautions" style="${e.suivi_medical ? '' : 'display:none'}">
                    <label>Précautions pour la vie scolaire</label>
                    ${txt('precautions_medicales')}
                    <small style="color:var(--text-muted);display:block;margin-top:4px">
                        ⚠️ Indiquez uniquement les précautions pratiques (traitement en cours, aménagements).
                        Pas de diagnostic, pas de pathologie — ces informations relèvent du dossier médical de l'école.
                    </small>
                </div>
            </div>
        </div>

        ${this._buildRepresentantsTab()}`;
    },

    async _save() {
        const data = this._collect();
        if (!data.nom || !data.prenom) {
            Modal.alert('Erreur', 'Nom et prénom sont requis.');
            return;
        }
        // Guidage : l'établissement est requis — Toast + focus sur le champ (on ne perd pas la saisie)
        if (!data.etablissement_id) {
            const hasEtablissements = (this._etablissements || []).some(e => e.actif !== 0);
            Toast.error(hasEtablissements
                ? "Sélectionne l'établissement de l'élève dans l'onglet « Scolarité » avant d'enregistrer."
                : "Aucun établissement enregistré. Clique « + Créer » à côté du champ « Établissement actuel » (onglet Scolarité).");
            this._switchTab('scolarite');
            const sel = document.getElementById('f-etablissement_id');
            if (sel) {
                sel.style.borderColor = '#c62828';
                sel.style.boxShadow = '0 0 0 2px rgba(198,40,40,.25)';
                sel.focus();
                setTimeout(() => { sel.style.borderColor = ''; sel.style.boxShadow = ''; }, 5000);
            }
            return;
        }
        // A13 : synchroniser telephone_urgence depuis le représentant marqué "Urgence"
        const repItems = this._getRepresentantsFromDOM();
        const urgenceRep = repItems.find(r => r.telephone_urgence && r.telephone);
        if (urgenceRep) {
            data.telephone_urgence = urgenceRep.telephone;
        }
        try {
            let eleveId = this._eleve.id;
            if (this._isNew) {
                const res = await API.post('eleves.php', data);
                eleveId = res.id;
            } else {
                await API.put('eleves.php?id=' + eleveId, data);
            }
            // Save AESH
            await API.del('aesh_eleves.php?eleve_id=' + eleveId);
            const aeshItems = this._getAESHFromDOM();
            for (const item of aeshItems) {
                await API.post('aesh_eleves.php', { ...item, eleve_id: eleveId });
            }
            // Save PEC
            await API.del('pec_eleves.php?eleve_id=' + eleveId);
            const pecItems = this._getPECFromDOM();
            for (const item of pecItems) {
                await API.post('pec_eleves.php', { ...item, eleve_id: eleveId });
            }
            // Save Représentants
            await API.del('representants.php?eleve_id=' + eleveId);
            for (const item of repItems) {
                await API.post('representants.php', { ...item, eleve_id: eleveId, adresse: item.adresse || '' });
            }
            Modal.close();
            await ElevesList._load();
            State.emit('eleves:changed');
            Toast.success(this._isNew ? 'Élève créé' : 'Élève modifié');
        } catch (e) {
            Modal.alert('Erreur', e.message);
        }
    },

    _collect() {
        const data = {};
        // Champs texte
        ['nom','prenom','date_naissance','ine','classe','ecole_origine','ecole_origine_id','etablissement_id',
         'date_entree_ulis',
         'transport','telephone','email','adresse','allergies',
         'regime_alimentaire','precautions_medicales','lien_pai','remarques',
         'langue_maison','regime_scolaire','photo_path','champ_perso_1','champ_perso_2','telephone_urgence',
         'ase_structure_nom','ase_structure_adresse','ase_structure_telephone',
         'ase_referent_nom','ase_referent_telephone','ase_referent_email','ase_lien_ppe',
         'mdph_ulis_date_fin','mdph_ulis_statut','mdph_sessad_date_fin','mdph_sessad_statut',
         'mdph_aesh_date_fin','mdph_aesh_statut','mdph_transport_date_fin','mdph_transport_statut',
         'mdph_autre_date_fin','mdph_autre_statut','mdph_autre_libelle']
        .forEach(f => { const el = document.getElementById('f-' + f); if (el) data[f] = el.value; });

        // classe_id : lire le select, sync le texte classe pour backward compat
        const classeSelect = document.getElementById('f-classe_id');
        if (classeSelect && classeSelect.value) {
            data.classe_id = parseInt(classeSelect.value);
            data.classe = classeSelect.options[classeSelect.selectedIndex]?.text || '';
        } else {
            data.classe_id = null;
            data.classe = document.getElementById('f-classe')?.value || '';
        }

        // ecole_origine_id : auto-sync le nom texte pour backward compat
        const eoSelect = document.getElementById('f-ecole_origine_id');
        if (eoSelect && eoSelect.value) {
            data.ecole_origine = eoSelect.options[eoSelect.selectedIndex]?.text || '';
        }

        // Checkboxes
        data.ulis = document.getElementById('f-ulis')?.checked ? 1 : 0;
        data.cantine = document.getElementById('f-cantine')?.checked ? 1 : 0;
        data.bourse = document.getElementById('f-bourse')?.checked ? 1 : 0;
        data.pai = document.getElementById('f-pai')?.checked ? 1 : 0;
        data.ase_place = document.getElementById('f-ase_place')?.checked ? 1 : 0;
        data.suivi_medical = document.getElementById('f-suivi_medical')?.checked ? 1 : 0;
        data.actif = document.getElementById('f-actif')?.checked ? 1 : 0;

        // Notifications
        const notifs = [];
        document.querySelectorAll('.f-notif:checked').forEach(cb => notifs.push(cb.dataset.type));
        data.notifications = JSON.stringify(notifs);

        // Liens MDPH
        const liensMdph = {};
        document.querySelectorAll('.liens-mdph').forEach(div => {
            const liens = [];
            div.querySelectorAll('.sub-row').forEach(row => {
                const label = row.querySelector('.lien-label')?.value?.trim();
                const url = row.querySelector('.lien-url')?.value?.trim();
                if (url) liens.push({ label: label || '', url });
            });
            if (liens.length) liensMdph[div.dataset.type] = liens;
        });
        data.liens_mdph = JSON.stringify(liensMdph);

        return data;
    },

    async _loadEtablissements() {
        const remplirSelect = (selectId, currentId) => {
            const select = document.getElementById(selectId);
            if (!select) return;
            select.innerHTML = '<option value="">— Sélectionner —</option>' +
                this._etablissements.filter(e => e.actif !== 0).map(e =>
                    `<option value="${e.id}" ${e.id === currentId ? 'selected' : ''}>${escapeHtml(e.nom)}${e.ville ? ' (' + escapeHtml(e.ville) + ')' : ''}</option>`
                ).join('');
        };

        try {
            this._etablissements = await API.get('etablissements.php');
        } catch {
            this._etablissements = [];
        }

        const currentEtablissement = this._eleve && this._eleve.etablissement_id;
        remplirSelect('f-etablissement_id', currentEtablissement);

        const currentOrigine = this._eleve && this._eleve.ecole_origine_id;
        remplirSelect('f-ecole_origine_id', currentOrigine);

        // Aide : aucun établissement enregistré → inviter à en créer un
        const hint = document.getElementById('f-etablissement-hint');
        if (hint) {
            const actifs = this._etablissements.filter(e => e.actif !== 0);
            hint.style.display = actifs.length ? 'none' : '';
        }

        // Classes de référence
        try {
            const classes = await API.get('classes.php');
            const classeSelect = document.getElementById('f-classe_id');
            if (classeSelect) {
                classeSelect.innerHTML = '<option value="">— Sélectionner —</option>' +
                    classes.map(c => {
                        let niveauxLabel = '';
                        try { const n = JSON.parse(c.niveaux || '[]'); if (n.length) niveauxLabel = ' [' + n.map(x => NIVEAU_LABELS[x] || x).join('+') + ']'; } catch {}
                        return `<option value="${c.id}" ${(this._eleve && this._eleve.classe_id === c.id) ? 'selected' : ''}>${escapeHtml(c.nom)}${niveauxLabel}${c.enseignant_nom ? ' — ' + escapeHtml(c.enseignant_prenom || '') + ' ' + escapeHtml(c.enseignant_nom) : ''}</option>`;
                    }).join('');
            }
        } catch {}
    },
};
