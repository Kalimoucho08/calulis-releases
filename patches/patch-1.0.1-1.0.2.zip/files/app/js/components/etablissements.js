/**
 * Calulis — Vue Établissements (Phase 7)
 * Liste des établissements avec création, double-clic fiche, recherche
 * L'établissement principal (notre_etablissement) est épinglé en haut.
 * Chaque type a sa propre couleur de fond.
 */
/** Statut des établissements (public / privé + contrat) — partagé avec la fiche */
const SECTEUR_LABELS = {
    public: 'Public',
    prive_sous_contrat: 'Privé sous contrat',
    prive_hors_contrat: 'Privé hors contrat',
    associatif: 'Associatif',
};

/** Libellés des types d'établissements — partagé avec la fiche et l'annuaire */
const ETABLISSEMENT_TYPE_LABELS = {
    ecole: 'École',
    ecole_maternelle: 'École maternelle',
    ecole_primaire: 'École primaire',
    ecole_elementaire: 'École élémentaire',
    groupe_scolaire: 'Groupe scolaire',
    ensemble_scolaire: 'Ensemble scolaire',
    college: 'Collège',
    lycee: 'Lycée',
    ime: 'IME',
    sessad: 'SESSAD',
    cmp: 'CMP',
    cmpp: 'CMPP',
    foyer_ase: 'Foyer ASE',
    association: 'Association',
    taxi: 'Taxi',
    periscolaire: 'Périscolaire',
    centre_culturel: 'Centre culturel',
    service_public: 'Service public',
};

const EtablissementsList = {
    _etablissements: [],
    _notreId: null,
    _sort: { col: 'nom', dir: 'asc' },

    async render() {
        const view = document.getElementById('view-etablissements');
        if (!view) return;

        // Charger les établissements + l'ID de notre établissement
        try {
            this._etablissements = await API.get('etablissements.php');
        } catch {
            this._etablissements = [];
        }
        try {
            const params = await API.get('params.php');
            const row = params.find(p => p.cle === 'notre_etablissement_id');
            this._notreId = (row && row.valeur !== 'null') ? parseInt(row.valeur) : null;
        } catch {
            this._notreId = null;
        }

        view.innerHTML = `
            <div class="toolbar" data-help="Établissements partenaires|Tous les établissements avec lesquels vous travaillez : écoles, collèges, structures médico-sociales (CMP, CMPP, SESSAD, IME), services sociaux (ASE, MDA). L'établissement principal (votre école) apparaît en haut avec le badge doré 🏫 NOTRE ÉCOLE. Double-cliquez sur une ligne pour voir la fiche détaillée avec les intervenants rattachés.">
                <button class="btn btn-primary" id="btn-new-etablissement">+ Nouvel établissement</button>
                <span style="margin-left:12px;position:relative;flex:1;max-width:350px">
                    <input type="text" id="filter-etablissement-q" class="filter-input"
                           placeholder="Rechercher nom, ville, type…" style="width:100%;font-size:13px;padding-right:28px">
                    <button class="filter-clear" id="filter-etablissement-clear"
                            style="display:none;position:absolute;right:4px;top:50%;transform:translateY(-50%);background:none;border:none;cursor:pointer;font-size:14px;color:var(--text-muted);padding:2px 6px">✕</button>
                </span>
            </div>
            <div id="etablissements-table-container" style="flex:1;overflow:auto"></div>
        `;

        document.getElementById('btn-new-etablissement').addEventListener('click', () => this._openFiche({}));
        document.getElementById('filter-etablissement-q').addEventListener('input', () => this._renderTable());
        document.getElementById('filter-etablissement-clear').addEventListener('click', () => {
            document.getElementById('filter-etablissement-q').value = '';
            document.getElementById('filter-etablissement-clear').style.display = 'none';
            this._renderTable();
        });

        this._renderTable();
    },

    _renderTable() {
        const q = (document.getElementById('filter-etablissement-q')?.value || '').toLowerCase();
        const clearBtn = document.getElementById('filter-etablissement-clear');
        if (clearBtn) clearBtn.style.display = q ? '' : 'none';

        let filtered = this._etablissements;
        if (q) {
            filtered = filtered.filter(e =>
                (e.nom || '').toLowerCase().includes(q) ||
                (e.ville || '').toLowerCase().includes(q) ||
                (e.type || '').toLowerCase().includes(q) ||
                (SECTEUR_LABELS[e.secteur] || '').toLowerCase().includes(q)
            );
        }

        const notreId = this._notreId;

        const typeLabel = (t) => ETABLISSEMENT_TYPE_LABELS[t] || t || '—';

        // Trier : notre établissement toujours en premier, puis selon la colonne choisie
        const sortCol = this._sort.col;
        const sortDir = this._sort.dir;
        filtered = [...filtered].sort((a, b) => {
            if (a.id === notreId) return -1;
            if (b.id === notreId) return 1;
            let va, vb;
            if (sortCol === 'type') {
                va = typeLabel(a.type).toLowerCase();
                vb = typeLabel(b.type).toLowerCase();
            } else {
                va = (a[sortCol] || '').toString().toLowerCase();
                vb = (b[sortCol] || '').toString().toLowerCase();
            }
            const cmp = va.localeCompare(vb, 'fr', { sensitivity: 'base' });
            return sortDir === 'asc' ? cmp : -cmp;
        });

        const container = document.getElementById('etablissements-table-container');
        container.innerHTML = filtered.length === 0
            ? `<div style="text-align:center;padding:32px;color:var(--text-muted)">${q ? 'Aucun résultat trouvé.' : `Aucun établissement enregistré.<br><button class="btn btn-primary" id="btn-empty-new-etablissement" style="margin-top:12px">+ Nouvel établissement</button>`}</div>`
            : `<table class="data-table">
                <thead>
                    <tr>
                        <th data-sort="nom" class="sortable">Nom</th>
                        <th data-sort="type" class="sortable">Type</th>
                        <th data-sort="ville" class="sortable">Ville</th>
                        <th>Contact</th><th style="width:110px">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    ${filtered.map(e => {
                        const isNotre = e.id === notreId;
                        const typeClass = 'etab-type-' + (e.type || 'autre');
                        return `
                        <tr class="clickable${isNotre ? ' row-notre-etablissement' : ''}"
                            data-id="${e.id}" data-etab-type="${e.type || ''}">
                            <td>
                                <strong>${escapeHtml(e.nom)}</strong>
                                ${isNotre ? '<span class="badge-notre-etab">🏫 Notre établissement</span>' : ''}
                            </td>
                            <td>
                                <span class="etab-type-dot ${typeClass}"></span>${escapeHtml(typeLabel(e.type))}
                                ${e.secteur ? `<br><span class="badge-secteur secteur-${escapeHtml(e.secteur)}">${escapeHtml(SECTEUR_LABELS[e.secteur] || e.secteur)}</span>` : ''}
                            </td>
                            <td>${escapeHtml(e.ville || '—')}</td>
                            <td style="font-size:12px">
                                ${e.telephone ? '📞 ' + escapeHtml(e.telephone) : ''}
                                ${e.email ? '<br>✉ ' + escapeHtml(e.email) : ''}
                            </td>
                            <td style="white-space:nowrap">
                                ${!isNotre ? `<button class="btn-sm btn-del" data-id="${e.id}" title="Supprimer">Supprimer</button>` : ''}
                                <button class="btn-sm btn-view" data-id="${e.id}" title="Fiche établissement">📋</button>
                            </td>
                        </tr>`;
                    }).join('')}
                </tbody>
            </table>`;

        // Tri par colonnes
        container.querySelectorAll('th.sortable').forEach(th => {
            th.addEventListener('click', () => {
                const col = th.dataset.sort;
                if (this._sort.col === col) this._sort.dir = this._sort.dir === 'asc' ? 'desc' : 'asc';
                else { this._sort.col = col; this._sort.dir = 'asc'; }
                this._renderTable();
            });
            // Indicateur de tri
            if (th.dataset.sort === this._sort.col) {
                th.classList.add('sorted-' + this._sort.dir);
                th.innerHTML = th.innerHTML.replace(/ [▲▼]$/, '') + ' ' + (this._sort.dir === 'asc' ? '▲' : '▼');
            }
        });

        const emptyBtn = document.getElementById('btn-empty-new-etablissement');
        if (emptyBtn) emptyBtn.addEventListener('click', () => this._openFiche({}));

        // Double-clic sur ligne → fiche
        container.querySelectorAll('tr.clickable').forEach(tr => {
            tr.addEventListener('dblclick', () => {
                const id = parseInt(tr.dataset.id);
                const etab = this._etablissements.find(e => e.id === id);
                if (etab) this._openFiche(etab);
            });
        });

        // Clic Supprimer
        container.querySelectorAll('button.btn-del').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                this._delete(parseInt(btn.dataset.id));
            });
        });

        // Clic 📋 → fiche
        container.querySelectorAll('button.btn-view').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const id = parseInt(btn.dataset.id);
                const etab = this._etablissements.find(e => e.id === id);
                if (etab) this._openFiche(etab);
            });
        });
    },

    async _delete(id) {
        const e = this._etablissements.find(et => et.id === id);
        if (!e) return;
        if (e.id === this._notreId) {
            Modal.alert('Impossible', 'Impossible de supprimer l\'établissement principal. Modifie d\'abord le paramètre « Notre établissement » dans Paramètres.');
            return;
        }
        if (!await Modal.confirm('Confirmer', `Supprimer l'établissement « ${e.nom} » ?`)) return;
        try {
            await API.del('etablissements.php?id=' + id);
            this._etablissements = this._etablissements.filter(et => et.id !== id);
            this._renderTable();
            State.emit('etablissements:changed');
            Toast.success('Établissement supprimé');
        } catch (err) {
            Modal.alert('Erreur', err.message);
        }
    },

    _openFiche(etab) {
        // Abonnement one-shot : après sauvegarde, re-rendre la vue
        const handler = () => {
            this.render();
            State.off('etablissements:changed', handler);
        };
        State.on('etablissements:changed', handler);
        // 2e paramètre = readonly : jamais bloqué ici (création ET édition doivent être modifiables)
        FicheEtablissement.open(etab || {}, false);
    },
};
