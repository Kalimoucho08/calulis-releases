/**
 * Calulis — Composant Fiche Établissement / Structure
 */
const FicheEtablissement = {
    _etablissement: null,
    _isNew: false,
    _readonly: false,

    open(data = {}, readonly = false) {
        this._isNew = !data || !data.id;
        this._etablissement = this._isNew ? {} : { ...data };
        this._readonly = readonly;

        const label = data.nom || 'Nouvel établissement';
        Modal.open({
            title: this._isNew ? 'Nouvel établissement' : (readonly ? 'Fiche : ' : 'Modifier : ') + label,
            body: this._buildHTML(),
            footer: readonly
                ? '<button class="btn btn-secondary" onclick="Modal.close()">Fermer</button>'
                : `<button class="btn btn-secondary" onclick="Modal.close()">Annuler</button>
                   <button class="btn btn-primary" id="btn-save-etablissement">Enregistrer</button>`,
        });

        document.querySelectorAll('#modal .tab').forEach(tab => {
            tab.addEventListener('click', () => this._switchTab(tab.dataset.tab));
        });

        if (!readonly) {
            document.getElementById('btn-save-etablissement').addEventListener('click', () => this._save());
        }

        this._loadNotreBadge(data);
        this._loadPersonnel(data);
        this._loadIntervenants(data);
        this._loadEleves(data);
    },

    async _loadNotreBadge(data) {
        const badgeEl = document.getElementById('fe-notre-badge');
        if (!badgeEl || !data.id) return;
        try {
            const notreId = await this._getNotreEtablissementId();
            if (data.id === notreId) {
                badgeEl.innerHTML = '<div style="background:#e8f5e9;color:#2e7d32;padding:6px 12px;border-radius:4px;margin-bottom:12px;font-weight:600;display:inline-block">★ NOTRE ÉTABLISSEMENT</div>';
            }
        } catch {}
    },

    _switchTab(name) {
        document.querySelectorAll('#modal .tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
        document.querySelectorAll('#modal .tab-panel').forEach(p => {
            p.style.display = p.dataset.tab === name ? '' : 'none';
        });
    },

    _buildHTML() {
        const e = this._etablissement;
        const ro = this._readonly ? 'disabled' : '';
        const f = (name, val) => `<input type="text" id="fe-${name}" value="${escapeHtml(val !== undefined ? val : (e[name] || ''))}" ${ro}>`;
        const txt = (name, val) => `<textarea id="fe-${name}" rows="3" ${ro}>${escapeHtml(val !== undefined ? val : (e[name] || ''))}</textarea>`;

        const typeLabels = { ...ETABLISSEMENT_TYPE_LABELS, autre: 'Autre' };
        const typeOptions = Object.keys(typeLabels);
        const natureOptions = ['ecole','college','lycee','IME','ITEP','SESSAD','CMP','CMPP','hopital','association','autre'];
        const secteurOptions = ['public','prive_sous_contrat','prive_hors_contrat','associatif'];

        return `
        <div class="tabs">
            <button class="tab active" data-tab="identite">Identité</button>
            <button class="tab" data-tab="intervenants" id="tab-intervenants" style="${this._isNew ? 'display:none' : ''}">Intervenants / Personnel</button>
            <button class="tab" data-tab="eleves" id="tab-eleves" style="${this._isNew ? 'display:none' : ''}">Élèves</button>
        </div>

        <div class="tab-panel active" data-tab="identite">
            <div id="fe-notre-badge"></div>
            <div class="form-row">
                <div class="form-group" style="flex:2"><label>Nom *</label>${f('nom')}</div>
                <div class="form-group" style="flex:1"><label>UAI</label>${f('uai')}</div>
            </div>
            <div class="form-row">
                <div class="form-group" style="flex:1"><label>Type</label>
                    <select id="fe-type" ${ro} style="width:100%">
                        <option value="">— Sélectionner —</option>
                        ${typeOptions.map(t =>
                            `<option value="${t}" ${(e.type || '') === t ? 'selected' : ''}>${typeLabels[t] || t}</option>`
                        ).join('')}
                    </select>
                </div>
                <div class="form-group" style="flex:1"><label>Nature</label>
                    <select id="fe-nature" ${ro} style="width:100%">
                        <option value="">— Sélectionner —</option>
                        ${natureOptions.map(n =>
                            `<option value="${n}" ${(e.nature || '') === n ? 'selected' : ''}>${n}</option>`
                        ).join('')}
                    </select>
                </div>
                <div class="form-group" style="flex:1"><label>Statut</label>
                    <select id="fe-secteur" ${ro} style="width:100%">
                        <option value="">— Sélectionner —</option>
                        ${secteurOptions.map(s =>
                            `<option value="${s}" ${(e.secteur || '') === s ? 'selected' : ''}>${SECTEUR_LABELS[s] || s}</option>`
                        ).join('')}
                    </select>
                </div>
            </div>
            <div class="form-group"><label>Adresse</label>${f('adresse')}</div>
            <div class="form-group"><label>Ville</label>${f('ville')}</div>
            <div class="form-row">
                <div class="form-group"><label>Téléphone</label>${f('telephone')}</div>
                <div class="form-group"><label>Téléphone 2</label>${f('telephone2')}</div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Email</label>${f('email')}</div>
                <div class="form-group"><label>Email 2</label>${f('email2')}</div>
            </div>
            <div class="form-group"><label>Description</label>${txt('description')}</div>
            ${!this._isNew ? `<div class="form-row" style="margin-top:12px">
                <div class="form-group"><label style="display:flex;align-items:center;gap:8px">
                    <input type="checkbox" id="fe-actif" ${e.actif === 1 ? 'checked' : ''} ${ro}> Actif
                </label></div>
            </div>` : ''}
        </div>

        <div class="tab-panel" data-tab="intervenants" style="display:none">
            <p class="text-muted small" style="margin-bottom:8px" id="fe-intervenants-helper">Chargement...</p>
            <div id="fe-intervenants-content"><p class="text-muted">Chargement...</p></div>
        </div>

        <div class="tab-panel" data-tab="eleves" style="display:none">
            <p class="text-muted small" style="margin-bottom:8px">Élèves rattachés à cet établissement.</p>
            <div id="fe-eleves-content"><p class="text-muted">Chargement...</p></div>
        </div>`;
    },

    async _loadPersonnel(data) {
        const content = document.getElementById('fe-intervenants-content');
        const helper = document.getElementById('fe-intervenants-helper');
        if (!content || !data.id) return;
        try {
            const notreId = await this._getNotreEtablissementId();
            const isNotre = data.id === notreId;

            if (isNotre) {
                if (helper) helper.textContent = 'Personnel rattaché à cet établissement (enseignants, AESH).';
                const staff = await API.get('etablissements.php?id=' + data.id + '&staff=1');
                if (staff.length === 0) {
                    content.innerHTML = '<p class="text-muted small">Aucun personnel rattaché.</p>';
                } else {
                    content.innerHTML = '<table class="data-table"><thead><tr><th>Nom</th><th>Prénom</th><th>Rôle</th><th></th></tr></thead><tbody>' +
                        staff.map(a => `<tr>
                            <td><strong>${escapeHtml(a.nom || '')}</strong></td>
                            <td>${escapeHtml(a.prenom || '')}</td>
                            <td><span class="badge">${escapeHtml(a.role || '')}</span></td>
                            <td><button class="btn-sm btn-view" data-type="adulte" data-id="${a.id}" title="Fiche adulte">📋</button></td>
                        </tr>`).join('') + '</tbody></table>';
                }
            } else {
                if (helper) helper.textContent = 'Intervenants liés à cette structure.';
                const intervenants = await API.get('etablissements.php?id=' + data.id + '&intervenants=1');
                if (intervenants.length === 0) {
                    content.innerHTML = '<p class="text-muted small">Aucun intervenant lié.</p>';
                } else {
                    content.innerHTML = '<table class="data-table"><thead><tr><th>Nom</th><th>Prénom</th><th>Rôle</th><th>Fonction</th><th></th></tr></thead><tbody>' +
                        intervenants.map(a => `<tr>
                            <td><strong>${escapeHtml(a.nom || '')}</strong></td>
                            <td>${escapeHtml(a.prenom || '')}</td>
                            <td><span class="badge">${escapeHtml(a.role || '')}</span></td>
                            <td class="small">${escapeHtml(a.role_lie || '')}</td>
                            <td><button class="btn-sm btn-view" data-type="adulte" data-id="${a.id}" title="Fiche adulte">📋</button></td>
                        </tr>`).join('') + '</tbody></table>';
                }
            }

            // Lier les clics sur les boutons fiche adulte
            content.querySelectorAll('[data-type="adulte"]').forEach(btn => {
                btn.addEventListener('click', (e) => {
                    e.stopPropagation();
                    const id = parseInt(btn.dataset.id);
                    API.get('adultes.php?id=' + id).then(a => { if (a) FicheAdulte.open(a, true); });
                });
            });
        } catch {
            content.innerHTML = '<p class="text-muted">Impossible de charger.</p>';
        }
    },

    async _loadIntervenants(data) {
        // Same as _loadPersonnel — unified via _loadPersonnel
    },

    async _loadEleves(data) {
        const content = document.getElementById('fe-eleves-content');
        if (!content || !data.id) return;
        try {
            const eleves = await API.get('etablissements.php?id=' + data.id + '&eleves=1');
            if (eleves.length === 0) {
                content.innerHTML = '<p class="text-muted small">Aucun élève rattaché.</p>';
            } else {
                content.innerHTML = '<table class="data-table"><thead><tr><th>Nom</th><th>Prénom</th><th>Classe</th><th></th></tr></thead><tbody>' +
                    eleves.map(el => `<tr>
                        <td><strong>${escapeHtml(el.nom || '')}</strong></td>
                        <td>${escapeHtml(el.prenom || '')}</td>
                        <td>${escapeHtml(el.classe || '')}</td>
                        <td><button class="btn-sm btn-view" data-type="eleve" data-id="${el.id}" title="Fiche élève">📋</button></td>
                    </tr>`).join('') + '</tbody></table>';

                content.querySelectorAll('[data-type="eleve"]').forEach(btn => {
                    btn.addEventListener('click', (e) => {
                        e.stopPropagation();
                        const id = parseInt(btn.dataset.id);
                        API.get('eleves.php?id=' + id).then(el => { if (el) FicheEleve.open(el, true); });
                    });
                });
            }
        } catch {
            content.innerHTML = '<p class="text-muted">Impossible de charger.</p>';
        }
    },

    async _getNotreEtablissementId() {
        try {
            const params = await API.get('params.php');
            const row = params.find(p => p.cle === 'notre_etablissement_id');
            if (row && row.valeur !== 'null') return parseInt(row.valeur);
        } catch {}
        return null;
    },

    async _save() {
        const data = this._collect();
        if (!data.nom) {
            Modal.alert('Erreur', 'Le nom est requis.');
            return;
        }
        try {
            if (this._isNew) {
                await API.post('etablissements.php', data);
            } else {
                await API.put('etablissements.php?id=' + this._etablissement.id, data);
            }
            Modal.close();
            State.emit('etablissements:changed');
            Toast.success(this._isNew ? 'Établissement créé' : 'Établissement modifié');
        } catch (e) {
            Modal.alert('Erreur', e.message);
        }
    },

    _collect() {
        const data = {};
        ['nom','uai','type','nature','secteur','ville','adresse','telephone','telephone2','email','email2','description'].forEach(f => {
            const el = document.getElementById('fe-' + f);
            if (el) data[f] = el.value;
        });
        data.actif = document.getElementById('fe-actif')?.checked ? 1 : 1;
        return data;
    },
};
