/**
 * Calulis — Print EDT : builders emplois du temps (pdfmake)
 * Attaché à l'objet Print via Object.assign
 */

Object.assign(Print, {

    /* ---- DocDef builders (return pdfmake document definition, no download) ---- */

    async _buildStudentWeek(eleveId, semaineId) {
        const params = await this._ensureParams();
        const eleve = this._eleves.find(e => e.id === eleveId);
        const label = eleve ? `${eleve.prenom || ''} ${eleve.nom || ''}`.trim() : `Élève #${eleveId}`;
        const creneaux = await this._loadCreneaux(semaineId, eleveId);
        return this._buildPersonWeek(creneaux, params, label, semaineId);
    },

    async _buildAdultWeekFromAPI(adulteNom, semaineId, jourFiltre) {
        const params = await this._ensureParams();
        const qs = new URLSearchParams({ adulte: adulteNom });
        qs.set('semaine_id', semaineId !== null ? semaineId : 'null');
        let creneaux = await API.get('creneaux.php?' + qs.toString());
        creneaux = creneaux.map(c => ({ ...c, heure_debut: c.heure_debut?.substring(0, 5) }));
        if (jourFiltre) creneaux = creneaux.filter(c => c.jour === jourFiltre);
        return this._buildAdultWeek(creneaux, params, adulteNom, semaineId, jourFiltre);
    },

    async _buildMultiDayFromAPI(jour, semaineId, eleveIds) {
        const params = await this._ensureParams();
        const creneaux = await this._loadCreneaux(semaineId);
        const eleves = this._eleves.filter(e => eleveIds.includes(e.id));
        if (!eleves.length) { Modal.alert('Erreur', 'Aucun élève sélectionné.'); return null; }
        return this._buildMultiDay(creneaux, params, jour, semaineId, eleves);
    },

    async _buildMultiAdultDay(jour, semaineId, adultNoms) {
        const params = await this._ensureParams();
        const qs = new URLSearchParams({ with_eleves: '1' });
        qs.set('semaine_id', semaineId !== null ? semaineId : 'null');
        let all = await API.get('creneaux.php?' + qs.toString());
        all = all.map(c => ({ ...c, heure_debut: c.heure_debut?.substring(0, 5) }));
        const creneaux = all.filter(c => c.jour === jour && c.adulte && adultNoms.some(n => (c.adulte || '').endsWith(n)));

        const timeSlots = this._genTimeSlots(
            params.horaires?.debut || '08:30',
            params.horaires?.fin || '16:30',
            Math.max(params.horaires?.duree_creneau || 15, 30)
        );
        const couleurs = params.couleurs_types || {};
        const dureePas = params.horaires?.duree_creneau || 15;

        const matchName = (cAdulte) => {
            for (const n of adultNoms) {
                if ((cAdulte || '').endsWith(n)) return n;
            }
            return null;
        };
        const grid = {};
        adultNoms.forEach(n => { grid[n] = {}; });
        creneaux.forEach(c => {
            const matched = matchName(c.adulte);
            if (!matched) return;
            if (!grid[matched][c.heure_debut]) grid[matched][c.heure_debut] = { eleves: [], rowspan: 1 };
            const nom = [c.eleve_prenom, c.eleve_nom].filter(Boolean).join(' ');
            if (nom && !grid[matched][c.heure_debut].eleves.includes(nom)) grid[matched][c.heure_debut].eleves.push(nom);
            grid[matched][c.heure_debut].rowspan = Math.max(
                grid[matched][c.heure_debut].rowspan,
                Math.max(1, Math.round((c.duree || dureePas) / dureePas))
            );
        });

        const header = [{ text: 'Heure', style: 'tableHeader' }];
        adultNoms.forEach(n => header.push({ text: n, style: 'tableHeader' }));
        const body = [header];
        timeSlots.forEach(h => {
            const row = [{ text: h, style: 'hourCell' }];
            adultNoms.forEach(n => {
                const cell = grid[n]?.[h];
                row.push(cell?.eleves.length ? this._studentGrid(cell.eleves) : { text: '', style: 'slotCell' });
            });
            body.push(row);
        });

        this._applyRowspan(body, timeSlots, adultNoms, (n, h) => grid[n]?.[h]);

        return {
            pageSize: 'A4', pageOrientation: 'landscape', pageMargins: [15, 15, 15, 15],
            content: [
                { text: `Emploi du temps · ${jour.charAt(0).toUpperCase() + jour.slice(1)}`, style: 'header' },
                { text: this._semaineLabel(semaineId) + ` · ${adultNoms.length} adulte(s)`, style: 'subheader' },
                { table: { headerRows: 1, widths: ['auto', ...adultNoms.map(() => '*')], body }, fontSize: 7 },
            ],
            styles: this._makeStyles({ header: { fontSize: 12, margin: [0, 0, 0, 3] }, subheader: { margin: [0, 0, 0, 6] } }),
        };
    },

    /* ---- Builders pdfmake EDT ---- */

    _buildPersonWeek(creneaux, params, label, semaineId) {
        const horaires = params.horaires || { debut: '08:30', fin: '16:30', duree_creneau: 15 };
        const jours = params.jours_affiches || ['lundi','mardi','mercredi','jeudi','vendredi','samedi'];
        const couleurs = params.couleurs_types || {};
        const dureePas = horaires.duree_creneau || 15;
        const { slots: timeSlots, pauseRows } = this._genTimeSlotsSmart(params);
        const pauseByIndex = {};
        (pauseRows || []).forEach(p => { pauseByIndex[p.index] = p; });
        const joursLabels = jours.map(j => j.charAt(0).toUpperCase() + j.slice(1,3)).join(' · ');

        const grid = {};
        jours.forEach(j => { grid[j] = {}; });
        creneaux.forEach(c => {
            if (!grid[c.jour]) return;
            const idx = timeSlots.indexOf(c.heure_debut);
            if (idx === -1) return;
            grid[c.jour][c.heure_debut] = { creneau: c, rowspan: Math.max(1, Math.round((c.duree || dureePas) / dureePas)) };
        });

        const header = [{ text: 'Heure', style: 'tableHeader' }];
        jours.forEach(j => header.push({ text: j.charAt(0).toUpperCase() + j.slice(1,3), style: 'tableHeader' }));
        const body = [header];
        timeSlots.forEach((h, slotIdx) => {
            const pauseRow = pauseByIndex[slotIdx];
            if (pauseRow) {
                body.push([{
                    text: pauseRow.label,
                    style: 'midiPause',
                    colSpan: jours.length + 1,
                    fillColor: '#fff3e0',
                    color: '#e65100',
                }].concat(jours.map(() => ({}))));
            }
            const row = [{ text: h, style: 'hourCell' }];
            jours.forEach(j => {
                const cell = grid[j][h];
                if (cell) {
                    const c = cell.creneau;
                    const couleur = c.couleur_override || couleurs[c.regroupement_type] || '#fff';
                    const text = [c.regroupement_type || '', c.matiere || ''].filter(Boolean).join('\n');
                    row.push({ text, fillColor: couleur, color: this._textColor(couleur), style: 'slotCell' });
                } else { row.push({ text: '', style: 'slotCell' }); }
            });
            body.push(row);
        });

        this._applyRowspan(body, timeSlots, jours, (j, h) => grid[j]?.[h], pauseRows);

        return {
            pageSize: 'A4', pageOrientation: 'portrait', pageMargins: [20, 20, 20, 20],
            content: [
                { text: `Emploi du temps · ${label}`, style: 'header' },
                { text: this._semaineLabel(semaineId) + ` · ${joursLabels}`, style: 'subheader' },
                { table: { headerRows: 1, widths: ['auto', ...jours.map(() => '*')], body }, fontSize: 7.5 },
                ...this._legendParts(couleurs),
            ],
            styles: this._makeStyles({ header: { fontSize: 13, margin: [0, 0, 0, 4] } }),
        };
    },

    _buildAdultWeek(creneaux, params, adulteNom, semaineId, jourFiltre) {
        const horaires = params.horaires || { debut: '08:30', fin: '16:30', duree_creneau: 15 };
        let jours = params.jours_affiches || ['lundi','mardi','mercredi','jeudi','vendredi','samedi'];
        if (jourFiltre) jours = jours.filter(j => j === jourFiltre);
        const couleurs = params.couleurs_types || {};
        const dureePas = horaires.duree_creneau || 15;
        const { slots: timeSlots, pauseRows } = this._genTimeSlotsSmart(params);
        const pauseByIndex = {};
        (pauseRows || []).forEach(p => { pauseByIndex[p.index] = p; });

        const grid = {};
        jours.forEach(j => { grid[j] = {}; });
        creneaux.forEach(c => {
            if (!grid[c.jour]) return;
            if (!grid[c.jour][c.heure_debut]) grid[c.jour][c.heure_debut] = { eleves: [], rowspan: 1 };
            const nom = [c.eleve_prenom, c.eleve_nom].filter(Boolean).join(' ');
            if (nom && !grid[c.jour][c.heure_debut].eleves.includes(nom)) grid[c.jour][c.heure_debut].eleves.push(nom);
            grid[c.jour][c.heure_debut].rowspan = Math.max(grid[c.jour][c.heure_debut].rowspan, Math.max(1, Math.round((c.duree || dureePas) / dureePas)));
        });

        const header = [{ text: 'Heure', style: 'tableHeader' }];
        jours.forEach(j => header.push({ text: j.charAt(0).toUpperCase() + j.slice(1,3), style: 'tableHeader' }));
        const body = [header];
        timeSlots.forEach((h, slotIdx) => {
            const pauseRow = pauseByIndex[slotIdx];
            if (pauseRow) {
                body.push([{
                    text: pauseRow.label,
                    style: 'midiPause',
                    colSpan: jours.length + 1,
                    fillColor: '#fff3e0',
                    color: '#e65100',
                }].concat(jours.map(() => ({}))));
            }
            const row = [{ text: h, style: 'hourCell' }];
            jours.forEach(j => {
                const cell = grid[j][h];
                row.push(cell?.eleves.length ? this._studentGrid(cell.eleves) : { text: '', style: 'slotCell' });
            });
            body.push(row);
        });

        this._applyRowspan(body, timeSlots, jours, (j, h) => grid[j]?.[h], pauseRows);

        return {
            pageSize: 'A4', pageOrientation: 'portrait', pageMargins: [20, 20, 20, 20],
            content: [
                { text: `Emploi du temps · ${adulteNom}`, style: 'header' },
                { text: this._semaineLabel(semaineId) + (jourFiltre ? ` · ${jourFiltre.charAt(0).toUpperCase() + jourFiltre.slice(1)}` : ''), style: 'subheader' },
                { table: { headerRows: 1, widths: ['auto', ...jours.map(() => '*')], body }, fontSize: 7 },
            ],
            styles: this._makeStyles({ header: { fontSize: 13, margin: [0, 0, 0, 4] } }),
        };
    },

    _buildMultiDay(creneaux, params, jour, semaineId, eleves) {
        const horaires = params.horaires || { debut: '08:30', fin: '16:30', duree_creneau: 15 };
        const couleurs = params.couleurs_types || {};
        const dureePas = horaires.duree_creneau || 15;
        const timeSlots = this._genTimeSlots(horaires.debut, horaires.fin, dureePas);
        const nbTotal = eleves.length;

        // Compact d'abord : jusqu'à MAX_PAR_PAGE élèves sur une page, au-delà on bascule en multi-page
        // (pdfmake ne coupe pas les colonnes automatiquement, il faut découper en tableaux/page).
        const MAX_PAR_PAGE = 16;

        const grid = {};
        eleves.forEach(e => { grid[e.id] = {}; });
        creneaux.filter(c => c.jour === jour).forEach(c => {
            if (!grid[c.eleve_id]) return;
            grid[c.eleve_id][c.heure_debut] = { creneau: c, rowspan: Math.max(1, Math.round((c.duree || dureePas) / dureePas)) };
        });

        // Découpage des élèves en pages (chaque page = un tableau avec son propre en-tête).
        const pages = [];
        for (let i = 0; i < nbTotal; i += MAX_PAR_PAGE) pages.push(eleves.slice(i, i + MAX_PAR_PAGE));

        const content = [];
        pages.forEach((chunk, pageIdx) => {
            const isFirst = pageIdx === 0;
            // Police adaptée au nombre d'élèves de LA page (une page peu remplie garde une police lisible).
            const fontSize = chunk.length <= 6 ? 7.5 : chunk.length <= 10 ? 7 : chunk.length <= 12 ? 6.5 : 6;

            // En-tête compact « Prénom N. » dès qu'il y a beaucoup d'élèves sur la page.
            const headerLabel = (e) => {
                const prenom = (e.prenom || '').trim();
                const nom = (e.nom || '').trim();
                if (chunk.length <= 9) return (prenom + ' ' + nom).trim();
                const initiale = nom ? nom.charAt(0).toUpperCase() + '.' : '';
                return (prenom + (initiale ? ' ' + initiale : '')).trim();
            };

            const header = [{ text: 'Heure', style: { fontSize, bold: true, fillColor: '#eee', alignment: 'center' } }];
            chunk.forEach(e => header.push({ text: headerLabel(e), style: { fontSize, bold: true, fillColor: '#eee', alignment: 'center' } }));
            const body = [header];
            timeSlots.forEach(h => {
                const row = [{ text: h, style: { fontSize, bold: true, alignment: 'center', fillColor: '#fafafa' } }];
                chunk.forEach(e => {
                    const cell = grid[e.id]?.[h];
                    if (cell) {
                        const c = cell.creneau;
                        const couleur = c.couleur_override || couleurs[c.regroupement_type] || '#fff';
                        // Le type de regroupement est porté par la couleur + la légende : on
                        // affiche « matière · adulte » pour ne pas tronquer la table (bug jour/élèves).
                        const parts = [c.matiere || '', c.adulte || ''].filter(Boolean);
                        row.push({ text: parts.join(' · '), fillColor: couleur, color: this._textColor(couleur), style: { fontSize, alignment: 'center', margin: [1, 1] } });
                    } else { row.push({ text: '', style: { fontSize, alignment: 'center', margin: [1, 1] } }); }
                });
                body.push(row);
            });
            this._applyRowspan(body, timeSlots, chunk, (e, h) => grid[e.id]?.[h]);

            const debut = pageIdx * MAX_PAR_PAGE + 1;
            const fin = debut + chunk.length - 1;
            const sub = pages.length > 1
                ? this._semaineLabel(semaineId) + ` · ${jour.charAt(0).toUpperCase() + jour.slice(1)} · élèves ${debut} à ${fin} / ${nbTotal}`
                : this._semaineLabel(semaineId) + ` · ${nbTotal} élève(s)`;

            content.push({
                text: `Emploi du temps · ${jour.charAt(0).toUpperCase() + jour.slice(1)}`,
                style: 'header',
                pageBreak: isFirst ? undefined : 'before',
            });
            content.push({ text: sub, style: 'subheader' });
            content.push({ table: { headerRows: 1, widths: ['auto', ...chunk.map(() => '*')], body }, fontSize });
            content.push(...this._legendParts(couleurs));
        });

        return {
            pageSize: 'A4', pageOrientation: 'landscape', pageMargins: [10, 12, 10, 12],
            content,
            styles: this._makeStyles({ header: { fontSize: 12, margin: [0, 0, 0, 3] }, subheader: { margin: [0, 0, 0, 6] } }),
        };
    },

    /* ---- Helpers EDT ---- */

    _roleLabel(role) {
        const labels = {
            enseignant: 'Enseignant', coordo_ulis: 'Coordo ULIS',
            aeshco: 'AESHco', aeshi: 'AESHi', aeshm: 'AESHm',
            specialiste: 'Spécialiste', educateur: 'Éducateur', assistant_familial: 'Ass. familial',
        };
        return labels[role] || role?.replace(/_/g, ' ') || 'Autre';
    },

    _adulteSuffix(a) {
        if (a.role === 'enseignant') {
            if (a.fonction === 'coordo_ulis') return 'Coordo ULIS';
            if (a.fonction) return a.fonction;
            const classes = (this._classes || []).filter(c => (c.enseignants || []).some(e => e.adulte_id === a.id));
            return classes.length ? classes.map(c => c.nom).join(' · ') : '';
        }
        if (a.role?.startsWith('aesh')) return this._roleLabel(a.role);
        if (a.fonction) return a.fonction;
        return this._roleLabel(a.role) || '';
    },

    _buildAdultOptions() {
        const groups = { enseignants: [], aesh: [], coordo: [], autres: [] };
        this._adultes.forEach(a => {
            const r = a.role || '';
            if (r === 'enseignant') groups.enseignants.push(a);
            else if (r.startsWith('aesh')) groups.aesh.push(a);
            else if (r === 'coordo_ulis') groups.coordo.push(a);
            else groups.autres.push(a);
        });
        const opt = list => list.map(a => {
            const suffix = this._adulteSuffix(a);
            return `<option value="${escapeHtml(a.nom || '')}">${escapeHtml(a.nom || '')}${suffix ? ' · ' + escapeHtml(suffix) : ''}</option>`;
        }).join('');
        let html = '';
        if (groups.enseignants.length) html += `<optgroup label="👩‍🏫 Enseignants">${opt(groups.enseignants)}</optgroup>`;
        if (groups.aesh.length) html += `<optgroup label="🤝 AESH">${opt(groups.aesh)}</optgroup>`;
        if (groups.coordo.length) html += `<optgroup label="📋 Coordo ULIS">${opt(groups.coordo)}</optgroup>`;
        if (groups.autres.length) html += `<optgroup label="🌍 Autres">${opt(groups.autres)}</optgroup>`;
        return html || '<option value="">Aucun adulte</option>';
    },

    _buildAdultMultiOptions() {
        return this._adultes.map(a => {
            const suffix = this._adulteSuffix(a);
            return `<option value="${escapeHtml(a.nom || '')}" selected>${escapeHtml(a.nom || '')}${suffix ? ' · ' + escapeHtml(suffix) : ''}</option>`;
        }).join('');
    },

    _legendParts(couleurs) {
        const entries = Object.entries(couleurs).filter(([,c]) => c && c !== '#fff');
        if (!entries.length) return [];
        return [
            { text: 'Légende :', style: 'legendTitle', margin: [0, 10, 0, 2] },
            {
                table: {
                    body: [entries.map(([type, c]) => ({
                        text: ` ${type} `, fillColor: c, color: this._textColor(c),
                        alignment: 'center', margin: [3, 1],
                    }))],
                },
                layout: 'noBorders',
                margin: [0, 0, 0, 10],
            }
        ];
    },

    _genTimeSlots(debut, fin, interval) {
        const slots = [];
        const [dh, dm] = debut.split(':').map(Number);
        const [fh, fm] = fin.split(':').map(Number);
        let min = dh * 60 + dm;
        const endMin = fh * 60 + fm;
        while (min < endMin) {
            slots.push(`${String(Math.floor(min / 60)).padStart(2, '0')}:${String(min % 60).padStart(2, '0')}`);
            min += interval;
        }
        return slots;
    },

    _genTimeSlotsSmart(params) {
        // Grille continue : les pauses (récréation, pause du midi) sont des créneaux
        // normaux, imprimés comme les autres. Plus de ligne « pause » injectée.
        const horaires = params.horaires || { debut: '08:30', fin: '16:30', duree_creneau: 15 };
        const dureePas = horaires.duree_creneau || 15;
        const debut = horaires.debut || '08:30';
        const fin = horaires.fin || '16:30';
        return { slots: this._genTimeSlots(debut, fin, dureePas), pauseRows: [] };
    },

    _textColor(bg) {
        if (!bg || bg === '#fff') return '#333';
        const hex = bg.replace('#', '');
        const r = parseInt(hex.substring(0,2), 16);
        const g = parseInt(hex.substring(2,4), 16);
        const b = parseInt(hex.substring(4,6), 16);
        return (r * 0.299 + g * 0.587 + b * 0.114) > 150 ? '#333' : '#fff';
    },

    _studentGrid(students) {
        if (!students || !students.length) return { text: '', style: 'slotCell' };
        const lines = students.map(s => {
            const parts = s.split(' ');
            const p = parts[0] || '';
            const init = parts.length > 1 ? (parts[parts.length-1].charAt(0) + '.') : '';
            return init ? `${p} ${init}` : p;
        });
        if (lines.length <= 3) return { text: lines.join('\n'), style: 'slotCell', fontSize: 5.5 };
        const mid = Math.ceil(lines.length / 2);
        const col = lines.slice(0, mid).map((name, i) => {
            const right = lines[mid + i] || '';
            return name.padEnd(14) + right;
        });
        return { text: col.join('\n'), style: 'slotCell', fontSize: 5.5 };
    },

    _applyRowspan(body, timeSlots, items, getGridCell, pauseRows = []) {
        timeSlots.forEach((h, rowIdx) => {
            const pausesBefore = pauseRows.filter(p => p.index <= rowIdx).length;
            const bodyIdx = rowIdx + 1 + pausesBefore;
            items.forEach((item, colIdx) => {
                const cell = getGridCell(item, h);
                if (cell && cell.rowspan > 1) {
                    // Clamper le rowSpan au nombre de lignes restantes (évite pdfmake crash markVSpans)
                    const maxSpan = body.length - bodyIdx;
                    const span = Math.min(cell.rowspan, maxSpan);
                    if (span > 1 && bodyIdx < body.length) {
                        body[bodyIdx][colIdx + 1].rowSpan = span;
                        for (let r = 1; r < span; r++)
                            body[bodyIdx + r][colIdx + 1] = { text: '' };
                    }
                }
            });
        });
    },

    _makeStyles(overrides) {
        return { ...BASE_STYLES, ...overrides };
    },

    async _loadCreneaux(semaineId, eleveId) {
        const qs = new URLSearchParams({ with_eleves: '1' });
        qs.set('semaine_id', semaineId !== null ? semaineId : 'null');
        let creneaux = await API.get('creneaux.php?' + qs.toString());
        creneaux = creneaux.map(c => ({ ...c, heure_debut: c.heure_debut?.substring(0, 5) }));
        if (eleveId) creneaux = creneaux.filter(c => Number(c.eleve_id) === Number(eleveId));
        return creneaux;
    },

    _semaineLabel(semaineId) {
        return semaineId ? `Semaine ${semaineId}` : 'Semaine type';
    },

    _selectAllToggle(selectId, selectAll) {
        const el = document.getElementById(selectId);
        if (!el) return;
        Array.from(el.options).forEach(o => { o.selected = selectAll; });
    },

    _bindWeekSearch() {
        const input = document.getElementById('print-semaine-search');
        const select = document.getElementById('print-semaine');
        if (!input || !select) return;
        const allOpts = Array.from(select.options).map(o => ({ value: o.value, text: o.text }));
        input.addEventListener('input', () => {
            const q = input.value.toLowerCase();
            select.innerHTML = allOpts
                .filter(o => !q || o.text.toLowerCase().includes(q))
                .map(o => `<option value="${o.value}">${escapeHtml(o.text)}</option>`)
                .join('');
        });
    },

});
