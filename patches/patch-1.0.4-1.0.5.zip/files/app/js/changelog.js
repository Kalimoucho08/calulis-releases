/**
 * Calulis — Changelog (Nouveautés)
 * Résumé des nouveautés depuis la v1.0. À mettre à jour à CHAQUE release
 * (voir scripts/release-checklist.sh — étape « quoi de neuf »).
 */
const Changelog = {
    /** Dernière version connue (mise à jour à chaque release) */
    latest: '1.0.5',
    /** Entrées de la plus récente à la plus ancienne */
    entries: [
        {
            version: '1.0.5', date: '19 août 2026',
            items: [
                '🔧 Rattachement d'un élève à une classe corrigé (l'enregistrement échouait avec une erreur de base de données)',
            ],
        },
        {
            version: '1.0.4', date: '19 août 2026',
            items: [
                '💬 Messages d\'erreur enfin compréhensibles : plus de « Internal Server Error », Calulis explique quoi faire',
                '🐛 Bouton « Signaler un bug » sur les écrans d\'erreur (infos techniques envoyées à l\'équipe)',
                '🛠️ Lanceur : bouton « Copier le rapport », aide intégrée, erreurs de démarrage claires',
                '⚡ Le lanceur se met à jour automatiquement, comme l\'application',
                'ℹ️ Version de l\'application affichée + cette page « Quoi de neuf »',
            ],
        },
        {
            version: '1.0.3', date: '17 août 2026',
            items: [
                '🗓️ Calendrier scolaire (vacances) réparé sur toutes les machines Windows',
                '💬 Messages d\'erreur qui guident (connexion, certificat, DNS…)',
                '⚡ Les pages se rafraîchissent correctement après chaque mise à jour',
            ],
        },
        {
            version: '1.0.2', date: '17 août 2026',
            items: [
                '🏫 Établissements : ensembles scolaires, statut public/privé',
                '🏷️ Tous les niveaux : maternelle, élémentaire, collège (6e→3e), lycée, lycée professionnel',
                '👥 Création d\'élève guidée (bouton « + Créer » pour l\'établissement manquant)',
            ],
        },
        {
            version: '1.0.1', date: '16 août 2026',
            items: [
                '🔧 Correction du bug « ID requis » (modification/suppression élève, adulte, classe)',
            ],
        },
        {
            version: '1.0.0', date: '10 août 2026',
            items: [
                '🎉 Première version portable, sans installation : élèves, emploi du temps, réunions, annuaire, impression PDF',
                '🔄 Mises à jour automatiques, sauvegarde/restauration des données',
            ],
        },
    ],
};
