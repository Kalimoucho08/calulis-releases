<?php
/** Calulis — Model Élève Année (versionnement des données scolaires par année) */
require_once __DIR__ . '/../config.php';

class EleveAnnee {
    /** Récupère la version d'un élève pour une année donnée */
    public static function getByEleveAndAnnee(int $eleveId, int $anneeId): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT ea.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
            FROM eleve_annees ea
            JOIN eleves e ON e.id = ea.eleve_id
            WHERE ea.eleve_id = :eleve_id AND ea.annee_scolaire_id = :annee_id
            LIMIT 1');
        $stmt->execute(['eleve_id' => $eleveId, 'annee_id' => $anneeId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Historique complet d'un élève à travers les années */
    public static function getHistory(int $eleveId): array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT ea.*, a.nom AS annee_nom, a.date_debut, a.date_fin
             FROM eleve_annees ea
             JOIN annees_scolaires a ON a.id = ea.annee_scolaire_id
             WHERE ea.eleve_id = :eleve_id
             ORDER BY a.date_debut DESC'
        );
        $stmt->execute(['eleve_id' => $eleveId]);
        return $stmt->fetchAll();
    }

    /** Tous les élèves avec leurs données pour une année donnée */
    public static function getAllByAnnee(int $anneeId): array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT ea.*, e.nom, e.prenom, e.date_naissance, e.actif, e.ordre,
                    e.ecole_origine, e.ecole_origine_id, e.date_entree_ulis,
                    e.telephone_urgence, e.telephone, e.email, e.adresse,
                    e.allergies, e.regime_alimentaire, e.suivi_medical, e.precautions_medicales, e.pai, e.lien_pai,
                    e.liens_mdph, e.remarques, e.notifications,
                    e.mdph_ulis_date_fin, e.mdph_ulis_statut,
                    e.mdph_sessad_date_fin, e.mdph_sessad_statut,
                    e.mdph_aesh_date_fin, e.mdph_aesh_statut,
                    e.mdph_transport_date_fin, e.mdph_transport_statut,
                    e.mdph_autre_date_fin, e.mdph_autre_statut, e.mdph_autre_libelle,
                    e.ase_place, e.ase_structure_nom, e.ase_structure_adresse, e.ase_structure_telephone,
                    e.ase_referent_nom, e.ase_referent_telephone, e.ase_referent_email, e.ase_lien_ppe,
                    c.nom AS classe_nom
             FROM eleve_annees ea
             JOIN eleves e ON e.id = ea.eleve_id
             LEFT JOIN classes c ON c.id = ea.classe_id
             WHERE ea.annee_scolaire_id = :annee_id
             ORDER BY e.ordre, e.nom, e.prenom'
        );
        $stmt->execute(['annee_id' => $anneeId]);
        return $stmt->fetchAll();
    }

    /** Normalise les champs entiers : '' → null (MySQL 8 strict rejette
     *  "Incorrect integer value: ''" alors que MariaDB le tolère). */
    private static function _normalize(array $data): array {
        foreach (['classe_id', 'etablissement_id'] as $f) {
            if (!array_key_exists($f, $data)) continue;
            $data[$f] = ($data[$f] === '' || $data[$f] === null || $data[$f] === 'null')
                ? null : (int)$data[$f];
        }
        if (array_key_exists('ulis', $data) && $data['ulis'] === '') {
            $data['ulis'] = 0;
        }
        // Sécurité : classe est varchar(20) — tronquer plutôt que planter
        // (« data too long » en mode strict → erreur générique côté UI)
        if (array_key_exists('classe', $data) && $data['classe'] !== null) {
            $data['classe'] = mb_substr((string)$data['classe'], 0, 20);
        }
        return $data;
    }

    /** Crée ou met à jour la version d'un élève pour une année */
    public static function upsert(int $eleveId, int $anneeId, array $data): bool {
        $pdo = getDB();
        $data = self::_normalize($data);
        
        // Vérifier si une ligne existe déjà
        $existing = self::getByEleveAndAnnee($eleveId, $anneeId);
        
        // A4 : PEC retiré — géré par la table pec_eleves (multi-spécialités)
        $fields = ['classe_id', 'classe', 'ulis', 'groupe', 'niveau_scolaire',
            'etablissement_id', 'aesh_type', 'aesh_nom', 'aesh_heures', 'aesh_mutualise_avec',
            'transport', 'cantine'];
        
        if ($existing) {
            // UPDATE
            $sets = [];
            $params = ['id' => $existing['id']];
            foreach ($fields as $f) {
                if (array_key_exists($f, $data)) {
                    $sets[] = "$f = :$f";
                    $params[$f] = $data[$f];
                }
            }
            if (empty($sets)) return true;
            $sql = 'UPDATE eleve_annees SET ' . implode(', ', $sets) . ', updated_at = CURRENT_TIMESTAMP WHERE id = :id';
            $stmt = $pdo->prepare($sql);
            return $stmt->execute($params);
        } else {
            // INSERT
            $cols = ['eleve_id', 'annee_scolaire_id'];
            $vals = [':eleve_id', ':annee_id'];
            $params = ['eleve_id' => $eleveId, 'annee_id' => $anneeId];
            foreach ($fields as $f) {
                if (array_key_exists($f, $data)) {
                    $cols[] = $f;
                    $vals[] = ":$f";
                    $params[$f] = $data[$f];
                }
            }
            $sql = 'INSERT INTO eleve_annees (' . implode(', ', $cols) . ') VALUES (' . implode(', ', $vals) . ')';
            $stmt = $pdo->prepare($sql);
            return $stmt->execute($params);
        }
    }

    /** Duplique les données d'un élève vers une nouvelle année */
    public static function copyToAnnee(int $eleveId, int $fromAnneeId, int $toAnneeId): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            // A4 : PEC retiré — géré par la table pec_eleves (multi-spécialités)
            'INSERT IGNORE INTO eleve_annees (eleve_id, annee_scolaire_id,
                classe_id, classe, ulis, groupe, niveau_scolaire, etablissement_id,
                aesh_type, aesh_nom, aesh_heures, aesh_mutualise_avec,
                transport, cantine)
             SELECT :eleve_id, :to_annee_id,
                classe_id, classe, ulis, groupe, niveau_scolaire, etablissement_id,
                aesh_type, aesh_nom, aesh_heures, aesh_mutualise_avec,
                transport, cantine
             FROM eleve_annees
             WHERE eleve_id = :eleve_id2 AND annee_scolaire_id = :from_annee_id
             LIMIT 1'
        );
        $stmt->execute([
            'eleve_id' => $eleveId,
            'to_annee_id' => $toAnneeId,
            'eleve_id2' => $eleveId,
            'from_annee_id' => $fromAnneeId,
        ]);
        return true;
    }

    /** Supprime la version d'un élève pour une année */
    public static function delete(int $eleveId, int $anneeId): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM eleve_annees WHERE eleve_id = :eleve_id AND annee_scolaire_id = :annee_id');
        return $stmt->execute(['eleve_id' => $eleveId, 'annee_id' => $anneeId]);
    }
}
