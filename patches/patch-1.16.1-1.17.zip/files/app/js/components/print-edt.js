/**
 * Calulis — Print EDT : builders emplois du temps (pdfmake)
 * Attaché à l'objet Print via Object.assign.
 *
 * Depuis la refonte d'impression (18/10/2026), plus aucune marges, police, pied de page ni
 * pagination n'est décidée ici : tout passe par le socle (`print-socle.js`).
 *
 * Règles visibles :
 *  - les couleurs sont celles de l'écran, sur TOUTES les vues (adulte incluse) ;
 *  - une ligne = un pas de créneau, hauteur fixe (le temps est proportionnel) ;
 *  - si la journée ne tient pas, elle est RÉPARTIE (matin / après-midi), jamais remplie au maximum ;
 *  - si les colonnes sont trop nombreuses, elles sont réparties en parts égales.
 */

Object.assign(Print, {

    /* ---- Entrées publiques (appelées par print.js) ---- */

    async _buildStudentWeek(eleveId, semaineId) {
        await this._ensureParams();
        const eleve = this._eleves.find(e => e.id === eleveId);
        const label = eleve ? `${eleve.prenom || ''} ${eleve.nom || ''}`.trim() : `Élève #${eleveId}`;
        const creneaux = await this._loadCreneaux(semaineId, eleveId);
        const classe = eleve ? (eleve.classe_nom || eleve.classe || '') : '';
        return this._buildPersonWeek(creneaux, this._params, label, semaineId, classe);
    },

    async _buildAdultWeekFromAPI(adulteNom, semaineId) {
        await this._ensureParams();
        const qs = new URLSearchParams({ adulte: adulteNom });
        qs.set('semaine_id', semaineId !== null ? semaineId : 'null');
        let creneaux = await API.get('creneaux.php?' + qs.toString());
        creneaux = creneaux.map(c => ({ ...c, heure_debut: (c.heure_debut || '').substring(0, 5) }));
        return this._buildAdultWeek(creneaux, this._params, adulteNom, semaineId);
    },

    async _buildMultiDayFromAPI(jour, semaineId, eleveIds) {
        await this._ensureParams();
        const creneaux = await this._loadCreneaux(semaineId);
        const eleves = this._eleves.filter(e => eleveIds.includes(e.id));
        if (!eleves.length) { Modal.alert('Erreur', 'Aucun élève sélectionné.'); return null; }
        return this._buildMultiDay(creneaux, jour, semaineId, eleves);
    },

    async _buildMultiAdultDay(jour, semaineId, adultNoms) {
        await this._ensureParams();
        const qs = new URLSearchParams({ with_eleves: '1' });
        qs.set('semaine_id', semaineId !== null ? semaineId : 'null');
        let all = await API.get('creneaux.php?' + qs.toString());
        all = all.map(c => ({ ...c, heure_debut: (c.heure_debut || '').substring(0, 5) }));
        // `creneaux.adulte` est une CHAÎNE D'AFFICHAGE multi-adultes, ex.
        // « M. DUPONT Marie, MARTIN Paul » (agenda.js, civilité comprise). Un `endsWith`
        // global ne voyait que le DERNIER nom : un créneau co-animé manquait dans la colonne
        // du premier adulte, sans aucun signe. On découpe donc sur la virgule et on compare
        // chaque nom (le préfixe de civilité reste toléré par endsWith).
        const adultesDuCreneau = (c) => String(c.adulte || '')
            .split(',').map(s => s.trim()).filter(Boolean);
        const concerne = (c) => adultesDuCreneau(c).some(a => adultNoms.some(n => a === n || a.endsWith(n)));
        const creneaux = all.filter(c => c.jour === jour && concerne(c));

        const horaires = this._horaires();
        const pas = horaires.duree_creneau || 15;
        const slots = this._genTimeSlots(horaires.debut || '08:30', horaires.fin || '16:30', pas);
        const couleurs = this._couleursDoc();

        const grid = {};
        adultNoms.forEach(n => { grid[n] = {}; });
        creneaux.forEach(c => {
            const hh = (c.heure_debut || '').substring(0, 5);
            if (slots.indexOf(hh) === -1) return;
            // Un créneau co-animé se place dans CHAQUE colonne des adultes concernés.
            const noms = adultesDuCreneau(c);
            const concernes = adultNoms.filter(n => noms.some(a => a === n || a.endsWith(n)));
            concernes.forEach(nom => {
                if (!grid[nom][hh]) grid[nom][hh] = { eleves: [], couleur: null, span: 1 };
                const cell = grid[nom][hh];
                const eleve = [c.eleve_prenom, c.eleve_nom].filter(Boolean).join(' ');
                if (eleve && !cell.eleves.includes(eleve)) cell.eleves.push(eleve);
                if (!cell.couleur) cell.couleur = this._couleurCase(c, couleurs);
                cell.span = Math.max(cell.span, Math.max(1, Math.round((c.duree || pas) / pas)));
            });
        });
        Object.keys(grid).forEach(n => Object.keys(grid[n]).forEach(hh => {
            const cell = grid[n][hh];
            cell.texte = cell.texteCourt = cell.eleves.join(', ');
        }));

        return this._documentJour({
            cle: 'edt_jour_adultes', orientation: 'landscape',
            titre: `Emploi du temps · ${this._capitaliser(jour)}`,
            sousTitre: this._semaineLabel(semaineId),
            colonnes: adultNoms.map(n => ({ cle: n, label: n })),
            libellePersonnes: 'adultes',
            slots, creneaux, grid, couleurs,
            contexte: { semaine: this._semaineLabel(semaineId), jour: this._capitaliser(jour) },
        });
    },

    /* ---- Documents ---- */

    _buildPersonWeek(creneaux, params, label, semaineId, classe) {
        const horaires = this._horaires();
        const pas = horaires.duree_creneau || 15;
        const jours = params.jours_affiches || ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
        const couleurs = this._couleursDoc();
        const slots = this._genTimeSlots(horaires.debut || '08:30', horaires.fin || '16:30', pas);

        const grid = {};
        jours.forEach(j => { grid[j] = {}; });
        creneaux.forEach(c => {
            if (!grid[c.jour]) return;
            const hh = (c.heure_debut || '').substring(0, 5);
            if (slots.indexOf(hh) === -1) return;
            grid[c.jour][hh] = {
                texte: [c.regroupement_type || '', c.matiere || ''].filter(Boolean).join('\n'),
                texteCourt: c.regroupement_type || c.matiere || '',
                couleur: this._couleurCase(c, couleurs),
                span: Math.max(1, Math.round((c.duree || pas) / pas)),
            };
        });

        return this._documentSemaine({
            cle: 'edt_semaine_eleve', orientation: 'portrait',
            titre: `Emploi du temps · ${label}`,
            sousTitre: `${this._semaineLabel(semaineId)} · ${this._joursLabels(jours)}`,
            jours, slots, creneaux, grid, couleurs,
            contexte: { nom: label, classe: classe || '', semaine: this._semaineLabel(semaineId) },
        });
    },

    _buildAdultWeek(creneaux, params, adulteNom, semaineId) {
        const horaires = this._horaires();
        const pas = horaires.duree_creneau || 15;
        const jours = params.jours_affiches || ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
        const couleurs = this._couleursDoc();
        const slots = this._genTimeSlots(horaires.debut || '08:30', horaires.fin || '16:30', pas);

        const brut = {};
        jours.forEach(j => { brut[j] = {}; });
        creneaux.forEach(c => {
            if (!brut[c.jour]) return;
            const hh = (c.heure_debut || '').substring(0, 5);
            if (slots.indexOf(hh) === -1) return;
            if (!brut[c.jour][hh]) brut[c.jour][hh] = { noms: [], matieres: [], couleur: null, span: 1 };
            const cell = brut[c.jour][hh];
            const nom = [c.eleve_prenom, c.eleve_nom].filter(Boolean).join(' ');
            if (nom && !cell.noms.includes(nom)) cell.noms.push(nom);
            if (c.matiere && !cell.matieres.includes(c.matiere)) cell.matieres.push(c.matiere);
            if (!cell.couleur) cell.couleur = this._couleurCase(c, couleurs);
            cell.span = Math.max(cell.span, Math.max(1, Math.round((c.duree || pas) / pas)));
        });

        const grid = {};
        jours.forEach(j => {
            grid[j] = {};
            Object.keys(brut[j]).forEach(hh => {
                const cell = brut[j][hh];
                const noms = cell.noms.join(', ');
                grid[j][hh] = {
                    texte: [noms, cell.matieres.join(' · ')].filter(Boolean).join('\n'),
                    texteCourt: noms,
                    couleur: cell.couleur,
                    span: cell.span,
                };
            });
        });

        return this._documentSemaine({
            cle: 'edt_semaine_adulte', orientation: 'portrait',
            titre: `Emploi du temps · ${adulteNom}`,
            sousTitre: this._semaineLabel(semaineId),
            jours, slots, creneaux, grid, couleurs,
            contexte: { nom: adulteNom, semaine: this._semaineLabel(semaineId) },
        });
    },

    _buildMultiDay(creneaux, jour, semaineId, eleves) {
        const horaires = this._horaires();
        const pas = horaires.duree_creneau || 15;
        const slots = this._genTimeSlots(horaires.debut || '08:30', horaires.fin || '16:30', pas);
        const couleurs = this._couleursDoc();
        const duJour = creneaux.filter(c => c.jour === jour);

        const grid = {};
        eleves.forEach(e => { grid[e.id] = {}; });
        duJour.forEach(c => {
            const hh = (c.heure_debut || '').substring(0, 5);
            if (!grid[c.eleve_id] || slots.indexOf(hh) === -1) return;
            const texte = [c.matiere || '', c.adulte || ''].filter(Boolean).join(' · ');
            grid[c.eleve_id][hh] = {
                texte, texteCourt: texte,
                couleur: this._couleurCase(c, couleurs),
                span: Math.max(1, Math.round((c.duree || pas) / pas)),
            };
        });

        return this._documentJour({
            cle: 'edt_jour_eleves', orientation: 'landscape',
            titre: `Emploi du temps · ${this._capitaliser(jour)}`,
            sousTitre: this._semaineLabel(semaineId),
            // Deux libellés : le nom complet quand la page a peu de colonnes, « Prénom N. »
            // quand elles sont nombreuses. Le choix se fait PAR PAGE dans _documentJour
            // (spec § 2.5.3) et non sur le total, qui ignorait la répartition.
            colonnes: eleves.map(e => ({
                cle: e.id,
                label: this._labelEleve(e, 1),
                labelCourt: this._labelEleve(e, 99),
            })),
            libellePersonnes: 'élèves',
            slots, creneaux: duJour, grid, couleurs,
            contexte: { semaine: this._semaineLabel(semaineId), jour: this._capitaliser(jour) },
        });
    },

    /* ---- Composition des pages ---- */

    /**
     * Une grille « jour × heure » (semaine élève ou adulte).
     * Les lignes sont réparties en pages égales, coupées de préférence au milieu de la journée.
     */
    _documentSemaine({ cle, orientation, titre, sousTitre, jours, slots, creneaux, grid, couleurs, contexte }) {
        const reglages = this._reglagesImpression(cle);
        // L'orientation EFFECTIVE est celle des réglages du document : le socle l'applique
        // déjà à la page (`_docStandard`), et les calculs de hauteur/largeur doivent lire la
        // MÊME valeur — sinon une semaine passée en paysage garde des lignes calculées pour
        // le portrait et déborde sur une seconde page non répartie (trouvé le 18/10/2026).
        const orient = reglages.orientation || orientation;
        if (!slots.length) {
            return this._docStandard({
                cle, titre, sousTitre, orientation: orient, contexte,
                contenu: [...this._entetePage(titre, sousTitre), {
                    text: 'Aucun créneau : vérifiez les horaires dans Paramètres → Horaires.',
                    color: '#999', margin: [0, 12, 0, 0],
                }],
            });
        }
        const pas = this._horaires().duree_creneau || 15;
        const mise = this._miseEnPage(reglages, orient, slots.length);
        // L'avertissement voyage AVEC le document : un champ partagé pouvait être posé par
        // une génération périmée et s'afficher au-dessus du document suivant.
        const avertissement = (reglages.tenirSurUnePage !== false && mise.pages > 1)
            ? `Cette semaine ne tient pas sur une page sans devenir illisible : ${mise.pages} pages.`
            : '';
        const tailles = this._decouper(slots.length, mise.pages);
        const points = mise.pages > 1 ? this._pointsDeCoupe(slots, creneaux, tailles, pas, mise.maxParPage) : [];
        const parts = this._partsSelonPoints(slots, points);
        const entetes = jours.map(j => this._capitaliser(j).slice(0, 3));
        const maxChars = this._maxChars(reglages, orient, entetes.length, mise.police);

        const contenu = [];
        parts.forEach((part, i) => {
            if (i > 0) contenu.push({ text: '', pageBreak: 'before' });
            const sous = i === 0 ? sousTitre : `Suite · ${this._trancheLabel(part, pas)}`;
            contenu.push(...this._entetePage(titre, sous));
            contenu.push(this._tableauGrille({
                entetes,
                lignes: part,
                maxChars,
                hauteurLigne: mise.hauteurLigne,
                police: mise.police,
                deuxLignes: mise.deuxLignes,
                cellule: (c, r) => {
                    const cell = grid[jours[c]] && grid[jours[c]][part[r]];
                    if (!cell) return null;
                    return { ...cell, span: Math.min(cell.span, part.length - r) };
                },
            }));
            contenu.push(...this._legendParts(couleurs));
        });

        return this._poserAvertissement(
            this._docStandard({ cle, titre, sousTitre, orientation: orient, contenu, contexte }),
            avertissement);
    },

    /**
     * Une grille « personne × heure » (jour · élèves, jour · adultes).
     * Les colonnes sont réparties en parts égales, puis les lignes si la journée est trop longue.
     */
    _documentJour({ cle, orientation, titre, sousTitre, colonnes, libellePersonnes, slots, creneaux, grid, couleurs, contexte }) {
        const reglages = this._reglagesImpression(cle);
        const orient = reglages.orientation || orientation;
        if (!slots.length) {
            return this._docStandard({
                cle, titre, sousTitre, orientation: orient, contexte,
                contenu: [...this._entetePage(titre, sousTitre), {
                    text: 'Aucun créneau : vérifiez les horaires dans Paramètres → Horaires.',
                    color: '#999', margin: [0, 12, 0, 0],
                }],
            });
        }
        const pas = this._horaires().duree_creneau || 15;
        const mise = this._miseEnPage(reglages, orient, slots.length);
        const largeur = this._colonnesParPage(reglages, orient, colonnes.length);
        // Le nombre de pages est VERTICAL × HORIZONTAL : une journée de 20 élèves s'imprime
        // sur deux colonnes, donc deux pages, même si les lignes tiennent sur une.
        const nbPages = mise.pages * largeur.tailles.length;
        const avertissement = (reglages.tenirSurUnePage !== false && nbPages > 1)
            ? `Cette journée ne tient pas sur une page sans devenir illisible : ${nbPages} pages.`
            : '';
        const taillesLignes = this._decouper(slots.length, mise.pages);
        const points = mise.pages > 1 ? this._pointsDeCoupe(slots, creneaux, taillesLignes, pas, mise.maxParPage) : [];
        const partsLignes = this._partsSelonPoints(slots, points);

        const contenu = [];
        let premiere = true;
        let debut = 0;
        largeur.tailles.forEach((n) => {
            const chunk = colonnes.slice(debut, debut + n);
            const depuis = debut + 1;
            const jusqua = debut + n;
            debut += n;
            const maxChars = this._maxChars(reglages, orient, chunk.length, mise.police);

            partsLignes.forEach((part, ri) => {
                if (!premiere) contenu.push({ text: '', pageBreak: 'before' });
                premiere = false;
                const morceaux = [sousTitre];
                if (colonnes.length > 0) {
                    morceaux.push(largeur.tailles.length > 1
                        ? `${libellePersonnes} ${depuis} à ${jusqua}`
                        : this._accorder(chunk.length, libellePersonnes));
                }
                if (partsLignes.length > 1) morceaux.push(this._trancheLabel(part, pas));
                contenu.push(...this._entetePage(titre, morceaux.filter(Boolean).join(' · ')));
                contenu.push(this._tableauGrille({
                    entetes: chunk.map(c => chunk.length <= 9 ? (c.label || c.labelCourt) : (c.labelCourt || c.label)),
                    lignes: part,
                    maxChars,
                    hauteurLigne: mise.hauteurLigne,
                    police: mise.police,
                    deuxLignes: mise.deuxLignes,
                    cellule: (c, r) => {
                        const cell = grid[chunk[c].cle] && grid[chunk[c].cle][part[r]];
                        if (!cell) return null;
                        return { ...cell, span: Math.min(cell.span, part.length - r) };
                    },
                }));
                contenu.push(...this._legendParts(couleurs));
            });
        });

        return this._poserAvertissement(
            this._docStandard({ cle, titre, sousTitre, orientation: orient, contenu, contexte }),
            avertissement);
    },

    /* ---- Petits helpers ---- */

    /** Attache l'avertissement de pagination au document lui-même (jamais à un champ partagé). */
    _poserAvertissement(def, avertissement) {
        if (def && avertissement) def._avertissement = avertissement;
        return def;
    },

    /** « 1 élève » / « 3 élèves » : le libellé est fourni au pluriel par l'appelant. */
    _accorder(n, motPluriel) {
        return `${n} ${n > 1 ? motPluriel : String(motPluriel).replace(/s$/, '')}`;
    },

    _capitaliser(txt) {
        return txt ? txt.charAt(0).toUpperCase() + txt.slice(1) : '';
    },

    _joursLabels(jours) {
        return jours.map(j => this._capitaliser(j).slice(0, 3)).join(' · ');
    },

    _trancheLabel(part, pas) {
        if (!part.length) return '';
        const fin = this._ajouterMinutes(part[part.length - 1], pas);
        // Repère de position lisible (spec § 2.5) : « Matin · 08:30 → 12:00 ».
        const matin = String(part[part.length - 1]) < '13:00';
        return `${matin ? 'Matin' : 'Après-midi'} · ${part[0]} → ${fin}`;
    },

    _ajouterMinutes(heure, minutes) {
        const [h, m] = heure.split(':').map(Number);
        const total = h * 60 + m + minutes;
        return `${String(Math.floor(total / 60)).padStart(2, '0')}:${String(total % 60).padStart(2, '0')}`;
    },

    /** Nombre de caractères tenables sur une ligne de case. */
    _maxChars(reglages, orientation, nbColonnes, police) {
        // Une seule source de largeur de colonne (socle `_largeurColonne`) : ce calcul
        // refaisait la soustraction des marges et de la gouttière avec des littéraux.
        // 0,6 em par caractère : les types sont en CAPITALES, plus larges que 0,52.
        // L'ancien calcul laissait 15 caractères là où 9 tiennent, et
        // « DECLOISONNEMENT » débordait sur la colonne voisine.
        const colW = this._largeurColonne(reglages, orientation, nbColonnes);
        return Math.max(5, Math.floor(colW / (0.6 * police)));
    },

    /** « Prénom N. » quand les colonnes sont nombreuses, sinon « Prénom Nom ». */
    _labelEleve(e, nbColonnes) {
        const prenom = (e.prenom || '').trim();
        const nom = (e.nom || '').trim();
        if (nbColonnes <= 9) return `${prenom} ${nom}`.trim();
        const initiale = nom ? nom.charAt(0).toUpperCase() + '.' : '';
        return `${prenom} ${initiale}`.trim();
    },

    _roleLabel(role) {
        const labels = {
            enseignant: 'Enseignant', coordo_ulis: 'Coordo ULIS',
            aeshco: 'AESHco', aeshi: 'AESHi', aeshm: 'AESHm',
            specialiste: 'Spécialiste', educateur: 'Éducateur', assistant_familial: 'Ass. familial',
        };
        return labels[role] || role?.replace(/_/g, ' ') || 'Autre';
    },

    _adulteSuffix(a) {
        if (a.role === 'enseignant') {
            if (a.fonction === 'coordo_ulis') return 'Coordo ULIS';
            if (a.fonction) return a.fonction;
            const classes = (this._classes || []).filter(c => (c.enseignants || []).some(e => e.adulte_id === a.id));
            return classes.length ? classes.map(c => c.nom).join(' · ') : '';
        }
        if (a.role?.startsWith('aesh')) return this._roleLabel(a.role);
        if (a.fonction) return a.fonction;
        return this._roleLabel(a.role) || '';
    },

    _buildAdultOptions() {
        const groups = { enseignants: [], aesh: [], coordo: [], autres: [] };
        this._adultes.forEach(a => {
            const r = a.role || '';
            if (r === 'enseignant') groups.enseignants.push(a);
            else if (r.startsWith('aesh')) groups.aesh.push(a);
            else if (r === 'coordo_ulis') groups.coordo.push(a);
            else groups.autres.push(a);
        });
        const opt = list => list.map(a => {
            const suffix = this._adulteSuffix(a);
            return `<option value="${escapeAttr(a.nom || '')}">${escapeHtml(a.nom || '')}${suffix ? ' · ' + escapeHtml(suffix) : ''}</option>`;
        }).join('');
        let html = '';
        if (groups.enseignants.length) html += `<optgroup label="👩‍🏫 Enseignants">${opt(groups.enseignants)}</optgroup>`;
        if (groups.aesh.length) html += `<optgroup label="🤝 AESH">${opt(groups.aesh)}</optgroup>`;
        if (groups.coordo.length) html += `<optgroup label="📋 Coordo ULIS">${opt(groups.coordo)}</optgroup>`;
        if (groups.autres.length) html += `<optgroup label="🌍 Autres">${opt(groups.autres)}</optgroup>`;
        return html || '<option value="">Aucun adulte</option>';
    },

    _buildAdultMultiOptions() {
        return this._adultes.map(a => {
            const suffix = this._adulteSuffix(a);
            return `<option value="${escapeAttr(a.nom || '')}" selected>${escapeHtml(a.nom || '')}${suffix ? ' · ' + escapeHtml(suffix) : ''}</option>`;
        }).join('');
    },

    async _loadCreneaux(semaineId, eleveId) {
        const qs = new URLSearchParams({ with_eleves: '1' });
        qs.set('semaine_id', semaineId !== null ? semaineId : 'null');
        let creneaux = await API.get('creneaux.php?' + qs.toString());
        creneaux = creneaux.map(c => ({ ...c, heure_debut: (c.heure_debut || '').substring(0, 5) }));
        if (eleveId) creneaux = creneaux.filter(c => Number(c.eleve_id) === Number(eleveId));
        return creneaux;
    },

});
