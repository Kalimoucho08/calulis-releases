/**
 * Calulis — Fiches de renseignements / urgence (documents de la page Impression)
 * Greffé sur l'objet Print. Génère un PDF A4 portrait par élève (ou en lot, une fiche par page).
 *
 * Depuis la phase 3 (18/10/2026), la page, les marges, les bandeaux et les métadonnées
 * viennent du socle (`print-socle.js`) : ce fichier ne décide plus que du CONTENU d'une fiche.
 */
Object.assign(Print, {

  async _generateFiches(typeForce, demande) {
    if (demande == null) demande = this._invaliderApercu();
    // Le type vient du document choisi dans la liste (fiche d'urgence / fiche de renseignements).
    const type = typeForce || 'urgence';
    const sel = document.getElementById('print-fiche-eleves');
    if (!sel) return;
    const ids = Array.from(sel.selectedOptions).map(o => parseInt(o.value));
    if (!ids.length) { Modal.alert('Erreur', 'Sélectionnez au moins un élève.'); return; }

    const btn = document.getElementById('btn-print-generate');
    btn.disabled = true; btn.textContent = '⏳ Génération…';
    try {
      const eleves = await API.get('listes.php?ids=' + ids.join(','));
      if (demande !== this._demande) return;   // une autre génération a pris la main
      const ordered = ids.map(id => (eleves || []).find(e => e.id === id)).filter(Boolean);
      if (!ordered.length) { Modal.alert('Erreur', 'Aucun élève trouvé.'); return; }
      const def = this._buildFichesDoc(type, ordered);
      const fname = this._nomFichier(type === 'urgence' ? 'fiche_urgence' : 'fiche_renseignements');
      if (def) this._showPreview(def, fname);
    } catch (e) {
      // Sans ce catch, un échec de `listes.php` laissait l'ancien aperçu à l'écran, sans un mot.
      if (demande !== this._demande) return;
      console.error('[Print] fiches error:', e);
      if (typeof Modal !== 'undefined' && Modal.alert) {
        Modal.alert('Erreur', 'Impossible de générer les fiches : ' + (e.message || 'Erreur inconnue'));
      }
    } finally {
      btn.disabled = false; btn.textContent = '↻ Actualiser';
    }
  },

  _buildFichesDoc(type, eleves) {
    const contenu = [];
    eleves.forEach((e, i) => {
      if (i > 0) contenu.push(this._sautPage('portrait'));
      contenu.push(type === 'urgence' ? this._buildFicheUrgence(e) : this._buildFicheRenseignement(e));
    });
    const titre = type === 'urgence' ? 'Fiche d\'urgence' : 'Fiche de renseignements';
    const seule = eleves.length === 1 ? [eleves[0].prenom, eleves[0].nom].filter(Boolean).join(' ') : '';
    const def = this._docStandard({
      cle: type === 'urgence' ? 'fiche_urgence' : 'fiche_renseignements',
      titre,
      sousTitre: seule || `${eleves.length} fiches`,
      orientation: 'portrait',
      contenu,
      contexte: { nom: seule, titre },
      styles: {
        header: { fontSize: 15, bold: true, alignment: 'center' },
        name: { fontSize: 12, bold: true, alignment: 'center', margin: [0, 2, 0, 6] },
        muted: { fontSize: 8, italics: true, color: '#777', alignment: 'center', margin: [0, 0, 0, 8] },
        sectionTitle: { fontSize: 10, bold: true, margin: [0, 10, 0, 3], color: '#2c3e50' },
        kvLabel: { fontSize: 9, bold: true, color: '#555' },
        kvValue: { fontSize: 9 },
        th: { fontSize: 8, bold: true, fillColor: '#eee', alignment: 'center' },
      },
    });
    // Une fiche est TOUJOURS en portrait (spec) : un ancien réglage « paysage » ne doit pas
    // donner un PDF à orientation mixte (page 1 paysage, suivantes portrait).
    def.pageOrientation = 'portrait';
    return def;
  },

  _kv(label, value) {
    return { columns: [ { text: label, style: 'kvLabel', width: 110 }, { text: value || '—', style: 'kvValue', width: '*' } ], margin: [0, 1, 0, 1] };
  },

  _repsFor(e) {
    const reps = e.representants || [];
    if (!reps.length) return { text: 'Aucun représentant renseigné.', style: 'muted', alignment: 'left' };
    const body = [[
      { text: 'Nom', style: 'th' }, { text: 'Lien', style: 'th' }, { text: 'Téléphone', style: 'th' }, { text: 'Urgence', style: 'th' },
    ]];
    reps.forEach(r => body.push([
      { text: (r.prenom ? r.prenom + ' ' : '') + (r.nom || '') },
      { text: r.lien || '' },
      { text: (r.telephone && r.telephone !== '0') ? r.telephone : '' },
      { text: (r.telephone_urgence && r.telephone_urgence !== '0') ? 'Oui' : '' },
    ]));
    return { table: { headerRows: 1, widths: [90, 60, 80, 40], body }, fontSize: 8 };
  },

  _droitText(d) {
    const m = { autorise: 'Autorisé', refuse: 'Refusé', limite: 'Limité', en_attente: 'En attente', retire: 'Retiré' };
    return d ? (m[d.statut] || d.statut) : 'Non renseigné';
  },

  _buildFicheUrgence(e) {
    return {
      stack: [
        { text: 'FICHE D\'URGENCE', style: 'header' },
        { text: (e.nom || '') + ' ' + (e.prenom || ''), style: 'name' },
        { text: 'Document confidentiel — précautions pour la vie scolaire uniquement. À détruire en fin d\'année.', style: 'muted' },
        this._kv('Classe', e.classe_nom || e.classe),
        this._kv('Naissance', formatDate(e.date_naissance)),
        this._kv('Groupe', e.groupe),
        { text: 'Représentants légaux', style: 'sectionTitle' },
        this._repsFor(e),
        { text: 'Santé & vie scolaire', style: 'sectionTitle' },
        this._kv('Allergies', e.allergies),
        this._kv('Régime alimentaire', e.regime_alimentaire),
        this._kv('PAI', e.pai ? 'Oui' : 'Non'),
        this._kv('Précautions', e.precautions_medicales),
        this._kv('Transport', e.transport),
        this._kv('Cantine', e.cantine ? 'Oui' : 'Non'),
        this._kv('Droit à l\'image', this._droitText(e.droit_image)),
      ],
      unbreakable: true,
    };
  },

  _buildFicheRenseignement(e) {
    const reps = e.representants || [];
    const repEmail = reps.map(r => r.email).filter(Boolean).join(', ');
    return {
      stack: [
        { text: 'FICHE DE RENSEIGNEMENTS', style: 'header' },
        { text: (e.nom || '') + ' ' + (e.prenom || ''), style: 'name' },
        { text: 'Année scolaire en cours — à compléter et signer par la famille.', style: 'muted' },
        { text: 'Identité', style: 'sectionTitle' },
        this._kv('Nom', e.nom), this._kv('Prénom', e.prenom),
        this._kv('Date de naissance', formatDate(e.date_naissance)),
        this._kv('Numéro INE', e.ine), this._kv('N° dossier MDPH', e.numero_dossier_mdph),
        { text: 'Scolarité', style: 'sectionTitle' },
        this._kv('Classe', e.classe_nom || e.classe), this._kv('Établissement', e.etablissement_nom),
        this._kv('ULIS', e.ulis ? 'Oui' : 'Non'), this._kv('Groupe', e.groupe),
        { text: 'Représentants légaux', style: 'sectionTitle' },
        this._repsFor(e),
        this._kv('Email (représentants)', repEmail),
        this._kv('Adresse', e.adresse),
        { text: 'Divers', style: 'sectionTitle' },
        this._kv('Droit à l\'image', this._droitText(e.droit_image)),
      ],
      unbreakable: true,
    };
  },
});