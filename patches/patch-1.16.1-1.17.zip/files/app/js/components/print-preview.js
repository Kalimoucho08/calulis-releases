/**
 * Calulis — Print Preview : aperçu canvas PDF.js, zoom, navigation
 * Attaché à l'objet Print via Object.assign
 */

Object.assign(Print, {

    /* ---- Aperçu canvas PDF.js ---- */

    async _showPreview(docDef, filename) {
        // Un seul rendu à la fois : la page Impression régénère l'aperçu à chaque réglage,
        // et deux rendus simultanés sur le même canevas lèvent « Cannot use the same canvas »
        // (vu le 18/10/2026). Le dernier demandé gagne.
        const seq = (this._seq = (this._seq || 0) + 1);
        this._pendingDef = docDef;
        this._pendingFilename = filename;
        if (typeof this._majBoutonsApercu === 'function') this._majBoutonsApercu();

        // La fenêtre d'aperçu est globale (index.html) : elle sert aussi au suivi et aux tâches.
        // Ses commandes doivent donc être branchées ICI et pas seulement au rendu de la page
        // Impression — sinon, ouvert depuis le suivi ou les tâches, « Fermer » ne répondait pas
        // et « Télécharger le PDF » restait inerte (trouvé par la revue du 04/10/2026).
        this._brancherApercu();
        const voile = document.getElementById('apercu-voile');
        // Sur l'Impression en fenêtre étroite, l'aperçu flottant ne s'ouvre QUE si
        // l'utilisateur l'a demandé : sinon il recouvrirait les réglages à chaque frappe.
        const surImpression = typeof this._surImpression === 'function' && this._surImpression();
        // Une fermeture demandée par l'utilisateur est durable : sur un écran large, la
        // génération suivante ne doit pas rouvrir l'aperçu qu'il vient de fermer
        // (trouvé par la revue du 18/10/2026). Le bouton « Aperçu » le rouvre.
        const doitOuvrir = !surImpression || this._apercuOuvert
            || (window.innerWidth > 1100 && !this._apercuFerme);
        if (voile && doitOuvrir) voile.classList.remove('cache');
        if (surImpression && doitOuvrir && window.innerWidth > 1100) {
            document.body.classList.add('impression-ouverte');
        }

        const area = document.getElementById('print-preview-area');
        const placeholder = document.getElementById('print-preview-placeholder');
        const label = document.getElementById('print-preview-label');
        const canvas = document.getElementById('print-preview-canvas');
        const dlBtn = document.getElementById('btn-print-download');
        const pageNav = document.getElementById('print-page-nav');
        const pageInfo = document.getElementById('print-page-info');

        label.textContent = 'Génération du PDF…';
        area.style.display = 'none';

        pdfMake.createPdf(docDef).getBlob(async (blob) => {
            try {
                if (seq !== this._seq) return;
                const arrayBuffer = await blob.arrayBuffer();
                const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
                if (seq !== this._seq) return;
                this._pdfDoc = pdf;
                this._currentPage = 1;
                this._zoom = 1;

                pageNav.style.display = pdf.numPages > 1 ? 'flex' : 'none';
                await this._renderPage(1, pdf, canvas, pageInfo, seq);
                if (seq !== this._seq) return;   // une génération plus récente a pris la main

                if (placeholder) placeholder.style.display = 'none';
                area.style.display = 'flex';
                // L'avertissement voyage AVEC le document : un champ partagé pouvait être
                // posé par une génération périmée et s'afficher au-dessus du document suivant
                // (trouvé par la revue du 18/10/2026).
                label.textContent = (docDef && docDef._avertissement)
                    || 'Aperçu prêt — utilisez le zoom ou téléchargez le PDF.';
                dlBtn.disabled = false;
                // Ajuster APRÈS l'affichage : sur une zone encore masquée la largeur
                // mesurée vaut 0, et le zoom retombait sur son minimum (25 %). Corrigé le 04/10/2026.
                this._zoomFit();
            } catch (err) {
                label.textContent = 'Erreur lors du rendu de l\'aperçu.';
                console.error('[Print] PDF.js render error:', err);
            }
        });
    },

    /**
     * Branche les commandes de la fenêtre d'aperçu — UNE seule fois (garde idempotent).
     * Appelée à chaque ouverture : la fenêtre sert à plusieurs pages.
     */
    _brancherApercu() {
        if (this._apercuBranche) return;
        this._apercuBranche = true;
        document.getElementById('btn-print-download').addEventListener('click', () => {
            if (this._pendingDef && this._pendingFilename) this._download(this._pendingDef, this._pendingFilename);
        });
        document.getElementById('btn-prev-page').addEventListener('click', () => this._navigatePage(-1));
        document.getElementById('btn-next-page').addEventListener('click', () => this._navigatePage(1));
        document.getElementById('btn-zoom-in').addEventListener('click', () => this._zoomChange(0.25));
        document.getElementById('btn-zoom-out').addEventListener('click', () => this._zoomChange(-0.25));
        document.getElementById('btn-zoom-fit').addEventListener('click', () => this._zoomFit());
        document.getElementById('apercu-fermer').addEventListener('click', () => this._fermerApercu());
        document.addEventListener('keydown', (ev) => {
            const voile = document.getElementById('apercu-voile');
            if (ev.key === 'Escape' && voile && !voile.classList.contains('cache')) this._fermerApercu();
        });
    },

    /** Ferme la fenêtre d'aperçu (bouton ou touche Échap) */
    _fermerApercu() {
        this._apercuOuvert = false;
        // Mémorisé : sans ce drapeau, la génération suivante rouvrait l'aperçu sur un écran
        // large, et la fenêtre flottante réapparaissait sur les réglages.
        this._apercuFerme = true;
        const voile = document.getElementById('apercu-voile');
        if (voile) voile.classList.add('cache');
        // Amarré à droite de l'Impression, l'aperçu n'est pas une modale : le fermer doit
        // aussi rendre la colonne au formulaire (le bouton « Aperçu » le rouvre).
        if (document.body.classList.contains('impression-ouverte')) {
            document.body.classList.remove('impression-ouverte');
        }
    },

    async _renderPage(pageNum, pdf, canvas, pageInfo, seq) {
        if (seq != null && seq !== this._seq) return;
        try {
            const page = await pdf.getPage(pageNum);
            const dpr = window.devicePixelRatio || 1;
            // `this._zoom` est un pourcentage d'affichage : la largeur CSS de la page doit
            // valoir zoom × largeur du PDF. L'ancien calcul multipliait par 1,5 puis divisait
            // par le dpr, donc 100 % faisait 150 % à dpr=1 et 75 % à 150 % de Windows.
            const viewport = page.getViewport({ scale: this._zoom });
            canvas.width = Math.round(viewport.width * dpr);
            canvas.height = Math.round(viewport.height * dpr);
            canvas.style.width = Math.round(viewport.width) + 'px';
            canvas.style.height = Math.round(viewport.height) + 'px';

            const ctx = canvas.getContext('2d');
            ctx.setTransform(1, 0, 0, 1, 0, 0);
            ctx.scale(dpr, dpr);
            ctx.clearRect(0, 0, viewport.width, viewport.height);

            if (this._renderTask) { try { this._renderTask.cancel(); } catch (e) { /* déjà fini */ } }
            const tache = page.render({ canvasContext: ctx, viewport });
            this._renderTask = tache;
            await tache.promise;
            if (seq != null && seq !== this._seq) return;
            if (pageInfo) pageInfo.textContent = `Page ${pageNum} / ${pdf.numPages}`;
        } catch (err) {
            // Un rendu annulé (nouvel aperçu) n'est pas une panne.
            if (err && err.name === 'RenderingCancelledException') return;
            console.error('[Print] page render error:', err);
        }
    },

    _navigatePage(delta) {
        if (!this._pdfDoc) return;
        const newPage = this._currentPage + delta;
        if (newPage < 1 || newPage > this._pdfDoc.numPages) return;
        this._currentPage = newPage;
        const canvas = document.getElementById('print-preview-canvas');
        const pageInfo = document.getElementById('print-page-info');
        this._renderPage(newPage, this._pdfDoc, canvas, pageInfo, this._seq);
    },

    _download(docDef, filename) {
        if (typeof pdfMake === 'undefined') {
            Modal.alert('Erreur', 'pdfmake non chargé. Vérifiez votre connexion internet.');
            return;
        }
        pdfMake.createPdf(docDef).download(filename);
    },

    /* ---- Zoom preview ---- */

    _zoomChange(delta) {
        this._zoom = Math.max(0.25, Math.min(3, this._zoom + delta));
        this._updateZoomLabel();
        this._reRenderPreview();
    },

    _zoomFit() {
        if (!this._pdfDoc) return;
        const wrapper = document.querySelector('.print-canvas-wrapper');
        if (!wrapper) return;
        const w = wrapper.clientWidth * 0.75;
        const page = this._pdfDoc.getPage(1);
        page.then(p => {
            const vp = p.getViewport({ scale: 1 });
            this._zoom = Math.max(0.25, (w / vp.width));
            this._updateZoomLabel();
            this._reRenderPreview();
        });
    },

    _updateZoomLabel() {
        const lbl = document.getElementById('print-zoom-label');
        if (lbl) lbl.textContent = Math.round(this._zoom * 100) + '%';
    },

    _reRenderPreview() {
        if (!this._pdfDoc) return;
        this._currentPage = Math.min(this._currentPage, this._pdfDoc.numPages);
        const canvas = document.getElementById('print-preview-canvas');
        const pageInfo = document.getElementById('print-page-info');
        this._renderPage(this._currentPage, this._pdfDoc, canvas, pageInfo, this._seq);
    },

});
