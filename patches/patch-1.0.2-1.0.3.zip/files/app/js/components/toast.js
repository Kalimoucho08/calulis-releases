/**
 * Calulis — Système de notifications Toast
 */
const Toast = {
    show(msg, type = 'info', duration = 3000) {
        const container = document.getElementById('toast-container');
        if (!container) return;
        const el = document.createElement('div');
        el.className = `toast toast-${type}`;
        el.innerHTML = '<span class="toast-text"></span><button class="toast-close">&times;</button>';
        el.querySelector('.toast-text').textContent = msg;
        container.appendChild(el);
        el.querySelector('.toast-close').addEventListener('click', () => el.remove());
        if (duration > 0) setTimeout(() => { if (el.parentNode) el.remove(); }, duration);
    },
    success(msg) { this.show(msg, 'success'); },
    error(msg)   { this.show(msg, 'error', 8000); },
    info(msg)    { this.show(msg, 'info'); },
};
