/**
 * Calulis — Tableau de bord (Dashboard)
 * Page d'accueil avec compteurs, réunions à venir, lien agenda, alertes MDPH.
 */
const Dashboard = {

    async render() {
        const view = document.getElementById('view-dashboard');
        view.innerHTML = `
            <div class="dashboard-grid">
                <div class="dashboard-widget skeleton"><div class="skeleton-line skeleton-line-lg"></div><div class="skeleton-line skeleton-line-sm"></div><div class="skeleton-line skeleton-line-sm"></div></div>
                <div class="dashboard-widget skeleton"><div class="skeleton-line skeleton-line-lg"></div><div class="skeleton-line"></div><div class="skeleton-line"></div><div class="skeleton-line skeleton-line-sm"></div></div>
                <div class="dashboard-widget skeleton"><div class="skeleton-line skeleton-line-lg"></div><div class="skeleton-line"></div></div>
                <div class="dashboard-widget skeleton"><div class="skeleton-line skeleton-line-lg"></div><div class="skeleton-line"></div><div class="skeleton-line skeleton-line-sm"></div></div>
            </div>`;

        let eleves = [], reunions = [], semaines = [], periodes = [], reunionsToutes = [];
        try {
            [eleves, reunions, semaines, periodes, reunionsToutes] = await Promise.all([
                API.get('eleves.php'),
                API.get('reunions.php?upcoming=30'),
                API.get('semaines.php'),
                API.get('periodes.php'),
                // Toutes les réunions, passées comprises : l'échéancier a besoin de la
                // DERNIÈRE ESS de chaque élève, pas seulement des prochaines.
                API.get('reunions.php'),
            ]);
        } catch (e) {
            view.innerHTML = `<div class="placeholder-view">
                <div class="placeholder-icon">⚠️</div>
                <div class="placeholder-title">Erreur de chargement</div>
                <div class="placeholder-text">${escapeHtml(e.message)}</div>
                <div class="placeholder-text" style="margin-top:10px;font-size:13px;max-width:520px">
                    Si le problème persiste, fermez puis relancez Calulis. Besoin d'aide ?
                    utilisez le bouton « 🐛 Signaler un bug » : il prépare un message avec
                    les informations techniques pour l'équipe.
                </div>
                <button class="btn btn-primary" style="margin-top:14px" onclick="BugReport.open()">🐛 Signaler un bug</button>
            </div>`;
            return;
        }

        // A21 : ne garder que les actifs — les élèves inactifs ont quitté le dispositif, leurs dates MDPH ne sont plus pertinentes
        const actifs = eleves.filter(e => e.actif);

        if (actifs.length === 0) {
            view.innerHTML = `
                <div class="dashboard-welcome">
                    <h2>Bienvenue dans Calulis !</h2>
                    <p>Commencez par ajouter des élèves et configurer votre établissement dans <a href="#" onclick="Router.go('params')">Paramètres</a>.</p>
                </div>`;
            this._injectVersionFooter(view);
            return;
        }
        const ulis = actifs.filter(e => e.ulis);
        const classes = [...new Set(actifs.map(e => e.classe).filter(Boolean))];

        const now = new Date();
        const todayStr = toDateStr(now);
        const lundi = getLundi(now);

        // Semaine active dans l'année scolaire (contient aujourd'hui)
        const semaineActive = semaines.find(s => s.date_debut <= todayStr && s.date_fin >= todayStr);

        // Numérotation scolaire : ne compter que les semaines de cours (est_vacances=0),
        // jamais les semaines de vacances. Une année scolaire = 36 semaines.
        let semaineNum;
        let periodeInfo = '';
        if (semaineActive) {
            semaineNum = 'S' + getSchoolWeekNumber(semaineActive, semaines);

            // Contexte période : ne compter que les semaines de cours dans la période
            if (periodes.length > 0) {
                const periode = periodes.find(p =>
                    p.date_debut <= semaineActive.date_debut &&
                    p.date_fin >= semaineActive.date_fin
                );
                if (periode) {
                    // Filtrer les semaines de cours de cette période
                    const schoolWeeksInPeriode = semaines.filter(s =>
                        s.annee_scolaire_id === semaineActive.annee_scolaire_id &&
                        parseInt(s.est_vacances) !== 1 &&
                        s.date_debut >= periode.date_debut &&
                        s.date_fin <= periode.date_fin
                    ).sort((a, b) => a.numero - b.numero);
                    const idx = schoolWeeksInPeriode.findIndex(s => s.id === semaineActive.id);
                    const weekInPeriode = idx >= 0 ? idx + 1 : '?';
                    const total = schoolWeeksInPeriode.length;
                    periodeInfo = `${periode.nom} — Semaine ${weekInPeriode}/${total} · `;
                }
            }
        } else {
            semaineNum = getWeekNumber(now);
        }

        // ── Échéancier « à relancer » ────────────────────────────────────────────
        // Rien n'est inventé ici : chaque ligne est un FAIT lu dans la base, avec sa
        // raison écrite en clair et sa date. Le seuil de 60 jours est un repère
        // d'affichage (« ça approche »), pas une règle de droit — c'est l'enseignant
        // qui décide. Le seuil d'un an pour l'ESS reprend la fréquence annuelle de
        // l'équipe de suivi, et la ligne dit la date exacte de la dernière.
        const DROITS_MDPH = [
            { champ: 'mdph_ulis_date_fin', nom: 'ULIS' },
            { champ: 'mdph_aesh_date_fin', nom: 'AESH' },
            { champ: 'mdph_sessad_date_fin', nom: 'SESSAD' },
            { champ: 'mdph_transport_date_fin', nom: 'Transport' },
            { champ: 'mdph_autre_date_fin', nom: 'Autre droit' },
        ];
        const SEUIL_JOURS = 60;
        const SEUIL_ESS_JOURS = 365;
        const dateSeule = (d) => String(d || '').substring(0, 10);
        const joursEntre = (depuis, jusqua) =>
            Math.round((new Date(dateSeule(jusqua)) - new Date(dateSeule(depuis))) / 86400000);

        const droitsARelancer = [];
        actifs.forEach(e => {
            DROITS_MDPH.forEach(d => {
                const fin = dateSeule(e[d.champ]);
                if (!/^\d{4}-\d{2}-\d{2}$/.test(fin)) return;
                const reste = joursEntre(todayStr, fin);
                if (reste <= SEUIL_JOURS) droitsARelancer.push({ eleve: e, droit: d.nom, fin, reste });
            });
        });
        droitsARelancer.sort((a, b) => a.fin.localeCompare(b.fin));

        const essARelancer = [];
        ulis.forEach(e => {
            const dates = reunionsToutes
                .filter(r => Number(r.eleve_id) === Number(e.id) && String(r.type || '').toUpperCase() === 'ESS')
                .map(r => dateSeule(r.date_reunion))
                .filter(Boolean)
                .sort();
            const derniere = dates[dates.length - 1] || null;
            if (!derniere) essARelancer.push({ eleve: e, derniere: null, jours: null });
            else {
                const jours = joursEntre(derniere, todayStr);
                if (jours > SEUIL_ESS_JOURS) essARelancer.push({ eleve: e, derniere, jours });
            }
        });
        essARelancer.sort((a, b) => (b.jours ?? Infinity) - (a.jours ?? Infinity));

        const docsARelancer = [];
        actifs.forEach(e => {
            if (Number(e.pai) === 1 && !String(e.lien_pai || '').trim()) {
                docsARelancer.push({ eleve: e, quoi: 'PAI déclaré, document non joint' });
            }
            if (e.ulis && !String(e.notifications || '').includes('notif_mdph')) {
                docsARelancer.push({ eleve: e, quoi: 'notification MDPH non renseignée' });
            }
        });

        const totalARelancer = droitsARelancer.length + essARelancer.length + docsARelancer.length;
        const ligneARelancer = (e, raison) => `
            <li class="dashboard-list-item dashboard-relance-item" data-eleve-id="${e.id}"
                title="Ouvrir la fiche de ${escapeHtml(e.prenom)} ${escapeHtml(e.nom)} (onglet MDPH)">
                <span class="dashboard-alert-badge">⚠️</span>
                <span class="reunion-title">${escapeHtml(e.prenom)} ${escapeHtml(e.nom)}</span>
                <span class="text-muted small">${escapeHtml(raison)}</span>
            </li>`;
        const blocRelance = (titre, lignes) => lignes.length === 0 ? '' : `
            <p class="text-muted" style="font-size:12px;margin:10px 0 4px">${titre}</p>
            <ul class="dashboard-list">${lignes.slice(0, 4).join('')}</ul>
            ${lignes.length > 4 ? `<p class="dashboard-more">+ ${lignes.length - 4} autre(s)…</p>` : ''}`;

        view.innerHTML = `
            <div class="dashboard-grid">
                <div class="dashboard-widget">
                    <h3 class="dashboard-widget-title">Effectifs</h3>
                    <div class="dashboard-stats">
                        <div class="dashboard-stat">
                            <span class="dashboard-stat-value">${actifs.length}</span>
                            <span class="dashboard-stat-label">élèves actifs</span>
                        </div>
                        <div class="dashboard-stat">
                            <span class="dashboard-stat-value">${ulis.length}</span>
                            <span class="dashboard-stat-label">en ULIS</span>
                        </div>
                        <div class="dashboard-stat">
                            <span class="dashboard-stat-value">${classes.length}</span>
                            <span class="dashboard-stat-label">classes</span>
                        </div>
                        <div class="dashboard-stat">
                            <span class="dashboard-stat-value">${eleves.length - actifs.length}</span>
                            <span class="dashboard-stat-label">inactifs</span>
                        </div>
                    </div>
                </div>

                <div class="dashboard-widget">
                    <h3 class="dashboard-widget-title">Prochaines réunions</h3>
                    ${reunions.length === 0 ? '<p class="dashboard-empty">Aucune réunion prévue.</p>' : `
                    <ul class="dashboard-list">
                        ${reunions.slice(0, 5).map(r => `
                            <li class="dashboard-list-item">
                                <span class="reunion-date">${formatDate(r.date_reunion)}</span>
                                <span class="badge">${escapeHtml(r.type || '')}</span>
                                <span class="reunion-title">${escapeHtml(r.titre)}</span>
                                ${r.eleve_nom ? `<span class="reunion-eleve">${escapeHtml(r.eleve_prenom)} ${escapeHtml(r.eleve_nom)}</span>` : ''}
                                <span class="badge reunion-statut-${(r.statut || 'prevue').toLowerCase()}">${escapeHtml(r.statut || '')}</span>
                            </li>
                        `).join('')}
                    </ul>`}
                    ${reunions.length > 5 ? `<p class="dashboard-more">+ ${reunions.length - 5} autre(s)...</p>` : ''}
                </div>

                <div class="dashboard-widget">
                    <h3 class="dashboard-widget-title">Agenda</h3>
                    <div class="dashboard-agenda">
                        <p>${periodeInfo}<strong>${semaineNum}</strong> — du <strong>${formatDate(toDateStr(lundi))}</strong></p>
                        <button class="btn btn-primary" id="dashboard-goto-agenda">📅 Voir l'agenda</button>
                    </div>
                </div>

                <div class="dashboard-widget">
                    <h3 class="dashboard-widget-title">À relancer${totalARelancer > 0 ? ' (' + totalARelancer + ')' : ''}</h3>
                    ${totalARelancer === 0
                        ? '<p class="dashboard-ok">✅ Rien à relancer.</p>'
                        : blocRelance('Droits MDPH', droitsARelancer.map(d =>
                            ligneARelancer(d.eleve, d.reste < 0
                                ? `${d.droit} — expiré depuis le ${formatDate(d.fin)}`
                                : `${d.droit} — expire le ${formatDate(d.fin)} (dans ${d.reste} j)`)))
                          + blocRelance('ESS à programmer', essARelancer.map(x =>
                            ligneARelancer(x.eleve, x.derniere
                                ? `dernière ESS le ${formatDate(x.derniere)}`
                                : 'aucune ESS enregistrée')))
                          + blocRelance('Documents', docsARelancer.map(x => ligneARelancer(x.eleve, x.quoi)))
                    }
                </div>
            </div>
        `;

        document.getElementById('dashboard-goto-agenda')?.addEventListener('click', () => {
            State.set('agenda-goto-today', true);
            Router.go('agenda');
        });

        // Widget « À relancer » → ouvrir la fiche élève sur l'onglet MDPH
        view.querySelectorAll('.dashboard-relance-item').forEach(li => {
            li.addEventListener('click', () => {
                const eleveId = parseInt(li.dataset.eleveId);
                const eleve = actifs.find(e => e.id === eleveId);
                if (eleve) {
                    FicheEleve.open(eleve);
                    FicheEleve._switchTab('mdph');
                }
            });
        });

        // Widget réunions → aller à la page réunions
        view.querySelectorAll('.dashboard-list-item:not(.dashboard-relance-item)').forEach(li => {
            li.addEventListener('click', () => Router.go('reunions'));
        });

        this._injectVersionFooter(view);
    },

    /** Pied de page : version de l'application + lien « Quoi de neuf ? » */
    _injectVersionFooter(view) {
        const footer = document.createElement('div');
        footer.className = 'dashboard-footer';
        footer.style.cssText = 'margin-top:24px;padding-top:14px;border-top:1px solid var(--border-color);display:flex;gap:16px;align-items:center;font-size:13px;color:var(--text-muted);flex-wrap:wrap';
        footer.innerHTML = `
            <span>Calulis <strong id="calulis-version">…</strong></span>
            <a href="#" onclick="State.set('aide-section','nouveautes'); Router.go('aide'); return false;">🎉 Quoi de neuf ?</a>
        `;
        view.appendChild(footer);

        // Version réelle depuis l'API (silencieux si indisponible)
        API.get('version.php').then(v => {
            const el = document.getElementById('calulis-version');
            if (el && v && v.appVersion) el.textContent = 'v' + v.appVersion;
        }).catch(() => {});
    },

};
