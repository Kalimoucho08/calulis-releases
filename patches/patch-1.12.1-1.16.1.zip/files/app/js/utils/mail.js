/**
 * Calulis — Utilitaires d'envoi et de copie : UN seul endroit.
 *
 * Pourquoi ce fichier : le signalement de bug ouvrait déjà la messagerie de l'utilisateur avec
 * un message pré-rempli (`mailto:`). Le carnet de souhaits fait exactement la même chose —
 * sans serveur, sans compte, sans collecte : c'est l'utilisateur qui envoie, depuis SA
 * messagerie, et rien ne part tant qu'il n'a pas cliqué.
 */

/** Adresse de signalement : paramètre `email_support`, sinon l'adresse par défaut. */
async function obtenirEmailSupport() {
    try {
        const params = await API.get('params.php');
        const p = (params || []).find(x => x.cle === 'email_support');
        if (p && p.valeur) return String(p.valeur).trim();
    } catch { /* base injoignable : on garde l'adresse par défaut */ }
    return 'generateurs.scolaire@free.fr';
}

/**
 * Ouvre le logiciel de messagerie avec un message prêt à envoyer.
 * @returns {Promise<boolean>} vrai si la fenêtre s'est ouverte
 */
async function ouvrirMailto(email, sujet, corps) {
    if (!email) return false;
    const mailto = 'mailto:' + email
        + '?subject=' + encodeURIComponent(sujet)
        + '&body=' + encodeURIComponent(corps);
    try {
        const win = window.open(mailto, '_blank');
        return !!(win && !win.closed);
    } catch {
        return false;
    }
}

/** Copie un texte dans le presse-papier. @returns {Promise<boolean>} vrai si la copie a réussi */
async function copierTexte(texte) {
    try {
        await navigator.clipboard.writeText(texte);
        return true;
    } catch {
        return false;
    }
}
