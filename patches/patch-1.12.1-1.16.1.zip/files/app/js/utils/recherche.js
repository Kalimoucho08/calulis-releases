/**
 * Calulis — Recherche : règles de correspondance PARTAGÉES.
 *
 * Une seule source pour « est-ce que ce élève / cet adulte / cet établissement / cette classe
 * correspond au terme tapé ». L'annuaire et la recherche globale du haut de page s'appuient
 * toutes les deux dessus : un même terme doit donner les mêmes trouvailles des deux côtés.
 *
 * La comparaison ignore la casse ET les accents (« Léger » se trouve en tapant « leger »),
 * parce que personne ne tape les accents dans une barre de recherche.
 */
const Recherche = {

    /** Minuscules, sans accents, espaces de bord retirés. */
    normaliser(valeur) {
        return String(valeur == null ? '' : valeur)
            .normalize('NFD')
            .replace(/[\u0300-\u036f]/g, '')
            .toLowerCase()
            .trim();
    },

    /** Vrai si l'un des champs contient le terme (casse et accents ignorés). */
    correspond(champs, terme) {
        const t = this.normaliser(terme);
        if (!t) return true;
        return (champs || []).some(c => c != null && this.normaliser(c).includes(t));
    },

    /** Champs d'un élève sur lesquels la recherche porte. */
    champsEleve(e) {
        if (!e) return [];
        return [
            e.nom, e.prenom, `${e.prenom || ''} ${e.nom || ''}`, e.classe,
            e.telephone, e.email, e.adresse, e.ecole_origine, e.transport, e.suivi_par,
        ];
    },

    /** Champs d'un adulte (nom, rôle, coordonnées, établissements liés). */
    champsAdulte(a) {
        if (!a) return [];
        const etabText = (a.liens_etablissements || [])
            .map(et => (et.nom || '') + ' ' + (et.ville || '')).join(' ');
        return [
            a.nom, a.prenom, `${a.prenom || ''} ${a.nom || ''}`, a.role, a.fonction,
            a.telephone, a.email, a.commentaires, etabText,
        ];
    },

    /** Champs d'un établissement. */
    champsEtablissement(et) {
        if (!et) return [];
        return [et.nom, et.ville, et.type, et.telephone, et.email];
    },

    /** Champs d'une classe (nom, niveaux). */
    champsClasse(c) {
        if (!c) return [];
        const niveaux = Array.isArray(c.niveaux) ? c.niveaux.join(' ') : c.niveaux;
        return [c.nom, niveaux];
    },
};
