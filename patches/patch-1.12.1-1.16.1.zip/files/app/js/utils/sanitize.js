/**
 * Calulis — Utilitaires sanitization + sélecteurs DOM
 */
function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}

/**
 * Échappement pour un CONTEXTE D'ATTRIBUT (value="…", aria-label="…", title="…").
 * `escapeHtml` passe par textContent → innerHTML : il échappe < > & mais PAS les guillemets.
 * Mesuré le 04/10/2026 : escapeHtml('a"b') === 'a"b' — dans un attribut, le guillemet ferme
 * la valeur et la suite devient du balisage. Ne jamais utiliser escapeHtml dans un attribut.
 */
function escapeAttr(str) {
    return String(str == null ? '' : str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function $(selector, parent = document) {
    return parent.querySelector(selector);
}

function $$(selector, parent = document) {
    return Array.from(parent.querySelectorAll(selector));
}
