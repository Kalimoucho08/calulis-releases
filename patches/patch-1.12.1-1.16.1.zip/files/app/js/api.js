/**
 * Calulis — Client HTTP API
 * Tous les appels passent par le backend PHP (MySQL).
 */

// ── Anti-CSRF : l'API locale n'accepte que les requêtes portant le jeton
// interne (X-Calulis-App). Une page web externe ne peut pas poser d'en-tête
// custom sans préflight — et le préflight est refusé pour les origines non
// locales (CORS restreint côté serveur). Le wrapper global couvre TOUS les
// fetch (API.*, state.js, params.js…).
(() => {
    const _origFetch = window.fetch;
    window.fetch = function (url, opts = {}) {
        opts = opts || {};
        opts.headers = Object.assign({}, opts.headers, { 'X-Calulis-App': '1' });
        return _origFetch.call(this, url, opts);
    };
})();

const API = {
    base: 'api',
    _loading: 0,

    async health() {
        try {
            const res = await fetch(`${this.base}/ping.php`);
            return res.ok;
        } catch {
            return false;
        }
    },

    async _fetch(url, opts = {}) {
        this._loading++;
        document.body.classList.add('loading');
        try {
            const res = await fetch(url, opts);
            return await this._handle(res);
        } catch (e) {
            if (e instanceof TypeError || e.name === 'TypeError') {
                throw new Error('Impossible de contacter le serveur. Vérifie la connexion.');
            }
            throw e;
        } finally {
            this._loading--;
            if (this._loading <= 0) {
                this._loading = 0;
                document.body.classList.remove('loading');
            }
        }
    },

    /**
     * Ajoute les query params globaux (annee_scolaire_id, etc.)
     * `options.sansAnnee` les omet : la page Documents montre le dossier complet
     * d'un élève, toutes années confondues (un élève sorti du dispositif doit
     * rester retrouvable — règle de conservation du 04/10/2026).
     */
    _buildUrl(endpoint, options = {}) {
        let url = `${this.base}/${endpoint}`;
        if (!options.sansAnnee && typeof State !== 'undefined' && State.getQueryParams) {
            const params = State.getQueryParams();
            const keys = Object.keys(params);
            if (keys.length > 0) {
                const sep = endpoint.includes('?') ? '&' : '?';
                url += sep + keys.map(k => `${k}=${encodeURIComponent(params[k])}`).join('&');
            }
        }
        return url;
    },

    async get(endpoint, options = {}) {
        return this._fetch(this._buildUrl(endpoint, options));
    },

    async post(endpoint, data) {
        // Ajouter l'année active dans le body si elle n'y est pas
        if (typeof State !== 'undefined' && State.get) {
            const anneeId = State.get('annee_scolaire_id');
            if (anneeId && data && typeof data === 'object' && !data.annee_scolaire_id) {
                data.annee_scolaire_id = anneeId;
            }
        }
        return this._fetch(`${this.base}/${endpoint}`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data),
        });
    },

    async put(endpoint, data) {
        // Ajouter l'année active dans le body si elle n'y est pas
        if (typeof State !== 'undefined' && State.get) {
            const anneeId = State.get('annee_scolaire_id');
            if (anneeId && data && typeof data === 'object' && !data.annee_scolaire_id) {
                data.annee_scolaire_id = anneeId;
            }
        }
        return this._fetch(`${this.base}/${endpoint}`, {
            method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data),
        });
    },

    async del(endpoint) {
        return this._fetch(`${this.base}/${endpoint}`, { method: 'DELETE' });
    },

    /**
     * Envoi d'un fichier (multipart). `formData` est construit par l'appelant ;
     * l'année active y est ajoutée comme pour post(). Le navigateur pose lui-même
     * l'en-tête Content-Type (frontière multipart) : ne JAMAIS le fixer ici.
     */
    async upload(endpoint, formData) {
        if (typeof State !== 'undefined' && State.get) {
            const anneeId = State.get('annee_scolaire_id');
            if (anneeId && !formData.has('annee_scolaire_id')) {
                formData.append('annee_scolaire_id', anneeId);
            }
        }
        return this._fetch(`${this.base}/${endpoint}`, { method: 'POST', body: formData });
    },

    /**
     * Récupère le fichier d'un document en Blob. Le jeton X-Calulis-App est posé
     * par le wrapper global : un document n'est donc jamais obtenu par une URL nue,
     * et son contenu n'est jamais exposé au serveur web.
     */
    async blob(endpoint, options = {}) {
        const reponse = await this.blobAvecNom(endpoint, options);
        return reponse.blob;
    },

    /**
     * Comme `blob()`, mais rend AUSSI le nom de fichier annoncé par le serveur
     * (`Content-Disposition`). C'est ce nom qu'il faut donner au téléchargement :
     * le reconstruire côté navigateur dupliquerait la règle de nommage, et les deux
     * copies finiraient par diverger. Utilisé par l'archive des documents d'un élève,
     * dont le nom porte le nom de l'élève et la date.
     *
     * `options.sansAnnee` omet l'année active (l'archive d'un élève couvre toutes ses
     * années : un élève sorti du dispositif doit rester retrouvable).
     *
     * @return {Promise<{blob: Blob, nom: string}>}
     */
    async blobAvecNom(endpoint, options = {}) {
        this._loading++;
        document.body.classList.add('loading');
        try {
            const res = await fetch(this._buildUrl(endpoint, options));
            if (!res.ok) {
                let message = 'Le document n\'a pas pu être ouvert (HTTP ' + res.status + ').';
                try {
                    const j = await res.json();
                    if (j && typeof j.error === 'string' && j.error) message = j.error;
                } catch { /* corps binaire ou vide : on garde le message générique */ }
                throw new Error(message);
            }
            const nom = this._nomDeFichier(res.headers.get('Content-Disposition'));
            return { blob: await res.blob(), nom };
        } finally {
            this._loading--;
            if (this._loading <= 0) {
                this._loading = 0;
                document.body.classList.remove('loading');
            }
        }
    },

    /** Nom de fichier d'un en-tête Content-Disposition, ou chaîne vide. */
    _nomDeFichier(entete) {
        if (!entete) return '';
        // Forme moderne d'abord (`filename*=UTF-8''…`), forme simple ensuite.
        const moderne = /filename\*=UTF-8''([^;]+)/i.exec(entete);
        const simple = /filename="?([^";]+)"?/i.exec(entete);
        const brut = moderne ? moderne[1] : (simple ? simple[1] : '');
        if (!brut) return '';
        try {
            return decodeURIComponent(brut.trim());
        } catch {
            return brut.trim();
        }
    },

    async _handle(res) {
        if (!res.ok) {
            let message = null;
            let detail = null;
            try {
                const j = await res.json();
                if (j && typeof j.error === 'string' && j.error) message = j.error;
                if (j && typeof j.detail === 'string' && j.detail) detail = j.detail;
            } catch {
                // Corps non-JSON (fatal PHP sans handler, proxy…) → message générique
            }
            if (!message) {
                message = 'Erreur serveur (HTTP ' + res.status + '). Si le problème persiste, relancez l\'application.';
                if (res.statusText) console.error('[API] réponse non-JSON, statusText:', res.statusText);
            }
            if (detail) console.error('[API] détail:', detail);
            // Dernière erreur API → visible dans le Bug Report (bouton 🐛)
            window._calulisLastApiError = { status: res.status, message, detail, ts: new Date().toISOString() };
            throw new Error(message);
        }
        if (res.status === 204) return { ok: true };
        return res.json();
    },
};
