/**
 * Calulis — Tâches
 *
 * Une tâche = une chose à faire, avec une échéance. Elle peut être liée à un élève,
 * à un adulte, aux deux, ou à personne (tâche générale). Le coordonnateur est seul
 * utilisateur : pas de responsable d'exécution.
 *
 * Convention serveur (Tache.php) : la PREMIÈRE LIGNE de `description` est le titre,
 * le reste est le détail. L'écran présente donc deux champs et compose à l'enregistrement.
 */
const Taches = {

    _statuts: [
        { cle: 'a_faire',   libelle: 'À faire'   },
        { cle: 'plus_tard', libelle: 'Plus tard' },
        { cle: 'en_cours',  libelle: 'En cours'  },
        { cle: 'fait',      libelle: 'Fait'      },
        { cle: 'annule',    libelle: 'Annulé'    },
    ],
    _couleurs: [
        { cle: 'jaune',  nom: 'Jaune',  fond: '#fff4c2', bord: '#efd463' },
        { cle: 'vert',   nom: 'Vert',   fond: '#d9f5de', bord: '#88cf9a' },
        { cle: 'bleu',   nom: 'Bleu',   fond: '#dcecff', bord: '#8fbdf0' },
        { cle: 'rose',   nom: 'Rose',   fond: '#ffe0ec', bord: '#f0a1bd' },
        { cle: 'violet', nom: 'Violet', fond: '#e8dfff', bord: '#b3a0e6' },
        { cle: 'orange', nom: 'Orange', fond: '#ffe6cf', bord: '#f0b183' },
    ],
    _priorites: { haute: 'Haute', moyenne: 'Moyenne', basse: 'Basse' },

    _taches: [],
    _eleves: [],
    _adultes: [],
    _vue: 'tableau',
    _coches: new Set(),
    _tri: { cle: 'echeance', sens: 1 },

    async render() {
        const view = document.getElementById('view-taches');
        view.innerHTML = '<p class="text-muted" style="padding:24px">Chargement des tâches…</p>';
        try {
            const [taches, eleves, adultes] = await Promise.all([
                API.get('taches.php'),
                API.get('eleves.php'),
                API.get('adultes.php'),
            ]);
            this._taches = Array.isArray(taches) ? taches : [];
            this._eleves = (Array.isArray(eleves) ? eleves : [])
                .sort((a, b) => `${a.nom} ${a.prenom}`.localeCompare(`${b.nom} ${b.prenom}`, 'fr'));
            this._adultes = (Array.isArray(adultes) ? adultes : [])
                .sort((a, b) => `${a.nom} ${a.prenom}`.localeCompare(`${b.nom} ${b.prenom}`, 'fr'));
        } catch (e) {
            console.error('[Taches] chargement impossible:', e);
            view.innerHTML = '<p class="text-muted" style="padding:24px">Impossible de charger les tâches. ' +
                'Vérifiez que la base est démarrée.</p>';
            return;
        }
        this._dessiner();
    },

    /* ------------------------------------------------------------------ */
    /* Titre / détail : même règle que Tache.php                           */
    /* ------------------------------------------------------------------ */

    _titre(t) { return (t.description || '').split(/\r?\n/)[0].trim(); },
    _detail(t) {
        const l = (t.description || '').split(/\r?\n/);
        l.shift();
        return l.join('\n').trim();
    },
    _couleur(cle) { return this._couleurs.find(c => c.cle === cle) || this._couleurs[0]; },
    _libelleStatut(cle) { const s = this._statuts.find(x => x.cle === cle); return s ? s.libelle : cle; },
    _concerne(t) {
        if (t.eleve_id && t.eleve_nom) return { texte: `${t.eleve_prenom || ''} ${t.eleve_nom}`.trim(), classe: 'eleve' };
        if (t.adulte_id && t.adulte_nom) {
            const nom = [t.adulte_civilite, t.adulte_prenom, t.adulte_nom].filter(Boolean).join(' ');
            return { texte: nom, classe: 'adulte' };
        }
        return { texte: 'Sans élève', classe: 'general' };
    },
    _dateFr(iso) {
        if (!iso) return '';
        try {
            return new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'short' })
                .format(new Date(iso + 'T00:00:00'));
        } catch { return iso; }
    },
    _jour(iso) {
        const a = new Date(); a.setHours(0, 0, 0, 0);
        return Math.round((new Date(iso + 'T00:00:00') - a) / 86400000);
    },
    _etatEcheance(iso, statut) {
        if (!iso) return { classe: '', texte: 'sans échéance' };
        // Une tâche TERMINÉE ou ANNULÉE n'est plus « en retard » (décision de Jérôme,
        // 04/10/2026 : « si c'est terminé, ça ne peut pas être en retard »). La date reste
        // affichée — elle sert à retrouver la tâche — mais sans rouge ni mot d'urgence.
        if (statut === 'fait' || statut === 'annule') return { classe: '', texte: this._dateFr(iso) };
        const j = this._jour(iso);
        if (j < 0) return { classe: 'retard', texte: this._dateFr(iso) + ' · en retard' };
        if (j <= 2) return { classe: 'bientot', texte: this._dateFr(iso) + (j === 0 ? ' · aujourd\u2019hui' : ' · bientôt') };
        return { classe: '', texte: this._dateFr(iso) };
    },

    /* ------------------------------------------------------------------ */
    /* Affichage                                                           */
    /* ------------------------------------------------------------------ */

    _dessiner() {
        const view = document.getElementById('view-taches');
        const tableau = this._vue === 'tableau';
        view.innerHTML = `
        <div class="suivi-entete">
            <h2 style="margin:0">Tâches</h2>
            <div class="vue-bascule" role="group" aria-label="Choix de la vue">
                <button type="button" id="taches-vue-tableau" aria-pressed="${tableau}">Tableau</button>
                <button type="button" id="taches-vue-liste" aria-pressed="${!tableau}">Liste</button>
            </div>
            <button class="btn btn-primary" id="taches-nouvelle">+ Nouvelle tâche</button>
        </div>
        <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap;margin:10px 0">
            <span class="text-muted"><strong>${this._taches.length}</strong> tâche(s)</span>
            <span class="text-muted">·</span>
            <span class="text-muted"><strong id="taches-n-coches">${this._coches.size}</strong> cochée(s)</span>
            <button class="btn btn-sm" id="taches-tout">Tout cocher</button>
            <button class="btn btn-sm" id="taches-rien">Tout décocher</button>
        </div>

        <div class="card" style="margin-bottom:14px;display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
            <div class="form-group" style="margin:0">
                <label for="taches-i-quoi">Quoi imprimer</label>
                <select id="taches-i-quoi">
                    <option value="a_venir">Ce qui reste à faire</option>
                    <option value="faites_periode">Ce qui a été fait sur une période</option>
                    <option value="coche">La sélection cochée</option>
                    <option value="tout">Toutes les tâches de l'année</option>
                </select>
            </div>
            <div class="form-group" style="margin:0">
                <label for="taches-i-du">Du</label>
                <input type="date" id="taches-i-du">
            </div>
            <div class="form-group" style="margin:0">
                <label for="taches-i-au">Au</label>
                <input type="date" id="taches-i-au">
            </div>
            <div class="form-group" style="margin:0">
                <label for="taches-i-groupe">Présentation</label>
                <select id="taches-i-groupe">
                    <option value="statut">Par statut</option>
                    <option value="echeance">Par échéance</option>
                    <option value="personne">Par personne concernée</option>
                </select>
            </div>
            <div class="form-group" style="margin:0">
                <label for="taches-i-opt">Contenu</label>
                <select id="taches-i-opt">
                    <option value="complet">Titre et détail</option>
                    <option value="court">Liste courte — titres seulement</option>
                </select>
            </div>
            <button class="btn btn-secondary" id="taches-apercu">Aperçu</button>
            <button class="btn btn-primary" id="taches-imprimer">🖨️ Imprimer / PDF</button>
        </div>

        <div id="taches-zone"></div>`;

        if (tableau) this._dessinerTableau(); else this._dessinerListe();
        this._brancher();
    },

    _dessinerTableau() {
        const zone = document.getElementById('taches-zone');
        zone.className = 'taches-plateau';
        zone.innerHTML = this._statuts.map(st => {
            const dedans = this._taches.filter(t => t.statut === st.cle);
            return `
            <section class="taches-colonne" data-statut="${st.cle}">
                <div class="taches-colonne-tete">${st.libelle}<span class="taches-compteur">${dedans.length}</span></div>
                <div class="taches-corps">${dedans.map(t => this._carte(t)).join('')}</div>
            </section>`;
        }).join('');
        this._brancherCartes();
    },

    _carte(t) {
        const c = this._couleur(t.couleur);
        const ech = this._etatEcheance(t.echeance, t.statut);
        const concerne = this._concerne(t);
        const cochee = this._coches.has(t.id);
        const options = this._statuts.map(s =>
            `<option value="${s.cle}"${s.cle === t.statut ? ' selected' : ''}>Déplacer vers : ${s.libelle}</option>`).join('');
        return `
        <article class="tache-carte${cochee ? ' cochee' : ''}" data-id="${t.id}" draggable="true"
                 style="background:${c.fond};border-color:${c.bord}">
            <div class="tache-carte-tete">
                <input type="checkbox" data-coche="${t.id}" ${cochee ? 'checked' : ''}
                       aria-label="Sélectionner la tâche ${escapeAttr(this._titre(t))}">
            </div>
            <button class="tache-ouvrir" type="button" data-ouvrir="${t.id}"
                    aria-label="Ouvrir la tâche : ${escapeAttr(this._titre(t))}">
                <span class="tache-titre">${escapeHtml(this._titre(t))}</span>
                <span class="tache-extrait">${escapeHtml(this._detail(t))}</span>
            </button>
            <div class="tache-pied">
                <span class="tache-etiquette ${concerne.classe}">${escapeHtml(concerne.texte)}</span>
                ${t.precision_libre ? `<span class="tache-etiquette">${escapeHtml(t.precision_libre)}</span>` : ''}
                <span class="tache-echeance ${ech.classe}">${ech.texte}</span>
            </div>
            <select class="tache-deplacer" data-deplacer="${t.id}"
                    aria-label="Changer le statut de la tâche ${escapeAttr(this._titre(t))}">${options}</select>
        </article>`;
    },

    _dessinerListe() {
        const zone = document.getElementById('taches-zone');
        zone.className = '';
        const ordreP = { haute: 0, moyenne: 1, basse: 2 };
        const rangS = Object.fromEntries(this._statuts.map((s, i) => [s.cle, i]));
        const copie = this._taches.slice().sort((a, b) => {
            let x, y;
            if (this._tri.cle === 'priorite') { x = ordreP[a.priorite]; y = ordreP[b.priorite]; }
            else if (this._tri.cle === 'statut') { x = rangS[a.statut]; y = rangS[b.statut]; }
            else if (this._tri.cle === 'titre') { x = this._titre(a).toLowerCase(); y = this._titre(b).toLowerCase(); }
            else if (this._tri.cle === 'concerne') { x = this._concerne(a).texte; y = this._concerne(b).texte; }
            else { x = a.echeance || '9999'; y = b.echeance || '9999'; }
            return (x > y ? 1 : x < y ? -1 : 0) * this._tri.sens;
        });
        const fleche = (cle) => this._tri.cle === cle ? (this._tri.sens === 1 ? ' ▾' : ' ▴') : '';
        zone.innerHTML = `
        <table class="taches-liste">
            <caption class="sr-only">Liste des tâches</caption>
            <thead><tr>
                <th style="width:34px"></th>
                <th data-tri="titre" tabindex="0"${this._tri.cle === 'titre' ? ` aria-sort="${this._tri.sens === 1 ? 'ascending' : 'descending'}"` : ''}>Tâche${fleche('titre')}</th>
                <th data-tri="concerne" tabindex="0"${this._tri.cle === 'concerne' ? ` aria-sort="${this._tri.sens === 1 ? 'ascending' : 'descending'}"` : ''}>Concerne${fleche('concerne')}</th>
                <th data-tri="echeance" tabindex="0"${this._tri.cle === 'echeance' ? ` aria-sort="${this._tri.sens === 1 ? 'ascending' : 'descending'}"` : ''}>Échéance${fleche('echeance')}</th>
                <th data-tri="priorite" tabindex="0"${this._tri.cle === 'priorite' ? ` aria-sort="${this._tri.sens === 1 ? 'ascending' : 'descending'}"` : ''}>Priorité${fleche('priorite')}</th>
                <th data-tri="statut" tabindex="0"${this._tri.cle === 'statut' ? ` aria-sort="${this._tri.sens === 1 ? 'ascending' : 'descending'}"` : ''}>Statut${fleche('statut')}</th>
            </tr></thead>
            <tbody>
                ${copie.map(t => {
                    const ech = this._etatEcheance(t.echeance, t.statut);
                    const concerne = this._concerne(t);
                    const c = this._couleur(t.couleur);
                    const options = this._statuts.map(s =>
                        `<option value="${s.cle}"${s.cle === t.statut ? ' selected' : ''}>${s.libelle}</option>`).join('');
                    return `<tr>
                        <td><input type="checkbox" data-coche="${t.id}" ${this._coches.has(t.id) ? 'checked' : ''}
                                   aria-label="Sélectionner la tâche ${escapeAttr(this._titre(t))}"></td>
                        <td><span class="tache-pastille" style="background:${c.fond};border-color:${c.bord}"></span>
                            <button class="tache-lien" type="button" data-ouvrir="${t.id}">${escapeHtml(this._titre(t))}</button></td>
                        <td><span class="tache-etiquette ${concerne.classe}">${escapeHtml(concerne.texte)}</span></td>
                        <td><span class="tache-echeance ${ech.classe}">${ech.texte}</span></td>
                        <td>${this._priorites[t.priorite] || t.priorite}</td>
                        <td><select data-deplacer="${t.id}" aria-label="Statut de ${escapeAttr(this._titre(t))}">${options}</select></td>
                    </tr>`;
                }).join('')}
            </tbody>
        </table>`;
        zone.querySelectorAll('th[data-tri]').forEach(th => {
            const trier = () => {
                const cle = th.dataset.tri;
                this._tri = { cle, sens: this._tri.cle === cle ? -this._tri.sens : 1 };
                this._dessinerListe();
            };
            th.addEventListener('click', trier);
            th.addEventListener('keydown', (ev) => { if (ev.key === 'Enter' || ev.key === ' ') { ev.preventDefault(); trier(); } });
        });
        this._brancherCartes();
    },

    _brancher() {
        const view = document.getElementById('view-taches');
        view.querySelector('#taches-nouvelle').addEventListener('click', () => this._ouvrir(null));
        view.querySelector('#taches-vue-tableau').addEventListener('click', () => { this._vue = 'tableau'; this._dessiner(); });
        view.querySelector('#taches-vue-liste').addEventListener('click', () => { this._vue = 'liste'; this._dessiner(); });
        view.querySelector('#taches-tout').addEventListener('click', () => {
            this._taches.forEach(t => this._coches.add(t.id)); this._dessiner();
        });
        view.querySelector('#taches-rien').addEventListener('click', () => {
            this._coches.clear(); this._dessiner();
        });
        view.querySelector('#taches-apercu').addEventListener('click', () => this._imprimer(true));
        view.querySelector('#taches-imprimer').addEventListener('click', () => this._imprimer(false));
    },

    _brancherCartes() {
        document.querySelectorAll('[data-ouvrir]').forEach(b =>
            b.addEventListener('click', () => this._ouvrir(Number(b.dataset.ouvrir))));
        document.querySelectorAll('[data-deplacer]').forEach(s =>
            s.addEventListener('change', () => this._changerStatut(Number(s.dataset.deplacer), s.value)));
        document.querySelectorAll('[data-coche]').forEach(cb =>
            cb.addEventListener('change', () => {
                const id = Number(cb.dataset.coche);
                if (cb.checked) this._coches.add(id); else this._coches.delete(id);
                const compteur = document.getElementById('taches-n-coches');
                if (compteur) compteur.textContent = this._coches.size;
                const carte = cb.closest('.tache-carte');
                if (carte) carte.classList.toggle('cochee', cb.checked);
            }));

        // Glisser-déposer entre colonnes — jamais le SEUL moyen : le « Déplacer vers »
        // de chaque carte fait la même chose au clavier.
        document.querySelectorAll('.tache-carte').forEach(carte => {
            carte.addEventListener('dragstart', (ev) => {
                ev.dataTransfer.setData('text/plain', carte.dataset.id);
                ev.dataTransfer.effectAllowed = 'move';
                carte.classList.add('porte');
            });
            carte.addEventListener('dragend', () => carte.classList.remove('porte'));
        });
        document.querySelectorAll('.taches-colonne').forEach(colonne => {
            colonne.addEventListener('dragover', (ev) => { ev.preventDefault(); colonne.classList.add('survol'); });
            colonne.addEventListener('dragleave', () => colonne.classList.remove('survol'));
            colonne.addEventListener('drop', (ev) => {
                ev.preventDefault();
                colonne.classList.remove('survol');
                const id = Number(ev.dataTransfer.getData('text/plain'));
                if (id) this._changerStatut(id, colonne.dataset.statut);
            });
        });
    },

    async _changerStatut(id, statut) {
        const t = this._taches.find(x => x.id === id);
        if (!t || t.statut === statut) return;
        try {
            await API.put(`taches.php?id=${id}`, { statut });
            t.statut = statut;
            Toast.show(`Tâche déplacée dans « ${this._libelleStatut(statut)} ».`, 'success');
            this._dessiner();
        } catch (e) {
            console.error('[Taches] changement de statut impossible:', e);
            Toast.show('Changement de statut impossible.', 'error');
        }
    },

    /* ------------------------------------------------------------------ */
    /* Création / modification / suppression                               */
    /* ------------------------------------------------------------------ */

    _optionsEleves(selection) {
        return '<option value="">— Aucun —</option>' + this._eleves.map(e =>
            `<option value="${e.id}"${String(selection) === String(e.id) ? ' selected' : ''}>` +
            `${escapeHtml((e.prenom || '') + ' ' + (e.nom || ''))}</option>`).join('');
    },

    _optionsAdultes(selection) {
        return '<option value="">— Aucun —</option>' + this._adultes.map(a =>
            `<option value="${a.id}"${String(selection) === String(a.id) ? ' selected' : ''}>` +
            `${escapeHtml([a.civilite, a.prenom, a.nom].filter(Boolean).join(' '))}</option>`).join('');
    },

    _ouvrir(id) {
        const t = id ? this._taches.find(x => x.id === id) : null;
        const aujourdhui = new Date().toISOString().slice(0, 10);
        const couleurChoisie = t ? (t.couleur || 'jaune') : 'jaune';
        const pastilles = this._couleurs.map(c =>
            `<button type="button" class="tache-pastille-choix" data-couleur="${c.cle}"
                     style="background:${c.fond};border-color:${c.bord}"
                     aria-pressed="${c.cle === couleurChoisie}" title="${c.nom}"
                     aria-label="Couleur ${c.nom}"></button>`).join('');

        Modal.open({
            title: t ? 'Modifier la tâche' : 'Nouvelle tâche',
            body: `
                <div class="form-group">
                    <label for="tache-titre">Titre</label>
                    <input type="text" id="tache-titre" maxlength="200" placeholder="Ce qu'il y a à faire"
                           value="${t ? escapeHtml(this._titre(t)) : ''}">
                </div>
                <div class="form-group">
                    <label for="tache-detail">Détail</label>
                    <textarea id="tache-detail" rows="3" maxlength="500" placeholder="Précisions, étapes, documents à réunir…">${t ? escapeHtml(this._detail(t)) : ''}</textarea>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="tache-echeance">Échéance</label>
                        <input type="date" id="tache-echeance" value="${t && t.echeance ? t.echeance : ''}">
                    </div>
                    <div class="form-group">
                        <label for="tache-priorite">Priorité</label>
                        <select id="tache-priorite">
                            ${Object.entries(this._priorites).map(([c, l]) =>
                                `<option value="${c}"${t && t.priorite === c ? ' selected' : (!t && c === 'moyenne' ? ' selected' : '')}>${l}</option>`).join('')}
                        </select>
                    </div>
                </div>
                <div class="form-row">
                    <div class="form-group">
                        <label for="tache-statut">Statut</label>
                        <select id="tache-statut">
                            ${this._statuts.map(s =>
                                `<option value="${s.cle}"${t && t.statut === s.cle ? ' selected' : (!t && s.cle === 'a_faire' ? ' selected' : '')}>${s.libelle}</option>`).join('')}
                        </select>
                    </div>
                    <div class="form-group">
                        <label for="tache-concerne">Concerne</label>
                        <select id="tache-concerne">
                            <option value="aucun"${!t || (!t.eleve_id && !t.adulte_id) ? ' selected' : ''}>Personne en particulier</option>
                            <option value="eleve"${t && t.eleve_id ? ' selected' : ''}>Un élève</option>
                            <option value="adulte"${t && t.adulte_id ? ' selected' : ''}>Un adulte</option>
                        </select>
                    </div>
                </div>
                <div class="form-group" id="tache-bloc-eleve" style="${t && t.eleve_id ? '' : 'display:none'}">
                    <label for="tache-eleve">Élève</label>
                    <select id="tache-eleve">${this._optionsEleves(t ? t.eleve_id : null)}</select>
                </div>
                <div class="form-group" id="tache-bloc-adulte" style="${t && t.adulte_id ? '' : 'display:none'}">
                    <label for="tache-adulte">Adulte</label>
                    <select id="tache-adulte">${this._optionsAdultes(t ? t.adulte_id : null)}</select>
                </div>
                <div class="form-group">
                    <label for="tache-precision">Précision (100 caractères)</label>
                    <input type="text" id="tache-precision" maxlength="100"
                           placeholder="Établissement, interlocuteur…" value="${t && t.precision_libre ? escapeHtml(t.precision_libre) : ''}">
                    <small class="text-muted"><span id="tache-precision-compteur">0</span> / 100 — une précision courte, pas le détail</small>
                </div>
                <div class="form-group">
                    <label id="tache-couleurs-label">Couleur du post-it</label>
                    <div class="tache-couleurs" role="group" aria-labelledby="tache-couleurs-label">${pastilles}</div>
                </div>`,
            footer: `
                ${t ? '<button class="btn btn-danger" id="tache-supprimer">Supprimer</button>' : ''}
                <button class="btn btn-secondary" id="tache-annuler">Annuler</button>
                <button class="btn btn-primary" id="tache-enregistrer">Enregistrer</button>`,
        });

        // Choix de la couleur
        let couleur = couleurChoisie;
        document.querySelectorAll('.tache-pastille-choix').forEach(b => {
            b.addEventListener('click', () => {
                couleur = b.dataset.couleur;
                document.querySelectorAll('.tache-pastille-choix').forEach(x =>
                    x.setAttribute('aria-pressed', String(x.dataset.couleur === couleur)));
            });
        });

        // Lien élève / adulte
        const basculerLien = () => {
            const choix = document.getElementById('tache-concerne').value;
            document.getElementById('tache-bloc-eleve').style.display = choix === 'eleve' ? '' : 'none';
            document.getElementById('tache-bloc-adulte').style.display = choix === 'adulte' ? '' : 'none';
        };
        document.getElementById('tache-concerne').addEventListener('change', basculerLien);
        basculerLien();

        // Compteur de la précision
        const precision = document.getElementById('tache-precision');
        const compteur = document.getElementById('tache-precision-compteur');
        const majCompteur = () => { compteur.textContent = precision.value.length; };
        precision.addEventListener('input', majCompteur);
        majCompteur();

        setTimeout(() => { const el = document.getElementById('tache-titre'); if (el) el.focus(); }, 160);

        document.getElementById('tache-annuler').addEventListener('click', () => Modal.close());
        if (t) {
            // Confirmation DANS la fenêtre, en deux temps. « Modal.confirm » remplacerait la fiche
            // ouverte : annuler la suppression ferait perdre la saisie en cours — exactement le
            // piège payé le 29/09/2026 avec la boîte de conflit.
            const boutonSupprimer = document.getElementById('tache-supprimer');
            boutonSupprimer.addEventListener('click', () => {
                if (boutonSupprimer.dataset.confirme !== '1') {
                    boutonSupprimer.dataset.confirme = '1';
                    boutonSupprimer.textContent = 'Confirmer la suppression';
                    return;
                }
                this._supprimer(t);
            });
        }
        document.getElementById('tache-enregistrer').addEventListener('click', async () => {
            const titre = document.getElementById('tache-titre').value.trim();
            if (!titre) { Toast.show('Il faut au moins un titre.', 'error'); return; }
            const choix = document.getElementById('tache-concerne').value;
            const donnees = {
                titre,
                detail: document.getElementById('tache-detail').value.trim(),
                echeance: document.getElementById('tache-echeance').value,
                priorite: document.getElementById('tache-priorite').value,
                statut: document.getElementById('tache-statut').value,
                couleur,
                precision_libre: precision.value.trim(),
                eleve_id: choix === 'eleve' ? Number(document.getElementById('tache-eleve').value) || null : null,
                adulte_id: choix === 'adulte' ? Number(document.getElementById('tache-adulte').value) || null : null,
            };
            try {
                if (t) await API.put(`taches.php?id=${t.id}`, donnees);
                else await API.post('taches.php', donnees);
                Modal.close();
                Toast.show(t ? 'Tâche modifiée.' : 'Tâche ajoutée.', 'success');
                await this._recharger();
            } catch (e) {
                console.error('[Taches] enregistrement impossible:', e);
                Toast.show('Enregistrement impossible : ' + (e.message || 'erreur inconnue'), 'error');
            }
        });
    },

    async _supprimer(t) {
        try {
            await API.del(`taches.php?id=${t.id}`);
            this._coches.delete(t.id);
            Modal.close();
            Toast.show('Tâche supprimée.', 'success');
            await this._recharger();
        } catch (e) {
            console.error('[Taches] suppression impossible:', e);
            Toast.show('Suppression impossible.', 'error');
        }
    },

    async _recharger() {
        const taches = await API.get('taches.php');
        this._taches = Array.isArray(taches) ? taches : [];
        this._dessiner();
    },

    /* ------------------------------------------------------------------ */
    /* Impression                                                          */
    /* ------------------------------------------------------------------ */

    _selectionPourImpression() {
        const quoi = document.getElementById('taches-i-quoi').value;
        if (quoi === 'tout') return this._taches.slice();
        if (quoi === 'coche') return this._taches.filter(t => this._coches.has(t.id));
        if (quoi === 'faites_periode') {
            const du = document.getElementById('taches-i-du').value;
            const au = document.getElementById('taches-i-au').value;
            return this._taches.filter(t => t.statut === 'fait'
                && (!du || (t.echeance && t.echeance >= du))
                && (!au || (t.echeance && t.echeance <= au)));
        }
        // « Ce qui reste à faire » : les trois statuts actifs, dans l'ordre des échéances
        return this._taches.filter(t => ['a_faire', 'plus_tard', 'en_cours'].includes(t.statut));
    },

    _sousTitre(selection) {
        const quoi = document.getElementById('taches-i-quoi').value;
        const du = document.getElementById('taches-i-du').value;
        const au = document.getElementById('taches-i-au').value;
        const bouts = [];
        if (quoi === 'coche') bouts.push(`sélection de ${selection.length} tâche(s)`);
        else if (quoi === 'faites_periode') bouts.push('tâches faites');
        else if (quoi === 'a_venir') bouts.push('ce qui reste à faire');
        else bouts.push('toutes les tâches de l\u2019année');
        if ((quoi === 'faites_periode' || quoi === 'tout') && (du || au)) {
            bouts.push(`du ${du || '…'} au ${au || '…'}`);
        }
        return bouts.join(' · ') + ` — ${selection.length} tâche(s)`;
    },

    _docDef() {
        const selection = this._selectionPourImpression();
        const groupe = document.getElementById('taches-i-groupe').value;
        const court = document.getElementById('taches-i-opt').value === 'court';
        const contenu = [
            { text: 'Tâches', style: 'titre' },
            { text: this._sousTitre(selection), style: 'sousTitre' },
        ];

        const ligne = (t) => {
            const blocs = [{
                columns: [
                    { text: this._titre(t), style: 'tacheTitre', width: '*' },
                    { text: this._etatEcheance(t.echeance, t.statut).texte, style: 'tacheDate', width: 'auto' },
                ],
            }];
            if (!court) {
                const detail = this._detail(t);
                if (detail) blocs.push({ text: detail, style: 'tacheDetail' });
                const infos = [this._concerne(t).texte];
                if (t.precision_libre) infos.push(t.precision_libre);
                infos.push('Priorité : ' + (this._priorites[t.priorite] || t.priorite));
                blocs.push({ text: infos.join(' · '), style: 'tacheInfos' });
            }
            return { stack: blocs, margin: [0, 0, 0, 8] };
        };

        const bloc = (titreBloc, liste) => {
            if (titreBloc) contenu.push({ text: titreBloc, style: 'groupe' });
            if (!liste.length) contenu.push({ text: '(aucune tâche)', style: 'tacheInfos' });
            for (const t of liste) contenu.push(ligne(t));
        };

        if (!selection.length) {
            contenu.push({ text: 'Aucune tâche à imprimer avec ces critères.', style: 'sousTitre' });
        } else if (groupe === 'statut') {
            for (const st of this._statuts) {
                const dedans = selection.filter(t => t.statut === st.cle);
                if (dedans.length) bloc(st.libelle, dedans);
            }
        } else if (groupe === 'personne') {
            const groupes = new Map();
            for (const t of selection) {
                const cle = this._concerne(t).texte;
                if (!groupes.has(cle)) groupes.set(cle, []);
                groupes.get(cle).push(t);
            }
            for (const [nom, liste] of [...groupes.entries()].sort((a, b) => a[0].localeCompare(b[0], 'fr'))) {
                bloc(nom, liste);
            }
        } else {
            bloc(null, selection);
        }

        contenu.push({ text: 'Calulis — document de travail, imprimé depuis les tâches.', style: 'pied' });

        return {
            pageSize: 'A4',
            pageMargins: [45, 45, 45, 45],
            defaultStyle: { fontSize: 10 },
            content: contenu,
            styles: {
                titre: { fontSize: 16, bold: true, margin: [0, 0, 0, 2] },
                sousTitre: { fontSize: 9, color: '#555555', margin: [0, 0, 0, 12] },
                groupe: { fontSize: 12, bold: true, margin: [0, 10, 0, 6] },
                tacheTitre: { fontSize: 10.5, bold: true },
                tacheDate: { fontSize: 9, color: '#555555' },
                tacheDetail: { fontSize: 9.5, color: '#333333' },
                tacheInfos: { fontSize: 8.5, color: '#666666', margin: [0, 2, 0, 0] },
                pied: { fontSize: 8, color: '#777777', margin: [0, 16, 0, 0] },
            },
        };
    },

    _imprimer(apercuSeul) {
        const selection = this._selectionPourImpression();
        if (!selection.length) {
            Toast.show('Rien à imprimer : aucune tâche ne correspond.', 'error');
            return;
        }
        Print._showPreview(this._docDef(), 'taches-' + new Date().toISOString().slice(0, 10) + '.pdf');
        if (!apercuSeul) {
            Toast.show('Aperçu prêt : le bouton « Télécharger le PDF » se trouve en bas de la fenêtre.', 'success');
        }
    },
};
