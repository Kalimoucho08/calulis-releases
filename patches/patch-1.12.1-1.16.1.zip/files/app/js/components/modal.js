/**
 * Calulis — Gestionnaire de modale générique
 * Usage : Modal.open({ title, body, footer, onClose })
 */
const Modal = {
    backdrop: null,
    modal: null,
    _onClose: null,

    init() {
        this.backdrop = document.getElementById('modal-backdrop');
        this.modal = document.getElementById('modal');
        document.getElementById('modal-close').addEventListener('click', () => this.close());
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && !this.backdrop.classList.contains('hidden')) {
                this.close();
            }
        });
    },

    /** Ouvre la modale avec contenu personnalisé */
    open({ title, body, footer, onClose } = {}) {
        document.getElementById('modal-title').textContent = title || '';
        const bodyEl = document.getElementById('modal-body');
        const footerEl = document.getElementById('modal-footer');
        bodyEl.innerHTML = body || '';
        footerEl.innerHTML = footer || '';
        linkLabels(bodyEl);
        this._onClose = onClose || null;
        this.backdrop.classList.remove('hidden');
        // Accessibilité : auto-associer les labels aux inputs
        this.modal.querySelectorAll('.form-group label, .form-row label, .field-group label, label:not([for])').forEach(label => {
            if (label.getAttribute('for')) return;
            const input = label.closest('.form-group, .form-row, .field-group, div')?.querySelector('input, select, textarea');
            if (!input) return;
            if (!input.id) input.id = 'm-' + Math.random().toString(36).slice(2, 8);
            label.setAttribute('for', input.id);
            if (!input.getAttribute('aria-label')) {
                input.setAttribute('aria-label', label.textContent.replace(/[*:]/g, '').replace(/\s+/g, ' ').trim() || 'Champ');
            }
        });
        // Focus : d'abord un champ de saisie, sinon le PREMIER BOUTON DU PIED DE PAGE —
        // jamais le « × » de l'en-tête. `Modal.confirm` promettait depuis toujours que
        // « une confirmation dangereuse se refuse par défaut » (Annuler est le premier
        // bouton), mais le focus partait sur la croix : relevé par la revue de code du
        // 08/10/2026. La croix porte maintenant un nom accessible (index.html).
        const premier = this.modal.querySelector('input, select, textarea')
            || footerEl.querySelector('button')
            || this.modal.querySelector('button');
        if (premier) setTimeout(() => premier.focus(), 100);
    },

    /** Ferme la modale */
    close() {
        if (this._onClose) this._onClose();
        this._onClose = null;
        this.backdrop.classList.add('hidden');
    },

    /**
     * Raccourci : boîte de confirmation. Retourne une Promise<boolean>.
     *
     * options.html    : le message est déjà du HTML (plusieurs paragraphes, listes) ;
     * options.okLabel : libellé du bouton de confirmation.
     * Le bouton « Annuler » est le PREMIER et reçoit le focus (Modal.open) :
     * une confirmation dangereuse se refuse par défaut, jamais par inadvertance.
     */
    confirm(title, message, options = {}) {
        const okLabel = options.okLabel || 'Confirmer';
        return new Promise(resolve => {
            Modal.open({
                title,
                body: options.html ? message : `<p>${message}</p>`,
                footer: `
                    <button class="btn btn-secondary" id="modal-confirm-cancel">Annuler</button>
                    <button class="btn btn-danger" id="modal-confirm-ok">${okLabel}</button>
                `,
                onClose: () => resolve(false),
            });
            document.getElementById('modal-confirm-cancel').addEventListener('click', () => {
                Modal._onClose = null;
                Modal.close();
                resolve(false);
            });
            document.getElementById('modal-confirm-ok').addEventListener('click', () => {
                Modal._onClose = null;
                Modal.close();
                resolve(true);
            });
        });
    },

    /** Raccourci : affiche un simple message */
    alert(title, message) {
        this.open({
            title,
            body: `<p>${message}</p>`,
            footer: '<button class="btn btn-primary" onclick="Modal.close()">OK</button>',
        });
    },
};
