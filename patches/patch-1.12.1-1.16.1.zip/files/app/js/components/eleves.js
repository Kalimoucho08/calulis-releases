/**
 * Calulis — Composant Liste Élèves
 * Affiche la liste avec recherche, filtres, et actions.
 */
const ElevesList = {
    _eleves: [],
    _sort: { col: 'nom', dir: 'asc' },
    _classes: [],   // Toutes les classes disponibles (chargées depuis l'API)

    init() {
        // La vue #view-eleves doit avoir la structure HTML (voir index.html)
    },

    async render() {
        const view = document.getElementById('view-eleves');
        const isConsult = State.get('consultation');
        view.innerHTML = `
            <div class="toolbar" data-help="Liste des élèves|Filtres en haut : le premier select filtre par niveau (CP, CE1, CE2…), le deuxième par classe précise (ex: CE1 — Sophie Bernard). Les boutons ULIS/Non ULIS et Actifs/Inactifs affinent l\'affichage. La barre de recherche porte sur le nom et le prénom. Cliquez sur un en-tête de colonne pour trier.">
                <button class="btn btn-primary" id="btn-new-eleve">+ Nouvel élève</button>
                <input type="text" id="filter-search" class="topbar-search" placeholder="Rechercher un élève…" style="max-width:250px" aria-label="Rechercher un élève">
                <select id="filter-classe" style="width:auto;padding:6px 12px;font-size:13px" aria-label="Filtrer par niveau">
                    <option value="">Tous les niveaux</option>
                </select>
                <select id="filter-classe-id" style="width:auto;padding:6px 12px;font-size:13px" aria-label="Filtrer par classe">
                    <option value="">Toutes les classes</option>
                </select>
                <span class="toggle-group" id="toggle-ulis">
                    <button data-value="1">ULIS</button>
                    <button data-value="0">Non ULIS</button>
                </span>
                <span class="toggle-group" id="toggle-actif">
                    <button data-value="1">Actifs</button>
                    <button data-value="0">Inactifs</button>
                </span>
                <span class="toggle-group" id="toggle-contact">
                    <button data-value="1">📞 Avec contact</button>
                    <button data-value="0">📭 Sans contact</button>
                </span>
                <span class="toggle-group" id="toggle-documents">
                    <button data-value="1">📁 Avec documents</button>
                    <button data-value="0">📄 Sans document</button>
                </span>
                <button class="btn btn-sm btn-secondary" id="btn-csv-eleves" title="Exporter en CSV">📥 CSV</button>
                <span class="text-muted" id="eleve-count" style="margin-left:auto"></span>
            </div>
            <div class="card" style="flex:1;overflow:auto;padding:0" data-help="Fiche élève|La fiche élève a 6 onglets : Identité (coordonnées, transport, cantine), Scolarité (classe, date entrée ULIS, école d\'origine), AESH & PEC (accompagnants, prises en charge extérieures), MDPH & Plans (dates de droits, notifications), Médical (PAI, traitements), Représentants légaux (parents, contacts urgence). Clic sur Fiche = lecture seule. Clic sur Modifier = édition.">
                <table class="data-table" id="table-eleves">
                    <thead>
                        <tr>
                            <th data-sort="numero" class="sortable">N°</th>
                            <th data-sort="nom" class="sortable">Nom</th>
                            <th data-sort="prenom" class="sortable">Prénom</th>
                            <th data-sort="classe" class="sortable">Classe</th>
                            <th data-sort="ulis" class="sortable">ULIS</th>
                            <th data-sort="actif" class="sortable">Actif</th>
                            <th data-sort="age" class="sortable">Âge</th>
                            <th data-sort="annees_ulis" class="sortable">Années ULIS</th>
                            <th data-sort="nb_documents" class="sortable">Documents</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody id="tbody-eleves"><tr><td colspan="8" class="empty">Chargement…</td></tr></tbody>
                </table>
            </div>
        `;

        // Masquer le bouton nouvelle élève si consultation
        if (isConsult) {
            document.getElementById('btn-new-eleve').style.display = 'none';
        }
        // Events
        document.getElementById('btn-new-eleve').addEventListener('click', () => {
            if (State.get('consultation')) return;
            FicheEleve.open();
        });
        document.getElementById('filter-search').addEventListener('input', () => this._load());
        document.getElementById('filter-classe').addEventListener('change', () => this._load());
        document.getElementById('filter-classe-id').addEventListener('change', () => this._load());
        document.getElementById('btn-csv-eleves').addEventListener('click', () => this._exportCSV());
        // Toggle groups : un clic sélectionne, re-clic désélectionne
        // Tri par colonnes
        view.querySelectorAll('#table-eleves th.sortable').forEach(th => {
            th.addEventListener('click', () => {
                const col = th.dataset.sort;
                if (this._sort.col === col) this._sort.dir = this._sort.dir === 'asc' ? 'desc' : 'asc';
                else { this._sort.col = col; this._sort.dir = 'asc'; }
                this._renderTable();
            });
        });

        view.querySelectorAll('.toggle-group').forEach(group => {
            group.addEventListener('click', (e) => {
                const btn = e.target.closest('button');
                if (!btn) return;
                if (btn.classList.contains('active')) {
                    btn.classList.remove('active');
                } else {
                    group.querySelector('.active')?.classList.remove('active');
                    btn.classList.add('active');
                }
                this._load();
            });
        });

        // Charger les classes AVANT les élèves pour le filtre par niveau
        try { this._classes = await API.get('classes.php'); }
        catch (_) { this._classes = []; }
        await this._load();
    },

    async _load() {
        const q = document.getElementById('filter-search')?.value || '';
        const classe = document.getElementById('filter-classe')?.value || '';
        const classeId = document.getElementById('filter-classe-id')?.value || '';
        const ulisBtn = document.querySelector('#toggle-ulis .active');
        const ulis = ulisBtn ? (ulisBtn.dataset.value === '1') : null;
        const actifBtn = document.querySelector('#toggle-actif .active');
        const actif = actifBtn ? (actifBtn.dataset.value === '1') : null;
        const contactBtn = document.querySelector('#toggle-contact .active');
        const contactFilter = contactBtn ? (contactBtn.dataset.value === '1' ? 'avec' : 'sans') : '';
        const docBtn = document.querySelector('#toggle-documents .active');
        const docFilter = docBtn ? (docBtn.dataset.value === '1' ? 'avec' : 'sans') : '';
        const params = new URLSearchParams();
        if (q) params.set('q', q);
        if (classe) params.set('classe', classe);
        if (classeId) params.set('classe_id', classeId);
        if (ulis !== null) params.set('ulis', ulis ? '1' : '0');
        if (actif !== null) params.set('actif', actif ? '1' : '0');
        const qs = params.toString();
        try {
            this._eleves = await API.get('eleves.php' + (qs ? '?' + qs : ''));
            // Filtre contact côté client
            if (contactFilter === 'avec') {
                this._eleves = this._eleves.filter(e => e.telephone || e.email);
            } else if (contactFilter === 'sans') {
                this._eleves = this._eleves.filter(e => !e.telephone && !e.email);
            }
            // Filtre documents côté client : le compteur est déjà dans chaque élève
            // (une seule requête serveur), donc filtrer ici ne coûte rien de plus.
            if (docFilter === 'avec') {
                this._eleves = this._eleves.filter(e => (parseInt(e.nb_documents || 0, 10) || 0) > 0);
            } else if (docFilter === 'sans') {
                this._eleves = this._eleves.filter(e => !(parseInt(e.nb_documents || 0, 10) || 0));
            }
            this._renderTable();
            this._updateFilterClasses();
        } catch (e) {
            document.getElementById('tbody-eleves').innerHTML =
                `<tr><td colspan="10" class="empty" style="color:var(--danger)">Erreur : ${escapeHtml(e.message)}</td></tr>`;
        }
    },

    _sortData(data) {
        if (!this._sort.col) return data;
        const dir = this._sort.dir === 'asc' ? 1 : -1;
        return [...data].sort((a, b) => {
            const va = (a[this._sort.col] ?? '').toString().toLowerCase();
            const vb = (b[this._sort.col] ?? '').toString().toLowerCase();
            if (this._sort.col === 'actif' || this._sort.col === 'ulis') {
                return ((a[this._sort.col] ? 1 : 0) - (b[this._sort.col] ? 1 : 0)) * dir;
            }
            if (this._sort.col === 'age') {
                const aa = this._calcAge(a) ?? -1, ab = this._calcAge(b) ?? -1;
                return (aa - ab) * dir;
            }
            if (this._sort.col === 'annees_ulis') {
                const ua = this._calcMoisUlis(a) ?? -1, ub = this._calcMoisUlis(b) ?? -1;
                return (ua - ub) * dir;
            }
            if (this._sort.col === 'nb_documents') {
                return ((parseInt(a.nb_documents || 0, 10) || 0)
                      - (parseInt(b.nb_documents || 0, 10) || 0)) * dir;
            }
            if (this._sort.col === 'numero') {
                const na = parseInt(a.numero || '0', 10) || 0, nb = parseInt(b.numero || '0', 10) || 0;
                return (na - nb) * dir;
            }
            return va.localeCompare(vb) * dir;
        });
    },

    _renderTable() {
        const isConsult = State.get('consultation');
        const tbody = document.getElementById('tbody-eleves');
        document.getElementById('eleve-count').textContent = this._eleves.length + ' élève(s)';
        if (!this._eleves.length) {
            const hasFilter = document.getElementById('filter-search')?.value
                || document.getElementById('filter-classe')?.value
                || document.getElementById('filter-classe-id')?.value
                || document.querySelector('#toggle-ulis .active') || document.querySelector('#toggle-actif .active')
                || document.querySelector('#toggle-documents .active');
            const cta = (hasFilter || isConsult) ? ''
                : '<button class="btn btn-primary" onclick="FicheEleve.open()" style="margin-top:12px">+ Nouvel élève</button>';
            tbody.innerHTML = `<tr><td colspan="10" class="empty">${hasFilter ? 'Aucun résultat trouvé.' : 'Aucun élève enregistré.'}<br>${cta}</td></tr>`;
            return;
        }
        const sorted = this._sortData(this._eleves);
        tbody.innerHTML = sorted.map(e => `
            <tr>
                <td>${this._fmtNumero(e)}</td>
                <td>${escapeHtml(e.nom)}</td>
                <td>${escapeHtml(e.prenom)}</td>
                <td>${escapeHtml(e.classe)}</td>
                <td>${e.ulis ? '<span class="badge badge-ulis">ULIS</span>' : '—'}</td>
                <td>${e.actif ? '✅' : '<span class="badge badge-status-expired">Inactif</span>'}</td>
                <td class="center">${this._fmtAge(e)}</td>
                <td class="center">${this._fmtAnneesUlis(e)}</td>
                <td class="center">${this._fmtDocuments(e)}</td>
                <td>
                    ${isConsult ? '' : `<button class="btn-sm btn-edit" data-id="${e.id}">Modifier</button>
                    <button class="btn-sm btn-del" data-id="${e.id}">Supprimer</button>`}
                    <button class="btn-sm btn-view" data-id="${e.id}">Fiche</button>
                </td>
            </tr>
        `).join('');

        if (!isConsult) {
            tbody.querySelectorAll('.btn-edit').forEach(b => b.addEventListener('click', () => {
                const el = this._eleves.find(e => e.id === parseInt(b.dataset.id));
                if (el) FicheEleve.open(el);
            }));
            tbody.querySelectorAll('.btn-del').forEach(b => {
                b.addEventListener('click', () => this._delete(parseInt(b.dataset.id)));
            });
        }
        tbody.querySelectorAll('.btn-view').forEach(b => b.addEventListener('click', () => {
            const el = this._eleves.find(e => e.id === parseInt(b.dataset.id));
            if (el) FicheEleve.open(el, true);
        }));
        // Le nombre de documents ouvre la fiche SUR son onglet Documents : c'est là qu'on
        // veut aller quand on voit qu'un élève a un dossier.
        tbody.querySelectorAll('.btn-doc').forEach(b => b.addEventListener('click', () => {
            const el = this._eleves.find(e => e.id === parseInt(b.dataset.id));
            if (el) {
                FicheEleve.open(el, true);
                FicheEleve._switchTab('documents');
            }
        }));

        // Tri par colonnes — labels
        this._updateSortHeaders();
    },

    /**
     * Nombre de documents de l'élève. Rien à dire quand il n'y en a aucun (un tiret),
     * et un bouton quand il y en a : il ouvre la fiche sur l'onglet Documents.
     */
    _fmtDocuments(e) {
        const n = parseInt(e.nb_documents || 0, 10) || 0;
        if (!n) return '<span class="text-muted" title="Aucun document">—</span>';
        const mot = n > 1 ? 'documents' : 'document';
        return `<button type="button" class="btn-sm btn-doc" data-id="${e.id}"
                        title="${n} ${mot}" aria-label="${n} ${mot} : voir dans la fiche">📁 ${n}</button>`;
    },

    /** Calcule l'âge (nombre) à partir de la date de naissance */
    _calcAge(e) {
        if (!e.date_naissance) return null;
        const naissance = new Date(e.date_naissance);
        const aujourdhui = new Date();
        let age = aujourdhui.getFullYear() - naissance.getFullYear();
        const m = aujourdhui.getMonth() - naissance.getMonth();
        if (m < 0 || (m === 0 && aujourdhui.getDate() < naissance.getDate())) age--;
        return age;
    },
    _fmtAge(e) {
        const a = this._calcAge(e);
        return a !== null ? `${a} an${a > 1 ? 's' : ''}` : '—';
    },

    /** Calcule le nombre de MOIS passés dans le dispositif ULIS (depuis date_entree_ulis).
     *  Précis : « 1 an et 5 mois », « 0 mois » pour le 1er mois (gère les arrivées en cours d'année). */
    _calcMoisUlis(e) {
        if (!e.date_entree_ulis) return null;
        const entree = new Date(e.date_entree_ulis);
        const maintenant = new Date();
        let mois = (maintenant.getFullYear() - entree.getFullYear()) * 12 + (maintenant.getMonth() - entree.getMonth());
        if (maintenant.getDate() < entree.getDate()) mois--;
        return Math.max(0, mois);
    },
    _fmtAnneesUlis(e) {
        const mois = this._calcMoisUlis(e);
        if (mois === null) return '—';
        if (mois === 0) return '0 mois';
        const ans = Math.floor(mois / 12);
        const reste = mois % 12;
        const ansTxt = ans > 0 ? ans + ' an' + (ans > 1 ? 's' : '') : '';
        const moisTxt = reste > 0 ? reste + ' mois' : '';
        if (ansTxt && moisTxt) return ansTxt + ' et ' + moisTxt;
        return ansTxt || moisTxt;
    },
    _fmtNumero(e) {
        const n = e.numero;
        if (n === null || n === undefined || n === '') return '';
        const num = parseInt(n, 10);
        return isNaN(num) ? escapeHtml(String(n)) : String(num).padStart(2, '0');
    },

    _exportCSV() {
        const headers = ['numero', 'nom', 'prenom', 'classe', 'ulis', 'actif', 'age', 'annees_ulis', 'telephone', 'email'];
        const rows = this._eleves.map(e => ({
            ...e,
            ulis: e.ulis ? 'Oui' : 'Non',
            actif: e.actif ? 'Oui' : 'Non',
            age: this._fmtAge(e),
            annees_ulis: this._fmtAnneesUlis(e),
        }));
        exportCSV('eleves.csv', headers, rows);
    },

    _updateSortHeaders() {
        document.querySelectorAll('#table-eleves th.sortable').forEach(th => {
            if (!th.dataset.label) th.dataset.label = th.textContent;
            th.textContent = th.dataset.sort === this._sort.col
                ? th.dataset.label + (this._sort.dir === 'asc' ? ' ▲' : ' ▼')
                : th.dataset.label;
        });
    },

    _updateFilterClasses() {
        const selectNiveau = document.getElementById('filter-classe');
        const selectClasse = document.getElementById('filter-classe-id');
        const classes = this._classes || [];

        // Aide : label lisible ("6e+5e") + clé de tri pédagogique (via NIVEAUX_* de classes.js)
        const niveauxLabel = (n) => {
            try {
                const arr = typeof n === 'string' ? JSON.parse(n) : n;
                if (Array.isArray(arr)) return arr.map(x => NIVEAU_LABELS[x] || x).join('+');
            } catch {}
            return n || '';
        };
        const niveauxSortKey = (n) => {
            try {
                const arr = typeof n === 'string' ? JSON.parse(n) : (n || []);
                if (Array.isArray(arr) && arr.length) {
                    const idx = NIVEAUX_KEYS.indexOf(arr[0]);
                    if (idx !== -1) return idx;
                }
            } catch {}
            return NIVEAUX_KEYS.length;
        };

        // Select 1 : Niveaux (CP, CE1, 6e, 5e…) — triés par ordre pédagogique, labels lisibles
        if (selectNiveau) {
            const current = selectNiveau.value;
            const niveaux = [...new Set(classes.map(c => c.niveaux).filter(Boolean))]
                .sort((a, b) => niveauxSortKey(a) - niveauxSortKey(b) || a.localeCompare(b));
            selectNiveau.innerHTML = '<option value="">Tous les niveaux</option>' +
                niveaux.map(n => `<option value="${n}" ${n === current ? 'selected' : ''}>${escapeHtml(niveauxLabel(n))}</option>`).join('');
        }

        // Select 2 : Classes spécifiques (ex: "CE1 — Sophie Bernard") — tri pédagogique
        if (selectClasse) {
            const currentId = selectClasse.value;
            const sorted = [...classes].sort((a, b) =>
                niveauxSortKey(a.niveaux) - niveauxSortKey(b.niveaux) || (a.nom || '').localeCompare(b.nom || '')
            );
            selectClasse.innerHTML = '<option value="">Toutes les classes</option>' +
                sorted.map(c => {
                    const ens = (c.enseignants || []).map(a => ((a.prenom || '') + ' ' + (a.nom || '')).trim()).filter(Boolean);
                    const label = ens.length ? c.nom + ' — ' + ens.join(' · ') : c.nom;
                    return `<option value="${c.id}" ${String(c.id) === currentId ? 'selected' : ''}>${escapeHtml(label)}</option>`;
                }).join('');
        }
    },

    /**
     * Supprime un élève — mais JAMAIS sans dire ce qui part avec lui.
     *
     * Depuis le 08/10/2026, supprimer un élève efface aussi ses documents et leurs
     * fichiers (droit à l'effacement, promis par la page « Mentions RGPD »). Comme
     * un dossier peut être redemandé des années plus tard, l'écran propose d'abord
     * de l'EMPORTER : l'archive est fabriquée et téléchargée AVANT la suppression,
     * et si elle échoue, rien n'est supprimé.
     *
     * Trois garde-fous, dans cet ordre :
     *   1. on lit ce qu'il y a à perdre — si la lecture échoue, on ne supprime pas ;
     *   2. l'utilisateur choisit (archiver / supprimer sans archiver / annuler) ;
     *   3. l'archive doit être REÇUE (les octets en mémoire) avant qu'on supprime.
     */
    async _delete(id) {
        const el = this._eleves.find(e => e.id === id);
        if (!el) return;

        let docs;
        try {
            // Toutes les années : l'effacement porte sur le dossier complet.
            docs = await API.get('documents.php?eleve_id=' + id, { sansAnnee: true }) || [];
        } catch (e) {
            Modal.alert('Suppression impossible',
                `Les documents de ${el.prenom} ${el.nom} n'ont pas pu être lus (${e.message}). `
                + `Rien n'a été supprimé : recommencez quand l'application répond.`);
            return;
        }
        const nb = docs.length;
        const avecFichier = docs.filter(d => d.fichier_id).length;
        const octets = docs.reduce((total, d) => total + (parseInt(d.fichier_taille || 0, 10) || 0), 0);

        const choix = await this._demanderSort(el, nb, avecFichier, octets);
        if (choix === 'annuler') return;

        if (choix === 'archiver') {
            try {
                const archive = await API.blobAvecNom('documents_archive.php?eleve_id=' + id, { sansAnnee: true });
                telechargerBlob(archive.nom || 'documents.zip', archive.blob);
            } catch (e) {
                Modal.alert('Archive impossible',
                    `${e.message}\n\n${el.prenom} ${el.nom} n'a PAS été supprimé : `
                    + `son dossier n'a pas pu être emporté.`);
                return;
            }
        }

        try {
            const reponse = await API.del('eleves.php?id=' + id + '&documents=supprimer');
            await this._load();
            State.emit('eleves:changed');
            const restants = parseInt((reponse && reponse.fichiers_restants) || 0, 10) || 0;
            const dossierReste = !!(reponse && reponse.dossier_supprime === false);
            if (restants > 0 || dossierReste) {
                // On ne tait pas un effacement incomplet, et on ne promet pas un nettoyage
                // automatique qui n'existe pas : rien ne reviendra chercher ce reste.
                const causes = [];
                if (restants > 0) {
                    causes.push(`${restants} fichier(s) n'ont pas pu être effacés — ils sont probablement `
                        + `ouverts dans un autre programme (lecteur de PDF, traitement de texte)`);
                }
                if (dossierReste) {
                    causes.push(`son dossier n'a pas pu être entièrement effacé`);
                }
                Modal.alert('Effacement incomplet',
                    `${el.prenom} ${el.nom} et ses documents ont bien été supprimés de Calulis, mais `
                    + `${causes.join(', et ')}.\n\n`
                    + `Calulis ne reviendra pas le chercher : dans le dossier d'installation de Calulis, `
                    + `supprimez à la main le dossier « runtime\\documents\\eleve-${id} » `
                    + `(fermez d'abord le programme qui tient le fichier ouvert).`);
            } else {
                Toast.success('Élève supprimé');
            }
        } catch (e) {
            Modal.alert('Erreur', e.message);
        }
    },

    /**
     * Le choix, dit en clair : ce qui part, et la possibilité d'emporter le dossier.
     * Rend 'annuler' | 'archiver' | 'supprimer'.
     */
    _demanderSort(el, nb, avecFichier, octets) {
        const documents = nb === 0
            ? `<p>Cet élève n'a <strong>aucun document</strong> enregistré dans Calulis.</p>`
            : `<p>Cet élève a <strong>${nb} document${nb > 1 ? 's' : ''}</strong>`
                + (avecFichier > 0
                    ? `, dont <strong>${avecFichier}</strong> avec un fichier rapatrié (${formatOctets(octets)}).`
                    : ` (aucun fichier rapatrié : que des documents décrits).`);

        return new Promise(resolve => {
            Modal.open({
                title: `Supprimer ${el.prenom} ${el.nom}`,
                body: `
                    ${documents}
                    <p>Supprimer cet élève efface <strong>définitivement</strong> sa fiche, ses documents
                    et leurs fichiers. L'opération ne peut pas être annulée.</p>
                    ${nb > 0 ? `<p>Pour ne rien perdre, emportez d'abord son dossier : un fichier ZIP
                    contenant tous ses documents et un index lisible, que vous pourrez ranger ailleurs
                    ou transmettre.</p>` : ''}
                `,
                footer: `
                    <button class="btn btn-secondary" id="eleve-del-annuler">Annuler</button>
                    ${nb > 0 ? `<button class="btn btn-primary" id="eleve-del-archiver">Archiver puis supprimer</button>` : ''}
                    <button class="btn btn-danger" id="eleve-del-supprimer">${nb > 0 ? 'Supprimer sans archiver' : 'Supprimer'}</button>
                `,
                onClose: () => resolve('annuler'),
            });
            const finir = (valeur) => {
                Modal._onClose = null;
                Modal.close();
                resolve(valeur);
            };
            document.getElementById('eleve-del-annuler').addEventListener('click', () => finir('annuler'));
            const archiver = document.getElementById('eleve-del-archiver');
            if (archiver) archiver.addEventListener('click', () => finir('archiver'));
            document.getElementById('eleve-del-supprimer').addEventListener('click', () => finir('supprimer'));
        });
    },
};
