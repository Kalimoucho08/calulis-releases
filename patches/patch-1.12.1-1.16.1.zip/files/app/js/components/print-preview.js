/**
 * Calulis — Print Preview : aperçu canvas PDF.js, zoom, navigation
 * Attaché à l'objet Print via Object.assign
 */

Object.assign(Print, {

    /* ---- Aperçu canvas PDF.js ---- */

    async _showPreview(docDef, filename) {
        this._pendingDef = docDef;
        this._pendingFilename = filename;

        // La fenêtre d'aperçu est globale (index.html) : elle sert aussi au suivi et aux tâches.
        // Ses commandes doivent donc être branchées ICI et pas seulement au rendu de la page
        // Impression — sinon, ouvert depuis le suivi ou les tâches, « Fermer » ne répondait pas
        // et « Télécharger le PDF » restait inerte (trouvé par la revue du 04/10/2026).
        this._brancherApercu();
        const voile = document.getElementById('apercu-voile');
        if (voile) voile.classList.remove('cache');

        const area = document.getElementById('print-preview-area');
        const placeholder = document.getElementById('print-preview-placeholder');
        const label = document.getElementById('print-preview-label');
        const canvas = document.getElementById('print-preview-canvas');
        const dlBtn = document.getElementById('btn-print-download');
        const pageNav = document.getElementById('print-page-nav');
        const pageInfo = document.getElementById('print-page-info');

        label.textContent = 'Génération du PDF…';
        area.style.display = 'none';

        pdfMake.createPdf(docDef).getBlob(async (blob) => {
            try {
                const arrayBuffer = await blob.arrayBuffer();
                const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
                this._pdfDoc = pdf;
                this._currentPage = 1;
                this._zoom = 1;

                pageNav.style.display = pdf.numPages > 1 ? 'flex' : 'none';
                await this._renderPage(1, pdf, canvas, pageInfo);

                if (placeholder) placeholder.style.display = 'none';
                area.style.display = 'flex';
                label.textContent = 'Aperçu prêt — utilisez le zoom ou téléchargez le PDF.';
                dlBtn.disabled = false;
                // Ajuster APRÈS l'affichage : sur une zone encore masquée la largeur
                // mesurée vaut 0, et le zoom retombait sur son minimum (25 %). Corrigé le 04/10/2026.
                this._zoomFit();
            } catch (err) {
                label.textContent = 'Erreur lors du rendu de l\'aperçu.';
                console.error('[Print] PDF.js render error:', err);
            }
        });
    },

    /**
     * Branche les commandes de la fenêtre d'aperçu — UNE seule fois (garde idempotent).
     * Appelée à chaque ouverture : la fenêtre sert à plusieurs pages.
     */
    _brancherApercu() {
        if (this._apercuBranche) return;
        this._apercuBranche = true;
        document.getElementById('btn-print-download').addEventListener('click', () => {
            if (this._pendingDef && this._pendingFilename) this._download(this._pendingDef, this._pendingFilename);
        });
        document.getElementById('btn-prev-page').addEventListener('click', () => this._navigatePage(-1));
        document.getElementById('btn-next-page').addEventListener('click', () => this._navigatePage(1));
        document.getElementById('btn-zoom-in').addEventListener('click', () => this._zoomChange(0.25));
        document.getElementById('btn-zoom-out').addEventListener('click', () => this._zoomChange(-0.25));
        document.getElementById('btn-zoom-fit').addEventListener('click', () => this._zoomFit());
        document.getElementById('apercu-fermer').addEventListener('click', () => this._fermerApercu());
        document.addEventListener('keydown', (ev) => {
            const voile = document.getElementById('apercu-voile');
            if (ev.key === 'Escape' && voile && !voile.classList.contains('cache')) this._fermerApercu();
        });
    },

    /** Ferme la fenêtre d'aperçu (bouton ou touche Échap) */
    _fermerApercu() {
        const voile = document.getElementById('apercu-voile');
        if (voile) voile.classList.add('cache');
    },

    async _renderPage(pageNum, pdf, canvas, pageInfo) {
        try {
            const page = await pdf.getPage(pageNum);
            const dpr = window.devicePixelRatio || 1;
            const scale = (this._zoom * 1.5) / dpr;
            const viewport = page.getViewport({ scale });
            canvas.width = viewport.width * dpr;
            canvas.height = viewport.height * dpr;
            canvas.style.width = viewport.width + 'px';
            canvas.style.height = viewport.height + 'px';

            const ctx = canvas.getContext('2d');
            ctx.scale(dpr, dpr);
            ctx.clearRect(0, 0, viewport.width, viewport.height);

            await page.render({ canvasContext: ctx, viewport }).promise;
            if (pageInfo) pageInfo.textContent = `Page ${pageNum} / ${pdf.numPages}`;
        } catch (err) {
            console.error('[Print] page render error:', err);
        }
    },

    _navigatePage(delta) {
        if (!this._pdfDoc) return;
        const newPage = this._currentPage + delta;
        if (newPage < 1 || newPage > this._pdfDoc.numPages) return;
        this._currentPage = newPage;
        const canvas = document.getElementById('print-preview-canvas');
        const pageInfo = document.getElementById('print-page-info');
        this._renderPage(newPage, this._pdfDoc, canvas, pageInfo);
    },

    _download(docDef, filename) {
        if (typeof pdfMake === 'undefined') {
            Modal.alert('Erreur', 'pdfmake non chargé. Vérifiez votre connexion internet.');
            return;
        }
        pdfMake.createPdf(docDef).download(filename);
    },

    /* ---- Zoom preview ---- */

    _zoomChange(delta) {
        this._zoom = Math.max(0.25, Math.min(3, this._zoom + delta));
        this._updateZoomLabel();
        this._reRenderPreview();
    },

    _zoomFit() {
        if (!this._pdfDoc) return;
        const wrapper = document.querySelector('.print-canvas-wrapper');
        if (!wrapper) return;
        const w = wrapper.clientWidth * 0.75;
        const page = this._pdfDoc.getPage(1);
        page.then(p => {
            const vp = p.getViewport({ scale: 1 });
            this._zoom = Math.max(0.25, (w / vp.width));
            this._updateZoomLabel();
            this._reRenderPreview();
        });
    },

    _updateZoomLabel() {
        const lbl = document.getElementById('print-zoom-label');
        if (lbl) lbl.textContent = Math.round(this._zoom * 100) + '%';
    },

    _reRenderPreview() {
        if (!this._pdfDoc) return;
        this._currentPage = Math.min(this._currentPage, this._pdfDoc.numPages);
        const canvas = document.getElementById('print-preview-canvas');
        const pageInfo = document.getElementById('print-page-info');
        this._renderPage(this._currentPage, this._pdfDoc, canvas, pageInfo);
    },

});
