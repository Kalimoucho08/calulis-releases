/**
 * Calulis — Fiche élève : onglet Documents (module Documents, 1.16)
 *
 * POURQUOI CET ONGLET
 * Le plan du 01/09/2026 prévoyait l'« accès depuis la fiche élève » : on travaille un
 * élève dans sa fiche, pas dans une page à part. Sans cet onglet, il fallait quitter la
 * fiche, ouvrir Documents et filtrer soi-même — le plan disait l'inverse, et le modèle
 * portait déjà `Document::getByEleve()` pour ça.
 *
 * UNE SEULE IMPLÉMENTATION
 * L'aperçu, le téléchargement et le formulaire de dépôt viennent du composant
 * `Documents` (la page Documents). Ici, on ne fait que la LISTE des documents de
 * l'élève — pas une deuxième liste à maintenir.
 */
Object.assign(FicheEleve, {

    _buildDocumentsTab() {
        return `
        <div class="tab-panel" data-tab="documents" style="display:none" data-help="Documents|Les documents de cet élève, rapatriés dans Calulis : notification MDPH, PPS, GEVA-Sco, compte rendu d'ESS, PAI, document médical, courrier, bulletin… Déposez-en un sans quitter la fiche, ouvrez l'aperçu (rien à installer), et passez à la page Documents pour chercher ou filtrer autrement.">
            <div class="form-section">
                <div class="form-section-title" id="fiche-documents-titre">Documents de l'élève</div>
                <div id="fiche-documents-liste"><p class="text-muted">Chargement…</p></div>
                <div style="display:flex;gap:8px;margin-top:12px;flex-wrap:wrap">
                    <button type="button" class="btn btn-primary" id="fiche-doc-ajouter">＋ Déposer un document</button>
                    <button type="button" class="btn btn-secondary" id="fiche-doc-archiver">📦 Emporter le dossier (ZIP)</button>
                    <button type="button" class="btn btn-secondary" id="fiche-doc-page">Voir tous ses documents (recherche, filtres)</button>
                </div>
            </div>
        </div>`;
    },

    /** Charge et affiche les documents de l'élève ouvert dans la fiche. */
    async _loadDocuments() {
        const cible = document.getElementById('fiche-documents-liste');
        if (!cible || !this._eleve || !this._eleve.id) return;
        this._brancherDocuments();
        cible.innerHTML = '<p class="text-muted">Chargement…</p>';

        let docs = [];
        try {
            await Documents.assurerReferentiel();   // pour les libellés de type
            docs = await API.get('documents.php?eleve_id=' + this._eleve.id, { sansAnnee: true });
        } catch (e) {
            console.error('[FicheEleve] documents :', e);
            cible.innerHTML = '<p class="text-muted">Impossible de charger les documents de cet élève.</p>';
            return;
        }
        this._documents = Array.isArray(docs) ? docs : [];
        this._dessinerDocuments(this._documents);
    },

    _dessinerDocuments(docs) {
        const cible = document.getElementById('fiche-documents-liste');
        if (!cible) return;

        // Le nombre sur l'onglet : on voit qu'il y a un dossier sans l'ouvrir. Rien quand
        // il n'y en a aucun (un « (0) » ne dirait rien de plus que l'absence).
        const onglet = document.querySelector('#modal .tab[data-tab="documents"]');
        if (onglet) onglet.textContent = docs.length ? `Documents (${docs.length})` : 'Documents';
        // Et le total des fichiers, dans le titre de la section : c'est ce qui dit si le
        // dossier tient dans un courriel ou s'il faudra un support.
        const titre = document.getElementById('fiche-documents-titre');
        if (titre) {
            const octets = docs.reduce((n, d) => n + (parseInt(d.fichier_taille || 0, 10) || 0), 0);
            titre.textContent = octets
                ? `Documents de l'élève — ${docs.length} document${docs.length > 1 ? 's' : ''}, ${Documents._taille(octets)}`
                : "Documents de l'élève";
        }

        if (!docs.length) {
            cible.innerHTML = '<p class="text-muted">Aucun document pour cet élève. ' +
                'Le bouton ci-dessous en rapatrie un dans Calulis (il reste sur votre ordinateur).</p>';
            this._afficherBoutonArchive(false);
            return;
        }
        this._afficherBoutonArchive(true);

        const lignes = docs.map(d => {
            const aFichier = !!d.fichier_id;
            return `
            <tr>
                <td>${escapeHtml(Documents._libelleType(d.type))}</td>
                <td>
                    <strong>${escapeHtml(d.nom)}</strong>
                    ${d.notes ? `<div class="text-muted" style="font-size:12px">${escapeHtml(d.notes)}</div>` : ''}
                </td>
                <td>${escapeHtml(formatDate(d.date_document))}</td>
                <td>${aFichier
                    ? `${escapeHtml(d.fichier_nom || 'fichier')}
                       <div class="text-muted" style="font-size:12px">${escapeHtml(Documents._taille(d.fichier_taille))}</div>`
                    : '<span class="text-muted">aucun fichier</span>'}</td>
                <td style="white-space:nowrap">
                    ${aFichier ? `
                        <button type="button" class="btn btn-sm" data-action="apercu" data-id="${d.id}"
                                aria-label="Aperçu de ${escapeAttr(d.nom)}">👁 Aperçu</button>
                        <button type="button" class="btn btn-sm" data-action="telecharger" data-id="${d.id}"
                                aria-label="Télécharger ${escapeAttr(d.fichier_nom || d.nom)}">⬇</button>`
                    : '<span class="text-muted" style="font-size:12px">pas de copie numérique</span>'}
                    <button type="button" class="btn btn-sm" data-action="modifier" data-id="${d.id}"
                            aria-label="Modifier ${escapeAttr(d.nom)}">✏️</button>
                    <button type="button" class="btn btn-sm btn-danger" data-action="supprimer" data-id="${d.id}"
                            aria-label="Supprimer ${escapeAttr(d.nom)}">🗑</button>
                </td>
            </tr>`;
        }).join('');

        cible.innerHTML = `
            <table class="data-table">
                <caption class="sr-only">Documents rapatriés de cet élève</caption>
                <thead>
                    <tr>
                        <th scope="col">Type</th>
                        <th scope="col">Document</th>
                        <th scope="col">Date</th>
                        <th scope="col">Fichier</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>${lignes}</tbody>
            </table>`;
    },

    /**
     * Branche les commandes de l'onglet. Chaque élément porte sa marque : `Modal.open`
     * remplace le HTML à chaque ouverture de fiche, donc les écouteurs meurent avec lui,
     * et le marquage évite de les poser deux fois quand on revient sur l'onglet.
     */
    _brancherDocuments() {
        const ajouter = document.getElementById('fiche-doc-ajouter');
        if (ajouter && !ajouter.dataset.branche) {
            ajouter.dataset.branche = '1';
            ajouter.addEventListener('click', () => {
                // Le même formulaire que la page Documents, avec l'élève de la fiche
                // présélectionné, et un rechargement de la liste au retour.
                Documents._ouvrirFormulaire(null, this._eleve.id, () => this._loadDocuments())
                    .catch(e => console.error('[FicheEleve] dépôt de document :', e));
            });
        }

        const versPage = document.getElementById('fiche-doc-page');
        if (versPage && !versPage.dataset.branche) {
            versPage.dataset.branche = '1';
            versPage.addEventListener('click', () => {
                // On part sur la page Documents DÉJÀ filtrée sur cet élève.
                Documents._filtres.eleve_id = String(this._eleve.id);
                Modal.close();
                Router.go('documents');
            });
        }

        const archiver = document.getElementById('fiche-doc-archiver');
        if (archiver && !archiver.dataset.branche) {
            archiver.dataset.branche = '1';
            archiver.addEventListener('click', () => {
                this._emporterDossier().catch(e => console.error('[FicheEleve] archive :', e));
            });
        }

        const liste = document.getElementById('fiche-documents-liste');
        if (liste && !liste.dataset.branche) {
            liste.dataset.branche = '1';
            liste.addEventListener('click', (ev) => {
                const bouton = ev.target.closest('button[data-action]');
                if (!bouton) return;
                const doc = (this._documents || []).find(d => String(d.id) === bouton.dataset.id);
                if (!doc) return;
                if (bouton.dataset.action === 'apercu') Documents._ouvrirApercu(doc);
                if (bouton.dataset.action === 'telecharger') Documents._telecharger(doc);
                // Modifier et supprimer depuis la fiche : la fiche reste ouverte (ces
                // fenêtres sont propres au module Documents, pas la modale partagée).
                if (bouton.dataset.action === 'modifier') {
                    Documents._ouvrirFormulaire(doc, null, () => this._loadDocuments())
                        .catch(e => console.error('[FicheEleve] modification de document :', e));
                }
                if (bouton.dataset.action === 'supprimer') {
                    Documents._supprimer(doc).then(() => this._loadDocuments());
                }
            });
        }
    },

    /** Le bouton « Emporter le dossier » n'a de sens que s'il y a un dossier. */
    _afficherBoutonArchive(visible) {
        const bouton = document.getElementById('fiche-doc-archiver');
        if (bouton) bouton.style.display = visible ? '' : 'none';
    },

    /**
     * Emporte TOUT le dossier de l'élève dans un fichier ZIP.
     *
     * C'est exactement l'archive proposée avant une suppression (`documents_archive.php`) :
     * une seule implémentation, deux chemins. Utile pour transmettre un dossier complet à
     * un partenaire (collège, MDPH, famille) sans passer par le téléchargement, un par un,
     * de vingt documents.
     */
    async _emporterDossier() {
        const bouton = document.getElementById('fiche-doc-archiver');
        if (bouton) bouton.disabled = true;
        try {
            const archive = await API.blobAvecNom(
                'documents_archive.php?eleve_id=' + this._eleve.id, { sansAnnee: true });
            telechargerBlob(archive.nom || 'documents.zip', archive.blob);
            Toast.success('Le dossier part dans vos téléchargements');
        } catch (e) {
            Modal.alert('Archive impossible', e.message);
        } finally {
            if (bouton) bouton.disabled = false;
        }
    },
});
