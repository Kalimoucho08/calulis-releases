/**
 * Calulis — Recherche globale (barre du haut)
 *
 * Tapez un nom, un prénom, une classe, une ville : les résultats s'affichent **en direct**,
 * groupés par type, et ouvrent la fiche correspondante. Le champ existait déjà mais ne faisait
 * qu'envoyer vers l'annuaire après « Entrée » ; il cherche maintenant pendant la frappe
 * (demandé le 01/10/2026, reste de la phase 13).
 *
 * Les règles de correspondance sont celles de `Recherche` (utils/recherche.js), partagées avec
 * l'annuaire : un même terme donne les mêmes trouvailles des deux côtés.
 *
 * Clavier : ↓ / ↑ pour parcourir, Entrée pour ouvrir, Échap pour fermer (le champ garde le focus).
 */
const RechercheGlobale = {
    _donnees: null,
    _chargement: null,
    _resultats: [],
    _actif: -1,
    _ouvert: false,
    _jeton: 0,

    init() {
        const input = document.getElementById('global-search');
        if (!input) return;
        this._input = input;

        const panneau = document.createElement('div');
        panneau.className = 'recherche-panneau';
        panneau.id = 'recherche-panneau';
        panneau.setAttribute('role', 'listbox');
        panneau.setAttribute('aria-label', 'Résultats de la recherche');
        panneau.hidden = true;
        input.parentElement.appendChild(panneau);
        this._panneau = panneau;

        input.setAttribute('role', 'combobox');
        input.setAttribute('aria-expanded', 'false');
        input.setAttribute('aria-controls', 'recherche-panneau');
        input.setAttribute('autocomplete', 'off');

        input.addEventListener('focus', () => this._maj());
        input.addEventListener('input', () => { this._actif = -1; this._maj(); });
        input.addEventListener('keydown', (e) => this._touche(e));
        document.addEventListener('click', (e) => {
            if (!this._ouvert) return;
            if (e.target === this._input || this._panneau.contains(e.target)) return;
            this._fermer();
        });
    },

    /** Charge les listes UNE fois (élèves, adultes, établissements, classes). */
    async _charger() {
        if (this._donnees) return this._donnees;
        if (!this._chargement) {
            // Une liste indisponible ne doit pas vider la recherche : on garde les autres.
            this._chargement = Promise.all([
                API.get('eleves.php').catch(() => []),
                API.get('adultes.php').catch(() => []),
                API.get('etablissements.php').catch(() => []),
                API.get('classes.php').catch(() => []),
            ]).then(([eleves, adultes, etablissements, classes]) => {
                this._donnees = {
                    eleves: eleves || [],
                    adultes: adultes || [],
                    etablissements: etablissements || [],
                    classes: classes || [],
                };
                return this._donnees;
            });
        }
        return this._chargement;
    },

    async _maj() {
        const q = this._input.value.trim();
        if (q.length < 2) { this._fermer(); return; }

        const jeton = ++this._jeton;
        await this._charger();
        if (jeton !== this._jeton) return;   // une frappe plus récente a pris la main

        const d = this._donnees;
        const trouver = (liste, champs) => liste
            .filter(o => Recherche.correspond(champs(o), q))
            .slice(0, 5);

        this._resultats = [
            ...trouver(d.eleves, Recherche.champsEleve).map(o => this._ligne('eleve', o)),
            ...trouver(d.adultes, Recherche.champsAdulte).map(o => this._ligne('adulte', o)),
            ...trouver(d.etablissements, Recherche.champsEtablissement).map(o => this._ligne('etablissement', o)),
            ...trouver(d.classes, Recherche.champsClasse).map(o => this._ligne('classe', o)),
        ];
        this._afficher(q);
    },

    _ligne(type, objet) {
        const nom = (a, b) => `${a || ''} ${b || ''}`.trim();
        if (type === 'eleve') {
            return {
                type, objet, icone: '🎓',
                titre: nom(objet.prenom, objet.nom),
                detail: [objet.classe, objet.actif == 0 ? 'archivé' : ''].filter(Boolean).join(' · '),
            };
        }
        if (type === 'adulte') {
            return {
                type, objet, icone: '👩‍🏫',
                titre: nom(objet.prenom, objet.nom),
                detail: [libelleRole(objet.role), objet.actif == 0 ? 'archivé' : ''].filter(Boolean).join(' · '),
            };
        }
        if (type === 'etablissement') {
            return { type, objet, icone: '🏫', titre: objet.nom || 'Établissement', detail: objet.ville || '' };
        }
        return { type, objet, icone: '🏷️', titre: objet.nom || 'Classe', detail: 'Classe' };
    },

    _afficher(q) {
        const p = this._panneau;
        p.style.left = this._input.offsetLeft + 'px';
        p.style.width = Math.max(this._input.offsetWidth, 260) + 'px';

        if (!this._resultats.length) {
            p.innerHTML = `<div class="recherche-vide">Aucun résultat pour « ${escapeHtml(q)} »</div>` +
                this._aide();
        } else {
            const groupes = [
                ['eleve', 'Élèves'], ['adulte', 'Adultes'],
                ['etablissement', 'Établissements'], ['classe', 'Classes'],
            ];
            let i = 0;
            p.innerHTML = groupes.map(([type, titre]) => {
                const items = this._resultats.filter(r => r.type === type);
                if (!items.length) return '';
                return `<div class="recherche-groupe-titre">${titre}</div>` +
                    items.map(r => {
                        const idx = i++;
                        return `<div class="recherche-item" role="option" aria-selected="false" data-index="${idx}" id="recherche-item-${idx}">
                            <span class="recherche-icone" aria-hidden="true">${r.icone}</span>
                            <span class="recherche-titre">${escapeHtml(r.titre)}</span>
                            <span class="recherche-detail">${escapeHtml(r.detail)}</span>
                        </div>`;
                    }).join('');
            }).join('') + this._aide();

            p.querySelectorAll('.recherche-item').forEach(el => {
                el.addEventListener('click', () => this._ouvrir(this._resultats[+el.dataset.index]));
            });
        }
        p.hidden = false;
        this._ouvert = true;
        this._input.setAttribute('aria-expanded', 'true');
    },

    _aide() {
        return '<div class="recherche-aide">↓ ↑ pour parcourir · Entrée pour ouvrir · Échap pour fermer</div>';
    },

    _fermer() {
        this._panneau.hidden = true;
        this._ouvert = false;
        this._actif = -1;
        this._input.setAttribute('aria-expanded', 'false');
        this._input.removeAttribute('aria-activedescendant');
    },

    /** Met en avant le résultat n° i (clavier) sans perdre le focus du champ. */
    _surligner(i) {
        const items = [...this._panneau.querySelectorAll('.recherche-item')];
        if (!items.length) return;
        this._actif = (i + items.length) % items.length;
        items.forEach((el, k) => {
            const on = k === this._actif;
            el.classList.toggle('actif', on);
            el.setAttribute('aria-selected', on ? 'true' : 'false');
        });
        const actif = items[this._actif];
        actif.scrollIntoView({ block: 'nearest' });
        this._input.setAttribute('aria-activedescendant', actif.id);
    },

    _touche(e) {
        if (e.key === 'ArrowDown') {
            e.preventDefault();
            if (!this._ouvert) { this._maj(); return; }
            this._surligner(this._actif + 1);
        } else if (e.key === 'ArrowUp') {
            e.preventDefault();
            if (this._ouvert) this._surligner(this._actif - 1);
        } else if (e.key === 'Enter') {
            if (this._ouvert && this._resultats.length) {
                e.preventDefault();
                this._ouvrir(this._resultats[this._actif >= 0 ? this._actif : 0]);
            } else if (this._input.value.trim()) {
                // Aucun résultat en direct : on garde l'ancien comportement (l'annuaire).
                e.preventDefault();
                const q = this._input.value.trim();
                this._fermer();
                if (Router.current === 'annuaire') Annuaire.render({ search: q }).catch(() => {});
                else { State.set('global-search-term', q); Router.go('annuaire'); }
            }
        } else if (e.key === 'Escape') {
            if (this._ouvert) {
                e.preventDefault();
                e.stopPropagation();   // sinon le raccourci global retire le focus du champ
                this._fermer();
            }
        }
    },

    _ouvrir(r) {
        if (!r) return;
        this._fermer();
        this._input.blur();
        if (r.type === 'eleve' && typeof FicheEleve !== 'undefined') FicheEleve.open(r.objet, true);
        else if (r.type === 'adulte' && typeof FicheAdulte !== 'undefined') FicheAdulte.open(r.objet, true);
        else if (r.type === 'etablissement' && typeof FicheEtablissement !== 'undefined') FicheEtablissement.open(r.objet, true);
        else if (r.type === 'classe') this._ouvrirClasse(r.objet);
    },

    /**
     * Une classe n'a pas de « fiche » autonome : son formulaire a besoin des adultes et des
     * établissements chargés par la vue Classes. On va donc sur la vue, on attend (borné) que
     * ses données soient prêtes, puis on ouvre. Si elles ne viennent pas, on laisse simplement
     * l'utilisateur sur la liste — jamais d'écran vide ni d'erreur.
     */
    async _ouvrirClasse(classe) {
        if (Router.current !== 'classes') {
            Router.go('classes');
            const pret = await this._attendre(
                () => typeof ClassesView !== 'undefined' && (ClassesView._adultes || []).length > 0, 2500);
            if (!pret) return;
        }
        if (typeof ClassesView !== 'undefined') ClassesView._openFiche(classe);
    },

    /** Attente bornée d'une condition (pas de délai fixe, jamais d'attente infinie). */
    _attendre(predicat, ms) {
        return new Promise((res) => {
            const debut = performance.now();
            const tic = () => {
                let ok = false;
                try { ok = !!predicat(); } catch { ok = false; }
                if (ok || performance.now() - debut > ms) res(ok);
                else setTimeout(tic, 80);
            };
            tic();
        });
    },
};
