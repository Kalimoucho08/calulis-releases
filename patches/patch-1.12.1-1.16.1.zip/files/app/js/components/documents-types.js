/**
 * Calulis — Éditeur de TYPES DE DOCUMENTS (module Documents, 1.16)
 *
 * POURQUOI
 * Les types vivaient dans une constante PHP : impossible d'en ajouter un qui vient de
 * paraître, de renommer un document institutionnel, ni d'adapter la liste à son
 * établissement. Or un coordinateur de primaire, de collège et de lycée n'a pas les mêmes
 * documents. Demande de Jérôme (08/10/2026) : « un éditeur de types de documents — renommer,
 * supprimer, activer, désactiver, ajouter ».
 *
 * CE QUE L'ÉCRAN NE LAISSE PAS FAIRE, ET POURQUOI
 * - **Renommer** un type ne touche à aucun document : un document enregistre la CLÉ du type
 *   (`notification_mdph`), jamais son libellé. Le nouveau nom s'affiche donc partout, y
 *   compris sur les documents classés depuis des années. La clé, elle, ne se modifie jamais.
 * - **Supprimer** un type encore utilisé est REFUSÉ, en disant combien de documents le
 *   portent, et en proposant de les **réaffecter** à un autre type (décision de Jérôme).
 *   L'écran ne supprime jamais « quand même » : les documents deviendraient illisibles.
 * - **Désactiver** est la sortie douce : le type n'est plus proposé à la saisie, mais les
 *   documents déjà classés gardent leur libellé.
 *
 * Greffé sur le composant `Documents` (comme les onglets de la fiche élève).
 */
Object.assign(Documents, {

    /** Ouvre l'éditeur. Rend une promesse résolue quand la fenêtre est prête. */
    async ouvrirEditeurTypes() {
        this._fermerEditeurTypes();
        const voile = document.createElement('div');
        voile.id = 'doc-types-voile';
        voile.className = 'modal-backdrop';
        voile.innerHTML = `
            <div class="modal" role="dialog" aria-modal="true" aria-label="Types de documents">
                <div class="modal-header">
                    <h3>Types de documents</h3>
                    <button type="button" class="modal-close" id="doc-types-fermer" style="min-width:24px;min-height:24px" aria-label="Fermer">✕</button>
                </div>
                <div class="modal-body" style="min-height:0">
                    <p class="text-muted" style="margin-top:0">
                        Cette liste est propre à votre établissement. Renommer un type change son nom
                        <strong>partout</strong>, y compris sur les documents déjà classés — aucun document
                        n'est modifié. Désactiver un type le retire du formulaire de dépôt sans le rendre
                        illisible. Un type encore utilisé ne peut pas être supprimé : réaffectez d'abord ses
                        documents.
                    </p>
                    <div id="doc-types-corps"><p class="text-muted">Chargement…</p></div>
                    <div class="form-row" style="margin-top:12px;align-items:flex-end">
                        <div class="form-group" style="flex:1">
                            <label for="doc-type-nouveau">Ajouter un type</label>
                            <input type="text" id="doc-type-nouveau" placeholder="Ex. : Compte rendu de stage"
                                   maxlength="120">
                        </div>
                        <div class="form-group" style="flex:none">
                            <button type="button" class="btn btn-primary" id="doc-type-ajouter">＋ Ajouter</button>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="doc-types-fini">Fermer</button>
                </div>
            </div>`;
        document.body.appendChild(voile);
        this._voileTypes = voile;

        // Comme l'aperçu et le formulaire : Échap ferme CETTE fenêtre, et laisse la page —
        // ou la fiche élève — intacte en dessous.
        this._toucheTypes = (ev) => {
            if (ev.key === 'Escape') {
                ev.stopPropagation();
                ev.preventDefault();
                this._fermerEditeurTypes();
            }
        };
        document.addEventListener('keydown', this._toucheTypes, true);

        const fermer = () => this._fermerEditeurTypes();
        document.getElementById('doc-types-fermer').addEventListener('click', fermer);
        document.getElementById('doc-types-fini').addEventListener('click', fermer);
        document.getElementById('doc-type-ajouter').addEventListener('click', () => {
            this._ajouterType().catch(e => console.error('[Documents] ajout de type :', e));
        });
        document.getElementById('doc-type-nouveau').addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter') { ev.preventDefault(); this._ajouterType().catch(() => {}); }
        });
        document.getElementById('doc-types-corps').addEventListener('click', (ev) => {
            const bouton = ev.target.closest('button[data-action]');
            if (!bouton) return;
            const id = parseInt(bouton.dataset.id, 10);
            if (bouton.dataset.action === 'enregistrer') {
                this._enregistrerType(id).catch(e => console.error('[Documents] renommage :', e));
            }
            if (bouton.dataset.action === 'basculer') {
                this._basculerType(id).catch(e => console.error('[Documents] activation :', e));
            }
            if (bouton.dataset.action === 'supprimer') {
                this._supprimerType(id).catch(e => console.error('[Documents] suppression de type :', e));
            }
        });

        await this._chargerTypes();
    },

    async _chargerTypes() {
        const corps = document.getElementById('doc-types-corps');
        if (!corps) return;
        let types = [];
        try {
            types = await API.get('types_documents.php');
        } catch (e) {
            console.error('[Documents] types :', e);
            corps.innerHTML = '<p class="text-muted">Impossible de charger les types de documents.</p>';
            return;
        }
        this._types = Array.isArray(types) ? types : [];
        this._dessinerTypes();
    },

    _dessinerTypes() {
        const corps = document.getElementById('doc-types-corps');
        if (!corps) return;
        const types = this._types || [];
        if (!types.length) {
            corps.innerHTML = '<p class="text-muted">Aucun type : ajoutez-en un ci-dessous.</p>';
            return;
        }
        const lignes = types.map(t => {
            const n = parseInt(t.nb_documents || 0, 10) || 0;
            return `
            <tr data-id="${t.id}" class="${t.actif ? '' : 'doc-type-inactif'}">
                <td>
                    <label class="sr-only" for="doc-type-libelle-${t.id}">Nom du type</label>
                    <input type="text" id="doc-type-libelle-${t.id}" class="doc-type-libelle"
                           data-id="${t.id}" value="${escapeAttr(t.libelle)}" maxlength="120">
                </td>
                <td class="center text-muted" style="font-size:12px">${n
                    ? `${n} document${n > 1 ? 's' : ''}`
                    : '—'}</td>
                <td class="center">${t.actif
                    ? '<span class="badge">actif</span>'
                    : '<span class="badge badge-status-expired">désactivé</span>'}</td>
                <td style="white-space:nowrap">
                    <button type="button" class="btn btn-sm" data-action="enregistrer" data-id="${t.id}"
                            title="Enregistrer le nouveau nom">💾</button>
                    <button type="button" class="btn btn-sm" data-action="basculer" data-id="${t.id}"
                            title="${t.actif ? 'Ne plus proposer ce type' : 'Reproposer ce type'}">${t.actif ? '🚫' : '✅'}</button>
                    <button type="button" class="btn btn-sm btn-danger" data-action="supprimer" data-id="${t.id}"
                            title="Supprimer ce type">🗑</button>
                </td>
            </tr>`;
        }).join('');

        corps.innerHTML = `
            <table class="data-table">
                <caption class="sr-only">Types de documents de cet établissement</caption>
                <thead>
                    <tr>
                        <th scope="col">Nom du type</th>
                        <th scope="col">Utilisé par</th>
                        <th scope="col">État</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>${lignes}</tbody>
            </table>`;
    },

    async _ajouterType() {
        const champ = document.getElementById('doc-type-nouveau');
        const libelle = (champ ? champ.value : '').trim();
        if (!libelle) {
            Toast.info('Donnez un nom au type de document.');
            if (champ) champ.focus();
            return;
        }
        try {
            await API.post('types_documents.php', { libelle });
        } catch (e) {
            Toast.error(e.message || 'Ajout impossible.');
            return;
        }
        if (champ) champ.value = '';
        Toast.success(`Type « ${libelle} » ajouté.`);
        await this._chargerTypes();
        await this.assurerReferentiel(true);   // le formulaire de dépôt doit le proposer
    },

    async _enregistrerType(id) {
        const champ = document.getElementById('doc-type-libelle-' + id);
        const libelle = (champ ? champ.value : '').trim();
        if (!libelle) {
            Toast.info('Le nom du type est obligatoire.');
            return;
        }
        try {
            await API.put('types_documents.php?id=' + id, { libelle });
        } catch (e) {
            Toast.error(e.message || 'Enregistrement impossible.');
            return;
        }
        Toast.success('Type renommé. Les documents déjà classés suivent.');
        await this._chargerTypes();
        await this.assurerReferentiel(true);
    },

    async _basculerType(id) {
        const type = (this._types || []).find(t => parseInt(t.id, 10) === id);
        if (!type) return;
        const actif = parseInt(type.actif, 10) ? 0 : 1;
        try {
            await API.put('types_documents.php?id=' + id, { actif });
        } catch (e) {
            Toast.error(e.message || 'Modification impossible.');
            return;
        }
        Toast.success(actif ? 'Type réactivé.' : 'Type désactivé : plus proposé, toujours lisible.');
        await this._chargerTypes();
        await this.assurerReferentiel(true);
    },

    /**
     * Supprimer. Si des documents portent ce type, on EXPLIQUE combien, on REFUSE la
     * suppression simple, et on propose la réaffectation vers un autre type — c'est
     * exactement la décision de Jérôme du 08/10/2026.
     */
    async _supprimerType(id) {
        const type = (this._types || []).find(t => parseInt(t.id, 10) === id);
        if (!type) return;
        const n = parseInt(type.nb_documents || 0, 10) || 0;
        const autres = (this._types || []).filter(t => parseInt(t.id, 10) !== id);
        const options = autres.map(t =>
            `<option value="${escapeAttr(t.cle)}">${escapeHtml(t.libelle)}</option>`).join('');

        if (n > 0) {
            const cible = await this._confirmer(
                'Supprimer ce type de document',
                `<p>« <strong>${escapeHtml(type.libelle)}</strong> » est utilisé par
                    <strong>${n} document${n > 1 ? 's' : ''}</strong> : il ne peut pas être supprimé tel quel.</p>
                 <p>Réaffectez ces documents à un autre type, puis le type sera supprimé. Vous pouvez aussi
                    simplement le <strong>désactiver</strong> : il ne sera plus proposé, et les documents
                    déjà classés resteront lisibles.</p>
                 <div class="form-group">
                    <label for="doc-type-reaffecter">Réaffecter ses documents à</label>
                    <select id="doc-type-reaffecter">${options || '<option value="">Aucun autre type</option>'}</select>
                 </div>`,
                'Réaffecter puis supprimer',
                'doc-type-reaffecter'
            );
            if (!cible) return;
            try {
                const r = await API.post(
                    'types_documents.php?id=' + id + '&reaffecter=' + encodeURIComponent(cible), {});
                Toast.success(`${(r && r.documents_reaffectes) || n} document(s) réaffecté(s), type supprimé.`);
            } catch (e) {
                Toast.error(e.message || 'Réaffectation impossible.');
                return;
            }
        } else {
            const ok = await this._confirmer(
                'Supprimer ce type de document',
                `<p>Supprimer « <strong>${escapeHtml(type.libelle)}</strong> » ? Aucun document ne l'utilise.</p>`,
                'Supprimer'
            );
            if (!ok) return;
            try {
                await API.del('types_documents.php?id=' + id);
            } catch (e) {
                Toast.error(e.message || 'Suppression impossible.');
                return;
            }
            Toast.success('Type supprimé.');
        }
        await this._chargerTypes();
        await this.assurerReferentiel(true);
    },

    _fermerEditeurTypes() {
        if (this._toucheTypes) {
            document.removeEventListener('keydown', this._toucheTypes, true);
            this._toucheTypes = null;
        }
        if (this._voileTypes) {
            this._voileTypes.remove();
            this._voileTypes = null;
        }
    },
});
