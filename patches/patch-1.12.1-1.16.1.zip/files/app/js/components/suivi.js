/**
 * Calulis — Suivi des élèves
 *
 * Une note de suivi = un élève, une date, un type et un texte libre.
 * Le suivi ne concerne QUE des élèves (pas de note générale, pas d'auteur : monoposte).
 *
 * L'impression passe par l'aperçu PDF global (Print._showPreview), partagé avec
 * la page Impression : sélection par filtres, par cases cochées, ou tout.
 */
const Suivi = {

    /** Types de note — même liste que NoteSuivi::TYPES côté serveur */
    _types: [
        { cle: 'observation', libelle: 'Observation', classe: 't-observation' },
        { cle: 'objectif',    libelle: 'Objectif',    classe: 't-objectif' },
        { cle: 'reussite',    libelle: 'Réussite',    classe: 't-reussite' },
        { cle: 'alerte',      libelle: 'Alerte',      classe: 't-alerte' },
        { cle: 'action',      libelle: 'Action',      classe: 't-action' },
    ],

    _notes: [],
    _eleves: [],
    _filtres: { eleve_id: '', type: '', du: '', au: '', texte: '' },
    _coches: new Set(),

    async render() {
        const view = document.getElementById('view-suivi');
        view.innerHTML = '<p class="text-muted" style="padding:24px">Chargement du suivi…</p>';

        try {
            const [notes, eleves] = await Promise.all([
                API.get('notes_suivi.php'),
                API.get('eleves.php'),
            ]);
            this._notes = Array.isArray(notes) ? notes : [];
            this._eleves = (Array.isArray(eleves) ? eleves : [])
                .slice()
                .sort((a, b) => `${a.nom} ${a.prenom}`.localeCompare(`${b.nom} ${b.prenom}`, 'fr'));
        } catch (e) {
            console.error('[Suivi] chargement impossible:', e);
            view.innerHTML = '<p class="text-muted" style="padding:24px">Impossible de charger le suivi. ' +
                'Vérifiez que la base est démarrée.</p>';
            return;
        }

        this._coches = new Set();
        this._dessiner();
    },

    /* ------------------------------------------------------------------ */
    /* Affichage                                                           */
    /* ------------------------------------------------------------------ */

    _filtrees() {
        const f = this._filtres;
        const mot = (f.texte || '').trim().toLowerCase();
        return this._notes.filter(n => {
            if (f.eleve_id && String(n.eleve_id) !== String(f.eleve_id)) return false;
            if (f.type && n.type !== f.type) return false;
            if (f.du && n.date_note < f.du) return false;
            if (f.au && n.date_note > f.au) return false;
            if (mot) {
                const dansTexte = (n.contenu || '').toLowerCase().includes(mot);
                const dansNom = this._nomEleve(n).toLowerCase().includes(mot);
                if (!dansTexte && !dansNom) return false;
            }
            return true;
        }).sort((a, b) => (b.date_note || '').localeCompare(a.date_note || '') || (b.id - a.id));
    },

    _nomEleve(n) {
        const complet = `${n.eleve_prenom || ''} ${n.eleve_nom || ''}`.trim();
        return complet || 'Élève inconnu';
    },

    _libelleType(cle) {
        const t = this._types.find(x => x.cle === cle);
        return t ? t.libelle : cle;
    },

    _dateFr(iso) {
        if (!iso) return '';
        try {
            return new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })
                .format(new Date(iso + 'T00:00:00'));
        } catch { return iso; }
    },

    _dessiner() {
        const view = document.getElementById('view-suivi');
        const liste = this._filtrees();

        const optionsEleves = this._eleves.map(e =>
            `<option value="${e.id}"${String(this._filtres.eleve_id) === String(e.id) ? ' selected' : ''}>` +
            `${escapeHtml((e.prenom || '') + ' ' + (e.nom || ''))}</option>`).join('');

        const optionsTypes = this._types.map(t =>
            `<option value="${t.cle}"${this._filtres.type === t.cle ? ' selected' : ''}>${t.libelle}</option>`).join('');

        const lignes = liste.map(n => {
            const type = this._types.find(x => x.cle === n.type) || this._types[0];
            const cochee = this._coches.has(n.id);
            return `
            <article class="suivi-note t-bord-${escapeAttr(n.type)}${cochee ? ' cochee' : ''}" data-id="${n.id}">
                <div class="suivi-choix">
                    <input type="checkbox" data-coche="${n.id}" ${cochee ? 'checked' : ''}
                           aria-label="Sélectionner la note du ${escapeAttr(this._dateFr(n.date_note))} pour ${escapeAttr(this._nomEleve(n))}">
                </div>
                <div class="suivi-corps">
                    <div class="suivi-tete">
                        <span class="suivi-eleve">${escapeHtml(this._nomEleve(n))}</span>
                        <span class="suivi-date">${escapeHtml(this._dateFr(n.date_note))}</span>
                        <span class="suivi-type ${type.classe}">${type.libelle}</span>
                    </div>
                    <p class="suivi-texte">${escapeHtml(n.contenu)}</p>
                </div>
                <div class="suivi-actions">
                    <button class="btn btn-sm" data-modifier="${n.id}">Modifier</button>
                    <button class="btn btn-sm" data-supprimer="${n.id}" aria-label="Supprimer cette note">🗑</button>
                </div>
            </article>`;
        }).join('');

        view.innerHTML = `
        <div class="suivi-entete">
            <h2 style="margin:0">Suivi des élèves</h2>
            <button class="btn btn-primary" id="suivi-nouvelle">+ Nouvelle note</button>
        </div>

        <div class="card" style="margin:12px 0;display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
            <div class="form-group" style="margin:0">
                <label for="suivi-f-eleve">Élève</label>
                <select id="suivi-f-eleve"><option value="">Tous les élèves</option>${optionsEleves}</select>
            </div>
            <div class="form-group" style="margin:0">
                <label for="suivi-f-type">Type</label>
                <select id="suivi-f-type"><option value="">Tous les types</option>${optionsTypes}</select>
            </div>
            <div class="form-group" style="margin:0">
                <label for="suivi-f-du">Du</label>
                <input type="date" id="suivi-f-du" value="${this._filtres.du}">
            </div>
            <div class="form-group" style="margin:0">
                <label for="suivi-f-au">Au</label>
                <input type="date" id="suivi-f-au" value="${this._filtres.au}">
            </div>
            <div class="form-group" style="margin:0;flex:1;min-width:180px">
                <label for="suivi-f-texte">Dans le texte</label>
                <input type="search" id="suivi-f-texte" placeholder="un mot…" value="${escapeAttr(this._filtres.texte)}">
            </div>
            <button class="btn btn-secondary" id="suivi-reinit">Réinitialiser</button>
        </div>

        <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap;margin-bottom:8px">
            <span class="text-muted"><strong>${liste.length}</strong> note(s) affichée(s)</span>
            <span class="text-muted">·</span>
            <span class="text-muted"><strong id="suivi-n-coches">${this._coches.size}</strong> cochée(s)</span>
            <button class="btn btn-sm" id="suivi-tout">Tout cocher</button>
            <button class="btn btn-sm" id="suivi-rien">Tout décocher</button>
        </div>

        <div class="card" style="margin-bottom:14px;display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
            <div class="form-group" style="margin:0">
                <label for="suivi-i-quoi">Quoi imprimer</label>
                <select id="suivi-i-quoi">
                    <option value="filtre">Ce qui est affiché (filtres)</option>
                    <option value="coche">La sélection cochée</option>
                    <option value="tout">Toutes les notes de l'année</option>
                </select>
            </div>
            <div class="form-group" style="margin:0">
                <label for="suivi-i-groupe">Présentation</label>
                <select id="suivi-i-groupe">
                    <option value="eleve">Regroupées par élève</option>
                    <option value="date">Dans l'ordre des dates</option>
                </select>
            </div>
            <div class="form-group" style="margin:0">
                <label for="suivi-i-opt">Contenu</label>
                <select id="suivi-i-opt">
                    <option value="complet">Texte complet des notes</option>
                    <option value="court">Liste courte — SANS le texte des notes</option>
                </select>
            </div>
            <button class="btn btn-secondary" id="suivi-apercu">Aperçu</button>
            <button class="btn btn-primary" id="suivi-imprimer">🖨️ Imprimer / PDF</button>
        </div>

        <div class="suivi-liste" id="suivi-liste">
            ${lignes || '<p class="text-muted" style="padding:16px">Aucune note ne correspond à ces critères.</p>'}
        </div>`;

        this._brancher();
    },

    _brancher() {
        const view = document.getElementById('view-suivi');
        const relire = () => {
            this._filtres.eleve_id = view.querySelector('#suivi-f-eleve').value;
            this._filtres.type = view.querySelector('#suivi-f-type').value;
            this._filtres.du = view.querySelector('#suivi-f-du').value;
            this._filtres.au = view.querySelector('#suivi-f-au').value;
            this._filtres.texte = view.querySelector('#suivi-f-texte').value;
            this._dessiner();
        };
        ['#suivi-f-eleve', '#suivi-f-type', '#suivi-f-du', '#suivi-f-au'].forEach(sel =>
            view.querySelector(sel).addEventListener('change', relire));
        view.querySelector('#suivi-f-texte').addEventListener('input', () => {
            clearTimeout(this._minuteur);
            this._minuteur = setTimeout(relire, 200);
        });
        view.querySelector('#suivi-reinit').addEventListener('click', () => {
            this._filtres = { eleve_id: '', type: '', du: '', au: '', texte: '' };
            this._dessiner();
        });

        view.querySelector('#suivi-tout').addEventListener('click', () => {
            this._filtrees().forEach(n => this._coches.add(n.id));
            this._dessiner();
        });
        view.querySelector('#suivi-rien').addEventListener('click', () => {
            this._coches.clear();
            this._dessiner();
        });

        view.querySelectorAll('[data-coche]').forEach(cb => {
            cb.addEventListener('change', () => {
                const id = Number(cb.dataset.coche);
                if (cb.checked) this._coches.add(id); else this._coches.delete(id);
                const compteur = document.getElementById('suivi-n-coches');
                if (compteur) compteur.textContent = this._coches.size;
                const carte = cb.closest('.suivi-note');
                if (carte) carte.classList.toggle('cochee', cb.checked);
            });
        });

        view.querySelectorAll('[data-modifier]').forEach(b =>
            b.addEventListener('click', () => this._ouvrirNote(Number(b.dataset.modifier))));
        view.querySelectorAll('[data-supprimer]').forEach(b =>
            b.addEventListener('click', () => this._supprimer(Number(b.dataset.supprimer))));

        view.querySelector('#suivi-nouvelle').addEventListener('click', () => this._ouvrirNote(null));
        view.querySelector('#suivi-apercu').addEventListener('click', () => this._imprimer(true));
        view.querySelector('#suivi-imprimer').addEventListener('click', () => this._imprimer(false));
    },

    /* ------------------------------------------------------------------ */
    /* Création / modification / suppression                               */
    /* ------------------------------------------------------------------ */

    _ouvrirNote(id) {
        const note = id ? this._notes.find(n => n.id === id) : null;
        const optionsEleves = this._eleves.map(e =>
            `<option value="${e.id}"${note && String(note.eleve_id) === String(e.id) ? ' selected' : ''}>` +
            `${escapeHtml((e.prenom || '') + ' ' + (e.nom || ''))}</option>`).join('');
        const optionsTypes = this._types.map(t =>
            `<option value="${t.cle}"${note && note.type === t.cle ? ' selected' : ''}>${t.libelle}</option>`).join('');
        const aujourdhui = new Date().toISOString().slice(0, 10);

        Modal.open({
            title: note ? 'Modifier la note' : 'Nouvelle note de suivi',
            body: `
                <div class="form-row">
                    <div class="form-group">
                        <label for="note-eleve">Élève</label>
                        <select id="note-eleve">${optionsEleves}</select>
                    </div>
                    <div class="form-group">
                        <label for="note-date">Date</label>
                        <input type="date" id="note-date" value="${note ? note.date_note : aujourdhui}">
                    </div>
                </div>
                <div class="form-group">
                    <label for="note-type">Type</label>
                    <select id="note-type">${optionsTypes}</select>
                </div>
                <div class="form-group">
                    <label for="note-contenu">Note</label>
                    <textarea id="note-contenu" rows="7" placeholder="Ce que vous avez observé, décidé, réussi…">${note ? escapeHtml(note.contenu) : ''}</textarea>
                </div>`,
            footer: `
                <button class="btn btn-secondary" id="note-annuler">Annuler</button>
                <button class="btn btn-primary" id="note-enregistrer">Enregistrer</button>`,
        });

        document.getElementById('note-annuler').addEventListener('click', () => Modal.close());
        // Modal.open place le focus sur le premier contrôle de la fenêtre (le bouton « fermer »)
        // après 100 ms : on reprend le focus sur le texte juste après.
        setTimeout(() => {
            const zone = document.getElementById('note-contenu');
            if (zone) zone.focus();
        }, 160);
        document.getElementById('note-enregistrer').addEventListener('click', async () => {
            const donnees = {
                eleve_id: Number(document.getElementById('note-eleve').value),
                date_note: document.getElementById('note-date').value,
                type: document.getElementById('note-type').value,
                contenu: document.getElementById('note-contenu').value.trim(),
            };
            if (!donnees.contenu) {
                Toast.show('La note est vide.', 'error');
                return;
            }
            try {
                if (note) {
                    await API.put(`notes_suivi.php?id=${note.id}`, donnees);
                } else {
                    await API.post('notes_suivi.php', donnees);
                }
                Modal.close();
                Toast.show(note ? 'Note modifiée.' : 'Note ajoutée.', 'success');
                await this._recharger();
            } catch (e) {
                console.error('[Suivi] enregistrement impossible:', e);
                Toast.show('Enregistrement impossible : ' + (e.message || 'erreur inconnue'), 'error');
            }
        });
    },

    async _supprimer(id) {
        const note = this._notes.find(n => n.id === id);
        if (!note) return;
        const ok = await Modal.confirm('Supprimer la note',
            `Supprimer définitivement la note du ${this._dateFr(note.date_note)} pour ${this._nomEleve(note)} ?`);
        if (!ok) return;
        try {
            await API.del(`notes_suivi.php?id=${id}`);
            this._coches.delete(id);
            Toast.show('Note supprimée.', 'success');
            await this._recharger();
        } catch (e) {
            console.error('[Suivi] suppression impossible:', e);
            Toast.show('Suppression impossible.', 'error');
        }
    },

    /** Recharge les notes sans reconstruire toute la page (filtres conservés) */
    async _recharger() {
        const notes = await API.get('notes_suivi.php');
        this._notes = Array.isArray(notes) ? notes : [];
        this._dessiner();
    },

    /* ------------------------------------------------------------------ */
    /* Impression                                                          */
    /* ------------------------------------------------------------------ */

    _selectionPourImpression() {
        const quoi = document.getElementById('suivi-i-quoi').value;
        if (quoi === 'tout') return this._notes.slice();
        if (quoi === 'coche') return this._notes.filter(n => this._coches.has(n.id));
        return this._filtrees();
    },

    _sousTitre(selection) {
        const f = this._filtres;
        const quoi = document.getElementById('suivi-i-quoi').value;
        const bouts = [];
        if (quoi === 'coche') bouts.push(`sélection de ${selection.length} note(s)`);
        if (f.eleve_id) {
            const e = this._eleves.find(x => String(x.id) === String(f.eleve_id));
            if (e) bouts.push(`${e.prenom || ''} ${e.nom || ''}`.trim());
        }
        if (f.type) bouts.push('type : ' + this._libelleType(f.type));
        if (f.du || f.au) bouts.push(`du ${f.du ? this._dateFr(f.du) : '…'} au ${f.au ? this._dateFr(f.au) : '…'}`);
        if (!bouts.length) bouts.push('toutes les notes de l\'année');
        return bouts.join(' · ') + ` — ${selection.length} note(s)`;
    },

    _docDef() {
        const selection = this._selectionPourImpression();
        const groupe = document.getElementById('suivi-i-groupe').value;
        const court = document.getElementById('suivi-i-opt').value === 'court';
        const contenu = [
            { text: 'Suivi des élèves', style: 'titre' },
            { text: this._sousTitre(selection), style: 'sousTitre' },
        ];

        const bloc = (titre, notes) => {
            if (titre) contenu.push({ text: titre, style: 'eleve' });
            for (const n of notes) {
                contenu.push({
                    text: `${this._dateFr(n.date_note)} · ${this._libelleType(n.type)}`,
                    style: 'noteTete',
                });
                if (!court) contenu.push({ text: n.contenu, style: 'noteTexte' });
            }
        };

        if (!selection.length) {
            contenu.push({ text: 'Aucune note à imprimer avec ces critères.', style: 'sousTitre' });
        } else if (groupe === 'eleve') {
            const parEleve = new Map();
            for (const n of selection) {
                const cle = this._nomEleve(n);
                if (!parEleve.has(cle)) parEleve.set(cle, []);
                parEleve.get(cle).push(n);
            }
            for (const [nom, notes] of [...parEleve.entries()].sort((a, b) => a[0].localeCompare(b[0], 'fr'))) {
                bloc(nom, notes.sort((a, b) => (a.date_note || '').localeCompare(b.date_note || '')));
            }
        } else {
            bloc(null, selection.slice().sort((a, b) => (a.date_note || '').localeCompare(b.date_note || '')));
        }

        contenu.push({
            text: 'Calulis — document de travail, imprimé depuis le suivi des élèves.',
            style: 'pied',
        });

        return {
            pageSize: 'A4',
            pageMargins: [45, 45, 45, 45],
            defaultStyle: { fontSize: 10 },
            content: contenu,
            styles: {
                titre: { fontSize: 16, bold: true, margin: [0, 0, 0, 2] },
                sousTitre: { fontSize: 9, color: '#555555', margin: [0, 0, 0, 12] },
                eleve: { fontSize: 12, bold: true, margin: [0, 8, 0, 4] },
                noteTete: { fontSize: 8.5, color: '#555555', margin: [0, 4, 0, 1] },
                noteTexte: { fontSize: 10, margin: [0, 0, 0, 2] },
                pied: { fontSize: 8, color: '#777777', margin: [0, 16, 0, 0] },
            },
        };
    },

    _imprimer(apercuSeul) {
        const selection = this._selectionPourImpression();
        if (!selection.length) {
            Toast.show('Rien à imprimer : aucune note ne correspond.', 'error');
            return;
        }
        const def = this._docDef();
        const nom = 'suivi-eleves-' + new Date().toISOString().slice(0, 10) + '.pdf';
        Print._showPreview(def, nom);
        if (!apercuSeul) {
            // Le bouton « Imprimer / PDF » ouvre l'aperçu (comme partout dans Calulis) :
            // c'est là que se trouve le téléchargement du fichier.
            Toast.show('Aperçu prêt : le bouton « Télécharger le PDF » se trouve en bas de la fenêtre.', 'success');
        }
    },
};
