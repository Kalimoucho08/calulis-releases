/**
 * Calulis — Composant Mentions Légales & RGPD
 * Accessible depuis la sidebar (📄 Mentions RGPD)
 */
const MentionsRGPD = {

    render() {
        const view = document.getElementById('view-mentions-rgpd');
        view.innerHTML = this._buildHTML();
        this._bindEvents();
    },

    _buildHTML() {
        return `
        <div class="page-header">
            <h1>📄 Mentions légales & RGPD</h1>
        </div>
        <div class="aide-container">
            <div class="aide-nav">
                <a href="#" class="aide-nav-item active" data-section="responsable">Responsable</a>
                <a href="#" class="aide-nav-item" data-section="finalites">Finalités</a>
                <a href="#" class="aide-nav-item" data-section="donnees">Données traitées</a>
                <a href="#" class="aide-nav-item" data-section="base-legale">Base légale</a>
                <a href="#" class="aide-nav-item" data-section="conservation">Conservation</a>
                <a href="#" class="aide-nav-item" data-section="destinataires">Destinataires</a>
                <a href="#" class="aide-nav-item" data-section="droits">Vos droits</a>
                <a href="#" class="aide-nav-item" data-section="securite">Sécurité</a>
                <a href="#" class="aide-nav-item" data-section="tiers">Services tiers</a>
                <a href="#" class="aide-nav-item" data-section="dpd">DPD</a>
            </div>
            <div class="aide-content">
                <div id="section-responsable" class="aide-section">
                    <h2>🔑 Responsable de traitement</h2>
                    <p>Dans le cadre de l'utilisation de <strong>Calulis</strong> en établissement scolaire, le responsable de traitement est :</p>
                    <ul>
                        <li><strong>Pour le second degré (collège, lycée)</strong> : le chef d'établissement, en sa qualité de responsable de la mise en œuvre des dispositifs ULIS au sein de l'établissement.</li>
                        <li><strong>Pour le premier degré (école)</strong> : le DASEN (Directeur Académique des Services de l'Éducation Nationale), par délégation du recteur d'académie.</li>
                    </ul>
                    <p>L'utilisation de Calulis s'inscrit dans le cadre des missions de l'Éducation nationale et du service public de l'enseignement.</p>
                    <div class="aide-note">
                        <strong>📌 À compléter par l'établissement :</strong> cette page est livrée telle quelle avec le logiciel et ne peut pas être modifiée depuis Calulis. Le nom de votre établissement et son UAI se renseignent dans <em>Paramètres → Notre établissement</em>. Pour nommer le responsable de traitement, utilisez la note d'information de votre établissement ou la fiche remise aux familles.
                    </div>
                </div>

                <div id="section-finalites" class="aide-section" style="display:none">
                    <h2>🎯 Finalités du traitement</h2>
                    <p>Calulis est un outil de gestion destiné aux coordonnateurs ULIS. Les finalités poursuivies sont les suivantes :</p>
                    <ul>
                        <li><strong>Suivi pédagogique</strong> — organisation des emplois du temps des élèves ULIS, gestion des inclusions en classe ordinaire, suivi des progressions.</li>
                        <li><strong>Coordination des accompagnements</strong> — gestion des AESH (Accompagnants des Élèves en Situation de Handicap) et des PEC (Prise en Charge) extérieures.</li>
                        <li><strong>Gestion administrative</strong> — suivi des notifications MDPH (dates de droits ULIS, SESSAD, AESH, transport), organisation des ESS (Équipes de Suivi de la Scolarisation).</li>
                        <li><strong>Organisation scolaire</strong> — gestion des transports, cantine, contacts d'urgence, représentants légaux.</li>
                        <li><strong>Suivi des réunions</strong> — comptes rendus ESS, équipes éducatives, rendez-vous familles.</li>
                        <li><strong>Tableau de bord et statistiques</strong> — effectifs, temps d'inclusion, prises en charge, droits MDPH, pour le pilotage du dispositif ULIS. Les indicateurs d'ensemble sont des comptages ; certains états détaillés (statistiques par élève ou par prise en charge, listes, fiches) <strong>portent les noms des élèves</strong> et sont destinés à un usage interne.</li>
                    </ul>
                    <p>Ces finalités sont conformes aux missions définies par la <strong>circulaire n° 2015-129 du 21 août 2015</strong> relative aux ULIS.</p>
                </div>

                <div id="section-donnees" class="aide-section" style="display:none">
                    <h2>📋 Données personnelles traitées</h2>
                    <h3>Catégories de données</h3>
                    <table class="data-table" style="font-size:14px">
                        <thead>
                            <tr><th>Catégorie</th><th>Données concernées</th><th>Finalité</th></tr>
                        </thead>
                        <tbody>
                            <tr><td>Identité</td><td>Nom, prénom, date de naissance</td><td>Suivi scolaire, identification</td></tr>
                            <tr><td>Scolarité</td><td>Classe, niveau, ULIS, école d'origine, aménagements d'examens, temps de scolarisation</td><td>Organisation pédagogique</td></tr>
                            <tr><td>Identifiant national</td><td>INE (identifiant national élève) et numéro de dossier MDPH</td><td>Suivi administratif du dossier</td></tr>
                            <tr><td>Suivi pédagogique et observations</td><td>Notes de suivi datées (observations, objectifs, réussites, alertes, actions), comptes rendus de réunions, évaluations de stage</td><td>Préparation des bilans et des ESS</td></tr>
                            <tr><td>Handicap</td><td>Dates et statuts MDPH (ULIS, SESSAD, AESH, transport)</td><td>Suivi des notifications CDAPH — obligation réglementaire</td></tr>
                            <tr><td>Santé</td><td>Allergies, PAI, précautions médicales pour la vie scolaire</td><td>Sécurité de l'élève — uniquement les précautions nécessaires à la vie scolaire</td></tr>
                            <tr><td>Coordonnées</td><td>Téléphone, email, adresse (élève et représentants)</td><td>Contact d'urgence, communication école-famille</td></tr>
                            <tr><td>Accompagnement</td><td>AESH, PEC, transport, cantine</td><td>Coordination des accompagnements</td></tr>
                            <tr><td>Protection enfance</td><td>ASE (statut, référent)</td><td>Coordination avec les services de protection de l'enfance</td></tr>
                            <tr><td>Image</td><td>Droit à l'image (demandé, reçu, refusé), photographie de l'élève si vous en déposez une</td><td>Autorisations de diffusion (photo de classe, site de l'école, réseaux sociaux de l'école)</td></tr>
                            <tr><td>Données sociales et d'origine</td><td>Bourse, cantine, régime scolaire, transport, langue parlée à la maison</td><td>Organisation de la vie scolaire</td></tr>
                            <tr><td>Personnels et partenaires</td><td>Nom, prénom, téléphone, courriel des adultes (enseignants, AESH, professionnels)</td><td>Annuaire et coordination des accompagnements</td></tr>
                        </tbody>
                    </table>
                    <p class="aide-note" style="margin-top:12px">
                        ⚠️ <strong>Précision importante</strong> : Calulis ne comporte <em>aucun champ « diagnostic »</em> et n'en demande aucun. Les seules informations de santé attendues sont les précautions nécessaires à la vie scolaire (allergies, traitements en cours, aménagements). Les diagnostics relèvent du dossier médical de l'école ou de l'établissement.
                        <br><br>
                        ⚠️ <strong>Mais Calulis ne contrôle pas ce que vous y mettez.</strong> Les champs libres (remarques, notes de suivi, comptes rendus de réunion) et les documents que vous rapatriez peuvent contenir un diagnostic ou tout autre élément sensible : c'est alors votre responsabilité de responsable de traitement, et ces éléments relèvent de l'article 9 du RGPD. Ne saisissez que ce qui est nécessaire au suivi.
                    </p>
                </div>

                <div id="section-base-legale" class="aide-section" style="display:none">
                    <h2>⚖️ Base légale des traitements</h2>
                    <p>Les traitements mis en œuvre dans Calulis reposent sur les bases légales suivantes :</p>
                    <ul>
                        <li><strong>Mission d'intérêt public</strong> (Article 6.1.e du RGPD) — pour l'ensemble des traitements liés à la scolarisation des élèves ULIS, conformément aux missions définies par le code de l'éducation et les circulaires relatives aux ULIS.</li>
                        <li><strong>Obligation légale</strong> (Article 6.1.c du RGPD) — pour le suivi des notifications MDPH et l'organisation des ESS, conformément aux dispositions du code de l'éducation (articles L.112-1 et suivants).</li>
                        <li><strong>Intérêts vitaux</strong> (Article 6.1.d du RGPD) — pour les données de contact d'urgence et les précautions médicales (allergies, traitements).</li>
                    </ul>
                    <div class="aide-note">
                        <strong>📌 Note :</strong> Le recueil du consentement individuel des familles n'est pas requis lorsque le traitement est nécessaire à l'exécution d'une mission d'intérêt public. Toutefois, les familles doivent être informées du traitement de leurs données (cf. section "Vos droits").
                    </div>
                </div>

                <div id="section-conservation" class="aide-section" style="display:none">
                    <h2>⏱️ Durée de conservation</h2>
                    <table class="data-table" style="font-size:14px">
                        <thead>
                            <tr><th>Catégorie de données</th><th>Durée de conservation</th></tr>
                        </thead>
                        <tbody>
                            <tr><td>Données élève (dans le dispositif)</td><td>Tant que l'élève est suivi en ULIS — de 5 à 7 ans selon le parcours (du CP au CM2). Les données de l'année en cours, comme celles des années précédentes, sont conservées</td></tr>
                            <tr><td>Données élève (sorti du dispositif)</td><td><strong>2 ans</strong> après la sortie — durée <em>recommandée</em>, qu'aucune tâche de Calulis ne fait respecter automatiquement. Pendant ces deux ans, l'élève et ses documents restent consultables. Le <strong>dossier complet</strong> peut être emporté en un seul fichier ZIP : depuis la fiche de l'élève (onglet <em>Documents</em> → « Emporter le dossier »), ou au moment de sa suppression, où Calulis le propose avant d'effacer. En revanche la <strong>purge groupée</strong> des élèves sortis efface sans proposer d'archive — c'est pourquoi il vaut mieux emporter un dossier avant. Calulis ne sait pas anonymiser : la suppression est définitive</td></tr>
                            <tr><td>Comptes rendus de réunions et documents de l'élève</td><td>Tant que l'élève est suivi, puis 2 ans après sa sortie — même règle que ses autres données</td></tr>
                            <tr><td>Journaux techniques</td><td>Calulis n'enregistre <strong>aucune donnée de connexion</strong>. Il écrit en revanche un journal d'erreurs techniques dans son dossier d'installation (<code>runtime/logs</code>) : les valeurs que vous avez saisies en sont retirées, mais il peut contenir des chemins internes et le détail d'une erreur. Il est plafonné automatiquement, se supprime depuis ce dossier, et le lanceur ne le transmet au support que si vous le demandez</td></tr>
                            <tr><td>Documents rapatriés (fichiers)</td><td>Tant que l'élève est suivi, puis 2 ans après sa sortie — même règle que ses autres données. Supprimer un document efface la copie du fichier sur le disque, et <strong>supprimer l'élève efface tous ses documents et tous ses fichiers</strong> (Calulis propose alors de les emporter d'abord dans un fichier ZIP). Les fichiers sont rangés dans un sous-dossier nommé d'après le <strong>numéro interne</strong> de l'élève (<code>eleve-12</code>), et le nom d'origine du fichier est conservé et affiché</td></tr>
                            <tr><td>Sauvegardes (fichiers .sql)</td><td>Une sauvegarde est écrite automatiquement <strong>avant chaque opération qui remplace des données</strong> (restauration, chargement d'une base, mise à jour). Elle reste sur le poste tant que vous ne la supprimez pas : prévoyez une purge régulière et un support maîtrisé (disque de l'établissement, <strong>jamais</strong> un dossier synchronisé vers un service en ligne). <strong>⚠️ Une sauvegarde ne contient que la base, jamais les documents rapatriés</strong> : après une restauration, les fiches reviennent mais les fichiers ont disparu. Pour les conserver, copiez aussi le dossier <code>runtime/documents</code> de votre installation</td></tr>
                        </tbody>
                    </table>
                    <p><strong>Rien n'est effacé automatiquement par Calulis</strong> : il n'y a ni tâche planifiée ni purge à échéance. La suppression est un geste de l'utilisateur — suppression d'un élève, purge des élèves sortis, suppression d'un document — et chacun efface aussi les fichiers correspondants sur le disque. C'est donc à l'établissement d'en fixer la date. Calulis ne fait pas non plus d'anonymisation : la suppression est définitive.</p>
                </div>

                <div id="section-destinataires" class="aide-section" style="display:none">
                    <h2>👥 Destinataires des données</h2>
                    <p>Les données traitées dans Calulis sont destinées aux personnes suivantes, dans le cadre de leurs fonctions :</p>
                    <ul>
                        <li><strong>Coordonnateur ULIS</strong> — accès complet à l'ensemble des données pour la gestion du dispositif.</li>
                        <li><strong>AESH</strong> — accès limité aux emplois du temps et aux informations nécessaires à leur mission d'accompagnement.</li>
                        <li><strong>Chef d'établissement / Directeur d'école</strong> — accès aux données statistiques et au suivi global du dispositif.</li>
                        <li><strong>Enseignants de classe de référence</strong> — informations sur les temps d'inclusion et les aménagements pédagogiques.</li>
                    </ul>
                    <p><strong>Non-destinataires :</strong> Les données ne sont en aucun cas transmises à des tiers non autorisés, ni vendues, ni louées, ni partagées à des fins commerciales.</p>
                    <div class="aide-note">
                        ⚠️ <strong>Calulis n'a pas de comptes utilisateurs.</strong> Il n'y a ni identifiant, ni mot de passe, ni profil : la liste ci-dessus décrit <em>qui est légitime</em> pour consulter quoi, pas ce que le logiciel empêche techniquement. Toute personne qui ouvre Calulis — ou qui trouve le poste déverrouillé, ou qui lit le dossier d'installation — accède à <strong>toutes</strong> les données. La confidentialité repose donc sur l'accès au poste : session Windows protégée et verrouillée en cas d'absence, dossier d'installation non partagé. C'est la limite principale du logiciel, et elle doit être connue de votre établissement.
                    </div>
                    <div class="aide-note">
                        <strong>🔒 Application locale :</strong> Calulis fonctionne sur le poste de l'utilisateur (serveur local). Aucune donnée d'élève n'est transmise à des serveurs distants. Les seules requêtes sortantes sont la <strong>vérification des mises à jour</strong> (dépôt GitHub, puis son miroir pCloud) et, si vous le demandez, l'<strong>import du calendrier scolaire officiel</strong> : aucune ne porte de donnée personnelle (cf. section « Services tiers »).
                    </div>
                </div>

                <div id="section-droits" class="aide-section" style="display:none">
                    <h2>🛡️ Vos droits</h2>
                    <p>Conformément au RGPD (Règlement Général sur la Protection des Données) et à la loi Informatique et Libertés, les personnes concernées (élèves et leurs représentants légaux) disposent des droits suivants :</p>
                    <table class="data-table" style="font-size:14px">
                        <thead>
                            <tr><th>Droit</th><th>Description</th><th>Procédure</th></tr>
                        </thead>
                        <tbody>
                            <tr><td><strong>Accès</strong></td><td>Obtenir la confirmation que des données sont traitées et en recevoir une copie</td><td>Contacter le chef d'établissement ou le DPD</td></tr>
                            <tr><td><strong>Rectification</strong></td><td>Demander la correction de données inexactes ou incomplètes</td><td>Contacter le coordonnateur ULIS ou le chef d'établissement</td></tr>
                            <tr><td><strong>Effacement</strong></td><td>Demander la suppression des données (dans la limite des obligations légales de conservation)</td><td>Contacter le chef d'établissement ou le DPD</td></tr>
                            <tr><td><strong>Limitation</strong></td><td>Demander le gel temporaire du traitement</td><td>Contacter le DPD</td></tr>
                            <tr><td><strong>Opposition</strong></td><td>S'opposer au traitement pour des motifs tenant à la situation particulière</td><td>Contacter le chef d'établissement ou le DPD</td></tr>
                            <tr><td><strong>Portabilité</strong></td><td>Recevoir les données dans un format structuré (sur demande)</td><td>Contacter le DPD</td></tr>
                        </tbody>
                    </table>
                    <div class="aide-note">
                        <strong>✉️ Pour exercer vos droits :</strong> Adressez-vous d'abord au chef d'établissement ou au coordonnateur ULIS. Vous pouvez également contacter le Délégué à la Protection des Données (DPD) de votre académie — voir coordonnées dans la section "DPD".
                        <br><br>
                        Si vous estimez que vos droits ne sont pas respectés, vous avez la possibilité d'introduire une réclamation auprès de la <strong>CNIL</strong> (Commission Nationale de l'Informatique et des Libertés) : <a href="https://www.cnil.fr" target="_blank" rel="noopener">www.cnil.fr</a>.
                    </div>
                </div>

                <div id="section-securite" class="aide-section" style="display:none">
                    <h2>🔐 Sécurité des données</h2>
                    <p>Calulis met en œuvre les mesures de sécurité suivantes pour protéger les données personnelles :</p>
                    <ul>
                        <li>✅ <strong>Protection contre les injections SQL</strong> — toutes les requêtes utilisent des requêtes préparées (PDO) avec désactivation de l'émulation.</li>
                        <li>✅ <strong>Protection XSS</strong> — toutes les données affichées sont échappées (fonction <code>escapeHtml()</code>).</li>
                        <li>✅ <strong>Application locale</strong> — pas d'exposition sur Internet, les données ne quittent pas le poste de l'utilisateur.</li>
                        <li>✅ <strong>Absence de télémétrie</strong> — pas d'analytics, pas de tracking, pas de cookies.</li>
                        <li>✅ <strong>Pas de données dans le navigateur</strong> — le navigateur ne garde qu'un réglage d'affichage (le thème clair ou sombre). Aucune donnée d'élève n'y est enregistrée.</li>
                        <li>✅ <strong>Documents rapatriés dans l'application</strong> — les documents que vous associez à un élève (notification, PPS, compte rendu, PAI, courrier, photo) sont <strong>copiés dans un dossier de votre ordinateur</strong>, à l'intérieur de l'installation de Calulis. Ils ne sont jamais envoyés sur Internet, et aucun serveur distant n'y a accès. La liste des élèves affiche un <strong>compteur de documents</strong> par élève, et l'établissement gère lui-même les <strong>types de documents</strong> (ajouter, renommer, désactiver, supprimer) : supprimer un type encore utilisé oblige à réaffecter d'abord ses documents.</li>
                        <li>⚠️ <strong>Ces documents peuvent être sensibles</strong> (santé, situation de handicap) et relèvent de l'article 9 du RGPD : ne rapatriez que ce qui est nécessaire au suivi, et supprimez-les depuis Calulis quand ils ne le sont plus. Supprimer le document d'origine ne suffit pas — la copie reste tant qu'elle n'est pas supprimée ici.</li>
                    </ul>
                    <p><strong>Recommandations :</strong></p>
                    <ul>
                        <li>Utiliser un poste de travail dont l'accès est protégé par un mot de passe.</li>
                        <li>Verrouiller la session en cas d'absence.</li>
                        <li>Les exports PDF ou CSV contenant des données personnelles doivent être stockés de manière sécurisée et supprimés dès que leur usage est terminé.</li>
                    </ul>
                </div>

                <div id="section-tiers" class="aide-section" style="display:none">
                    <h2>🔗 Services tiers</h2>
                    <p>Calulis utilise les services tiers suivants, strictement nécessaires à son fonctionnement :</p>
                    <p><strong>✅ Aucun service tiers.</strong> Calulis fonctionne entièrement en local : aucune bibliothèque n'est chargée depuis Internet (pdfmake et pdf.js sont livrés avec l'application), et il n'y a ni statistiques, ni publicité, ni police distante.</p>
                    <p>Deux requêtes sortantes existent, et <strong>aucune ne porte de donnée personnelle</strong> :</p>
                    <ul>
                        <li><strong>Mise à jour du logiciel</strong> — la vérification lit le manifeste public des versions (dépôt GitHub, puis son miroir pCloud si GitHub est injoignable). Aucun identifiant de machine, aucune donnée locale n'est envoyé.</li>
                        <li><strong>Calendrier scolaire officiel</strong> — l'import des vacances (Paramètres) interroge <code>data.education.gouv.fr</code> avec la zone (A, B ou C) et l'année scolaire. Rien d'autre ne part. Sans Internet, cette seule fonction est indisponible ; tout le reste de Calulis continue de fonctionner.</li>
                    </ul>
                    <p style="font-size:13px;color:var(--text-muted)">Les liens vers Facebook (aide), PayPal (soutenir), la CNIL et les sources des composants ne sont que des liens : rien n'est envoyé tant que vous ne cliquez pas.</p>
                </div>

                <div id="section-dpd" class="aide-section" style="display:none">
                    <h2>👤 Délégué à la Protection des Données (DPD)</h2>
                    <p>Le Délégué à la Protection des Données (DPD, ou DPO en anglais) de votre académie est l'interlocuteur privilégié pour toutes les questions relatives à la protection des données personnelles.</p>
                    <div class="aide-info-box" style="background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:16px;margin:12px 0">
                        <p style="margin:0 0 8px"><strong>📧 Contacter le DPD de votre académie :</strong></p>
                        <p style="margin:0 0 4px">⚠️ <strong>Calulis ne peut pas deviner votre académie</strong> et ne vous donne donc aucune adresse toute faite : écrire à une académie qui n'est pas la vôtre ferait perdre votre demande.</p>
                        <p style="margin:0;font-size:13px;color:var(--text-muted)">L'adresse du délégué à la protection des données se trouve sur le site de votre rectorat ou de votre académie, rubrique « données personnelles » ou « RGPD ».</p>
                    </div>
                    <p><strong>Informations générales :</strong></p>
                    <ul>
                        <li>Le DPD est chargé de veiller à la conformité RGPD au sein de l'académie.</li>
                        <li>Il doit être informé de tout nouveau traitement de données personnelles ou de toute modification substantielle d'un traitement existant (Eduscol).</li>
                        <li>Il est joignable pour toute question relative à l'utilisation de Calulis et au respect des droits des personnes.</li>
                    </ul>
                    <p class="aide-note">
                        <strong>📌 Action recommandée :</strong> Avant de déployer Calulis dans votre établissement, contactez votre DPD académique pour l'informer de ce traitement et vous assurer de la conformité avec les règles locales.
                    </p>
                </div>
            </div>
        </div>
        <div class="aide-footer" style="border-top:1px solid var(--border);margin-top:32px;padding-top:16px;font-size:13px;color:var(--text-muted);text-align:center">
            <p style="margin:0">Calulis — Application de gestion ULIS. Dernière mise à jour : octobre 2026.</p>
            <p style="margin:4px 0 0">Conformément au RGPD et à la loi Informatique et Libertés.</p>
        </div>
        `;
    },

    _bindEvents() {
        document.querySelectorAll('.aide-nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const section = item.dataset.section;
                if (!section) return;
                // Navigation
                document.querySelectorAll('.aide-nav-item').forEach(n => n.classList.remove('active'));
                item.classList.add('active');
                document.querySelectorAll('.aide-section').forEach(s => s.style.display = 'none');
                const target = document.getElementById('section-' + section);
                if (target) target.style.display = 'block';
            });
        });
    }
};
