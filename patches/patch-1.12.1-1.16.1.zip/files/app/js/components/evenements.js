/**
 * Calulis — Composant Événements
 * Gestion des événements : jours fériés, semaines thématiques, examens, anniversaires…
 */
const EvenementsView = {
    _events: [],
    _filterCat: '',
    _showModeles: true,
    _batchInProgress: false,
    _sort: { col: 'date_debut', dir: 'asc' },

    async render() {
        const view = document.getElementById('view-evenements');
        view.innerHTML = `
            <div class="toolbar">
                <button class="btn btn-primary" id="btn-new-event">+ Événement</button>
                <select id="filter-cat-evenement" style="width:auto;padding:6px 12px;font-size:13px">
                    <option value="">Toutes les catégories</option>
                    <option value="ferie">🏛️ Fériés</option>
                    <option value="examen">📝 Examens</option>
                    <option value="national">🇫🇷 Nationaux</option>
                    <option value="scolaire">🏫 Scolaires</option>
                    <option value="individuel">👤 Individuels</option>
                    <option value="anniversaire">🎂 Anniversaires</option>
                </select>
                <label style="display:flex;align-items:center;gap:6px;cursor:pointer;font-size:13px;margin-left:8px">
                    <input type="checkbox" id="toggle-modeles" checked>
                    Afficher les modèles
                </label>
                <span style="margin-left:auto;display:flex;align-items:center;gap:8px">
                    <button class="btn btn-sm btn-secondary" id="btn-ics-evenements" title="Exporter les événements affichés dans un fichier .ics (téléphone, Google Agenda, Outlook)" data-help="Exporter (.ics)|Fabrique un fichier que votre téléphone, Google Agenda ou Outlook savent ouvrir, avec les événements AFFICHÉS (vos filtres font foi). Les modèles sans date ne sont pas exportés. Le fichier est fabriqué sur votre ordinateur : rien n'est envoyé sur Internet.">📆 Exporter (.ics)</button>
                    <button class="btn btn-sm btn-secondary" id="btn-generer-anniversaires" title="Génère un événement par élève actif avec sa date de naissance">🎂 Générer les anniversaires</button>
                    <span id="anniv-msg" class="text-muted" style="font-size:12px"></span>
                </span>
            </div>
            <div class="card" style="flex:1;overflow:auto;padding:0">
                <table class="data-table" id="table-evenements">
                    <thead><tr>
                        <th style="width:40px"><input type="checkbox" id="cb-master-events" title="Tout cocher / décocher"></th>
                        <th data-sort="nom" class="sortable">Nom</th>
                        <th data-sort="categorie" class="sortable" style="width:90px">Catégorie</th>
                        <th data-sort="date_debut" class="sortable" style="width:110px">Date</th>
                        <th style="width:80px">Statut</th>
                        <th style="width:90px">Actions</th>
                    </tr></thead>
                    <tbody id="tbody-evenements"><tr><td colspan="6" class="empty">Chargement…</td></tr></tbody>
                </table>
            </div>
        `;
        document.getElementById('btn-new-event').addEventListener('click', () => this._openForm());
        document.getElementById('filter-cat-evenement').addEventListener('change', () => {
            this._filterCat = document.getElementById('filter-cat-evenement').value;
            this._renderTable();
        });
        document.getElementById('toggle-modeles').addEventListener('change', () => {
            this._showModeles = document.getElementById('toggle-modeles').checked;
            this._renderTable();
        });
        // Tri par colonnes
        view.querySelectorAll('#table-evenements th.sortable').forEach(th => {
            th.addEventListener('click', () => {
                const col = th.dataset.sort;
                if (this._sort.col === col) this._sort.dir = this._sort.dir === 'asc' ? 'desc' : 'asc';
                else { this._sort.col = col; this._sort.dir = 'asc'; }
                this._renderTable();
            });
        });
        document.getElementById('btn-generer-anniversaires')?.addEventListener('click', () => this._genererAnniversaires());
        document.getElementById('btn-ics-evenements')?.addEventListener('click', () => this._exportICS());
        await this._load();
    },

    /**
     * Export .ics des événements AFFICHÉS (les filtres de la barre d'outils font foi).
     * Seuls ceux qui ont une date partent : un modèle sans date ne se place nulle part
     * dans un agenda. Le fichier est fabriqué dans le navigateur (`exportICS`).
     */
    _exportICS() {
        const evenements = this._eventsAffiches().filter(e => e.date_debut);
        if (evenements.length === 0) {
            Toast.info('Aucun événement daté à exporter.' + (this._filterCat ? ' Vérifiez le filtre de catégorie.' : ''));
            return;
        }
        exportICS('evenements-calulis.ics', 'Événements Calulis', evenements.map(e => ({
            uid: 'evenement-' + e.id + '@calulis',
            debut: e.date_debut,
            fin: e.date_fin || null,
            titre: e.nom || 'Événement',
            description: e.description || '',
        })));
        Toast.success(evenements.length + ' événement(s) exporté(s).');
    },

    async _load() {
        try {
            // Charger TOUS les événements (modèles + réels)
            // Charger TOUS les événements (modèles + actifs), sans filtre d'année
            const all = await API.get('evenements.php?toutes_annees=1');
            this._events = all;
            this._renderTable();
        } catch (e) {
            document.getElementById('tbody-evenements').innerHTML =
                `<tr><td colspan="6" class="empty" style="color:var(--danger)">Erreur : ${escapeHtml(e.message)}</td></tr>`;
        }
    },

    /** Les événements tels que l'utilisateur les voit (filtres + tri de la barre d'outils). */
    _eventsAffiches() {
        let events = this._events;
        if (this._filterCat) events = events.filter(e => e.categorie === this._filterCat);
        if (!this._showModeles) events = events.filter(e => !e.est_modele);
        return this._sortData(events);
    },

    _renderTable() {
        const tbody = document.getElementById('tbody-evenements');

        // Mettre à jour les flèches de tri
        document.querySelectorAll('#table-evenements th.sortable').forEach(th => {
            th.classList.remove('sorted-asc', 'sorted-desc');
            if (th.dataset.sort === this._sort.col) {
                th.classList.add(this._sort.dir === 'asc' ? 'sorted-asc' : 'sorted-desc');
            }
        });

        // Trier
        const events = this._eventsAffiches();

        if (!events.length) {
            tbody.innerHTML = `<tr><td colspan="6" class="empty">Aucun événement.</td></tr>`;
            return;
        }

        const catLabels = {
            ferie: '🏛️ Férié', examen: '📝 Examen', national: '🇫🇷 National',
            scolaire: '🏫 École', individuel: '👤 Individuel', anniversaire: '🎂 Anniv.',
        };

        tbody.innerHTML = events.map(e => {
            const isModeleInactif = e.est_modele && !e.annee_scolaire_id;
            const checked = isModeleInactif ? '' : 'checked';
            const cbTitle = isModeleInactif ? 'Activer cet événement' : 'Désactiver';
            const hasDate = e.date_debut ? `<span style="color:var(--success)">${formatDate(e.date_debut)}</span>` : '<span class="text-muted">—</span>';
            const statutClass = isModeleInactif ? 'badge badge-status-pending' : 'badge badge-ulis';
            const statut = isModeleInactif ? 'Modèle' : 'Actif';
            const rowStyle = e.est_modele && e.annee_scolaire_id === 0 ? '' : 'font-weight:500';
            return `
            <tr style="${rowStyle}">
                <td style="text-align:center">
                    <input type="checkbox" class="cb-activate-event" data-id="${e.id}" ${checked}
                        title="${cbTitle}">
                </td>
                <td>${escapeHtml(e.nom)}${e.description ? `<br><span class="text-muted small">${escapeHtml(e.description)}</span>` : ''}</td>
                <td class="small">${catLabels[e.categorie] || escapeHtml(e.categorie || '—')}</td>
                <td class="small">${hasDate}</td>
                <td><span class="${statutClass}">${statut}</span></td>
                <td>
                    <button class="btn-sm btn-edit" data-id="${e.id}">✏️</button>
                    <button class="btn-sm btn-del" data-id="${e.id}" ${e.est_modele ? '' : 'style="color:var(--danger)"'}>${e.est_modele ? '↺' : '🗑'}</button>
                </td>
            </tr>`;
        }).join('');

        // Event listeners
        tbody.querySelectorAll('.cb-activate-event').forEach(cb => {
            cb.addEventListener('change', () => {
                if (this._batchInProgress) return;
                this._toggleActivate(parseInt(cb.dataset.id), cb.checked);
                this._updateMasterCheckbox();
            });
        });

        // Master checkbox : tout cocher / décocher (visible)
        const masterCb = document.getElementById('cb-master-events');
        if (masterCb) {
            this._updateMasterCheckbox();
            masterCb.addEventListener('change', () => {
                const allCbs = tbody.querySelectorAll('.cb-activate-event');
                const targetState = masterCb.checked;
                this._batchInProgress = true;
                allCbs.forEach(cb => { cb.checked = targetState; });
                this._batchToggle(allCbs, targetState).finally(() => {
                    this._batchInProgress = false;
                });
            });
        }
        tbody.querySelectorAll('.btn-edit').forEach(b => {
            b.addEventListener('click', () => {
                const ev = this._events.find(e => e.id === parseInt(b.dataset.id));
                if (ev) this._openForm(ev);
            });
        });
        tbody.querySelectorAll('.btn-del').forEach(b => {
            b.addEventListener('click', () => this._deleteEvent(parseInt(b.dataset.id)));
        });
    },

    _sortData(data) {
        if (!this._sort.col) return data;
        const dir = this._sort.dir === 'asc' ? 1 : -1;
        return [...data].sort((a, b) => {
            const va = (a[this._sort.col] ?? '').toString().toLowerCase();
            const vb = (b[this._sort.col] ?? '').toString().toLowerCase();
            if (this._sort.col === 'date_debut') {
                // Trier par date : null/empty en dernier
                if (!a.date_debut && !b.date_debut) return 0;
                if (!a.date_debut) return 1;
                if (!b.date_debut) return -1;
                return (a.date_debut.localeCompare(b.date_debut)) * dir;
            }
            return va.localeCompare(vb) * dir;
        });
    },

    async _toggleActivate(id, checked) {
        const ev = this._events.find(e => e.id === id);
        if (!ev) return;
        if (checked && !ev.date_debut) {
            Toast.error('Impossible d\'activer un événement sans date. Modifie-le d\'abord pour ajouter une date.');
            // Revert the checkbox
            this._renderTable();
            return;
        }
        try {
            if (checked) {
                // Activer : définir l'année scolaire active
                const anneeId = State.get('annee_scolaire_id') || 0;
                await API.put('evenements.php?id=' + id, { ...ev, annee_scolaire_id: anneeId });
                Toast.success('Événement activé');
            } else {
                // Désactiver (pour les modèles : remettre annee_scolaire_id à null)
                await API.put('evenements.php?id=' + id, { ...ev, annee_scolaire_id: null });
                Toast.success('Événement désactivé');
            }
            await this._load();
        } catch (e) {
            Toast.error(e.message);
            await this._load();
        }
    },

    _openForm(event = null) {
        const isNew = !event;
        const ev = event || { nom: '', description: '', date_debut: '', date_fin: '', categorie: '', est_modele: 1, couleur: '#4A90D9' };
        const catOptions = [
            ['', '— Catégorie —'],
            ['ferie', '🏛️ Jours fériés'],
            ['examen', '📝 Examens'],
            ['national', '🇫🇷 Nationaux'],
            ['scolaire', '🏫 École'],
            ['individuel', '👤 Individuels'],
        ];
        const html = `
            <div class="form-group"><label>Nom *</label>
                <input type="text" id="ev-nom" value="${escapeHtml(ev.nom)}" style="width:100%"></div>
            <div class="form-group"><label>Description</label>
                <textarea id="ev-desc" style="width:100%;min-height:60px">${escapeHtml(ev.description || '')}</textarea></div>
            <div style="display:flex;gap:12px">
                <div class="form-group" style="flex:1"><label>Catégorie</label>
                    <select id="ev-cat" style="width:100%">${catOptions.map(([v,l]) =>
                        `<option value="${v}" ${ev.categorie === v ? 'selected' : ''}>${l}</option>`
                    ).join('')}</select></div>
                <div class="form-group" style="flex:1"><label>Couleur</label>
                    <input type="color" id="ev-couleur" value="${ev.couleur || '#4A90D9'}" style="width:60px;height:34px"></div>
            </div>
            <div style="display:flex;gap:12px">
                <div class="form-group" style="flex:1"><label>Date début</label>
                    <input type="date" id="ev-debut" value="${ev.date_debut || ''}" style="width:100%"></div>
                <div class="form-group" style="flex:1"><label>Date fin</label>
                    <input type="date" id="ev-fin" value="${ev.date_fin || ''}" style="width:100%"></div>
            </div>
            <label style="display:flex;align-items:center;gap:6px;margin-top:8px;font-size:13px">
                <input type="checkbox" id="ev-modele" ${ev.est_modele ? 'checked' : ''}>
                Événement modèle (réutilisable chaque année)
            </label>
        `;
        Modal.open({
            title: isNew ? 'Nouvel événement' : 'Modifier l\'événement',
            body: html,
            buttons: [
                { text: 'Annuler', class: 'btn-secondary' },
                { text: isNew ? 'Créer' : 'Enregistrer', class: 'btn-primary', action: async () => {
                    const nom = document.getElementById('ev-nom').value.trim();
                    if (!nom) { Toast.error('Nom requis'); return false; }
                    const data = {
                        nom,
                        description: document.getElementById('ev-desc').value.trim(),
                        categorie: document.getElementById('ev-cat').value,
                        date_debut: document.getElementById('ev-debut').value || null,
                        date_fin: document.getElementById('ev-fin').value || null,
                        couleur: document.getElementById('ev-couleur').value,
                        est_modele: document.getElementById('ev-modele').checked ? 1 : 0,
                        annee_scolaire_id: ev.annee_scolaire_id || (document.getElementById('ev-modele').checked ? null : (State.get('annee_scolaire_id') || null)),
                    };
                    try {
                        if (isNew) {
                            await API.post('evenements.php', data);
                            Toast.success('Événement créé');
                        } else {
                            await API.put('evenements.php?id=' + ev.id, data);
                            Toast.success('Événement mis à jour');
                        }
                        await this._load();
                    } catch (err) { Toast.error(err.message); return false; }
                    return true;
                }},
            ],
        });
    },

    _updateMasterCheckbox() {
        const masterCb = document.getElementById('cb-master-events');
        const allCbs = document.querySelectorAll('#tbody-evenements .cb-activate-event');
        if (!masterCb || !allCbs.length) return;
        const checked = [...allCbs].filter(cb => cb.checked).length;
        masterCb.checked = checked === allCbs.length;
        masterCb.indeterminate = checked > 0 && checked < allCbs.length;
    },

    async _batchToggle(cbs, activate) {
        const anneeId = State.get('annee_scolaire_id') || 0;
        let skipped = 0;
        const promises = [...cbs].map(cb => {
            const id = parseInt(cb.dataset.id);
            const ev = this._events.find(e => e.id === id);
            if (!ev) return Promise.resolve();
            const wasActive = ev.est_modele && !ev.annee_scolaire_id ? false : true;
            if (activate === wasActive) return Promise.resolve(); // déjà dans le bon état
            if (activate && !ev.date_debut) { skipped++; return Promise.resolve(); } // sans date → ignoré
            if (activate) {
                return API.put('evenements.php?id=' + id, { ...ev, annee_scolaire_id: anneeId });
            } else {
                return API.put('evenements.php?id=' + id, { ...ev, annee_scolaire_id: null });
            }
        });
        try {
            await Promise.all(promises);
            if (activate && skipped > 0) {
                Toast.warning(`${skipped} événement${skipped>1?'s':''} sans date ignoré${skipped>1?'s':''}. Ajoute une date dans ✏️ Modifier.`);
            } else {
                Toast.success(activate ? 'Événements activés' : 'Événements désactivés');
            }
        } catch (e) {
            Toast.error(e.message);
        }
        await this._load();
    },

    async _deleteEvent(id) {
        const ev = this._events.find(e => e.id === id);
        if (!ev) return;
        if (ev.est_modele && !ev.annee_scolaire_id) {
            // Pour les modèles inactifs, supprimer sans confirmation
        } else {
            if (!await Modal.confirm('Supprimer', `Supprimer "${ev.nom}" ?`)) return;
        }
        try {
            await API.del('evenements.php?id=' + id);
            await this._load();
            Toast.success('Événement supprimé');
        } catch (e) {
            Toast.error(e.message);
        }
    },

    async _genererAnniversaires() {
        const msg = document.getElementById('anniv-msg');
        if (msg) msg.textContent = '⏳…';
        try {
            const anneeId = State.get('annee_scolaire_id');
            const res = await API.post('evenements.php', {
                action: 'generer_anniversaires',
                annee_scolaire_id: anneeId,
            });
            if (res.crees > 0) {
                if (msg) msg.textContent = `✅ ${res.crees} créé${res.crees > 1 ? 's' : ''}`;
                Toast.success(`${res.crees} anniversaire${res.crees > 1 ? 's' : ''} ajouté${res.crees > 1 ? 's' : ''}`);
            } else if (res.ignores > 0) {
                if (msg) msg.textContent = `ℹ️ Déjà existants`;
            } else {
                if (msg) msg.textContent = 'ℹ️ Aucun élève avec date';
            }
            await this._load();
        } catch (e) {
            if (msg) msg.textContent = '❌ ' + e.message;
            Toast.error(e.message);
        }
    },
};
