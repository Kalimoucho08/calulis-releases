/**
 * Calulis — Agenda Clipboard : copier/couper/coller
 * Ajouté à Agenda via Object.assign
 */

Object.assign(Agenda, {

    _copySelection() {
        const creneaux = this._getSelectedCreneaux();
        if (creneaux.length > 0) {
            this._clipboard = {
                creneaux: creneaux.map(c => ({
                    eleve_id: c.eleve_id,
                    matiere: c.matiere,
                    groupe: c.groupe,
                    adulte: c.adulte,
                    role_adulte: c.role_adulte,
                    type: c.type,
                    regroupement_type: c.regroupement_type,
                    couleur_override: c.couleur_override,
                    commentaire: c.commentaire,
                    duree: c.duree,
                })),
                mode: 'copy',
            };
            const status = document.getElementById('status-selection');
            if (status) status.textContent = `${creneaux.length} créneau(x) copié(s)`;
        }
    },

    async _cutSelection() {
        const creneaux = this._getSelectedCreneaux();
        if (creneaux.length === 0) return;

        this._clipboard = {
            creneaux: creneaux.map(c => ({
                eleve_id: c.eleve_id,
                matiere: c.matiere,
                groupe: c.groupe,
                adulte: c.adulte,
                role_adulte: c.role_adulte,
                type: c.type,
                regroupement_type: c.regroupement_type,
                couleur_override: c.couleur_override,
                commentaire: c.commentaire,
                duree: c.duree,
            })),
            mode: 'cut',
        };

        // Supprimer les originaux
        const tasks = creneaux.map(c => API.del('creneaux.php?id=' + c.id));
        try {
            await Promise.all(tasks);
            await this._markModified();
            this._clearSelection();
            this._creneaux = await API.get('creneaux.php' + (this._semaineId !== null ? '?semaine_id=' + this._semaineId : '?semaine_id=null'));
            this._creneaux = this._creneaux.map(c => ({ ...c, heure_debut: c.heure_debut?.substring(0, 5) }));
            this._rebuildGrid();
            const status = document.getElementById('status-selection');
            if (status) status.textContent = `${creneaux.length} créneau(x) coupé(s)`;
        } catch (e) {
            Toast.error('Erreur couper : ' + (e.message || ''));
        }
    },

    _findPasteConflicts(targets) {
        const conflicts = new Map();
        const occupancy = this._buildOccupancy();
        targets.forEach((t, i) => {
            const col = this._getCol(parseInt(t.eleve));
            const row = this._getRow(t.heure);
            if (col >= 0 && row >= 0 && occupancy[row + ':' + col] != null) {
                conflicts.set(i, occupancy[row + ':' + col]);
            }
        });
        return conflicts;
    },

    /**
     * Dialogue du collage : même fenêtre que la saisie (factorisée dans `_askConflit`).
     * Les identifiants historiques `paste-*` sont conservés : les tests CDP les ciblent.
     *
     * @param {number} n nombre de cibles en conflit
     * @param {boolean} avecAdultes true si un adulte collé est déjà occupé ailleurs
     */
    async _askPasteConflict(n, avecAdultes = false) {
        const choix = await this._askConflit(n, {
            titre: 'Coller',
            question: avecAdultes
                ? n + ' cible(s) en conflit : une case est déjà occupée, ou un adulte du créneau est déjà pris ailleurs. Que faire ?'
                : n + ' cible(s) déjà occupée(s). Que faire ?',
            ids: { annuler: 'paste-cancel', ignorer: 'paste-skip', ecraser: 'paste-overwrite' },
        });
        return choix === 'annuler' ? 'cancel' : (choix === 'ignorer' ? 'skip' : 'overwrite');
    },

    async _pasteClipboard() {
        if (!this._clipboard || !this._clipboard.creneaux || this._clipboard.creneaux.length === 0) return;

        const targets = Array.from(this._selection.cells.values());
        const sources = this._clipboard.creneaux;
        if (targets.length === 0) return;

        const nbColles = Math.min(sources.length, targets.length);

        // Contrôle 1 : la case visée est déjà occupée (grille du jour affiché).
        const conflicts = this._findPasteConflicts(targets);

        // Contrôle 2 : un adulte du créneau collé est déjà occupé ailleurs au même moment —
        // même règle que la saisie et la pause (décision du 29/09/2026). `_chevauchements`
        // regarde aussi l'élève : on ne garde ici que les conflits d'ADULTE, sans quoi le
        // contrôle 1 serait signalé deux fois.
        const cibles = [];
        for (let i = 0; i < nbColles; i++) {
            cibles.push({
                index: i,
                eleve_id: parseInt(targets[i].eleve),
                jour: this._currentDay,
                heure_debut: targets[i].heure,
                duree: sources[i].duree,
                adulte: sources[i].adulte,
            });
        }
        const conflitsAdultes = this._chevauchements(cibles).filter(c => c.parAdulte > 0);

        let skip = new Set();
        let overwriteIds = [];
        const indicesEnConflit = new Set(conflicts.keys());
        for (const ca of conflitsAdultes) indicesEnConflit.add(ca.cible.index);
        if (indicesEnConflit.size > 0) {
            const choice = await this._askPasteConflict(indicesEnConflit.size, conflitsAdultes.length > 0);
            if (choice === 'cancel') return;
            if (choice === 'skip') skip = indicesEnConflit;
            if (choice === 'overwrite') {
                overwriteIds = [...new Set([
                    ...conflicts.values(),
                    ...conflitsAdultes.flatMap(c => c.occupants.map(o => o.id)),
                ])];
            }
        }

        const tasks = [];
        for (let i = 0; i < nbColles; i++) {
            if (skip.has(i)) continue;
            tasks.push(API.post('creneaux.php', {
                ...sources[i],
                eleve_id: parseInt(targets[i].eleve),
                heure_debut: targets[i].heure,
                jour: this._currentDay,
                semaine_id: this._semaineId !== null ? this._semaineId : undefined,
            }));
        }

        if (tasks.length === 0) { this._clearSelection(); return; }

        const deleteTasks = overwriteIds.map(id => API.del('creneaux.php?id=' + id));

        try {
            await Promise.all([...deleteTasks, ...tasks]);
            await this._markModified();
            this._clearSelection();
            this._creneaux = await API.get('creneaux.php' + (this._semaineId !== null ? '?semaine_id=' + this._semaineId : '?semaine_id=null'));
            this._creneaux = this._creneaux.map(c => ({ ...c, heure_debut: c.heure_debut?.substring(0, 5) }));
            this._rebuildGrid();
            const status = document.getElementById('status-selection');
            if (status) status.textContent = `${tasks.length} créneau(x) collé(s)`;
        } catch (e) {
            Toast.error('Erreur collage : ' + (e.message || ''));
        }
    },

    _hasClipboard() {
        return this._clipboard && this._clipboard.creneaux && this._clipboard.creneaux.length > 0;
    },

});
