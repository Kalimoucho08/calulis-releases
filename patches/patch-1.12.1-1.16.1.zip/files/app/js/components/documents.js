/**
 * Calulis — Documents des élèves (module Documents, version 1.16)
 *
 * CE QUE FAIT CETTE PAGE
 *   Rapatrier DANS Calulis les documents qu'on veut associer à un élève — un scan,
 *   un PDF reçu, une photo, un courrier, un Word — puis les consulter, les modifier,
 *   les remplacer et les supprimer. Le fichier est copié dans le dossier de
 *   l'application (`runtime/documents/eleve-<id>/`) : l'original peut être déplacé,
 *   renommé ou supprimé, le document reste.
 *
 * CE QU'ELLE NE FAIT PAS
 *   Elle n'envoie rien sur Internet et ne lit pas le contenu des documents : c'est
 *   un rangement, pas une analyse.
 *
 * DEUX POINTS DE CONCEPTION
 *   - La liste montre TOUTES les années (`sansAnnee`), pas seulement l'année
 *     sélectionnée : un élève sorti du dispositif doit rester retrouvable, avec
 *     l'ensemble de ses documents (règle du 04/10/2026).
 *   - L'aperçu passe par `API.blob` : le fichier est demandé AVEC le jeton
 *     anti-CSRF, jamais par une URL nue. Le dossier de stockage est hors de la
 *     racine web, donc rien n'est joignable directement.
 */
const Documents = {
    _docs: [],
    _eleves: [],
    _referentiel: { types: {}, extensions: [], taille_max: 0 },
    _filtres: { eleve_id: '', type: '', etat_fichier: '', q: '' },
    _minuteurRecherche: null,
    _objets: [],   // URL d'objets (aperçus) à libérer en quittant la vue
    _surEnregistrement: null,   // appelé après un dépôt fait depuis la fiche élève
    _tri: { col: 'date', dir: 'desc' },   // tri de la liste (date décroissante au départ)
    _voileApercu: null,         // la fenêtre d'aperçu (propre au module, pas la modale)
    _voileFormulaire: null,     // la fenêtre du formulaire de dépôt (idem)
    _voileConfirmation: null,   // la fenêtre de confirmation (idem)
    _pdf: null,    // document pdf.js en cours d'aperçu
    _page: 1,

    /**
     * Charge le référentiel (types, extensions, taille max) UNE fois, et le partage avec
     * la fiche élève : son onglet Documents ouvre le même formulaire de dépôt, et il doit
     * connaître les types même si la page Documents n'a jamais été ouverte.
     */
    async assurerReferentiel(forcer = false) {
        // `forcer` : après une modification des types (ajout, renommage, désactivation),
        // le référentiel en mémoire est périmé — l'éditeur le recharge.
        if (!forcer && Object.keys(this._referentiel.types || {}).length) return this._referentiel;
        try {
            const r = await API.get('documents.php?referentiel=1');
            if (r && r.types) this._referentiel = r;
        } catch (e) {
            console.error('[Documents] référentiel indisponible :', e);
        }
        return this._referentiel;
    },

    /**
     * Charge la liste des élèves UNE fois, et la partage avec la fiche élève : sans ça,
     * ouvrir le formulaire de dépôt depuis une fiche — sans être passé par la page
     * Documents — le laissait sans aucun élève à choisir (défaut trouvé par
     * tests/verif-documents-ui.mjs le 08/10/2026).
     */
    async assurerEleves() {
        if (this._eleves.length) return this._eleves;
        try {
            const eleves = await API.get('eleves.php', { sansAnnee: true });
            this._eleves = (Array.isArray(eleves) ? eleves : [])
                .slice()
                .sort((a, b) => `${a.nom} ${a.prenom}`.localeCompare(`${b.nom} ${b.prenom}`, 'fr'));
        } catch (e) {
            console.error('[Documents] liste des élèves indisponible :', e);
        }
        return this._eleves;
    },

    async render() {
        const view = document.getElementById('view-documents');
        if (!view) return;
        this._libererObjets();
        view.innerHTML = '<p class="text-muted" style="padding:24px">Chargement des documents…</p>';

        try {
            // `sansAnnee` : la liste montre toutes les années, donc le filtre doit aussi
            // proposer les élèves sortis du dispositif (même promesse).
            await Promise.all([this.assurerReferentiel(), this.assurerEleves()]);
        } catch (e) {
            console.error('[Documents] chargement impossible :', e);
            view.innerHTML = '<p class="text-muted" style="padding:24px">Impossible de charger les documents. ' +
                'Vérifiez que la base est démarrée.</p>';
            return;
        }

        this._dessiner();
        await this._charger();
    },

    // ── Rendu ────────────────────────────────────────────────────────────────

    _dessiner() {
        const view = document.getElementById('view-documents');
        view.innerHTML = `
        <div class="page-header">
            <h1>📁 Documents</h1>
            <p class="text-muted" style="margin-top:4px">
                Les documents sont copiés dans Calulis : l'original peut être déplacé ou supprimé,
                le document reste. Rien ne part sur Internet.
            </p>
        </div>
        <div class="filter-bar">
            <label class="sr-only" for="doc-filtre-eleve">Filtrer par élève</label>
            <select id="doc-filtre-eleve" class="filter-input">
                <option value="">Tous les élèves</option>
                ${this._eleves.map(e => `
                    <option value="${e.id}"${String(this._filtres.eleve_id) === String(e.id) ? ' selected' : ''}>
                        ${escapeHtml(this._nomComplet(e))}
                    </option>`).join('')}
            </select>
            <label class="sr-only" for="doc-filtre-type">Filtrer par type de document</label>
            <select id="doc-filtre-type" class="filter-input">
                <option value="">Tous les types</option>
                ${Object.entries(this._referentiel.types || {}).map(([cle, libelle]) => `
                    <option value="${escapeAttr(cle)}"${this._filtres.type === cle ? ' selected' : ''}>
                        ${escapeHtml(libelle)}
                    </option>`).join('')}
            </select>
            <label class="sr-only" for="doc-filtre-etat">Filtrer selon la présence du fichier</label>
            <select id="doc-filtre-etat" class="filter-input">
                <option value="">Fichier ou non</option>
                <option value="avec"${this._filtres.etat_fichier === 'avec' ? ' selected' : ''}>Avec un fichier</option>
                <option value="sans"${this._filtres.etat_fichier === 'sans' ? ' selected' : ''}>Sans copie numérique</option>
            </select>
            <label class="sr-only" for="doc-recherche">Rechercher un document</label>
            <input type="search" id="doc-recherche" class="filter-input" style="flex:1;min-width:180px"
                   placeholder="Rechercher un élève, un document, une note…"
                   value="${escapeAttr(this._filtres.q)}">
            <button type="button" class="btn btn-primary" id="doc-ajouter">＋ Déposer un document</button>
            <button type="button" class="btn btn-secondary" id="doc-types"
                    title="Ajouter, renommer, désactiver ou supprimer un type de document">🏷️ Types de documents</button>
        </div>
        <div id="documents-liste"></div>`;

        this._brancher();
    },

    _brancher() {
        const eleve = document.getElementById('doc-filtre-eleve');
        const type = document.getElementById('doc-filtre-type');
        const etat = document.getElementById('doc-filtre-etat');
        const recherche = document.getElementById('doc-recherche');
        const ajouter = document.getElementById('doc-ajouter');

        if (eleve) eleve.addEventListener('change', () => { this._filtres.eleve_id = eleve.value; this._charger(); });
        if (type) type.addEventListener('change', () => { this._filtres.type = type.value; this._charger(); });
        if (etat) etat.addEventListener('change', () => { this._filtres.etat_fichier = etat.value; this._charger(); });
        if (recherche) {
            recherche.addEventListener('input', () => {
                this._filtres.q = recherche.value;
                clearTimeout(this._minuteurRecherche);
                this._minuteurRecherche = setTimeout(() => this._charger(), 250);
            });
        }
        const types = document.getElementById('doc-types');
        if (types) {
            types.addEventListener('click', () => {
                this.ouvrirEditeurTypes().catch(e => console.error('[Documents] éditeur de types :', e));
            });
        }
        if (ajouter) {
            ajouter.addEventListener('click', () => {
                this._ouvrirFormulaire(null).catch(e => console.error('[Documents] formulaire :', e));
            });
        }

        const liste = document.getElementById('documents-liste');
        if (liste) {
            liste.addEventListener('click', (e) => {
                const th = e.target.closest('th[data-tri]');
                if (th) this._trierDocs(th.dataset.tri);
            });
            liste.addEventListener('click', (e) => {
                const bouton = e.target.closest('button[data-action]');
                if (!bouton) return;
                const doc = this._docs.find(d => String(d.id) === bouton.dataset.id);
                if (!doc) return;
                const action = bouton.dataset.action;
                if (action === 'apercu') this._ouvrirApercu(doc);
                if (action === 'telecharger') this._telecharger(doc);
                if (action === 'fichier') this._choisirFichier(doc);
                if (action === 'modifier') this._ouvrirFormulaire(doc);
                if (action === 'supprimer') this._supprimer(doc);
            });
        }
    },

    // ── Données ──────────────────────────────────────────────────────────────

    async _charger() {
        const cible = document.getElementById('documents-liste');
        if (!cible) return;
        cible.innerHTML = '<p class="text-muted" style="padding:16px">Chargement…</p>';

        const q = new URLSearchParams();
        if (this._filtres.eleve_id) q.set('eleve_id', this._filtres.eleve_id);
        if (this._filtres.type) q.set('type', this._filtres.type);
        if (this._filtres.etat_fichier) q.set('etat_fichier', this._filtres.etat_fichier);
        if (this._filtres.q.trim()) q.set('q', this._filtres.q.trim());
        const requete = 'documents.php' + (q.toString() ? '?' + q.toString() : '');

        try {
            const docs = await API.get(requete, { sansAnnee: true });
            this._docs = Array.isArray(docs) ? docs : [];
        } catch (e) {
            console.error('[Documents] liste impossible :', e);
            cible.innerHTML = '<p class="text-muted" style="padding:16px">Impossible de charger la liste des documents.</p>';
            return;
        }
        this._dessinerListe();
    },

    /** Trie la liste affichée : par date (le plus récent d'abord) au départ. */
    _docsTries() {
        const col = this._tri.col, dir = this._tri.dir === 'asc' ? 1 : -1;
        const valeur = (d) => {
            if (col === 'type') return (this._libelleType(d.type) || '').toLowerCase();
            if (col === 'nom') return (d.nom || '').toLowerCase();
            if (col === 'eleve') return (this._nomEleve(d) || '').toLowerCase();
            if (col === 'date') return d.date_document || '';
            if (col === 'taille') return parseInt(d.fichier_taille || 0, 10) || 0;
            return '';
        };
        return [...this._docs].sort((a, b) => {
            const va = valeur(a), vb = valeur(b);
            if (typeof va === 'number' && typeof vb === 'number') return (va - vb) * dir;
            return String(va).localeCompare(String(vb), 'fr') * dir;
        });
    },

    _trierDocs(col) {
        if (this._tri.col === col) {
            this._tri.dir = this._tri.dir === 'asc' ? 'desc' : 'asc';
        } else {
            // La date descend par défaut (le plus récent d'abord), les autres montent.
            this._tri = { col, dir: col === 'date' ? 'desc' : 'asc' };
        }
        this._dessinerListe();
    },

    /** Marqueur de tri sur l'en-tête (▲ / ▼), comme les autres tableaux du projet. */
    _flecheTri(col) {
        if (this._tri.col !== col) return '';
        return this._tri.dir === 'asc' ? ' ▲' : ' ▼';
    },

    _dessinerListe() {
        const cible = document.getElementById('documents-liste');
        if (!cible) return;

        if (this._docs.length === 0) {
            const filtre = this._filtres.eleve_id || this._filtres.type || this._filtres.q || this._filtres.etat_fichier;
            cible.innerHTML = `
                <div class="dashboard-empty" style="padding:24px">
                    ${filtre
                        ? "Aucun document ne correspond à ces filtres."
                        : "Aucun document pour l'instant. Utilisez « Déposer un document » pour en rapatrier un."}
                </div>`;
            return;
        }

        const docs = this._docsTries();
        const lignes = docs.map(d => {
            const aFichier = !!d.fichier_id;
            return `
            <tr>
                <td>${escapeHtml(this._libelleType(d.type))}</td>
                <td>
                    <strong>${escapeHtml(d.nom)}</strong>
                    ${d.notes ? `<div class="text-muted" style="font-size:12px">${escapeHtml(d.notes)}</div>` : ''}
                </td>
                <td>${d.eleve_id
                    ? escapeHtml(this._nomEleve(d))
                    : '<span class="text-muted">Non rattaché</span>'}</td>
                <td>${escapeHtml(formatDate(d.date_document))}</td>
                <td>${aFichier
                    ? `${escapeHtml(d.fichier_nom || 'fichier')}
                       <div class="text-muted" style="font-size:12px">${escapeHtml(this._taille(d.fichier_taille))}</div>`
                    : '<span class="text-muted">aucun fichier</span>'}</td>
                <td style="white-space:nowrap">
                    ${aFichier ? `
                        <button type="button" class="btn btn-sm" data-action="apercu" data-id="${d.id}"
                                aria-label="Aperçu de ${escapeAttr(d.nom)}">👁 Aperçu</button>
                        <button type="button" class="btn btn-sm" data-action="telecharger" data-id="${d.id}"
                                aria-label="Télécharger ${escapeAttr(d.fichier_nom || d.nom)}">⬇</button>
                        <button type="button" class="btn btn-sm" data-action="fichier" data-id="${d.id}"
                                aria-label="Remplacer le fichier de ${escapeAttr(d.nom)}">🔄</button>`
                    : `
                        <button type="button" class="btn btn-sm btn-primary" data-action="fichier" data-id="${d.id}"
                                aria-label="Joindre un fichier à ${escapeAttr(d.nom)}">📎 Joindre</button>`}
                    <button type="button" class="btn btn-sm" data-action="modifier" data-id="${d.id}"
                            aria-label="Modifier ${escapeAttr(d.nom)}">✏️</button>
                    <button type="button" class="btn btn-sm btn-danger" data-action="supprimer" data-id="${d.id}"
                            aria-label="Supprimer ${escapeAttr(d.nom)}">🗑</button>
                </td>
            </tr>`;
        }).join('');

        cible.innerHTML = `
            <p class="text-muted" style="margin:0 0 8px">
                ${this._docs.length} document${this._docs.length > 1 ? 's' : ''}${this._totalDocuments()}
            </p>
            <table class="data-table">
                <caption class="sr-only">Liste des documents rapatriés dans Calulis</caption>
                <thead>
                    <tr>
                        <th scope="col" class="sortable" data-tri="type">Type${this._flecheTri('type')}</th>
                        <th scope="col" class="sortable" data-tri="nom">Document${this._flecheTri('nom')}</th>
                        <th scope="col" class="sortable" data-tri="eleve">Élève${this._flecheTri('eleve')}</th>
                        <th scope="col" class="sortable" data-tri="date">Date${this._flecheTri('date')}</th>
                        <th scope="col" class="sortable" data-tri="taille">Fichier${this._flecheTri('taille')}</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>${lignes}</tbody>
            </table>`;
    },

    // ── Formulaire (dépôt et modification) ───────────────────────────────────

    /**
     * Ouvre le formulaire de dépôt ou de modification.
     *
     * @param doc               le document à modifier, ou null pour un dépôt
     * @param eleveParDefaut    l'élève présélectionné (la fiche élève passe le sien)
     * @param surEnregistrement appelé après un enregistrement réussi — la fiche élève
     *                          recharge sa propre liste, elle n'a pas de `#documents-liste`
     */
    async _ouvrirFormulaire(doc, eleveParDefaut = null, surEnregistrement = null) {
        const creation = !doc;
        await Promise.all([this.assurerReferentiel(), this.assurerEleves()]);
        this._surEnregistrement = typeof surEnregistrement === 'function' ? surEnregistrement : null;
        const types = Object.entries(this._referentiel.types || {});
        const eleveId = creation
            ? (eleveParDefaut || this._filtres.eleve_id || '')
            : (doc.eleve_id || '');
        const accept = (this._referentiel.extensions || []).map(e => '.' + e).join(',');

        const corps = `
            <div class="form-row">
                <div class="form-group">
                    <label for="doc-form-eleve">Élève</label>
                    <select id="doc-form-eleve">
                        <option value="">— Non rattaché —</option>
                        ${this._eleves.map(e => `
                            <option value="${e.id}"${String(eleveId) === String(e.id) ? ' selected' : ''}>
                                ${escapeHtml(this._nomComplet(e))}
                            </option>`).join('')}
                    </select>
                </div>
                <div class="form-group">
                    <label for="doc-form-type">Type de document</label>
                    <select id="doc-form-type">
                        ${types.map(([cle, libelle]) => `
                            <option value="${escapeAttr(cle)}"${(doc ? doc.type : 'autre') === cle ? ' selected' : ''}>
                                ${escapeHtml(libelle)}
                            </option>`).join('')}
                    </select>
                </div>
            </div>
            <div class="form-group">
                <label for="doc-form-nom">Nom du document <span aria-hidden="true">*</span></label>
                <input type="text" id="doc-form-nom" maxlength="300" required
                       value="${doc ? escapeAttr(doc.nom) : ''}"
                       placeholder="Ex. Notification MDPH 2026">
            </div>
            <div class="form-group">
                <label for="doc-form-date">Date du document</label>
                <input type="date" id="doc-form-date"
                       value="${escapeAttr(doc ? (doc.date_document || '') : aujourdhui())}">
            </div>
            <div class="form-group">
                <label for="doc-form-fichier">Fichier ${creation ? '' : '(laisser vide pour conserver l\'actuel)'}</label>
                <input type="file" id="doc-form-fichier" accept="${escapeAttr(accept)}">
                <div class="text-muted" style="font-size:12px;margin-top:4px">
                    Formats acceptés : ${escapeHtml((this._referentiel.extensions || []).join(', '))} —
                    ${escapeHtml(this._taille(this._referentiel.taille_max))} au maximum.
                </div>
            </div>
            <div class="form-group">
                <label for="doc-form-notes">Notes</label>
                <textarea id="doc-form-notes" rows="3">${doc ? escapeHtml(doc.notes || '') : ''}</textarea>
            </div>`;

        // FENÊTRE PROPRE AU FORMULAIRE, comme l'aperçu : ouvert depuis la fiche élève, ce
        // formulaire remplaçait la fiche dans la modale partagée, et « Annuler » la faisait
        // disparaître (l'élève était perdu de vue, une saisie en cours aussi). Défaut
        // trouvé par tests/verif-documents-ui.mjs le 08/10/2026.
        this._fermerFormulaire();
        const voile = document.createElement('div');
        voile.id = 'doc-form-voile';
        voile.className = 'modal-backdrop';
        voile.innerHTML = `
            <div class="modal" role="dialog" aria-modal="true"
                 aria-label="${escapeAttr(creation ? 'Déposer un document' : 'Modifier le document')}">
                <div class="modal-header">
                    <h3>${creation ? 'Déposer un document' : 'Modifier le document'}</h3>
                    <button type="button" class="modal-close" id="doc-form-fermer" style="min-width:24px;min-height:24px" aria-label="Fermer">✕</button>
                </div>
                <div class="modal-body" id="doc-form-corps">${corps}</div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" id="doc-form-annuler">Annuler</button>
                    <button type="button" class="btn btn-primary" id="doc-form-enregistrer">Enregistrer</button>
                </div>
            </div>`;
        document.body.appendChild(voile);
        this._voileFormulaire = voile;
        // Comme pour l'aperçu : en phase de capture, Échap ferme CE formulaire et laisse
        // la fiche (ouverte en dessous) intacte.
        this._toucheFormulaire = (ev) => {
            if (ev.key === 'Escape') {
                ev.stopPropagation();
                ev.preventDefault();
                this._fermerFormulaire();
            }
        };
        document.addEventListener('keydown', this._toucheFormulaire, true);
        if (typeof linkLabels === 'function') linkLabels(document.getElementById('doc-form-corps'));

        // Le nom se remplit tout seul à partir du fichier choisi (modifiable).
        const champFichier = document.getElementById('doc-form-fichier');
        if (champFichier) {
            champFichier.addEventListener('change', () => {
                const f = champFichier.files && champFichier.files[0];
                const champNom = document.getElementById('doc-form-nom');
                if (f && champNom && !champNom.value.trim()) {
                    champNom.value = f.name.replace(/\.[^.]+$/, '');
                }
            });
        }
        document.getElementById('doc-form-fermer').addEventListener('click', () => this._fermerFormulaire());
        document.getElementById('doc-form-annuler').addEventListener('click', () => this._fermerFormulaire());
        document.getElementById('doc-form-enregistrer').addEventListener('click', () => this._enregistrer(doc));
        const premier = document.getElementById('doc-form-nom');
        if (premier) setTimeout(() => premier.focus(), 100);
    },

    async _enregistrer(doc) {
        const valeur = (id) => {
            const el = document.getElementById(id);
            return el ? el.value.trim() : '';
        };
        const nom = valeur('doc-form-nom');
        const champFichier = document.getElementById('doc-form-fichier');
        const fichier = champFichier && champFichier.files ? champFichier.files[0] : null;

        if (!nom && !fichier) {
            Toast.error('Donnez un nom au document.');
            return;
        }
        if (fichier && this._referentiel.taille_max && fichier.size > this._referentiel.taille_max) {
            Toast.error(`Le fichier est trop volumineux (${this._taille(fichier.size)}). ` +
                `La limite est de ${this._taille(this._referentiel.taille_max)}.`);
            return;
        }

        const donnees = {
            nom: nom || fichier.name.replace(/\.[^.]+$/, ''),
            type: valeur('doc-form-type') || 'autre',
            eleve_id: valeur('doc-form-eleve'),
            date_document: valeur('doc-form-date'),
            notes: valeur('doc-form-notes'),
        };

        const bouton = document.getElementById('doc-form-enregistrer');
        if (bouton) bouton.disabled = true;

        try {
            if (!doc) {
                const fd = new FormData();
                Object.entries(donnees).forEach(([cle, val]) => { if (val !== '') fd.append(cle, val); });
                if (fichier) fd.append('fichier', fichier);
                await API.upload('documents.php', fd);
                Toast.success('Document enregistré.');
            } else {
                await API.put(`documents.php?id=${doc.id}`, donnees);
                if (fichier) {
                    const fd = new FormData();
                    fd.append('fichier', fichier);
                    await API.upload(`documents.php?id=${doc.id}&fichier=1`, fd);
                }
                Toast.success('Document modifié.');
            }
            this._fermerFormulaire();
            await this._charger();
            // Point d'accroche : la fiche élève recharge sa liste de documents.
            const apres = this._surEnregistrement;
            this._surEnregistrement = null;
            if (apres) { await apres(); }
        } catch (e) {
            console.error('[Documents] enregistrement impossible :', e);
            Toast.error(e.message || 'Enregistrement impossible.');
            if (bouton) bouton.disabled = false;
        }
    },

    // ── Fichier : joindre, remplacer, télécharger, apercevoir, supprimer ─────

    _choisirFichier(doc) {
        const input = document.createElement('input');
        input.type = 'file';
        input.accept = (this._referentiel.extensions || []).map(e => '.' + e).join(',');
        input.style.display = 'none';
        document.body.appendChild(input);
        input.addEventListener('change', async () => {
            const fichier = input.files && input.files[0];
            input.remove();
            if (!fichier) return;
            if (this._referentiel.taille_max && fichier.size > this._referentiel.taille_max) {
                Toast.error(`Le fichier est trop volumineux (${this._taille(fichier.size)}). ` +
                    `La limite est de ${this._taille(this._referentiel.taille_max)}.`);
                return;
            }
            try {
                const fd = new FormData();
                fd.append('fichier', fichier);
                await API.upload(`documents.php?id=${doc.id}&fichier=1`, fd);
                Toast.success(doc.fichier_id ? 'Fichier remplacé.' : 'Fichier joint.');
                await this._charger();
            } catch (e) {
                console.error('[Documents] envoi impossible :', e);
                Toast.error(e.message || 'Envoi impossible.');
            }
        });
        input.click();
    },

    async _telecharger(doc) {
        if (!doc.fichier_id) return;
        try {
            const blob = await API.blob(`documents.php?id=${doc.id}&fichier=1`);
            const url = URL.createObjectURL(blob);
            const lien = document.createElement('a');
            lien.href = url;
            lien.download = doc.fichier_nom || doc.nom;
            document.body.appendChild(lien);
            lien.click();
            lien.remove();
            setTimeout(() => URL.revokeObjectURL(url), 10000);
        } catch (e) {
            console.error('[Documents] téléchargement impossible :', e);
            Toast.error(e.message || 'Téléchargement impossible.');
        }
    },

    async _ouvrirApercu(doc) {
        if (!doc.fichier_id) {
            Toast.info('Ce document n\'a pas encore de fichier.');
            return;
        }

        let blob;
        try {
            blob = await API.blob(`documents.php?id=${doc.id}&fichier=1`);
        } catch (e) {
            console.error('[Documents] aperçu impossible :', e);
            Toast.error(e.message || 'Ouverture impossible.');
            return;
        }

        const url = URL.createObjectURL(blob);
        this._objets.push(url);
        const mime = doc.fichier_mime || blob.type || '';
        const estPdf = mime === 'application/pdf';
        const estImage = mime.indexOf('image/') === 0;

        // FENÊTRE PROPRE À L'APERÇU, et non la fenêtre modale partagée : sinon ouvrir
        // l'aperçu d'un document DEPUIS LA FICHE ÉLÈVE remplaçait la fiche (même modale),
        // et le fermer la faisait disparaître — une saisie en cours était perdue. Défaut
        // trouvé par tests/verif-documents-ui.mjs le 08/10/2026.
        if (this._voileApercu) { this._fermerApercu(); }
        const voile = document.createElement('div');
        voile.id = 'doc-apercu-voile';
        voile.className = 'apercu-voile';
        voile.innerHTML = `
            <div class="apercu-fenetre" role="dialog" aria-modal="true"
                 aria-label="Aperçu de ${escapeAttr(doc.nom)}">
                <div class="apercu-tete" style="display:flex;justify-content:space-between;
                     align-items:center;gap:8px;margin-bottom:8px">
                    <strong style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">${escapeHtml(doc.nom)}</strong>
                    <div style="display:flex;gap:6px;flex:none">
                        <button type="button" class="btn btn-sm" id="doc-apercu-telecharger">Télécharger</button>
                        <button type="button" class="btn btn-sm" id="doc-apercu-fermer"
                                aria-label="Fermer l'aperçu">✕</button>
                    </div>
                </div>
                <div id="doc-apercu-barre" style="display:${estPdf ? 'flex' : 'none'};gap:8px;
                     justify-content:center;align-items:center;margin-bottom:8px">
                    <button type="button" class="btn btn-sm" id="doc-page-prec" aria-label="Page précédente">◀</button>
                    <span class="text-muted" id="doc-page-info"></span>
                    <button type="button" class="btn btn-sm" id="doc-page-suiv" aria-label="Page suivante">▶</button>
                </div>
                <div id="doc-apercu-zone" style="flex:1;overflow:auto;text-align:center"></div>
            </div>`;
        document.body.appendChild(voile);
        this._voileApercu = voile;
        // La touche Échap ferme l'aperçu — et RIEN d'autre : en phase de capture, cet
        // écouteur passe avant celui de la modale, qui fermerait la fiche en dessous.
        this._toucheApercu = (ev) => {
            if (ev.key === 'Escape') {
                ev.stopPropagation();
                ev.preventDefault();
                this._fermerApercu();
            }
        };
        document.addEventListener('keydown', this._toucheApercu, true);

        const zone = document.getElementById('doc-apercu-zone');
        document.getElementById('doc-apercu-fermer').addEventListener('click', () => this._fermerApercu());
        document.getElementById('doc-apercu-telecharger').addEventListener('click', () => this._telecharger(doc));

        if (estImage) {
            zone.innerHTML = `<img src="${url}" alt="Aperçu de ${escapeAttr(doc.nom)}"
                style="max-width:100%;max-height:70vh;border-radius:6px">`;
            return;
        }
        if (mime === 'text/plain') {
            try {
                const texte = await blob.text();
                zone.innerHTML = `<pre style="text-align:left;white-space:pre-wrap;max-height:65vh;overflow:auto;
                    background:var(--surface-alt);padding:12px;border-radius:6px">${escapeHtml(texte)}</pre>`;
            } catch {
                zone.innerHTML = '<p>Le texte n\'a pas pu être affiché. Utilisez « Télécharger ».</p>';
            }
            return;
        }
        if (estPdf) {
            await this._afficherPdf(await blob.arrayBuffer(), zone);
            return;
        }
        zone.innerHTML = `<p>L'aperçu n'est pas disponible pour ce format
            (${escapeHtml(mime || 'inconnu')}).<br>Utilisez « Télécharger » pour l'ouvrir avec
            le logiciel de votre ordinateur.</p>`;
    },

    /** Rend la page courante d'un PDF avec le moteur pdf.js livré dans le paquet. */
    async _afficherPdf(donnees, zone) {
        try {
            this._pdf = await pdfjsLib.getDocument({ data: donnees }).promise;
            this._page = 1;
            zone.innerHTML = '<canvas id="doc-apercu-canvas" style="max-width:100%;border:1px solid var(--border);border-radius:6px"></canvas>';
            document.getElementById('doc-page-prec').addEventListener('click', () => this._pagePdf(-1));
            document.getElementById('doc-page-suiv').addEventListener('click', () => this._pagePdf(1));
            await this._rendrePagePdf();
        } catch (e) {
            console.error('[Documents] lecture du PDF impossible :', e);
            this._pdf = null;
            const barre = document.getElementById('doc-apercu-barre');
            if (barre) barre.style.display = 'none';
            zone.innerHTML = '<p>Ce PDF n\'a pas pu être affiché.<br>Utilisez « Télécharger » pour l\'ouvrir à l\'extérieur.</p>';
        }
    },

    async _pagePdf(pas) {
        if (!this._pdf) return;
        const page = this._page + pas;
        if (page < 1 || page > this._pdf.numPages) return;
        this._page = page;
        await this._rendrePagePdf();
    },

    async _rendrePagePdf() {
        const canvas = document.getElementById('doc-apercu-canvas');
        if (!canvas || !this._pdf) return;
        const page = await this._pdf.getPage(this._page);
        const largeurDispo = 560;
        const base = page.getViewport({ scale: 1 });
        const echelle = Math.min(1.5, largeurDispo / base.width);
        const viewport = page.getViewport({ scale: echelle });
        canvas.width = viewport.width;
        canvas.height = viewport.height;
        await page.render({ canvasContext: canvas.getContext('2d'), viewport }).promise;
        const info = document.getElementById('doc-page-info');
        if (info) info.textContent = `Page ${this._page} / ${this._pdf.numPages}`;
    },

    /**
     * Confirmation dans SA propre fenêtre, comme l'aperçu et le formulaire : la modale
     * partagée remplacerait la fiche élève, et on supprime justement un document depuis
     * la fiche. Rend une promesse de booléen.
     */
    _confirmer(titre, html, libelleOk = 'Confirmer', idChamp = null) {
        return new Promise((resoudre) => {
            this._fermerConfirmation();
            const voile = document.createElement('div');
            voile.id = 'doc-confirm-voile';
            voile.className = 'modal-backdrop';
            voile.innerHTML = `
                <div class="modal" role="dialog" aria-modal="true" aria-label="${escapeAttr(titre)}">
                    <div class="modal-header"><h3>${escapeHtml(titre)}</h3></div>
                    <div class="modal-body" style="min-height:0">${html}</div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" id="doc-confirm-annuler">Annuler</button>
                        <button type="button" class="btn btn-danger" id="doc-confirm-ok">${escapeHtml(libelleOk)}</button>
                    </div>
                </div>`;
            document.body.appendChild(voile);
            this._voileConfirmation = voile;
            this._reponseConfirmation = resoudre;
            this._toucheConfirmation = (ev) => {
                if (ev.key === 'Escape') {
                    ev.stopPropagation();
                    ev.preventDefault();
                    this._repondreConfirmation(false);
                }
            };
            document.addEventListener('keydown', this._toucheConfirmation, true);
            document.getElementById('doc-confirm-annuler')
                .addEventListener('click', () => this._repondreConfirmation(false));
            document.getElementById('doc-confirm-ok').addEventListener('click', () => {
                // `idChamp` : on rend la VALEUR du champ (choisir un type de destination),
                // lue AVANT que la fenêtre ne soit retirée. Sans champ : `true`.
                const valeur = idChamp ? ((document.getElementById(idChamp) || {}).value || '') : true;
                this._repondreConfirmation(valeur);
            });
            // Le focus part sur « Annuler » : une suppression se refuse par défaut.
            document.getElementById('doc-confirm-annuler').focus();
        });
    },

    _repondreConfirmation(reponse) {
        const resoudre = this._reponseConfirmation;
        this._reponseConfirmation = null;
        this._fermerConfirmation();
        if (resoudre) resoudre(reponse);
    },

    _fermerConfirmation() {
        if (this._toucheConfirmation) {
            document.removeEventListener('keydown', this._toucheConfirmation, true);
            this._toucheConfirmation = null;
        }
        if (this._voileConfirmation) {
            this._voileConfirmation.remove();
            this._voileConfirmation = null;
        }
    },

    _fermerFormulaire() {
        if (this._toucheFormulaire) {
            document.removeEventListener('keydown', this._toucheFormulaire, true);
            this._toucheFormulaire = null;
        }
        if (this._voileFormulaire) {
            this._voileFormulaire.remove();
            this._voileFormulaire = null;
        }
    },

    _fermerApercu() {
        this._pdf = null;
        this._page = 1;
        if (this._toucheApercu) {
            document.removeEventListener('keydown', this._toucheApercu, true);
            this._toucheApercu = null;
        }
        if (this._voileApercu) {
            this._voileApercu.remove();
            this._voileApercu = null;
        }
        this._libererObjets();
    },

    /** Libère les URL d'objets : sans ça, chaque aperçu garde le fichier en mémoire. */
    _libererObjets() {
        this._objets.forEach(url => {
            try { URL.revokeObjectURL(url); } catch { /* déjà libérée */ }
        });
        this._objets = [];
    },

    async _supprimer(doc) {
        const aFichier = doc.fichier_id;
        const ok = await this._confirmer(
            'Supprimer ce document',
            `Supprimer définitivement « ${escapeHtml(doc.nom)} » ?` +
            (aFichier
                ? '<br><br>Le fichier rapatrié sera <strong>supprimé du disque</strong>. ' +
                  'Si vous voulez le garder, utilisez d\'abord « Télécharger ».'
                : ''),
            'Supprimer'
        );
        if (!ok) return;
        try {
            const reponse = await API.del(`documents.php?id=${doc.id}`);
            // L'API dit combien de fichiers n'ont PAS pu être effacés : le taire ferait
            // croire à une suppression complète alors qu'un document (parfois médical)
            // reste sur le disque — enjeu de confidentialité, pas de confort.
            if (reponse && reponse.fichiers_restants > 0) {
                Toast.show("La fiche du document a été supprimée, mais le fichier n'a pas pu être " +
                    "effacé du disque (il est peut-être ouvert ailleurs). Vérifiez le dossier des " +
                    "documents de l'installation.", 'error');
            } else {
                Toast.success('Document supprimé.');
            }
            await this._charger();
        } catch (e) {
            console.error('[Documents] suppression impossible :', e);
            Toast.error(e.message || 'Suppression impossible.');
        }
    },

    // ── Petits utilitaires ───────────────────────────────────────────────────

    _nomComplet(e) {
        return `${e.nom || ''} ${e.prenom || ''}`.trim();
    },

    _nomEleve(doc) {
        const complet = `${doc.eleve_nom || ''} ${doc.eleve_prenom || ''}`.trim();
        return complet || ('Élève ' + doc.eleve_id);
    },

    _libelleType(cle) {
        // `types_tous` d'abord : un type DÉSACTIVÉ n'est plus proposé, mais un document
        // classé avec lui doit continuer d'afficher son nom, pas sa clé technique.
        const tous = this._referentiel.types_tous || {};
        return tous[cle] || (this._referentiel.types || {})[cle] || cle || 'Document';
    },

    /** Total des fichiers rapatriés, dit en clair (« · 1,2 Mo »). Rien s'il n'y a rien. */
    _totalDocuments() {
        const octets = this._docs.reduce((n, d) => n + (parseInt(d.fichier_taille || 0, 10) || 0), 0);
        if (!octets) return '';
        return ` · ${this._taille(octets)} de fichiers`;
    },

    /**
     * Taille d'un fichier, dite en clair. Le calcul vit dans `format.js` (source unique,
     * partagée avec la suppression d'un élève) ; ici on ne fait que nommer l'absence.
     */
    _taille(octets) {
        return formatOctets(octets, 'taille inconnue');
    },
};
