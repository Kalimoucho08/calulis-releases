/**
 * Calulis — Print Stats : builders statistiques (pdfmake)
 * Attaché à l'objet Print via Object.assign
 *
 * Depuis le 01/10/2026, l'export Statistiques est composé de **blocs indépendants** que
 * l'utilisateur coche (cases à cocher de l'onglet Statistiques) : le PDF enchaîne les blocs
 * choisis, chacun sur sa page.
 *
 * Le **catalogue `_statsBlocs()` est la source unique** : l'interface (print.js) et la
 * génération lisent la même liste. Ajouter un bloc = une entrée ici + un cas dans
 * `_contenuStats()`, jamais deux listes à tenir en parallèle.
 *
 * ⚠️ pdfmake n'a qu'UNE orientation par document : dès qu'un bloc large (tableau large,
 * `large: true`) est coché, tout le PDF passe en paysage. C'est une contrainte de la
 * bibliothèque, pas un choix d'ergonomie.
 */

Object.assign(Print, {

    /* ═══════════════════════════════════════════
       Export Statistiques — catalogue des blocs
       ═══════════════════════════════════════════ */

    /** Catalogue des blocs imprimables. L'ORDRE de cette liste est l'ordre du PDF. */
    _statsBlocs() {
        return [
            { id: 'kpi', icone: '🔢', label: 'Indicateurs clés', desc: 'effectifs, cantine, PEC', large: false, defaut: true },
            { id: 'inclusion_resume', icone: '📈', label: 'Inclusion (résumé)', desc: 'heures, % du temps', large: false, defaut: true },
            { id: 'pec', icone: '🏥', label: 'Prises en charge (PEC)', desc: 'par organisme', large: false, defaut: true },
            { id: 'cantine', icone: '🍽️', label: 'Cantine & Transport', desc: 'effectifs, transport', large: false, defaut: true },
            { id: 'mdph', icone: '📋', label: 'Notifications MDPH', desc: 'notifiés, échéances', large: false, defaut: true },
            { id: 'anciennete', icone: '⏳', label: 'Ancienneté', desc: 'répartition par années', large: false, defaut: true },
            { id: 'ecoles', icone: '🏫', label: 'Écoles d\'origine', desc: 'par école', large: false, defaut: true },
            { id: 'entrees', icone: '🚪', label: 'Entrées / Sorties', desc: 'par année', large: false, defaut: true },
            { id: 'adultes', icone: '👩‍🏫', label: 'Par adulte', desc: 'heures, élèves suivis, par type', large: false, defaut: false },
            { id: 'inclusion_eleves', icone: '👥', label: 'Inclusion — par élève', desc: 'A4 paysage · heures par période', large: true, defaut: false },
            { id: 'inclusion_periodes', icone: '📆', label: 'Inclusion — par période', desc: 'A4 paysage · trimestres', large: true, defaut: false },
            { id: 'evolution', icone: '📉', label: 'Évolution multi-année', desc: 'A4 paysage · historique', large: true, defaut: false },
        ];
    },

    async _loadStats() {
        const anneeId = typeof State !== 'undefined' ? State.get('annee_scolaire_id') : null;
        const toutes = typeof State !== 'undefined' ? State.get('toutes_periodes') : false;
        const params = toutes ? '' : (anneeId ? '?annee_scolaire_id=' + anneeId : '');
        return API.get('stats.php' + params);
    },

    async _generateStats() {
        const cases = [...document.querySelectorAll('input[name="print-stats-bloc"]')];
        const choisis = this._statsBlocs().filter(b => {
            const c = cases.find(x => x.value === b.id);
            return c && c.checked;
        });
        if (!choisis.length) {
            Modal.alert('Erreur', 'Cochez au moins une statistique à imprimer.');
            return;
        }

        const btn = document.getElementById('btn-print-generate');
        btn.disabled = true;
        btn.textContent = '⏳ Génération…';

        try {
            const data = await this._loadStats();
            const def = this._composerStats(choisis, data);
            const tous = this._statsBlocs().length;
            const filename = choisis.length === tous
                ? 'statistiques_complet.pdf'
                : 'statistiques_' + choisis.map(b => b.id).join('_') + '.pdf';
            this._showPreview(def, filename);
        } catch (e) {
            console.error('[Print] stats error:', e);
            if (typeof Modal !== 'undefined' && Modal.alert) {
                Modal.alert('Erreur', 'Impossible de générer les statistiques : ' + (e.message || 'Erreur inconnue'));
            }
        } finally {
            btn.disabled = false;
            btn.textContent = '🖨️ Générer l\'aperçu';
        }
    },

    /** Compose le document à partir des blocs CHOISIS (dans l'ordre du catalogue). */
    _composerStats(choisis, data) {
        const large = choisis.some(b => b.large);
        const today = new Date().toLocaleDateString('fr-FR');
        const content = [
            { text: 'Statistiques ULIS', style: 'header', margin: [0, 0, 0, 2] },
            { text: `Généré le ${today}`, style: 'subheader', margin: [0, 0, 0, 12] },
        ];
        choisis.forEach((b, i) => {
            // Chaque bloc commence sur une page : un PDF de statistiques se lit par bloc,
            // et un tableau large ne doit pas être coupé au milieu par le bloc précédent.
            if (i > 0) content.push({ text: '', pageBreak: 'before' });
            content.push(...this._contenuStats(b.id, data));
        });
        return {
            pageSize: 'A4',
            pageOrientation: large ? 'landscape' : 'portrait',
            pageMargins: large ? [15, 15, 15, 15] : [20, 20, 20, 20],
            content,
            defaultStyle: { fontSize: large ? 8 : 9 },
            styles: {
                header: { fontSize: 15, bold: true, alignment: 'center', margin: [0, 0, 0, 2] },
                subheader: { fontSize: 9, alignment: 'center', color: '#666', margin: [0, 0, 0, 12] },
                sectionTitle: { fontSize: 11, bold: true, margin: [0, 6, 0, 4], color: '#2c3e50' },
            },
        };
    },

    /** Contenu d'UN bloc (sans l'en-tête du document). Renvoie un tableau de nœuds pdfmake. */
    _contenuStats(id, data) {
        switch (id) {
            case 'kpi': return this._blocKpi(data);
            case 'inclusion_resume': return this._blocInclusionResume(data);
            case 'pec': return this._blocPec(data);
            case 'cantine': return this._blocCantine(data);
            case 'mdph': return this._blocMdph(data);
            case 'anciennete': return this._blocAnciennete(data);
            case 'ecoles': return this._blocEcoles(data);
            case 'entrees': return this._blocEntrees(data);
            case 'adultes': return this._blocAdultes(data);
            case 'inclusion_eleves': return this._blocInclusionEleves(data);
            case 'inclusion_periodes': return this._blocInclusionPeriodes(data);
            case 'evolution': return this._blocEvolution(data);
        }
        return [];
    },

    /** Titre d'un tableau + sous-titre optionnel (gardé compact dans le PDF). */
    _sectionStats(titre, tableDef, sousTitre) {
        const items = [];
        if (titre) items.push({ text: titre, style: 'sectionTitle' });
        if (sousTitre) items.push({ text: sousTitre, fontSize: 8, color: '#666', margin: [0, 0, 0, 3] });
        items.push(tableDef);
        return { stack: items, unbreakable: true, margin: [0, 0, 0, 6] };
    },

    /* ═══════════════════════════════════════════
       Les blocs
       ═══════════════════════════════════════════ */

    _blocKpi(data) {
        const kpi = data.kpi || {};
        return [this._sectionStats('Indicateurs clés', {
            table: {
                headerRows: 0, widths: ['*', 'auto', '*', 'auto'],
                body: [
                    ['Effectif total', String(kpi.total || 0), 'Élèves ULIS', String(kpi.ulis || 0)],
                    ['Cantine', String(kpi.cantine || 0), 'Transport taxi', String(kpi.taxi || 0)],
                    ['Avec PEC', String(kpi.pec || 0), '', ''],
                ],
            },
            layout: { fillColor: (i) => i % 2 === 0 ? '#f9f9f9' : null },
        })];
    },

    _blocInclusionResume(data) {
        const inc = data.inclusion || {};
        const h = (v) => v != null ? String(v) + ' h' : '—';
        const p = (v) => v != null ? String(v) + ' %' : '—';
        return [this._sectionStats('Inclusion', {
            table: {
                headerRows: 0, widths: ['*', 'auto'],
                body: [
                    ['Heures totales sur l\'année', h(inc.total_heures_annee)],
                    ['Heures par semaine (total)', h(inc.heures_par_semaine)],
                    ['Moyenne par élève / semaine', h(inc.moyenne_heures_eleve)],
                    ['Semaines scolaires', inc.nb_semaines_scolaires != null ? String(inc.nb_semaines_scolaires) : '—'],
                    ['Heures école / semaine', h(inc.heures_ecole_semaine)],
                    ['% du temps total', p(inc.pourcentage_temps_total)],
                ],
            },
            layout: { fillColor: (i) => i % 2 === 0 ? '#f9f9f9' : null },
        })];
    },

    _blocPec(data) {
        const pec = data.pec || {};
        const pecSpecs = pec.par_specialite || [];
        if (!pecSpecs.length) {
            return [this._sectionStats('Prises en charge (PEC)', {
                text: 'Aucune PEC renseignée.', color: '#999', margin: [0, 0, 0, 6],
            })];
        }
        const pecBody = [['Organisme', 'Spécialités', 'Nb', 'Élèves concernés']];
        pecSpecs.forEach(x => pecBody.push([
            x.pec_organisme || '', x.pec_specialites || '', String(x.nb_eleves || 0), x.eleves_noms || '',
        ]));
        return [this._sectionStats('Prises en charge (PEC)', {
            table: { headerRows: 1, widths: ['auto', 'auto', 'auto', '*'], body: pecBody },
            fontSize: 8,
        })];
    },

    _blocCantine(data) {
        const ct = data.cantine_transport || {};
        const items = [
            { text: 'Cantine & Transport', style: 'sectionTitle' },
            {
                table: {
                    headerRows: 0, widths: ['*', 'auto'],
                    body: [['Cantine', ct.cantine != null ? `${ct.cantine} élèves (${ct.cantine_pourcent || 0}%)` : '—']],
                },
                layout: { fillColor: (i) => i % 2 === 0 ? '#f9f9f9' : null },
            },
        ];
        const transp = ct.transport || [];
        if (transp.length) {
            const tBody = [['Transport', 'Nb élèves']];
            transp.forEach(t => tBody.push([t.transport || '', String(t.nb || 0)]));
            items.push({ table: { headerRows: 1, widths: ['*', 'auto'], body: tBody }, fontSize: 8, margin: [0, 4, 0, 0] });
        }
        return [{ stack: items, unbreakable: true, margin: [0, 0, 0, 6] }];
    },

    _blocMdph(data) {
        const mdph = data.mdph || {};
        const mdphBody = [['Type', 'Notifiés', 'Échéance ≤ 90j', 'Expirés']];
        Object.entries(mdph).forEach(([type, vals]) => {
            mdphBody.push([type, String(vals.notifies || 0), String(vals.echeance || 0), String(vals.expires || 0)]);
        });
        return [this._sectionStats('Notifications MDPH', {
            table: { headerRows: 1, widths: ['*', 'auto', 'auto', 'auto'], body: mdphBody },
            fontSize: 8,
        })];
    },

    _blocAnciennete(data) {
        const anc = data.anciennete || {};
        const r = anc.repartition || {};
        return [this._sectionStats('Ancienneté dans le dispositif', {
            table: {
                headerRows: 0, widths: ['*', 'auto'],
                body: [
                    ['Moyenne', anc.moyenne != null ? String(anc.moyenne) : '—'],
                    ['Moins d’un an', String(r['moins1'] || 0)],
                    ['1 an', String(r[1] || 0)],
                    ['2 ans', String(r[2] || 0)],
                    ['3 ans', String(r[3] || 0)],
                    ['4+ ans', String(r['4plus'] || 0)],
                ],
            },
            layout: { fillColor: (i) => i % 2 === 0 ? '#f9f9f9' : null },
        })];
    },

    _blocEcoles(data) {
        const eco = data.ecoles_origine || {};
        const ecoles = eco.ecoles || [];
        if (!ecoles.length) return [];
        const ecoBody = [['École', 'Type', 'Nb élèves']];
        ecoles.slice(0, 10).forEach(e => ecoBody.push([e.ecole_nom || '', e.ecole_type || '', String(e.nb_eleves || 0)]));
        return [this._sectionStats('Écoles d\'origine', {
            table: { headerRows: 1, widths: ['*', 'auto', 'auto'], body: ecoBody },
            fontSize: 8,
        })];
    },

    _blocEntrees(data) {
        const es = data.entrees_sorties || {};
        const parAnnee = es.par_annee || [];
        if (!parAnnee.length) return [];
        const esBody = [['Année', 'Effectif', 'Entrées', 'Sorties']];
        parAnnee.forEach(a => esBody.push([a.nom || '', String(a.effectif || 0), String(a.entrees || 0), String(a.sorties || 0)]));
        return [this._sectionStats('Entrées / Sorties', {
            table: { headerRows: 1, widths: ['*', 'auto', 'auto', 'auto'], body: esBody },
            fontSize: 8,
        })];
    },

    /** Heures par semaine, élèves suivis et répartition par type, pour chaque adulte. */
    _blocAdultes(data) {
        const ad = data.adultes || {};
        const adultes = ad.par_adulte || [];
        const types = ad.types || [];
        const sans = ad.sans_adulte || {};
        const nbSem = ad.nb_semaines_scolaires || 1;
        const parSemaine = (h) => Math.round((h || 0) / nbSem * 10) / 10;

        const content = [];
        content.push(...this._enteteBloc('Par adulte',
            `${adultes.length} adulte(s) · ${ad.total_heures || 0} h attribuées sur l'année · ${nbSem} semaines scolaires`));

        if (!adultes.length) {
            content.push({ text: 'Aucun créneau ne nomme d\'adulte sur cette année.', color: '#999', margin: [0, 0, 0, 6] });
            return content;
        }

        const entete = ['Adulte', 'Rôle', 'Heures/sem.', 'Élèves suivis', ...types.map(t => `${t} (h/sem.)`)];
        const corps = [entete];
        adultes.forEach(a => {
            const ligne = [
                a.adulte || '',
                libellesRoles(a.roles),
                String(a.heures_par_semaine) + ' h',
                String(a.nb_eleves || 0),
            ];
            types.forEach(t => {
                const h = (a.par_type || {})[t];
                ligne.push(h != null ? String(parSemaine(h)) + ' h' : '—');
            });
            corps.push(ligne);
        });

        content.push({
            table: { headerRows: 1, widths: ['*', 'auto', 'auto', 'auto', ...types.map(() => 'auto')], body: corps },
            fontSize: 8, margin: [0, 8, 0, 0],
        });

        if (sans.nb_creneaux) {
            content.push({
                text: `${sans.nb_creneaux} créneau(x) sans adulte nommé (${sans.total_heures} h sur l'année) : ces heures ne sont attribuées à personne.`,
                fontSize: 8, color: '#666', margin: [0, 8, 0, 0],
            });
        }
        content.push({
            text: 'Un créneau retient le nom de l\'adulte : deux personnes portant le même nom sont comptées ensemble.',
            fontSize: 8, color: '#666', margin: [0, 4, 0, 0],
        });

        return content;
    },

    _blocInclusionEleves(data) {
        const inc = data.inclusion || {};
        const parEleve = inc.par_eleve || [];
        const heuresEcole = inc.heures_ecole_semaine || 24;
        const tousPeriodes = data.inclusion_tous_eleves_periodes || {};

        let nbPeriodes = 0;
        for (const eid of Object.keys(tousPeriodes)) {
            nbPeriodes = Math.max(nbPeriodes, tousPeriodes[eid].length);
        }

        const content = [];
        content.push(...this._enteteBloc('Inclusion — Détail par élève',
            `${inc.nb_semaines_scolaires || '?'} semaines scolaires · ${heuresEcole} h école/sem.`));

        const headerRow = ['Élève', 'Heures totales', 'Heures/sem.', '% temps scolaire', 'Nb créneaux'];
        for (let p = 1; p <= nbPeriodes; p++) {
            headerRow.push(`P${p} h/sem`);
            headerRow.push(`P${p} %`);
        }
        const body = [headerRow];

        parEleve.forEach(e => {
            const pct = heuresEcole > 0 ? Math.round((e.heures_par_semaine || 0) / heuresEcole * 1000) / 10 : 0;
            const row = [
                `${e.prenom || ''} ${e.nom || ''}`.trim(),
                String(e.total_heures || 0) + ' h',
                String(e.heures_par_semaine || 0) + ' h/sem',
                String(pct) + ' %',
                String(e.nb_creneaux || 0),
            ];
            const elevePeriodes = tousPeriodes[e.eleve_id] || [];
            for (let p = 1; p <= nbPeriodes; p++) {
                const per = elevePeriodes.find(pp => pp.periode === p);
                const h = per ? per.heures_par_semaine || 0 : 0;
                row.push(per ? String(h) + ' h' : '—');
                row.push(per ? Math.round(h / heuresEcole * 100) + ' %' : '—');
            }
            body.push(row);
        });

        if (parEleve.length && nbPeriodes > 0) {
            const totalH = parEleve.reduce((s, e) => s + (e.total_heures || 0), 0);
            const totalC = parEleve.reduce((s, e) => s + (e.nb_creneaux || 0), 0);
            const totalRow = [
                { text: 'TOTAL', bold: true },
                { text: Math.round(totalH * 10) / 10 + ' h', bold: true },
                { text: inc.heures_par_semaine || '', bold: true },
                { text: inc.pourcentage_temps_total != null ? String(inc.pourcentage_temps_total) + ' %' : '', bold: true },
                { text: String(totalC), bold: true },
            ];
            for (let p = 1; p <= nbPeriodes; p++) {
                let sum = 0, count = 0;
                for (const eid of Object.keys(tousPeriodes)) {
                    const per = tousPeriodes[eid].find(pp => pp.periode === p);
                    if (per) { sum += per.heures_par_semaine || 0; count++; }
                }
                const avgH = count > 0 ? Math.round(sum / count * 10) / 10 : null;
                totalRow.push({ text: avgH != null ? avgH + ' h' : '—', bold: true, fontSize: 7 });
                totalRow.push({ text: avgH != null ? Math.round(avgH / heuresEcole * 100) + ' %' : '—', bold: true, fontSize: 7 });
            }
            body.push(totalRow);
        }

        const widths = ['*', 'auto', 'auto', 'auto', 'auto'];
        for (let p = 0; p < nbPeriodes; p++) { widths.push('auto'); widths.push('auto'); }

        content.push({
            table: { headerRows: 1, widths, body },
            fontSize: 7.5, margin: [0, 8, 0, 0],
        });

        content.push({
            text: `Moy/élève : ${inc.moyenne_heures_eleve || 0} h/sem · ${parEleve.length} élèves concernés${nbPeriodes > 0 ? ' · P1–P' + nbPeriodes + ' = périodes scolaires' : ''}`,
            fontSize: 8, color: '#666', margin: [0, 10, 0, 0],
        });

        return content;
    },

    _blocInclusionPeriodes(data) {
        const periodes = data.inclusion_periodes || [];
        const inc = data.inclusion || {};
        const heuresEcole = inc.heures_ecole_semaine || 24;

        const content = [];
        content.push(...this._enteteBloc('Inclusion par période', `${heuresEcole} h école/sem.`));

        const body = [['Période', 'Semaines', 'Heures totales', 'Heures/sem.', '% temps scolaire', 'Nb créneaux']];
        periodes.forEach(p => {
            const pct = heuresEcole > 0 ? Math.round((p.heures_par_semaine || 0) / heuresEcole * 1000) / 10 : 0;
            body.push([
                'Période ' + (p.periode || '?'),
                String(p.nb_semaines || 0),
                String(p.total_heures || 0) + ' h',
                String(p.heures_par_semaine || 0) + ' h/sem',
                String(pct) + ' %',
                String(p.nb_creneaux || 0),
            ]);
        });

        if (periodes.length) {
            const totalH = periodes.reduce((s, p) => s + (p.total_heures || 0), 0);
            const totalS = periodes.reduce((s, p) => s + (p.nb_semaines || 0), 0);
            const totalC = periodes.reduce((s, p) => s + (p.nb_creneaux || 0), 0);
            body.push([
                { text: 'TOTAL', bold: true },
                { text: String(totalS), bold: true },
                { text: Math.round(totalH * 10) / 10 + ' h', bold: true },
                { text: totalS > 0 ? Math.round(totalH / totalS * 10) / 10 + ' h/sem' : '', bold: true },
                { text: inc.pourcentage_temps_total != null ? String(inc.pourcentage_temps_total) + ' %' : '', bold: true },
                { text: String(totalC), bold: true },
            ]);
        }

        content.push({
            table: { headerRows: 1, widths: ['auto', 'auto', 'auto', 'auto', 'auto', 'auto'], body },
            fontSize: 9, margin: [0, 8, 0, 0],
        });

        content.push({
            text: `Année complète : ${inc.total_heures_annee || 0} h · ${inc.nb_semaines_scolaires || '?'} semaines scolaires`,
            fontSize: 8, color: '#666', margin: [0, 10, 0, 0],
        });

        return content;
    },

    _blocEvolution(data) {
        const evo = data.evolution || {};
        const parAnnee = evo.par_annee || [];
        const pecEvo = evo.pec_par_annee || [];
        const ecoEvo = evo.ecoles_par_annee || [];

        const content = [];
        content.push(...this._enteteBloc('Évolution multi-année', null));

        if (parAnnee.length) {
            content.push({ text: 'Indicateurs par année', style: 'sectionTitle' });
            const body = [['Année', 'Effectif', 'ULIS', 'Cantine', 'Taxi', 'PEC', 'Inclusion (h)', 'MDPH', 'MDPH expr.', 'Entrées', 'Sorties']];
            parAnnee.forEach(a => {
                body.push([
                    a.nom || '', String(a.total || 0), String(a.ulis || 0), String(a.cantine || 0),
                    String(a.taxi || 0), String(a.pec || 0), String(a.inclusion_heures || 0),
                    String(a.mdph_total || 0), String(a.mdph_expires || 0),
                    String(a.entrees || 0), String(a.sorties || 0),
                ]);
            });
            content.push({
                table: { headerRows: 1, widths: ['auto', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto'], body },
                fontSize: 7, margin: [0, 0, 0, 14],
            });
        }

        if (pecEvo.length) {
            content.push({ text: 'Évolution PEC par spécialité', style: 'sectionTitle' });
            const annees = parAnnee.map(a => a.nom);
            const header = ['Spécialité', ...annees];
            const body = [header];
            pecEvo.forEach(pec => {
                const row = [pec.specialite || ''];
                annees.forEach(nom => {
                    const v = (pec.values || []).find(v => v.nom === nom);
                    row.push(String(v ? v.nb : 0));
                });
                body.push(row);
            });
            content.push({
                table: { headerRows: 1, widths: ['*', ...annees.map(() => 'auto')], body },
                fontSize: 7, margin: [0, 0, 0, 14],
            });
        }

        if (ecoEvo.length) {
            content.push({ text: 'Écoles d\'origine par année', style: 'sectionTitle' });
            const annees = parAnnee.map(a => a.nom);
            const header = ['École', ...annees];
            const body = [header];
            ecoEvo.forEach(eco => {
                const row = [eco.ecole_nom || ''];
                annees.forEach(nom => {
                    const v = (eco.values || []).find(v => v.nom === nom);
                    row.push(String(v ? v.nb : 0));
                });
                body.push(row);
            });
            content.push({
                table: { headerRows: 1, widths: ['*', ...annees.map(() => 'auto')], body },
                fontSize: 7, margin: [0, 0, 0, 10],
            });
        }

        if (!parAnnee.length) {
            content.push({ text: 'Aucune donnée d\'évolution disponible.', color: '#999', margin: [0, 20, 0, 0] });
        }

        return content;
    },

    /** Titre d'un bloc (les blocs larges n'ont pas de tableau-titre à elles). */
    _enteteBloc(titre, sousTitre) {
        const items = [{ text: titre, style: 'sectionTitle' }];
        if (sousTitre) items.push({ text: sousTitre, fontSize: 8, color: '#666', margin: [0, 0, 0, 4] });
        return items;
    },

});
