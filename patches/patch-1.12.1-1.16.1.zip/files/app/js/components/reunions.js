/**
 * Calulis — Composant Réunions (liste + CRUD)
 */
const ReunionsList = {
    _reunions: [],
    _eleves: [],
    _typesReunions: {},
    _typeLabels: { ESS: 'ESS', equipe_suivi: 'Équipe de suivi', equipe_educative: 'Équipe éducative', rdv_famille: 'RDV famille', partenariat: 'Partenariat', autre: 'Autre' },

    async render() {
        const view = document.getElementById('view-reunions');
        // Charger données
        try {
            this._reunions = await API.get('reunions.php');
            this._eleves = await API.get('eleves.php');
        } catch {
            this._reunions = [];
            this._eleves = [];
        }
        // Récupérer les types de réunions paramétrés
        try {
            const params = await API.get('params.php');
            params.forEach(p => {
                if (p.cle === 'types_reunions') {
                    try { this._typesReunions = JSON.parse(p.valeur); } catch { this._typesReunions = {}; }
                }
            });
        } catch { this._typesReunions = {}; }

        view.innerHTML = `
            <div class="toolbar" data-help="Réunions|Filtre par type (ESS, équipe éducative...), par statut (prévue, réalisée, annulée) et par mot-clé (titre ou nom d'élève). Clique sur une ligne pour ouvrir la fiche complète d'une réunion.">
                <button class="btn btn-primary" id="btn-new-reunion">+ Nouvelle réunion</button>
                <button class="btn btn-sm btn-secondary" id="btn-ics-reunions" title="Exporter les réunions affichées dans un fichier .ics (téléphone, Google Agenda, Outlook)" data-help="Exporter (.ics)|Fabrique un fichier que votre téléphone, Google Agenda ou Outlook savent ouvrir, avec les réunions AFFICHÉES (vos filtres font foi). Le fichier est fabriqué sur votre ordinateur : rien n'est envoyé sur Internet." style="margin-left:8px">📆 Exporter (.ics)</button>
                <div style="display:flex;gap:8px;align-items:center;margin-left:auto">
                    <select id="filter-reunion-type" style="font-size:13px;max-width:180px">
                        <option value="">Tous les types</option>
                        ${Object.entries(this._typeLabels).map(([nom, label]) =>
                            `<option value="${escapeHtml(nom)}">${escapeHtml(label)}</option>`
                        ).join('')}
                    </select>
                    <select id="filter-reunion-statut" style="font-size:13px;max-width:150px">
                        <option value="">Tous statuts</option>
                        <option value="prevue">Prévue</option>
                        <option value="en_cours">En cours</option>
                        <option value="realisee">Réalisée</option>
                        <option value="terminee">Terminée</option>
                        <option value="annulee">Annulée</option>
                        <option value="reportee">Reportée</option>
                    </select>
                    <input type="text" id="filter-reunion-q" placeholder="Rechercher..." style="font-size:13px;width:180px">
                </div>
            </div>
            <div id="reunions-table-container"></div>
        `;

        document.getElementById('btn-new-reunion').addEventListener('click', () => this._openFiche({}));
        document.getElementById('btn-ics-reunions')?.addEventListener('click', () => this._exportICS());
        document.getElementById('filter-reunion-type').addEventListener('change', () => this._renderTable());
        document.getElementById('filter-reunion-statut').addEventListener('change', () => this._renderTable());
        document.getElementById('filter-reunion-q').addEventListener('input', () => this._renderTable());

        this._renderTable();
    },

    /** Les réunions telles que l'utilisateur les voit (filtres de la barre d'outils). */
    _reunionsFiltrees() {
        const typeFilter = document.getElementById('filter-reunion-type')?.value || '';
        const statutFilter = document.getElementById('filter-reunion-statut')?.value || '';
        const q = (document.getElementById('filter-reunion-q')?.value || '').toLowerCase();

        let filtered = this._reunions;
        if (typeFilter) filtered = filtered.filter(r => r.type === typeFilter);
        if (statutFilter) filtered = filtered.filter(r => r.statut === statutFilter);
        if (q) {
            filtered = filtered.filter(r =>
                (r.titre || '').toLowerCase().includes(q) ||
                (r.eleve_nom || '').toLowerCase().includes(q) ||
                (r.eleve_prenom || '').toLowerCase().includes(q) ||
                (r.type || '').toLowerCase().includes(q)
            );
        }
        return filtered;
    },

    /**
     * Export .ics des réunions AFFICHÉES (les filtres de la barre d'outils font foi) :
     * c'est ce qui permet de les retrouver sur un téléphone. Le fichier est fabriqué
     * dans le navigateur (`exportICS`).
     */
    _exportICS() {
        const reunions = this._reunionsFiltrees().filter(r => r.date_reunion);
        if (reunions.length === 0) {
            Toast.info('Aucune réunion datée à exporter.');
            return;
        }
        exportICS('reunions-calulis.ics', 'Réunions Calulis', reunions.map(r => ({
            uid: 'reunion-' + r.id + '@calulis',
            debut: r.date_reunion,
            heure: r.heure || null,
            duree: r.duree,
            titre: (this._typeLabels[r.type] ? this._typeLabels[r.type] + ' — ' : '') + (r.titre || 'Réunion'),
            lieu: r.lieu || '',
            description: [
                (r.eleve_prenom || r.eleve_nom) ? 'Élève : ' + [r.eleve_prenom, r.eleve_nom].filter(Boolean).join(' ') : '',
                r.participants ? 'Participants : ' + r.participants : '',
                r.notes || '',
            ].filter(Boolean).join('\n'),
        })));
        Toast.success(reunions.length + ' réunion(s) exportée(s).');
    },

    _renderTable() {
        const filtered = this._reunionsFiltrees();
        const typeFilter = document.getElementById('filter-reunion-type')?.value || '';
        const statutFilter = document.getElementById('filter-reunion-statut')?.value || '';
        const q = (document.getElementById('filter-reunion-q')?.value || '').toLowerCase();

        const badge = (statut) => {
            const labels = { prevue: 'Prévue', realisee: 'Réalisée', annulee: 'Annulée', reportee: 'Reportée', en_cours: 'En cours', terminee: 'Terminée' };
            return `<span class="badge reunion-statut-${statut || 'prevue'}">${labels[statut] || statut || 'prévue'}</span>`;
        };

        const typesCouleurs = this._typesReunions || {};
        const typeBadge = (type) => {
            const couleur = typesCouleurs[type] || '#e0e0e0';
            const label = this._typeLabels[type] || type || '?';
            return `<span class="badge" style="background:${couleur};color:#000;font-size:11px">${escapeHtml(label)}</span>`;
        };

        const container = document.getElementById('reunions-table-container');
        const hasFilter = typeFilter || statutFilter || q;
        container.innerHTML = filtered.length === 0
            ? `<div style="text-align:center;padding:32px;color:var(--text-muted)">${hasFilter ? 'Aucun résultat trouvé.' : `Aucune réunion enregistrée.<br><button class="btn btn-primary" id="btn-empty-new-reunion" style="margin-top:12px">+ Nouvelle réunion</button>`}</div>`
            : `<table class="data-table">
                <thead>
                    <tr>
                        <th>Date</th><th>Heure</th><th>Type</th><th>Titre</th><th>Élève</th><th>Statut</th><th style="width:80px"></th>
                    </tr>
                </thead>
                <tbody>
                    ${filtered.map(r => `
                        <tr class="clickable" data-id="${r.id}">
                            <td>${formatDate(r.date_reunion)}</td>
                            <td>${r.heure ? r.heure.substring(0,5) : '-'}</td>
                            <td>${typeBadge(r.type)}</td>
                            <td><strong>${escapeHtml(r.titre)}</strong></td>
                            <td>${r.eleve_nom ? escapeHtml(r.eleve_prenom) + ' ' + escapeHtml(r.eleve_nom) : '<span class="text-muted">—</span>'}</td>
                            <td>${badge(r.statut)}</td>
                            <td>
                                <button class="btn-sm btn-edit" data-action="edit" data-id="${r.id}" title="Modifier">✏️</button>
                                <button class="btn-sm btn-del" data-action="delete" data-id="${r.id}" title="Supprimer">🗑️</button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>`;

        // Bouton CTA dans l'état vide
        const emptyBtn = document.getElementById('btn-empty-new-reunion');
        if (emptyBtn) emptyBtn.addEventListener('click', () => this._openFiche({}));

        // Events
        container.querySelectorAll('[data-action="edit"]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const id = parseInt(btn.dataset.id);
                const r = this._reunions.find(r => r.id === id);
                if (r) this._openFiche(r);
            });
        });
        container.querySelectorAll('[data-action="delete"]').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.stopPropagation();
                const id = parseInt(btn.dataset.id);
                if (!await Modal.confirm('Confirmer', 'Supprimer cette réunion ?')) return;
                try {
                    await API.del('reunions.php?id=' + id);
                    this._reunions = this._reunions.filter(r => r.id !== id);
                    this._renderTable();
                } catch (err) {
                    Modal.alert('Erreur', err.message);
                }
            });
        });
        container.querySelectorAll('tr.clickable').forEach(row => {
            row.addEventListener('click', () => {
                const id = parseInt(row.dataset.id);
                const r = this._reunions.find(r => r.id === id);
                if (r) this._openFiche(r, true);
            });
        });
    },

    _openFiche(data = {}, readonly = false) {
        const isNew = !data || !data.id;
        const r = isNew ? { type: '', titre: '', date_reunion: '', heure: '', duree: 60, eleve_id: null, lieu: '', participants: '', statut: 'prevue', notes: '', documents_lies: '' } : { ...data };

        const elevesOptions = this._eleves.map(e =>
            `<option value="${e.id}" ${r.eleve_id === e.id ? 'selected' : ''}>${escapeHtml(e.prenom)} ${escapeHtml(e.nom)} (${escapeHtml(e.classe || '')})</option>`
        ).join('');

        const typesOptions = Object.entries(this._typesReunions).map(([nom]) =>
            `<option value="${escapeHtml(nom)}" ${r.type === nom ? 'selected' : ''}>${escapeHtml(nom)}</option>`
        ).join('');

        const ro = readonly ? 'disabled' : '';

        Modal.open({
            title: isNew ? 'Nouvelle réunion' : (readonly ? 'Réunion : ' : 'Modifier : ') + escapeHtml(r.titre),
            body: `
                <div class="form-row">
                    <div class="form-group"><label>Type *</label>
                        <select id="fr-type" ${ro}><option value="">—</option>${typesOptions}</select>
                    </div>
                    <div class="form-group"><label>Statut</label>
                        <select id="fr-statut" ${ro}>
                            ${[
                                {v:'prevue', l:'Prévue'},
                                {v:'en_cours', l:'En cours'},
                                {v:'realisee', l:'Réalisée'},
                                {v:'terminee', l:'Terminée'},
                                {v:'annulee', l:'Annulée'},
                                {v:'reportee', l:'Reportée'}
                            ].map(s => `<option value="${s.v}" ${r.statut === s.v ? 'selected' : ''}>${s.l}</option>`).join('')}
                        </select>
                    </div>
                </div>
                <div class="form-group"><label>Titre *</label><input type="text" id="fr-titre" value="${escapeHtml(r.titre || '')}" ${ro}></div>
                <div class="form-row">
                    <div class="form-group"><label>Date *</label><input type="date" id="fr-date" value="${r.date_reunion || ''}" ${ro}></div>
                    <div class="form-group"><label>Heure</label><input type="time" id="fr-heure" value="${r.heure ? r.heure.substring(0,5) : ''}" ${ro}></div>
                    <div class="form-group"><label>Durée (min)</label><input type="number" id="fr-duree" value="${r.duree || 60}" min="15" step="15" ${ro}></div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label>Élève</label>
                        <select id="fr-eleve" ${ro}><option value="">— Aucun —</option>${elevesOptions}</select>
                    </div>
                    <div class="form-group"><label>Lieu</label><input type="text" id="fr-lieu" value="${escapeHtml(r.lieu || '')}" ${ro}></div>
                </div>
                <div class="form-group"><label>Participants</label><input type="text" id="fr-participants" value="${escapeHtml(r.participants || '')}" placeholder="Noms séparés par des virgules" ${ro}></div>
                <div class="form-group"><label>Notes</label><textarea id="fr-notes" rows="3" ${ro}>${escapeHtml(r.notes || '')}</textarea></div>
            `,
            footer: readonly
                ? '<button class="btn btn-secondary" onclick="Modal.close()">Fermer</button>'
                : `<button class="btn btn-secondary" onclick="Modal.close()">Annuler</button>
                   <button class="btn btn-primary" id="btn-save-reunion">Enregistrer</button>`,
        });

        if (!readonly) {
            document.getElementById('btn-save-reunion').addEventListener('click', async () => {
                const data = {
                    type: document.getElementById('fr-type').value,
                    titre: document.getElementById('fr-titre').value,
                    date_reunion: document.getElementById('fr-date').value,
                    heure: document.getElementById('fr-heure').value || null,
                    duree: parseInt(document.getElementById('fr-duree').value) || 60,
                    eleve_id: document.getElementById('fr-eleve').value ? parseInt(document.getElementById('fr-eleve').value) : null,
                    lieu: document.getElementById('fr-lieu').value,
                    participants: document.getElementById('fr-participants').value,
                    statut: document.getElementById('fr-statut').value,
                    notes: document.getElementById('fr-notes').value,
                };
                if (!data.titre || !data.date_reunion || !data.type) {
                    Modal.alert('Erreur', 'Type, titre et date sont requis.');
                    return;
                }
                try {
                    if (isNew) {
                        await API.post('reunions.php', data);
                    } else {
                        await API.put('reunions.php?id=' + r.id, data);
                    }
                    Modal.close();
                    this._reunions = await API.get('reunions.php');
                    this._renderTable();
                    State.emit('reunions:changed');
                } catch (e) {
                    Modal.alert('Erreur', e.message);
                }
            });
        }
    },
};
