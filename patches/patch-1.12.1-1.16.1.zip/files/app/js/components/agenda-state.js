/**
 * Calulis — Agenda State : store central + occupancy map + collision/découpage
 * Ajouté à Agenda via Object.assign
 */

Object.assign(Agenda, {

    /* ─── State ─── */

    _initState() {
        this._selection = { anchor: null, cells: new Map() };
        this._clipboard = null;
        this._drag = null; // { creneauId, isCopy, startX, startY, ghost, targetRow, targetCol }
        this._filteredEleves = [];
        this._heures = [];
    },

    /* ─── Coords ─── */

    _getRow(heure) {
        return this._heures.indexOf(heure);
    },

    _getHeure(row) {
        return this._heures[row];
    },

    _getCol(eleveId) {
        return this._filteredEleves.findIndex(e => e.id === eleveId);
    },

    _getEleveId(col) {
        const e = this._filteredEleves[col];
        return e ? e.id : null;
    },

    /* ─── Occupancy map ─── */

    /**
     * Construit la map d'occupation pour le jour courant.
     * "row:col" → creneauId (ou null si libre)
     * Les pauses (RECREATION / PAUSE MIDI) sont des créneaux comme les autres.
     */
    _buildOccupancy() {
        const occ = {};
        const dureePas = this._params?.horaires?.duree_creneau || 15;
        const jour = this._currentDay;
        const heures = this._heures;
        const eleves = this._filteredEleves;
        const nCols = eleves.length;

        // Initialiser toutes les cellules à null
        for (let r = 0; r < heures.length; r++) {
            for (let c = 0; c < nCols; c++) {
                occ[`${r}:${c}`] = null;
            }
        }

        // Remplir avec les créneaux (les pauses en font partie)
        for (const c of this._creneaux) {
            if (c.jour !== jour) continue;
            const col = eleves.findIndex(e => e.id === c.eleve_id);
            if (col < 0) continue;
            const row = heures.indexOf(c.heure_debut);
            if (row < 0) continue;
            const span = Math.max(1, Math.ceil((c.duree || dureePas) / dureePas));
            for (let r = row; r < row + span && r < heures.length; r++) {
                occ[`${r}:${col}`] = c.id;
            }
        }

        return occ;
    },

    /* ─── Collision detection ─── */

    /**
     * Vérifie si un créneau de hauteur `span` peut être placé
     * à la position (row, col). Retourne { ok, conflicts[], reason }
     *
     * @param {number|number[]} sourceIds - ID(s) du créneau déplacé (ignore ses propres cellules)
     * @param {number} row - ligne cible
     * @param {number} col - colonne cible
     * @param {number} span - hauteur en pas de temps
     * @param {Object} [occupancy] - map précalculée (optionnel)
     */
    _canPlace(sourceIds, row, col, span, occupancy) {
        const occ = occupancy || this._buildOccupancy();
        const conflicts = [];
        // Normaliser en tableau
        const ids = Array.isArray(sourceIds) ? sourceIds : [sourceIds];

        for (let r = row; r < row + span && r < this._heures.length; r++) {
            const key = `${r}:${col}`;
            const occupant = occ[key];

            if (occupant !== null && !ids.includes(occupant)) {
                if (!conflicts.some(x => x.creneauId === occupant)) {
                    conflicts.push({ row: r, creneauId: occupant });
                }
            }
        }

        if (conflicts.length > 0) {
            // Chevauchement : autorisé avec avertissement (le découpage gère l'écrasement)
            return { ok: true, reason: 'overlap', conflicts };
        }

        return { ok: true };
    },

    /**
     * Noms d'adultes d'un créneau, sous forme normalisée, pour comparer deux créneaux.
     *
     * Le champ `adulte` est une **chaîne d'affichage** (« M. DUPONT Marie, MARTIN Paul »),
     * pas une liste d'identifiants : c'est ainsi que l'application le stocke. On retire
     * donc la civilité et la casse — sans quoi un créneau enregistré avant que la
     * civilité de l'adulte ne soit renseignée (ou modifiée depuis) ne serait jamais
     * reconnu comme le même adulte, et le conflit passerait inaperçu.
     *
     * Limite connue, héritée du stockage : deux adultes qui portent le même nom (le champ
     * `adulte` ne garde pas le prénom) sont vus comme un seul. Un vrai correctif demande
     * de stocker l'identifiant de l'adulte sur le créneau — ce n'est pas une petite
     * correction, et ce n'est pas ce qui a été demandé ici.
     *
     * @returns {string[]} noms normalisés (casse basse, sans civilité)
     */
    _nomsAdultes(adulte) {
        return String(adulte || '')
            .split(',')
            .map(n => n.trim().replace(/^(M\.|Mme|Mlle|Dr\.?|Pr\.?)\s+/i, '').toLowerCase())
            .filter(Boolean);
    },

    /**
     * Chevauchements entre des placements en cours de saisie et les créneaux existants.
     *
     * `_buildOccupancy()` ne couvre que le jour affiché ; la modale, elle, peut créer ou
     * modifier sur plusieurs jours (et une pause sur toute la semaine). D'où un contrôle
     * générique par (jour, élève, plage horaire) — celui qui manquait à la création
     * (priorité haute du 31/08/2026, corrigée le 29/09/2026).
     *
     * Depuis le 29/09/2026, la même règle s'applique aux **adultes** : un adulte ne peut
     * pas être à deux endroits en même temps (décision de Jérôme — « comme les élèves »).
     * Le créneau visé et le créneau existant se gênent s'ils partagent un élève **ou**
     * un adulte, le même jour, sur des plages qui se chevauchent.
     *
     * @param {Array<{eleve_id:number, jour:string, heure_debut:string, duree:number,
     *                adulte?:string, ignorer?:number[]}>} cibles
     * @returns {Array<{cible:Object, occupants:Array, parEleve:number, parAdulte:number}>}
     *          uniquement les cibles en conflit, avec la raison (pour la question posée)
     */
    _chevauchements(cibles) {
        const dureePas = this._params?.horaires?.duree_creneau || 15;
        const resultat = [];
        for (const cible of cibles || []) {
            const debut = this._heureToMin(cible.heure_debut);
            const fin = debut + (cible.duree || dureePas);
            if (!(fin > debut)) continue;
            const ignorer = new Set((cible.ignorer || []).map(Number));
            const nomsCible = this._nomsAdultes(cible.adulte);
            const occupants = [];
            let parEleve = 0;
            let parAdulte = 0;
            for (const c of this._creneaux || []) {
                if (c.jour !== cible.jour) continue;
                if (ignorer.has(Number(c.id))) continue;
                const debutExistant = this._heureToMin(c.heure_debut);
                const finExistante = debutExistant + (c.duree || dureePas);
                if (!(debut < finExistante && debutExistant < fin)) continue;
                const memeEleve = Number(c.eleve_id) === Number(cible.eleve_id);
                const memeAdulte = nomsCible.length > 0
                    && this._nomsAdultes(c.adulte).some(n => nomsCible.includes(n));
                if (!memeEleve && !memeAdulte) continue;
                occupants.push(c);
                if (memeEleve) parEleve++;
                if (memeAdulte) parAdulte++;
            }
            if (occupants.length) resultat.push({ cible, occupants, parEleve, parAdulte });
        }
        return resultat;
    },

    /**
     * Phrase posée dans la boîte de conflit : elle dit POURQUOI la case est occupée —
     * un élève déjà pris, un adulte déjà pris ailleurs, ou les deux. C'est utile avant
     * de choisir « Écraser », qui **supprime** les créneaux occupants.
     *
     * @returns {string|null} null = la question par défaut convient
     */
    _questionConflit(conflits) {
        const parEleve = conflits.filter(c => c.parEleve > 0).length;
        const parAdulte = conflits.filter(c => c.parAdulte > 0).length;
        if (parEleve === 0 && parAdulte === 0) return null;
        const detail = [];
        if (parEleve > 0) detail.push(parEleve + ' par un élève déjà pris');
        if (parAdulte > 0) detail.push(parAdulte + ' où un adulte est déjà occupé ailleurs');
        return conflits.length + ' case(s) en conflit : ' + detail.join(', ') + '. Que faire ?';
    },

    /**
     * Boîte de choix en cas de conflit, partagée par le collage et par la saisie :
     * Annuler / Ignorer les occupées / Écraser.
     *
     * Pourquoi une **boîte flottante** et non la fenêtre modale : Calulis n'a qu'une
     * seule fenêtre modale (`Modal.open` remplace son contenu). Poser la question dans
     * cette fenêtre **détruisait la saisie en cours** — l'utilisateur perdait ce qu'il
     * venait de taper, et « Annuler » ne pouvait plus le ramener (constaté sur le banc
     * le 29/09/2026). La boîte s'ajoute donc au-dessus, sans toucher à la fenêtre de
     * saisie, qui reste ouverte derrière.
     *
     * `ids` permet au collage de conserver ses identifiants historiques
     * (`paste-skip`…), que ciblent les tests CDP de `tests/cdp-creneaux/`.
     *
     * @returns {Promise<'annuler'|'ignorer'|'ecraser'>}
     */
    _askConflit(nb, { titre = 'Créneau', ids = null,
                      question = null } = {}) {
        const boutons = Object.assign({
            annuler: 'conflit-annuler',
            ignorer: 'conflit-ignorer',
            ecraser: 'conflit-ecraser',
        }, ids || {});
        return new Promise(resolve => {
            const boite = document.createElement('div');
            boite.className = 'conflit-boite';
            boite.setAttribute('role', 'alertdialog');
            boite.setAttribute('aria-label', titre);
            boite.innerHTML = '<p class="conflit-titre">' + escapeHtml(titre) + '</p>'
                + '<p>' + escapeHtml(question || (nb + ' case(s) déjà occupée(s). Que faire ?')) + '</p>'
                + '<div class="conflit-actions">'
                + '<button class="btn btn-secondary" id="' + boutons.annuler + '">Annuler</button>'
                + '<button class="btn btn-secondary" id="' + boutons.ignorer + '">Ignorer les occupées</button>'
                + '<button class="btn btn-primary" id="' + boutons.ecraser + '">Écraser</button>'
                + '</div>';
            document.body.appendChild(boite);
            const repondre = (valeur) => {
                boite.remove();
                resolve(valeur);
            };
            boutons.annuler && document.getElementById(boutons.annuler)
                .addEventListener('click', () => repondre('annuler'));
            boutons.ignorer && document.getElementById(boutons.ignorer)
                .addEventListener('click', () => repondre('ignorer'));
            boutons.ecraser && document.getElementById(boutons.ecraser)
                .addEventListener('click', () => repondre('ecraser'));
        });
    },

    /**
     * Collecte le bloc fusionné déplacé (créneau saisi + voisins visuellement
     * fusionnés) et calcule leurs offsets + l'empan total en pas de temps.
     */
    _getDragBlock(draggedCreneau, friendlyIds) {
        const dureePas = this._params?.horaires?.duree_creneau || 15;
        const block = [draggedCreneau];
        for (const id of (friendlyIds || [])) {
            if (id === draggedCreneau.id) continue;
            const cc = this._creneaux.find(c => c.id === id);
            if (cc && cc.jour === draggedCreneau.jour && cc.eleve_id === draggedCreneau.eleve_id) block.push(cc);
        }
        block.sort((a, b) => this._heureToMin(a.heure_debut) - this._heureToMin(b.heure_debut));
        const baseMin = this._heureToMin(draggedCreneau.heure_debut);
        const offsets = block.map(c => this._heureToMin(c.heure_debut) - baseMin);
        const blockEnd = Math.max(...block.map(c => this._heureToMin(c.heure_debut) + (c.duree || dureePas)));
        const blockStart = Math.min(...block.map(c => this._heureToMin(c.heure_debut)));
        const span = Math.max(1, Math.ceil((blockEnd - blockStart) / dureePas));
        return { block, offsets, span };
    },

    /**
     * Applique le drop avec découpage des créneaux écrasés.
     * Retourne un tableau d'opérations API à exécuter.
     * 
     * Cas gérés :
     *   A - Drop aligné au début : écrasement partiel par le haut
     *   B - Drop au milieu : écrasement partiel → split en deux
     *   C - Drop englobant : écrasement complet
     */
    _computeDropOps(draggedCreneau, targetEleveId, targetHeure, isCopy, friendlyIds) {
        const dureePas = this._params?.horaires?.duree_creneau || 15;
        const targetRow = this._getRow(targetHeure);
        const targetCol = this._getCol(targetEleveId);

        if (targetRow < 0 || targetCol < 0) return [];

        const ops = [];
        const occupancy = this._buildOccupancy();
        const affected = new Map();
        const idsAExclure = new Set(friendlyIds || []);
        idsAExclure.add(draggedCreneau.id);

        // Bloc fusionné déplacé (créneau saisi + voisins fusionnés)
        const { block, offsets, span } = this._getDragBlock(draggedCreneau, friendlyIds);

        // Trouver les créneaux impactés (hors friendlyIds)
        for (let r = targetRow; r < targetRow + span && r < this._heures.length; r++) {
            const key = `${r}:${targetCol}`;
            const cid = occupancy[key];
            if (cid && !idsAExclure.has(cid)) {
                affected.set(cid, true);
            }
        }

        // Appliquer le découpage sur chaque créneau impacté
        for (const cid of affected.keys()) {
            const existing = this._creneaux.find(c => c.id === cid);
            if (!existing) continue;

            const eRow = this._getRow(existing.heure_debut);
            const eSpan = Math.max(1, Math.ceil((existing.duree || dureePas) / dureePas));
            const eEndRow = eRow + eSpan - 1;

            // Zone de chevauchement
            const oStart = Math.max(eRow, targetRow);
            const oEnd = Math.min(eEndRow, targetRow + span - 1);

            if (oStart > oEnd) continue; // pas de chevauchement

            const hasTop = oStart > eRow;
            const hasBottom = oEnd < eEndRow;

            if (hasTop && hasBottom) {
                // CAS B — Split en deux
                const topDuree = (oStart - eRow) * dureePas;
                const bottomRow = oEnd + 1;
                const bottomHeure = this._getHeure(bottomRow);
                const bottomDuree = (eEndRow - oEnd) * dureePas;

                // Raccourcir l'existant (partie haute)
                ops.push({
                    type: 'update',
                    id: existing.id,
                    data: this._buildFullCreneauData(existing, { duree: topDuree })
                });

                // Créer un nouveau créneau (partie basse)
                ops.push({
                    type: 'create',
                    data: this._buildFullCreneauData(existing, {
                        id: null,
                        heure_debut: bottomHeure,
                        duree: bottomDuree,
                    })
                });

            } else if (hasTop) {
                // CAS A variante — Écrasement en bas
                const topDuree = (oStart - eRow) * dureePas;
                ops.push({
                    type: 'update',
                    id: existing.id,
                    data: this._buildFullCreneauData(existing, { duree: topDuree })
                });

            } else if (hasBottom) {
                // CAS A variante — Écrasement en haut
                const bottomHeure = this._getHeure(oEnd + 1);
                const bottomDuree = (eEndRow - oEnd) * dureePas;
                ops.push({
                    type: 'update',
                    id: existing.id,
                    data: this._buildFullCreneauData(existing, {
                        heure_debut: bottomHeure,
                        duree: bottomDuree,
                    })
                });

            } else {
                // CAS C — Écrasement total
                ops.push({ type: 'delete', id: existing.id });
            }
        }

        // Appliquer le bloc déposé (tous les créneaux fusionnés)
        const targetMin = this._heureToMin(targetHeure);
        block.forEach((c, i) => {
            const newHeure = this._minToHeure(targetMin + offsets[i]);
            if (isCopy) {
                ops.push({
                    type: 'create',
                    data: this._buildFullCreneauData(c, {
                        id: null,
                        eleve_id: targetEleveId,
                        heure_debut: newHeure,
                    })
                });
            } else {
                ops.push({
                    type: 'update',
                    id: c.id,
                    data: this._buildFullCreneauData(c, {
                        eleve_id: targetEleveId,
                        heure_debut: newHeure,
                    })
                });
            }
        });

        return ops;
    },

    /**
     * Construit un objet complet pour l'API creneaux.
     * Prend un créneau source et fusionne les overrides.
     * Nettoie les champs non-BD (eleve_nom, eleve_prenom, etc.)
     */
    _buildFullCreneauData(source, overrides) {
        const allowed = [
            'eleve_id', 'semaine_id', 'jour', 'heure_debut', 'duree',
            'matiere', 'groupe', 'adulte', 'role_adulte',
            'type', 'regroupement_type', 'couleur_override', 'commentaire'
        ];
        const data = {};
        for (const key of allowed) {
            if (overrides && key in overrides) {
                data[key] = overrides[key];
            } else if (source && key in source) {
                data[key] = source[key];
            }
        }
        // Valeurs par défaut
        if (data.eleve_id === undefined) data.eleve_id = null;
        if (data.duree === undefined) data.duree = this._params?.horaires?.duree_creneau || 15;
        if (data.type === undefined) data.type = 'fixe';
        if (data.regroupement_type === undefined) data.regroupement_type = 'AUTRE';
        // Semaine_id
        if (this._semaineId !== null) data.semaine_id = this._semaineId;
        return data;
    },

    /**
     * Exécute les opérations API (update/create/delete) en batch
     * puis rechargement + rebuild
     */
    async _executeOps(ops) {
        const tasks = ops.map(op => {
            switch (op.type) {
                case 'update': return API.put('creneaux.php?id=' + op.id, op.data);
                case 'create': return API.post('creneaux.php', op.data);
                case 'delete': return API.del('creneaux.php?id=' + op.id);
                default: return null;
            }
        }).filter(Boolean);

        try {
            await Promise.all(tasks);
            await this._markModified();
            // Recharger les créneaux
            this._creneaux = await API.get('creneaux.php' + (this._semaineId !== null ? '?semaine_id=' + this._semaineId : '?semaine_id=null'));
            this._creneaux = this._creneaux.map(c => ({ ...c, heure_debut: c.heure_debut?.substring(0, 5) }));
            this._rebuildGrid();
        } catch (e) {
            Toast.error(e.message || 'Erreur lors de la sauvegarde');
            throw e;
        }
    },

});
