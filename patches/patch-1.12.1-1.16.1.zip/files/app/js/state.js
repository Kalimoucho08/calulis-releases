/**
 * Calulis — Store central Pub/Sub
 * Usage : state.on('event', callback) / state.emit('event', data)
 *         state.get(key) / state.set(key, value)
 */
const State = {
    _data: {},
    _listeners: {},

    get(key) {
        return this._data[key];
    },

    set(key, value) {
        const prev = this._data[key];
        this._data[key] = value;
        this.emit(key + ':changed', { prev, value });
        this.emit('state:changed', { key, prev, value });
    },

    on(event, callback) {
        if (!this._listeners[event]) this._listeners[event] = [];
        this._listeners[event].push(callback);
    },

    off(event, callback) {
        if (!this._listeners[event]) return;
        this._listeners[event] = this._listeners[event].filter(cb => cb !== callback);
    },

    emit(event, data) {
        if (!this._listeners[event]) return;
        this._listeners[event].forEach(cb => {
            try { cb(data); } catch (e) { console.error('[State] Error in listener for', event, e); }
        });
    },

    /**
     * Charge l'année active depuis l'API et initialise le state
     * Appelé au boot de l'app
     */
    async initAnneeScolaire() {
        try {
            const resp = await fetch('/api/annees_scolaires.php?active=1');
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            const active = await resp.json();
            if (active && active.id) {
                this.set('annee_scolaire_id', active.id);
                this.set('annee_active', active);
            }
            // Charger la liste des années
            const respAll = await fetch('/api/annees_scolaires.php');
            if (respAll.ok) {
                const all = await respAll.json();
                this.set('annees', all);
            }
            this.set('toutes_periodes', false);
        } catch (e) {
            console.warn('[State] Impossible de charger l\'année active:', e);
            this.set('annee_scolaire_id', null);
            this.set('annees', []);
            this.set('toutes_periodes', false);
            // Alerte visible au boot (sinon l'échec reste silencieux)
            if (typeof Toast !== 'undefined') {
                Toast.error('Impossible de contacter le serveur Calulis. Vérifiez que l\'application est bien démarrée.');
            }
        }
    },

    /**
     * Retourne la liste des paramètres qui changent selon l'année active
     */
    getQueryParams() {
        const params = {};
        const anneeId = this.get('annee_scolaire_id');
        const toutesPeriodes = this.get('toutes_periodes');
        if (anneeId && !toutesPeriodes) {
            params.annee_scolaire_id = anneeId;
        }
        return params;
    },

    /**
     * NOTE — Annuler / Rétablir : il n'y a plus de mécanisme d'historique ici.
     * Les boutons ↶ ↷ de la barre d'état, grisés depuis toujours, ont été retirés
     * le 29/09/2026, ainsi que l'ébauche qui dormait dans ce fichier.
     * Raison : un vrai Annuler ne peut pas être un instantané des données du client —
     * chaque modification part à l'API et est écrite en base. L'implémenter demande
     * une conception côté serveur (journal des opérations, portée, conflits), pas une
     * petite correction. À reprendre comme un chantier à part entière.
     */

    /**
     * NOTE — `save()` / `load()` (localStorage) ont été retirés le 29/09/2026 : personne ne
     * les appelait. L'état de Calulis se reconstruit à chaque démarrage depuis l'API (année
     * active, paramètres) ; le conserver dans le navigateur n'apportait rien et pouvait
     * afficher un état périmé au premier rendu. Les préférences d'affichage (thème) ont leur
     * propre mécanisme.
     */
};
