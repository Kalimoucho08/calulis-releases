/**
 * Calulis — Routeur hash-based
 * Navigation : #dashboard, #eleves, #listes, #adultes, #agenda, #evenements, #reunions,
 * #stats, #etablissements, #classes, #annuaire, #aide, #mentions-rgpd, #print, #params, #don
 */
const Router = {
    _current: 'dashboard',
    _views: {},

    init() {
        window.addEventListener('hashchange', () => this._onChange());
        // Toujours activer la vue correspondant au hash (ou dashboard)
        const hash = window.location.hash.substring(1) || 'dashboard';
        this._show(hash);
    },

    /** Naviguer vers une vue */
    go(name) {
        if (name === this._current) return;
        window.location.hash = '#' + name;
    },

    _onChange() {
        const name = window.location.hash.substring(1) || 'dashboard';
        this._show(name);
    },

    _show(name) {
        // Aliases
        if (name === 'impression') name = 'print';
        if (name === 'eleve') name = 'eleves';
        if (name === 'adult') name = 'adultes';
        // Vue inconnue ou retirée (ex. un ancien lien #documents, dont le module
        // n'existe pas encore) : on retombe sur le tableau de bord plutôt que
        // d'afficher une zone vide sans rien dire.
        if (!document.getElementById('view-' + name)) name = 'dashboard';
        // Cacher vue courante
        const currentView = document.getElementById('view-' + this._current);
        if (currentView) currentView.classList.remove('active');

        // Afficher nouvelle vue
        const newView = document.getElementById('view-' + name);
        if (newView) newView.classList.add('active');

        this._current = name;
        State.set('currentView', name);
    },

    /** Vue actuelle */
    get current() { return this._current; },
};
