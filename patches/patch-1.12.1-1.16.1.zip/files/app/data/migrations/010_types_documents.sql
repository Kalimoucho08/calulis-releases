-- Migration 010 : les types de documents deviennent une DONNÉE (module Documents, 1.16)
--
-- Contexte. Les types de documents vivaient dans une constante PHP (`Document::TYPES`) :
-- impossible de les faire évoluer sans livrer une nouvelle version, impossible d'en ajouter
-- un qui vient de paraître, impossible de renommer. Or les besoins changent avec le temps,
-- et ils diffèrent d'un établissement à l'autre (primaire, collège, lycée). Demande de
-- Jérôme, 08/10/2026 : un éditeur de types de documents.
--
-- CE QUI EST CRÉÉ ICI
--   `types_documents` : cle (jamais modifiée), libelle (renommable), ordre, actif.
--   Les 16 types livrés jusqu'ici y sont amorcés (`INSERT IGNORE`, donc rejouable) : c'est
--   un POINT DE DÉPART, pas un socle intouchable — décision de Jérôme : « rien n'est livré,
--   on refait complètement cette partie ».
--
-- CE QUI N'EST PAS TOUCHÉ
--   La colonne `documents.type` (varchar) garde la CLÉ du type, jamais son libellé : renommer
--   un type change donc son affichage partout, y compris sur les documents déjà classés,
--   sans y toucher. Aucun document existant n'est modifié par cette migration.
--
-- ATTENTION : le lanceur de migrations découpe le fichier sur chaque point-virgule, y compris
-- dans les commentaires — ne jamais mettre de point-virgule ailleurs qu'en fin d'instruction.

CREATE TABLE IF NOT EXISTS types_documents (
  id int(11) NOT NULL AUTO_INCREMENT,
  cle varchar(50) NOT NULL,
  libelle varchar(120) NOT NULL,
  ordre int(11) NOT NULL DEFAULT 0,
  actif tinyint(1) NOT NULL DEFAULT 1,
  created_at timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY uk_types_documents_cle (cle)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT IGNORE INTO types_documents (cle, libelle, ordre, actif) VALUES
  ('notification_mdph', 'Notification MDPH', 1, 1),
  ('pps', 'PPS (projet personnalisé de scolarisation)', 2, 1),
  ('gevasco', 'GEVA-Sco', 3, 1),
  ('compte_rendu_ess', 'Compte rendu d''ESS', 4, 1),
  ('compte_rendu_ee', 'Compte rendu d''équipe éducative', 5, 1),
  ('pai', 'PAI (projet d''accueil individualisé)', 6, 1),
  ('medical', 'Document médical', 7, 1),
  ('bilan_professionnel', 'Bilan d''un professionnel', 8, 1),
  ('mopps', 'MOPPS (mise en œuvre du PPS)', 9, 1),
  ('institution', 'Document institutionnel (LPI, LSU…)', 10, 1),
  ('courrier', 'Courrier', 11, 1),
  ('bulletin', 'Bulletin / évaluation', 12, 1),
  ('fiche_urgence', 'Fiche de renseignements / urgence', 13, 1),
  ('synthese', 'Synthèse / bilan de période', 14, 1),
  ('convocation', 'Convocation', 15, 1),
  ('autre', 'Autre', 16, 1)
