-- Migration 008 : chantier « Suivi & Tâches » (04/10/2026)
--
-- Sur la table `taches` :
--   * `couleur`   : couleur du post-it (jaune, vert, bleu, rose, violet, orange)
--   * `adulte_id` : lien facultatif vers un adulte (le lien vers un élève, `eleve_id`, existe déjà)
--   * `responsable` renommée `precision_libre` : le responsable d'exécution n'existe pas (Calulis est
--     monoposte, la tâche incombe au coordonnateur), la colonne devient le champ libre court de
--     100 caractères (établissement, interlocuteur) décidé le 04/10/2026.
--     Nommée `precision_libre` et non `precision` : `PRECISION` est un mot réservé de MySQL 8.
--
-- La table `notes_suivi` n'a besoin d'aucun changement : la colonne `auteur` reste en place mais
-- n'est plus proposée à la saisie (elle est nullable).
--
-- Chaque instruction est idempotente (rejouable sans erreur), sur le modèle de la migration 007.
-- ATTENTION : le lanceur de migrations découpe le fichier sur chaque point-virgule, y compris
-- dans les commentaires — ne jamais mettre de point-virgule ailleurs qu'en fin d'instruction.

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'taches' AND COLUMN_NAME = 'couleur');
SET @sql := IF(@c = 0,
  'ALTER TABLE taches ADD COLUMN couleur VARCHAR(20) NOT NULL DEFAULT ''jaune'' AFTER statut',
  'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'taches' AND COLUMN_NAME = 'adulte_id');
SET @sql := IF(@c = 0,
  'ALTER TABLE taches ADD COLUMN adulte_id INT NULL AFTER eleve_id',
  'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @a := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'taches' AND COLUMN_NAME = 'responsable');
SET @b := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'taches' AND COLUMN_NAME = 'precision_libre');
SET @sql := IF(@a = 1 AND @b = 0,
  'ALTER TABLE taches CHANGE COLUMN `responsable` `precision_libre` VARCHAR(100) NULL',
  'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @f := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'taches'
             AND CONSTRAINT_NAME = 'fk_taches_adulte' AND CONSTRAINT_TYPE = 'FOREIGN KEY');
SET @sql := IF(@f = 0,
  'ALTER TABLE taches ADD CONSTRAINT fk_taches_adulte FOREIGN KEY (adulte_id) REFERENCES adultes(id) ON DELETE SET NULL',
  'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
