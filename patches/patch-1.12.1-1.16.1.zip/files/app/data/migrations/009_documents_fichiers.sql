-- Migration 009 : module Documents (1.16) — où vit le fichier rapatrié
--
-- Contexte. La table `fichiers` décrit un fichier déposé sur le disque et son
-- rattachement à une entité (document, eleve, reunion...). Elle figurait dans les
-- dumps d'installation, mais AUCUNE migration ne la créait : une installation
-- mise à jour ne l'avait donc pas. C'est cette migration qui la crée, et elle ne
-- touche à rien d'autre — `documents` porte déjà ses colonnes (`annee_scolaire_id`
-- vient de la migration multi-année, `auteur_id` et `destinataire` du schéma
-- d'anticipation).
--
-- Où vit le fichier. Sous `<racine>/runtime/documents/eleve-<id>/`. Deux raisons :
-- `runtime/` survit aux mises à jour, et il est HORS de la racine web (`app/`),
-- donc un document n'est jamais joignable par une URL directe — c'est l'API qui
-- le sert, après contrôle. Le commentaire d'origine de `fichiers.chemin` parle de
-- `data/uploads/` : il est périmé, `app/data/` n'est plus servi du tout.
--
-- Chaque instruction est idempotente (rejouable sans erreur), sur le modèle des
-- migrations 007 et 008.
-- ATTENTION : le lanceur de migrations découpe le fichier sur chaque point-virgule,
-- y compris dans les commentaires — ne jamais mettre de point-virgule ailleurs
-- qu'en fin d'instruction.

CREATE TABLE IF NOT EXISTS fichiers (
  id int(11) NOT NULL AUTO_INCREMENT,
  entite_type varchar(50) NOT NULL,
  entite_id int(11) NOT NULL,
  nom_original varchar(500) NOT NULL,
  nom_stocke varchar(200) NOT NULL,
  chemin varchar(500) NOT NULL,
  taille int(11) DEFAULT NULL,
  type_mime varchar(100) DEFAULT NULL,
  categorie varchar(50) DEFAULT NULL,
  uploade_par varchar(100) DEFAULT NULL,
  created_at timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  KEY fichiers_entite_idx (entite_type, entite_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci
