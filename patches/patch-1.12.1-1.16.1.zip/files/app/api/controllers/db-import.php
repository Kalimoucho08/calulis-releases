<?php
/**
 * Calulis — Restauration d'une sauvegarde .sql
 * POST /db-import.php (multipart: sqlfile) → remplace la base courante
 *
 * SÉCURITÉ (AUDIT-1.15.1.md, B4)
 * Avant le 05/10/2026, ce contrôleur rejouait le fichier reçu (DROP/CREATE par
 * table) sans AUCUNE sauvegarde préalable : un fichier abîmé, une coupure, et
 * les données de l'utilisateur étaient perdues. Désormais :
 *   1. le contenu est analysé et les instructions visant une AUTRE base sont refusées ;
 *   2. la base actuelle est sauvegardée — si la sauvegarde échoue, RIEN n'est importé ;
 *   3. le fichier utilisé et le chemin de la sauvegarde sont nommés dans la réponse.
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Sauvegarde.php';
require_once __DIR__ . '/../models/ImportSql.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonError('Méthode non supportée', 405);
}

if (calulis_est_heberge() && getenv('CALULIS_ALLOW_IMPORT') !== '1') {
    jsonError('Import désactivé sur un déploiement hébergé', 403);
}

$file = $_FILES['sqlfile'] ?? null;
if (!$file || ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    jsonError('Fichier manquant ou erreur d\'upload (code ' . ($file['error'] ?? 'inconnu') . ')', 400);
}

$nomFichier = basename((string) ($file['name'] ?? 'sauvegarde.sql'));
$sql = file_get_contents($file['tmp_name']);
if ($sql === false || trim($sql) === '') {
    jsonError('Le fichier « ' . $nomFichier . ' » est vide : rien n\'a été modifié.', 400);
}

try {
    $pdo = getDB();

    // 1. Le fichier ne doit pas sortir du périmètre de la base courante.
    ImportSql::verifier($pdo, $sql);

    // 2. Ce qui va être remplacé — mesuré AVANT (et non supposé).
    $avant = calulis_compter_base($pdo);

    // 3. Sauvegarde obligatoire. Si elle échoue, on n'importe RIEN.
    try {
        $sauvegarde = Sauvegarde::ecrireFichier($pdo, 'avant-restauration');
    } catch (\Throwable $e) {
        calulis_log_error('SAUVEGARDE PRÉALABLE ÉCHOUÉE (restauration annulée) : ' . $e->getMessage());
        jsonError(
            "Restauration annulée : la sauvegarde de vos données actuelles a échoué ("
            . $e->getMessage() . "). AUCUNE donnée n'a été modifiée.",
            500
        );
    }

    // 4. Import.
    $resultat = ImportSql::executer($pdo, $sql);

    if (count($resultat['erreurs']) > 0) {
        calulis_log_error('IMPORT PARTIEL : ' . implode(' | ', array_slice($resultat['erreurs'], 0, 5)));
        jsonError(
            $resultat['instructions'] . ' instruction(s) exécutée(s), '
            . count($resultat['erreurs']) . ' erreur(s). '
            . 'Vos données d\'avant la restauration sont conservées dans : ' . $sauvegarde['chemin'] . '. '
            . 'Détail : ' . implode(' | ', array_slice($resultat['erreurs'], 0, 3)),
            500
        );
    }

    $apres = calulis_compter_base($pdo);

    jsonResponse([
        'ok' => true,
        'fichier' => $nomFichier,
        'instructions' => $resultat['instructions'],
        'avant' => $avant,
        'apres' => $apres,
        'sauvegarde' => $sauvegarde['chemin'],
        'message' => "Sauvegarde « {$nomFichier} » restaurée ({$resultat['instructions']} instructions). "
            . 'Avant : ' . calulis_resume_comptes($avant) . '. '
            . 'Maintenant : ' . calulis_resume_comptes($apres) . '.',
    ]);
} catch (\RuntimeException $e) {
    // Refus de sûreté (fichier visant une autre base, sauvegarde impossible…) :
    // le message est destiné à l'utilisateur et doit lui parvenir tel quel.
    jsonError($e->getMessage(), 400);
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
