<?php
/** Calulis — Controller « Tâches » (CRUD REST, multi-année)
 *
 *  GET    api/taches.php?annee_scolaire_id=…&statut=…&eleve_id=…&adulte_id=…&du=…&au=…&a_venir=1
 *  GET    api/taches.php?id=…
 *  POST   api/taches.php        (body JSON : description ou titre+detail, eleve_id, adulte_id,
 *                                echeance, priorite, statut, couleur, precision_libre)
 *  PUT    api/taches.php?id=…    (body JSON : les champs à modifier)
 *  DELETE api/taches.php?id=…
 */
require_once __DIR__ . '/../models/Tache.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$anneeId = isset($_GET['annee_scolaire_id']) ? (int)$_GET['annee_scolaire_id'] : null;

try {
    switch ($method) {

        case 'GET':
            if ($id) {
                $tache = Tache::find($id);
                if (!$tache) jsonError('Tâche non trouvée', 404);
                jsonResponse($tache);
            }
            jsonResponse(Tache::all($anneeId, [
                'statut'    => $_GET['statut'] ?? null,
                'eleve_id'  => $_GET['eleve_id'] ?? null,
                'adulte_id' => $_GET['adulte_id'] ?? null,
                'du'        => $_GET['du'] ?? null,
                'au'        => $_GET['au'] ?? null,
                'a_venir'   => $_GET['a_venir'] ?? null,
            ]));
            break;

        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true) ?: [];
            $bodyAnneeId = isset($input['annee_scolaire_id']) && $input['annee_scolaire_id'] !== ''
                ? (int)$input['annee_scolaire_id']
                : $anneeId;
            $newId = Tache::create($input, $bodyAnneeId);
            jsonResponse(['ok' => true, 'id' => $newId], 201);
            break;

        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true) ?: [];
            $cible = $id ?: (int)($input['id'] ?? 0);
            if ($cible <= 0) jsonError('Identifiant de tâche manquant');
            Tache::update($cible, $input);
            jsonResponse(['ok' => true]);
            break;

        case 'DELETE':
            if (!$id) jsonError('Identifiant de tâche manquant');
            if (!Tache::delete($id)) jsonError('Tâche non trouvée', 404);
            jsonResponse(['ok' => true]);
            break;

        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (InvalidArgumentException $e) {
    jsonError($e->getMessage(), 400);
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
