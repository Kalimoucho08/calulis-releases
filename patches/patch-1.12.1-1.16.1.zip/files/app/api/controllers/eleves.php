<?php
/** Calulis — Controller Élèves (CRUD REST, multi-année) */
require_once __DIR__ . '/../models/Eleve.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$anneeId = isset($_GET['annee_scolaire_id']) ? (int)$_GET['annee_scolaire_id'] : null;

try {
    switch ($method) {

        case 'GET':
            if ($id) {
                $eleve = Eleve::find($id, $anneeId);
                if (!$eleve) jsonError('Élève non trouvé', 404);
                jsonResponse($eleve);
            }
            // Recherche ou liste
            $q = $_GET['q'] ?? '';
            $classe = $_GET['classe'] ?? '';
            $classeId = isset($_GET['classe_id']) ? (int)$_GET['classe_id'] : null;
            $ulis = isset($_GET['ulis']) ? ($_GET['ulis'] === '1') : null;
            $actif = isset($_GET['actif']) ? ($_GET['actif'] === '1') : null;
            if ($q !== '' || $classe !== '' || $classeId !== null || $ulis !== null || $actif !== null) {
                jsonResponse(Eleve::search($q, $classe, $ulis, $actif, $anneeId, $classeId));
            }
            $inclureInactifs = isset($_GET['inclure_inactifs']) ? (bool)$_GET['inclure_inactifs'] : true;
            jsonResponse(Eleve::all($inclureInactifs, $anneeId));

            break;
        case 'POST':
            // Action purge
            $action = $_GET['action'] ?? '';
            if ($action === 'purge') {
                $before = $_GET['before'] ?? '';
                if (!$before || !preg_match('/^\d{4}-\d{2}-\d{2}$/', $before)) {
                    jsonError('Date limite invalide (format YYYY-MM-DD requis)');
                }
                $purge = Eleve::purgeInactifsAvant($before);
                jsonResponse([
                    'ok'        => true,
                    // « purged » reste le nombre d'ÉLÈVES : l'écran des paramètres s'en sert tel quel.
                    'purged'    => $purge['eleves'],
                    'documents' => $purge['documents'],
                    'fichiers'  => $purge['fichiers'],
                    // Ce qui n'a PAS pu être effacé est dit, jamais tu : l'écran doit pouvoir l'annoncer.
                    'fichiers_restants' => $purge['fichiers_restants'],
                    'dossiers_restants' => $purge['dossiers_restants'],
                ]);
            }
            $input = json_decode(file_get_contents('php://input'), true);
            if (empty($input['nom']) || empty($input['prenom'])) {
                jsonError('Nom et prénom requis');
            }
            // Établissement requis à la création : message clair au lieu d'une erreur SQL brute
            if (!isset($input['etablissement_id']) || $input['etablissement_id'] === '' || $input['etablissement_id'] === null) {
                jsonError("Aucun établissement sélectionné. Crée d'abord ton établissement (menu Établissements ou Paramètres), puis choisis-le dans l'onglet « Scolarité » de la fiche élève.");
            }
            // Si annee_scolaire_id passé dans le body, l'utiliser
            $bodyAnneeId = $input['annee_scolaire_id'] ?? $anneeId;
            $newId = Eleve::create($input, $bodyAnneeId);
            jsonResponse(['ok' => true, 'id' => $newId], 201);

            break;
        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            // Réordonnancement des élèves
            if (($input['action'] ?? '') === 'reorder' && !empty($input['ordres'])) {
                Eleve::reorder($input['ordres']);
                jsonResponse(['ok' => true]);
            }
            if (!$id) jsonError('ID requis');
            // Empêcher de vider l'établissement (message clair)
            if (array_key_exists('etablissement_id', $input) && ($input['etablissement_id'] === '' || $input['etablissement_id'] === null)) {
                jsonError("L'établissement ne peut pas être vide. Choisis un établissement dans l'onglet « Scolarité ».");
            }
            // Si annee_scolaire_id passé dans le body, l'utiliser
            $bodyAnneeId = $input['annee_scolaire_id'] ?? $anneeId;
            Eleve::update($id, $input, $bodyAnneeId);
            jsonResponse(['ok' => true]);

            break;
        case 'DELETE':
            if (!$id) jsonError('ID requis');
            // Le sort des documents est un CHOIX EXPLICITE du client, jamais un défaut.
            // Avant le 08/10/2026, supprimer un élève laissait ses documents et ses
            // fichiers sur le disque sans le dire : un écart au droit à l'effacement
            // que la page « Mentions RGPD » promettait déjà.
            if (($_GET['documents'] ?? '') !== 'supprimer') {
                jsonError("Précisez le sort des documents de cet élève : ajoutez « documents=supprimer ».", 400);
            }
            if (!Eleve::find($id)) {
                jsonError('Élève non trouvé', 404);
            }
            $effacement = Eleve::delete($id, true);
            jsonResponse([
                'ok'        => true,
                'documents' => $effacement['documents'] ?? 0,
                'fichiers'  => $effacement['fichiers'] ?? 0,
                // Un fichier qui résiste (verrouillé par un lecteur PDF) est DIT, jamais tu :
                // l'écran doit pouvoir l'annoncer au lieu de laisser croire à un effacement complet.
                'fichiers_restants' => $effacement['fichiers_restants'] ?? 0,
                'dossier_supprime'  => $effacement['dossier_supprime'] ?? true,
            ]);

            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    // Helper partagé : journalise l'erreur réelle (php-error.log) et
    // répond un message propre (jamais de SQL brut exposé)
    calulis_handle_error($e);
}
