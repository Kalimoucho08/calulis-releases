<?php
// @calulis-controleur-dev - outil de DEVELOPPEMENT : retire du paquet portable
// a la construction (scripts/build-portable.ps1) et refuse par le routeur en production.
/** Reset complet de la base → exécute setup-test puis propagation */
require_once __DIR__ . '/../config.php';

if (getenv('CALULIS_ENV') === 'production') { http_response_code(403); die('Accès interdit en production'); }

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonError('POST requis', 405);
}

try {
    $pdo = getDB();

    // 1. Nettoyer
    $tables = ['creneaux','eleve_annees','adultes','adultes_etablissements','etablissements','eleves','semaines','periodes','parametres','pauses','vacances','annees_scolaires'];
    $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
    foreach ($tables as $t) $pdo->exec("DELETE FROM $t");
    $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');

    // 2. Recréer via setup-test
    ob_start();
    require __DIR__ . '/setup-test.php';
    ob_end_clean();
    // setup-test s'arrête après avoir créé le template

    // 3. Propager vers toutes les semaines
    require_once __DIR__ . '/../models/Creneau.php';
    $semaines = $pdo->query("SELECT id FROM semaines WHERE est_vacances = 0 ORDER BY numero")->fetchAll(PDO::FETCH_COLUMN);
    foreach ($semaines as $sid) Creneau::copyFromTemplate($sid);

    // 4. Variations sur ~30% des semaines
    $elevesIds = $pdo->query("SELECT id FROM eleves WHERE actif = 1")->fetchAll(PDO::FETCH_COLUMN);
    $jours = ['lundi','mardi','jeudi','vendredi'];
    $count = 0;
    foreach ($semaines as $sid) {
        $stmt = $pdo->prepare("SELECT numero FROM semaines WHERE id = ?");
        $stmt->execute([$sid]);
        $num = $stmt->fetchColumn();
        $rand = ($num * 7 + 3) % 10;
        if ($rand >= 3) continue;
        $count++;

        $limit = rand(2, 5);
        $stmt = $pdo->prepare("SELECT id, eleve_id, jour, heure_debut, duree FROM creneaux WHERE semaine_id = ? ORDER BY RAND() LIMIT ?");
        $stmt->execute([$sid, $limit]);
        $creneaux = $stmt->fetchAll();
        foreach ($creneaux as $c) {
            if ($rand == 0) {
                $newHeure = date('H:i', strtotime($c['heure_debut']) + 900);
                if ($newHeure < '16:30') {
                    $pdo->prepare("UPDATE creneaux SET heure_debut = ? WHERE id = ?")->execute([$newHeure, $c['id']]);
                }
            } elseif ($rand == 1) {
                $other = $elevesIds[array_rand($elevesIds)];
                if ($other != $c['eleve_id']) {
                    $pdo->prepare("UPDATE creneaux SET eleve_id = ? WHERE id = ?")->execute([$other, $c['id']]);
                }
            } else {
                $eid = $elevesIds[array_rand($elevesIds)];
                $j = $jours[array_rand($jours)];
                $h = ['08:30','09:00','10:15','11:00','13:30','14:45','15:30'][array_rand(range(0,6))];
                $m = ['Sortie scolaire','Projet','Évaluation','Atelier','Intervention'][array_rand(range(0,4))];
                $pdo->prepare("INSERT INTO creneaux (eleve_id, semaine_id, jour, heure_debut, duree, matiere, type, regroupement_type) VALUES (?,?,?,?,?,?,'exception','AUTRE')")
                    ->execute([$eid, $sid, $j, $h, rand(1,4)*15, $m]);
            }
        }
        $pdo->prepare("UPDATE semaines SET est_modifiee = 1 WHERE id = ?")->execute([$sid]);
    }

    // 5. Booster les variations (tags visibles)
    $modifiees = $pdo->query("SELECT id, numero FROM semaines WHERE est_modifiee = 1")->fetchAll();
    foreach ($modifiees as $s) {
        $pdo->prepare("UPDATE creneaux SET matiere = CONCAT(matiere, ' ⚡S" . $s['numero'] . "') WHERE semaine_id = ? AND type != 'pause' ORDER BY RAND() LIMIT 3")->execute([$s['id']]);
        $e = $pdo->query("SELECT id FROM eleves WHERE actif = 1 ORDER BY RAND() LIMIT 1")->fetchColumn();
        $pdo->prepare("INSERT INTO creneaux (eleve_id, semaine_id, jour, heure_debut, duree, matiere, adulte, role_adulte, type, regroupement_type) VALUES (?, ?, 'lundi', '11:30', 30, 'SEMAINE MODIFIEE S" . $s['numero'] . "', 'M. Dupont', 'enseignant', 'exception', 'ULIS')")->execute([$e, $s['id']]);
    }

    // 6. Enrichissement V3 (données réalistes : ASE, PAI, MDPH, représentants, AESH, PEC, réunions)
    $enrich3 = __DIR__ . '/../../data/calulis-enrich-v3.sql';
    if (file_exists($enrich3)) {
        exec("mysql -u calulis -pcalulis -S /var/run/mysqld/mysqld.sock calulis < " . escapeshellarg($enrich3) . " 2>/dev/null");   // ggignore - mot de passe de demonstration, public et documente (remplace par un mot de passe aleatoire par installation depuis la 1.15.1)
    }

    // 7. Enrichissement V4 (établissements + rattachements)
    $enrich4 = __DIR__ . '/../../data/calulis-enrich-v4.sql';
    if (file_exists($enrich4)) {
        exec("mysql -u calulis -pcalulis -S /var/run/mysqld/mysqld.sock calulis < " . escapeshellarg($enrich4) . " 2>/dev/null");   // ggignore - mot de passe de demonstration, public et documente (remplace par un mot de passe aleatoire par installation depuis la 1.15.1)
    }

    $total = $pdo->query("SELECT COUNT(*) FROM creneaux")->fetchColumn();
    jsonResponse(['ok' => true, 'message' => "Base reset OK — $total créneaux, $count semaines avec variations (données V4 enrichies)"]);

} catch (\Throwable $e) {
    jsonError('Erreur reset : ' . $e->getMessage(), 500);
}
