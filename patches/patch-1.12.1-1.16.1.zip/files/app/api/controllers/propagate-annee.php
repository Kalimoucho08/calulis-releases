<?php
// @calulis-controleur-dev - outil de DEVELOPPEMENT : retire du paquet portable
// a la construction (scripts/build-portable.ps1) et refuse par le routeur en production.
/** Propager le template vers toutes les semaines avec variations */
require_once __DIR__ . '/../config.php';
if (getenv('CALULIS_ENV') === 'production') { http_response_code(403); die('Accès interdit en production'); }
require_once __DIR__ . '/../models/Creneau.php';

$pdo = getDB();

// Récupérer les semaines scolaires (non vacances)
$semaines = $pdo->query("SELECT id, numero, date_debut FROM semaines WHERE est_vacances = 0 ORDER BY numero")->fetchAll();
$elevesIds = $pdo->query("SELECT id FROM eleves WHERE actif = 1")->fetchAll(PDO::FETCH_COLUMN);
$jours = ['lundi', 'mardi', 'jeudi', 'vendredi'];

echo "Propagation vers " . count($semaines) . " semaines...\n";

$total = 0;
$variations = 0;

foreach ($semaines as $s) {
    $sid = $s['id'];
    $num = $s['numero'];

    // Copier le template
    Creneau::copyFromTemplate($sid);

    // Variations aléatoires (~30% des semaines ont des modifs)
    $rand = ($num * 7 + 3) % 10; // déterministe mais varie par semaine

    if ($rand < 3) {
        $variations++;
        $creneaux = $pdo->prepare("SELECT id, eleve_id, jour, heure_debut, duree, matiere FROM creneaux WHERE semaine_id = ? ORDER BY RAND() LIMIT ?");
        $creneaux->execute([$sid, rand(2, 5)]);
        $toModify = $creneaux->fetchAll();

        foreach ($toModify as $c) {
            if ($rand == 0) {
                // Décaler l'heure de 15 min
                $newHeure = date('H:i', strtotime($c['heure_debut']) + 900);
                if ($newHeure < '16:30') {
                    $pdo->prepare("UPDATE creneaux SET heure_debut = ? WHERE id = ?")->execute([$newHeure, $c['id']]);
                }
            } elseif ($rand == 1) {
                // Changer d'élève (swap avec un autre)
                $other = $elevesIds[array_rand($elevesIds)];
                if ($other != $c['eleve_id']) {
                    $pdo->prepare("UPDATE creneaux SET eleve_id = ? WHERE id = ?")->execute([$other, $c['id']]);
                }
            } else {
                // Ajouter un créneau exceptionnel
                $eid = $elevesIds[array_rand($elevesIds)];
                $jour = $jours[array_rand($jours)];
                $heures = ['08:30', '09:00', '10:15', '11:00', '13:30', '14:45', '15:30'];
                $matieres = ['Sortie scolaire', 'Projet ponctuel', 'Évaluation', 'Atelier décloisonné', 'Intervention extérieure'];
                $adultes = ['M. Dupont', 'Intervenant', '', 'Mme Martin'];
                $pdo->prepare("INSERT INTO creneaux (eleve_id, semaine_id, jour, heure_debut, duree, matiere, adulte, role_adulte, type, regroupement_type) VALUES (?,?,?,?,?,?,?,?,?,?)")
                    ->execute([$eid, $sid, $jour, $heures[array_rand($heures)], rand(1,4)*15, $matieres[array_rand($matieres)], $adultes[array_rand($adultes)], 'enseignant', 'exception', 'AUTRE']);
            }
        }

        // Marquer la semaine comme modifiée
        $pdo->prepare("UPDATE semaines SET est_modifiee = 1 WHERE id = ?")->execute([$sid]);
    }

    $stmt = $pdo->prepare("SELECT COUNT(*) FROM creneaux WHERE semaine_id = ?");
    $stmt->execute([$sid]);
    $count = $stmt->fetchColumn();
    $total += $count;
}

echo "✓ $total créneaux créés ($variations semaines avec variations)\n";
