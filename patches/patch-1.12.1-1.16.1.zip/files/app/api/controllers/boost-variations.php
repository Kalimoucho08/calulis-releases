<?php
// @calulis-controleur-dev - outil de DEVELOPPEMENT : retire du paquet portable
// a la construction (scripts/build-portable.ps1) et refuse par le routeur en production.
/** Rend les variations ultra-visibles dans les semaines modifiées */
require_once __DIR__ . '/../config.php';
if (getenv('CALULIS_ENV') === 'production') { http_response_code(403); die('Accès interdit en production'); }
$pdo = getDB();

$modifiees = $pdo->query("SELECT id, numero FROM semaines WHERE est_modifiee = 1 ORDER BY numero")->fetchAll();

foreach ($modifiees as $s) {
    $sid = $s['id'];
    $num = $s['numero'];

    // Modifier 3 créneaux avec un tag visible
    $pdo->prepare("UPDATE creneaux SET matiere = CONCAT(matiere, ' ⚡S" . $num . "') WHERE semaine_id = ? AND type != 'pause' ORDER BY RAND() LIMIT 3")->execute([$sid]);

    // Ajouter un créneau flashy pour un élève au hasard
    $eleve = $pdo->query("SELECT id FROM eleves WHERE actif = 1 ORDER BY RAND() LIMIT 1")->fetchColumn();
    $pdo->prepare("INSERT INTO creneaux (eleve_id, semaine_id, jour, heure_debut, duree, matiere, adulte, role_adulte, type, regroupement_type) VALUES (?, ?, 'lundi', '11:30', 30, 'SEMAINE MODIFIEE S" . $num . "', 'M. Dupont', 'enseignant', 'exception', 'ULIS')")->execute([$eleve, $sid]);

    echo "S$num ✓\n";
}
echo "OK — " . count($modifiees) . " semaines boostées\n";
