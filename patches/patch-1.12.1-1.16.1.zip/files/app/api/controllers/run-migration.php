<?php
// @calulis-controleur-dev - outil de DEVELOPPEMENT : retire du paquet portable
// a la construction (scripts/build-portable.ps1) et refuse par le routeur en production.
/** Calulis — Migration runner (multi-année)
 *  Accessible via POST /api/run-migration.php
 *  Exécute data/migration-multiannee.sql
 */
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonError('POST requis', 405);
}

if (getenv('CALULIS_ENV') === 'production') {
    jsonError('Interdit en production', 403);
}

try {
    $pdo = getDB();
    $sql = file_get_contents(__DIR__ . '/../../data/migration-multiannee.sql');
    if (!$sql) {
        jsonError('Fichier migration-multiannee.sql introuvable', 500);
    }

    $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');

    // Exécuter chaque statement
    $statements = explode(';', $sql);
    $count = 0;
    $errors = [];
    foreach ($statements as $stmt) {
        $stmt = trim($stmt);
        if ($stmt === '' || str_starts_with($stmt, '--')) continue;
        try {
            $pdo->exec($stmt);
            $count++;
        } catch (\Exception $e) {
            $errors[] = 'Erreur: ' . $e->getMessage() . ' | SQL: ' . mb_substr($stmt, 0, 100);
        }
    }

    $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');

    jsonResponse([
        'ok' => empty($errors),
        'statements_executed' => $count,
        'errors' => $errors,
        'message' => empty($errors) ? 'Migration multi-année appliquée avec succès' : 'Des erreurs sont survenues',
    ]);
} catch (\Throwable $e) {
    jsonError('Erreur: ' . $e->getMessage(), 500);
}
