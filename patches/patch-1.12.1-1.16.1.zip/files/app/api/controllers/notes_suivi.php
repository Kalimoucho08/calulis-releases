<?php
/** Calulis — Controller « Notes de suivi » (CRUD REST, multi-année)
 *
 *  GET    api/notes_suivi.php?annee_scolaire_id=…&eleve_id=…&type=…&du=…&au=…
 *  GET    api/notes_suivi.php?id=…
 *  POST   api/notes_suivi.php                (body JSON : eleve_id, date_note, type, contenu)
 *  PUT    api/notes_suivi.php?id=…            (body JSON : les champs à modifier)
 *  DELETE api/notes_suivi.php?id=…
 */
require_once __DIR__ . '/../models/NoteSuivi.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$anneeId = isset($_GET['annee_scolaire_id']) ? (int)$_GET['annee_scolaire_id'] : null;

try {
    switch ($method) {

        case 'GET':
            if ($id) {
                $note = NoteSuivi::find($id);
                if (!$note) jsonError('Note non trouvée', 404);
                jsonResponse($note);
            }
            jsonResponse(NoteSuivi::all($anneeId, [
                'eleve_id' => $_GET['eleve_id'] ?? null,
                'type'     => $_GET['type'] ?? null,
                'du'       => $_GET['du'] ?? null,
                'au'       => $_GET['au'] ?? null,
            ]));
            break;

        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true) ?: [];
            $bodyAnneeId = isset($input['annee_scolaire_id']) && $input['annee_scolaire_id'] !== ''
                ? (int)$input['annee_scolaire_id']
                : $anneeId;
            $newId = NoteSuivi::create($input, $bodyAnneeId);
            jsonResponse(['ok' => true, 'id' => $newId], 201);
            break;

        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true) ?: [];
            $cible = $id ?: (int)($input['id'] ?? 0);
            if ($cible <= 0) jsonError('Identifiant de note manquant');
            NoteSuivi::update($cible, $input);
            jsonResponse(['ok' => true]);
            break;

        case 'DELETE':
            if (!$id) jsonError('Identifiant de note manquant');
            if (!NoteSuivi::delete($id)) jsonError('Note non trouvée', 404);
            jsonResponse(['ok' => true]);
            break;

        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (InvalidArgumentException $e) {
    // Saisie invalide : message clair pour l'utilisateur, pas une erreur serveur
    jsonError($e->getMessage(), 400);
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
