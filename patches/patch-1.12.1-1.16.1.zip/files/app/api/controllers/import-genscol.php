<?php
/** Calulis — Controller Import Genscol
 *  POST /api/import-genscol.php
 *  Importe un fichier CSV d'export Genscol pour remplir INE et représentants.
 *  Format CSV attendu : nom, prenom, date_naissance, ine,
 *    responsable1_nom, responsable1_prenom, responsable1_lien,
 *    responsable1_tel, responsable1_email,
 *    responsable2_nom, responsable2_prenom, responsable2_lien,
 *    responsable2_tel, responsable2_email
 */
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonError('POST requis', 405);
}

// Fonction de l'utilisateur (bouton « Import CSV » des Paramètres) : autorisée
// dans le paquet portable, refusée sur un déploiement HÉBERGÉ. La condition
// portait sur CALULIS_ENV seul, or le lanceur pose désormais
// CALULIS_ENV=production (audit 1.15.1, B1) : le bouton aurait cessé de marcher.
if (calulis_est_heberge()) {
    jsonError('Interdit sur un déploiement hébergé', 403);
}

try {
    $pdo = getDB();

    // Lire le fichier uploadé ou le body JSON
    if (!empty($_FILES['csv']['tmp_name'])) {
        $filename = $_FILES['csv']['tmp_name'];
    } elseif (!empty($_FILES['file']['tmp_name'])) {
        $filename = $_FILES['file']['tmp_name'];
    } else {
        $input = json_decode(file_get_contents('php://input'), true);
        if (!empty($input['csv_content'])) {
            $lines = explode("\n", $input['csv_content']);
            $rows = [];
            if (count($lines) < 2) jsonError('CSV vide ou invalide');
            $headers = str_getcsv(trim($lines[0]));
            for ($i = 1; $i < count($lines); $i++) {
                $vals = str_getcsv(trim($lines[$i]));
                if (count($vals) === count($headers)) {
                    $rows[] = array_combine($headers, $vals);
                }
            }
        } else {
            jsonError('Fichier CSV requis');
        }
    }

    if (!empty($filename)) {
        $handle = fopen($filename, 'r');
        if (!$handle) jsonError('Impossible de lire le fichier');
        $headers = fgetcsv($handle);
        $rows = [];
        while (($vals = fgetcsv($handle)) !== false) {
            if (count($vals) === count($headers)) {
                $rows[] = array_combine($headers, $vals);
            }
        }
        fclose($handle);
    }

    if (empty($rows)) jsonError('Aucune ligne à importer');

    // Traitement
    $result = [
        'total' => count($rows),
        'imported' => 0,
        'matched' => 0,
        'errors' => [],
        'details' => [],
    ];

    $stmtFind = $pdo->prepare('SELECT id, nom, prenom FROM eleves WHERE ine = :ine LIMIT 1');
    $stmtFindByName = $pdo->prepare(
        'SELECT id, nom, prenom FROM eleves WHERE nom = :nom AND prenom = :prenom AND date_naissance = :dn LIMIT 1'
    );
    $stmtUpdateIne = $pdo->prepare('UPDATE eleves SET ine = :ine WHERE id = :id');
    $stmtInsertRep = $pdo->prepare(
        'INSERT INTO representants (eleve_id, nom, prenom, lien, telephone, telephone2, email, ordre)
         VALUES (:eleve_id, :nom, :prenom, :lien, :tel, :tel2, :email, :ordre)'
    );

    foreach ($rows as $idx => $row) {
        $eleveId = null;

        // 1. Matching par INE
        if (!empty($row['ine'])) {
            $stmtFind->execute(['ine' => trim($row['ine'])]);
            $eleve = $stmtFind->fetch();
            if ($eleve) $eleveId = (int)$eleve['id'];
        }

        // 2. Matching par nom + prénom + date_naissance
        if (!$eleveId && !empty($row['nom']) && !empty($row['prenom']) && !empty($row['date_naissance'])) {
            $stmtFindByName->execute([
                'nom' => trim($row['nom']),
                'prenom' => trim($row['prenom']),
                'dn' => $row['date_naissance'],
            ]);
            $eleve = $stmtFindByName->fetch();
            if ($eleve) $eleveId = (int)$eleve['id'];
        }

        if (!$eleveId) {
            $result['errors'][] = "Ligne $idx : aucun élève trouvé pour " . ($row['nom'] ?? '?') . ' ' . ($row['prenom'] ?? '');
            continue;
        }

        // 3. Mettre à jour INE si pas déjà présent
        if (!empty($row['ine'])) {
            $stmtUpdateIne->execute(['ine' => trim($row['ine']), 'id' => $eleveId]);
        }

        $result['matched']++;

        // 4. Insérer/synchroniser représentants
        for ($r = 1; $r <= 2; $r++) {
            $repNom = trim($row["responsable{$r}_nom"] ?? '');
            $repPrenom = trim($row["responsable{$r}_prenom"] ?? '');
            if (empty($repNom) || empty($repPrenom)) continue;

            // Vérifier si déjà existant
            $check = $pdo->prepare(
                'SELECT id FROM representants WHERE eleve_id = ? AND nom = ? AND prenom = ? LIMIT 1'
            );
            $check->execute([$eleveId, $repNom, $repPrenom]);
            if ($check->fetch()) continue; // déjà existant, ne pas écraser

            $stmtInsertRep->execute([
                'eleve_id' => $eleveId,
                'nom' => $repNom,
                'prenom' => $repPrenom,
                'lien' => $row["responsable{$r}_lien"] ?? '',
                'tel' => $row["responsable{$r}_tel"] ?? '',
                'tel2' => $row["responsable{$r}_tel2"] ?? '',
                'email' => $row["responsable{$r}_email"] ?? '',
                'ordre' => $r - 1,
            ]);
        }

        $result['imported']++;
        $result['details'][] = [
            'eleve_id' => $eleveId,
            'nom' => ($eleve['nom'] ?? $row['nom']) . ' ' . ($eleve['prenom'] ?? $row['prenom']),
            'ine' => $row['ine'] ?? '',
            'statut' => 'ok',
        ];
    }

    jsonResponse([
        'ok' => true,
        'result' => $result,
        'message' => "{$result['imported']}/{$result['total']} élèves importés ({$result['matched']} matchés)",
    ]);

} catch (\Throwable $e) {
    jsonError('Erreur: ' . $e->getMessage(), 500);
}
