<?php
/**
 * Calulis — Controller Types de documents (module Documents, 1.16)
 *
 * Routes :
 *   GET    /api/types_documents.php                    la liste, avec le nombre de documents
 *                                                      qui utilise chaque type
 *   POST   /api/types_documents.php                    créer (libelle, ordre facultatif)
 *   PUT    /api/types_documents.php?id=N               renommer / réordonner / activer-désactiver
 *   DELETE /api/types_documents.php?id=N               supprimer — REFUSÉ si des documents
 *                                                      l'utilisent, avec le compte et la porte
 *                                                      de sortie dans le message
 *   POST   /api/types_documents.php?id=N&reaffecter=K  réaffecter ses documents au type de clé K,
 *                                                      PUIS supprimer le type
 *
 * LA CLÉ NE SE MODIFIE JAMAIS (voir TypeDocument) : un document l'enregistre, et la changer
 * orphelinerait les documents classés. Renommer change le libellé, donc l'affichage partout.
 *
 * DÉCISIONS DE JÉRÔME (08/10/2026) : une suppression est REFUSÉE tant que des documents
 * utilisent le type, en expliquant combien et en proposant de les réaffecter ; et rien n'est
 * « protégé » — les 16 types amorcés par la migration 010 sont un point de départ.
 */
require_once __DIR__ . '/../models/TypeDocument.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$reaffecterVers = isset($_GET['reaffecter']) ? trim((string)$_GET['reaffecter']) : '';

/** Corps de requête : JSON (le frontend n'envoie que du JSON ici). */
function types_documents_entree(): array
{
    $json = json_decode((string)file_get_contents('php://input'), true);
    return is_array($json) ? $json : [];
}

/** Un type enrichi de son nombre d'utilisations — ce que l'écran d'édition doit dire. */
function types_documents_avec_compteur(array $type): array
{
    $type['nb_documents'] = TypeDocument::compterDocuments((string)$type['cle']);
    return $type;
}

try {
    switch ($method) {

        case 'GET':
            $types = array_map('types_documents_avec_compteur', TypeDocument::tous(false));
            jsonResponse($types);
            break;

        case 'POST':
            // ── Réaffecter puis supprimer : la porte de sortie d'une suppression refusée ──
            if ($id > 0 && $reaffecterVers !== '') {
                $type = TypeDocument::find($id);
                if (!$type) {
                    jsonError('Type de document non trouvé', 404);
                }
                if (TypeDocument::parCle($reaffecterVers) === null) {
                    throw new InvalidArgumentException('Le type de destination est inconnu.');
                }
                if ($reaffecterVers === (string)$type['cle']) {
                    throw new InvalidArgumentException('Choisissez un autre type que celui que vous supprimez.');
                }
                // Transaction : si la suppression échoue après la réaffectation, on ne veut
                // pas avoir déplacé des documents pour rien en annonçant un refus.
                $pdo = getDB();
                $pdo->beginTransaction();
                try {
                    $deplaces = TypeDocument::reaffecter((string)$type['cle'], $reaffecterVers);
                    TypeDocument::supprimer($id);
                    $pdo->commit();
                } catch (\Throwable $e) {
                    $pdo->rollBack();
                    throw $e;
                }
                jsonResponse([
                    'ok' => true,
                    'documents_reaffectes' => $deplaces,
                    'vers' => $reaffecterVers,
                ]);
            }

            $entree = types_documents_entree();
            $libelle = trim((string)($entree['libelle'] ?? ''));
            $ordre = isset($entree['ordre']) && $entree['ordre'] !== '' ? (int)$entree['ordre'] : null;
            $nouvelId = TypeDocument::creer($libelle, $ordre);
            $type = TypeDocument::find($nouvelId);
            jsonResponse(['ok' => true, 'id' => $nouvelId, 'type' => $type], 201);
            break;

        case 'PUT':
            if ($id <= 0) {
                jsonError('Identifiant du type manquant', 400);
            }
            $entree = types_documents_entree();
            if (!TypeDocument::modifier($id, $entree)) {
                jsonError('Type de document non trouvé', 404);
            }
            jsonResponse(['ok' => true, 'id' => $id, 'type' => TypeDocument::find($id)]);
            break;

        case 'DELETE':
            if ($id <= 0) {
                jsonError('Identifiant du type manquant', 400);
            }
            $type = TypeDocument::find($id);
            if (!$type) {
                jsonError('Type de document non trouvé', 404);
            }

            // SUPPRESSION REFUSÉE s'il est utilisé : on dit combien, et comment s'en sortir.
            // Rien n'est jamais supprimé « quand même » — les documents qui portent ce type
            // deviendraient illisibles (leur clé n'aurait plus de libellé).
            $utilise = TypeDocument::compterDocuments((string)$type['cle']);
            if ($utilise > 0) {
                jsonError(
                    sprintf(
                        'Ce type est utilisé par %d document%s : réaffectez-%s à un autre type, '
                        . 'ou désactivez-le (il ne sera plus proposé, mais les documents déjà '
                        . 'classés resteront lisibles).',
                        $utilise,
                        $utilise > 1 ? 's' : '',
                        $utilise > 1 ? 'les' : 'le'
                    ),
                    409
                );
            }

            TypeDocument::supprimer($id);
            jsonResponse([
                'ok' => true,
                'id' => $id,
                'libelle' => (string)$type['libelle'],
                'types_restants' => count(TypeDocument::tous(false)),
            ]);
            break;

        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (InvalidArgumentException $e) {
    jsonError($e->getMessage(), 400);
} catch (RuntimeException $e) {
    jsonError($e->getMessage(), 409);
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
