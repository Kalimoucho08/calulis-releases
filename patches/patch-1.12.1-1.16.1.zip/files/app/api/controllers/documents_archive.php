<?php
/**
 * Calulis — Archive des documents d'un élève (module Documents, version 1.16)
 *
 * Route :
 *   GET /api/documents_archive.php?eleve_id=N   → un ZIP des documents de l'élève
 *
 * POURQUOI CETTE ROUTE EXISTE
 * Supprimer un élève efface ses documents (droit à l'effacement, promis par la page
 * « Mentions RGPD »). Mais un dossier peut être redemandé des années plus tard — un
 * élève parti au collège dont on recherche les bilans. L'application propose donc de
 * l'emporter AVANT : cette route fabrique l'archive, le navigateur la télécharge, et
 * l'écran ne supprime qu'ensuite.
 *
 * CE QU'ELLE NE FAIT PAS
 * Elle ne supprime rien : supprimer est une autre route (`DELETE eleves.php`), et
 * c'est le client qui décide, après avoir reçu les octets.
 *
 * POURQUOI ELLE EST LENTE, ET POURQUOI LE CLIENT DOIT ATTENDRE
 * L'archive est fabriquée en entier côté serveur (les octets sont tous en mémoire
 * temporaire) avant que le premier octet ne parte : si un fichier manque, c'est une
 * ERREUR JSON, pas un ZIP tronqué que l'utilisateur croirait complet.
 */
require_once __DIR__ . '/../models/Eleve.php';
require_once __DIR__ . '/../models/DossierDocuments.php';

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'GET') {
    jsonError('Méthode non supportée', 405);
}

$eleveId = isset($_GET['eleve_id']) ? (int)$_GET['eleve_id'] : 0;
if ($eleveId <= 0) {
    jsonError("Identifiant de l'élève manquant.", 400);
}

$eleve = Eleve::find($eleveId);
if (!$eleve) {
    jsonError('Élève non trouvé', 404);
}

try {
    $archive = DossierDocuments::archive($eleveId, $eleve);
} catch (RuntimeException $e) {
    // Deux causes possibles, toutes deux refusées plutôt que livrées en silence :
    // un fichier annoncé en base qui n'a pas pu être lu (l'archive serait amputée, et
    // personne ne le verrait avant de supprimer), ou un dossier qui dépasse les bornes
    // du format ZIP sans ZIP64 (l'archive s'ouvrirait de travers dans Windows).
    // Le message de l'exception est écrit pour l'utilisateur : il ne porte aucun chemin.
    calulis_log_error('[documents] archive : ' . $e->getMessage());
    jsonError($e->getMessage() . ' Rien n\'a été supprimé.', 500);
}

if ($archive === null) {
    jsonError("Cet élève n'a aucun document : il n'y a rien à archiver.", 404);
}

$nom = DossierDocuments::nomArchive($eleve);
header('Content-Type: application/zip');
header('Content-Length: ' . (string)$archive->taille());
header("Content-Disposition: attachment; filename*=UTF-8''" . rawurlencode($nom));
// Une archive n'est pas du code : nosniff empêche le navigateur d'en deviner un autre type.
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
$archive->envoyer();
exit;
