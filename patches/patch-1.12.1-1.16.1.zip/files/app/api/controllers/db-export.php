<?php
/**
 * Calulis — Export de la base de données (sauvegarde téléchargée par l'utilisateur)
 * GET /db-export.php → fichier .sql téléchargé
 *
 * Une seule implémentation du dump dans tout le projet : app/api/models/Sauvegarde.php
 * (partagée avec les sauvegardes automatiques faites avant un remplacement de base).
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Sauvegarde.php';

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    jsonError('Méthode non supportée', 405);
}

// Restreindre l'accès : localhost uniquement ou token en query param
$allowedToken = getenv('CALULIS_EXPORT_TOKEN') ?: null;
$isLocalhost = in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1', 'localhost'], true);
$hasToken = $allowedToken && isset($_GET['token']) && $_GET['token'] === $allowedToken;
if (!$isLocalhost && !$hasToken) {
    jsonError('Accès non autorisé', 403);
}

$pdo = getDB();
$date = date('Y-m-d_His');
header('Content-Type: application/sql; charset=utf-8');
header('Content-Disposition: attachment; filename="calulis-backup-' . $date . '.sql"');

$flux = fopen('php://output', 'wb');
try {
    Sauvegarde::ecrireFlux($pdo, $flux);
    fwrite($flux, "-- FIN DE LA SAUVEGARDE\n");
} catch (\Throwable $e) {
    // Les en-têtes sont déjà partis : on ne peut plus changer le code HTTP.
    // On inscrit la panne DANS le fichier, pour qu'un fichier tronqué ne passe
    // pas pour une sauvegarde complète.
    calulis_log_error('EXPORT INTERROMPU : ' . $e->getMessage());
    fwrite($flux, "-- ÉCHEC DE LA SAUVEGARDE : " . str_replace("\n", ' ', $e->getMessage()) . "\n");
    fwrite($flux, "-- CE FICHIER EST INCOMPLET — NE PAS L'UTILISER POUR RESTAURER.\n");
}
fclose($flux);
exit;
