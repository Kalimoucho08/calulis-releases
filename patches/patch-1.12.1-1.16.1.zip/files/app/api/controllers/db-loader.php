<?php
/**
 * Calulis — Chargement d'une base de démonstration ou d'une base vierge.
 *
 * GET  /db-loader.php   → liste les bases proposées
 * POST /db-loader.php   → REMPLACE la base courante (body: { snapshot: "v6" })
 *
 * SÉCURITÉ (AUDIT-1.15.1.md, B3)
 * Trois défauts corrigés le 05/10/2026 :
 *   1. l'opération remplaçait la base SANS sauvegarde → sauvegarde obligatoire
 *      d'abord ; si elle échoue, rien n'est remplacé ;
 *   2. elle passait par `exec('mysql … -S /var/run/mysqld/mysqld.sock …')` — un
 *      chemin de socket LINUX codé en dur, inopérant sur le poste Windows de
 *      l'utilisateur (le repli PHP lent faisait tout le travail) → import via
 *      le modèle partagé ImportSql, sans commande externe ;
 *   3. elle RÉÉCRIVAIT `runtime/config.json` avec un schéma à elle
 *      (`dbType`, `dbInitDone`), effaçant la liste `Bases` du lanceur → plus
 *      aucune écriture de ce fichier par l'application (il appartient au lanceur).
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Sauvegarde.php';
require_once __DIR__ . '/../models/ImportSql.php';

$method = $_SERVER['REQUEST_METHOD'];

try {
    $snapshotFiles = [
        'v6' => [
            'id' => 'v6',
            'label' => 'Base démo V6',
            'description' => '12 élèves, 15 adultes, 11 établissements, 3 années (2024→2027), ~12500 créneaux. Horaires 08:30-16:30, pauses 10h+15h.',
            'size' => '~2.1 Mo',
            'path' => __DIR__ . '/../../data/calulis-demo-v6.sql',
        ],
        'empty' => [
            'id' => 'empty',
            'label' => 'Base vierge (structure uniquement)',
            'description' => 'Aucune donnée — uniquement les tables vides. Pour démarrer une nouvelle base de zéro.',
            'size' => '~15 Ko',
            'path' => __DIR__ . '/../../data/calulis-vierge.sql',
        ],
    ];

    if ($method === 'GET') {
        // Ce qui existe RÉELLEMENT dans la base courante (et non ce que le
        // lanceur a pu écrire autrefois dans config.json).
        $comptes = [];
        try {
            $comptes = calulis_compter_base(getDB());
        } catch (\Throwable $e) {
            $comptes = [];
        }
        $list = array_values(array_map(function ($s) { unset($s['path']); return $s; }, $snapshotFiles));
        jsonResponse(['bases' => $list, 'actuelle' => $comptes]);
    }

    if ($method === 'POST') {
        if (calulis_est_heberge()) {
            jsonError('Chargement d\'une base de démonstration désactivé sur un déploiement hébergé', 403);
        }

        $input = json_decode(file_get_contents('php://input'), true);
        $id = is_array($input) ? ($input['snapshot'] ?? 'v6') : 'v6';

        if (!isset($snapshotFiles[$id])) {
            jsonError('Base inconnue : ' . $id, 400);
        }

        // Base vierge : le fichier peut manquer, on le régénère depuis la base live.
        if ($id === 'empty' && !file_exists($snapshotFiles['empty']['path'])) {
            $pdo = getDB();
            $flux = @fopen($snapshotFiles['empty']['path'], 'wb');
            if (!$flux) {
                jsonError('Impossible de préparer la base vierge (écriture refusée dans app/data).', 500);
            }
            try {
                // Structure seule : le dump est écrit puis les INSERT retirés.
                Sauvegarde::ecrireFlux($pdo, $flux);
            } finally {
                fclose($flux);
            }
            // Retirer les DONNÉES en gardant la structure. Le découpage partagé
            // est utilisé (et non une expression ligne à ligne) : un INSERT dont
            // une valeur contient un vrai saut de ligne s'étale sur plusieurs
            // lignes, et seul le découpage en instructions sait le retirer entier.
            $contenu = (string) file_get_contents($snapshotFiles['empty']['path']);
            $structure = [];
            foreach (ImportSql::decouper($contenu) as $instruction) {
                if (preg_match('/^\s*INSERT\s+INTO/i', $instruction)) { continue; }
                if (trim($instruction) !== '') { $structure[] = trim($instruction) . ";\n"; }
            }
            file_put_contents($snapshotFiles['empty']['path'], implode("\n", $structure));
        }

        $fichier = $snapshotFiles[$id]['path'];
        if (!file_exists($fichier)) {
            jsonError('Fichier SQL introuvable : ' . $fichier, 500);
        }

        $sql = (string) file_get_contents($fichier);
        $pdo = getDB();

        // Le fichier livré vise `calulis`, la base courante : accepté.
        ImportSql::verifier($pdo, $sql);

        $avant = calulis_compter_base($pdo);

        // Sauvegarde obligatoire AVANT remplacement.
        try {
            $sauvegarde = Sauvegarde::ecrireFichier($pdo, 'avant-chargement-base');
        } catch (\Throwable $e) {
            calulis_log_error('SAUVEGARDE PRÉALABLE ÉCHOUÉE (chargement annulé) : ' . $e->getMessage());
            jsonError(
                "Changement de base annulé : la sauvegarde de vos données actuelles a échoué ("
                . $e->getMessage() . "). AUCUNE donnée n'a été modifiée.",
                500
            );
        }

        $resultat = ImportSql::executer($pdo, $sql);

        if (count($resultat['erreurs']) > 0) {
            calulis_log_error('CHARGEMENT PARTIEL : ' . implode(' | ', array_slice($resultat['erreurs'], 0, 5)));
            jsonError(
                $resultat['instructions'] . ' instruction(s) exécutée(s), '
                . count($resultat['erreurs']) . ' erreur(s). '
                . 'Vos données d\'avant sont conservées dans : ' . $sauvegarde['chemin'] . '. '
                . 'Détail : ' . implode(' | ', array_slice($resultat['erreurs'], 0, 3)),
                500
            );
        }

        // Migrations en attente : certaines tables (classe_enseignants, groupes,
        // eleve_groupes) sont créées par migration et absentes des dumps.
        try {
            require_once __DIR__ . '/../models/Migration.php';
            (new Migration())->run();
        } catch (\Throwable $me) {
            calulis_log_error('migration après chargement : ' . $me->getMessage());
        }

        $apres = calulis_compter_base($pdo);

        jsonResponse([
            'ok' => true,
            'base' => $id,
            'label' => $snapshotFiles[$id]['label'],
            'instructions' => $resultat['instructions'],
            'avant' => $avant,
            'apres' => $apres,
            'sauvegarde' => $sauvegarde['chemin'],
            'message' => $snapshotFiles[$id]['label'] . ' chargée. '
                . 'Avant : ' . calulis_resume_comptes($avant) . '. '
                . 'Maintenant : ' . calulis_resume_comptes($apres) . '.',
        ]);
    }

    jsonError('Méthode non supportée', 405);
} catch (\RuntimeException $e) {
    jsonError($e->getMessage(), 400);
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
