<?php
/**
 * Calulis — Controller Documents (module Documents, version 1.16)
 *
 * Routes :
 *   GET    /api/documents.php                        liste filtrable
 *   GET    /api/documents.php?referentiel=1          types proposés
 *   GET    /api/documents.php?id=N                   un document
 *   GET    /api/documents.php?id=N&fichier=1         le fichier rapatrié (octets)
 *   POST   /api/documents.php                        création (multipart « fichier », ou JSON)
 *   POST   /api/documents.php?id=N&fichier=1         remplacement du fichier
 *   PUT    /api/documents.php?id=N                   modification des métadonnées
 *   DELETE /api/documents.php?id=N                   suppression (document ET fichier)
 *
 * LE FICHIER N'EST JAMAIS SERVI PAR LE SERVEUR WEB : il vit sous
 * `runtime/documents/` (hors de la racine web `app/`), et c'est cette route qui le
 * rend, après contrôle. Aucune URL devinée ne donne accès à un document.
 */
require_once __DIR__ . '/../models/Document.php';
require_once __DIR__ . '/../models/Fichier.php';
require_once __DIR__ . '/../models/Stockage.php';
require_once __DIR__ . '/../models/TypeDocument.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$veutFichier = isset($_GET['fichier']);

/** Métadonnées reçues : formulaire multipart, ou corps JSON. */
function documents_entree(): array
{
    if ($_POST !== []) {
        return $_POST;
    }
    $json = json_decode((string)file_get_contents('php://input'), true);
    return is_array($json) ? $json : [];
}

/** Garde uniquement les champs que le modèle Document sait écrire. */
function documents_champs(array $entree): array
{
    $connus = ['nom', 'type', 'eleve_id', 'reunion_id', 'date_document', 'version',
        'statut', 'reference_externe', 'notes', 'annee_scolaire_id'];
    $donnees = array_intersect_key($entree, array_flip($connus));

    if (isset($donnees['type']) && TypeDocument::parCle((string)$donnees['type']) === null) {
        // Clé inconnue (type supprimé, renommé, ou saisie à la main) : on retombe sur le
        // premier type actif plutôt que d'écrire une clé que plus personne ne saura afficher.
        $donnees['type'] = TypeDocument::cleParDefaut();
    }
    foreach (['date_document', 'reference_externe', 'version', 'statut'] as $vide) {
        if (isset($donnees[$vide]) && trim((string)$donnees[$vide]) === '') {
            $donnees[$vide] = null;
        }
    }
    return $donnees;
}

/** Y a-t-il un fichier réellement joint à la requête ? */
function documents_aUnFichier(): bool
{
    return isset($_FILES['fichier'])
        && is_array($_FILES['fichier'])
        && (int)($_FILES['fichier']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_NO_FILE;
}

/**
 * Envoie le fichier rapatrié au navigateur (aperçu ou téléchargement).
 * Ne revient jamais : termine la réponse.
 */
function documents_servirFichier(array $doc): void
{
    $chemin = (string)($doc['fichier_chemin'] ?? '');
    if ($chemin === '') {
        jsonError('Ce document n\'a pas de fichier : il n\'est que décrit.', 404);
    }
    $absolu = Stockage::cheminAbsolu($chemin);
    if ($absolu === null || !is_file($absolu)) {
        jsonError('Le fichier de ce document est introuvable sur le disque. Il a peut-être été déplacé ou supprimé.', 404);
    }

    $extension = Stockage::extension((string)($doc['fichier_stocke'] ?? $absolu));
    $mime = Stockage::typeMime($extension) ?: 'application/octet-stream';
    $nom = (string)($doc['fichier_nom'] ?? '') ?: basename($absolu);

    header('Content-Type: ' . $mime);
    header('Content-Length: ' . (string)filesize($absolu));
    header("Content-Disposition: inline; filename*=UTF-8''" . rawurlencode($nom));
    // Un document n'est pas du code : nosniff empêche le navigateur d'en deviner un autre type.
    header('X-Content-Type-Options: nosniff');
    header('Cache-Control: private, no-store');
    readfile($absolu);
    exit;
}

try {
    switch ($method) {

        case 'GET':
            if ($id > 0) {
                $doc = Document::find($id);
                if (!$doc) {
                    jsonError('Document non trouvé', 404);
                }
                if ($veutFichier) {
                    documents_servirFichier($doc);
                }
                jsonResponse($doc);
            }

            if (isset($_GET['referentiel'])) {
                jsonResponse([
                    'types'      => TypeDocument::referentiel(),
                    // Les types désactivés ne sont plus PROPOSÉS, mais ils restent LISIBLES :
                    // un document classé avec eux doit continuer d'afficher son libellé.
                    'types_tous' => TypeDocument::referentiel(false),
                    'extensions' => array_keys(Stockage::TYPES),
                    'taille_max' => Stockage::TAILLE_MAX,
                ]);
            }

            jsonResponse(Document::liste([
                'eleve_id'          => $_GET['eleve_id'] ?? null,
                'annee_scolaire_id' => $_GET['annee_scolaire_id'] ?? null,
                'type'              => $_GET['type'] ?? null,
                'q'                 => $_GET['q'] ?? null,
                'fichier'           => $_GET['etat_fichier'] ?? null,
            ]));
            break;

        case 'POST':
            // ── Remplacement du fichier d'un document existant ────────────────
            if ($id > 0 && $veutFichier) {
                $doc = Document::find($id);
                if (!$doc) {
                    jsonError('Document non trouvé', 404);
                }
                if (!documents_aUnFichier()) {
                    throw new InvalidArgumentException('Aucun fichier reçu. Choisissez un document et recommencez.');
                }

                $valide = Stockage::valider($_FILES['fichier']);
                $entree = documents_entree();
                $eleveId = isset($doc['eleve_id']) && $doc['eleve_id'] !== null ? (int)$doc['eleve_id'] : null;

                $pdo = getDB();
                $pdo->beginTransaction();
                $ecrit = null;
                try {
                    $ecrit = Stockage::enregistrer($valide, $eleveId, $id);
                    Fichier::create([
                        'entite_type'  => 'document',
                        'entite_id'    => $id,
                        'nom_original' => $ecrit['nom_original'],
                        'nom_stocke'   => $ecrit['nom_stocke'],
                        'chemin'       => $ecrit['chemin'],
                        'taille'       => $ecrit['taille'],
                        'type_mime'    => $ecrit['type_mime'],
                    ]);
                    $pdo->commit();
                } catch (\Throwable $e) {
                    $pdo->rollBack();
                    if ($ecrit !== null) {
                        Stockage::supprimer($ecrit['chemin']);
                    }
                    throw $e;
                }

                // L'ancien fichier n'est retiré qu'une fois le nouveau en place. S'il
                // résiste (fichier verrouillé sous Windows, droits), on le DIT dans le
                // journal : sinon il resterait sur le disque sans aucune ligne pour le
                // réclamer, donc invisible.
                foreach (Fichier::tousPourEntite('document', $id) as $ancien) {
                    if ((string)$ancien['chemin'] === (string)$ecrit['chemin']) {
                        continue;
                    }
                    if (!Stockage::supprimer((string)$ancien['chemin'])) {
                        // On NE SUPPRIME PAS sa ligne : le fichier resterait sur le disque
                        // sans personne pour le réclamer, donc invisible et jamais nettoyé.
                        // Et on journalise l'id du fichier, jamais son chemin (qui porte le
                        // numéro de l'élève et le nom du dossier d'installation).
                        calulis_log_error('[documents] ancien fichier non supprimé (fichier ' . (int)$ancien['id'] . ')');
                    } else {
                        Fichier::delete((int)$ancien['id']);
                    }
                }

                jsonResponse(['ok' => true, 'id' => $id, 'fichier' => $ecrit], 201);
            }

            // ── Création ──────────────────────────────────────────────────────
            $entree = documents_entree();
            $donnees = documents_champs($entree);
            $eleveId = isset($donnees['eleve_id']) && $donnees['eleve_id'] !== '' ? (int)$donnees['eleve_id'] : null;
            $donnees['eleve_id'] = $eleveId;

            $valide = null;
            if (documents_aUnFichier()) {
                $valide = Stockage::valider($_FILES['fichier']);
                if (trim((string)($donnees['nom'] ?? '')) === '') {
                    $donnees['nom'] = pathinfo($valide['nom_original'], PATHINFO_FILENAME);
                }
            }
            if (trim((string)($donnees['nom'] ?? '')) === '') {
                throw new InvalidArgumentException('Donnez un nom au document.');
            }
            $donnees['nom'] = Stockage::tronquer(trim((string)$donnees['nom']), 300);
            if (!isset($donnees['type'])) {
                $donnees['type'] = 'autre';
            }
            if (!isset($donnees['statut']) || $donnees['statut'] === null) {
                $donnees['statut'] = $valide !== null ? 'recu' : 'en_attente';
            }

            $pdo = getDB();
            $pdo->beginTransaction();
            $ecrit = null;
            try {
                $docId = Document::create($donnees);
                if ($valide !== null) {
                    $ecrit = Stockage::enregistrer($valide, $eleveId, $docId);
                    Fichier::create([
                        'entite_type'  => 'document',
                        'entite_id'    => $docId,
                        'nom_original' => $ecrit['nom_original'],
                        'nom_stocke'   => $ecrit['nom_stocke'],
                        'chemin'       => $ecrit['chemin'],
                        'taille'       => $ecrit['taille'],
                        'type_mime'    => $ecrit['type_mime'],
                    ]);
                }
                $pdo->commit();
            } catch (\Throwable $e) {
                $pdo->rollBack();
                if ($ecrit !== null) {
                    Stockage::supprimer($ecrit['chemin']);
                }
                throw $e;
            }

            jsonResponse(['ok' => true, 'id' => $docId, 'fichier' => $ecrit], 201);
            break;

        case 'PUT':
            if ($id <= 0) {
                jsonError('Identifiant du document manquant', 400);
            }
            $doc = Document::find($id);
            if (!$doc) {
                jsonError('Document non trouvé', 404);
            }

            $entree = documents_entree();
            $donnees = documents_champs($entree);
            // L'ANNÉE NE SE MODIFIE PAS À L'ÉDITION. `API.put` (app/js/api.js) ajoute
            // l'année active à tout corps qui ne la porte pas : sans ce retrait, éditer un
            // document de 2024 le reclassait dans l'année en cours, en silence — et comme
            // la page montre toutes les années, il disparaissait de la sienne. Défaut
            // trouvé par la relecture indépendante du 08/10/2026.
            unset($donnees['annee_scolaire_id']);
            if (trim((string)($donnees['nom'] ?? '')) === '') {
                throw new InvalidArgumentException('Le nom du document est obligatoire.');
            }
            $donnees['nom'] = Stockage::tronquer(trim((string)$donnees['nom']), 300);

            // Une seule table est écrite : pas de transaction à ouvrir (elle l'était quand
            // la catégorie du fichier se modifiait ici aussi — catégorie RETIRÉE le
            // 08/10/2026 à la demande de Jérôme : elle doublait le type de document et
            // mêlait deux axes (« pédagogique » = à quoi ça sert, « photo » = avec quoi
            // c'est fait), ce qui rendait impossible un travail d'élève photographié).
            if (!Document::update($id, $donnees)) {
                jsonError('Document non trouvé', 404);
            }

            jsonResponse(['ok' => true, 'id' => $id, 'document' => Document::find($id)]);
            break;

        case 'DELETE':
            if ($id <= 0) {
                jsonError('Identifiant du document manquant', 400);
            }
            $doc = Document::find($id);
            if (!$doc) {
                jsonError('Document non trouvé', 404);
            }

            $fichiers = Fichier::tousPourEntite('document', $id);
            $octets = 0;
            foreach ($fichiers as $f) {
                $octets += (int)($f['taille'] ?? 0);
            }

            $pdo = getDB();
            $pdo->beginTransaction();
            try {
                Fichier::deletePourEntite('document', $id);
                Document::delete($id);
                $pdo->commit();
            } catch (\Throwable $e) {
                $pdo->rollBack();
                throw $e;
            }

            // Les fichiers partent APRÈS l'enregistrement : si le disque refuse, la
            // ligne n'est plus là et le journal garde la trace de ce qui reste.
            $restants = 0;
            foreach ($fichiers as $f) {
                if (!Stockage::supprimer((string)$f['chemin'])) {
                    $restants++;
                    calulis_log_error('[documents] fichier non supprimé (fichier ' . (int)$f['id'] . ')');
                }
            }

            jsonResponse([
                'ok'                => true,
                'fichiers'          => count($fichiers),
                'octets'            => $octets,
                'fichiers_restants' => $restants,
            ]);
            break;

        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (InvalidArgumentException $e) {
    jsonError($e->getMessage(), 400);
} catch (\PDOException $e) {
    // AVANT RuntimeException : PDOException en hérite, et sans ce cas une erreur SQL
    // (clé étrangère, colonne inconnue) serait annoncée comme un « disque plein ».
    // Défaut introduit puis attrapé par tests/verif-documents.sh le 08/10/2026.
    calulis_handle_error($e);
} catch (RuntimeException $e) {
    // Écriture disque impossible (dossier refusé, disque plein, fichier verrouillé) :
    // message compréhensible pour l'utilisateur, chemin complet dans le journal.
    calulis_log_error('[documents] ' . $e->getMessage());
    jsonError("Le fichier n'a pas pu être enregistré sur le disque. Vérifiez qu'il reste de la place, puis réessayez.", 500);
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
