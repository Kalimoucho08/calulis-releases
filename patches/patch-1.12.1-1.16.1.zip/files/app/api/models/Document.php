<?php
/** Calulis — Model Document (multi-année) */
require_once __DIR__ . '/../config.php';

class Document {
    /**
     * Colonnes communes à toutes les lectures : le document, le nom de l'élève, et
     * le fichier rapatrié s'il y en a un (table `fichiers`, module Documents 1.16).
     *
     * La sous-requête `MAX(f2.id)` garantit AU PLUS une ligne de fichier par
     * document : un LEFT JOIN direct dupliquerait la ligne si un document portait
     * deux fichiers.
     */
    private const CHAMPS = 'SELECT d.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom,
                f.id AS fichier_id, f.nom_original AS fichier_nom,
                f.nom_stocke AS fichier_stocke, f.chemin AS fichier_chemin,
                f.taille AS fichier_taille, f.type_mime AS fichier_mime,
                f.created_at AS fichier_ajoute_le
            FROM documents d
            LEFT JOIN eleves e ON d.eleve_id = e.id
            LEFT JOIN fichiers f ON f.id = (
                SELECT MAX(f2.id) FROM fichiers f2
                WHERE f2.entite_type = \'document\' AND f2.entite_id = d.id
            )';

    /** Liste tous les documents (filtrés par année si fournie) */
    public static function all(?int $anneeId = null): array {
        $pdo = getDB();
        $sql = self::CHAMPS;
        $params = [];
        if ($anneeId !== null) {
            $sql .= ' WHERE d.annee_scolaire_id = :annee_id';
            $params['annee_id'] = $anneeId;
        }
        $sql .= ' ORDER BY d.date_document DESC, d.nom';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /**
     * Liste filtrable du module Documents.
     *
     * Filtres acceptés : `eleve_id`, `annee_scolaire_id`, `type`,
     * `q` (recherche sur le nom, les notes et le nom du fichier d'origine),
     * `fichier` = 'avec' | 'sans' (documents rapatriés ou seulement décrits).
     */
    public static function liste(array $filtres = []): array {
        $pdo = getDB();
        $sql = self::CHAMPS;
        $where = [];
        $params = [];

        if (!empty($filtres['eleve_id'])) {
            $where[] = 'd.eleve_id = :eleve_id';
            $params['eleve_id'] = (int)$filtres['eleve_id'];
        }
        if (!empty($filtres['annee_scolaire_id'])) {
            $where[] = 'd.annee_scolaire_id = :annee_id';
            $params['annee_id'] = (int)$filtres['annee_scolaire_id'];
        }
        if (!empty($filtres['type'])) {
            $where[] = 'd.type = :type';
            $params['type'] = (string)$filtres['type'];
        }
        $q = trim((string)($filtres['q'] ?? ''));
        if ($q !== '') {
            // La recherche porte sur le document (nom, notes), sur le NOM DU FICHIER
            // D'ORIGINE, et sur l'ÉLÈVE auquel il est rattaché. Les deux concaténations
            // permettent de taper « Léa Lemoine » ou « Lemoine Léa » d'un seul trait —
            // sans elles, l'élève n'était trouvé que par un seul de ses deux mots.
            // Chaque paramètre est DISTINCT : MySQL en requête préparée native refuse un
            // même paramètre nommé employé plusieurs fois (« Invalid parameter number »),
            // défaut trouvé par tests/verif-documents.sh le 08/10/2026.
            $where[] = '(d.nom LIKE :q1 OR d.notes LIKE :q2 OR f.nom_original LIKE :q3'
                . ' OR e.nom LIKE :q4 OR e.prenom LIKE :q5'
                . " OR CONCAT(e.prenom, ' ', e.nom) LIKE :q6"
                . " OR CONCAT(e.nom, ' ', e.prenom) LIKE :q7)";
            foreach (['q1', 'q2', 'q3', 'q4', 'q5', 'q6', 'q7'] as $marque) {
                $params[$marque] = '%' . $q . '%';
            }
        }
        $etatFichier = (string)($filtres['fichier'] ?? '');
        if ($etatFichier === 'avec') {
            $where[] = 'f.id IS NOT NULL';
        } elseif ($etatFichier === 'sans') {
            $where[] = 'f.id IS NULL';
        }

        if ($where !== []) {
            $sql .= ' WHERE ' . implode(' AND ', $where);
        }
        $sql .= ' ORDER BY d.date_document DESC, d.nom';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Trouve un document par ID */
    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare(self::CHAMPS . ' WHERE d.id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Documents liés à un élève */
    public static function getByEleve(int $eleveId, ?int $anneeId = null): array {
        $pdo = getDB();
        $sql = self::CHAMPS . ' WHERE d.eleve_id = :eleveId';
        $params = ['eleveId' => $eleveId];
        if ($anneeId !== null) {
            $sql .= ' AND d.annee_scolaire_id = :annee_id';
            $params['annee_id'] = $anneeId;
        }
        $sql .= ' ORDER BY d.date_document DESC, d.nom';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Documents liés à une réunion */
    public static function getByReunion(int $reunionId): array {
        $pdo = getDB();
        $stmt = $pdo->prepare(self::CHAMPS . ' WHERE d.reunion_id = :reunionId
             ORDER BY d.date_document DESC, d.nom');
        $stmt->execute(['reunionId' => $reunionId]);
        return $stmt->fetchAll();
    }

    /** Crée un document */
    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO documents (
            nom, type, eleve_id, reunion_id, date_document, version,
            statut, reference_externe, notes, annee_scolaire_id
        ) VALUES (
            :nom, :type, :eleve_id, :reunion_id, :date_document, :version,
            :statut, :reference_externe, :notes, :annee_scolaire_id
        )');
        $stmt->execute(self::_bind($data, false));
        return (int)$pdo->lastInsertId();
    }

    /** Met à jour un document */
    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $existing = self::find($id);
        if (!$existing) return false;
        $data = array_merge($existing, $data);
        $data['id'] = $id;
        $stmt = $pdo->prepare('UPDATE documents SET
            nom=:nom, type=:type, eleve_id=:eleve_id, reunion_id=:reunion_id,
            date_document=:date_document, version=:version,
            statut=:statut, reference_externe=:reference_externe, notes=:notes,
            annee_scolaire_id=:annee_scolaire_id,
            updated_at=CURRENT_TIMESTAMP
        WHERE id=:id');
        return $stmt->execute(self::_bind($data));
    }

    /** Supprime un document */
    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM documents WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    /** Compteur pour le dashboard */
    public static function count(?int $anneeId = null): int {
        $pdo = getDB();
        if ($anneeId !== null) {
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM documents WHERE annee_scolaire_id = :aid');
            $stmt->execute(['aid' => $anneeId]);
            return (int)$stmt->fetchColumn();
        }
        return (int)$pdo->query('SELECT COUNT(*) FROM documents')->fetchColumn();
    }

    /** Lie les champs aux paramètres SQL */
    private static function _bind(array $data, bool $includeId = true): array {
        $strFields = ['nom', 'type', 'date_document', 'version',
            'statut', 'reference_externe', 'notes'];
        $intFields = ['eleve_id', 'reunion_id', 'annee_scolaire_id'];
        if ($includeId) $intFields[] = 'id';
        $params = [];
        foreach ($strFields as $f) {
            $params[$f] = isset($data[$f]) ? trim((string)$data[$f]) : null;
        }
        $intDefaults = ['eleve_id' => null, 'reunion_id' => null, 'annee_scolaire_id' => null, 'id' => 0];
        foreach ($intFields as $f) {
            $params[$f] = isset($data[$f]) && $data[$f] !== '' && $data[$f] !== null
                ? (int)$data[$f]
                : ($intDefaults[$f] ?? null);
        }
        if ($includeId) $params['id'] = isset($data['id']) ? (int)$data['id'] : 0;
        return $params;
    }
}
