<?php
/**
 * Calulis — Exécution d'un fichier .sql dans la base courante.
 *
 * DEUX DÉFAUTS CORRIGÉS ICI (AUDIT-1.15.1.md, B4 et MAJEURS)
 *
 * 1. Le découpage des instructions était `preg_split('/;\s*\n/')` : un
 *    point-virgule suivi d'un saut de ligne À L'INTÉRIEUR d'un texte (une note
 *    de suivi, par exemple) coupait l'instruction en deux et la restauration
 *    écrivait des données tronquées, sans le dire. Le découpage respecte
 *    maintenant les chaînes entre guillemets et les commentaires.
 *
 * 2. Aucun contrôle du contenu : un .sql contenant `DROP DATABASE autre_base`
 *    ou `USE autre_base` était exécuté tel quel. Ces instructions sont
 *    désormais refusées dès qu'elles visent une base AUTRE que la base
 *    courante ; le fichier de « base vierge » du paquet, qui vise `calulis`
 *    (la base courante), reste accepté.
 */
class ImportSql
{
    /**
     * Refuse les instructions qui sortiraient du périmètre de la base courante.
     *
     * @throws RuntimeException (le message est destiné à l'utilisateur)
     */
    public static function verifier(PDO $pdo, string $sql): void
    {
        self::verifierNom((string) $pdo->query('SELECT DATABASE()')->fetchColumn(), $sql);
    }

    /**
     * Même contrôle, sans connexion : c'est cette forme qui est éprouvée par les
     * tests (le nom de la base courante est fourni).
     *
     * @throws RuntimeException
     */
    public static function verifierNom(string $courante, string $sql): void
    {
        $motif = '/\b(DROP\s+DATABASE|CREATE\s+DATABASE|USE)\s+(?:IF\s+(?:NOT\s+)?EXISTS\s+)?`?([A-Za-z0-9_$-]+)`?\s*(?:;|\z)/i';
        if (!preg_match_all($motif, self::sansCommentaires($sql), $trouves, PREG_SET_ORDER)) {
            return;
        }

        foreach ($trouves as $t) {
            $cible = $t[2];
            if ($courante !== '' && strcasecmp($cible, $courante) === 0) {
                continue; // même base : autorisé (cas du fichier « base vierge »)
            }
            throw new RuntimeException(sprintf(
                "Ce fichier demande « %s %s » : il vise une AUTRE base que la base actuelle (%s). "
                . "Import refusé — aucune donnée n'a été touchée.",
                strtoupper(preg_replace('/\s+/', ' ', $t[1])),
                $cible,
                $courante !== '' ? $courante : 'inconnue'
            ));
        }
    }

    /**
     * Exécute un script SQL déjà validé.
     *
     * @return array{instructions:int,erreurs:array<int,string>}
     */
    public static function executer(PDO $pdo, string $sql): array
    {
        $instructions = 0;
        $erreurs = [];

        $pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
        try {
            foreach (self::decouper($sql) as $stmt) {
                if (trim($stmt) === '') { continue; }
                try {
                    $pdo->exec($stmt);
                    $instructions++;
                } catch (\Throwable $e) {
                    // Le journal (et le rapport rendu à l'utilisateur) ne doit JAMAIS
                    // recevoir une valeur d'élève : on ne garde que la forme de
                    // l'instruction et un message MySQL débarrassé de ses citations.
                    // Constat C de la revue RGPD du 08/10/2026.
                    $erreurs[] = self::decrire($stmt) . ' — ' . self::messageSansValeur($e);
                }
            }
        } finally {
            $pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
        }

        return ['instructions' => $instructions, 'erreurs' => $erreurs];
    }

    /**
     * Décrit une instruction SQL SANS son contenu : « INSERT INTO eleves ».
     * Un `INSERT INTO eleves …` fautif envoyait jusqu'ici ses 80 premiers caractères
     * au journal — donc un nom, un prénom et une date de naissance.
     */
    public static function decrire(string $stmt): string
    {
        $tete = preg_replace('/\s+/', ' ', trim(self::sansCommentaires($stmt))) ?? '';
        if (preg_match('/^(INSERT\s+INTO|REPLACE\s+INTO|UPDATE|DELETE\s+FROM|SELECT|CREATE\s+TABLE(?:\s+IF\s+NOT\s+EXISTS)?|ALTER\s+TABLE|DROP\s+TABLE(?:\s+IF\s+EXISTS)?|TRUNCATE\s+TABLE)\s+`?([A-Za-z0-9_]+)`?/i', $tete, $m)) {
            return strtoupper((string)preg_replace('/\s+/', ' ', $m[1])) . ' ' . $m[2];
        }
        return 'instruction SQL';
    }

    /**
     * Message d'une erreur MySQL débarrassé des VALEURS qu'il peut citer
     * (« Duplicate entry 'DUPONT Jean' for key… », « Incorrect string value: '…' »).
     */
    public static function messageSansValeur(\Throwable $e): string
    {
        $msg = (string)$e->getMessage();
        $msg = (string)preg_replace(["/'[^']*'/", '/"[^"]*"/'], ["'…'", '"…"'], $msg);
        return substr($msg, 0, 200);
    }

    /** Retire commentaires de ligne et blocs (pour l'analyse de sûreté). */
    private static function sansCommentaires(string $sql): string
    {
        $sql = preg_replace('/^\s*--.*$/m', '', $sql) ?? $sql;
        return preg_replace('#/\*.*?\*/#s', '', $sql) ?? $sql;
    }

    /**
     * Découpe un script en instructions, en respectant les chaînes ('…', "…"),
     * les identifiants (`…`), l'échappement par antislash et le doublement du
     * guillemet, les commentaires `--` et `/* … *\/`.
     *
     * @return array<int,string>
     */
    public static function decouper(string $sql): array
    {
        $instructions = [];
        $courant = '';
        $longueur = strlen($sql);
        $quote = null;

        for ($i = 0; $i < $longueur; $i++) {
            $c = $sql[$i];

            if ($quote !== null) {
                $courant .= $c;
                if ($c === '\\' && $quote !== '`') {
                    if ($i + 1 < $longueur) { $courant .= $sql[++$i]; }
                    continue;
                }
                if ($c === $quote) {
                    // Guillemet doublé = guillemet littéral ('' ou "" ou ``)
                    if (($sql[$i + 1] ?? '') === $quote) { $courant .= $sql[++$i]; continue; }
                    $quote = null;
                }
                continue;
            }

            if ($c === "'" || $c === '"' || $c === '`') {
                $quote = $c;
                $courant .= $c;
                continue;
            }

            if ($c === '-' && ($sql[$i + 1] ?? '') === '-') {
                while ($i < $longueur && $sql[$i] !== "\n") { $i++; }
                $courant .= "\n";
                continue;
            }

            if ($c === '/' && ($sql[$i + 1] ?? '') === '*') {
                $fin = strpos($sql, '*/', $i + 2);
                $i = $fin === false ? $longueur : $fin + 1;
                continue;
            }

            if ($c === ';') {
                $instructions[] = $courant;
                $courant = '';
                continue;
            }

            $courant .= $c;
        }

        if (trim($courant) !== '') { $instructions[] = $courant; }

        return $instructions;
    }
}
