<?php
/**
 * Calulis — Sauvegarde de la base, côté application.
 *
 * POURQUOI CE FICHIER
 * Charger une base de démonstration, repartir d'une base vierge et restaurer un
 * fichier .sql remplacent TOUTES les données. Jusqu'au 05/10/2026 ces trois
 * opérations n'avaient aucun filet : un fichier abîmé, une coupure, et les
 * données de l'utilisateur étaient perdues (constat B3/B4 de AUDIT-1.15.1.md).
 *
 * OÙ SONT LES SAUVEGARDES
 * `<racine>/runtime/backups/db/<horodatage>/<motif>.sql` — le MÊME dossier que
 * les sauvegardes du lanceur (`pre-update.sql`, écrites par BackupService.cs).
 * Une seule porte de restauration les retrouve donc toutes.
 *
 * Une seule implémentation du dump : ce modèle, utilisé par l'export au
 * navigateur (db-export.php) ET par les sauvegardes automatiques.
 */
class Sauvegarde
{
    /** Racine d'installation (…/runtime est à côté de app/, launcher/, mysql/). */
    public static function racine(): string
    {
        return dirname(__DIR__, 3);
    }

    /**
     * Dossier des sauvegardes. Surchargeable par CALULIS_BACKUP_DIR : c'est ce
     * qui permet aux tests de travailler dans un dossier jetable SANS jamais
     * écrire ni supprimer quoi que ce soit dans une installation réelle.
     */
    public static function dossierBackups(): string
    {
        $force = getenv('CALULIS_BACKUP_DIR');
        if ($force !== false && $force !== '') {
            return rtrim($force, '/\\');
        }
        return self::racine() . '/runtime/backups/db';
    }

    /**
     * Écrit un dump SQL complet de la base courante dans un fichier daté.
     *
     * @param string $motif nom court, sans accent ni espace (ex. « avant-restauration »)
     * @return array{chemin:string,octets:int,tables:int,lignes:int}
     * @throws RuntimeException si le dossier ou le fichier ne peuvent pas être écrits
     *         (l'appelant DOIT alors annuler l'opération destructrice)
     */
    public static function ecrireFichier(PDO $pdo, string $motif = 'sauvegarde'): array
    {
        $motif = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $motif) ?? 'sauvegarde');
        $motif = trim($motif, '-') ?: 'sauvegarde';

        $dossier = self::dossierBackups() . '/' . date('Y-m-d_H-i-s');
        if (!is_dir($dossier) && !@mkdir($dossier, 0777, true) && !is_dir($dossier)) {
            throw new RuntimeException("Impossible de créer le dossier de sauvegarde : $dossier");
        }

        $chemin = $dossier . '/' . $motif . '.sql';
        for ($i = 2; is_file($chemin) && $i < 100; $i++) {
            $chemin = $dossier . '/' . $motif . "-$i.sql";
        }

        $flux = @fopen($chemin, 'wb');
        if (!$flux) {
            throw new RuntimeException("Impossible d'écrire la sauvegarde : $chemin");
        }

        try {
            $stats = self::ecrireFlux($pdo, $flux);
        } finally {
            fclose($flux);
        }

        $octets = @filesize($chemin) ?: 0;
        if ($octets <= 0) {
            @unlink($chemin);
            throw new RuntimeException("La sauvegarde est vide : $chemin");
        }

        return [
            'chemin'  => $chemin,
            'octets'  => $octets,
            'tables'  => $stats['tables'],
            'lignes'  => $stats['lignes'],
        ];
    }

    /**
     * Écrit le dump complet vers un flux déjà ouvert (export au navigateur).
     *
     * @param resource $flux
     * @return array{tables:int,lignes:int}
     */
    public static function ecrireFlux(PDO $pdo, $flux): array
    {
        $tables = 0;
        $lignes = 0;

        self::ecrire($flux, "-- Calulis — sauvegarde du " . date('Y-m-d H:i:s') . "\n");
        self::ecrire($flux, "-- Fichier produit sur le poste : aucune donnée n'est envoyée sur Internet.\n");
        self::ecrire($flux, "SET FOREIGN_KEY_CHECKS = 0;\n\n");

        $noms = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
        foreach ($noms as $table) {
            $create = $pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_NUM);
            if (!$create) { continue; }
            $tables++;

            self::ecrire($flux, "DROP TABLE IF EXISTS `$table`;\n");
            self::ecrire($flux, $create[1] . ";\n\n");

            $rows = $pdo->query("SELECT * FROM `$table`");
            $nbCols = $rows->columnCount();
            if ($nbCols === 0) { continue; }

            $cols = [];
            for ($i = 0; $i < $nbCols; $i++) {
                $meta = $rows->getColumnMeta($i);
                $cols[] = $meta['name'];
            }

            while (($row = $rows->fetch(PDO::FETCH_NUM)) !== false) {
                $values = array_map(static function ($v) use ($pdo) {
                    return $v === null ? 'NULL' : $pdo->quote($v);
                }, $row);
                self::ecrire($flux, "INSERT INTO `$table` (`" . implode('`,`', $cols) . "`) VALUES (" . implode(',', $values) . ");\n");
                $lignes++;
            }
            self::ecrire($flux, "\n");
        }

        self::ecrire($flux, "SET FOREIGN_KEY_CHECKS = 1;\n");

        return ['tables' => $tables, 'lignes' => $lignes];
    }

    /** @param resource $flux */
    private static function ecrire($flux, string $bloc): void
    {
        if (fwrite($flux, $bloc) === false) {
            throw new RuntimeException("Écriture interrompue : il n'y a plus assez de place sur le disque ?");
        }
    }

}
