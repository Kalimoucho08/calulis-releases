<?php
/**
 * Calulis — Model TypeDocument (table `types_documents`, module Documents 1.16)
 *
 * POURQUOI UNE TABLE, ET PAS UNE CONSTANTE
 * Les types de documents vivaient dans une constante PHP (`Document::TYPES`) : impossible
 * d'en ajouter un qui vient de paraître, de renommer un document institutionnel, ou
 * d'adapter la liste à son établissement — or un coordinateur de primaire, de collège et de
 * lycée n'a pas les mêmes documents. Demande de Jérôme (08/10/2026) : un éditeur de types.
 *
 * LA CLÉ NE CHANGE JAMAIS, LE LIBELLÉ SI
 * Un document enregistre la CLÉ de son type (`notification_mdph`), jamais son libellé :
 * renommer un type change donc son affichage PARTOUT, y compris sur les documents déjà
 * classés, sans y toucher. C'est aussi pourquoi on ne modifie jamais une clé après création :
 * la changer orphelinerait les documents qui la portent.
 *
 * SUPPRIMER : on refuse tant que des documents l'utilisent (`compterDocuments()`), en
 * expliquant, et on propose de les réaffecter (`reaffecter()`) — décision de Jérôme du
 * 08/10/2026. Rien n'est « protégé » : les 16 types amorcés par la migration 010 sont un
 * point de départ, pas un socle intouchable (même décision).
 */
require_once __DIR__ . '/../config.php';

class TypeDocument
{
    /** Longueur maximale de la clé (colonne `cle`). */
    private const LONGUEUR_CLE = 50;

    /**
     * Tous les types, dans l'ordre d'affichage.
     * @return array<int, array>
     */
    public static function tous(bool $actifsSeulement = false): array
    {
        $pdo = getDB();
        $sql = 'SELECT * FROM types_documents';
        if ($actifsSeulement) {
            $sql .= ' WHERE actif = 1';
        }
        $sql .= ' ORDER BY ordre, libelle';
        return $pdo->query($sql)->fetchAll();
    }

    /**
     * Le référentiel attendu par l'écran : [cle => libellé]. Même forme que l'ancienne
     * constante, donc le frontend n'a pas changé.
     */
    public static function referentiel(bool $actifsSeulement = true): array
    {
        $ref = [];
        foreach (self::tous($actifsSeulement) as $t) {
            $ref[(string)$t['cle']] = (string)$t['libelle'];
        }
        return $ref;
    }

    public static function find(int $id): ?array
    {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM types_documents WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function parCle(string $cle): ?array
    {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM types_documents WHERE cle = :cle');
        $stmt->execute(['cle' => $cle]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Clé à utiliser quand le type reçu est inconnu : le premier type actif, sinon « autre ». */
    public static function cleParDefaut(): string
    {
        foreach (self::tous(true) as $t) {
            return (string)$t['cle'];
        }
        return 'autre';
    }

    /**
     * Ajoute un type. La clé est fabriquée depuis le libellé (slug), jamais fournie par
     * l'appelant : c'est elle qui ne doit jamais changer.
     */
    public static function creer(string $libelle, ?int $ordre = null): int
    {
        $libelle = trim($libelle);
        if ($libelle === '') {
            throw new InvalidArgumentException('Donnez un nom au type de document.');
        }
        $pdo = getDB();
        $cle = self::cleUnique($libelle);
        if ($ordre === null) {
            $ordre = 1 + (int)$pdo->query('SELECT COALESCE(MAX(ordre), 0) FROM types_documents')->fetchColumn();
        }
        $stmt = $pdo->prepare(
            'INSERT INTO types_documents (cle, libelle, ordre, actif) VALUES (:cle, :libelle, :ordre, 1)'
        );
        $stmt->execute([
            'cle' => $cle,
            'libelle' => calulis_substr($libelle, 120),
            'ordre' => (int)$ordre,
        ]);
        return (int)$pdo->lastInsertId();
    }

    /**
     * Modifie un type : libellé, ordre, actif. La CLÉ n'est jamais modifiable (voir l'en-tête).
     */
    public static function modifier(int $id, array $data): bool
    {
        $existant = self::find($id);
        if (!$existant) {
            return false;
        }
        $libelle = array_key_exists('libelle', $data) ? trim((string)$data['libelle']) : (string)$existant['libelle'];
        if ($libelle === '') {
            throw new InvalidArgumentException('Le nom du type de document est obligatoire.');
        }
        $ordre = array_key_exists('ordre', $data) && $data['ordre'] !== null && $data['ordre'] !== ''
            ? (int)$data['ordre'] : (int)$existant['ordre'];
        $actif = array_key_exists('actif', $data) && $data['actif'] !== null
            ? (int)(bool)$data['actif'] : (int)$existant['actif'];

        $pdo = getDB();
        $stmt = $pdo->prepare(
            'UPDATE types_documents SET libelle = :libelle, ordre = :ordre, actif = :actif WHERE id = :id'
        );
        return $stmt->execute([
            'libelle' => calulis_substr($libelle, 120),
            'ordre' => $ordre,
            'actif' => $actif,
            'id' => $id,
        ]);
    }

    /**
     * Nombre de documents qui portent ce type — TOUTES années confondues : un élève sorti du
     * dispositif garde ses documents, et supprimer un type utilisé les rendrait illisibles.
     */
    public static function compterDocuments(string $cle): int
    {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM documents WHERE type = :cle');
        $stmt->execute(['cle' => $cle]);
        return (int)$stmt->fetchColumn();
    }

    /**
     * Réaffecte tous les documents d'un type vers un autre, et rend le nombre de documents
     * déplacés. C'est la porte de sortie proposée quand une suppression est refusée.
     */
    public static function reaffecter(string $cleSource, string $cleCible): int
    {
        if ($cleSource === $cleCible) {
            return 0;
        }
        if (self::parCle($cleCible) === null) {
            throw new InvalidArgumentException('Le type de destination est inconnu.');
        }
        $pdo = getDB();
        $stmt = $pdo->prepare('UPDATE documents SET type = :cible WHERE type = :source');
        $stmt->execute(['cible' => $cleCible, 'source' => $cleSource]);
        return $stmt->rowCount();
    }

    public static function supprimer(int $id): bool
    {
        $type = self::find($id);
        if (!$type) {
            return false;
        }
        // On ne supprime JAMAIS un type encore utilisé : l'appelant a normalement déjà
        // refusé avec un message clair, mais la règle vit ici aussi (une seule source).
        if (self::compterDocuments((string)$type['cle']) > 0) {
            throw new RuntimeException('Ce type est encore utilisé par des documents.');
        }
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM types_documents WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    /** Fabrique une clé unique à partir d'un libellé (« Compte rendu d'ESS » → compte_rendu_d_ess). */
    public static function cleUnique(string $libelle): string
    {
        $base = self::slug($libelle);
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT COUNT(*) FROM types_documents WHERE cle = :cle');
        $cle = $base;
        for ($i = 2; $i < 100; $i++) {
            $stmt->execute(['cle' => $cle]);
            if ((int)$stmt->fetchColumn() === 0) {
                return $cle;
            }
            $suffixe = '_' . $i;
            $cle = calulis_substr($base, self::LONGUEUR_CLE - strlen($suffixe)) . $suffixe;
        }
        return calulis_substr($base, self::LONGUEUR_CLE - 4) . '_' . random_int(1000, 9999);
    }

    /**
     * Slug sans dépendance : minuscules, accents français dépliés, tout le reste en « _ ».
     * Volontairement sans iconv/mbstring — le PHP de développement de ce poste n'a pas
     * mbstring (constaté le 08/10/2026).
     */
    public static function slug(string $libelle): string
    {
        $minuscules = strtr($libelle, [
            'À' => 'a', 'Â' => 'a', 'Ä' => 'a', 'Á' => 'a', 'Ã' => 'a', 'Å' => 'a',
            'à' => 'a', 'â' => 'a', 'ä' => 'a', 'á' => 'a', 'ã' => 'a', 'å' => 'a',
            'Ç' => 'c', 'ç' => 'c',
            'É' => 'e', 'È' => 'e', 'Ê' => 'e', 'Ë' => 'e', 'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
            'Î' => 'i', 'Ï' => 'i', 'î' => 'i', 'ï' => 'i',
            'Ô' => 'o', 'Ö' => 'o', 'ô' => 'o', 'ö' => 'o',
            'Ù' => 'u', 'Û' => 'u', 'Ü' => 'u', 'ù' => 'u', 'û' => 'u', 'ü' => 'u',
            'Œ' => 'oe', 'œ' => 'oe', 'Æ' => 'ae', 'æ' => 'ae',
            'Ñ' => 'n', 'ñ' => 'n',
        ]);
        $slug = strtolower($minuscules);
        $slug = preg_replace('/[^a-z0-9]+/', '_', $slug) ?? '';
        $slug = trim($slug, '_');
        if ($slug === '') {
            $slug = 'type';
        }
        return calulis_substr($slug, self::LONGUEUR_CLE);
    }
}
