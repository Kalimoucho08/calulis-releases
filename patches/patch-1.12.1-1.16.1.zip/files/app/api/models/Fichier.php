<?php
/**
 * Calulis — Model Fichier (table `fichiers`, module Documents 1.16).
 *
 * La table est polymorphique : `entite_type` + `entite_id` désignent le propriétaire
 * du fichier (« document », plus tard « eleve », « reunion »…). Le module Documents
 * l'utilise avec `entite_type = 'document'` et un fichier par document.
 *
 * Créée par la migration 009 : elle existait dans les dumps d'installation mais
 * aucune migration ne la créait, donc une installation mise à jour ne l'avait pas.
 */
require_once __DIR__ . '/../config.php';

class Fichier
{
    /** Le fichier d'une entité (le plus récent), ou null. */
    public static function pourEntite(string $entiteType, int $entiteId): ?array
    {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT * FROM fichiers
             WHERE entite_type = :t AND entite_id = :i
             ORDER BY id DESC LIMIT 1'
        );
        $stmt->execute(['t' => $entiteType, 'i' => $entiteId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Tous les fichiers d'une entité (le plus récent en dernier). */
    public static function tousPourEntite(string $entiteType, int $entiteId): array
    {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT * FROM fichiers
             WHERE entite_type = :t AND entite_id = :i
             ORDER BY id ASC'
        );
        $stmt->execute(['t' => $entiteType, 'i' => $entiteId]);
        return $stmt->fetchAll();
    }

    /** Enregistre un fichier en base et rend son identifiant. */
    public static function create(array $data): int
    {
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO fichiers (
            entite_type, entite_id, nom_original, nom_stocke, chemin,
            taille, type_mime, uploade_par
        ) VALUES (
            :entite_type, :entite_id, :nom_original, :nom_stocke, :chemin,
            :taille, :type_mime, :uploade_par
        )');
        $stmt->execute([
            'entite_type'  => $data['entite_type'],
            'entite_id'    => (int)$data['entite_id'],
            'nom_original' => $data['nom_original'],
            'nom_stocke'   => $data['nom_stocke'],
            'chemin'       => $data['chemin'],
            'taille'       => isset($data['taille']) ? (int)$data['taille'] : null,
            'type_mime'    => $data['type_mime'] ?? null,
            'uploade_par'  => $data['uploade_par'] ?? null,
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function delete(int $id): bool
    {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM fichiers WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    /** Supprime toutes les lignes d'une entité, rend le nombre supprimé. */
    public static function deletePourEntite(string $entiteType, int $entiteId): int
    {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM fichiers WHERE entite_type = :t AND entite_id = :i');
        $stmt->execute(['t' => $entiteType, 'i' => $entiteId]);
        return $stmt->rowCount();
    }

    /**
     * Toutes les lignes dont le chemin commence par un préfixe — par exemple
     * `eleve-12/` quand on efface le dossier d'un élève.
     *
     * À QUOI ÇA SERT : une ligne `fichiers` peut survivre à la disparition de son
     * document (le document a été supprimé, ou la base a été restaurée d'un autre
     * poste). En ne regardant que les documents de l'élève, on laisserait ces lignes
     * pointer vers des fichiers effacés — invisibles, mais fausses. On les retire
     * donc par le chemin, qui est le seul lien restant avec le disque.
     */
    public static function tousPourPrefixeChemin(string $prefixe): array
    {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM fichiers WHERE chemin LIKE :p');
        // Les jokers de LIKE sont neutralisés : le préfixe est une donnée, pas un motif.
        $stmt->execute(['p' => str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $prefixe) . '%']);
        return $stmt->fetchAll();
    }

    /** Supprime une ligne par son identifiant, rend TRUE si elle existait. */
    public static function supprimerParId(int $id): bool
    {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM fichiers WHERE id = :id');
        $stmt->execute(['id' => $id]);
        return $stmt->rowCount() > 0;
    }
}
