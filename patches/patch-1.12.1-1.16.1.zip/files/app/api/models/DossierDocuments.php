<?php
/**
 * Calulis — Le dossier de documents d'un élève (module Documents, 1.16).
 *
 * POURQUOI CE FICHIER
 * Quand on supprime un élève, ses documents ne peuvent pas disparaître en silence :
 * la page « Mentions RGPD » promet le droit à l'effacement, et un dossier peut être
 * redemandé des années plus tard (un élève parti au collège dont on recherche les
 * bilans). La décision de Jérôme (08/10/2026) tient en deux gestes, et c'est ce
 * fichier qui les rend possibles :
 *
 *   1. **archiver** — fabriquer un ZIP qui contient tous ses documents ET un index
 *      lisible, pour que l'utilisateur puisse l'emporter ailleurs avant de perdre
 *      l'élève de l'application ;
 *   2. **effacer** — supprimer les documents, leurs fichiers, et le dossier de
 *      l'élève sur le disque, UNIQUEMENT sous `runtime/documents/`.
 *
 * OÙ CELA SE BRANCHE
 * `Eleve::delete()` et `Eleve::purgeInactifsAvant()` délèguent ici : une suppression
 * d'élève n'est jamais « juste » une ligne de moins dans `eleves`.
 *
 * CE QUI N'EST PAS FAIT ICI
 * Aucun HTML, aucun HTTP : ce modèle rend des données, le contrôleur les sert.
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/Document.php';
require_once __DIR__ . '/Fichier.php';
require_once __DIR__ . '/Stockage.php';
require_once __DIR__ . '/TypeDocument.php';
require_once __DIR__ . '/Archive.php';

class DossierDocuments
{
    /** Nom de l'index dans l'archive : annoncé tel quel par l'aide et la page RGPD. */
    public const INDEX = 'documents.txt';

    /** Les documents d'un élève (fichier joint compris), du plus récent au plus ancien. */
    public static function documents(int $eleveId): array
    {
        return Document::getByEleve($eleveId);
    }

    /**
     * Fabrique l'archive des documents d'un élève.
     *
     * Rend `null` quand l'élève n'a AUCUN document : il n'y a alors rien à emporter,
     * et proposer une archive vide serait une promesse en l'air.
     *
     * L'archive contient :
     *   - un fichier par document rapatrié, sous son nom d'origine ;
     *   - `documents.txt`, l'index de TOUS les documents (y compris ceux qui n'ont
     *     pas de fichier — les « documents à compléter » — et ceux dont le fichier a
     *     disparu du disque, signalés comme tels). Sans cet index, un dossier de PDF
     *     perdrait tout son classement : quel courrier, quelle date, quel type.
     *
     * @param array $eleve Ligne de l'élève (nom, prénom) pour nommer l'archive.
     * @throws RuntimeException si un fichier disparaît pendant la lecture
     */
    public static function archive(int $eleveId, array $eleve): ?Archive
    {
        $documents = self::documents($eleveId);
        if ($documents === []) {
            return null;
        }
        $types = TypeDocument::referentiel(false);

        // Premier passage : on résout les chemins sur le disque AVANT d'écrire le
        // moindre octet. Une archive à moitié écrite serait pire que pas d'archive.
        $aAjouter = [];
        $manquants = 0;
        foreach ($documents as $d) {
            if (empty($d['fichier_id'])) {
                continue;
            }
            $absolu = Stockage::cheminAbsolu((string)($d['fichier_chemin'] ?? ''));
            if ($absolu === null || !is_file($absolu)) {
                $manquants++;
                continue;
            }
            $nom = (string)($d['fichier_nom'] ?? '');
            $aAjouter[(int)$d['id']] = [
                'nom'    => $nom !== '' ? $nom : basename($absolu),
                'absolu' => $absolu,
            ];
        }

        $archive = new Archive();
        // L'index garde TOUJOURS son nom : un document qui s'appellerait « documents.txt »
        // serait renommé, pas l'index (l'aide et la page RGPD l'annoncent sous ce nom).
        $archive->reserverNom(self::INDEX);
        $nomsEcrits = [];
        foreach ($aAjouter as $documentId => $entree) {
            $nomsEcrits[$documentId] = $archive->ajouterFichier($entree['nom'], $entree['absolu']);
        }

        $archive->ajouterIndex(self::INDEX, self::index($eleve, $documents, $types, $nomsEcrits, $manquants));
        return $archive;
    }

    /** Nom de fichier proposé au navigateur : `documents-lea-lemoine-2026-10-08.zip`. */
    public static function nomArchive(array $eleve): string
    {
        $nom = trim(((string)($eleve['prenom'] ?? '')) . ' ' . ((string)($eleve['nom'] ?? '')));
        $nom = strtolower($nom);
        // Les accents sont retirés par une table explicite : `iconv//TRANSLIT` n'existe
        // pas partout, et un nom de fichier avec « é » se comporte mal selon les outils.
        $nom = strtr($nom, [
            'à' => 'a', 'â' => 'a', 'ä' => 'a', 'á' => 'a', 'ã' => 'a', 'å' => 'a',
            'ç' => 'c', 'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
            'î' => 'i', 'ï' => 'i', 'í' => 'i', 'ô' => 'o', 'ö' => 'o', 'ó' => 'o', 'õ' => 'o',
            'ù' => 'u', 'û' => 'u', 'ü' => 'u', 'ú' => 'u', 'ÿ' => 'y', 'ñ' => 'n',
            'œ' => 'oe', 'æ' => 'ae',
        ]);
        $nom = (string)preg_replace('/[^a-z0-9]+/', '-', $nom);
        $nom = trim($nom, '-');
        if ($nom === '') {
            $nom = 'eleve';
        }
        return 'documents-' . $nom . '-' . date('Y-m-d') . '.zip';
    }

    /**
     * Recense et supprime les LIGNES des documents d'un élève : ses documents et leurs
     * fichiers. **N'ouvre aucune transaction** : c'est l'appelant qui en ouvre une et y
     * met AUSSI la suppression de l'élève. Sans cela, un `DELETE FROM eleves` qui échoue
     * (verrou, coupure) laisserait un élève dont les documents ont déjà disparu —
     * défaut relevé par la revue de code du 08/10/2026.
     *
     * @return array{documents:int,fichiers:array<int,array>} Les lignes de fichiers recensées,
     *         à effacer du disque APRÈS le commit (voir `purgerFichiers`).
     */
    public static function supprimerLignes(int $eleveId): array
    {
        $documents = self::documents($eleveId);
        $idsDocuments = array_map(static fn(array $d): int => (int)$d['id'], $documents);

        // Les fichiers sont recensés AVANT la suppression des lignes : après, plus rien
        // ne dit quels octets appartenaient à cet élève.
        $fichiers = [];
        foreach ($idsDocuments as $documentId) {
            foreach (Fichier::tousPourEntite('document', $documentId) as $f) {
                $fichiers[(int)$f['id']] = $f;
            }
        }
        // Plus ceux dont le CHEMIN désigne le dossier de l'élève, même si leur document
        // a disparu : ce sont eux qui resteraient sinon, sans personne pour les réclamer.
        $prefixe = Stockage::nomDossierEleve($eleveId) . '/';
        foreach (Fichier::tousPourPrefixeChemin($prefixe) as $f) {
            $fichiers[(int)$f['id']] = $f;
        }

        $pdo = getDB();
        foreach (array_keys($fichiers) as $fichierId) {
            Fichier::supprimerParId($fichierId);
        }
        if ($idsDocuments !== []) {
            $marques = implode(',', array_fill(0, count($idsDocuments), '?'));
            $stmt = $pdo->prepare("DELETE FROM documents WHERE id IN ($marques)");
            $stmt->execute($idsDocuments);
        }

        return ['documents' => count($documents), 'fichiers' => array_values($fichiers)];
    }

    /**
     * Efface du disque les fichiers recensés par `supprimerLignes()`, puis le dossier
     * ENTIER de l'élève. À appeler **après** le commit de la transaction.
     *
     * Un fichier qui résiste (ouvert dans un lecteur PDF) n'interrompt pas le reste :
     * il est compté et journalisé, l'appelant doit le DIRE à l'utilisateur — jamais
     * laisser croire à un effacement complet.
     *
     * @param array<int,array> $fichiers
     * @return array{fichiers:int,fichiers_restants:int,dossier_supprime:bool}
     */
    public static function purgerFichiers(array $fichiers, int $eleveId): array
    {
        $restants = 0;
        foreach ($fichiers as $f) {
            if (!Stockage::supprimer((string)$f['chemin'])) {
                $restants++;
                calulis_log_error('[documents] fichier non supprimé (fichier ' . (int)$f['id'] . ')');
            }
        }
        $dossierSupprime = Stockage::supprimerDossierEleve($eleveId);
        if (!$dossierSupprime) {
            calulis_log_error('[documents] dossier d\'élève non supprimé (élève ' . $eleveId . ')');
        }

        return [
            'fichiers'          => count($fichiers),
            'fichiers_restants' => $restants,
            'dossier_supprime'  => $dossierSupprime,
        ];
    }

    /** L'index `documents.txt` de l'archive : lisible par un humain, en UTF-8. */
    private static function index(array $eleve, array $documents, array $types, array $nomsEcrits, int $manquants): string
    {
        $nom = trim(((string)($eleve['prenom'] ?? '')) . ' ' . ((string)($eleve['nom'] ?? '')));
        $lignes = [];
        $lignes[] = 'Documents de ' . ($nom !== '' ? $nom : 'cet élève');
        $lignes[] = 'Archive créée le ' . date('d/m/Y à H:i') . ' par Calulis.';
        $lignes[] = '';
        $lignes[] = 'Cet index décrit TOUS les documents de l\'élève, y compris ceux qui n\'avaient';
        $lignes[] = 'pas encore de fichier joint (« document à compléter »).';
        $lignes[] = '';
        $numero = 0;
        $sansFichier = 0;
        foreach ($documents as $d) {
            $numero++;
            $libelle = (string)($types[(string)$d['type']] ?? $d['type']);
            $date = (string)($d['date_document'] ?? '');
            $dateLisible = $date !== '' ? date('d/m/Y', strtotime($date) ?: time()) : 'date non renseignée';
            $details = [$libelle, $dateLisible];

            $id = (int)$d['id'];
            if (isset($nomsEcrits[$id])) {
                $details[] = $nomsEcrits[$id];
            } elseif (!empty($d['fichier_id'])) {
                $details[] = 'FICHIER INTROUVABLE sur le disque';
            } else {
                $details[] = 'aucun fichier joint';
                $sansFichier++;
            }
            $lignes[] = sprintf('%2d. %s', $numero, implode(' — ', $details));
            $notes = trim((string)($d['notes'] ?? ''));
            if ($notes !== '') {
                foreach (preg_split('/\R/', $notes) ?: [] as $ligneNote) {
                    $lignes[] = '      ' . $ligneNote;
                }
            }
        }
        $lignes[] = '';
        $lignes[] = sprintf(
            '%d document(s) : %d avec un fichier%s.',
            count($documents),
            count($nomsEcrits),
            $sansFichier > 0 ? ', ' . $sansFichier . ' sans fichier joint' : ''
        );
        if ($manquants > 0) {
            $lignes[] = sprintf(
                'ATTENTION : %d fichier(s) annoncé(s) en base n\'ont pas été retrouvés sur le disque.',
                $manquants
            );
        }
        return implode("\n", $lignes) . "\n";
    }
}
