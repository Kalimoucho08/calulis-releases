<?php
/** Calulis — Modèle « Tâches »
 *
 *  Une tâche est une chose à faire, avec une échéance. Elle peut être liée à un élève
 *  (`eleve_id`) et/ou à un adulte (`adulte_id`) — les deux sont facultatifs : les tâches
 *  générales (« commander du matériel ») ont leur place.
 *
 *  Convention arrêtée le 04/10/2026 : il n'y a PAS de colonne « titre ». La PREMIÈRE LIGNE
 *  de `description` fait office de titre, le reste est le détail. La composition et la
 *  lecture se font ici, pour que tous les appelants partagent la même règle.
 *
 *  Statuts : a_faire, plus_tard, en_cours, fait, annule.
 *  Monoposte : pas de responsable d'exécution ; `precision_libre` est un champ libre court.
 */

require_once __DIR__ . '/../config.php';

class Tache {

    public const STATUTS   = ['a_faire', 'plus_tard', 'en_cours', 'fait', 'annule'];
    public const PRIORITES = ['haute', 'moyenne', 'basse'];
    public const COULEURS  = ['jaune', 'vert', 'bleu', 'rose', 'violet', 'orange'];

    private static function pdo(): PDO {
        return getDB();
    }

    /* ------------------------------------------------------------------ */
    /* Convention titre / détail (première ligne = titre)                  */
    /* ------------------------------------------------------------------ */

    /** Compose la description stockée à partir du titre et du détail */
    public static function composer(string $titre, string $detail = ''): string {
        $titre = trim($titre);
        $detail = trim($detail);
        return $detail === '' ? $titre : $titre . "\n" . $detail;
    }

    /** Première ligne = titre */
    public static function titre(string $description): string {
        $lignes = preg_split('/\R/', trim($description));
        return $lignes[0] ?? '';
    }

    /** Le reste = détail */
    public static function detail(string $description): string {
        $lignes = preg_split('/\R/', trim($description));
        array_shift($lignes);
        return trim(implode("\n", $lignes));
    }

    /* ------------------------------------------------------------------ */
    /* Lecture                                                             */
    /* ------------------------------------------------------------------ */

    /**
     * Liste des tâches, filtrée.
     * @param int|null $anneeId Année scolaire active
     * @param array $filtres statut, eleve_id, adulte_id, du, au, a_venir
     */
    public static function all(?int $anneeId, array $filtres = []): array {
        $sql = "SELECT t.id, t.annee_scolaire_id, t.description, t.eleve_id, t.adulte_id, t.reunion_id,
                       t.date_creation, t.echeance, t.priorite, t.statut, t.couleur, t.precision_libre, t.notes,
                       e.nom AS eleve_nom, e.prenom AS eleve_prenom,
                       a.nom AS adulte_nom, a.prenom AS adulte_prenom, a.civilite AS adulte_civilite
                  FROM taches t
             LEFT JOIN eleves  e ON e.id = t.eleve_id
             LEFT JOIN adultes a ON a.id = t.adulte_id
                 WHERE 1 = 1";
        $params = [];

        if ($anneeId) {
            $sql .= " AND t.annee_scolaire_id = :annee_id";
            $params['annee_id'] = $anneeId;
        }
        if (!empty($filtres['statut']) && in_array($filtres['statut'], self::STATUTS, true)) {
            $sql .= " AND t.statut = :statut";
            $params['statut'] = $filtres['statut'];
        }
        if (!empty($filtres['eleve_id'])) {
            $sql .= " AND t.eleve_id = :eleve_id";
            $params['eleve_id'] = (int)$filtres['eleve_id'];
        }
        if (!empty($filtres['adulte_id'])) {
            $sql .= " AND t.adulte_id = :adulte_id";
            $params['adulte_id'] = (int)$filtres['adulte_id'];
        }
        if (!empty($filtres['du'])) {
            $sql .= " AND t.echeance >= :du";
            $params['du'] = $filtres['du'];
        }
        if (!empty($filtres['au'])) {
            $sql .= " AND t.echeance <= :au";
            $params['au'] = $filtres['au'];
        }
        if (!empty($filtres['a_venir'])) {
            $sql .= " AND t.statut IN ('a_faire', 'plus_tard', 'en_cours')";
        }

        // Par échéance croissante ; les tâches sans échéance à la fin
        $sql .= " ORDER BY (t.echeance IS NULL), t.echeance ASC, t.id DESC";

        $stmt = self::pdo()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function find(int $id): ?array {
        $stmt = self::pdo()->prepare(
            "SELECT t.id, t.annee_scolaire_id, t.description, t.eleve_id, t.adulte_id, t.reunion_id,
                    t.date_creation, t.echeance, t.priorite, t.statut, t.couleur, t.precision_libre, t.notes,
                    e.nom AS eleve_nom, e.prenom AS eleve_prenom,
                    a.nom AS adulte_nom, a.prenom AS adulte_prenom, a.civilite AS adulte_civilite
               FROM taches t
          LEFT JOIN eleves  e ON e.id = t.eleve_id
          LEFT JOIN adultes a ON a.id = t.adulte_id
              WHERE t.id = :id"
        );
        $stmt->execute(['id' => $id]);
        $t = $stmt->fetch(PDO::FETCH_ASSOC);
        return $t ?: null;
    }

    /* ------------------------------------------------------------------ */
    /* Écriture                                                            */
    /* ------------------------------------------------------------------ */

    public static function create(array $data, ?int $anneeId): int {
        $propre = self::_valider($data, true);

        $stmt = self::pdo()->prepare(
            "INSERT INTO taches (annee_scolaire_id, description, eleve_id, adulte_id, date_creation,
                                 echeance, priorite, statut, couleur, precision_libre, notes)
             VALUES (:annee_id, :description, :eleve_id, :adulte_id, :date_creation,
                     :echeance, :priorite, :statut, :couleur, :precision_libre, :notes)"
        );
        $stmt->execute([
            'annee_id'        => $anneeId,
            'description'     => $propre['description'],
            'eleve_id'        => $propre['eleve_id'],
            'adulte_id'       => $propre['adulte_id'],
            'date_creation'   => $propre['date_creation'],
            'echeance'        => $propre['echeance'],
            'priorite'        => $propre['priorite'],
            'statut'          => $propre['statut'],
            'couleur'         => $propre['couleur'],
            'precision_libre' => $propre['precision_libre'],
            'notes'           => $propre['notes'],
        ]);
        return (int)self::pdo()->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $propre = self::_valider($data, false);
        if (!$propre) {
            return false;
        }
        $sets = [];
        $params = ['id' => $id];
        foreach ($propre as $colonne => $valeur) {
            $sets[] = "$colonne = :$colonne";
            $params[$colonne] = $valeur;
        }
        $stmt = self::pdo()->prepare("UPDATE taches SET " . implode(', ', $sets) . " WHERE id = :id");
        $stmt->execute($params);
        return $stmt->rowCount() >= 0;
    }

    public static function delete(int $id): bool {
        $stmt = self::pdo()->prepare("DELETE FROM taches WHERE id = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->rowCount() > 0;
    }

    /* ------------------------------------------------------------------ */
    /* Validation                                                          */
    /* ------------------------------------------------------------------ */

    private static function _valider(array $data, bool $creation): array {
        $propre = [];
        $champ = fn(string $cle) => array_key_exists($cle, $data);

        // Le titre est obligatoire : c'est la première ligne de la description
        if ($creation || $champ('description') || $champ('titre')) {
            $description = (string)($data['description'] ?? '');
            // Le client peut envoyer titre + detail séparément : on compose ici
            if ($champ('titre') && !$champ('description')) {
                $description = self::composer((string)$data['titre'], (string)($data['detail'] ?? ''));
            }
            $description = trim($description);
            if ($description === '') {
                throw new InvalidArgumentException('Il faut au moins un titre pour la tâche');
            }
            // Le titre et le détail tiennent dans une seule colonne de 500 caractères : on REFUSE
            // au lieu de couper en silence (la revue du 04/10/2026 a relevé l'incohérence avec la
            // précision, qui, elle, refusait déjà). Un message vaut mieux qu'une perte de texte.
            if (mb_strlen($description) > 500) {
                throw new InvalidArgumentException(
                    'La tâche est trop longue : 500 caractères au maximum, titre et détail compris'
                );
            }
            $propre['description'] = $description;
        }

        foreach (['eleve_id', 'adulte_id'] as $lien) {
            if ($creation || $champ($lien)) {
                $valeur = $data[$lien] ?? null;
                $propre[$lien] = ($valeur === null || $valeur === '' || (int)$valeur === 0) ? null : (int)$valeur;
            }
        }

        if ($creation || $champ('precision_libre')) {
            $precision = trim((string)($data['precision_libre'] ?? ''));
            if (mb_strlen($precision) > 100) {
                throw new InvalidArgumentException('La précision ne doit pas dépasser 100 caractères');
            }
            $propre['precision_libre'] = $precision === '' ? null : $precision;
        }

        if ($creation || $champ('notes')) {
            $propre['notes'] = trim((string)($data['notes'] ?? '')) ?: null;
        }

        if ($creation || $champ('echeance')) {
            $echeance = trim((string)($data['echeance'] ?? ''));
            if ($echeance !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $echeance)) {
                throw new InvalidArgumentException('Échéance invalide : ' . $echeance);
            }
            $propre['echeance'] = $echeance === '' ? null : $echeance;
        }

        if ($creation || $champ('date_creation')) {
            $date = trim((string)($data['date_creation'] ?? ''));
            if ($date === '') {
                $date = date('Y-m-d');
            }
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
                throw new InvalidArgumentException('Date de création invalide : ' . $date);
            }
            $propre['date_creation'] = $date;
        }

        if ($creation || $champ('statut')) {
            $statut = (string)($data['statut'] ?? 'a_faire');
            if (!in_array($statut, self::STATUTS, true)) {
                throw new InvalidArgumentException('Statut inconnu : ' . $statut);
            }
            $propre['statut'] = $statut;
        }

        if ($creation || $champ('priorite')) {
            $priorite = (string)($data['priorite'] ?? 'moyenne');
            if (!in_array($priorite, self::PRIORITES, true)) {
                throw new InvalidArgumentException('Priorité inconnue : ' . $priorite);
            }
            $propre['priorite'] = $priorite;
        }

        if ($creation || $champ('couleur')) {
            $couleur = (string)($data['couleur'] ?? 'jaune');
            if (!in_array($couleur, self::COULEURS, true)) {
                throw new InvalidArgumentException('Couleur inconnue : ' . $couleur);
            }
            $propre['couleur'] = $couleur;
        }

        return $propre;
    }
}
