<?php
/**
 * Calulis — Stockage local des documents (module Documents, version 1.16).
 *
 * POURQUOI CE FICHIER
 * Jusqu'ici Calulis ne stockait AUCUN fichier : `lien_pai` et `liens_mdph` sont de
 * simples liens externes. Le module Documents rapatrie au contraire le document
 * demandé par l'utilisateur DANS un dossier de l'installation, pour qu'il reste
 * consultable même si l'original a été déplacé, renommé ou supprimé.
 *
 * OÙ SONT LES FICHIERS
 * `<racine>/runtime/documents/eleve-<id>/<nom-stocké>` — jamais dans `app/`, qui
 * est la racine web : un document n'est donc pas joignable par une URL devinée,
 * c'est l'API qui le sert après contrôle. `runtime/` est le dossier que les mises
 * à jour ne remplacent pas (même choix que `runtime/backups/db`).
 *
 * CE QUE CE MODÈLE NE FAIT PAS
 * Il ne connaît ni PDO ni la table `fichiers` : l'enregistrement SQL est le travail
 * de `Fichier.php`. Ici, uniquement le disque et les garde-fous.
 *
 * Variable d'environnement : CALULIS_DOCUMENTS_DIR force la racine (les tests
 * écrivent ainsi dans un dossier jetable, jamais dans une installation réelle).
 */
class Stockage
{
    /**
     * Types acceptés : extension => type MIME que NOUS annonçons au navigateur.
     * On ne reprend jamais le type MIME envoyé par le client : il ne sert qu'à
     * refuser (voir MIME_REFUSES) et à journaliser.
     */
    public const TYPES = [
        'pdf'  => 'application/pdf',
        'jpg'  => 'image/jpeg',
        'jpeg' => 'image/jpeg',
        'png'  => 'image/png',
        'webp' => 'image/webp',
        'txt'  => 'text/plain',
        'odt'  => 'application/vnd.oasis.opendocument.text',
        'doc'  => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    ];

    /**
     * 32 Mo : la plus petite des deux limites réellement configurées
     * (`php/php.ini` en développement, `frankenphp/php.ini` dans le paquet, 100 Mo).
     * Refuser ici plutôt que de laisser PHP tronquer la requête en silence.
     */
    public const TAILLE_MAX = 33554432;

    /** Types MIME de contenu exécutable : refusés même si l'extension est permise. */
    private const MIME_REFUSES = [
        'text/x-php', 'application/x-php', 'application/x-httpd-php',
        'text/x-httpd-php', 'text/x-shellscript', 'application/x-shellscript',
        'application/x-dosexec', 'application/x-executable', 'application/x-sharedlib',
        'application/x-msdownload', 'application/x-java-applet',
    ];

    /** Racine d'installation : `runtime/` et `app/` sont à côté de `launcher/`, `mysql/`. */
    public static function racineInstallation(): string
    {
        return dirname(__DIR__, 3);
    }

    /** Dossier des documents, surchargeable par CALULIS_DOCUMENTS_DIR (tests). */
    public static function racine(): string
    {
        $force = getenv('CALULIS_DOCUMENTS_DIR');
        if ($force !== false && $force !== '') {
            return rtrim($force, '/\\');
        }
        return self::racineInstallation() . '/runtime/documents';
    }

    /** Dossier d'un élève (ou `_sans-eleve` pour un document non rattaché). */
    public static function dossierEleve(?int $eleveId): string
    {
        return self::racine() . '/' . self::nomDossierEleve($eleveId);
    }

    public static function nomDossierEleve(?int $eleveId): string
    {
        return $eleveId !== null && $eleveId > 0 ? 'eleve-' . $eleveId : '_sans-eleve';
    }

    /** Extension normalisée (minuscules, sans le point), ou chaîne vide. */
    public static function extension(string $nomFichier): string
    {
        $ext = strtolower(pathinfo($nomFichier, PATHINFO_EXTENSION));
        return preg_replace('/[^a-z0-9]/', '', $ext) ?? '';
    }

    /** Type MIME officiel d'une extension permise, ou null. */
    public static function typeMime(string $extension): ?string
    {
        return self::TYPES[strtolower($extension)] ?? null;
    }

    /** Vrai si l'extension fait partie de la liste blanche. */
    public static function extensionPermise(string $nomFichier): bool
    {
        return self::typeMime(self::extension($nomFichier)) !== null;
    }

    /**
     * Contrôle un fichier reçu ($_FILES['…']) et rend ce qu'il faut pour l'enregistrer.
     *
     * @return array{nom_original:string,extension:string,type_mime:string,taille:int,tmp:string}
     * @throws InvalidArgumentException message destiné à l'utilisateur (affiché tel quel)
     */
    public static function valider(array $file): array
    {
        $nom = (string)($file['name'] ?? '');
        $tmp = (string)($file['tmp_name'] ?? '');
        $err = (int)($file['error'] ?? UPLOAD_ERR_NO_FILE);

        if ($err !== UPLOAD_ERR_OK) {
            throw new InvalidArgumentException(self::messageErreur($err));
        }
        if ($nom === '' || $tmp === '' || !is_uploaded_file($tmp)) {
            throw new InvalidArgumentException("Aucun fichier reçu. Choisissez un document et recommencez.");
        }
        if (!self::extensionPermise($nom)) {
            throw new InvalidArgumentException(
                "Ce type de fichier n'est pas accepté. Formats autorisés : "
                . implode(', ', array_keys(self::TYPES)) . '.'
            );
        }

        $taille = (int)($file['size'] ?? 0);
        if ($taille <= 0) {
            $taille = (int)@filesize($tmp);
        }
        if ($taille <= 0) {
            throw new InvalidArgumentException("Le fichier reçu est vide.");
        }
        if ($taille > self::TAILLE_MAX) {
            throw new InvalidArgumentException(
                'Le fichier est trop volumineux (' . self::tailleLisible($taille)
                . '). La limite est de ' . self::tailleLisible(self::TAILLE_MAX) . '.'
            );
        }

        $ext = self::extension($nom);
        $reel = self::typeMimeDetecte($tmp);
        if ($reel !== null && in_array($reel, self::MIME_REFUSES, true)) {
            throw new InvalidArgumentException("Ce fichier n'est pas un document (contenu exécutable).");
        }

        return [
            'nom_original' => self::nomOriginalSain($nom),
            'extension'    => $ext,
            'type_mime'    => self::TYPES[$ext],
            'taille'       => $taille,
            'tmp'          => $tmp,
            'mime_detecte' => $reel,
        ];
    }

    /**
     * Déplace le fichier reçu dans le dossier de l'élève.
     *
     * @return array{nom_original:string,nom_stocke:string,chemin:string,taille:int,type_mime:string}
     * @throws RuntimeException si le disque refuse l'écriture (l'appelant DOIT alors annuler)
     */
    public static function enregistrer(array $valide, ?int $eleveId, int $documentId): array
    {
        $dossier = self::dossierEleve($eleveId);
        if (!is_dir($dossier) && !@mkdir($dossier, 0755, true) && !is_dir($dossier)) {
            // Le message ne porte pas le chemin : il finit dans le journal, et le chemin
            // contient le numéro de l'élève et le dossier d'installation du poste.
            throw new RuntimeException("Impossible de créer le dossier des documents (élève $eleveId)");
        }

        $nomStocke = self::nomStocke($documentId, $valide['extension']);
        $absolu = $dossier . '/' . $nomStocke;

        if (!@move_uploaded_file($valide['tmp'], $absolu)) {
            // Repli pour les environnements de test où le fichier n'est pas un
            // vrai téléversement PHP : jamais utilisé sur le chemin normal.
            if (!@rename($valide['tmp'], $absolu) || !is_file($absolu)) {
                throw new RuntimeException("Le fichier n'a pas pu être enregistré (document $documentId)");
            }
        }
        @chmod($absolu, 0644);

        return [
            'nom_original' => $valide['nom_original'],
            'nom_stocke'   => $nomStocke,
            'chemin'       => self::nomDossierEleve($eleveId) . '/' . $nomStocke,
            'taille'       => (int)@filesize($absolu) ?: $valide['taille'],
            'type_mime'    => $valide['type_mime'],
        ];
    }

    /**
     * Supprime un fichier. Rend TRUE quand il n'y a plus rien sur le disque — y compris
     * s'il avait déjà disparu : un fichier absent n'est pas un échec, et le compter comme
     * tel faisait écrire une fausse alerte dans le journal (relevé le 08/10/2026).
     * FALSE veut donc dire : le fichier est TOUJOURS là (verrou, droits).
     */
    public static function supprimer(?string $cheminRelatif): bool
    {
        if ($cheminRelatif === null || $cheminRelatif === '') {
            return true;
        }
        $absolu = self::cheminAbsolu($cheminRelatif);
        if ($absolu === null) {
            return true;
        }
        if (!is_file($absolu)) {
            return true;
        }
        return @unlink($absolu) && !is_file($absolu);
    }

    /**
     * Supprime le dossier entier d'un élève (`runtime/documents/eleve-<id>/`).
     *
     * POURQUOI LE DOSSIER ENTIER, ET PAS SEULEMENT LES FICHIERS CONNUS : quand on
     * supprime un élève, le droit à l'effacement porte sur ses documents, pas sur
     * « les fichiers dont la ligne en base a bien voulu nous parler ». Un fichier
     * resté là sans ligne (import interrompu, base restaurée d'un autre poste) serait
     * invisible dans l'application et ne partirait jamais.
     *
     * @return bool TRUE quand il ne reste plus rien sur le disque.
     */
    public static function supprimerDossierEleve(?int $eleveId): bool
    {
        // Jamais le dossier `_sans-eleve` : il ne désigne personne.
        if ($eleveId === null || $eleveId <= 0) {
            return true;
        }
        $dossier = self::dossierEleve($eleveId);
        if (!is_dir($dossier)) {
            return true;
        }
        // Garde-fou : on ne supprime QUE sous la racine des documents. Sans lui, un
        // `CALULIS_DOCUMENTS_DIR` mal posé ferait disparaître un dossier étranger.
        $racineReelle = realpath(self::racine());
        $dossierReel = realpath($dossier);
        if ($racineReelle === false || $dossierReel === false
            || !self::sousRacine($dossierReel, $racineReelle)) {
            return false;
        }

        $tout = true;
        foreach (scandir($dossierReel) ?: [] as $entree) {
            if ($entree === '.' || $entree === '..') {
                continue;
            }
            $chemin = $dossierReel . '/' . $entree;
            if (is_dir($chemin)) {
                // Structure inattendue : on ne descend pas en récursif sur un dossier
                // qu'on n'a pas créé. On le signale par un échec, l'appelant le dit.
                $tout = false;
                continue;
            }
            if (!@unlink($chemin) || is_file($chemin)) {
                $tout = false;
            }
        }
        if ($tout && !@rmdir($dossierReel)) {
            $tout = false;
        }
        return $tout && !is_dir($dossier);
    }

    /**
     * Chemin absolu d'un chemin relatif stocké en base, ou null si le chemin sort
     * de la racine des documents (défense contre un `..` écrit en base).
     */
    public static function cheminAbsolu(string $cheminRelatif): ?string
    {
        $propre = str_replace('\\', '/', trim($cheminRelatif));
        if ($propre === '' || str_starts_with($propre, '/') || preg_match('#(^|/)\.\.(/|$)#', $propre)) {
            return null;
        }
        $racineReelle = realpath(self::racine());
        $absolu = self::racine() . '/' . $propre;
        $dossierReel = realpath(dirname($absolu));
        if ($racineReelle === false || $dossierReel === false) {
            return null;
        }
        // La comparaison porte sur un dossier ENTIER : sans le séparateur final, un
        // dossier frère « documents-xxx » passerait pour la racine (relevé le 08/10/2026).
        if (!self::sousRacine($dossierReel, $racineReelle)) {
            return null;
        }
        return $absolu;
    }

    /**
     * Vrai si `$cheminReel` désigne la racine des documents ou un chemin SOUS elle.
     *
     * POURQUOI CETTE FONCTION EXISTE — défaut trouvé au banc Windows le 08/10/2026, et il
     * rendait le module Documents inutilisable : `realpath()` rend des ANTI-SLASH sur
     * Windows, si bien que `str_starts_with($dossier . '/', $racine . '/')` ne pouvait
     * JAMAIS être vrai (le caractère après « documents » est « \ » d'un côté, « / » de
     * l'autre). Sur un poste Windows, le fichier d'un document n'était donc ni SERVI, ni
     * SUPPRIMÉ, ni ARCHIVÉ (l'archive ne contenait que son index), et le dossier d'un élève
     * supprimé restait sur le disque. Les tests hors VM ne pouvaient pas le voir : sous
     * Linux, `realpath()` rend des slashs.
     *
     * Le séparateur est donc normalisé AVANT de comparer, et le dossier est comparé entier
     * (sans le séparateur final, un dossier frère « documents-xxx » passerait pour la racine).
     */
    public static function sousRacine(string $cheminReel, string $racineReelle): bool
    {
        $chemin = rtrim(str_replace('\\', '/', $cheminReel), '/');
        $racine = rtrim(str_replace('\\', '/', $racineReelle), '/');
        if ($chemin === '' || $racine === '') {
            return false;
        }
        return $chemin === $racine || str_starts_with($chemin . '/', $racine . '/');
    }

    /** Nom de fichier unique sur le disque : ni accent, ni espace, ni collision. */
    public static function nomStocke(int $documentId, string $extension): string
    {
        $ext = preg_replace('/[^a-z0-9]/', '', strtolower($extension)) ?? '';
        $suffixe = bin2hex(random_bytes(4));
        return 'doc-' . $documentId . '-' . $suffixe . ($ext !== '' ? '.' . $ext : '');
    }

    /** Nom d'origine nettoyé (gardé pour l'affichage et le téléchargement). */
    public static function nomOriginalSain(string $nom): string
    {
        $nom = str_replace('\\', '/', $nom);
        // On ne garde que le DERNIER segment : « ../../evasion.pdf » devient
        // « evasion.pdf ». `substr(strrpos('/'.$nom, '/'))` laissait la barre
        // oblique initiale — payé par le test du 08/10/2026.
        $position = strrpos($nom, '/');
        if ($position !== false) {
            $nom = substr($nom, $position + 1);
        }
        $nom = preg_replace('/[\x00-\x1F\x7F]/u', '', $nom) ?? '';
        $nom = trim($nom);
        if ($nom === '' || $nom === '.' || $nom === '..') {
            $nom = 'document';
        }
        return self::tronquer($nom, 300);
    }

    /**
     * Tronque un texte sans dépendre de l'extension mbstring — absente du PHP de
     * développement de ce poste (constaté le 08/10/2026), alors qu'elle est présente
     * dans le runtime livré. Le repli ne coupe jamais un caractère UTF-8 en deux.
     */
    public static function tronquer(string $texte, int $max): string
    {
        if (function_exists('mb_substr')) {
            return mb_substr($texte, 0, $max);
        }
        $coupe = substr($texte, 0, $max);
        // Un caractère UTF-8 tronqué laisse des octets de continuation (0x80-0xBF) :
        // on les retire pour ne pas écrire une séquence invalide en base.
        return (string)preg_replace('/[\x80-\xBF]+$/', '', $coupe);
    }

    /** Taille lisible, pour les messages (« 4,2 Mo »). */    public static function tailleLisible(int $octets): string
    {
        if ($octets >= 1048576) {
            return number_format($octets / 1048576, 1, ',', ' ') . ' Mo';
        }
        if ($octets >= 1024) {
            return number_format($octets / 1024, 0, ',', ' ') . ' Ko';
        }
        return $octets . ' o';
    }

    private static function typeMimeDetecte(string $chemin): ?string
    {
        if (!function_exists('finfo_open')) {
            return null;
        }
        $finfo = @finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo === false) {
            return null;
        }
        $mime = @finfo_file($finfo, $chemin);
        finfo_close($finfo);
        return is_string($mime) && $mime !== '' ? strtolower($mime) : null;
    }

    private static function messageErreur(int $code): string
    {
        return match ($code) {
            UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'Le fichier dépasse la taille maximale autorisée par le serveur.',
            UPLOAD_ERR_PARTIAL    => "Le fichier n'a été reçu qu'en partie. Recommencez.",
            UPLOAD_ERR_NO_FILE    => 'Aucun fichier reçu. Choisissez un document et recommencez.',
            UPLOAD_ERR_NO_TMP_DIR => 'Le dossier temporaire du serveur est introuvable.',
            UPLOAD_ERR_CANT_WRITE => "Le serveur n'a pas pu écrire le fichier sur le disque.",
            UPLOAD_ERR_EXTENSION  => 'Le téléversement a été interrompu par une extension PHP.',
            default               => 'Le fichier n\'a pas pu être reçu.',
        };
    }
}
