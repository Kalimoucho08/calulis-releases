<?php
/** Calulis — Modèle « Notes de suivi »
 *
 *  Le suivi ne concerne QUE des élèves : `eleve_id` est obligatoire (il est NOT NULL en base).
 *  Une note = un élève, une date, un type et un texte libre.
 *  Monoposte / monoutilisateur : la colonne `auteur` existe mais n'est plus saisie.
 *
 *  Toutes les requêtes sont préparées (PDO, émulation désactivée) et filtrées par année scolaire.
 */

require_once __DIR__ . '/../config.php';

class NoteSuivi {

    /** Types admis (le prototype et la page s'appuient sur cette liste) */
    public const TYPES = ['observation', 'objectif', 'reussite', 'alerte', 'action'];

    private static function pdo(): PDO {
        return getDB();
    }

    /**
     * Liste des notes, filtrée.
     * @param int|null $anneeId Année scolaire active (null = toutes les années, cas rare)
     * @param array $filtres eleve_id, type, du, au
     */
    public static function all(?int $anneeId, array $filtres = []): array {
        $sql = "SELECT n.id, n.eleve_id, n.date_note, n.type, n.contenu, n.annee_scolaire_id,
                       e.nom AS eleve_nom, e.prenom AS eleve_prenom
                  FROM notes_suivi n
             LEFT JOIN eleves e ON e.id = n.eleve_id
                 WHERE 1 = 1";
        $params = [];

        if ($anneeId) {
            $sql .= " AND n.annee_scolaire_id = :annee_id";
            $params['annee_id'] = $anneeId;
        }
        if (!empty($filtres['eleve_id'])) {
            $sql .= " AND n.eleve_id = :eleve_id";
            $params['eleve_id'] = (int)$filtres['eleve_id'];
        }
        if (!empty($filtres['type']) && in_array($filtres['type'], self::TYPES, true)) {
            $sql .= " AND n.type = :type";
            $params['type'] = $filtres['type'];
        }
        if (!empty($filtres['du'])) {
            $sql .= " AND n.date_note >= :du";
            $params['du'] = $filtres['du'];
        }
        if (!empty($filtres['au'])) {
            $sql .= " AND n.date_note <= :au";
            $params['au'] = $filtres['au'];
        }

        $sql .= " ORDER BY n.date_note DESC, n.id DESC";

        $stmt = self::pdo()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Une note par son identifiant (null si absente) */
    public static function find(int $id): ?array {
        $stmt = self::pdo()->prepare(
            "SELECT n.id, n.eleve_id, n.date_note, n.type, n.contenu, n.annee_scolaire_id,
                    e.nom AS eleve_nom, e.prenom AS eleve_prenom
               FROM notes_suivi n
          LEFT JOIN eleves e ON e.id = n.eleve_id
              WHERE n.id = :id"
        );
        $stmt->execute(['id' => $id]);
        $note = $stmt->fetch(PDO::FETCH_ASSOC);
        return $note ?: null;
    }

    /** Crée une note et retourne son identifiant */
    public static function create(array $data, ?int $anneeId): int {
        $propre = self::_valider($data, true);

        $stmt = self::pdo()->prepare(
            "INSERT INTO notes_suivi (annee_scolaire_id, eleve_id, date_note, type, contenu)
             VALUES (:annee_id, :eleve_id, :date_note, :type, :contenu)"
        );
        $stmt->execute([
            'annee_id'  => $anneeId,
            'eleve_id'  => $propre['eleve_id'],
            'date_note' => $propre['date_note'],
            'type'      => $propre['type'],
            'contenu'   => $propre['contenu'],
        ]);
        return (int)self::pdo()->lastInsertId();
    }

    /** Met à jour une note existante */
    public static function update(int $id, array $data): bool {
        $propre = self::_valider($data, false);

        $sets = [];
        $params = ['id' => $id];
        foreach (['eleve_id', 'date_note', 'type', 'contenu'] as $colonne) {
            if (array_key_exists($colonne, $propre)) {
                $sets[] = "$colonne = :$colonne";
                $params[$colonne] = $propre[$colonne];
            }
        }
        if (!$sets) {
            return false;
        }

        $stmt = self::pdo()->prepare(
            "UPDATE notes_suivi SET " . implode(', ', $sets) . " WHERE id = :id"
        );
        $stmt->execute($params);
        return $stmt->rowCount() >= 0; // 0 ligne modifiée = valeurs identiques, ce n'est pas une erreur
    }

    /** Supprime une note */
    public static function delete(int $id): bool {
        $stmt = self::pdo()->prepare("DELETE FROM notes_suivi WHERE id = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->rowCount() > 0;
    }

    /** Champs autorisés, contrôlés et normalisés */
    private static function _valider(array $data, bool $creation): array {
        $propre = [];

        if ($creation || array_key_exists('eleve_id', $data)) {
            $eleveId = (int)($data['eleve_id'] ?? 0);
            if ($eleveId <= 0) {
                throw new InvalidArgumentException('La note doit concerner un élève');
            }
            $propre['eleve_id'] = $eleveId;
        }

        if ($creation || array_key_exists('contenu', $data)) {
            $contenu = trim((string)($data['contenu'] ?? ''));
            if ($contenu === '') {
                throw new InvalidArgumentException('La note est vide');
            }
            $propre['contenu'] = $contenu;
        }

        if ($creation || array_key_exists('type', $data)) {
            $type = (string)($data['type'] ?? 'observation');
            if (!in_array($type, self::TYPES, true)) {
                throw new InvalidArgumentException('Type de note inconnu : ' . $type);
            }
            $propre['type'] = $type;
        }

        if ($creation || array_key_exists('date_note', $data)) {
            $date = trim((string)($data['date_note'] ?? ''));
            if ($date === '') {
                $date = date('Y-m-d');
            }
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
                throw new InvalidArgumentException('Date invalide : ' . $date);
            }
            $propre['date_note'] = $date;
        }

        return $propre;
    }
}
