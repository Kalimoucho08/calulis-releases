<?php
/**
 * Calulis — Configuration base de données
 * Prod : lit les variables d'environnement
 * Local : MySQL 8.0 (TCP 127.0.0.1:3307)
 * Cible = MySQL 8.0 (binaire embarqué du stack portable).
 */

// Sécurité : ne pas exposer les erreurs en production
if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1', 'localhost'], true)) {
    @ini_set('display_errors', '0');
    @ini_set('log_errors', '1');
}

// Détection automatique de l'environnement
$isProd = strpos($_SERVER['HTTP_HOST'] ?? '', 'infinityfree.com') !== false
       || strpos($_SERVER['HTTP_HOST'] ?? '', 'free.nf') !== false
       || getenv('CALULIS_ENV') === 'production';

if ($isProd) {
    $dbHost = getenv('CALULIS_DB_HOST');
    $dbName = getenv('CALULIS_DB_NAME');
    $dbUser = getenv('CALULIS_DB_USER');
    $dbPass = getenv('CALULIS_DB_PASS');
    // Le port fait partie de l'environnement : le MySQL embarqué du paquet
    // portable écoute sur 3307, pas sur le 3306 par défaut. Sans cette ligne,
    // passer en production (CALULIS_ENV=production, posé par le lanceur) ferait
    // échouer TOUTE connexion à la base locale.
    $dbPort = getenv('CALULIS_DB_PORT') ?: '3306';
    if (!$dbHost || !$dbName || !$dbUser) {
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Configuration base de données manquante. Définir CALULIS_DB_HOST, CALULIS_DB_NAME, CALULIS_DB_USER.']);
        exit;
    }
    $dsn = "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4";
} else {
    // Mode développement — cible MySQL 8.0 (binaire embarqué du stack portable, port 3307)
    $dbHost = getenv('CALULIS_DB_HOST') ?: '127.0.0.1';
    $dbName = getenv('CALULIS_DB_NAME') ?: 'calulis';
    $dbUser = getenv('CALULIS_DB_USER') ?: 'calulis';
    // Un mot de passe VIDE est une valeur légitime : ne pas le confondre avec
    // « variable non définie » (un `?:` remplaçait un mot de passe vide par
    // « calulis », changeant silencieusement les identifiants).
    $dbPass = getenv('CALULIS_DB_PASS');
    if ($dbPass === false) { $dbPass = 'calulis'; }   // ggignore - mot de passe de demonstration, public et documente (remplace par un mot de passe aleatoire par installation depuis la 1.15.1)
    $dbPort = getenv('CALULIS_DB_PORT') ?: '3307';
    $dsn = "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4";
}

define('USE_MYSQL', true);
define('DB_DSN', $dsn);
define('DB_USER', $dbUser);
define('DB_PASS', $dbPass);

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(DB_DSN, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            // Borne le temps de connexion. Sans cette limite, une base qui ne
            // répond pas (au lieu de refuser) fige la requête : mesuré 27 s par
            // requête sur cette machine de développement — l'application paraît
            // gelée au lieu d'afficher « erreur de base de données ».
            PDO::ATTR_TIMEOUT => 5,
        ]);
    }
    return $pdo;
}

function jsonResponse(mixed $data, int $code = 200): never {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    // Une réponse nominative ne doit pas rester dans le cache du navigateur : le poste
    // peut être partagé, et le profil du navigateur survit à la fermeture de Calulis
    // (constat J de la revue RGPD du 08/10/2026). Une seule porte de sortie JSON, donc
    // un seul en-tête à poser.
    header('Cache-Control: no-store, private');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Journalise une erreur Calulis dans runtime/logs/php-error.log.
 *
 * Défini ICI (socle commun) et non dans router.php : en développement
 * (dev-router.php) la fonction n'existait pas, et le moindre appel — y compris
 * depuis un `catch` qui voulait justement expliquer une panne — levait
 * « Call to undefined function calulis_log_error() », masquant l'erreur réelle.
 */
if (!function_exists('calulis_log_error')) {
    function calulis_log_error(string $msg): void {
        // TOUT le journal passe par ici : c'est donc le seul endroit à assainir pour
        // qu'aucune VALEUR d'élève ne s'y écrive. MySQL cite la valeur fautive entre
        // apostrophes ou guillemets (« Duplicate entry 'DUPONT Jean' »,
        // « Incorrect string value: '…' ») ; un message d'exception peut donc en
        // contenir, quelle que soit la couche qui l'a levée (constat C de la revue RGPD
        // du 08/10/2026). Le journal garde de quoi diagnostiquer, jamais la donnée.
        // Repérage GREEDY, d'un guillemet ouvrant au DERNIER guillemet de la ligne : MySQL
        // cite « 'D'Angelo' », et un motif qui s'arrête au premier guillemet laissait
        // « Angelo » en clair dans le journal (revue de sécurité du 08/10/2026). Sur un
        // journal, mieux vaut masquer un peu trop que laisser passer un nom.
        $msg = (string)preg_replace(["/'.*'/", '/".*"/'], ["'…'", '"…"'], $msg);
        $dir = getenv('CALULIS_LOG_DIR') ?: (__DIR__ . '/../../runtime/logs');
        // 2 Mo, une seule génération conservée : sans plafond, le journal grandissait
        // sans fin sur le poste de l'utilisateur (constat F de la revue RGPD du
        // 08/10/2026). Au-delà, le fichier courant devient « php-error.log.1 ».
        $max = 2097152;
        $ok = false;
        if (is_dir($dir) || @mkdir($dir, 0755, true)) {
            $fichier = $dir . '/php-error.log';
            $taille = @filesize($fichier);
            if ($taille !== false && $taille > $max) {
                @rename($fichier, $fichier . '.1');
            }
            $ok = @file_put_contents($fichier,
                '[' . date('c') . '] ' . $msg . PHP_EOL, FILE_APPEND) !== false;
        }
        if (!$ok) { @error_log('calulis: ' . $msg); }
    }
}

function jsonError(string $message, int $code = 400): never {
    jsonResponse(['error' => $message], $code);
}

/**
 * Vrai dans un déploiement HÉBERGÉ (site distant), faux dans le paquet portable.
 *
 * Le paquet portable est reconnu par CALULIS_PORTABLE=1 (posé par le lanceur) :
 * chez lui, l'utilisateur est seul devant son poste, et les fonctions
 * « sauvegarde / restauration » lui appartiennent.
 *
 * ⚠️ Ne PAS se contenter de CALULIS_ENV : la seule chose qui le pose est le
 * lanceur, qui pose AUSSI CALULIS_PORTABLE=1 — la garde serait alors toujours
 * fausse, y compris sur le site public (défaut trouvé par la revue du
 * 05/10/2026 : le jeton X-Calulis-App est public, n'importe qui aurait pu
 * téléverser un .sql et remplacer la base en ligne). On reprend donc la même
 * détection d'hôte que la branche de production ci-dessus.
 */
function calulis_est_heberge(): bool {
    if (getenv('CALULIS_PORTABLE') === '1') {
        return false;
    }
    $hote = $_SERVER['HTTP_HOST'] ?? '';
    return strpos($hote, 'infinityfree.com') !== false
        || strpos($hote, 'free.nf') !== false
        || getenv('CALULIS_ENV') === 'production';
}

/**
 * Compte les données visibles par l'utilisateur : sert à DIRE ce qui va être
 * remplacé avant de le remplacer (jamais de remplacement en aveugle).
 * @return array<string,int|null>
 */
function calulis_compter_base(PDO $pdo): array {
    $comptes = [];
    foreach (['eleves', 'adultes', 'creneaux', 'classes', 'etablissements'] as $table) {
        try {
            $comptes[$table] = (int) $pdo->query("SELECT COUNT(*) FROM `$table`")->fetchColumn();
        } catch (\Throwable $e) {
            $comptes[$table] = null;
        }
    }
    return $comptes;
}

/** Résumé en français des comptes (« 12 élèves, 15 adultes, 12 553 créneaux »). */
function calulis_resume_comptes(array $comptes): string {
    $libelles = [
        'eleves' => 'élèves', 'adultes' => 'adultes', 'creneaux' => 'créneaux',
        'classes' => 'classes', 'etablissements' => 'établissements',
    ];
    $parts = [];
    foreach ($libelles as $cle => $libelle) {
        if (($comptes[$cle] ?? null) !== null) {
            $parts[] = number_format((int) $comptes[$cle], 0, ',', ' ') . ' ' . $libelle;
        }
    }
    return $parts ? implode(', ', $parts) : 'aucune donnée lisible';
}

// ─────────────────────────────────────────────────────────────
// Helpers partagés : erreurs TOUJOURS journalisées + lisibles,
// et troncature défensive des champs varchar courts (anti
// « data too long » qui donnait des erreurs de sauvegarde).
// ─────────────────────────────────────────────────────────────

/** Limites varchar connues (colonnes courtes du schéma) */
const CALULIS_VARCHAR_LIMITS = [
    'ine' => 15, 'classe' => 20, 'niveau_scolaire' => 20, 'aesh_type' => 10,
    'aesh_heures' => 20, 'groupe' => 50, 'temps_scolarisation' => 30,
    'telephone' => 20, 'telephone_urgence' => 20, 'telephone2' => 20,
    'uai' => 8, 'code_postal' => 10, 'departement' => 50,
    'numero_dossier_mdph' => 50, 'numero_dossier' => 50,
    'ase_structure_telephone' => 20, 'ase_referent_telephone' => 20,
    'fonction' => 50, 'role' => 50, 'civilite' => 10, 'lien' => 50,
    'specialite' => 100, 'pec_specialite' => 50, 'pec_organisme' => 50,
    'pec_frequence' => 30, 'pec_lieu' => 50, 'pec_duree' => 20,
    // Oubliées jusqu'à la revue de sécurité du 08/10/2026 : une valeur trop longue
    // envoyée directement à l'API n'était pas tronquée (erreur MySQL ou troncature muette
    // selon le sql_mode).
    'reference_externe' => 500, 'version' => 20, 'statut' => 30,
];

/**
 * Tronque un texte sans dépendre de mbstring : elle est ABSENTE du PHP de développement de
 * ce poste (constaté le 08/10/2026), et `calulis_truncate()` l'appelait sans repli — une
 * simple valeur accentuée dans une colonne courte faisait échouer la requête en 500.
 * C'est la SEULE implémentation : `Stockage::tronquer()` et le modèle des types de
 * documents s'appuient dessus (une règle, un endroit).
 */
if (!function_exists('calulis_substr')) {
    function calulis_substr(string $texte, int $max): string {
        if (function_exists('mb_substr')) {
            return mb_substr($texte, 0, $max);
        }
        // On retire un éventuel octet de continuation UTF-8 coupé en deux.
        return (string)preg_replace('/[\x80-\xBF]+$/', '', substr($texte, 0, $max));
    }
}

/** Tronque les champs varchar courts (défensif — jamais d'erreur « data too long ») */
function calulis_truncate(array $data): array {
    foreach (CALULIS_VARCHAR_LIMITS as $f => $len) {
        if (array_key_exists($f, $data) && $data[$f] !== null && $data[$f] !== '') {
            $data[$f] = calulis_substr((string)$data[$f], $len);
        }
    }
    return $data;
}

/** Journalise une erreur et répond un message propre (jamais de SQL brut) */
function calulis_handle_error(\Throwable $e): never {
    if (function_exists('calulis_log_error')) {
        calulis_log_error('EXCEPTION ' . get_class($e) . ': ' . $e->getMessage()
            . ' @ ' . $e->getFile() . ':' . $e->getLine());
    } else {
        @error_log('[calulis] ' . get_class($e) . ': ' . $e->getMessage());
    }
    if ($e instanceof \PDOException) {
        jsonError("Les données n'ont pas pu être enregistrées (erreur de base de données). Vérifie les champs saisis puis réessaie. Si le problème persiste, redémarre l'application.", 500);
    }
    jsonError('Erreur technique. Le détail est enregistré dans les logs (bouton « Ouvrir les logs » du lanceur).', 500);
}

/**
 * Auto-réparation du schéma DB : applique les migrations en attente une seule fois par processus.
 *
 * Appelée au démarrage (router.php en prod / dev-router.php en dev), elle garantit que les tables
 * créées par migration (classe_enseignants, groupes, eleve_groupes) existent sur TOUTE base —
 * perso, démo ou vierge, existante ou fraîche — quel que soit son état de schéma au chargement.
 * C'est le mécanisme qui réaligne TOUTES les bases sur le même schéma canonique.
 *
 * Idempotent : si tout est déjà à jour (aucune migration en attente), c'est un simple statut sans effet.
 * En cas d'erreur, on journalise et on continue (ne bloque pas l'API).
 */
function calulis_auto_migrate(): void {
    static $ran = false;
    if ($ran) { return; }
    $ran = true;
    try {
        $migrationFile = __DIR__ . '/models/Migration.php';
        if (!file_exists($migrationFile)) { return; }
        require_once $migrationFile;
        (new Migration())->run();
    } catch (\Throwable $e) {
        @error_log('[calulis] auto-migration: ' . $e->getMessage());
    }
}
