<?php
/**
 * Calulis — Point d'entrée API / Router CLI server
 * Utilisé comme router : php -S localhost:8081 api/router.php
 * Laisse passer les fichiers statiques, route les /api/* vers les controllers
 */
// Serveur intégré : servir les fichiers statiques
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (php_sapi_name() === 'cli-server') {
    $filePath = __DIR__ . '/..' . $uri;
    if ($uri === '/' && is_dir(__DIR__ . '/..')) {
        return false; // index.html automatique
    }
    if (is_file($filePath)) {
        return false; // fichier statique (JS, CSS, etc.)
    }
}

require_once __DIR__ . '/config.php';

// ─────────────────────────────────────────────────────────────────
// Erreurs TOUJOURS lisibles : réponse JSON + log fichier pour le support.
// Sans ça, un fatal PHP répond 500 avec un corps non-JSON et le frontend
// affiche le statusText HTTP brut (ex. « Internal Server Error »).
//
// calulis_log_error() est définie dans config.php (socle commun, donc aussi
// disponible en développement) : ne pas la redéfinir ici.
// ─────────────────────────────────────────────────────────────────

// Le message d'erreur envoyé au navigateur ne porte AUCUN détail brut : celui-ci peut
// citer une valeur d'élève (« Duplicate entry 'DUPONT Jean' »), et l'interface le
// conserve puis le recopie dans le signalement de bug (constat C de la revue RGPD du
// 08/10/2026). Le détail complet reste dans le journal, sur le poste. Un paramètre
// unique rend la fuite impossible : il n'y a plus rien à passer.
function calulis_erreur_json(string $message): void
{
    if (headers_sent()) { return; }
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => $message], JSON_UNESCAPED_UNICODE);
}

// Auto-réparation du schéma : applique les migrations en attente une fois par processus.
// Voir calulis_auto_migrate() dans config.php (partagé avec dev-router.php).
calulis_auto_migrate();

// 1) Exceptions non rattrapées (PDO, Error, TypeError…) → JSON + log
set_exception_handler(function (Throwable $e): void {
    calulis_log_error('EXCEPTION ' . get_class($e) . ': ' . $e->getMessage()
        . ' @ ' . $e->getFile() . ':' . $e->getLine() . "
" . $e->getTraceAsString());
    calulis_erreur_json('Erreur technique. Le détail est enregistré dans les logs (bouton « Ouvrir les logs » du lanceur).');
    exit(1);
});

// 2) Erreurs fatales (fonction inconnue, extension manquante…) → JSON + log
register_shutdown_function(function (): void {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        calulis_log_error('FATAL ' . $err['message'] . ' @ ' . $err['file'] . ':' . $err['line']);
        calulis_erreur_json('Erreur technique du serveur. Le détail est enregistré dans les logs (bouton « Ouvrir les logs » du lanceur).');
    }
});

// ── CORS : UNE seule origine autorisée, celle que sert le paquet portable.
//
// Avant le 05/10/2026, tout `http://127.0.0.1:<n'importe quel port>` était reflété :
// une page ouverte dans le même navigateur sur un autre port local (par exemple un
// site servi par un outil quelconque) pouvait donc lire les réponses de l'API Calulis
// — qui manipule des données nominatives d'élèves, sans aucun mot de passe.
//
// L'application elle-même est servie en same-origin (ses appels sont relatifs) :
// elle n'a besoin d'aucun en-tête CORS. Une origine non listée n'en reçoit aucun,
// et le navigateur bloque la lecture.
$calulisOriginesAutorisees = ['http://127.0.0.1:8088'];
$calulisOrigin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (in_array($calulisOrigin, $calulisOriginesAutorisees, true)) {
    header('Access-Control-Allow-Origin: ' . $calulisOrigin);
    header('Vary: Origin');
}
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Calulis-App');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

// ── Contrôle de l'HÔTE : le rempart contre le « DNS rebinding » ───────────────
//
// Vérifier que l'appelant vient de la boucle locale (`REMOTE_ADDR`, dans config.php)
// NE SUFFIT PAS. Une page web quelconque dont le domaine résout vers 127.0.0.1
// atteint Calulis avec l'adresse de la boucle locale, et le jeton anti-CSRF posé
// plus bas n'est que la constante « 1 » — publique dans api.js. Dans ce scénario,
// le navigateur considère la requête comme same-origin : ni CORS ni préflight ne
// s'y opposent, et une page visitée pourrait lire des données nominatives d'élèves.
//
// Le seul élément que l'attaquant ne peut PAS falsifier est le nom qu'il a fait
// résoudre : on refuse donc tout Hôte qui n'est pas la boucle locale (le port est
// libre — le serveur de développement et les tests en changent).
$calulisHote = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
$calulisNomHote = (string)preg_replace('/:\d+$/', '', $calulisHote);
if ($calulisHote !== '' && !in_array($calulisNomHote, ['127.0.0.1', 'localhost', '[::1]', '::1'], true)) {
    calulis_log_error('Requête refusée : hôte non local (' . $calulisNomHote . ')');
    jsonError('Requête refusée : Calulis ne répond qu\'à cette machine.', 403);
}
// Même règle pour l'origine déclarée, quand il y en a une.
if ($calulisOrigin !== '') {
    $calulisNomOrigine = strtolower((string)(parse_url($calulisOrigin, PHP_URL_HOST) ?? ''));
    if (!in_array($calulisNomOrigine, ['127.0.0.1', 'localhost', '[::1]', '::1'], true)) {
        jsonError('Requête refusée : origine non locale.', 403);
    }
}

// ── Anti-CSRF : l'API n'accepte que les requêtes portant le jeton interne
// (posé par l'app via le wrapper fetch global). Les requêtes cross-site ne
// peuvent pas poser d'en-tête custom sans préflight (refusé ci-dessus).
// On exempte /api/migrate (et /api/migrate/seed) : ces endpoints sont appelés par le
// lanceur (MigrationService) pendant la mise à jour, SANS l'en-tête X-Calulis-App.
// Ils sont idempotents (CREATE TABLE IF NOT EXISTS / statut) et non destructeurs de données.
// En prod (Caddy) l'URL peut être réécrite en /api/router.php?r=/api/xxx → on vérifie le chemin ET le param r.
$reqPath = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?? '';
$isMigrateRoute = (strpos($reqPath, '/api/migrate') === 0)
    || (strpos($_GET['r'] ?? '', '/api/migrate') === 0);
if (($_SERVER['HTTP_X_CALULIS_APP'] ?? '') !== '1' && !$isMigrateRoute) {
    jsonError('Requête refusée (jeton anti-CSRF manquant). Rechargez l\'application.', 403);
}

// Router les requêtes /api/* vers les controllers
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = rtrim($uri, '/');

if (strpos($uri, '/api/') === false) {
    if (php_sapi_name() === 'cli-server') return false;
    jsonError('Route non trouvée', 404);
}

$parts = explode('/', trim($uri, '/'));
$resource = $parts[count($parts) - 1] ?? '';
$resource = str_replace('.php', '', $resource);

$controllerFile = __DIR__ . '/controllers/' . $resource . '.php';
if (file_exists($controllerFile)) {
    // 2e barrière : un contrôleur marqué « développement » n'est JAMAIS exécuté
    // en production. Il est aussi retiré du paquet à la construction
    // (scripts/build-portable.ps1) : si on le retrouve ici, c'est qu'il a été
    // recopié à la main ou livré par erreur — on refuse.
    // Le marqueur vit dans le fichier lui-même : une seule source de la liste.
    if (getenv('CALULIS_ENV') === 'production') {
        $tete = (string) @file_get_contents($controllerFile, false, null, 0, 2048);
        if (str_contains($tete, '@calulis-controleur-dev')) {
            calulis_log_error('Contrôleur de développement refusé en production : ' . $resource);
            jsonError('Route non trouvée : ' . $resource, 404);
        }
    }
    require_once $controllerFile;
} else {
    jsonError('Route non trouvée : ' . $resource, 404);
}
