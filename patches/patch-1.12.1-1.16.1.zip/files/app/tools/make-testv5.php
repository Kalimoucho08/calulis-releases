<?php
/**
 * Calulis — Genere calulis-testv5.sql (base complete, autonome)
 *
 * Usage : php tools/make-testv5.php
 *
 * TOUT est ici : structure + donnees, sans heriter d'aucun fichier externe.
 * Les IDs sont fixes et previsibles.
 */
require_once __DIR__ . '/../api/config.php';

$pdo = getDB();
$isMySQL = USE_MYSQL;
$ai = $isMySQL ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
$engine = $isMySQL ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' : '';
$ts = $isMySQL ? 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP' : 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP';
$now = $isMySQL ? 'CURRENT_TIMESTAMP' : "CURRENT_TIMESTAMP";
$autoIncrement = $isMySQL ? 'AUTO_INCREMENT=100' : '';

// ============================================================
// ETAPE 1 : Nettoyer et recréer les tables
// ============================================================
echo "-> Tables...\n";

$pdo->exec('SET FOREIGN_KEY_CHECKS = 0');

// Supprimer toutes les tables existantes
$old = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
foreach ($old as $t) $pdo->exec("DROP TABLE IF EXISTS `$t`");

$sql = [];

$sql[] = "CREATE TABLE annees_scolaires (
    id $ai, nom VARCHAR(50) NOT NULL, date_debut DATE NOT NULL, date_fin DATE NOT NULL,
    est_active INTEGER DEFAULT 0
) $engine $autoIncrement";

$sql[] = "CREATE TABLE eleves (
    id $ai,
    nom VARCHAR(100) NOT NULL, prenom VARCHAR(100) NOT NULL, date_naissance DATE,
    classe VARCHAR(20), ulis INTEGER DEFAULT 0, groupe VARCHAR(50),
    niveau_scolaire VARCHAR(20), ecole_origine VARCHAR(100), date_entree_ulis DATE,
    suivi_par VARCHAR(100),
    aesh_type VARCHAR(10), aesh_nom VARCHAR(100), aesh_heures VARCHAR(20),
    aesh_mutualise_avec TEXT,
    pec_specialite VARCHAR(50), pec_organisme VARCHAR(50), pec_frequence VARCHAR(30),
    pec_lieu VARCHAR(50), pec_duree VARCHAR(20), pec_commentaires TEXT,
    transport VARCHAR(100), cantine INTEGER DEFAULT 0,
    telephone_urgence VARCHAR(20), telephone VARCHAR(20), email VARCHAR(100), adresse TEXT,
    allergies TEXT, regime_alimentaire VARCHAR(100), info_medicale TEXT,
    pai INTEGER DEFAULT 0, lien_pai VARCHAR(500), liens_mdph TEXT, remarques TEXT,
    notifications TEXT,
    mdph_ulis_date_fin DATE, mdph_ulis_statut VARCHAR(30),
    mdph_sessad_date_fin DATE, mdph_sessad_statut VARCHAR(30),
    mdph_aesh_date_fin DATE, mdph_aesh_statut VARCHAR(30),
    mdph_transport_date_fin DATE, mdph_transport_statut VARCHAR(30),
    mdph_autre_date_fin DATE, mdph_autre_statut VARCHAR(30), mdph_autre_libelle VARCHAR(100),
    ase_place INTEGER DEFAULT 0, ase_type_placement VARCHAR(50),
    ase_structure_nom VARCHAR(200), ase_structure_adresse TEXT, ase_structure_telephone VARCHAR(20),
    ase_referent_nom VARCHAR(100), ase_referent_telephone VARCHAR(20), ase_referent_email VARCHAR(100),
    ase_lien_ppe VARCHAR(500), ase_notes TEXT,
    etablissement_id INTEGER DEFAULT NULL, ecole_origine_id INTEGER DEFAULT NULL, classe_id INTEGER DEFAULT NULL,
    actif INTEGER DEFAULT 1, ordre INTEGER DEFAULT 0,
    created_at $ts, updated_at $ts
) $engine $autoIncrement";

$sql[] = "CREATE TABLE adultes (
    id $ai,
    nom VARCHAR(150) NOT NULL, prenom VARCHAR(100) NOT NULL DEFAULT '',
    role VARCHAR(50) DEFAULT '', fonction VARCHAR(50) DEFAULT '', telephone VARCHAR(20) DEFAULT '', email VARCHAR(100) DEFAULT '',
    etablissements TEXT, etablissement_id INTEGER DEFAULT NULL,
    commentaires TEXT, ordre INTEGER DEFAULT 0, actif INTEGER DEFAULT 1,
    created_at $ts, updated_at $ts
) $engine $autoIncrement";

$sql[] = "CREATE TABLE etablissements (
    id $ai,
    nom VARCHAR(200) NOT NULL, type VARCHAR(50) DEFAULT '',
    ville VARCHAR(100) DEFAULT '', adresse TEXT,
    telephone VARCHAR(20) DEFAULT '', telephone2 VARCHAR(20) DEFAULT '',
    email VARCHAR(100) DEFAULT '', email2 VARCHAR(100) DEFAULT '',
    description TEXT, actif INTEGER DEFAULT 1,
    created_at $ts, updated_at $ts
) $engine $autoIncrement";

$sql[] = "CREATE TABLE classes (
    id $ai,
    nom VARCHAR(100) NOT NULL,
    niveaux TEXT,
    enseignant_id INTEGER DEFAULT NULL,
    etablissement_id INTEGER DEFAULT NULL,
    actif INTEGER DEFAULT 1,
    created_at $ts, updated_at $ts" .
    ($isMySQL ? ", FOREIGN KEY (enseignant_id) REFERENCES adultes(id) ON DELETE SET NULL, FOREIGN KEY (etablissement_id) REFERENCES etablissements(id) ON DELETE SET NULL" : "") .
") $engine";

$sql[] = "CREATE TABLE adultes_etablissements (
    adulte_id INTEGER NOT NULL, etablissement_id INTEGER NOT NULL, role VARCHAR(50) DEFAULT '',
    PRIMARY KEY (adulte_id, etablissement_id)" .
    ($isMySQL ? ", FOREIGN KEY (adulte_id) REFERENCES adultes(id) ON DELETE CASCADE, FOREIGN KEY (etablissement_id) REFERENCES etablissements(id) ON DELETE CASCADE" : "") .
") $engine";

$sql[] = "CREATE TABLE semaines (
    id $ai, annee_scolaire_id INTEGER NOT NULL, numero INTEGER NOT NULL,
    date_debut DATE NOT NULL, date_fin DATE NOT NULL,
    est_vacances INTEGER DEFAULT 0, est_modifiee INTEGER DEFAULT 0, notes TEXT" .
    ($isMySQL ? ", FOREIGN KEY (annee_scolaire_id) REFERENCES annees_scolaires(id) ON DELETE CASCADE" : "") .
") $engine";

$sql[] = "CREATE TABLE creneaux (
    id $ai, eleve_id INTEGER NOT NULL, semaine_id INTEGER,
    jour VARCHAR(10) NOT NULL, heure_debut TIME NOT NULL, duree INTEGER DEFAULT 15,
    matiere VARCHAR(100), groupe VARCHAR(50), adulte VARCHAR(100),
    role_adulte VARCHAR(30), type VARCHAR(20) DEFAULT 'fixe',
    regroupement_type VARCHAR(30), couleur_override VARCHAR(7), commentaire TEXT,
    created_at $ts, updated_at $ts" .
    ($isMySQL ? ", FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE CASCADE, FOREIGN KEY (semaine_id) REFERENCES semaines(id) ON DELETE CASCADE" : "") .
") $engine";

$sql[] = "CREATE TABLE evenements (
    id $ai, annee_scolaire_id INTEGER NOT NULL, nom VARCHAR(200) NOT NULL,
    description TEXT, date_debut DATE, date_fin DATE, jour_semaine VARCHAR(10),
    est_recurrent INTEGER DEFAULT 0, recurrence_type VARCHAR(30), couleur VARCHAR(7),
    affecte_semaine_type INTEGER DEFAULT 0, created_at $ts" .
    ($isMySQL ? ", FOREIGN KEY (annee_scolaire_id) REFERENCES annees_scolaires(id) ON DELETE CASCADE" : "") .
") $engine";

$sql[] = "CREATE TABLE reunions (
    id $ai, type VARCHAR(50) NOT NULL, titre VARCHAR(200) NOT NULL,
    date_reunion DATE NOT NULL, heure TIME, duree INTEGER DEFAULT 60,
    eleve_id INTEGER, lieu VARCHAR(200), participants TEXT, statut VARCHAR(30) DEFAULT 'prevue',
    notes TEXT, documents_lies TEXT, created_at $ts, updated_at $ts" .
    ($isMySQL ? ", FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE SET NULL" : "") .
") $engine";

$sql[] = "CREATE TABLE taches (
    id $ai, description VARCHAR(500) NOT NULL, eleve_id INTEGER, reunion_id INTEGER,
    date_creation DATE NOT NULL DEFAULT (CURRENT_DATE), echeance DATE,
    priorite VARCHAR(20) DEFAULT 'moyenne', statut VARCHAR(30) DEFAULT 'a_faire',
    responsable VARCHAR(100), notes TEXT, created_at $ts, updated_at $ts" .
    ($isMySQL ? ", FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE SET NULL, FOREIGN KEY (reunion_id) REFERENCES reunions(id) ON DELETE SET NULL" : "") .
") $engine";

$sql[] = "CREATE TABLE notes_suivi (
    id $ai, eleve_id INTEGER NOT NULL, date_note DATE NOT NULL DEFAULT (CURRENT_DATE),
    auteur VARCHAR(100), type VARCHAR(30) DEFAULT 'observation', contenu TEXT NOT NULL,
    created_at $ts" .
    ($isMySQL ? ", FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE CASCADE" : "") .
") $engine";

$sql[] = "CREATE TABLE documents (
    id $ai, nom VARCHAR(300) NOT NULL, type VARCHAR(50) NOT NULL,
    eleve_id INTEGER, reunion_id INTEGER, date_document DATE, version VARCHAR(20),
    statut VARCHAR(30) DEFAULT 'en_attente', reference_externe VARCHAR(500), notes TEXT,
    created_at $ts, updated_at $ts" .
    ($isMySQL ? ", FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE SET NULL, FOREIGN KEY (reunion_id) REFERENCES reunions(id) ON DELETE SET NULL" : "") .
") $engine";

$sql[] = "CREATE TABLE periodes (
    id $ai, annee_scolaire_id INTEGER NOT NULL,
    nom VARCHAR(50) NOT NULL, date_debut DATE NOT NULL, date_fin DATE NOT NULL, ordre INTEGER DEFAULT 0" .
    ($isMySQL ? ", FOREIGN KEY (annee_scolaire_id) REFERENCES annees_scolaires(id) ON DELETE CASCADE" : "") .
") $engine";

$sql[] = "CREATE TABLE vacances (
    id $ai, nom VARCHAR(100) NOT NULL, date_debut DATE NOT NULL, date_fin DATE NOT NULL,
    zone VARCHAR(1), annee_scolaire_id INTEGER" .
    ($isMySQL ? ", FOREIGN KEY (annee_scolaire_id) REFERENCES annees_scolaires(id) ON DELETE CASCADE" : "") .
") $engine";

$sql[] = "CREATE TABLE parametres (
    cle VARCHAR(50) PRIMARY KEY, valeur TEXT NOT NULL, updated_at $ts
) $engine";

$sql[] = "CREATE TABLE pauses (
    id $ai, nom VARCHAR(100) NOT NULL, heure_debut TIME NOT NULL, heure_fin TIME NOT NULL,
    couleur VARCHAR(7) DEFAULT '#e0e0e0', actif INTEGER DEFAULT 1,
    jours VARCHAR(100) DEFAULT 'lundi,mardi,jeudi,vendredi', ordre INTEGER DEFAULT 0
) $engine";

$sql[] = "CREATE TABLE representants (
    id $ai, eleve_id INTEGER NOT NULL,
    nom VARCHAR(100) NOT NULL, prenom VARCHAR(100), lien VARCHAR(50),
    telephone VARCHAR(20), telephone_urgence INTEGER DEFAULT 0,
    email VARCHAR(100), adresse TEXT, ordre INTEGER DEFAULT 0,
    created_at $ts, updated_at $ts" .
    ($isMySQL ? ", FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE CASCADE" : "") .
") $engine";

$sql[] = "CREATE TABLE aesh_eleves (
    id $ai, eleve_id INTEGER NOT NULL, type VARCHAR(10) NOT NULL,
    nom VARCHAR(100), heures VARCHAR(20), mutualise_avec TEXT,
    ordre INTEGER DEFAULT 0, created_at $ts, updated_at $ts" .
    ($isMySQL ? ", FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE CASCADE" : "") .
") $engine";

$sql[] = "CREATE TABLE pec_eleves (
    id $ai, eleve_id INTEGER NOT NULL,
    specialite VARCHAR(50), organisme VARCHAR(50), frequence VARCHAR(30),
    lieu VARCHAR(50), duree VARCHAR(20), commentaires TEXT,
    ordre INTEGER DEFAULT 0, created_at $ts, updated_at $ts" .
    ($isMySQL ? ", FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE CASCADE" : "") .
") $engine";

foreach ($sql as $s) $pdo->exec($s);

$pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
echo "   OK " . count($sql) . " tables creees\n";

// ============================================================
// ETAPE 2 : Donnees
// ============================================================

// --- Annee scolaire ---
$pdo->exec("INSERT INTO annees_scolaires (id, nom, date_debut, date_fin, est_active) VALUES (1, '2026-2027', '2026-08-31', '2027-07-04', 1)");

// --- Periodes ---
$periodes = [
    [1, 'Periode 1', '2026-08-31', '2026-10-16', 1],
    [1, 'Periode 2', '2026-11-02', '2026-12-18', 2],
    [1, 'Periode 3', '2027-01-04', '2027-02-19', 3],
    [1, 'Periode 4', '2027-03-01', '2027-04-09', 4],
    [1, 'Periode 5', '2027-04-26', '2027-07-04', 5],
];
$stmt = $pdo->prepare('INSERT INTO periodes (annee_scolaire_id, nom, date_debut, date_fin, ordre) VALUES (?,?,?,?,?)');
foreach ($periodes as $p) $stmt->execute($p);

// --- Semaines (36) ---
$debut = new DateTime('2026-08-31');
for ($i = 1; $i <= 36; $i++) {
    $fin = clone $debut; $fin->modify('+4 days');
    $vacances = in_array($i, [7,8,16,17,25,26,33,34]) ? 1 : 0;
    $stmt = $pdo->prepare('INSERT INTO semaines (annee_scolaire_id, numero, date_debut, date_fin, est_vacances) VALUES (?,?,?,?,?)');
    $stmt->execute([1, $i, $debut->format('Y-m-d'), $fin->format('Y-m-d'), $vacances]);
    $debut->modify('+7 days');
}

// --- Vacances ---
$vacances = [
    ['Toussaint', '2026-10-17', '2026-11-01', 'A', 1],
    ['Noel', '2026-12-19', '2027-01-03', 'A', 1],
    ['Hiver', '2027-02-20', '2027-02-28', 'A', 1],
    ['Printemps', '2027-04-10', '2027-04-25', 'A', 1],
];
$stmt = $pdo->prepare('INSERT INTO vacances (nom, date_debut, date_fin, zone, annee_scolaire_id) VALUES (?,?,?,?,?)');
foreach ($vacances as $v) $stmt->execute($v);

// --- Parametres ---
$params = [
    ['couleurs_types', '{"ULIS":"#bbdefb","INCLUSION":"#c8e6c9","DECLOISONNEMENT":"#fff9c4","PEC":"#ffccbc","AUTRE":"#e0e0e0"}'],
    ['theme', '"clair"'],
    ['horaires', '{"debut":"08:30","fin":"16:30","duree_creneau":15}'],
    ['jours_affiches', '["lundi","mardi","jeudi","vendredi"]'],
    ['format_semaine', '"scolaire"'],
    ['types_reunions', '{"ESS":"#bbdefb","Équipe éducative":"#c8e6c9","RDV famille":"#fff9c4","Partenariat":"#ffccbc","Autre":"#e0e0e0"}'],
    ['notre_etablissement_id', '2'],
    ['zones_enseignement', '{"academie":"Poitiers","departement":"Charente","ville":"Ruffec"}'],
];
$stmt = $pdo->prepare('INSERT INTO parametres (cle, valeur) VALUES (?, ?)');
foreach ($params as $p) $stmt->execute($p);

// --- Pauses ---
$pauses = [
    ['Recreation', '10:00', '10:15', '#e0e0e0', 1, 'lundi,mardi,jeudi,vendredi', 0],
    ['Cantine', '12:00', '13:30', '#c8e6c9', 1, 'lundi,mardi,jeudi,vendredi', 1],
    ['Recreation', '14:30', '14:45', '#e0e0e0', 1, 'lundi,mardi,jeudi,vendredi', 2],
];
$stmt = $pdo->prepare('INSERT INTO pauses (nom, heure_debut, heure_fin, couleur, actif, jours, ordre) VALUES (?,?,?,?,?,?,?)');
foreach ($pauses as $p) $stmt->execute($p);

// --- Etablissements (11) ---
$etabs = [
    [1, 'Ecole maternelle Les Tilleuls', 'ecole_maternelle', 'Ruffec', '1 rue des Tilleuls, 16700 Ruffec', '0545123456', '', 'maternelle.tilleuls@academie.fr', '', 'Ecole maternelle publique, secteur de Ruffec', 1],
    [2, 'Ecole primaire Jules Ferry', 'ecole_primaire', 'Ruffec', '12 avenue Jules Ferry, 16700 Ruffec', '0545987654', '', 'ecole.julesferry@academie.fr', '', 'Ecole primaire publique, dispositif ULIS integre', 1],
    [3, 'Ecole primaire Paul Bert', 'ecole_primaire', 'Ruffec', '8 rue Paul Bert, 16700 Ruffec', '0545112233', '', 'paul.bert@academie.fr', '', 'Ecole primaire publique, secteur nord', 1],
    [4, 'Ecole primaire Victor Hugo', 'ecole_primaire', 'Ruffec', '5 boulevard Victor Hugo, 16700 Ruffec', '0545223344', '', 'victor.hugo@academie.fr', '', 'Ecole primaire publique, secteur est', 1],
    [5, 'CMPP Angouleme', 'cmpp', 'Angouleme', '25 rue de la Paix, 16000 Angouleme', '0545334455', '', 'cmpp.angouleme@ch-angouleme.fr', '', 'Centre Medico-Psycho-Pedagogique', 1],
    [6, 'CMP Angouleme', 'cmp', 'Angouleme', '18 avenue du General de Gaulle, 16000 Angouleme', '0545445566', '', 'cmp.angouleme@ch-angouleme.fr', '', 'Centre Medico-Psychologique, pedopsychiatrie', 1],
    [7, 'SESSAD APA 16', 'sessad', 'Angouleme', '42 rue des Remparts, 16000 Angouleme', '0545556677', '', 'sessad.apa16@association.fr', '', "Service d\'Education Speciale et de Soins a Domicile", 1],
    [8, 'ASE Charente', 'foyer_ase', 'Angouleme', '14 boulevard de l\'Entente, 16000 Angouleme', '0545667788', '', 'ase.charente@cd16.fr', '', 'Aide Sociale a l\'Enfance, Charente', 1],
    [9, 'Foyer Les Hirondelles', 'foyer_ase', 'Ruffec', '2 rue de l\'Enfance, 16700 Ruffec', '0545112233', '', 'foyer.hirondelles@ase16.fr', '', 'Foyer d\'accueil MECS', 1],
    [10, 'MDA Angouleme', 'association', 'Angouleme', '6 rue des Arts, 16000 Angouleme', '0545778899', '', 'contact@mda-angouleme.fr', '', 'Maison departementale de l\'autisme', 1],
    [11, 'College Jean Rostand', 'college', 'Ruffec', '15 avenue de la Gare, 16700 Ruffec', '0545889900', '', 'ce.0160000c@ac-poitiers.fr', '', 'College public de secteur, ULIS college', 1],
];
$stmt = $pdo->prepare('INSERT INTO etablissements (id, nom, type, ville, adresse, telephone, telephone2, email, email2, description, actif) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
foreach ($etabs as $e) $stmt->execute($e);
$pdo->exec('ALTER TABLE etablissements AUTO_INCREMENT = 20');

// --- Adultes (15) ---
$adultes = [
    [1, 'M. Dupont', 'Jean', 'enseignant', '', '0612345678', 'jean.dupont@ecole.fr', '', 2, 'Enseignant referent CP', 0],
    [2, 'Mme Martin', 'Marie', 'enseignant', '', '0623456789', 'marie.martin@ecole.fr', '', 2, 'Enseignante CE1-CE2', 1],
    [3, 'Mme Bernard', 'Sophie', 'enseignant', '', '0634567890', 'sophie.bernard@ecole.fr', '', 2, 'Enseignante CM1-CM2', 2],
    [4, 'M. Petit', 'Pierre', 'enseignant', 'directeur', '0645678901', 'pierre.petit@ecole.fr', '', 2, 'Enseignant decharge direction', 3],
    [5, 'Mme Robert', 'Isabelle', 'enseignant', 'coordo_ulis', '0656789012', 'isabelle.robert@ecole.fr', '', 2, 'Coordinatrice ULIS', 4],
    [6, 'Sophie', 'Sophie', 'aeshco', '', '0667890123', 'sophie.aesh@academie.fr', '', 2, 'AESH collective, 3 eleves mutualises', 5],
    [7, 'Dr. Laurent', 'Philippe', 'specialiste', '', '0678901234', 'p.laurent@ch-ruffec.fr', '', 5, 'Medecin scolaire, bilans et ESS', 6],
    [8, 'Mme Legrand', 'Catherine', 'specialiste', '', '0689012345', 'c.legrand@cg16.fr', '', 10, 'Ergotherapeute, evaluation et materiel adapte', 7],
    [9, 'Mme Rousseau', 'Nathalie', 'aeshi', '', '0611223344', 'n.rousseau@academie.fr', '', 2, 'AESH individuelle, Lea Lemoine', 8],
    [10, 'M. Lefebvre', 'Karim', 'aeshco', '', '0622334455', 'k.lefebvre@academie.fr', '', 2, 'AESH collective CE1-CE2', 9],
    [11, 'Mme Girard', 'Audrey', 'aeshi', '', '0633445566', 'a.girard@academie.fr', '', 2, 'AESH individuelle, Lucas Bernard + Hugo Robert', 10],
    [12, 'Mme Morel', 'Emilie', 'enseignant', '', '0644556677', 'e.morel@ecole.fr', '', 2, 'Enseignante CP-CE1', 11],
    [13, 'Dr. Mercier', 'Anne', 'specialiste', '', '0655667788', 'a.mercier@cmp-ruffec.fr', '', 6, 'Pedopsychiatre CMP', 12],
    [14, 'M. Dumont', 'Sylvain', 'educateur', '', '0666778899', 's.dumont@ase16.fr', '', 8, 'Educateur ASE, Mathis Leroy', 13],
    [15, 'Mme Lambert', 'Celine', 'assistant_familial', '', '0677889900', 'c.lambert@ase16.fr', '', 8, 'Assistante familiale, Ines Dubois', 14],
];
$stmt = $pdo->prepare('INSERT INTO adultes (id, nom, prenom, role, fonction, telephone, email, etablissements, etablissement_id, commentaires, ordre) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
foreach ($adultes as $a) $stmt->execute($a);
$pdo->exec('ALTER TABLE adultes AUTO_INCREMENT = 30');

// --- Adultes_Etablissements (tous les rattachements) ---
// Tous les adultes de Jules Ferry
$pdo->exec("INSERT INTO adultes_etablissements (adulte_id, etablissement_id, role) SELECT id, 2, role FROM adultes WHERE etablissement_id = 2");
// Rattachements spécifiques
$aes = [];
// Sophie aussi aux Tilleuls
$aes[] = [6, 1, 'aeshco'];
// Spécialistes dans leurs propres structures
$aes[] = [7, 5, 'specialiste'];  // Dr Laurent → CMPP
$aes[] = [8, 10, 'specialiste']; // Mme Legrand → MDA
$aes[] = [13, 6, 'specialiste']; // Dr Mercier → CMP
// ASE dans leur structure
$aes[] = [14, 8, 'educateur'];   // M. Dumont → ASE
$aes[] = [15, 8, 'assistant_familial']; // Mme Lambert → ASE
// Intervenants extérieurs à Jules Ferry
$aes[] = [7, 2, 'intervenant'];  // Dr Laurent intervient à Jules Ferry
$aes[] = [8, 2, 'intervenant'];  // Mme Legrand intervient à Jules Ferry
$stmt = $pdo->prepare('INSERT INTO adultes_etablissements (adulte_id, etablissement_id, role) VALUES (?,?,?)');
foreach ($aes as $ae) $stmt->execute($ae);

// --- Classes (6) ---
$classes = [
    [1, 'CP', '["cp"]', 1, 2],                   // M. Dupont
    [2, 'CP-CE1', '["cp","ce1"]', 12, 2],        // Mme Morel
    [3, 'CE1-CE2', '["ce1","ce2"]', 2, 2],       // Mme Martin
    [4, 'CE2-CM1', '["ce2","cm1"]', 3, 2],       // Mme Bernard
    [5, 'CM1-CM2', '["cm1","cm2"]', 4, 2],       // M. Petit
    [6, 'Dispositif ULIS', '["cp","ce1","ce2","cm1","cm2"]', 5, 2], // Mme Robert
];
$stmt = $pdo->prepare('INSERT INTO classes (id, nom, niveaux, enseignant_id, etablissement_id) VALUES (?,?,?,?,?)');
foreach ($classes as $c) $stmt->execute($c);
$pdo->exec('ALTER TABLE classes AUTO_INCREMENT = 20');

// --- Eleves (12) ---
/*
ID  prenoms attendus pour enrich data:
1=Lea Lemoine, 2=Thomas Moreau, 3=Emma Petit, 4=Noah Garcia, 5=Ines Dubois, 6=Lucas Bernard,
7=Chloe Martin, 8=Hugo Robert, 9=Maelys Durand, 10=Mathis Leroy, 11=Jade Simon, 12=Noe Laurent
*/
$eleves = [];
foreach ([
    [1, 'Lemoine', 'Lea', '2019-05-12', 'CP', 1, 1, 'CP', 'CP', 'Ecole maternelle Les Tilleuls', '2025-09-01', 'Taxi', 1, '0611112233', 'lemoine.famille@email.fr', '12 rue des Lilas, 16700 Ruffec', 2, 1],
    [2, 'Moreau', 'Thomas', '2019-09-03', 'CP', 1, 1, 'CP', 'CP', 'Ecole maternelle Les Tilleuls', '2025-09-01', 'Bus scolaire', 1, '0622223344', 'moreau.parents@email.fr', '3 impasse des Ecoles, 16700 Ruffec', 2, 1],
    [3, 'Petit', 'Emma', '2019-02-28', 'CP', 1, 0, 'CP', 'CP', 'Ecole maternelle Les Tilleuls', NULL, 'Bus scolaire', 1, '0633334455', 'petit.famille@email.fr', '8 rue de la Mairie, 16700 Ruffec', 2, 1],
    [4, 'Garcia', 'Noah', '2018-07-14', 'CE1', 2, 1, 'CE1', 'CE1', 'Ecole primaire Jules Ferry', '2024-09-01', 'Bus scolaire', 1, '0644445566', 'garcia.famille@email.fr', '22 avenue de la Gare, 16700 Ruffec', 2, 2],
    [5, 'Dubois', 'Ines', '2018-11-22', 'CE1', 2, 1, 'CE1', 'CE1', 'Ecole primaire Paul Bert', '2025-01-06', 'Taxi', 1, '0655556677', '', 'Chez Mme Lambert, 5 chemin du Moulin, 16700 Ruffec', 2, 3],
    [6, 'Bernard', 'Lucas', '2017-12-05', 'CE1', 2, 1, 'CE1', 'CE1', 'Ecole primaire Jules Ferry', '2024-09-01', 'Bus scolaire', 1, '0666667788', 'bernard.parents@email.fr', '15 rue du Stade, 16700 Ruffec', 2, 2],
    [7, 'Martin', 'Chloe', '2017-03-18', 'CE2', 3, 1, 'CE2', 'CE2', 'Ecole primaire Jules Ferry', '2023-09-01', 'Taxi', 1, '0677778899', 'martin.famille@email.fr', '7 place de l\'Eglise, 16700 Ruffec', 2, 2],
    [8, 'Robert', 'Hugo', '2016-09-30', 'CE2', 3, 1, 'CE2', 'CE2', 'Ecole primaire Victor Hugo', '2023-09-01', 'Taxi', 1, '0688889900', 'robert.parents@email.fr', '28 rue du Bois, 16700 Ruffec', 2, 4],
    [9, 'Durand', 'Maelys', '2017-06-08', 'CE2', 3, 1, 'CE2', 'CE2', 'Ecole primaire Jules Ferry', '2025-09-01', 'Bus scolaire', 1, '0699990011', 'durand.famille@email.fr', '4 allee des Platanes, 16700 Ruffec', 2, 2],
    [10, 'Leroy', 'Mathis', '2016-01-15', 'CM1', 5, 1, 'CM', 'CM1', 'Ecole primaire Paul Bert', '2022-09-01', 'Taxi', 1, '', '', 'Foyer Les Hirondelles, 2 rue de l\'Enfance, 16700 Ruffec', 2, 3],
    [11, 'Simon', 'Jade', '2015-08-22', 'CM1', 5, 1, 'CM', 'CM1', 'Ecole primaire Jules Ferry', '2024-09-01', 'Bus scolaire', 1, '0610101112', 'simon.famille@email.fr', '10 rue des Tilleuls, 16700 Ruffec', 2, 2],
    [12, 'Laurent', 'Noe', '2015-04-30', 'CM2', 5, 1, 'CM', 'CM2', 'Ecole primaire Victor Hugo', '2021-09-01', 'Bus de ville', 1, '0611111213', 'laurent.parents@email.fr', '18 boulevard de la Liberte, 16700 Ruffec', 2, 4],
] as $e) {
    $id = $e[0]; $nom = $e[1]; $prenom = $e[2]; $dn = $e[3]; $classe = $e[4]; $classe_id = $e[5];
    $ulis = $e[6]; $groupe = $e[7]; $niveau = $e[8]; $eo = $e[9]; $deu = $e[10];
    $transport = $e[11]; $cantine = $e[12]; $tel = $e[13]; $email = $e[14];
    $adresse = $e[15]; $etab_id = $e[16]; $eo_id = $e[17];

    $pdo->prepare('INSERT INTO eleves (id, nom, prenom, date_naissance, classe, classe_id, ulis, groupe, niveau_scolaire, ecole_origine, ecole_origine_id, date_entree_ulis, transport, cantine, telephone, email, adresse, etablissement_id, ordre)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
        ->execute([$id, $nom, $prenom, $dn, $classe, $classe_id, $ulis, $groupe, $niveau, $eo, $eo_id, $deu, $transport, $cantine, $tel, $email, $adresse, $etab_id, $id - 1]);
}
$pdo->exec('ALTER TABLE eleves AUTO_INCREMENT = 31');

// --- Enrichissement eleves (champs complexes) ---
// 1. Lea Lemoine
$pdo->exec("UPDATE eleves SET
    allergies = 'Arachide, acariens',
    info_medicale = 'Traitement antihistaminique si crise. Trousse d\'urgence dans le cartable.',
    pai = 1, lien_pai = 'documents/PAI/PAI_Lemoine_Lea_2025.pdf',
    notifications = '[\"PPS\",\"PAI\",\"ESS\"]',
    liens_mdph = '{\"ESS\":[{\"label\":\"GEVASCO 2025-2026\",\"url\":\"documents/GEVASCO/Lemoine_Gevasco_2025.pdf\"},{\"label\":\"GEVASCO 2024-2025\",\"url\":\"documents/GEVASCO/Lemoine_Gevasco_2024.pdf\"}],\"PPS\":[{\"label\":\"PPS 2025-2026\",\"url\":\"documents/PPS/PPS_Lemoine_2025.pdf\"}],\"PAI\":[{\"label\":\"PAI signe\",\"url\":\"documents/PAI/PAI_Lemoine_signe.pdf\"}]}',
    mdph_ulis_date_fin = '2027-08-31', mdph_ulis_statut = 'notifie',
    mdph_aesh_date_fin = '2027-08-31', mdph_aesh_statut = 'notifie',
    remarques = 'Parents tres investis. Bonne evolution depuis septembre. Progres en motricite fine.'
    WHERE id = 1");

// 2. Thomas Moreau
$pdo->exec("UPDATE eleves SET
    info_medicale = 'Troubles du langage oral, suivi orthophonique 2x/semaine',
    pai = 0,
    notifications = '[\"PPRE\",\"ESS\"]',
    liens_mdph = '{\"ESS\":[{\"label\":\"GEVASCO 2025\",\"url\":\"documents/GEVASCO/Moreau_Gevasco_2025.pdf\"}]}',
    mdph_ulis_date_fin = '2027-08-31', mdph_ulis_statut = 'notifie',
    remarques = 'Bonne integration dans le groupe.'
    WHERE id = 2");

// 3. Emma Petit (non ULIS)
$pdo->exec("UPDATE eleves SET
    allergies = 'Pollen',
    info_medicale = 'Lunettes, verifier port quotidien',
    pai = 0,
    notifications = '[\"PAP\"]',
    liens_mdph = '{\"PAP\":[{\"label\":\"PAP signe\",\"url\":\"documents/PAP/PAP_Petit_Emma_2025.pdf\"}]}',
    remarques = 'En attente de notification ULIS. Suivi RASED en CP.'
    WHERE id = 3");

// 4. Noah Garcia
$pdo->exec("UPDATE eleves SET
    info_medicale = 'TDAH, traitement methylphenidate LP pris a la maison le matin. Surveillance effets secondaires.',
    pai = 0,
    notifications = '[\"PPS\",\"ESS\"]',
    liens_mdph = '{\"ESS\":[{\"label\":\"GEVASCO 2025\",\"url\":\"documents/GEVASCO/Garcia_Gevasco_2025.pdf\"}],\"PPS\":[{\"label\":\"PPS 2024-2026\",\"url\":\"documents/PPS/PPS_Garcia_2024.pdf\"}]}',
    mdph_ulis_date_fin = '2026-08-31', mdph_ulis_statut = 'renouvellement',
    remarques = 'Agitation en fin de matinee. Amenagement: pauses motrices regulieres, assis pres du tableau.'
    WHERE id = 4");

// 5. Ines Dubois (ASE)
$pdo->exec("UPDATE eleves SET
    regime_alimentaire = 'Sans porc',
    info_medicale = 'Suivi pedopsychiatrique CMP',
    pai = 0,
    notifications = '[\"PPS\",\"ESS\"]',
    liens_mdph = '{\"ESS\":[{\"label\":\"GEVASCO 2025\",\"url\":\"documents/GEVASCO/Dubois_Gevasco_2025.pdf\"}],\"notif_mdph\":[{\"label\":\"Notification MDPH 2024\",\"url\":\"documents/MDPH/Dubois_Notif_2024.pdf\"}]}',
    mdph_ulis_date_fin = '2027-08-31', mdph_ulis_statut = 'notifie',
    mdph_sessad_date_fin = '2027-08-31', mdph_sessad_statut = 'notifie',
    mdph_transport_date_fin = '2027-08-31', mdph_transport_statut = 'notifie',
    ase_place = 1, ase_type_placement = 'Famille d\'accueil',
    ase_structure_nom = 'Mme Lambert Celine', ase_structure_adresse = '5 chemin du Moulin, 16700 Ruffec', ase_structure_telephone = '0677889900',
    ase_referent_nom = 'Sylvain Dumont', ase_referent_telephone = '0666778899', ase_referent_email = 's.dumont@ase16.fr',
    ase_lien_ppe = 'documents/ASE/PPE_Dubois_2025.pdf',
    ase_notes = 'Placement famille d\'accueil depuis janvier 2024. PPE signe en mars 2025. Visites mediatisees avec la mere 1x/mois.',
    remarques = 'Tres bon contact avec l\'assistante familiale. Progres en lecture depuis le placement.'
    WHERE id = 5");

// 6. Lucas Bernard
$pdo->exec("UPDATE eleves SET
    allergies = 'Port de lunettes, fatigue visuelle en fin de journee',
    info_medicale = '',
    pai = 1, lien_pai = 'documents/PAI/PAI_Bernard_Lucas_2025.pdf',
    notifications = '[\"PPS\",\"PAI\",\"ESS\"]',
    liens_mdph = '{\"ESS\":[{\"label\":\"GEVASCO 2025\",\"url\":\"documents/GEVASCO/Bernard_Gevasco_2025.pdf\"}],\"PPS\":[{\"label\":\"PPS 2024-2026\",\"url\":\"documents/PPS/PPS_Bernard_2024.pdf\"}],\"PAI\":[{\"label\":\"PAI Dys\",\"url\":\"documents/PAI/PAI_Bernard_Dys.pdf\"}]}',
    mdph_ulis_date_fin = '2026-08-31', mdph_ulis_statut = 'renouvellement',
    mdph_aesh_date_fin = '2026-08-31', mdph_aesh_statut = 'renouvellement',
    remarques = 'Dyslexie-dysorthographie severe. Materiel adapte: police Opendys, guide-doigt, ordinateur en projet.'
    WHERE id = 6");

// 7. Chloe Martin
$pdo->exec("UPDATE eleves SET
    allergies = 'Latex',
    info_medicale = 'IMC, hemiparesie droite. Kinesitherapie 2x/semaine. Fauteuil adapte en classe. Temps supplementaire.',
    pai = 1, lien_pai = 'documents/PAI/PAI_Martin_Chloe_2025.pdf',
    notifications = '[\"PPS\",\"PAI\",\"ESS\"]',
    liens_mdph = '{\"ESS\":[{\"label\":\"GEVASCO 2025\",\"url\":\"documents/GEVASCO/Martin_Gevasco_2025.pdf\"},{\"label\":\"Bilan kine 2025\",\"url\":\"documents/bilans/Martin_BilanKine_2025.pdf\"}],\"PPS\":[{\"label\":\"PPS 2023-2027\",\"url\":\"documents/PPS/PPS_Martin_2023.pdf\"}],\"PAI\":[{\"label\":\"PAI IMC\",\"url\":\"documents/PAI/PAI_Martin_IMC.pdf\"}]}',
    mdph_ulis_date_fin = '2027-08-31', mdph_ulis_statut = 'notifie',
    mdph_aesh_date_fin = '2027-08-31', mdph_aesh_statut = 'notifie',
    mdph_transport_date_fin = '2027-08-31', mdph_transport_statut = 'notifie',
    remarques = 'Excellente eleve, grande motivation. Projet inclusion complete en CM2.'
    WHERE id = 7");

// 8. Hugo Robert
$pdo->exec("UPDATE eleves SET
    allergies = 'Gluten (diagnostic 2024)',
    regime_alimentaire = 'Sans gluten, PAI fourni',
    info_medicale = 'TSA diagnostique CRA Poitiers 2023. Hypersensibilite auditive, casque anti-bruit disponible. Routines visuelles necessaires.',
    pai = 1, lien_pai = 'documents/PAI/PAI_Robert_Hugo_2025.pdf',
    notifications = '[\"PPS\",\"PAI\",\"ESS\"]',
    liens_mdph = '{\"ESS\":[{\"label\":\"GEVASCO 2025\",\"url\":\"documents/GEVASCO/Robert_Gevasco_2025.pdf\"}],\"PPS\":[{\"label\":\"PPS 2023-2027\",\"url\":\"documents/PPS/PPS_Robert_2023.pdf\"}],\"PAI\":[{\"label\":\"PAI Gluten\",\"url\":\"documents/PAI/PAI_Robert_Gluten.pdf\"}]}',
    mdph_ulis_date_fin = '2027-08-31', mdph_ulis_statut = 'notifie',
    mdph_aesh_date_fin = '2027-08-31', mdph_aesh_statut = 'notifie',
    mdph_transport_date_fin = '2027-08-31', mdph_transport_statut = 'notifie',
    remarques = 'Tres bons progres en socialisation. Utilise un emploi du temps visuel. Evitement des bruits forts.'
    WHERE id = 8");

// 9. Maelys Durand
$pdo->exec("UPDATE eleves SET
    info_medicale = 'Dyslexie severe, tiers-temps, police adaptee, dictee a l\'adulte',
    pai = 0,
    notifications = '[\"PAP\",\"PPRE\"]',
    liens_mdph = '{\"PPRE\":[{\"label\":\"PPRE signe\",\"url\":\"documents/PPRE/PPRE_Durand_2025.pdf\"}]}',
    mdph_ulis_date_fin = '2027-08-31', mdph_ulis_statut = 'notifie',
    remarques = 'Arrivee en ULIS en septembre 2025. Bonne adaptation. Travail sur la confiance en soi.'
    WHERE id = 9");

// 10. Mathis Leroy (ASE)
$pdo->exec("UPDATE eleves SET
    regime_alimentaire = '',
    info_medicale = 'Suivi pedopsychiatrique bimensuel. Troubles de l\'attachement. Gestion de la frustration difficile.',
    pai = 0,
    notifications = '[\"PPS\",\"ESS\"]',
    liens_mdph = '{\"ESS\":[{\"label\":\"GEVASCO 2025\",\"url\":\"documents/GEVASCO/Leroy_Gevasco_2025.pdf\"}],\"PPS\":[{\"label\":\"PPS 2022-2026\",\"url\":\"documents/PPS/PPS_Leroy_2022.pdf\"}],\"notif_mdph\":[{\"label\":\"Notification initiale\",\"url\":\"documents/MDPH/Leroy_Notif_2022.pdf\"}]}',
    mdph_ulis_date_fin = '2026-08-31', mdph_ulis_statut = 'renouvellement',
    mdph_transport_date_fin = '2026-08-31', mdph_transport_statut = 'renouvellement',
    ase_place = 1, ase_type_placement = 'Foyer / MECS',
    ase_structure_nom = 'Foyer Les Hirondelles', ase_structure_adresse = '2 rue de l\'Enfance, 16700 Ruffec', ase_structure_telephone = '0545112233',
    ase_referent_nom = 'Sylvain Dumont', ase_referent_telephone = '0666778899', ase_referent_email = 's.dumont@ase16.fr',
    ase_lien_ppe = 'documents/ASE/PPE_Leroy_2025.pdf',
    ase_notes = 'Placement judiciaire depuis mars 2022. Mere incarceree, pere inconnu. Projet de placement long terme. Fratrie de 3, Mathis est l\'aine.',
    remarques = 'Excellentes capacites intellectuelles. Travail sur le comportement et la relation aux autres. Tuteur de resilience identifie (educateur sportif).'
    WHERE id = 10");

// 11. Jade Simon
$pdo->exec("UPDATE eleves SET
    info_medicale = 'TDAH, traitement methylphenidate LP. Surveillance tension/poids tous les 3 mois.',
    pai = 0,
    notifications = '[\"PPS\",\"ESS\"]',
    liens_mdph = '{\"ESS\":[{\"label\":\"GEVASCO 2025\",\"url\":\"documents/GEVASCO/Simon_Gevasco_2025.pdf\"}],\"PPS\":[{\"label\":\"PPS 2024-2026\",\"url\":\"documents/PPS/PPS_Simon_2024.pdf\"}]}',
    mdph_ulis_date_fin = '2026-08-31', mdph_ulis_statut = 'renouvellement',
    remarques = 'Parents separes, garde alternee. Bien suivie, communication fluide entre les deux foyers. Progres en autonomie.'
    WHERE id = 11");

// 12. Noe Laurent
$pdo->exec("UPDATE eleves SET
    info_medicale = 'Dyslexie-dysorthographie + dyscalculie. Ordinateur portable fourni par MDPH. Logiciels: Balabolka, Geogebra.',
    pai = 0,
    notifications = '[\"PPS\",\"ESS\",\"PPRE\"]',
    liens_mdph = '{\"ESS\":[{\"label\":\"GEVASCO 2025\",\"url\":\"documents/GEVASCO/Laurent_Gevasco_2025.pdf\"},{\"label\":\"Bilan orthophoniste 2025\",\"url\":\"documents/bilans/Laurent_BilanOrtho_2025.pdf\"}],\"PPS\":[{\"label\":\"PPS 2021-2026\",\"url\":\"documents/PPS/PPS_Laurent_2021.pdf\"}],\"PPRE\":[{\"label\":\"PPRE College\",\"url\":\"documents/PPRE/PPRE_Laurent_College.pdf\"}]}',
    mdph_ulis_date_fin = '2026-08-31', mdph_ulis_statut = 'renouvellement',
    mdph_sessad_date_fin = '2026-07-04', mdph_sessad_statut = 'notifie',
    remarques = 'Derniere annee ULIS, preparation orientation ULIS college. ESS de fin d\'annee prevue en juin. Stage decouverte 3e en projet.'
    WHERE id = 12");

// --- Representants legaux (37) ---
$reps = [
    [1, 'Lemoine', 'Sebastien', 'pere', '0611112244', 1, 's.lemoine@email.fr', '12 rue des Lilas, 16700 Ruffec'],
    [1, 'Lemoine', 'Julie', 'mere', '0611112255', 0, 'j.lemoine@email.fr', '12 rue des Lilas, 16700 Ruffec'],
    [2, 'Moreau', 'David', 'pere', '0622223355', 1, 'd.moreau@email.fr', '3 impasse des Ecoles, 16700 Ruffec'],
    [2, 'Moreau', 'Melanie', 'mere', '0622223366', 0, 'm.moreau@email.fr', '3 impasse des Ecoles, 16700 Ruffec'],
    [3, 'Petit', 'Francois', 'pere', '0633334466', 1, 'f.petit@email.fr', '8 rue de la Mairie, 16700 Ruffec'],
    [3, 'Petit', 'Sandrine', 'mere', '0633334477', 0, 's.petit@email.fr', '8 rue de la Mairie, 16700 Ruffec'],
    [4, 'Garcia', 'Antonio', 'pere', '0644445577', 1, 'a.garcia@email.fr', '22 avenue de la Gare, 16700 Ruffec'],
    [4, 'Garcia', 'Laura', 'mere', '0644445588', 0, 'l.garcia@email.fr', '22 avenue de la Gare, 16700 Ruffec'],
    [5, 'Lambert', 'Celine', 'assistante familiale', '0677889900', 1, 'c.lambert@ase16.fr', '5 chemin du Moulin, 16700 Ruffec'],
    [5, 'Dumont', 'Sylvain', 'educateur referent', '0666778899', 0, 's.dumont@ase16.fr', 'ASE Charente, 16000 Angouleme'],
    [5, 'Dubois', 'Karima', 'mere', '0601020304', 0, '', 'Domicile inconnu, visites mediatisees au centre'],
    [6, 'Bernard', 'Olivier', 'pere', '0666667799', 1, 'o.bernard@email.fr', '15 rue du Stade, 16700 Ruffec'],
    [6, 'Bernard', 'Valerie', 'mere', '0666667800', 0, 'v.bernard@email.fr', '15 rue du Stade, 16700 Ruffec'],
    [7, 'Martin', 'Christophe', 'pere', '0677778800', 1, 'c.martin@email.fr', '7 place de l\'Eglise, 16700 Ruffec'],
    [7, 'Martin', 'Aurelie', 'mere', '0677778801', 0, 'a.martin@email.fr', '7 place de l\'Eglise, 16700 Ruffec'],
    [8, 'Robert', 'Pascal', 'pere', '0688889901', 1, 'p.robert@email.fr', '28 rue du Bois, 16700 Ruffec'],
    [8, 'Robert', 'Brigitte', 'mere', '0688889902', 0, 'b.robert@email.fr', '28 rue du Bois, 16700 Ruffec'],
    [9, 'Durand', 'Laurent', 'pere', '0699990022', 1, 'l.durand@email.fr', '4 allee des Platanes, 16700 Ruffec'],
    [9, 'Durand', 'Sophie', 'belle-mere', '0699990033', 0, 's.durand@email.fr', '4 allee des Platanes, 16700 Ruffec'],
    [10, 'Dumont', 'Sylvain', 'educateur referent', '0666778899', 1, 's.dumont@ase16.fr', 'ASE Charente, 16000 Angouleme'],
    [10, 'Moreau', 'Patricia', 'cheffe de service foyer', '0545112234', 0, 'p.moreau@foyer-hirondelles.fr', 'Foyer Les Hirondelles, 2 rue de l\'Enfance, 16700 Ruffec'],
    [11, 'Simon', 'Gregory', 'pere', '0610102222', 1, 'g.simon@email.fr', '10 rue des Tilleuls, 16700 Ruffec'],
    [11, 'Legrand', 'Patricia', 'mere', '0610103333', 0, 'p.legrand@email.fr', '25 rue de la Poste, 16700 Ruffec'],
    [12, 'Laurent', 'Vincent', 'pere', '0611112222', 1, 'v.laurent@email.fr', '18 boulevard de la Liberte, 16700 Ruffec'],
    [12, 'Laurent', 'Agnes', 'mere', '0611112223', 0, 'a.laurent@email.fr', '18 boulevard de la Liberte, 16700 Ruffec'],
];
$stmt = $pdo->prepare('INSERT INTO representants (eleve_id, nom, prenom, lien, telephone, telephone_urgence, email, adresse) VALUES (?,?,?,?,?,?,?,?)');
foreach ($reps as $r) $stmt->execute($r);

// --- AESH eleves ---
$aeshs = [
    [1, 'AESHi', 'Nathalie Rousseau', '12h', ''],
    [7, 'AESHm', 'Audrey Girard', '6h', '8'], // Chloe mutualisee avec Hugo
    [8, 'AESHm', 'Audrey Girard', '6h', '7'],
    [6, 'AESHco', 'Karim Lefebvre', '3h', '4'], // Lucas mutualise avec Noah
    [12, 'AESHi', 'Audrey Girard', '9h', ''],
];
$stmt = $pdo->prepare('INSERT INTO aesh_eleves (eleve_id, type, nom, heures, mutualise_avec) VALUES (?,?,?,?,?)');
foreach ($aeshs as $a) $stmt->execute($a);

// --- PEC eleves ---
$pecs = [
    [1, 'orthophoniste', 'prive', 'hebdomadaire', 'cabinet', '45 min', 'Mme Faure, 12 rue du Centre, Ruffec. Travail langage et articulation.'],
    [1, 'psychomotricien', 'prive', 'bimensuel', 'cabinet', '45 min', 'M. Blanc, 5 place du Marche, Ruffec. Motricite fine et graphisme.'],
    [2, 'orthophoniste', 'prive', 'hebdomadaire', 'cabinet', '30 min', 'Mme Faure, 2 seances/semaine (lundi et jeudi).'],
    [4, 'psychomotricien', 'CMPP', 'bimensuel', 'ecole', '45 min', 'Intervention dans les locaux de l\'ecole le mardi matin.'],
    [5, 'educateur', 'SESSAD', 'hebdomadaire', 'ecole', '1h', 'SESSAD APA 16, suivi educatif et scolaire.'],
    [5, 'psychologue', 'CMP', 'hebdomadaire', 'cabinet', '30 min', 'Dr Mercier, CMP Angouleme. Travail sur l\'attachement.'],
    [6, 'orthophoniste', 'CMPP', 'hebdomadaire', 'cabinet', '45 min', 'CMPP Angouleme. Prise en charge globale dys.'],
    [6, 'psychomotricien', 'CMPP', 'bimensuel', 'cabinet', '45 min', 'CMPP Angouleme. Graphisme et coordination.'],
    [7, 'psychomotricien', 'prive', 'hebdomadaire', 'cabinet', '1h', 'M. Moreau, 2x/semaine. Reeducation hemiparesie droite.'],
    [7, 'ergotherapeute', 'SESSAD', 'bimensuel', 'ecole', '1h', 'Catherine Legrand, adaptation poste de travail, materiel.'],
    [8, 'psychologue', 'CMPP', 'bimensuel', 'cabinet', '45 min', 'CMPP Angouleme. Travail habiletes sociales groupe TSA.'],
    [8, 'orthophoniste', 'prive', 'hebdomadaire', 'cabinet', '45 min', 'Mme Roux, pragmatique du langage.'],
    [9, 'orthophoniste', 'prive', 'hebdomadaire', 'cabinet', '30 min', 'Mme Faure, methode syllabique renforcee.'],
    [10, 'psychologue', 'CMP', 'bimensuel', 'cabinet', '45 min', 'Dr Mercier, CMP Angouleme.'],
    [10, 'educateur', 'prive', 'hebdomadaire', 'ecole', '1h', 'Sylvain Dumont, suivi ASE et scolaire.'],
    [11, 'psychologue', 'CMP', 'bimensuel', 'cabinet', '30 min', 'Dr Mercier, suivi TDAH et gestion des emotions.'],
    [12, 'orthophoniste', 'SESSAD', 'hebdomadaire', 'ecole', '45 min', 'SESSAD APA 16.'],
    [12, 'psychomotricien', 'SESSAD', 'bimensuel', 'ecole', '45 min', 'SESSAD APA 16. Preparation geste d\'ecriture.'],
];
$stmt = $pdo->prepare('INSERT INTO pec_eleves (eleve_id, specialite, organisme, frequence, lieu, duree, commentaires) VALUES (?,?,?,?,?,?,?)');
foreach ($pecs as $p) $stmt->execute($p);

// --- Reunions (10) ---
$reunions = [
    ['ESS', 'ESS, Lea Lemoine', '2025-11-15', '14:00', 90, 1, 'Salle reunion ecole', '["Mme Robert (coord ULIS)","M. Lemoine","Mme Lemoine","Nathalie Rousseau (AESHi)","Mme Faure (orthophoniste)","M. Dupont (enseignant CP)"]', 'realisee', 'Bonne evolution. Maintien AESHi 12h. Prochaine ESS en mai 2026.'],
    ['ESS', 'ESS, Hugo Robert', '2025-11-22', '14:00', 90, 8, 'Salle reunion ecole', '["Mme Robert (coord ULIS)","M. et Mme Robert","Audrey Girard (AESHi)","Dr Laurent (CMPP)","Mme Bernard (enseignant CE2)"]', 'realisee', 'Maintien dispositif. Progres en socialisation. Ajout seance habiletes sociales.'],
    ['ESS', 'ESS, Mathis Leroy', '2025-12-06', '14:30', 90, 10, 'Foyer Les Hirondelles', '["Mme Robert (coord ULIS)","Sylvain Dumont (educateur ASE)","Patricia Moreau (cheffe service)","Dr Mercier (CMP)"]', 'realisee', 'Cadre contenant necessaire. Maintien ULIS. PPE mis a jour.'],
    ['ESS', 'ESS, Chloe Martin', '2026-01-17', '14:00', 60, 7, 'Salle reunion ecole', '["Mme Robert (coord ULIS)","M. et Mme Martin","Audrey Girard (AESHi)","Catherine Legrand (ergotherapeute)"]', 'realisee', 'Materiel informatique adapte commande. Chaise ergonomique installee.'],
    ['Equipe educative', 'Equipe educative, Ines Dubois', '2026-02-07', '13:30', 60, 5, 'Salle reunion ecole', '["Mme Robert (coord ULIS)","Mme Lambert (assistante familiale)","Sylvain Dumont (ASE)","Mme Morel (enseignant CE1)"]', 'realisee', 'Tres bonne integration. Progres lecture confirmes. Point sur fratrie.'],
    ['ESS', 'ESS, Noe Laurent (prepa college)', '2026-03-21', '14:00', 90, 12, 'College Jean Rostand', '["Mme Robert (coord ULIS)","M. et Mme Laurent","Coordo ULIS college","Audrey Girard (AESHi)"]', 'realisee', 'Accord orientation ULIS college. Stage decouverte valide. Transmission dossier.'],
    ['ESS', 'ESS, Lea Lemoine (suivi)', '2026-05-15', '14:00', 60, 1, 'Salle reunion ecole', '["Mme Robert (coord ULIS)","M. et Mme Lemoine","Nathalie Rousseau (AESHi)","Mme Faure (orthophoniste)"]', 'prevue', 'Bilan fin d\'annee. Maintien AESHi pour le CE1.'],
    ['Equipe educative', 'Point trimestriel, Groupe CE1 ULIS', '2026-04-04', '12:30', 45, 4, 'Salle des maitres', '["Mme Robert (coord ULIS)","Mme Martin (CE1-CE2)","Karim Lefebvre (AESHco)"]', 'realisee', 'Point sur Noah, Ines, Lucas. Progres groupe en lecture.'],
    ['RDV famille', 'RDV parents, Maelys Durand', '2026-02-14', '17:30', 45, 9, 'Bureau coordo ULIS', '["Mme Robert (coord ULIS)","M. Durand","Mme Durand"]', 'realisee', 'Explication du PPRE. Accord parental pour le suivi renforce.'],
    ['Partenariat', 'Rencontre SESSAD APA 16', '2026-01-10', '10:00', 60, NULL, 'SESSAD APA 16', '["Mme Robert (coord ULIS)","Equipe SESSAD APA 16"]', 'realisee', 'Calage interventions 2026. Planning creneaux ecole.'],
];
$stmt = $pdo->prepare('INSERT INTO reunions (type, titre, date_reunion, heure, duree, eleve_id, lieu, participants, statut, notes) VALUES (?,?,?,?,?,?,?,?,?,?)');
foreach ($reunions as $r) $stmt->execute($r);
$pdo->exec('ALTER TABLE reunions AUTO_INCREMENT = 20');

// --- Evenements (12) ---
$events = [
    ['Sortie pedagogique, Ferme', 'Visite de la ferme pedagogique de Magne. Depart 9h, retour 16h.', '2026-10-10', NULL, NULL, 0, NULL, '#4caf50'],
    ['Conseil d\'ecole', 'Conseil d\'ecole trimestriel.', '2026-11-07', NULL, NULL, 0, NULL, '#ff9800'],
    ['Photo de classe', 'Photographe scolaire, toute la journee.', '2026-10-17', NULL, NULL, 0, NULL, '#2196f3'],
    ['Cross des ecoles', 'Cross annuel au stade municipal.', '2026-10-20', NULL, NULL, 0, NULL, '#f44336'],
    ['Journee inclusion', 'Journee nationale du handicap, ateliers sensibilisation.', '2026-12-03', NULL, NULL, 0, NULL, '#9c27b0'],
    ['Spectacle de Noel', 'Spectacle de fin d\'annee, salle des fetes.', '2026-12-18', NULL, NULL, 0, NULL, '#e91e63'],
    ['Vacances de Noel', '', '2026-12-19', '2027-01-03', NULL, 0, NULL, '#e0e0e0'],
    ['Rencontre USEP', 'Rencontre sportive inter-ecoles, cycle 2.', '2027-03-15', NULL, NULL, 0, NULL, '#4caf50'],
    ['Carnaval', 'Defile dans le bourg.', '2027-03-20', NULL, NULL, 0, NULL, '#ff5722'],
    ['Sortie cinema', 'Film d\'animation, Ecole et Cinema.', '2027-04-10', NULL, NULL, 0, NULL, '#3f51b5'],
    ['Vacances de printemps', '', '2027-04-12', '2027-04-25', NULL, 0, NULL, '#e0e0e0'],
    ['Kermesse', 'Kermesse de fin d\'annee.', '2027-06-20', NULL, NULL, 0, NULL, '#ff9800'],
];
$stmt = $pdo->prepare('INSERT INTO evenements (nom, description, date_debut, date_fin, jour_semaine, est_recurrent, recurrence_type, couleur, annee_scolaire_id) VALUES (?,?,?,?,?,?,?,?,1)');
foreach ($events as $ev) {
    $stmt->execute([$ev[0], $ev[1], $ev[2], $ev[3], $ev[4], $ev[5], $ev[6], $ev[7]]);
}

// --- Documents (10) ---
$docs = [
    ['GEVASCO Lea Lemoine 2025-2026', 'GEVASCO', 1, NULL, '2025-10-01', 'v1', 'final', 'documents/GEVASCO/Lemoine_Gevasco_2025.pdf', 'Redige pour l\'ESS du 15/11/2025'],
    ['PPS Lea Lemoine 2025', 'PPS', 1, NULL, '2025-09-15', 'v2', 'final', 'documents/PPS/PPS_Lemoine_2025.pdf', ''],
    ['PAI Lea Lemoine', 'PAI', 1, NULL, '2025-09-01', 'v1', 'final', 'documents/PAI/PAI_Lemoine_Lea_2025.pdf', 'Allergie arachide, protocole urgence joint'],
    ['GEVASCO Hugo Robert 2025', 'GEVASCO', 8, NULL, '2025-10-05', 'v1', 'final', 'documents/GEVASCO/Robert_Gevasco_2025.pdf', ''],
    ['PPS Noe Laurent 2021-2026', 'PPS', 12, NULL, '2021-11-01', 'v3', 'final', 'documents/PPS/PPS_Laurent_2021.pdf', 'Mise a jour annuelle, derniere revision oct 2025'],
    ['PPE Mathis Leroy 2025', 'PPE', 10, NULL, '2025-03-15', 'v1', 'final', 'documents/ASE/PPE_Leroy_2025.pdf', 'Valide en reunion ASE du 15/03/2025'],
    ['CR ESS Lea Lemoine 15/11/2025', 'compte_rendu', 1, 1, '2025-11-20', 'v1', 'final', '', ''],
    ['CR ESS Hugo Robert 22/11/2025', 'compte_rendu', 8, 2, '2025-11-25', 'v1', 'final', '', ''],
    ['CR ESS Mathis Leroy 06/12/2025', 'compte_rendu', 10, 3, '2025-12-10', 'v1', 'final', '', ''],
    ['Convocation ESS Lea Lemoine mai 2026', 'convocation', 1, 7, '2026-04-15', 'v1', 'brouillon', '', 'Envoi aux participants prevu debut mai'],
];
$stmt = $pdo->prepare('INSERT INTO documents (nom, type, eleve_id, reunion_id, date_document, version, statut, reference_externe, notes) VALUES (?,?,?,?,?,?,?,?,?)');
foreach ($docs as $d) $stmt->execute($d);

// --- Emploi du temps (template semaine 1) ---
// Inserts via setup-test logic simplifie: un template semaine 1 puis propagation
$jours = ['lundi','mardi','jeudi','vendredi'];
$adultesRef = [
    'M. Dupont' => ['enseignant', 'ULIS'],
    'Mme Martin' => ['enseignant', 'INCLUSION'],
    'Mme Bernard' => ['enseignant', 'DECLOISONNEMENT'],
    'M. Petit' => ['enseignant', 'ULIS'],
    'Mme Robert' => ['enseignant', 'ULIS'],
    'Sophie' => ['aeshco', 'PEC'],
];
$defaultAdulte = 'Mme Robert';

// Template par eleve (jours+heures fixes)
$template = [
    1 => [ // Lea Lemoine CP
        ['lundi','08:30',45,'Rituels','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
        ['lundi','09:15',45,'Lecture','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
        ['lundi','10:15',45,'Phonologie','CP','M. Dupont','enseignant','fixe','ULIS'],
        ['lundi','11:00',45,'Ecriture','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
        ['lundi','13:30',45,'Mathematiques','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
        ['lundi','14:45',45,'Arts plastiques','CP','Mme Martin','enseignant','fixe','INCLUSION'],
        ['mardi','08:30',45,'Rituels','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
        ['mardi','09:15',45,'Lecture','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
        ['mardi','10:15',45,'EPS','CP','M. Petit','enseignant','fixe','INCLUSION'],
        ['mardi','11:00',45,'Phonologie','CP','M. Dupont','enseignant','fixe','ULIS'],
        ['mardi','13:30',45,'Mathematiques','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
        ['mardi','14:45',45,'Decouverte monde','CP','Mme Martin','enseignant','fixe','INCLUSION'],
        ['jeudi','08:30',45,'Rituels','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
        ['jeudi','09:15',45,'Lecture','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
        ['jeudi','10:15',45,'Phonologie','CP','M. Dupont','enseignant','fixe','ULIS'],
        ['jeudi','11:00',45,'Ecriture','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
        ['jeudi','13:30',45,'Mathematiques','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
        ['jeudi','14:45',45,'Musique','CP','Mme Bernard','enseignant','fixe','INCLUSION'],
        ['vendredi','08:30',45,'Rituels','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
        ['vendredi','09:15',45,'Lecture','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
        ['vendredi','10:15',45,'EPS','CP','M. Petit','enseignant','fixe','INCLUSION'],
        ['vendredi','11:00',45,'Phonologie','CP','M. Dupont','enseignant','fixe','ULIS'],
        ['vendredi','13:30',45,'Mathematiques','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
    ],
    2 => [ // Thomas Moreau CP
        ['lundi','08:30',45,'Rituels','CP','M. Dupont','enseignant','fixe','ULIS'],
        ['lundi','09:15',45,'Langage oral','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
        ['lundi','13:30',45,'Mathematiques','CP','M. Dupont','enseignant','fixe','ULIS'],
        ['lundi','14:45',45,'Arts plastiques','CP','Mme Martin','enseignant','fixe','INCLUSION'],
        ['mardi','08:30',45,'Rituels','CP','M. Dupont','enseignant','fixe','ULIS'],
        ['mardi','09:15',45,'Phonologie','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
        ['mardi','10:15',45,'EPS','CP','M. Petit','enseignant','fixe','INCLUSION'],
        ['mardi','13:30',45,'Mathematiques','CP','M. Dupont','enseignant','fixe','ULIS'],
        ['mardi','14:45',45,'Decouverte monde','CP','Mme Martin','enseignant','fixe','INCLUSION'],
        ['jeudi','08:30',45,'Rituels','CP','M. Dupont','enseignant','fixe','ULIS'],
        ['jeudi','09:15',45,'Langage oral','CP',$defaultAdulte,'enseignant','fixe','ULIS'],
        ['jeudi','13:30',45,'Mathematiques','CP','M. Dupont','enseignant','fixe','ULIS'],
        ['jeudi','14:45',45,'Musique','CP','Mme Bernard','enseignant','fixe','INCLUSION'],
        ['vendredi','08:30',45,'Rituels','CP', $defaultAdulte,'enseignant','fixe','ULIS'],
        ['vendredi','10:15',45,'EPS','CP','M. Petit','enseignant','fixe','INCLUSION'],
    ],
];
// Generer les creneaux template (semaine_id=1) pour tous les eleves
foreach ($template as $eid => $creneaux) {
    foreach ($creneaux as $c) {
        $stmt = $pdo->prepare('INSERT INTO creneaux (eleve_id, semaine_id, jour, heure_debut, duree, matiere, groupe, adulte, role_adulte, type, regroupement_type) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute(array_merge([$eid, null], $c));
    }
}

// Ajouter des creneaux generiques pour les autres eleves (3-12) (semaine_id=NULL = template)
for ($eid = 3; $eid <= 12; $eid++) {
    $groupe = $eid <= 6 ? 'CP-CE1' : ($eid <= 9 ? 'CE1-CE2' : 'CM');
    $creneauxGen = [
        ['lundi','08:30',45,'Rituels',$groupe,$defaultAdulte,'enseignant','fixe','ULIS'],
        ['lundi','09:15',45,'Francais',$groupe,$defaultAdulte,'enseignant','fixe','ULIS'],
        ['lundi','13:30',45,'Mathematiques',$groupe,$defaultAdulte,'enseignant','fixe','ULIS'],
        ['mardi','08:30',45,'Rituels',$groupe,$defaultAdulte,'enseignant','fixe','ULIS'],
        ['mardi','09:15',45,'Francais',$groupe,$defaultAdulte,'enseignant','fixe','ULIS'],
        ['mardi','10:15',45,'EPS',$groupe,'M. Petit','enseignant','fixe','INCLUSION'],
        ['mardi','13:30',45,'Mathematiques',$groupe,$defaultAdulte,'enseignant','fixe','ULIS'],
        ['jeudi','08:30',45,'Rituels',$groupe,$defaultAdulte,'enseignant','fixe','ULIS'],
        ['jeudi','09:15',45,'Francais',$groupe,$defaultAdulte,'enseignant','fixe','ULIS'],
        ['jeudi','13:30',45,'Mathematiques',$groupe,$defaultAdulte,'enseignant','fixe','ULIS'],
        ['vendredi','08:30',45,'Rituels',$groupe,$defaultAdulte,'enseignant','fixe','ULIS'],
        ['vendredi','10:15',45,'EPS',$groupe,'M. Petit','enseignant','fixe','INCLUSION'],
        ['vendredi','13:30',45,'Projet',$groupe,$defaultAdulte,'enseignant','fixe','ULIS'],
    ];
    foreach ($creneauxGen as $c) {
        $stmt = $pdo->prepare('INSERT INTO creneaux (eleve_id, semaine_id, jour, heure_debut, duree, matiere, groupe, adulte, role_adulte, type, regroupement_type) VALUES (?,?,?,?,?,?,?,?,?,?,?)');
        $stmt->execute(array_merge([$eid, null], $c));
    }
}

// === Creneaux PEC (semaine 1) ===
$pecCreneaux = [
    [1, 'lundi', '15:15', 30, 'Orthophonie', 'CP', 'Mme Faure', 'orthophoniste', 'fixe', 'PEC', ''],
    [2, 'lundi', '15:15', 30, 'Orthophonie', 'CP', 'Mme Faure', 'orthophoniste', 'fixe', 'PEC', ''],
    [4, 'mardi', '15:15', 45, 'Psychomotricite', 'CE1', 'CMPP', 'psychomotricien', 'fixe', 'PEC', ''],
    [5, 'jeudi', '14:45', 60, 'SESSAD', 'CE1', 'SESSAD APA 16', 'educateur', 'fixe', 'PEC', ''],
    [6, 'mardi', '15:15', 45, 'Orthophonie', 'CE1', 'CMPP', 'orthophoniste', 'fixe', 'PEC', ''],
    [7, 'lundi', '15:15', 60, 'Kinesitherapie', 'CE2', 'M. Moreau', 'psychomotricien', 'fixe', 'PEC', ''],
    [8, 'jeudi', '15:15', 45, 'Hab. sociales', 'CE2', 'CMPP', 'psychologue', 'fixe', 'PEC', ''],
    [9, 'mardi', '15:15', 30, 'Orthophonie', 'CE2', 'Mme Faure', 'orthophoniste', 'fixe', 'PEC', ''],
    [10, 'jeudi', '11:00', 60, 'Educateur', 'CM', 'S. Dumont', 'educateur', 'fixe', 'PEC', ''],
    [11, 'jeudi', '15:00', 30, 'Psychologue', 'CM', 'Dr Mercier', 'psychologue', 'fixe', 'PEC', ''],
    [12, 'jeudi', '15:15', 45, 'Orthophonie', 'CM', 'SESSAD APA 16', 'orthophoniste', 'fixe', 'PEC', ''],
];
$stmt = $pdo->prepare('INSERT INTO creneaux (eleve_id, semaine_id, jour, heure_debut, duree, matiere, groupe, adulte, role_adulte, type, regroupement_type, commentaire) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)');
foreach ($pecCreneaux as $c) $stmt->execute(array_merge([$c[0], null], array_slice($c, 1)));

// === Propagation template vers toutes les semaines ===
echo "-> Propagation template...\n";
require_once __DIR__ . '/../api/models/Creneau.php';
$semaineIds = $pdo->query('SELECT id FROM semaines WHERE est_vacances = 0 ORDER BY numero')->fetchAll(PDO::FETCH_COLUMN);
foreach ($semaineIds as $sid) {
    // Semaine 1 incluse dans la propagation
    Creneau::copyFromTemplate($sid);
}

// === Variations sur ~30% des semaines ===
echo "-> Variations...\n";
$elevesIds = $pdo->query('SELECT id FROM eleves WHERE actif = 1')->fetchAll(PDO::FETCH_COLUMN);
$count = 0;
foreach ($semaineIds as $sid) {
    $num = $pdo->prepare('SELECT numero FROM semaines WHERE id = ?');
    $num->execute([$sid]);
    $num = (int)$num->fetchColumn();
    $rand = ($num * 7 + 3) % 10;
    if ($rand >= 3) continue;
    $count++;
    $lim = rand(2, 5);
    $smt = $pdo->prepare('SELECT id, eleve_id, jour, heure_debut, duree FROM creneaux WHERE semaine_id = ? ORDER BY RAND() LIMIT ' . $lim);
    $smt->execute([$sid]);
    foreach ($smt->fetchAll() as $c) {
        if ($rand == 0) {
            $nh = date('H:i', strtotime($c['heure_debut']) + 900);
            if ($nh < '16:30') $pdo->prepare('UPDATE creneaux SET heure_debut = ? WHERE id = ?')->execute([$nh, $c['id']]);
        } elseif ($rand == 1) {
            $other = $elevesIds[array_rand($elevesIds)];
            if ($other != $c['eleve_id']) $pdo->prepare('UPDATE creneaux SET eleve_id = ? WHERE id = ?')->execute([$other, $c['id']]);
        } else {
            $eid = $elevesIds[array_rand($elevesIds)];
            $j = $jours[array_rand($jours)];
            $h = ['08:30','09:00','10:15','11:00','13:30','14:45','15:30'][array_rand(range(0,6))];
            $m = ['Sortie scolaire','Projet','Evaluation','Atelier','Intervention'][array_rand(range(0,4))];
            $pdo->prepare("INSERT INTO creneaux (eleve_id, semaine_id, jour, heure_debut, duree, matiere, type, regroupement_type) VALUES (?,?,?,?,?,?,'exception','AUTRE')")
                ->execute([$eid, $sid, $j, $h, rand(1,4)*15, $m]);
        }
    }
    $pdo->prepare('UPDATE semaines SET est_modifiee = 1 WHERE id = ?')->execute([$sid]);
}

// ============================================================
// ETAPE 3 : Dump
// ============================================================
echo "-> Dump mysqldump...\n";
$outPath = __DIR__ . '/../data/calulis-testv5.sql';
$cmd = "mysqldump -u calulis -pcalulis -S /var/run/mysqld/mysqld.sock --complete-insert --create-options --skip-lock-tables calulis 2>/dev/null > " . escapeshellarg($outPath);   // ggignore - mot de passe de demonstration, public et documente (remplace par un mot de passe aleatoire par installation depuis la 1.15.1)
exec($cmd, $output, $code);

if ($code !== 0) {
    echo "   Fallback dump PHP...\n";
    // Dump via PHP
    require_once __DIR__ . '/../api/config.php';
    $pdo2 = getDB();
    $fh = fopen($outPath, 'w');
    fwrite($fh, "-- Calulis, Base de test V5 complete\n");
    fwrite($fh, "-- Generee le " . date('Y-m-d H:i') . "\n\n");
    fwrite($fh, "SET FOREIGN_KEY_CHECKS = 0;\n");
    fwrite($fh, "SET NAMES utf8mb4;\n\n");

    $tables = $pdo2->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
    foreach ($tables as $t) {
        $row = $pdo2->query("SHOW CREATE TABLE `$t`")->fetch();
        fwrite($fh, "DROP TABLE IF EXISTS `$t`;\n");
        fwrite($fh, $row[1] . ";\n\n");
    }
    foreach ($tables as $t) {
        $rows = $pdo2->query("SELECT * FROM `$t`")->fetchAll(PDO::FETCH_ASSOC);
        if (empty($rows)) continue;
        $cols = array_keys($rows[0]);
        $colList = '`' . implode('`, `', $cols) . '`';
        fwrite($fh, "INSERT INTO `$t` ($colList) VALUES\n");
        $chunks = array_chunk($rows, 50);
        foreach ($chunks as $ci => $chunk) {
            $lines = [];
            foreach ($chunk as $r) {
                $vals = [];
                foreach ($cols as $c) {
                    $v = $r[$c];
                    if ($v === null) { $vals[] = 'NULL'; }
                    else { $vals[] = "'" . str_replace(["'", "\n"], ["\\'", "\\n"], $v) . "'"; }
                }
                $lines[] = '(' . implode(', ', $vals) . ')';
            }
            $sep = ($ci < count($chunks) - 1) ? ',' : '';
            fwrite($fh, implode(",\n", $lines) . "$sep\n");
        }
        fwrite($fh, ";\n\n");
    }
    fwrite($fh, "SET FOREIGN_KEY_CHECKS = 1;\n");
    fclose($fh);
}

clearstatcache(true, $outPath);
$size = round(filesize($outPath) / 1024 / 1024, 1);

echo "\n=== OK calulis-testv5.sql genere, $size Mo ===\n";
$checks = ['eleves','adultes','etablissements','adultes_etablissements','classes','reunions','evenements','documents','representants','aesh_eleves','pec_eleves','creneaux','semaines','periodes'];
foreach ($checks as $t) {
    try {
        $cnt = $pdo->query("SELECT COUNT(*) FROM `$t`")->fetchColumn();
        echo "   $t : $cnt\n";
    } catch (\Throwable $e) {
        echo "   $t : ERREUR\n";
    }
}
