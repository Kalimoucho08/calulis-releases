<?php
/** Calulis — Endpoint version (affichée dans le dashboard) */
require_once __DIR__ . '/../config.php';

// Racine d'installation : controllers/ → api/ → app/ → racine (version.json à la racine)
$versionFile = __DIR__ . '/../../../version.json';
$version = [
    'appVersion' => '1.0.4',
    'launcherVersion' => '1.0.1',
    'updatedAt' => null,
];
if (is_file($versionFile)) {
    $raw = @file_get_contents($versionFile);
    $j = $raw ? json_decode($raw, true) : null;
    if (is_array($j)) {
        if (!empty($j['appVersion'])) $version['appVersion'] = $j['appVersion'];
        if (!empty($j['launcherVersion'])) $version['launcherVersion'] = $j['launcherVersion'];
        if (!empty($j['updatedAt'])) $version['updatedAt'] = $j['updatedAt'];
    }
}
jsonResponse($version);
