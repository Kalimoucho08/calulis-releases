<?php
/** Calulis — Controller Pauses (CRUD table pauses, sans sync auto) */
require_once __DIR__ . '/../models/Pause.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

try {
    switch ($method) {
        case 'GET':
            if ($id) {
                $pause = Pause::find($id);
                if (!$pause) jsonError('Pause introuvable', 404);
                jsonResponse($pause);
            }
            $eleveId = isset($_GET['eleve_id']) ? (int)$_GET['eleve_id'] : null;
            jsonResponse(Pause::findAll($eleveId));
            break;

        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (empty($input['nom']) || empty($input['heure_debut']) || empty($input['heure_fin'])) {
                jsonError('nom, heure_debut et heure_fin requis');
            }
            $newId = Pause::create($input);
            jsonResponse(['ok' => true, 'id' => $newId], 201);
            break;

        case 'PUT':
            if (!$id) jsonError('ID requis');
            $input = json_decode(file_get_contents('php://input'), true);
            Pause::update($id, $input);
            jsonResponse(['ok' => true]);
            break;

        case 'DELETE':
            if (!$id) jsonError('ID requis');
            Pause::delete($id);
            jsonResponse(['ok' => true]);
            break;

        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
