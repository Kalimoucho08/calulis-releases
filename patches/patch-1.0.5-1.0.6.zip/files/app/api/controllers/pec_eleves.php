<?php
/** Calulis — Controller PEC Élèves */
require_once __DIR__ . '/../models/PecEleve.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$eleveId = isset($_GET['eleve_id']) ? (int)$_GET['eleve_id'] : null;
$anneeId = isset($_GET['annee_scolaire_id']) ? (int)$_GET['annee_scolaire_id'] : null;

try {
    switch ($method) {

        case 'GET':
            if ($id) {
                $p = PecEleve::find($id);
                if (!$p) jsonError('PEC non trouvé', 404);
                jsonResponse($p);
            }
            if ($eleveId) {
                jsonResponse(PecEleve::getByEleve($eleveId, $anneeId));
            }
            jsonError('eleve_id ou id requis');

            break;
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (empty($input['eleve_id'])) jsonError('eleve_id requis');
            // Injecter annee_scolaire_id depuis le body ou la query string
            if (!isset($input['annee_scolaire_id']) && $anneeId) $input['annee_scolaire_id'] = $anneeId;
            $newId = PecEleve::create($input);
            jsonResponse(['ok' => true, 'id' => $newId], 201);

            break;
        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            if (!$id) jsonError('ID requis');
            if (!isset($input['annee_scolaire_id']) && $anneeId) $input['annee_scolaire_id'] = $anneeId;
            PecEleve::update($id, $input);
            jsonResponse(['ok' => true]);

            break;
        case 'DELETE':
            if ($eleveId) {
                PecEleve::deleteByEleve($eleveId, $anneeId);
                jsonResponse(['ok' => true]);
            }
            if (!$id) jsonError('ID ou eleve_id requis');
            PecEleve::delete($id);
            jsonResponse(['ok' => true]);

            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
