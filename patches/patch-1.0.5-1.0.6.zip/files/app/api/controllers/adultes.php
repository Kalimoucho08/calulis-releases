<?php
/** Calulis — Controller Adultes */
require_once __DIR__ . '/../models/Adulte.php';
require_once __DIR__ . '/../models/AdulteEtablissement.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$anneeId = isset($_GET['annee_scolaire_id']) ? (int)$_GET['annee_scolaire_id'] : null;

try {
    switch ($method) {

        case 'GET':
            if ($id) {
                $a = Adulte::find($id);
                if (!$a) jsonError('Adulte non trouvé', 404);
                $a['liens_etablissements'] = AdulteEtablissement::getByAdulte($id, $anneeId);
                jsonResponse($a);
            }
            // Filtres phase 8 : enseignant_notre, personnel_notre, autres
            $filtre = $_GET['filtre'] ?? '';
            $notreEtab = !empty($_GET['notre_etablissement']) ? (int)$_GET['notre_etablissement'] : null;
            $q = $_GET['q'] ?? '';
            if ($filtre && $notreEtab) {
                $adultes = Adulte::getFiltered($filtre, $notreEtab, $q ?: null);
            } elseif ($q) {
                $adultes = Adulte::search($q);
            } else {
                $adultes = Adulte::all();
            }
            // Attacher les liens établissements en une seule requête (évite N+1)
            $ids = array_map('intval', array_column($adultes, 'id'));
            $liens = AdulteEtablissement::getByAdulteIds($ids, $anneeId);
            foreach ($adultes as &$a) {
                $a['liens_etablissements'] = $liens[(int)$a['id']] ?? [];
            }
            jsonResponse($adultes);

            break;
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (empty($input['nom'])) jsonError('Nom requis');
            $id = Adulte::create($input);
            // Sync junction table
            if (isset($input['liens_etablissements'])) {
                $bodyAnneeId = $input['annee_scolaire_id'] ?? $anneeId;
                AdulteEtablissement::syncForAdulte($id, $input['liens_etablissements'], $bodyAnneeId);
            }
            jsonResponse(['ok' => true, 'id' => $id], 201);

            break;
        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            if (($input['action'] ?? '') === 'reorder' && !empty($input['ordres'])) {
                Adulte::reorder($input['ordres']);
                jsonResponse(['ok' => true]);
            }
            if (!$id) jsonError('ID requis');
            Adulte::update($id, $input);
            // Sync junction table
            if (isset($input['liens_etablissements'])) {
                $bodyAnneeId = $input['annee_scolaire_id'] ?? $anneeId;
                AdulteEtablissement::syncForAdulte($id, $input['liens_etablissements'], $bodyAnneeId);
            }
            jsonResponse(['ok' => true]);

            break;
        case 'DELETE':
            if (!$id) jsonError('ID requis');
            $pdo = getDB();
            $stmt = $pdo->prepare('UPDATE adultes SET actif = 0 WHERE id = :id');
            $stmt->execute(['id' => $id]);
            jsonResponse(['ok' => true]);

            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
