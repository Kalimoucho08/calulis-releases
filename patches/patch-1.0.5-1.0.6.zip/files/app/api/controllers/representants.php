<?php
/** Calulis — Controller Représentants */
require_once __DIR__ . '/../models/Representant.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$eleveId = isset($_GET['eleve_id']) ? (int)$_GET['eleve_id'] : null;

try {
    switch ($method) {

        case 'GET':
            if ($id) {
                $r = Representant::find($id);
                if (!$r) jsonError('Représentant non trouvé', 404);
                jsonResponse($r);
            }
            if ($eleveId) {
                jsonResponse(Representant::getByEleve($eleveId));
            }
            jsonError('eleve_id ou id requis');

            break;
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (empty($input['nom'])) jsonError('Nom requis');
            if (empty($input['eleve_id'])) jsonError('eleve_id requis');
            $id = Representant::create($input);
            jsonResponse(['ok' => true, 'id' => $id], 201);

            break;
        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            if (!$id) jsonError('ID requis');
            Representant::update($id, $input);
            jsonResponse(['ok' => true]);

            break;
        case 'DELETE':
            if ($eleveId) {
                Representant::deleteByEleve($eleveId);
                jsonResponse(['ok' => true]);
            }
            if (!$id) jsonError('ID ou eleve_id requis');
            Representant::delete($id);
            jsonResponse(['ok' => true]);

            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
