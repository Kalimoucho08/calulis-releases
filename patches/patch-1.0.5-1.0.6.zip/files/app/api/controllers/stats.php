<?php
/** Calulis — Controller Statistiques
 *  GET /api/stats.php?section=kpi|inclusion|pec|cantine_transport|mdph|anciennete|ecoles_origine|entrees_sorties|tous
 *  &annee_scolaire_id=N pour filtrer par année
 *
 *  Toutes les stats sont ANNUELLES (pas cumulatives sur plusieurs années).
 *  Sans annee_scolaire_id → utilise l'année active par défaut.
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Stats.php';

$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method !== 'GET') {
        jsonError('GET requis', 405);
    }

    $section = $_GET['section'] ?? 'tous';
    $anneeId = isset($_GET['annee_scolaire_id']) ? (int)$_GET['annee_scolaire_id'] : null;
    $pdo = getDB();

    $data = [];

    if ($section === 'tous' || $section === 'kpi') {
        $data['kpi'] = Stats::kpi($pdo, $anneeId);
    }
    if ($section === 'tous' || $section === 'inclusion') {
        $classeId = isset($_GET['classe_id']) ? (int)$_GET['classe_id'] : null;
        $data['inclusion'] = Stats::inclusion($pdo, $anneeId, $classeId);
    }
    if ($section === 'inclusion_groupe') {
        $classeId = isset($_GET['classe_id']) ? (int)$_GET['classe_id'] : null;
        $data['inclusion_groupe'] = Stats::inclusionGroupe($pdo, $anneeId, $classeId);
    }
    if ($section === 'tous' || $section === 'pec') {
        $data['pec'] = Stats::pec($pdo, $anneeId);
    }
    if ($section === 'tous' || $section === 'cantine_transport') {
        $data['cantine_transport'] = Stats::cantineTransport($pdo, $anneeId);
    }
    if ($section === 'tous' || $section === 'mdph') {
        $data['mdph'] = Stats::mdph($pdo, $anneeId);
    }
    if ($section === 'tous' || $section === 'anciennete') {
        $data['anciennete'] = Stats::anciennete($pdo, $anneeId);
    }
    if ($section === 'tous' || $section === 'ecoles_origine') {
        $data['ecoles_origine'] = Stats::ecolesOrigine($pdo, $anneeId);
    }
    if ($section === 'tous' || $section === 'entrees_sorties') {
        $data['entrees_sorties'] = Stats::entreesSorties($pdo, $anneeId);
    }
    if ($section === 'tous' || $section === 'inclusion_periodes') {
        $data['inclusion_periodes'] = Stats::inclusionPeriodes($pdo, $anneeId);
    }
    if ($section === 'inclusion_eleve_evolution') {
        $eleveId = isset($_GET['eleve_id']) ? (int)$_GET['eleve_id'] : null;
        if (!$eleveId) jsonError('eleve_id requis', 400);
        $data['inclusion_eleve_evolution'] = Stats::inclusionEleveEvolution($pdo, $eleveId);
    }
    if ($section === 'inclusion_eleve_periodes') {
        $eleveId = isset($_GET['eleve_id']) ? (int)$_GET['eleve_id'] : null;
        if (!$eleveId) jsonError('eleve_id requis', 400);
        $data['inclusion_eleve_periodes'] = Stats::inclusionElevePeriodes($pdo, $anneeId, $eleveId);
    }
    if ($section === 'tous' || $section === 'inclusion_semaines') {
        $data['inclusion_semaines'] = Stats::inclusionParSemaine($pdo, $anneeId);
    }
    if ($section === 'tous' || $section === 'evolution') {
        $data['evolution'] = Stats::evolution($pdo, $anneeId);
    }
    if ($section === 'tous' || $section === 'inclusion_tous_eleves_periodes') {
        $data['inclusion_tous_eleves_periodes'] = Stats::inclusionTousElevesPeriodes($pdo, $anneeId);
    }

    jsonResponse($data);

} catch (\Throwable $e) {
    calulis_handle_error($e);
}
