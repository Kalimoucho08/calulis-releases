<?php
/** Calulis — Controller AESH Élèves */
require_once __DIR__ . '/../models/AeshEleve.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$eleveId = isset($_GET['eleve_id']) ? (int)$_GET['eleve_id'] : null;

try {
    switch ($method) {

        case 'GET':
            if ($id) {
                $a = AeshEleve::find($id);
                if (!$a) jsonError('AESH non trouvé', 404);
                jsonResponse($a);
            }
            if ($eleveId) {
                jsonResponse(AeshEleve::getByEleve($eleveId));
            }
            jsonError('eleve_id ou id requis');

            break;
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (empty($input['eleve_id'])) jsonError('eleve_id requis');
            $id = AeshEleve::create($input);
            jsonResponse(['ok' => true, 'id' => $id], 201);

            break;
        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            if (!$id) jsonError('ID requis');
            AeshEleve::update($id, $input);
            jsonResponse(['ok' => true]);

            break;
        case 'DELETE':
            if ($eleveId) {
                AeshEleve::deleteByEleve($eleveId);
                jsonResponse(['ok' => true]);
            }
            if (!$id) jsonError('ID ou eleve_id requis');
            AeshEleve::delete($id);
            jsonResponse(['ok' => true]);

            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
