<?php
/** Calulis — Controller Réunions (CRUD REST) */
require_once __DIR__ . '/../models/Reunion.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$anneeId = isset($_GET['annee_scolaire_id']) ? (int)$_GET['annee_scolaire_id'] : null;

try {
    switch ($method) {

        case 'GET':
            if ($id) {
                $reunion = Reunion::find($id);
                if (!$reunion) jsonError('Réunion non trouvée', 404);
                jsonResponse($reunion);
            }
            if (isset($_GET['eleve_id'])) {
                jsonResponse(Reunion::getByEleve((int)$_GET['eleve_id'], $anneeId));
            }
            if (isset($_GET['upcoming'])) {
                jsonResponse(Reunion::getUpcoming((int)$_GET['upcoming']));
            }
            if (isset($_GET['debut']) && isset($_GET['fin'])) {
                jsonResponse(Reunion::getByPeriode($_GET['debut'], $_GET['fin']));
            }
            if (isset($_GET['adulte'])) {
                jsonResponse(Reunion::getByAdulte($_GET['adulte']));
            }
            jsonResponse(Reunion::all($anneeId));

            break;
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (empty($input['titre'])) jsonError('Titre requis');
            if (empty($input['date_reunion'])) jsonError('Date requise');
            if (empty($input['type'])) jsonError('Type requis');
            if (!isset($input['annee_scolaire_id']) && $anneeId !== null) {
                $input['annee_scolaire_id'] = $anneeId;
            }
            $id = Reunion::create($input);
            jsonResponse(['ok' => true, 'id' => $id], 201);

            break;
        case 'PUT':
            if (!$id) jsonError('ID requis');
            $input = json_decode(file_get_contents('php://input'), true);
            Reunion::update($id, $input);
            jsonResponse(['ok' => true]);

            break;
        case 'DELETE':
            if (!$id) jsonError('ID requis');
            Reunion::delete($id);
            jsonResponse(['ok' => true]);

            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
