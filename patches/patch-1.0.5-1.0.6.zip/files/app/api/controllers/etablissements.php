<?php
/** Calulis — Controller Établissements (CRUD REST) */
require_once __DIR__ . '/../models/Etablissement.php';
require_once __DIR__ . '/../models/AdulteEtablissement.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

try {
    switch ($method) {

        case 'GET':
            if ($id) {
                if (isset($_GET['staff'])) {
                    jsonResponse(Etablissement::getStaff($id));
                } elseif (isset($_GET['intervenants'])) {
                    jsonResponse(Etablissement::getIntervenants($id));
                } elseif (isset($_GET['eleves'])) {
                    jsonResponse(Etablissement::getEleves($id));
                } else {
                    $e = Etablissement::find($id);
                    if (!$e) jsonError('Établissement non trouvé', 404);
                    jsonResponse($e);
                }
            }
            $q = $_GET['q'] ?? '';
            if ($q !== '') {
                jsonResponse(Etablissement::search($q));
            }
            jsonResponse(Etablissement::all(true));

            break;
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (empty($input['nom'])) jsonError('Nom requis');
            $id = Etablissement::create($input);
            jsonResponse(['ok' => true, 'id' => $id], 201);

            break;
        case 'PUT':
            if (!$id) jsonError('ID requis');
            $input = json_decode(file_get_contents('php://input'), true);
            Etablissement::update($id, $input);
            jsonResponse(['ok' => true]);

            break;
        case 'DELETE':
            if (!$id) jsonError('ID requis');
            Etablissement::delete($id);
            jsonResponse(['ok' => true]);

            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
