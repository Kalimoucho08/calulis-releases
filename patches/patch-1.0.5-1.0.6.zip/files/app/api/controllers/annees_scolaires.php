<?php
/** Calulis — Controller Années Scolaires (CRUD REST) */
require_once __DIR__ . '/../models/AnneeScolaire.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

try {
    switch ($method) {

        case 'GET':
            if ($id) {
                $annee = AnneeScolaire::find($id);
                if (!$annee) jsonError('Année non trouvée', 404);
                jsonResponse($annee);
            }
            if (isset($_GET['active'])) {
                $active = AnneeScolaire::getActive();
                jsonResponse($active ?: null);
            }
            jsonResponse(AnneeScolaire::all());

            break;
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (empty($input['nom']) || empty($input['date_debut']) || empty($input['date_fin'])) {
                jsonError('Nom, date_debut et date_fin requis');
            }
            $newId = AnneeScolaire::create($input);
            jsonResponse(['ok' => true, 'id' => $newId], 201);

            break;
        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            if (($input['action'] ?? '') === 'activate' && $id) {
                AnneeScolaire::setActive($id);
                jsonResponse(['ok' => true, 'id' => $id]);
            }
            if (!$id) jsonError('ID requis');
            AnneeScolaire::update($id, $input);
            jsonResponse(['ok' => true]);

            break;
        case 'DELETE':
            if (!$id) jsonError('ID requis');
            AnneeScolaire::delete($id);
            jsonResponse(['ok' => true]);

            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
