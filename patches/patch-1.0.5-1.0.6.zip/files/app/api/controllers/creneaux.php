<?php
/** Calulis — Controller Créneaux */
require_once __DIR__ . '/../models/Creneau.php';
require_once __DIR__ . '/../models/Semaine.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$semaineId = isset($_GET['semaine_id']) ? ($_GET['semaine_id'] === 'null' ? null : (int)$_GET['semaine_id']) : null;

try {
    switch ($method) {
        case 'GET':
            if ($id) {
                // Créneau individuel — pas implémenté, on passe par findBySemaine
                jsonResponse([]);
            }
            if (!empty($_GET['adulte'])) {
                jsonResponse(Creneau::findByAdulte($_GET['adulte'], $semaineId));
            }
            if (!empty($_GET['with_eleves'])) {
                jsonResponse(Creneau::findBySemaineWithEleves($semaineId));
            }
            jsonResponse(Creneau::findBySemaine($semaineId));

            break;
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            // Batch : copier depuis template vers semaine(s)
            if (isset($input['action']) && $input['action'] === 'copy_from_template') {
                if (isset($input['semaine_ids']) && is_array($input['semaine_ids'])) {
                    // Copie batch vers plusieurs semaines
                    $today = date('Y-m-d');
                    $counts = [];
                    foreach ($input['semaine_ids'] as $sid) {
                        $semaine = Semaine::find((int)$sid);
                        if ($semaine && $semaine['date_fin'] >= $today) {
                            $counts[] = Creneau::copyFromTemplate((int)$sid);
                        }
                    }
                    jsonResponse(['ok' => true, 'count' => array_sum($counts), 'semaines' => count($counts)]);
                } else {
                    $count = Creneau::copyFromTemplate((int)$input['semaine_id']);
                    jsonResponse(['ok' => true, 'count' => $count]);
                }
            }
            // Création individuelle
            if (empty($input['eleve_id']) || empty($input['jour']) || empty($input['heure_debut'])) {
                jsonError('eleve_id, jour et heure_debut requis');
            }
            $id = Creneau::create($input);
            jsonResponse(['ok' => true, 'id' => $id], 201);

            break;
        case 'PUT':
            if (!$id) jsonError('ID requis');
            $input = json_decode(file_get_contents('php://input'), true);
            Creneau::update($id, $input);
            jsonResponse(['ok' => true]);

            break;
        case 'DELETE':
            if (!$id) jsonError('ID requis');
            Creneau::delete($id);
            jsonResponse(['ok' => true]);

            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
