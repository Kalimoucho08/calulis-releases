<?php
/** Calulis — Controller Périodes */
require_once __DIR__ . '/../models/Periode.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$anneeId = isset($_GET['annee_scolaire_id']) ? (int)$_GET['annee_scolaire_id'] : null;

try {
    switch ($method) {
        case 'GET':
            if ($id) {
                $periode = Periode::find($id);
                if (!$periode) jsonError('Période non trouvée', 404);
                jsonResponse($periode);
            }
            jsonResponse(Periode::all($anneeId));

            break;
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (empty($input['annee_scolaire_id']) || empty($input['nom'])) {
                jsonError('annee_scolaire_id et nom requis');
            }
            $id = Periode::create($input);
            jsonResponse(['ok' => true, 'id' => $id], 201);

            break;
        case 'PUT':
            if (!$id) jsonError('ID requis');
            $input = json_decode(file_get_contents('php://input'), true);
            Periode::update($id, $input);
            jsonResponse(['ok' => true]);

            break;
        case 'DELETE':
            if (!$id) jsonError('ID requis');
            Periode::delete($id);
            jsonResponse(['ok' => true]);

            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
