<?php
/** Calulis — Controller Paramètres */
require_once __DIR__ . '/../config.php';

$method = $_SERVER['REQUEST_METHOD'];

try {
    $pdo = getDB();

    if ($method === 'GET') {
        $stmt = $pdo->query('SELECT * FROM parametres');
        jsonResponse($stmt->fetchAll());
    }

    if ($method === 'PUT') {
        $input = json_decode(file_get_contents('php://input'), true);
        foreach ($input as $cle => $valeur) {
            $stmt = $pdo->prepare('INSERT INTO parametres (cle, valeur) VALUES (:cle, :valeur) ON DUPLICATE KEY UPDATE valeur=:valeur2, updated_at=CURRENT_TIMESTAMP');
            $json = is_string($valeur) ? $valeur : json_encode($valeur, JSON_UNESCAPED_UNICODE);
            $stmt->execute(['cle' => $cle, 'valeur' => $json, 'valeur2' => $json]);
        }
        // Synchroniser les pauses en créneaux par élève dans le template
        if (isset($input['pauses'])) {
            require_once __DIR__ . '/../models/Creneau.php';
            Creneau::syncPauses($input['pauses']);
        }
        jsonResponse(['ok' => true]);
    }

    jsonError('Méthode non supportée', 405);
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
