<?php
/** Calulis — Controller Semaines */
require_once __DIR__ . '/../models/Semaine.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$anneeId = isset($_GET['annee_scolaire_id']) ? (int)$_GET['annee_scolaire_id'] : null;

try {
    switch ($method) {
        case 'GET':
            if ($id) {
                $s = Semaine::find($id);
                if (!$s) jsonError('Semaine non trouvée', 404);
                jsonResponse($s);
            }
            jsonResponse(Semaine::all($anneeId));

            break;
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (isset($input['action']) && $input['action'] === 'generer_annee') {
                $res = Semaine::genererAnnee(
                    (int)($input['annee_id'] ?? 1),
                    $input['date_debut'],
                    $input['date_fin']
                );
                jsonResponse(['ok' => true, 'semaines' => $res]);
            }
            jsonError('Action inconnue');

            break;
        case 'PUT':
            if (!$id) jsonError('ID requis');
            Semaine::update($id, json_decode(file_get_contents('php://input'), true) ?: []);
            jsonResponse(['ok' => true]);

            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
