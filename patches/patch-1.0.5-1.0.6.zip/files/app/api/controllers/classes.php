<?php
/** Calulis — Controller Classes */
require_once __DIR__ . '/../models/Classe.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

try {
    switch ($method) {

        case 'GET':
            if ($id) {
                $c = Classe::find($id);
                if (!$c) jsonError('Classe non trouvée', 404);
                $c['eleves'] = Classe::getEleves($id);
                if (!empty($c['etablissement_id'])) {
                    $c['aesh_staff'] = Classe::getAeshStaff((int)$c['etablissement_id']);
                }
                jsonResponse($c);
            }
            if (!empty($_GET['etablissement_id'])) {
                jsonResponse(Classe::getByEtablissement((int)$_GET['etablissement_id']));
            }
            jsonResponse(Classe::all());

            break;
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (empty($input['nom'])) jsonError('Nom requis');
            $id = Classe::create($input);
            jsonResponse(['ok' => true, 'id' => $id], 201);

            break;
        case 'PUT':
            if (!$id) jsonError('ID requis');
            $input = json_decode(file_get_contents('php://input'), true);
            Classe::update($id, $input);
            jsonResponse(['ok' => true]);

            break;
        case 'DELETE':
            if (!$id) jsonError('ID requis');
            Classe::delete($id);
            jsonResponse(['ok' => true]);

            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
