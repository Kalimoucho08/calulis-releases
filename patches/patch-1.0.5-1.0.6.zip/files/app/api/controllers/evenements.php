<?php
/** Calulis — Controller Événements (CRUD REST) */
require_once __DIR__ . '/../models/Evenement.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

try {
    switch ($method) {

        case 'GET':
            if ($id) {
                $evenement = Evenement::find($id);
                if (!$evenement) jsonError('Événement non trouvé', 404);
                jsonResponse($evenement);
            }
            if (isset($_GET['date'])) {
                jsonResponse(Evenement::getByDate($_GET['date']));
            }
            if (isset($_GET['debut']) && isset($_GET['fin'])) {
                $anneeId = isset($_GET['annee_scolaire_id']) ? (int)$_GET['annee_scolaire_id'] : null;
                jsonResponse(Evenement::getByPeriode($_GET['debut'], $_GET['fin'], $anneeId));
            }
            // toutes_annees=1 → pas de filtre par année (pour la gestion des événements)
            if (isset($_GET['toutes_annees'])) {
                jsonResponse(Evenement::all(null));
            }
            $anneeId = isset($_GET['annee_scolaire_id']) ? (int)$_GET['annee_scolaire_id'] : null;
            jsonResponse(Evenement::all($anneeId));

            break;
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            // Action spéciale : génération des anniversaires
            if (($input['action'] ?? '') === 'generer_anniversaires') {
                $anneeId = $input['annee_scolaire_id'] ?? ($_GET['annee_scolaire_id'] ?? null);
                if (!$anneeId) jsonError('annee_scolaire_id requis');
                jsonResponse(Evenement::genererAnniversaires((int)$anneeId));
            }
            if (empty($input['nom'])) jsonError('Nom requis');
            // annee_scolaire_id peut être null pour les modèles
            if (!isset($input['annee_scolaire_id'])) $input['annee_scolaire_id'] = null;
            $id = Evenement::create($input);
            jsonResponse(['ok' => true, 'id' => $id], 201);

            break;
        case 'PUT':
            if (!$id) jsonError('ID requis');
            $input = json_decode(file_get_contents('php://input'), true);
            Evenement::update($id, $input);
            jsonResponse(['ok' => true]);

            break;
        case 'DELETE':
            if (!$id) jsonError('ID requis');
            Evenement::delete($id);
            jsonResponse(['ok' => true]);

            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
