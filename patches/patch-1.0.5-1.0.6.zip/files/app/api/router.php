<?php
/**
 * Calulis — Point d'entrée API / Router CLI server
 * Utilisé comme router : php -S localhost:8081 api/router.php
 * Laisse passer les fichiers statiques, route les /api/* vers les controllers
 */
// Serveur intégré : servir les fichiers statiques
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (php_sapi_name() === 'cli-server') {
    $filePath = __DIR__ . '/..' . $uri;
    if ($uri === '/' && is_dir(__DIR__ . '/..')) {
        return false; // index.html automatique
    }
    if (is_file($filePath)) {
        return false; // fichier statique (JS, CSS, etc.)
    }
}

require_once __DIR__ . '/config.php';

// ─────────────────────────────────────────────────────────────────
// Erreurs TOUJOURS lisibles : réponse JSON + log fichier pour le support.
// Sans ça, un fatal PHP répond 500 avec un corps non-JSON et le frontend
// affiche le statusText HTTP brut (ex. « Internal Server Error »).
// ─────────────────────────────────────────────────────────────────

function calulis_log_error(string $msg): void
{
    // Portable : runtime/logs ; dev : même chemin relatif ; prod : error_log PHP
    $dir = getenv('CALULIS_LOG_DIR') ?: (__DIR__ . '/../../runtime/logs');
    $ok = false;
    if (is_dir($dir) || @mkdir($dir, 0777, true)) {
        $ok = @file_put_contents($dir . '/php-error.log',
            '[' . date('c') . '] ' . $msg . PHP_EOL, FILE_APPEND) !== false;
    }
    if (!$ok) { @error_log('calulis: ' . $msg); }
}

function calulis_erreur_json(string $message, string $detail): void
{
    if (headers_sent()) { return; }
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'error'  => $message,
        'detail' => $detail,
    ], JSON_UNESCAPED_UNICODE);
}

// 1) Exceptions non rattrapées (PDO, Error, TypeError…) → JSON + log
set_exception_handler(function (Throwable $e): void {
    calulis_log_error('EXCEPTION ' . get_class($e) . ': ' . $e->getMessage()
        . ' @ ' . $e->getFile() . ':' . $e->getLine() . "
" . $e->getTraceAsString());
    calulis_erreur_json(
        'Erreur technique. Le détail est enregistré dans les logs (bouton « Ouvrir les logs » du lanceur).',
        $e->getMessage()
    );
    exit(1);
});

// 2) Erreurs fatales (fonction inconnue, extension manquante…) → JSON + log
register_shutdown_function(function (): void {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        calulis_log_error('FATAL ' . $err['message'] . ' @ ' . $err['file'] . ':' . $err['line']);
        calulis_erreur_json(
            'Erreur technique du serveur. Le détail est enregistré dans les logs (bouton « Ouvrir les logs » du lanceur).',
            $err['message']
        );
    }
});

// ── CORS restreint aux origines locales (anti-abus : une page externe ne
// doit pas pouvoir lire/appeler l'API locale). L'app elle-même est same-origin.
$calulisOrigin = $_SERVER['HTTP_ORIGIN'] ?? '';
if ($calulisOrigin !== '' && preg_match('#^https?://(127\.0\.0\.1|localhost)(:\d+)?$#', $calulisOrigin)) {
    header('Access-Control-Allow-Origin: ' . $calulisOrigin);
}
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Calulis-App');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

// ── Anti-CSRF : l'API n'accepte que les requêtes portant le jeton interne
// (posé par l'app via le wrapper fetch global). Les requêtes cross-site ne
// peuvent pas poser d'en-tête custom sans préflight (refusé ci-dessus).
if (($_SERVER['HTTP_X_CALULIS_APP'] ?? '') !== '1') {
    jsonError('Requête refusée (jeton anti-CSRF manquant). Rechargez l\'application.', 403);
}

// Router les requêtes /api/* vers les controllers
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = rtrim($uri, '/');

if (strpos($uri, '/api/') === false) {
    if (php_sapi_name() === 'cli-server') return false;
    jsonError('Route non trouvée', 404);
}

$parts = explode('/', trim($uri, '/'));
$resource = $parts[count($parts) - 1] ?? '';
$resource = str_replace('.php', '', $resource);

$controllerFile = __DIR__ . '/controllers/' . $resource . '.php';
if (file_exists($controllerFile)) {
    require_once $controllerFile;
} else {
    jsonError('Route non trouvée : ' . $resource, 404);
}
