<?php
/**
 * Calulis — Configuration base de données
 * Prod : lit les variables d'environnement
 * Local : MariaDB via socket, fallback TCP Windows
 */

// Sécurité : ne pas exposer les erreurs en production
if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1', 'localhost'], true)) {
    @ini_set('display_errors', '0');
    @ini_set('log_errors', '1');
}

// Détection automatique de l'environnement
$isProd = strpos($_SERVER['HTTP_HOST'] ?? '', 'infinityfree.com') !== false
       || strpos($_SERVER['HTTP_HOST'] ?? '', 'free.nf') !== false
       || getenv('CALULIS_ENV') === 'production';

if ($isProd) {
    $dbHost = getenv('CALULIS_DB_HOST');
    $dbName = getenv('CALULIS_DB_NAME');
    $dbUser = getenv('CALULIS_DB_USER');
    $dbPass = getenv('CALULIS_DB_PASS');
    if (!$dbHost || !$dbName || !$dbUser) {
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Configuration base de données manquante. Définir CALULIS_DB_HOST, CALULIS_DB_NAME, CALULIS_DB_USER.']);
        exit;
    }
    $dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
} else {
    // Mode développement
    $dbName = getenv('CALULIS_DB_NAME') ?: 'calulis';
    $dbUser = getenv('CALULIS_DB_USER') ?: 'calulis';
    $dbPass = getenv('CALULIS_DB_PASS') ?: 'calulis';
    $dbSocket = getenv('CALULIS_DB_SOCKET') ?: '/var/run/mysqld/mysqld.sock';
    if (PHP_OS_FAMILY === 'Windows' || !file_exists($dbSocket)) {
        // Windows ou socket indisponible → TCP 127.0.0.1:3307
        $dbPort = getenv('CALULIS_DB_PORT') ?: '3307';
        $dsn = "mysql:host=127.0.0.1;port={$dbPort};dbname={$dbName};charset=utf8mb4";
    } else {
        $dsn = "mysql:unix_socket={$dbSocket};dbname={$dbName};charset=utf8mb4";
    }
}

define('USE_MYSQL', true);
define('DB_DSN', $dsn);
define('DB_USER', $dbUser);
define('DB_PASS', $dbPass);

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(DB_DSN, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }
    return $pdo;
}

function jsonResponse(mixed $data, int $code = 200): never {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function jsonError(string $message, int $code = 400): never {
    jsonResponse(['error' => $message], $code);
}

// ─────────────────────────────────────────────────────────────
// Helpers partagés : erreurs TOUJOURS journalisées + lisibles,
// et troncature défensive des champs varchar courts (anti
// « data too long » qui donnait des erreurs de sauvegarde).
// ─────────────────────────────────────────────────────────────

/** Limites varchar connues (colonnes courtes du schéma) */
const CALULIS_VARCHAR_LIMITS = [
    'ine' => 15, 'classe' => 20, 'niveau_scolaire' => 20, 'aesh_type' => 10,
    'aesh_heures' => 20, 'groupe' => 50, 'temps_scolarisation' => 30,
    'telephone' => 20, 'telephone_urgence' => 20, 'telephone2' => 20,
    'uai' => 8, 'code_postal' => 10, 'departement' => 50,
    'numero_dossier_mdph' => 50, 'numero_dossier' => 50,
    'ase_structure_telephone' => 20, 'ase_referent_telephone' => 20,
    'fonction' => 50, 'role' => 50, 'civilite' => 10, 'lien' => 50,
    'specialite' => 100, 'pec_specialite' => 50, 'pec_organisme' => 50,
    'pec_frequence' => 30, 'pec_lieu' => 50, 'pec_duree' => 20,
];

/** Tronque les champs varchar courts (défensif — jamais d'erreur « data too long ») */
function calulis_truncate(array $data): array {
    foreach (CALULIS_VARCHAR_LIMITS as $f => $len) {
        if (array_key_exists($f, $data) && $data[$f] !== null && $data[$f] !== '') {
            $data[$f] = mb_substr((string)$data[$f], 0, $len);
        }
    }
    return $data;
}

/** Journalise une erreur et répond un message propre (jamais de SQL brut) */
function calulis_handle_error(\Throwable $e): never {
    if (function_exists('calulis_log_error')) {
        calulis_log_error('EXCEPTION ' . get_class($e) . ': ' . $e->getMessage()
            . ' @ ' . $e->getFile() . ':' . $e->getLine());
    } else {
        @error_log('[calulis] ' . get_class($e) . ': ' . $e->getMessage());
    }
    if ($e instanceof \PDOException) {
        jsonError("Les données n'ont pas pu être enregistrées (erreur de base de données). Vérifie les champs saisis puis réessaie. Si le problème persiste, redémarre l'application.", 500);
    }
    jsonError('Erreur technique. Le détail est enregistré dans les logs (bouton « Ouvrir les logs » du lanceur).', 500);
}
