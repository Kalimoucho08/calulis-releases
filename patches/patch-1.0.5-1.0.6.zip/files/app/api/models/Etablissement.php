<?php
/** Calulis — Model Établissement */
require_once __DIR__ . '/../config.php';

class Etablissement {
    public static function all(bool $inclureInactifs = false): array {
        $pdo = getDB();
        $sql = 'SELECT * FROM etablissements';
        if (!$inclureInactifs) $sql .= ' WHERE actif = 1';
        $sql .= ' ORDER BY nom';
        return $pdo->query($sql)->fetchAll();
    }

    public static function search(string $q): array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT * FROM etablissements WHERE actif = 1 AND (nom LIKE :q OR ville LIKE :q2) ORDER BY nom'
        );
        $stmt->execute(['q' => "%$q%", 'q2' => "%$q%"]);
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM etablissements WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO etablissements (
            nom, uai, type, nature, secteur, ville, adresse, telephone, telephone2, email, email2, description, actif
        ) VALUES (
            :nom, :uai, :type, :nature, :secteur, :ville, :adresse, :telephone, :telephone2, :email, :email2, :description, :actif
        )');
        $stmt->execute(self::_bind($data, false));
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $data['id'] = $id;
        $stmt = $pdo->prepare('UPDATE etablissements SET
            nom=:nom, uai=:uai, type=:type, nature=:nature, secteur=:secteur, ville=:ville, adresse=:adresse,
            telephone=:telephone, telephone2=:telephone2, email=:email, email2=:email2,
            description=:description, actif=:actif, updated_at=CURRENT_TIMESTAMP
        WHERE id=:id');
        return $stmt->execute(self::_bind($data));
    }

    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('UPDATE etablissements SET actif = 0 WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    /** Adultes rattachés à cet établissement (enseignants/AESH qui y appartiennent) */
    public static function getStaff(int $id): array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT id, nom, prenom, role FROM adultes WHERE etablissement_id = :id AND actif = 1 ORDER BY nom');
        $stmt->execute(['id' => $id]);
        return $stmt->fetchAll();
    }

    /** Intervenants liés via adultes_etablissements */
    public static function getIntervenants(int $id): array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT a.id, a.nom, a.prenom, a.role, ae.role AS role_lie
             FROM adultes_etablissements ae
             JOIN adultes a ON a.id = ae.adulte_id
             WHERE ae.etablissement_id = :id AND a.actif = 1
             ORDER BY a.nom'
        );
        $stmt->execute(['id' => $id]);
        return $stmt->fetchAll();
    }

    /** Élèves rattachés à cet établissement */
    public static function getEleves(int $id): array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT id, nom, prenom, classe FROM eleves WHERE etablissement_id = :id AND actif = 1 ORDER BY nom, prenom');
        $stmt->execute(['id' => $id]);
        return $stmt->fetchAll();
    }

    public static function stats(): array {
        $pdo = getDB();
        return [
            'total' => (int)$pdo->query('SELECT COUNT(*) FROM etablissements')->fetchColumn(),
            'actifs' => (int)$pdo->query('SELECT COUNT(*) FROM etablissements WHERE actif = 1')->fetchColumn(),
        ];
    }

    private static function _bind(array $data, bool $includeId = true): array {
        $strFields = ['nom','uai','type','nature','secteur','ville','adresse','telephone','telephone2','email','email2','description'];
        $intFields = ['actif'];
        if ($includeId) $intFields[] = 'id';
        $params = [];
        foreach ($strFields as $f) {
            $params[$f] = isset($data[$f]) ? trim($data[$f]) : '';
        }
        $intDefaults = ['actif' => 1];
        foreach ($intFields as $f) {
            $params[$f] = isset($data[$f]) ? (int)$data[$f] : ($intDefaults[$f] ?? 0);
        }
        if ($includeId) $params['id'] = isset($data['id']) ? (int)$data['id'] : 0;
        return $params;
    }
}
