<?php
/** Calulis — Model PEC Élève (multi-année, multi-spécialités) */
require_once __DIR__ . '/../config.php';

class PecEleve {
    /** Toutes les PEC d'un élève (filtrées par année si fournie) */
    public static function getByEleve(int $eleveId, ?int $anneeId = null): array {
        $pdo = getDB();
        $sql = 'SELECT * FROM pec_eleves WHERE eleve_id = :eid';
        $params = ['eid' => $eleveId];
        if ($anneeId !== null) {
            $sql .= ' AND annee_scolaire_id = :aid';
            $params['aid'] = $anneeId;
        }
        $sql .= ' ORDER BY ordre, specialite';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM pec_eleves WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO pec_eleves
            (eleve_id, annee_scolaire_id, specialite, organisme, frequence, lieu, duree, commentaires, ordre)
            VALUES (:eleve_id, :annee_scolaire_id, :specialite, :organisme, :frequence, :lieu, :duree, :commentaires, :ordre)');
        $stmt->execute(self::_bind($data, false));
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $data['id'] = $id;
        $stmt = $pdo->prepare('UPDATE pec_eleves SET
            eleve_id=:eleve_id, annee_scolaire_id=:annee_scolaire_id,
            specialite=:specialite, organisme=:organisme,
            frequence=:frequence, lieu=:lieu, duree=:duree, commentaires=:commentaires,
            ordre=:ordre, updated_at=CURRENT_TIMESTAMP
            WHERE id=:id');
        return $stmt->execute(self::_bind($data));
    }

    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM pec_eleves WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    /** Supprime toutes les PEC d'un élève (pour une année si fournie) */
    public static function deleteByEleve(int $eleveId, ?int $anneeId = null): bool {
        $pdo = getDB();
        $sql = 'DELETE FROM pec_eleves WHERE eleve_id = :eid';
        $params = ['eid' => $eleveId];
        if ($anneeId !== null) {
            $sql .= ' AND annee_scolaire_id = :aid';
            $params['aid'] = $anneeId;
        }
        $stmt = $pdo->prepare($sql);
        return $stmt->execute($params);
    }

    /** Stats PEC : comptage par spécialité + noms élèves (filtré par année) */
    public static function statsParSpecialite(?int $anneeId): array {
        $pdo = getDB();
        $sql = "SELECT p.specialite, p.organisme, COUNT(DISTINCT p.eleve_id) AS nb_eleves,
                GROUP_CONCAT(DISTINCT CONCAT(e.prenom, ' ', e.nom) ORDER BY e.nom SEPARATOR ', ') AS eleves_noms
                FROM pec_eleves p
                JOIN eleves e ON e.id = p.eleve_id
                WHERE p.specialite IS NOT NULL AND p.specialite != ''";
        $params = [];
        if ($anneeId !== null) {
            $sql .= ' AND p.annee_scolaire_id = ?';
            $params[] = $anneeId;
        }
        $sql .= ' GROUP BY p.specialite, p.organisme ORDER BY nb_eleves DESC';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    private static function _bind(array $data, bool $includeId = true): array {
        $strFields = ['specialite', 'organisme', 'frequence', 'lieu', 'duree', 'commentaires'];
        $intFields = ['eleve_id', 'annee_scolaire_id', 'ordre'];
        if ($includeId) $intFields[] = 'id';
        $params = [];
        foreach ($strFields as $f) {
            $params[$f] = isset($data[$f]) ? trim($data[$f]) : '';
        }
        $intDefaults = ['eleve_id' => 0, 'annee_scolaire_id' => null, 'ordre' => 0];
        foreach ($intFields as $f) {
            $params[$f] = isset($data[$f]) && $data[$f] !== '' && $data[$f] !== null
                ? (int)$data[$f]
                : ($intDefaults[$f] ?? null);
        }
        if ($includeId) $params['id'] = isset($data['id']) ? (int)$data['id'] : 0;
        return $params;
    }
}
