<?php
/** Calulis — Model Créneau */
require_once __DIR__ . '/../config.php';

class Creneau {

    public static function findBySemaine(?int $semaineId): array {
        $pdo = getDB();
        if ($semaineId === null) {
            $stmt = $pdo->query('SELECT * FROM creneaux WHERE semaine_id IS NULL ORDER BY jour, heure_debut');
        } else {
            $stmt = $pdo->prepare('SELECT * FROM creneaux WHERE semaine_id = :sid ORDER BY jour, heure_debut');
            $stmt->execute(['sid' => $semaineId]);
        }
        return $stmt->fetchAll();
    }

    /** Comme findBySemaine, mais avec LEFT JOIN eleves pour obtenir les noms */
    public static function findBySemaineWithEleves(?int $semaineId): array {
        $pdo = getDB();
        $sql = 'SELECT c.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom, e.classe AS eleve_classe
                FROM creneaux c
                LEFT JOIN eleves e ON c.eleve_id = e.id';
        if ($semaineId === null) {
            $stmt = $pdo->query($sql . ' WHERE c.semaine_id IS NULL ORDER BY c.jour, c.heure_debut');
        } else {
            $stmt = $pdo->prepare($sql . ' WHERE c.semaine_id = :sid ORDER BY c.jour, c.heure_debut');
            $stmt->execute(['sid' => $semaineId]);
        }
        return $stmt->fetchAll();
    }

    public static function findByAdulte(string $adulteNom, ?int $semaineId = null): array {
        $pdo = getDB();
        $pattern = '%' . addcslashes($adulteNom, '%_');
        if ($semaineId === null) {
            $stmt = $pdo->prepare(
                'SELECT c.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
                 FROM creneaux c
                 LEFT JOIN eleves e ON c.eleve_id = e.id
                 WHERE c.adulte LIKE :pattern AND c.semaine_id IS NULL
                 ORDER BY c.jour, c.heure_debut'
            );
            $stmt->execute(['pattern' => $pattern]);
        } else {
            $stmt = $pdo->prepare(
                'SELECT c.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
                 FROM creneaux c
                 LEFT JOIN eleves e ON c.eleve_id = e.id
                 WHERE c.adulte LIKE :pattern AND c.semaine_id = :sid
                 ORDER BY c.jour, c.heure_debut'
            );
            $stmt->execute(['pattern' => $pattern, 'sid' => $semaineId]);
        }
        return $stmt->fetchAll();
    }

    public static function findByEleve(int $eleveId, ?int $semaineId = null): array {
        $pdo = getDB();
        if ($semaineId === null) {
            $stmt = $pdo->prepare('SELECT * FROM creneaux WHERE eleve_id = :eid AND semaine_id IS NULL ORDER BY jour, heure_debut');
            $stmt->execute(['eid' => $eleveId]);
        } else {
            $stmt = $pdo->prepare('SELECT * FROM creneaux WHERE eleve_id = :eid AND semaine_id = :sid ORDER BY jour, heure_debut');
            $stmt->execute(['eid' => $eleveId, 'sid' => $semaineId]);
        }
        return $stmt->fetchAll();
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO creneaux (
            eleve_id, semaine_id, jour, heure_debut, duree, matiere, groupe, adulte,
            role_adulte, type, regroupement_type, couleur_override, commentaire
        ) VALUES (
            :eleve_id, :semaine_id, :jour, :heure_debut, :duree, :matiere, :groupe, :adulte,
            :role_adulte, :type, :regroupement_type, :couleur_override, :commentaire
        )');
        $stmt->execute(self::_bind($data));
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $data['id'] = $id;
        $stmt = $pdo->prepare('UPDATE creneaux SET
            eleve_id=:eleve_id, semaine_id=:semaine_id, jour=:jour, heure_debut=:heure_debut,
            duree=:duree, matiere=:matiere, groupe=:groupe, adulte=:adulte, role_adulte=:role_adulte,
            type=:type, regroupement_type=:regroupement_type,
            couleur_override=:couleur_override, commentaire=:commentaire, updated_at=CURRENT_TIMESTAMP
        WHERE id=:id');
        return $stmt->execute(self::_bind($data, true));
    }

    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM creneaux WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    /** Copie les créneaux de la semaine type vers une semaine réelle (remplacement) */
    public static function copyFromTemplate(int $semaineId): int {
        $pdo = getDB();
        // Supprimer les créneaux existants de la semaine cible
        $pdo->prepare('DELETE FROM creneaux WHERE semaine_id = :sid')->execute(['sid' => $semaineId]);
        // Copier depuis le template
        $stmt = $pdo->query('SELECT * FROM creneaux WHERE semaine_id IS NULL');
        $template = $stmt->fetchAll();
        $count = 0;
        $insert = $pdo->prepare('INSERT INTO creneaux (
            eleve_id, semaine_id, jour, heure_debut, duree, matiere, groupe, adulte,
            role_adulte, type, regroupement_type, couleur_override, commentaire
        ) VALUES (
            :eleve_id, :semaine_id, :jour, :heure_debut, :duree, :matiere, :groupe, :adulte,
            :role_adulte, :type, :regroupement_type, :couleur_override, :commentaire
        )');
        foreach ($template as $c) {
            $c['semaine_id'] = $semaineId;
            unset($c['id'], $c['created_at'], $c['updated_at']);
            $insert->execute(self::_bind($c));
            $count++;
        }
        return $count;
    }

    /** Synchronise les pauses : crée/supprime les créneaux pause du template pour chaque élève actif */
    public static function syncPauses(array $pauses): void {
        $pdo = getDB();
        $pdo->beginTransaction();
        try {
        // Supprimer les créneaux pause existants du template
        $pdo->exec("DELETE FROM creneaux WHERE semaine_id IS NULL AND type = 'pause'");

        // Récupérer les élèves actifs
        $eleves = $pdo->query('SELECT id FROM eleves WHERE actif = 1')->fetchAll();

        $insert = $pdo->prepare('INSERT INTO creneaux (
            eleve_id, semaine_id, jour, heure_debut, duree, matiere, groupe, adulte,
            role_adulte, type, regroupement_type, couleur_override, commentaire
        ) VALUES (
            :eleve_id, NULL, :jour, :heure_debut, :duree, :matiere, :groupe, :adulte,
            :role_adulte, :type, :regroupement_type, :couleur_override, :commentaire
        )');

        $jours = ['lundi', 'mardi', 'jeudi', 'vendredi'];
        $stmt = $pdo->query("SELECT valeur FROM parametres WHERE cle = 'jours_affiches'");
        if ($row = $stmt->fetch()) {
            $cfg = json_decode($row['valeur'], true);
            if (is_array($cfg) && count($cfg) > 0) $jours = $cfg;
        }

        foreach ($pauses as $pause) {
            if (empty($pause['actif'])) continue;
            $debut = $pause['heure_debut'];
            $fin = $pause['heure_fin'];
            $duree = (strtotime($fin) - strtotime($debut)) / 60;
            if ($duree <= 0) continue;

            foreach ($eleves as $eleve) {
                foreach ($jours as $jour) {
                    $insert->execute([
                        'eleve_id' => $eleve['id'],
                        'jour' => $jour,
                        'heure_debut' => $debut,
                        'duree' => $duree,
                        'matiere' => $pause['nom'] ?? 'Pause',
                        'groupe' => null,
                        'adulte' => null,
                        'role_adulte' => null,
                        'type' => 'pause',
                        'regroupement_type' => 'AUTRE',
                        'couleur_override' => '#e8e8e8',
                        'commentaire' => null,
                    ]);
                }
            }
        }
        $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    private static function _bind(array $data, bool $includeId = false): array {
        $strFields = ['jour','heure_debut','matiere','groupe','adulte','role_adulte','type','regroupement_type','couleur_override','commentaire'];
        $intFields = ['eleve_id','semaine_id','duree'];
        $params = [];
        foreach ($strFields as $f) {
            $params[$f] = isset($data[$f]) ? trim($data[$f]) : null;
        }
        foreach ($intFields as $f) {
            $params[$f] = isset($data[$f]) ? (int)$data[$f] : null;
        }
        if ($includeId) $params['id'] = (int)$data['id'];
        return $params;
    }
}
