<?php
/** Calulis — Model Adulte */
require_once __DIR__ . '/../config.php';

class Adulte {
    public static function all(): array {
        $pdo = getDB();
        return $pdo->query('SELECT a.*, c.nom AS classe_nom, c.id AS classe_id
            FROM adultes a
            LEFT JOIN classes c ON c.enseignant_id = a.id AND c.actif = 1
            WHERE a.actif = 1 ORDER BY a.ordre, a.nom')->fetchAll();
    }

    /** Recherche filtrée par catégorie (enseignant_notre, personnel_notre, autres) + recherche textuelle */
    public static function getFiltered(?string $filtre = null, ?int $notreEtabId = null, ?string $q = null): array {
        $pdo = getDB();
        $sql = "SELECT a.*, c.nom AS classe_nom, c.id AS classe_id
                FROM adultes a
                LEFT JOIN classes c ON c.enseignant_id = a.id AND c.actif = 1
                WHERE a.actif = 1";
        $params = [];

        if ($filtre && $notreEtabId) {
            if ($filtre === 'enseignant_notre') {
                $sql .= " AND a.role = 'enseignant' AND (a.etablissement_id = :ne1 OR EXISTS (SELECT 1 FROM adultes_etablissements ae WHERE ae.adulte_id = a.id AND ae.etablissement_id = :ne2))";
                $params['ne1'] = $notreEtabId;
                $params['ne2'] = $notreEtabId;
            } elseif ($filtre === 'personnel_notre') {
                $sql .= " AND a.role != 'enseignant' AND (a.etablissement_id = :ne1 OR EXISTS (SELECT 1 FROM adultes_etablissements ae WHERE ae.adulte_id = a.id AND ae.etablissement_id = :ne2))";
                $params['ne1'] = $notreEtabId;
                $params['ne2'] = $notreEtabId;
            } elseif ($filtre === 'autres') {
                $sql .= " AND (a.etablissement_id IS NULL OR a.etablissement_id != :ne1) AND NOT EXISTS (SELECT 1 FROM adultes_etablissements ae WHERE ae.adulte_id = a.id AND ae.etablissement_id = :ne2)";
                $params['ne1'] = $notreEtabId;
                $params['ne2'] = $notreEtabId;
            }
        }

        if ($q) {
            $sql .= " AND (a.nom LIKE :q1 OR a.prenom LIKE :q2)";
            $safe = addcslashes($q, '%_');
            $params['q1'] = "%$safe%";
            $params['q2'] = "%$safe%";
        }

        $sql .= " ORDER BY FIELD(a.role,'enseignant','aeshco','aeshi','aeshm','specialiste','educateur','assistant_familial','autre'), a.ordre, a.nom";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Recherche par nom/prénom */
    public static function search(string $q): array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT a.*, c.nom AS classe_nom, c.id AS classe_id
             FROM adultes a
             LEFT JOIN classes c ON c.enseignant_id = a.id AND c.actif = 1
             WHERE a.actif = 1 AND (a.nom LIKE :q OR a.prenom LIKE :q2)
             ORDER BY a.ordre, a.nom'
        );
        $safe = addcslashes($q, '%_');
        $stmt->execute(['q' => "%$safe%", 'q2' => "%$safe%"]);
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM adultes WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Migre : insère les adultes manquants depuis les créneaux */
    public static function syncFromCreneaux(): int {
        $pdo = getDB();
        $stmt = $pdo->query("SELECT DISTINCT adulte, role_adulte FROM creneaux WHERE adulte IS NOT NULL AND adulte != ''");
        $rows = $stmt->fetchAll();
        $count = 0;
        $insert = $pdo->prepare('INSERT IGNORE INTO adultes (nom, role, ordre) VALUES (:nom, :role, (SELECT COALESCE(MAX(ordre),0)+1 FROM adultes))');
        foreach ($rows as $r) {
            $nom = trim($r['adulte']);
            $role = $r['role_adulte'] ?? '';
            if ($nom === '') continue;
            $insert->execute(['nom' => $nom, 'role' => $role]);
            if ($insert->rowCount() > 0) $count++;
        }
        return $count;
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO adultes (nom, prenom, civilite, role, fonction, telephone, email, etablissement_id, commentaires)
            VALUES (:nom, :prenom, :civilite, :role, :fonction, :telephone, :email, :etablissement_id, :commentaires)');
        $params = self::_bind($data, false);
        unset($params['ordre'], $params['actif']);
        $stmt->execute($params);
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $data['id'] = $id;
        $stmt = $pdo->prepare('UPDATE adultes SET
            nom=:nom, prenom=:prenom, civilite=:civilite, role=:role, fonction=:fonction, telephone=:telephone, email=:email,
            etablissement_id=:etablissement_id, commentaires=:commentaires,
            ordre=:ordre, actif=:actif, updated_at=CURRENT_TIMESTAMP
        WHERE id=:id');
        return $stmt->execute(self::_bind($data));
    }

    public static function reorder(array $ordres): bool {
        $pdo = getDB();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('UPDATE adultes SET ordre = :ordre WHERE id = :id');
            foreach ($ordres as $o) {
                $stmt->execute(['id' => (int)$o['id'], 'ordre' => (int)$o['ordre']]);
            }
            $pdo->commit();
            return true;
        } catch (\Exception $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    private static function _bind(array $data, bool $includeId = true): array {
        $strFields = ['nom', 'prenom', 'civilite', 'role', 'fonction', 'telephone', 'email', 'commentaires', 'etablissement_id'];
        $intFields = ['ordre', 'actif'];
        if ($includeId) $intFields[] = 'id';
        $params = [];
        foreach ($strFields as $f) {
            $params[$f] = isset($data[$f]) ? trim($data[$f]) : '';
        }
        $intDefaults = ['ordre' => 0, 'actif' => 1, 'id' => 0];
        foreach ($intFields as $f) {
            $params[$f] = isset($data[$f]) ? (int)$data[$f] : ($intDefaults[$f] ?? 0);
        }
        // etablissement_id : string → nullable int
        if ($params['etablissement_id'] !== '') $params['etablissement_id'] = (int)$params['etablissement_id'];
        else $params['etablissement_id'] = null;
        if ($includeId) $params['id'] = isset($data['id']) ? (int)$data['id'] : 0;
        return $params;
    }
}
