<?php
/** Calulis — Model Pause */
require_once __DIR__ . '/../config.php';

class Pause {

    /** Récupère toutes les pauses (avec filtre optionnel eleve_id) */
    public static function findAll(?int $eleveId = null): array {
        $pdo = getDB();
        if ($eleveId !== null) {
            $stmt = $pdo->prepare('SELECT * FROM pauses WHERE actif = 1 AND (eleve_id = :eid OR eleve_id IS NULL) ORDER BY ordre, heure_debut');
            $stmt->execute(['eid' => $eleveId]);
        } else {
            $stmt = $pdo->query('SELECT * FROM pauses WHERE actif = 1 ORDER BY ordre, heure_debut');
        }
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM pauses WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO pauses (nom, heure_debut, heure_fin, couleur, actif, jours, ordre, eleve_id)
            VALUES (:nom, :heure_debut, :heure_fin, :couleur, :actif, :jours, :ordre, :eleve_id)');
        $stmt->execute(self::_bind($data));
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $data['id'] = $id;
        $stmt = $pdo->prepare('UPDATE pauses SET
            nom=:nom, heure_debut=:heure_debut, heure_fin=:heure_fin,
            couleur=:couleur, actif=:actif, jours=:jours, ordre=:ordre, eleve_id=:eleve_id
        WHERE id=:id');
        return $stmt->execute(self::_bind($data, true));
    }

    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM pauses WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    private static function _bind(array $data, bool $includeId = false): array {
        $params = [
            'nom'         => trim($data['nom'] ?? 'Pause'),
            'heure_debut' => $data['heure_debut'] ?? '00:00',
            'heure_fin'   => $data['heure_fin'] ?? '00:00',
            'couleur'     => $data['couleur'] ?? '#e0e0e0',
            'actif'       => isset($data['actif']) ? (int)$data['actif'] : 1,
            'jours'       => $data['jours'] ?? 'lundi,mardi,jeudi,vendredi',
            'ordre'       => isset($data['ordre']) ? (int)$data['ordre'] : 0,
            'eleve_id'    => isset($data['eleve_id']) && $data['eleve_id'] !== '' ? (int)$data['eleve_id'] : null,
        ];
        if ($includeId) $params['id'] = (int)$data['id'];
        return $params;
    }
}
