<?php
/** Calulis — Model Document (multi-année) */
require_once __DIR__ . '/../config.php';

class Document {
    /** Liste tous les documents (filtrés par année si fournie) */
    public static function all(?int $anneeId = null): array {
        $pdo = getDB();
        $sql = 'SELECT d.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
                FROM documents d
                LEFT JOIN eleves e ON d.eleve_id = e.id';
        $params = [];
        if ($anneeId !== null) {
            $sql .= ' WHERE d.annee_scolaire_id = :annee_id';
            $params['annee_id'] = $anneeId;
        }
        $sql .= ' ORDER BY d.date_document DESC, d.nom';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Trouve un document par ID */
    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT d.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
             FROM documents d
             LEFT JOIN eleves e ON d.eleve_id = e.id
             WHERE d.id = :id'
        );
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Documents liés à un élève */
    public static function getByEleve(int $eleveId, ?int $anneeId = null): array {
        $pdo = getDB();
        $sql = 'SELECT d.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
                FROM documents d
                LEFT JOIN eleves e ON d.eleve_id = e.id
                WHERE d.eleve_id = :eleveId';
        $params = ['eleveId' => $eleveId];
        if ($anneeId !== null) {
            $sql .= ' AND d.annee_scolaire_id = :annee_id';
            $params['annee_id'] = $anneeId;
        }
        $sql .= ' ORDER BY d.date_document DESC, d.nom';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Documents liés à une réunion */
    public static function getByReunion(int $reunionId): array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT d.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
             FROM documents d
             LEFT JOIN eleves e ON d.eleve_id = e.id
             WHERE d.reunion_id = :reunionId
             ORDER BY d.date_document DESC, d.nom'
        );
        $stmt->execute(['reunionId' => $reunionId]);
        return $stmt->fetchAll();
    }

    /** Crée un document */
    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO documents (
            nom, type, eleve_id, reunion_id, date_document, version,
            statut, reference_externe, notes, annee_scolaire_id
        ) VALUES (
            :nom, :type, :eleve_id, :reunion_id, :date_document, :version,
            :statut, :reference_externe, :notes, :annee_scolaire_id
        )');
        $stmt->execute(self::_bind($data, false));
        return (int)$pdo->lastInsertId();
    }

    /** Met à jour un document */
    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $existing = self::find($id);
        if (!$existing) return false;
        $data = array_merge($existing, $data);
        $data['id'] = $id;
        $stmt = $pdo->prepare('UPDATE documents SET
            nom=:nom, type=:type, eleve_id=:eleve_id, reunion_id=:reunion_id,
            date_document=:date_document, version=:version,
            statut=:statut, reference_externe=:reference_externe, notes=:notes,
            annee_scolaire_id=:annee_scolaire_id,
            updated_at=CURRENT_TIMESTAMP
        WHERE id=:id');
        return $stmt->execute(self::_bind($data));
    }

    /** Supprime un document */
    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM documents WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    /** Compteur pour le dashboard */
    public static function count(?int $anneeId = null): int {
        $pdo = getDB();
        if ($anneeId !== null) {
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM documents WHERE annee_scolaire_id = :aid');
            $stmt->execute(['aid' => $anneeId]);
            return (int)$stmt->fetchColumn();
        }
        return (int)$pdo->query('SELECT COUNT(*) FROM documents')->fetchColumn();
    }

    /** Lie les champs aux paramètres SQL */
    private static function _bind(array $data, bool $includeId = true): array {
        $strFields = ['nom', 'type', 'date_document', 'version',
            'statut', 'reference_externe', 'notes'];
        $intFields = ['eleve_id', 'reunion_id', 'annee_scolaire_id'];
        if ($includeId) $intFields[] = 'id';
        $params = [];
        foreach ($strFields as $f) {
            $params[$f] = isset($data[$f]) ? trim((string)$data[$f]) : null;
        }
        $intDefaults = ['eleve_id' => null, 'reunion_id' => null, 'annee_scolaire_id' => null, 'id' => 0];
        foreach ($intFields as $f) {
            $params[$f] = isset($data[$f]) && $data[$f] !== '' && $data[$f] !== null
                ? (int)$data[$f]
                : ($intDefaults[$f] ?? null);
        }
        if ($includeId) $params['id'] = isset($data['id']) ? (int)$data['id'] : 0;
        return $params;
    }
}
