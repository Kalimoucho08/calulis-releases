<?php
/** Calulis — Modèle Classe */
require_once __DIR__ . '/../../api/config.php';

class Classe
{
    public static function all(): array
    {
        $pdo = getDB();
        return $pdo->query("SELECT c.*, a.nom as enseignant_nom, a.prenom as enseignant_prenom, a.role as enseignant_role, a.fonction as enseignant_fonction, e.nom as etablissement_nom
            FROM classes c LEFT JOIN adultes a ON c.enseignant_id = a.id LEFT JOIN etablissements e ON c.etablissement_id = e.id
            WHERE c.actif = 1 ORDER BY c.nom")->fetchAll();
    }

    public static function find(int $id): ?array
    {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT c.*, a.nom as enseignant_nom, a.prenom as enseignant_prenom, a.role as enseignant_role, a.fonction as enseignant_fonction, e.nom as etablissement_nom
            FROM classes c LEFT JOIN adultes a ON c.enseignant_id = a.id LEFT JOIN etablissements e ON c.etablissement_id = e.id
            WHERE c.id = :id");
        $stmt->execute(['id' => $id]);
        $r = $stmt->fetch();
        return $r ?: null;
    }

    public static function getByEtablissement(int $etabId): array
    {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT * FROM classes WHERE etablissement_id = :eid AND actif = 1 ORDER BY nom");
        $stmt->execute(['eid' => $etabId]);
        return $stmt->fetchAll();
    }

    public static function getByNiveau(string $niveau): array
    {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT * FROM classes WHERE actif = 1 AND niveaux LIKE :n ORDER BY nom");
        $stmt->execute(['n' => '%"' . $niveau . '"%']);
        return $stmt->fetchAll();
    }

    public static function getEleves(int $id): array
    {
        $pdo = getDB();
        // Détecter si c'est le dispositif ULIS (3+ niveaux)
        $c = $pdo->prepare("SELECT niveaux FROM classes WHERE id = :id");
        $c->execute(['id' => $id]);
        $niveaux = json_decode($c->fetchColumn() ?: '[]', true) ?: [];

        if (count($niveaux) >= 3) {
            // Dispositif ULIS : tous les élèves ULIS
            $stmt = $pdo->query("SELECT id, nom, prenom, classe, groupe, ulis, actif FROM eleves WHERE ulis = 1 AND actif = 1 ORDER BY nom, prenom");
        } else {
            $stmt = $pdo->prepare("SELECT id, nom, prenom, classe, groupe, ulis, actif FROM eleves WHERE classe_id = :cid ORDER BY nom, prenom");
            $stmt->execute(['cid' => $id]);
        }
        return $stmt->fetchAll();
    }

    public static function getAeshStaff(int $etablissementId): array
    {
        $pdo = getDB();
        // Tous les élèves ULIS actifs
        $eleves = $pdo->query("SELECT id, nom, prenom FROM eleves WHERE actif = 1 AND ulis = 1 ORDER BY nom")->fetchAll();
        $elevesMap = [];
        foreach ($eleves as $e) $elevesMap[$e['id']] = $e;

        // AESH rattachés à l'établissement
        $stmt = $pdo->prepare("SELECT id, nom, prenom, role, telephone, email FROM adultes WHERE role IN ('aeshco','aeshi') AND etablissement_id = :eid AND actif = 1 ORDER BY role, nom");
        $stmt->execute(['eid' => $etablissementId]);
        $aesh = $stmt->fetchAll();

        // Pour chaque AESH, chercher les élèves via aesh_eleves (match sur prénom)
        foreach ($aesh as &$a) {
            $stmt2 = $pdo->prepare("SELECT ae.type, ae.heures, ae.mutualise_avec, ae.eleve_id
                FROM aesh_eleves ae
                WHERE ae.nom LIKE CONCAT('%', :prenom, '%')");
            $stmt2->execute(['prenom' => $a['prenom']]);
            $liens = $stmt2->fetchAll();
            $a['eleves'] = [];
            foreach ($liens as $l) {
                if (isset($elevesMap[$l['eleve_id']])) {
                    $a['eleves'][] = array_merge($elevesMap[$l['eleve_id']], [
                        'type_aesh' => $l['type'],
                        'heures' => $l['heures'],
                    ]);
                }
            }
        }
        return $aesh;
    }

    public static function create(array $data): int
    {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare("INSERT INTO classes (nom, niveaux, enseignant_id, etablissement_id) VALUES (:nom, :niveaux, :enseignant_id, :etablissement_id)");
        $stmt->execute(self::_bind($data, ['nom', 'niveaux', 'enseignant_id', 'etablissement_id']));
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): void
    {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $data['id'] = $id;
        $stmt = $pdo->prepare("UPDATE classes SET nom=:nom, niveaux=:niveaux, enseignant_id=:enseignant_id, etablissement_id=:etablissement_id, updated_at=CURRENT_TIMESTAMP WHERE id=:id");
        $stmt->execute(self::_bind($data));
    }

    public static function delete(int $id): void
    {
        $pdo = getDB();
        $pdo->prepare("UPDATE classes SET actif = 0 WHERE id = :id")->execute(['id' => $id]);
    }

    private static function _bind(array $d, ?array $onlyFields = null): array
    {
        $niveaux = $d['niveaux'] ?? [];
        if (is_string($niveaux)) {
            $decoded = json_decode($niveaux, true);
            $niveaux = is_array($decoded) ? $decoded : [];
        }
        $all = [
            'id' => $d['id'] ?? null,
            'nom' => $d['nom'] ?? '',
            'niveaux' => json_encode($niveaux, JSON_UNESCAPED_UNICODE),
            'enseignant_id' => !empty($d['enseignant_id']) ? (int)$d['enseignant_id'] : null,
            'etablissement_id' => !empty($d['etablissement_id']) ? (int)$d['etablissement_id'] : null,
        ];
        if ($onlyFields !== null) {
            return array_intersect_key($all, array_flip($onlyFields));
        }
        return $all;
    }
}
