<?php
/** Calulis — Model Période */
require_once __DIR__ . '/../config.php';

class Periode {

    public static function all(?int $anneeId = null): array {
        $pdo = getDB();
        if ($anneeId) {
            $stmt = $pdo->prepare('SELECT * FROM periodes WHERE annee_scolaire_id = :aid ORDER BY ordre');
            $stmt->execute(['aid' => $anneeId]);
        } else {
            $stmt = $pdo->query('SELECT * FROM periodes ORDER BY annee_scolaire_id, ordre');
        }
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM periodes WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO periodes (annee_scolaire_id, nom, date_debut, date_fin, ordre) VALUES (:annee_scolaire_id, :nom, :date_debut, :date_fin, :ordre)');
        $stmt->execute([
            'annee_scolaire_id' => $data['annee_scolaire_id'],
            'nom' => $data['nom'],
            'date_debut' => $data['date_debut'],
            'date_fin' => $data['date_fin'],
            'ordre' => $data['ordre'] ?? 0,
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('UPDATE periodes SET nom=:nom, date_debut=:date_debut, date_fin=:date_fin, ordre=:ordre, updated_at=CURRENT_TIMESTAMP WHERE id=:id');
        return $stmt->execute([
            'id' => $id,
            'nom' => $data['nom'],
            'date_debut' => $data['date_debut'],
            'date_fin' => $data['date_fin'],
            'ordre' => $data['ordre'] ?? 0,
        ]);
    }

    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM periodes WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }
}
