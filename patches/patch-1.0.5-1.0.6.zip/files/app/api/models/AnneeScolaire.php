<?php
/** Calulis — Model Année Scolaire */
require_once __DIR__ . '/../config.php';

class AnneeScolaire {
    /** Liste toutes les années, triées par date_debut DESC */
    public static function all(): array {
        $pdo = getDB();
        return $pdo->query('SELECT * FROM annees_scolaires ORDER BY date_debut DESC')->fetchAll();
    }

    /** Trouve une année par ID */
    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM annees_scolaires WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Récupère l'année active */
    public static function getActive(): ?array {
        $pdo = getDB();
        $stmt = $pdo->query('SELECT * FROM annees_scolaires WHERE est_active = 1 LIMIT 1');
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Crée une année, retourne l'ID */
    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO annees_scolaires (nom, date_debut, date_fin, est_active)
            VALUES (:nom, :date_debut, :date_fin, :est_active)');
        $stmt->execute([
            'nom' => trim($data['nom'] ?? ''),
            'date_debut' => $data['date_debut'] ?? null,
            'date_fin' => $data['date_fin'] ?? null,
            'est_active' => isset($data['est_active']) ? (int)$data['est_active'] : 0,
        ]);
        return (int)$pdo->lastInsertId();
    }

    /** Met à jour une année */
    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $fields = [];
        $params = ['id' => $id];
        foreach (['nom', 'date_debut', 'date_fin', 'est_active'] as $f) {
            if (array_key_exists($f, $data)) {
                $fields[] = "$f = :$f";
                $params[$f] = $f === 'est_active' ? (int)$data[$f] : trim($data[$f]);
            }
        }
        if (empty($fields)) return false;
        $sql = 'UPDATE annees_scolaires SET ' . implode(', ', $fields) . ' WHERE id = :id';
        $stmt = $pdo->prepare($sql);
        return $stmt->execute($params);
    }

    /** Définit l'année active (désactive les autres) */
    public static function setActive(int $id): bool {
        $pdo = getDB();
        $pdo->beginTransaction();
        try {
            $pdo->exec('UPDATE annees_scolaires SET est_active = 0');
            $stmt = $pdo->prepare('UPDATE annees_scolaires SET est_active = 1 WHERE id = :id');
            $stmt->execute(['id' => $id]);
            $pdo->commit();
            return true;
        } catch (\Exception $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    /** Supprime une année */
    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM annees_scolaires WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }
}
