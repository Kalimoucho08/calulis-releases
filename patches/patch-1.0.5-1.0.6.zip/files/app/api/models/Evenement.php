<?php
/** Calulis — Model Événement */
require_once __DIR__ . '/../config.php';

class Evenement {
    public static function all(?int $anneeId = null): array {
        $pdo = getDB();
        $sql = 'SELECT * FROM evenements';
        $params = [];
        if ($anneeId !== null) {
            $sql .= ' WHERE annee_scolaire_id = :anneeId';
            $params['anneeId'] = $anneeId;
        }
        $sql .= ' ORDER BY date_debut, nom';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM evenements WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Événements sur une date précise (inclut les récurrents qui correspondent) */
    public static function getByDate(string $date): array {
        $pdo = getDB();
        // Ponctuels dont la date est dans l'intervalle
        $stmt = $pdo->prepare(
            'SELECT * FROM evenements WHERE date_debut <= :d AND date_fin >= :d AND est_recurrent = 0
             ORDER BY date_debut, nom'
        );
        $stmt->execute(['d' => $date]);
        return $stmt->fetchAll();
    }

    /** Événements dans une plage de dates */
    public static function getByPeriode(string $debut, string $fin, ?int $anneeId = null): array {
        $pdo = getDB();
        $sql = 'SELECT * FROM evenements WHERE (
            (date_debut BETWEEN :debut AND :fin) OR
            (date_fin BETWEEN :debut AND :fin) OR
            (date_debut <= :debut2 AND date_fin >= :fin2)
        )';
        $params = ['debut' => $debut, 'fin' => $fin, 'debut2' => $debut, 'fin2' => $fin];
        if ($anneeId !== null) {
            $sql .= ' AND annee_scolaire_id = :anneeId';
            $params['anneeId'] = $anneeId;
        }
        $sql .= ' ORDER BY date_debut, nom';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO evenements (
            annee_scolaire_id, nom, description, date_debut, date_fin,
            jour_semaine, est_recurrent, recurrence_type, categorie, est_modele, couleur, affecte_semaine_type
        ) VALUES (
            :annee_scolaire_id, :nom, :description, :date_debut, :date_fin,
            :jour_semaine, :est_recurrent, :recurrence_type, :categorie, :est_modele, :couleur, :affecte_semaine_type
        )');
        $stmt->execute(self::_bind($data, false));
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $data['id'] = $id;
        $stmt = $pdo->prepare('UPDATE evenements SET
            annee_scolaire_id=:annee_scolaire_id, nom=:nom, description=:description,
            date_debut=:date_debut, date_fin=:date_fin, jour_semaine=:jour_semaine,
            est_recurrent=:est_recurrent, recurrence_type=:recurrence_type,
            categorie=:categorie, est_modele=:est_modele,
            couleur=:couleur, affecte_semaine_type=:affecte_semaine_type
        WHERE id=:id');
        return $stmt->execute(self::_bind($data));
    }

    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM evenements WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    /** Génère les événements d'anniversaire pour tous les élèves actifs d'une année scolaire */
    public static function genererAnniversaires(int $anneeId): array {
        $pdo = getDB();
        // Récupérer l'année scolaire pour déterminer l'année civile des anniversaires
        $stmt = $pdo->prepare('SELECT date_debut, date_fin FROM annees_scolaires WHERE id = :id');
        $stmt->execute(['id' => $anneeId]);
        $annee = $stmt->fetch();
        if (!$annee) return ['ok' => false, 'message' => 'Année scolaire introuvable'];

        // L'année des anniversaires = année de début (ex: 2026 pour 2026-2027)
        $anneeCivile = (int)substr($annee['date_debut'], 0, 4);

        // Récupérer les élèves actifs avec date de naissance
        // (on utilise eleve_annees pour filtrer par année active)
        $stmt = $pdo->prepare(
            'SELECT e.id, e.nom, e.prenom, e.date_naissance
             FROM eleves e
             JOIN eleve_annees ea ON ea.eleve_id = e.id AND ea.annee_scolaire_id = :aid
             WHERE e.actif = 1 AND e.date_naissance IS NOT NULL'
        );
        $stmt->execute(['aid' => $anneeId]);
        $eleves = $stmt->fetchAll();

        $crees = 0;
        $ignores = 0;

        foreach ($eleves as $el) {
            // Construire la date d'anniversaire dans l'année scolaire
            $moisJour = substr($el['date_naissance'], 5); // MM-DD
            $dateAnniv = $anneeCivile . '-' . $moisJour;

            // Si la date est déjà passée côté scolaire mais qu'on est en 2e semestre,
            // on pourrait mettre dans l'année suivante. On garde l'année civile de début.
            // Vérifier si un événement existe déjà pour cet élève cette année
            $stmtCheck = $pdo->prepare(
                "SELECT COUNT(*) FROM evenements
                 WHERE annee_scolaire_id = :aid
                   AND nom LIKE :pattern
                   AND date_debut = :date"
            );
            $pattern = '%' . $el['prenom'] . ' ' . $el['nom'] . '%';
            $stmtCheck->execute(['aid' => $anneeId, 'pattern' => $pattern, 'date' => $dateAnniv]);
            if ($stmtCheck->fetchColumn() > 0) {
                $ignores++;
                continue;
            }

            // Créer l'événement
            $stmtInsert = $pdo->prepare(
                'INSERT INTO evenements (annee_scolaire_id, nom, description, date_debut, date_fin,
                 est_recurrent, categorie, couleur, affecte_semaine_type)
                 VALUES (:aid, :nom, :desc, :date_debut, :date_fin, 0, :cat, :couleur, 0)'
            );
            $nom = '🎂 ' . $el['prenom'] . ' ' . $el['nom'];
            $desc = 'Anniversaire — ' . $el['prenom'] . ' ' . $el['nom']
                  . ' (né·e le ' . date('d/m/Y', strtotime($el['date_naissance'])) . ')';
            $stmtInsert->execute([
                'aid' => $anneeId,
                'nom' => $nom,
                'desc' => $desc,
                'date_debut' => $dateAnniv,
                'date_fin' => $dateAnniv,
                'cat' => 'anniversaire',
                'couleur' => '#FF6B6B',
            ]);
            $crees++;
        }

        return [
            'ok' => true,
            'crees' => $crees,
            'ignores' => $ignores,
            'total_eleves' => count($eleves),
        ];
    }

    private static function _bind(array $data, bool $includeId = true): array {
        $strFields = ['nom', 'description', 'date_debut', 'date_fin', 'jour_semaine',
            'recurrence_type', 'categorie', 'couleur'];
        $intFields = ['annee_scolaire_id', 'est_recurrent', 'est_modele', 'affecte_semaine_type'];
        if ($includeId) $intFields[] = 'id';
        $params = [];
        foreach ($strFields as $f) {
            $params[$f] = isset($data[$f]) ? trim($data[$f]) : null;
        }
        $intDefaults = ['annee_scolaire_id' => null, 'est_recurrent' => 0, 'est_modele' => 0, 'affecte_semaine_type' => 0, 'id' => 0];
        foreach ($intFields as $f) {
            $params[$f] = isset($data[$f]) ? (int)$data[$f] : ($intDefaults[$f] ?? 0);
        }
        if ($includeId) $params['id'] = isset($data['id']) ? (int)$data['id'] : 0;
        return $params;
    }
}
