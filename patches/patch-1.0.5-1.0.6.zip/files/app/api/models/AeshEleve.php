<?php
/** Calulis — Model AESH Élève */
require_once __DIR__ . '/../config.php';

class AeshEleve {
    public static function getByEleve(int $eleveId): array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM aesh_eleves WHERE eleve_id = :eid ORDER BY ordre');
        $stmt->execute(['eid' => $eleveId]);
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM aesh_eleves WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO aesh_eleves
            (eleve_id, type, nom, heures, mutualise_avec, ordre)
            VALUES (:eleve_id, :type, :nom, :heures, :mutualise_avec, :ordre)');
        $stmt->execute(self::_bind($data, false));
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $data['id'] = $id;
        $stmt = $pdo->prepare('UPDATE aesh_eleves SET
            eleve_id=:eleve_id, type=:type, nom=:nom, heures=:heures,
            mutualise_avec=:mutualise_avec, ordre=:ordre, updated_at=CURRENT_TIMESTAMP
            WHERE id=:id');
        return $stmt->execute(self::_bind($data));
    }

    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM aesh_eleves WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    public static function deleteByEleve(int $eleveId): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM aesh_eleves WHERE eleve_id = :eid');
        return $stmt->execute(['eid' => $eleveId]);
    }

    private static function _bind(array $data, bool $includeId = true): array {
        $strFields = ['type', 'nom', 'heures', 'mutualise_avec'];
        $intFields = ['eleve_id', 'ordre'];
        if ($includeId) $intFields[] = 'id';
        $params = [];
        foreach ($strFields as $f) {
            $params[$f] = isset($data[$f]) ? trim($data[$f]) : '';
        }
        $intDefaults = ['eleve_id' => 0, 'ordre' => 0];
        foreach ($intFields as $f) {
            $params[$f] = isset($data[$f]) ? (int)$data[$f] : ($intDefaults[$f] ?? 0);
        }
        if ($includeId) $params['id'] = isset($data['id']) ? (int)$data['id'] : 0;
        return $params;
    }
}
