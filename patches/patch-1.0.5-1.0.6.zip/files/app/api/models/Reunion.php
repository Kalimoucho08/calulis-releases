<?php
/** Calulis — Model Réunion (multi-année) */
require_once __DIR__ . '/../config.php';

class Reunion {
    public static function all(?int $anneeId = null): array {
        $pdo = getDB();
        $sql = 'SELECT r.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
                FROM reunions r
                LEFT JOIN eleves e ON r.eleve_id = e.id';
        $params = [];
        if ($anneeId !== null) {
            $sql .= ' WHERE r.annee_scolaire_id = :annee_id';
            $params['annee_id'] = $anneeId;
        }
        $sql .= ' ORDER BY r.date_reunion DESC, r.heure';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT r.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
             FROM reunions r
             LEFT JOIN eleves e ON r.eleve_id = e.id
             WHERE r.id = :id'
        );
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Réunions liées à un élève */
    public static function getByEleve(int $eleveId, ?int $anneeId = null): array {
        $pdo = getDB();
        $sql = 'SELECT r.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
                FROM reunions r
                LEFT JOIN eleves e ON r.eleve_id = e.id
                WHERE r.eleve_id = :eleveId';
        $params = ['eleveId' => $eleveId];
        if ($anneeId !== null) {
            $sql .= ' AND r.annee_scolaire_id = :annee_id';
            $params['annee_id'] = $anneeId;
        }
        $sql .= ' ORDER BY r.date_reunion DESC, r.heure';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Réunions à venir (dans les N prochains jours) */
    public static function getUpcoming(int $days = 30): array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT r.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
             FROM reunions r
             LEFT JOIN eleves e ON r.eleve_id = e.id
             WHERE r.date_reunion BETWEEN CURRENT_DATE AND DATE_ADD(CURRENT_DATE, INTERVAL :days DAY)
               AND r.statut IN ("prevue", "reportee")
             ORDER BY r.date_reunion, r.heure'
        );
        $stmt->execute(['days' => $days]);
        return $stmt->fetchAll();
    }

    /** Réunions dans une plage de dates */
    public static function getByPeriode(string $debut, string $fin): array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT r.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
             FROM reunions r
             LEFT JOIN eleves e ON r.eleve_id = e.id
             WHERE r.date_reunion BETWEEN :debut AND :fin
             ORDER BY r.date_reunion, r.heure'
        );
        $stmt->execute(['debut' => $debut, 'fin' => $fin]);
        return $stmt->fetchAll();
    }

    /** Réunions où un adulte est participant (recherche JSON) */
    public static function getByAdulte(string $adulteNom): array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT r.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
             FROM reunions r
             LEFT JOIN eleves e ON r.eleve_id = e.id
             WHERE r.participants LIKE :q
             ORDER BY r.date_reunion DESC, r.heure'
        );
        $stmt->execute(['q' => '%' . $adulteNom . '%']);
        return $stmt->fetchAll();
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO reunions (
            type, titre, date_reunion, heure, duree, eleve_id, lieu,
            participants, statut, notes, documents_lies, annee_scolaire_id
        ) VALUES (
            :type, :titre, :date_reunion, :heure, :duree, :eleve_id, :lieu,
            :participants, :statut, :notes, :documents_lies, :annee_scolaire_id
        )');
        $stmt->execute(self::_bind($data, false));
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $existing = self::find($id);
        if (!$existing) return false;
        $data = array_merge($existing, $data);
        $data['id'] = $id;
        $stmt = $pdo->prepare('UPDATE reunions SET
            type=:type, titre=:titre, date_reunion=:date_reunion, heure=:heure,
            duree=:duree, eleve_id=:eleve_id, lieu=:lieu, participants=:participants,
            statut=:statut, notes=:notes, documents_lies=:documents_lies,
            annee_scolaire_id=:annee_scolaire_id,
            updated_at=CURRENT_TIMESTAMP
        WHERE id=:id');
        return $stmt->execute(self::_bind($data));
    }

    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM reunions WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    private static function _bind(array $data, bool $includeId = true): array {
        $strFields = ['type', 'titre', 'date_reunion', 'heure', 'lieu',
            'participants', 'statut', 'notes', 'documents_lies'];
        $intFields = ['duree', 'eleve_id', 'annee_scolaire_id'];
        if ($includeId) $intFields[] = 'id';
        $params = [];
        foreach ($strFields as $f) {
            $params[$f] = isset($data[$f]) ? trim($data[$f]) : null;
        }
        $intDefaults = ['duree' => 60, 'eleve_id' => null, 'annee_scolaire_id' => null, 'id' => 0];
        foreach ($intFields as $f) {
            $params[$f] = isset($data[$f]) ? (int)$data[$f] : ($intDefaults[$f] ?? null);
        }
        if ($includeId) $params['id'] = isset($data['id']) ? (int)$data['id'] : 0;
        return $params;
    }
}
