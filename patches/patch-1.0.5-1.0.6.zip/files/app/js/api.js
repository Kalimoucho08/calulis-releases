/**
 * Calulis — Client HTTP API
 * Tous les appels passent par le backend PHP (MySQL).
 */

// ── Anti-CSRF : l'API locale n'accepte que les requêtes portant le jeton
// interne (X-Calulis-App). Une page web externe ne peut pas poser d'en-tête
// custom sans préflight — et le préflight est refusé pour les origines non
// locales (CORS restreint côté serveur). Le wrapper global couvre TOUS les
// fetch (API.*, state.js, params.js…).
(() => {
    const _origFetch = window.fetch;
    window.fetch = function (url, opts = {}) {
        opts = opts || {};
        opts.headers = Object.assign({}, opts.headers, { 'X-Calulis-App': '1' });
        return _origFetch.call(this, url, opts);
    };
})();

const API = {
    base: 'api',
    _loading: 0,

    async health() {
        try {
            const res = await fetch(`${this.base}/ping.php`);
            return res.ok;
        } catch {
            return false;
        }
    },

    async _fetch(url, opts = {}) {
        this._loading++;
        document.body.classList.add('loading');
        try {
            const res = await fetch(url, opts);
            return await this._handle(res);
        } catch (e) {
            if (e instanceof TypeError || e.name === 'TypeError') {
                throw new Error('Impossible de contacter le serveur. Vérifie la connexion.');
            }
            throw e;
        } finally {
            this._loading--;
            if (this._loading <= 0) {
                this._loading = 0;
                document.body.classList.remove('loading');
            }
        }
    },

    /**
     * Ajoute les query params globaux (annee_scolaire_id, etc.)
     */
    _buildUrl(endpoint) {
        let url = `${this.base}/${endpoint}`;
        if (typeof State !== 'undefined' && State.getQueryParams) {
            const params = State.getQueryParams();
            const keys = Object.keys(params);
            if (keys.length > 0) {
                const sep = endpoint.includes('?') ? '&' : '?';
                url += sep + keys.map(k => `${k}=${encodeURIComponent(params[k])}`).join('&');
            }
        }
        return url;
    },

    async get(endpoint) {
        return this._fetch(this._buildUrl(endpoint));
    },

    async post(endpoint, data) {
        // Ajouter l'année active dans le body si elle n'y est pas
        if (typeof State !== 'undefined' && State.get) {
            const anneeId = State.get('annee_scolaire_id');
            if (anneeId && data && typeof data === 'object' && !data.annee_scolaire_id) {
                data.annee_scolaire_id = anneeId;
            }
        }
        return this._fetch(`${this.base}/${endpoint}`, {
            method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data),
        });
    },

    async put(endpoint, data) {
        // Ajouter l'année active dans le body si elle n'y est pas
        if (typeof State !== 'undefined' && State.get) {
            const anneeId = State.get('annee_scolaire_id');
            if (anneeId && data && typeof data === 'object' && !data.annee_scolaire_id) {
                data.annee_scolaire_id = anneeId;
            }
        }
        return this._fetch(`${this.base}/${endpoint}`, {
            method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data),
        });
    },

    async del(endpoint) {
        return this._fetch(`${this.base}/${endpoint}`, { method: 'DELETE' });
    },

    async _handle(res) {
        if (!res.ok) {
            let message = null;
            let detail = null;
            try {
                const j = await res.json();
                if (j && typeof j.error === 'string' && j.error) message = j.error;
                if (j && typeof j.detail === 'string' && j.detail) detail = j.detail;
            } catch {
                // Corps non-JSON (fatal PHP sans handler, proxy…) → message générique
            }
            if (!message) {
                message = 'Erreur serveur (HTTP ' + res.status + '). Si le problème persiste, relancez l\'application.';
                if (res.statusText) console.error('[API] réponse non-JSON, statusText:', res.statusText);
            }
            if (detail) console.error('[API] détail:', detail);
            // Dernière erreur API → visible dans le Bug Report (bouton 🐛)
            window._calulisLastApiError = { status: res.status, message, detail, ts: new Date().toISOString() };
            throw new Error(message);
        }
        if (res.status === 204) return { ok: true };
        return res.json();
    },
};
