<?php
/**
 * Calulis — Routeur local pour php -S
 * Usage : php -S localhost:8083 dev-router.php
 */
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

require_once __DIR__ . '/api/config.php';

// Auto-réparation du schéma DB (mêmes règles que router.php en prod) :
// applique les migrations en attente une fois par processus → toutes les bases convergent
// vers le même schéma canonique (tables classe_enseignants, groupes, eleve_groupes).
calulis_auto_migrate();

// API : router vers le controller
if (preg_match('#^/api/([\w-]+)#', $uri, $m)) {
    $resource = $m[1];
    $file = __DIR__ . '/api/controllers/' . $resource . '.php';
    if (file_exists($file)) {
        require $file;
        return true;
    }
    http_response_code(404);
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Controller non trouvé : ' . $resource]);
    return true;
}

// Fichier statique
return false;
