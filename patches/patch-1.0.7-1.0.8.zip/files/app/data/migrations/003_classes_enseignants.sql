-- Migration 003 : classes <-> enseignants (many-to-many + jours) + numero eleve
-- 1. Table de liaison classe_enseignants
CREATE TABLE IF NOT EXISTS classe_enseignants (
  id INT NOT NULL AUTO_INCREMENT,
  classe_id INT NOT NULL,
  adulte_id INT NOT NULL,
  jours TEXT,
  plage VARCHAR(20) DEFAULT 'journee',
  ordre INT DEFAULT 0,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY classe_id (classe_id),
  KEY adulte_id (adulte_id),
  CONSTRAINT ce_classe_fk FOREIGN KEY (classe_id) REFERENCES classes(id) ON DELETE CASCADE,
  CONSTRAINT ce_adulte_fk FOREIGN KEY (adulte_id) REFERENCES adultes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. Migrer le champ unique enseignant_id vers la table de liaison
INSERT INTO classe_enseignants (classe_id, adulte_id, jours, plage, ordre)
SELECT id, enseignant_id, '["lundi","mardi","jeudi","vendredi"]', 'journee', 0
FROM classes WHERE enseignant_id IS NOT NULL;

-- 3. Champ numero eleve (optionnel)
SET @col_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'eleves' AND COLUMN_NAME = 'numero');
SET @sql = IF(@col_exists = 0, 'ALTER TABLE eleves ADD COLUMN numero INT NULL AFTER ordre', 'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;