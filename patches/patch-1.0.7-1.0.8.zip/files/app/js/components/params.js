/**
 * Calulis — Composant Paramètres
 */
const ParamsView = {
    _data: {},

    async render() {
        const view = document.getElementById('view-params');
        // Charger params + semaines
        try {
            const raw = await API.get('params.php');
            this._data = {};
            raw.forEach(p => { try { this._data[p.cle] = JSON.parse(p.valeur); } catch { this._data[p.cle] = p.valeur; } });
        } catch { this._data = this._defaults(); }
        let semaines = [];
        try { semaines = await API.get('semaines.php'); } catch {}

        const couleurs = this._data.couleurs_types || { ULIS: '#bbdefb', INCLUSION: '#c8e6c9', DECLOISONNEMENT: '#fff9c4', PEC: '#ffccbc', AUTRE: '#e0e0e0' };
        const typesReunions = this._data.types_reunions || { 'ESS': '#bbdefb', 'Équipe éducative': '#c8e6c9', 'RDV famille': '#fff9c4', 'Partenariat': '#ffccbc', 'Autre': '#e0e0e0' };
        const horaires = this._data.horaires || { debut: '08:30', fin: '16:30', duree_creneau: 15 };
        const apc = this._data.apc || { actif: false, slots: [] };
        const joursAffiches = this._data.jours_affiches || ['lundi', 'mardi', 'jeudi', 'vendredi'];
        const theme = (this._data.theme || 'clair').replace(/"/g, '');

        view.innerHTML = `
            <div style="max-width:700px">
                <div class="card" style="margin-bottom:16px" data-help="Couleurs par type|Chaque type de regroupement (ULIS, Inclusion, Décloisonnement…) a une couleur. Elle s\'applique automatiquement à tous les créneaux de ce type dans l\'agenda. Choisissez des teintes bien distinctes, lisibles à l\'écran comme à l\'impression. Modifier une couleur ici la répercute instantanément sur tous les créneaux existants.">
                    <h3>🎨 Couleurs par type</h3>
                    <p class="text-muted small" style="margin-bottom:12px">Modifier une couleur la répercute sur tous les créneaux de ce type.</p>
                    ${Object.entries(couleurs).map(([type, color]) => `
                        <div class="form-row" style="margin-bottom:8px">
                            <label style="display:flex;align-items:center;gap:8px;font-size:14px">
                                <span style="width:90px;font-weight:600">${type}</span>
                                <input type="color" id="color-${type}" value="${color}" style="width:48px;height:32px;border:none;cursor:pointer">
                                <code style="font-size:12px">${color}</code>
                            </label>
                        </div>
                    `).join('')}
                </div>

                <div class="card" style="margin-bottom:16px" data-help="Types de réunions|Ajoute les types adaptés à ton fonctionnement (ESS, équipe éducative, RDV famille, concertation, partenariat...). Chaque type aura sa couleur dans la liste des réunions.">
                    <h3>🤝 Types de réunions</h3>
                    <p class="text-muted small" style="margin-bottom:12px">Ces types apparaîtront dans le menu déroulant du formulaire de réunion.</p>
                    <div id="types-reunions-list"></div>
                    <button class="btn btn-sm btn-secondary" id="btn-add-type-reunion" style="margin-top:8px">+ Ajouter un type</button>
                </div>

                <div class="card" style="margin-bottom:16px" data-help="Fonctions|Définis les fonctions disponibles pour le personnel : Coordo ULIS, Directeur, Adjoint, Enseignant RASED… Ces fonctions sont attribuables aux adultes dans leur fiche.">
                    <h3>🏷️ Fonctions</h3>
                    <p class="text-muted small" style="margin-bottom:12px">Attribuables aux adultes dans leur fiche (enseignant, AESH…).</p>
                    <div id="fonctions-list"></div>
                    <button class="btn btn-sm btn-secondary" id="btn-add-fonction" style="margin-top:8px">+ Ajouter une fonction</button>
                </div>

                <div class="card" style="margin-bottom:16px" data-help="Horaires de l'école|Définissez l'heure de début, l'heure de fin et la durée d'un créneau. 15 minutes est la granularité recommandée (un créneau = un quart d'heure). La grille de l'agenda s'adapte automatiquement à ces réglages. La pause méridienne est calculée automatiquement à partir de l'heure de fin du matin et de reprise de l'après-midi.">
                    <h3>⏰ Horaires</h3>
                    <div style="display:flex;gap:12px;flex-wrap:wrap;align-items:end">
                        <div class="form-group"><label>Début de la journée</label><input type="time" id="param-debut" value="${horaires.debut || '08:30'}"></div>
                        <div class="form-group"><label>Fin de matinée</label><input type="time" id="param-fin-matin" value="${horaires.fin_matin || '11:30'}"></div>
                        <div class="form-group"><label>Début d'après-midi</label><input type="time" id="param-debut-aprem" value="${horaires.debut_aprem || '13:30'}"></div>
                        <div class="form-group"><label>Fin de la journée</label><input type="time" id="param-fin" value="${horaires.fin || '16:30'}"></div>
                        <div class="form-group"><label>Durée créneau (min)</label>
                            <select id="param-duree">
                                ${[10,15,20,30,60].map(d => `<option ${horaires.duree_creneau === d ? 'selected' : ''}>${d}</option>`).join('')}
                            </select>
                        </div>
                    </div>
                    <p id="cantine-info" class="text-muted small" style="margin-top:8px"></p>
                </div>

                <div class="card" style="margin-bottom:16px" data-help="APC (Activités Pédagogiques Complémentaires)|Les APC sont des créneaux hors temps scolaire obligatoire : le midi entre la cantine et la reprise, le soir après la classe, ou le mercredi matin. Cochez les plages que vous utilisez pour qu'elles apparaissent dans l'agenda. Une fois activées, vous pourrez y placer des créneaux comme dans le reste de la grille.">
                    <h3>📝 APC — Activités Pédagogiques Complémentaires</h3>
                    <p class="text-muted small" style="margin-bottom:8px">
                        Créneaux hors temps scolaire (midi, soir après la classe, mercredi matin…).
                    </p>
                    <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:14px;margin-bottom:8px">
                        <input type="checkbox" id="param-apc-actif" ${apc.actif ? 'checked' : ''}>
                        <strong>Activer les créneaux APC dans l'agenda</strong>
                    </label>
                    <div id="apc-slots-list" style="${apc.actif ? '' : 'display:none'}"></div>
                    <button class="btn btn-sm btn-secondary" id="btn-add-apc" style="margin-top:8px;${apc.actif ? '' : 'display:none'}">+ Ajouter un créneau APC</button>
                </div>

                <div class="card" style="margin-bottom:16px" data-help="Jours travaillés|Cochez les jours où il y a classe. Les jours décochés disparaissent de la grille de l'agenda. En élémentaire, on coche généralement Lundi, Mardi, Jeudi, Vendredi (pas de classe le mercredi ni le samedi). Vous pouvez modifier ce choix à tout moment, par exemple si vous avez une sortie un mercredi.">
                    <h3>📅 Jours affichés</h3>
                    <div style="display:flex;gap:16px;flex-wrap:wrap">
                        ${['lundi','mardi','mercredi','jeudi','vendredi','samedi'].map(j => `
                            <label style="display:flex;align-items:center;gap:4px;cursor:pointer;font-size:14px">
                                <input type="checkbox" class="param-jour" value="${j}" ${joursAffiches.includes(j) ? 'checked' : ''}>
                                ${j.charAt(0).toUpperCase() + j.slice(1,3)}
                            </label>
                        `).join('')}
                    </div>
                </div>

                <div class="card" style="margin-bottom:16px">
                    <h3>🔢 Numérotation des semaines</h3>
                    <select id="param-format-semaine" style="max-width:250px;font-size:14px">
                        <option value="scolaire" ${(this._data.format_semaine || 'scolaire') === 'scolaire' ? 'selected' : ''}>Scolaire (S1, S2…)</option>
                        <option value="periode" ${(this._data.format_semaine || '') === 'periode' ? 'selected' : ''}>Par période (P1S1, P2S3…)</option>
                        <option value="iso" ${(this._data.format_semaine || '') === 'iso' ? 'selected' : ''}>ISO (S2026-W35…)</option>
                    </select>
                </div>

                <div class="card" style="margin-bottom:16px">
                    <h3>🏖️ Semaines scolaires / vacances</h3>
                    <p class="text-muted small" style="margin-bottom:8px">Décoche une semaine pour la masquer de la navigation.</p>
                    <div id="semaines-list" style="max-height:300px;overflow-y:auto;font-size:13px"></div>
                </div>

                <div class="card" style="margin-bottom:16px" data-help="Pauses|Les pauses (récréation, cantine) apparaissent comme des bandes dans la grille. Elles sont automatiquement créées pour chaque élève. Un créneau normal peut recouvrir une pause si besoin.">
                    <h3>🍽️ Pauses (cantine, récréations)</h3>
                    <p class="text-muted small" style="margin-bottom:8px">Créneaux fusionnés sur toute la largeur de la grille.</p>
                    <div id="pauses-list"></div>
                    <button class="btn btn-sm btn-secondary" id="btn-add-pause" style="margin-top:8px">+ Ajouter une pause</button>
                </div>

                <div class="card" style="margin-bottom:16px">
                    <h3>🌓 Thème</h3>
                    <label style="display:flex;align-items:center;gap:8px;cursor:pointer;font-size:14px">
                        <input type="checkbox" id="param-theme" ${theme === 'dark' ? 'checked' : ''}> Mode sombre
                    </label>
                </div>

                <div class="card" style="margin-bottom:16px" data-help="Email de signalement|L'adresse vers laquelle sont envoyés les signalements de bug (bouton 🐛).">
                    <h3>📧 Email de signalement</h3>
                    <p class="text-muted small" style="margin-bottom:8px">Destinataire des signalements de bug (bouton 🐛).</p>
                    <input type="email" id="param-email-support" value="${escapeHtml(this._data.email_support || 'generateurs.scolaire@free.fr')}" placeholder="ex: mon-email@free.fr" style="max-width:360px;font-size:14px">
                </div>

                <div class="card" style="margin-bottom:16px" data-help="Notre établissement|Sélectionnez l'école où se trouve votre dispositif ULIS. C'est important : les élèves et le personnel y seront automatiquement rattachés, et cet établissement apparaîtra en premier dans la liste avec le badge 🏫 NOTRE ÉCOLE. Si votre école n'est pas encore dans la liste, créez-la d'abord dans 🏫 Établissements.">
                    <h3>🏫 Notre établissement</h3>
                    <p class="text-muted small" style="margin-bottom:12px">Établissement principal où se trouve le dispositif ULIS.</p>
                    <div class="form-row" style="align-items:center">
                        <div class="form-group" style="flex:1">
                            <select id="param-notre-etablissement" style="max-width:400px;font-size:14px">
                                <option value="">— Non configuré —</option>
                            </select>
                        </div>
                        <button class="btn btn-sm btn-secondary" id="btn-create-etablissement" style="margin-left:8px">+ Nouvel établissement</button>
                        <button class="btn btn-sm btn-secondary" id="btn-refresh-etablissements" style="margin-left:4px" title="Rafraîchir">⟳</button>
                    </div>
                    <div id="notre-etablissement-info" class="text-muted small" style="margin-top:4px"></div>
                </div>

                <button class="btn btn-primary" id="btn-save-params" style="margin-top:8px">💾 Enregistrer</button>
                <span id="params-msg" class="text-muted" style="margin-left:12px;font-size:13px"></span>

                <!-- ── Import CSV ── -->
                <div class="card" style="margin-bottom:16px">
                    <h3>📥 Importer des élèves (fichier CSV)</h3>
                    <p class="text-muted small" style="margin-bottom:8px">
                        <strong>À quoi ça sert ?</strong> Exportez la liste de vos élèves depuis votre
                        logiciel de scolarité habituel (ONDE pour le 1er degré, Siècle/Sconet pour le
                        2nd degré…) au format CSV, puis importez-le ici. Les numéros INE et les contacts
                        des responsables légaux seront automatiquement ajoutés aux fiches élèves.
                    </p>
                    <p class="text-muted small" style="margin-bottom:4px">
                        📋 <strong>Format attendu</strong> : colonnes <code>nom</code>, <code>prenom</code>,
                        <code>date_naissance</code>, <code>ine</code> (identifiant national),
                        <code>responsable1_nom</code>, <code>responsable1_prenom</code>,
                        <code>responsable1_lien</code>, <code>responsable1_tel</code>,
                        <code>responsable1_email</code>…
                    </p>
                    <p class="text-muted small" style="margin-bottom:12px;color:var(--success)">
                        🔒 Les infos déjà saisies manuellement ne sont jamais écrasées.
                    </p>
                    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                        <input type="file" id="genscol-file" accept=".csv" style="display:none">
                        <button class="btn btn-secondary" id="btn-genscol-select">📁 Choisir le fichier CSV</button>
                        <button class="btn btn-primary" id="btn-genscol-import" style="display:none">📥 Lancer l'import</button>
                        <span id="genscol-file-name" class="text-muted small"></span>
                    </div>
                    <div id="genscol-status" class="text-muted small" style="margin-top:8px;min-height:1.2em"></div>
                </div>

                <!-- ── Années scolaires ── -->
                <div class="card" style="margin-bottom:16px" id="annees-scolaires-card">
                    <h3>📅 Années scolaires</h3>
                    <p class="text-muted small" style="margin-bottom:12px">
                        <strong>À quoi ça sert ?</strong> Chaque année scolaire a ses propres élèves,
                        son propre agenda et ses créneaux. L'année <strong>active</strong>
                        (avec le liseré bleu) est celle que vous consultez en ce moment.
                    </p>
                    <div id="annees-list" style="margin-bottom:12px"></div>
                    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                        <button class="btn btn-primary" id="btn-add-annee">➕ Créer une nouvelle année</button>
                        <span class="text-muted small">— À faire en fin d'année pour préparer la rentrée suivante</span>
                    </div>
                    <div style="margin-top:12px;padding-top:12px;border-top:1px solid var(--border)">
                        <p class="text-muted small" style="margin-bottom:4px">
                            <strong>📅 Calendrier officiel</strong> — Importe les semaines et les
                            vacances depuis le site de l'Éducation Nationale. Choisissez votre zone
                            (A, B ou C) selon votre académie.
                        </p>
                        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                            <select id="param-zone-calendrier" style="width:auto;font-size:13px">
                                <option value="Zone A">Zone A — Besançon, Bordeaux, Clermont-Ferrand, Dijon, Grenoble, Limoges, Lyon, Poitiers</option>
                                <option value="Zone B" selected>Zone B — Aix-Marseille, Amiens, Caen, Lille, Nancy-Metz, Nantes, Nice, Orléans-Tours, Reims, Rennes, Rouen, Strasbourg</option>
                                <option value="Zone C">Zone C — Créteil, Montpellier, Paris, Toulouse, Versailles</option>
                            </select>
                            <button class="btn btn-sm btn-secondary" id="btn-import-calendrier">
                                📅 Importer le calendrier pour l'année active
                            </button>
                            <button class="btn btn-sm btn-danger" id="btn-delete-calendrier" style="margin-left:8px" title="Supprimer les semaines/vacances importées (si mauvaise zone ou année)">🗑️ Supprimer</button>
                        </div>
                        <span id="annee-msg" class="text-muted" style="margin-left:8px;font-size:13px"></span>
                    </div>
                </div>

                <!-- ── Base de données ── -->
                <div class="card" style="margin-bottom:16px">
                    <h3>💾 Sauvegardes et données</h3>

                    <div class="form-section" style="border-left:4px solid var(--success);padding:12px 16px">
                        <div class="form-section-title" style="color:var(--success);font-size:14px">🟢 Sauvegarder mes données</div>
                        <p class="text-muted small" style="margin-bottom:8px">
                            Téléchargez une copie de secours de <strong>toutes</strong> vos données
                            (élèves, agenda, paramètres…) sur votre ordinateur.
                            <br>📌 <em>À faire régulièrement : une fois par semaine, avant chaque période de vacances.</em>
                        </p>
                        <button class="btn btn-primary" id="btn-db-export">📥 Sauvegarder maintenant</button>
                        <span id="db-export-msg" class="text-muted" style="margin-left:8px;font-size:13px"></span>
                        <p class="text-danger small" style="margin-top:4px;font-size:12px">
                            ⚠️ Les fichiers de sauvegarde contiennent <strong>toutes les données personnelles</strong> (élèves, représentants, santé).
                            Stockez-les dans un endroit sécurisé et supprimez-les dès qu'ils ne sont plus nécessaires.
                        </p>
                    </div>

                    <div class="form-section" style="border-left:4px solid var(--warning);padding:12px 16px">
                        <div class="form-section-title" style="color:var(--warning);font-size:14px">🟠 Restaurer une sauvegarde</div>
                        <p class="text-muted small" style="margin-bottom:8px">
                            Récupérez vos données à partir d'une sauvegarde précédemment téléchargée.
                            <br>⚠️ <strong>Toutes les données actuelles seront remplacées.</strong>
                            <br>📌 <em>Quand ? Changement d'ordinateur, erreur, ou retour en arrière.</em>
                        </p>
                        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                            <input type="file" id="db-import-file" accept=".sql" style="display:none">
                            <button class="btn btn-secondary" id="btn-db-import-select">📁 Choisir mon fichier de sauvegarde</button>
                            <button class="btn btn-danger" id="btn-db-import-go" style="display:none">⚠️ Restaurer cette sauvegarde</button>
                        </div>
                        <span id="db-import-name" style="margin-left:4px;font-size:13px;color:var(--text-muted)"></span>
                        <div id="db-import-status" class="text-muted small" style="margin-top:8px;min-height:1.2em"></div>
                    </div>

                    <div class="form-section" style="border-left:4px solid var(--warning);padding:12px 16px">
                        <div class="form-section-title" style="color:var(--warning);font-size:14px">🧹 Purger les anciens élèves</div>
                        <p class="text-muted small" style="margin-bottom:8px">
                            Supprimez les données des élèves <strong>inactifs (sortis du dispositif)</strong> dont
                            la dernière année scolaire de présence est antérieure à une date donnée.
                            <br>⚠️ <strong>Cette action est irréversible.</strong> Faites une sauvegarde avant.
                            <br>📌 <em>Recommandé : purger après chaque fin d'année scolaire les élèves sortis depuis plus d'un an.</em>
                        </p>
                        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                            <input type="date" id="purge-avant-date" style="font-size:14px">
                            <button class="btn btn-warning" id="btn-purge-anciens">🧹 Purger les élèves antérieurs à cette date</button>
                        </div>
                        <div id="purge-status" class="text-muted small" style="margin-top:4px;min-height:1.2em"></div>
                    </div>

                    <div class="form-section" style="border-left:4px solid var(--danger);padding:12px 16px">
                        <div class="form-section-title" style="color:var(--danger);font-size:14px">🔴 Réinitialiser l'application</div>
                        <p class="text-muted small" style="margin-bottom:8px">
                            Effacez toutes vos données et chargez une base de démonstration (pour tester
                            les fonctionnalités) ou une base vierge (pour repartir de zéro).
                            <br>⚠️ <strong>Toutes vos données seront définitivement effacées.</strong>
                            <br>📌 <em>Quand ? Première découverte, test, ou reconfiguration complète.</em>
                        </p>
                        <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap">
                            <select id="param-db-snapshot" style="max-width:350px;font-size:14px"></select>
                            <button class="btn btn-danger" id="btn-load-snapshot">🔄 Charger cette base</button>
                            <button class="btn btn-sm btn-secondary" id="btn-refresh-snapshots" title="Rafraîchir la liste">⟳</button>
                        </div>
                        <div id="db-status" class="text-muted small" style="margin-top:4px;min-height:1.2em"></div>
                    </div>
                </div>
            </div>
        `;

        document.getElementById('btn-save-params').addEventListener('click', () => this._save());

        // Import CSV (élèves)
        document.getElementById('btn-genscol-select')?.addEventListener('click', () => {
            document.getElementById('genscol-file').click();
        });
        document.getElementById('genscol-file')?.addEventListener('change', () => {
            const file = document.getElementById('genscol-file').files[0];
            if (file) {
                document.getElementById('genscol-file-name').textContent = file.name;
                document.getElementById('btn-genscol-import').style.display = '';
            }
        });
        document.getElementById('btn-genscol-import')?.addEventListener('click', () => this._importGenscol());

        // Années scolaires
        this._renderAnnees();
        document.getElementById('btn-add-annee')?.addEventListener('click', () => this._addAnnee());
        document.getElementById('btn-import-calendrier')?.addEventListener('click', () => this._importCalendrier());
        document.getElementById('btn-delete-calendrier')?.addEventListener('click', () => this._deleteCalendrier());
        State.on('annees:changed', () => this._renderAnnees());

        // Horaires — afficher le temps de cantine et de classe
        this._updateCantineInfo();
        ['param-debut', 'param-fin-matin', 'param-debut-aprem', 'param-fin'].forEach(id => {
            document.getElementById(id)?.addEventListener('change', () => this._updateCantineInfo());
        });

        // APC
        this._renderApcSlots(apc);
        document.getElementById('param-apc-actif')?.addEventListener('change', () => {
            const checked = document.getElementById('param-apc-actif')?.checked;
            document.getElementById('apc-slots-list').style.display = checked ? '' : 'none';
            document.getElementById('btn-add-apc').style.display = checked ? '' : 'none';
        });
        document.getElementById('btn-add-apc')?.addEventListener('click', () => this._addApcSlot());

        // Semaines
        this._renderSemaines(semaines);
        // Pauses
        this._renderPauses();
        document.getElementById('btn-add-pause').addEventListener('click', () => this._addPause());
        // Types réunions
        this._renderTypesReunions(typesReunions);
        document.getElementById('btn-add-type-reunion').addEventListener('click', () => this._addTypeReunion());
        // Fonctions
        this._renderFonctions();
        document.getElementById('btn-add-fonction').addEventListener('click', () => this._addFonction());

        // Notre établissement
        this._loadNotreEtablissement();
        document.getElementById('btn-create-etablissement')?.addEventListener('click', () => {
            FicheEtablissement.open({}, false);
        });
        document.getElementById('btn-refresh-etablissements')?.addEventListener('click', () => {
            this._loadNotreEtablissement();
        });
        // Écouter la création d'établissement pour rafraîchir
        State.on('etablissements:changed', () => this._loadNotreEtablissement());

        // Purge anciens élèves
        document.getElementById('btn-purge-anciens')?.addEventListener('click', () => this._purgeAnciensEleves());

        // Export DB
        document.getElementById('btn-db-export')?.addEventListener('click', () => this._exportDB());

        // Import DB
        document.getElementById('btn-db-import-select')?.addEventListener('click', () => {
            document.getElementById('db-import-file').click();
        });
        document.getElementById('db-import-file')?.addEventListener('change', () => {
            const file = document.getElementById('db-import-file').files[0];
            if (file) {
                document.getElementById('db-import-name').textContent = file.name;
                document.getElementById('btn-db-import-go').style.display = '';
            }
        });
        document.getElementById('btn-db-import-go')?.addEventListener('click', () => this._importDB());

        // Snapshots DB
        this._loadSnapshotsList();
        document.getElementById('btn-refresh-snapshots')?.addEventListener('click', () => this._loadSnapshotsList());
        document.getElementById('btn-load-snapshot')?.addEventListener('click', () => this._loadSnapshot());
        document.getElementById('param-db-snapshot')?.addEventListener('change', () => {
            const sel = document.getElementById('param-db-snapshot');
            const desc = document.getElementById('db-status');
            if (sel && desc) {
                const opt = sel.options[sel.selectedIndex];
                desc.textContent = opt?.dataset?.description || '';
            }
        });
    },

    _updateCantineInfo() {
        const el = document.getElementById('cantine-info');
        if (!el) return;
        const debut = document.getElementById('param-debut')?.value || '08:30';
        const finMatin = document.getElementById('param-fin-matin')?.value || '11:30';
        const debutAprem = document.getElementById('param-debut-aprem')?.value || '13:30';
        const fin = document.getElementById('param-fin')?.value || '16:30';

        const toMin = t => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
        const fmtDelta = mins => {
            const h = Math.floor(mins / 60);
            const m = mins % 60;
            return h > 0 ? `${h}h${m > 0 ? m.toString().padStart(2,'0') : ''}` : `${m}min`;
        };

        const pauseMidi = toMin(debutAprem) - toMin(finMatin);
        const tempsMatin = toMin(finMatin) - toMin(debut);
        const tempsAprem = toMin(fin) - toMin(debutAprem);
        const tempsClasse = tempsMatin + tempsAprem;

        if (pauseMidi > 0 && tempsClasse > 0) {
            el.innerHTML = `🍽️ <strong>Pause méridienne</strong> : ${fmtDelta(pauseMidi)} (${finMatin} → ${debutAprem}) &nbsp;|&nbsp; 📚 <strong>Temps de classe</strong> : ${fmtDelta(tempsClasse)}/jour (${fmtDelta(tempsMatin)} matin + ${fmtDelta(tempsAprem)} après-midi)`;
            el.style.color = '';
        } else {
            el.innerHTML = '⚠️ Vérifiez les horaires : la fin de matinée doit être avant le début d\'après-midi.';
            el.style.color = 'var(--warning)';
        }
    },

    _renderApcSlots(apc) {
        const container = document.getElementById('apc-slots-list');
        if (!container) return;
        const slots = apc.slots || [];
        container.innerHTML = slots.map((s, i) => `
            <div class="form-row" style="margin-bottom:6px;align-items:center" data-apc="${i}">
                <select class="apc-jour" style="width:100px;font-size:13px">
                    ${['lundi','mardi','mercredi','jeudi','vendredi','samedi'].map(j =>
                        `<option value="${j}" ${s.jour === j ? 'selected' : ''}>${j.charAt(0).toUpperCase() + j.slice(1,3)}</option>`
                    ).join('')}
                </select>
                <input type="time" class="apc-debut" value="${s.debut || '12:00'}" style="width:100px;font-size:13px">
                <span>→</span>
                <input type="time" class="apc-fin" value="${s.fin || '12:30'}" style="width:100px;font-size:13px">
                <button class="btn-sm btn-del" onclick="this.closest('[data-apc]').remove()">×</button>
            </div>
        `).join('') || '<p class="text-muted small">Aucun créneau APC configuré. Ajoutez-en un avec le bouton ci-dessous.</p>';
    },

    _addApcSlot() {
        const container = document.getElementById('apc-slots-list');
        if (!container) return;
        const existing = container.querySelectorAll('[data-apc]').length;
        const slot = { jour: 'lundi', debut: '12:00', fin: '12:30' };
        const apc = { actif: true, slots: [slot] };
        // Ajouter le slot sans recréer tout le DOM
        const div = document.createElement('div');
        div.className = 'form-row';
        div.style.cssText = 'margin-bottom:6px;align-items:center';
        div.setAttribute('data-apc', String(existing));
        div.innerHTML = `
            <select class="apc-jour" style="width:100px;font-size:13px">
                ${['lundi','mardi','mercredi','jeudi','vendredi','samedi'].map(j =>
                    `<option value="${j}" ${slot.jour === j ? 'selected' : ''}>${j.charAt(0).toUpperCase() + j.slice(1,3)}</option>`
                ).join('')}
            </select>
            <input type="time" class="apc-debut" value="${slot.debut}" style="width:100px;font-size:13px">
            <span>→</span>
            <input type="time" class="apc-fin" value="${slot.fin}" style="width:100px;font-size:13px">
            <button class="btn-sm btn-del" onclick="this.closest('[data-apc]').remove()">×</button>
        `;
        // Enlever le message "aucun créneau" s'il est encore là
        const empty = container.querySelector('.text-muted');
        if (empty) empty.remove();
        container.appendChild(div);
    },

    _renderSemaines(semaines) {
        const container = document.getElementById('semaines-list');
        const scolaires = semaines.filter(s => !s.est_vacances).length;
        container.innerHTML = `
            <p class="text-muted small" style="margin-bottom:4px">${scolaires} semaines scolaires / ${semaines.length - scolaires} vacances</p>
            ${semaines.map(s => `
                <label style="display:flex;align-items:center;gap:6px;padding:3px 0;cursor:pointer;font-size:12px">
                    <input type="checkbox" class="semaine-scolaire" value="${s.id}" ${!s.est_vacances ? 'checked' : ''}>
                    <span style="flex:1">S${getSchoolWeekNumber(s, semaines)} · ${formatDate(s.date_debut)} → ${formatDate(s.date_fin)}</span>
                </label>
            `).join('')}
        `;
    },

    /** Détecte les pauses en double (mêmes horaires) et les chevauchements */
    _pauseConflicts(pauses) {
        const toMin = (s) => {
            const parts = String(s || '').split(':');
            const h = parseInt(parts[0], 10), m = parseInt(parts[1], 10);
            return (isNaN(h) ? 0 : h * 60) + (isNaN(m) ? 0 : m);
        };
        const actifs = pauses.filter(p => p.actif && p.heure_debut && p.heure_fin);
        const issues = [];
        // Doublons : mêmes horaires début/fin
        const byTime = new Map();
        actifs.forEach((p, i) => {
            const key = p.heure_debut + '|' + p.heure_fin;
            if (byTime.has(key)) {
                const prev = actifs[byTime.get(key)];
                issues.push('« ' + (p.nom || 'Pause sans nom') + ' » ' + p.heure_debut + '–' + p.heure_fin + ' est en double avec « ' + (prev.nom || 'Pause sans nom') + ' »');
            } else {
                byTime.set(key, i);
            }
        });
        // Chevauchements : intervalles qui se croisent
        for (let i = 0; i < actifs.length; i++) {
            for (let j = i + 1; j < actifs.length; j++) {
                const a = actifs[i], b = actifs[j];
                const a0 = toMin(a.heure_debut), a1 = toMin(a.heure_fin);
                const b0 = toMin(b.heure_debut), b1 = toMin(b.heure_fin);
                if (a1 <= a0 || b1 <= b0) continue;
                if (a0 < b1 && b0 < a1) {
                    issues.push('« ' + (a.nom || 'Pause sans nom') + ' » ' + a.heure_debut + '–' + a.heure_fin + ' chevauche « ' + (b.nom || 'Pause sans nom') + ' » ' + b.heure_debut + '–' + b.heure_fin);
                }
            }
        }
        return [...new Set(issues)];
    },

    _renderPauses() {
        const pauses = this._data.pauses || [];
        const container = document.getElementById('pauses-list');
        container.innerHTML = pauses.map((p, i) => `
            <div class="form-row" style="margin-bottom:6px;align-items:center" data-pause="${i}">
                <input type="text" class="pause-nom" value="${escapeHtml(p.nom || '')}" placeholder="Nom" style="width:120px">
                <input type="time" class="pause-debut" value="${p.heure_debut || ''}" style="width:100px">
                <span>→</span>
                <input type="time" class="pause-fin" value="${p.heure_fin || ''}" style="width:100px">
                <label style="display:flex;align-items:center;gap:4px;font-size:12px">
                    <input type="checkbox" class="pause-actif" ${p.actif ? 'checked' : ''}> Actif
                </label>
                <button class="btn-sm btn-del" onclick="this.parentElement.remove()">×</button>
            </div>
        `).join('') || '<p class="text-muted small">Aucune pause configurée.</p>';
    },

    _addPause() {
        if (!this._data.pauses) this._data.pauses = [];
        this._data.pauses.push({ nom: 'Nouvelle pause', heure_debut: '10:00', heure_fin: '10:15', actif: true, couleur: '#e0e0e0' });
        this._renderPauses();
    },

    async _save() {
        const couleurs = {};
        ['ULIS','INCLUSION','DECLOISONNEMENT','PEC','AUTRE'].forEach(t => {
            const el = document.getElementById('color-' + t);
            if (el) couleurs[t] = el.value;
        });

        const horaires = {
            debut: document.getElementById('param-debut').value,
            fin_matin: document.getElementById('param-fin-matin').value,
            debut_aprem: document.getElementById('param-debut-aprem').value,
            fin: document.getElementById('param-fin').value,
            duree_creneau: parseInt(document.getElementById('param-duree').value),
        };

        const jours = Array.from(document.querySelectorAll('.param-jour:checked')).map(cb => cb.value);
        const theme = document.getElementById('param-theme').checked ? 'dark' : 'clair';

        // Types réunions
        const typesReunions = {};
        document.querySelectorAll('.type-reunion-row').forEach(row => {
            const nom = row.querySelector('.type-reunion-nom').value.trim();
            if (nom) typesReunions[nom] = row.querySelector('.type-reunion-couleur').value;
        });

        // Fonctions
        const fonctions = [];
        document.querySelectorAll('.fonction-row input').forEach(input => {
            const v = input.value.trim();
            if (v) fonctions.push(v);
        });

        // Pauses
        const pauses = [];
        document.querySelectorAll('#pauses-list [data-pause]').forEach(row => {
            pauses.push({
                nom: row.querySelector('.pause-nom').value,
                heure_debut: row.querySelector('.pause-debut').value,
                heure_fin: row.querySelector('.pause-fin').value,
                actif: row.querySelector('.pause-actif').checked ? 1 : 0,
                couleur: '#e0e0e0',
            });
        });

        // Garde-fou : bloquer si pauses en double ou chevauchements
        const pauseIssues = this._pauseConflicts(pauses);
        if (pauseIssues.length) {
            const msg = 'Pauses : ' + pauseIssues[0] + (pauseIssues.length > 1 ? ' (+' + (pauseIssues.length - 1) + ' autre(s))' : '');
            Toast.error(msg);
            const pel = document.getElementById('params-msg');
            if (pel) { pel.textContent = '❌ ' + msg; pel.style.color = 'var(--danger)'; }
            return;
        }

        // APC
        const apc = {
            actif: document.getElementById('param-apc-actif')?.checked || false,
            slots: [],
        };
        document.querySelectorAll('#apc-slots-list [data-apc]').forEach(row => {
            apc.slots.push({
                jour: row.querySelector('.apc-jour')?.value || 'lundi',
                debut: row.querySelector('.apc-debut')?.value || '12:00',
                fin: row.querySelector('.apc-fin')?.value || '12:30',
            });
        });

        try {
            const formatSemaine = document.getElementById('param-format-semaine')?.value || 'scolaire';
            const notreEtabId = document.getElementById('param-notre-etablissement')?.value;

            const payload = {
                couleurs_types: couleurs,
                types_reunions: typesReunions,
                fonctions: fonctions,
                horaires: horaires,
                apc: apc,
                jours_affiches: jours,
                format_semaine: formatSemaine,
                theme: theme,
                pauses: pauses,
                email_support: document.getElementById('param-email-support')?.value?.trim() || '',
                notre_etablissement_id: notreEtabId ? parseInt(notreEtabId) : null,
            };

            await API.put('params.php', payload);
            // Sauvegarder le statut vacances des semaines
            const semaineChecks = document.querySelectorAll('.semaine-scolaire');
            const semaineTasks = [];
            semaineChecks.forEach(cb => {
                const id = parseInt(cb.value);
                const estVacances = cb.checked ? 0 : 1;
                semaineTasks.push(API.put('semaines.php?id=' + id, { est_vacances: estVacances }));
            });
            await Promise.all(semaineTasks);

            // Propager via State
            State.set('theme', theme);
            document.getElementById('btn-theme').textContent = theme === 'dark' ? '☀️' : '🌙';
            if (theme === 'dark') document.body.classList.add('dark');
            else document.body.classList.remove('dark');

            document.getElementById('params-msg').textContent = '✅ Sauvegardé';
            State.emit('params:changed');
            setTimeout(() => { document.getElementById('params-msg').textContent = ''; }, 2000);
        } catch (e) {
            document.getElementById('params-msg').textContent = '❌ ' + e.message;
        }
    },

    _renderTypesReunions(types) {
        const container = document.getElementById('types-reunions-list');
        container.innerHTML = Object.entries(types).map(([nom, couleur]) => `
            <div class="form-row type-reunion-row" style="margin-bottom:6px;align-items:center">
                <input type="text" class="type-reunion-nom" value="${escapeHtml(nom)}" placeholder="Nom du type" style="width:180px">
                <input type="color" class="type-reunion-couleur" value="${couleur}" style="width:40px;height:28px;border:none;cursor:pointer">
                <code style="font-size:11px">${couleur}</code>
                <button class="btn-sm btn-del" onclick="this.closest('.type-reunion-row').remove()">×</button>
            </div>
        `).join('') || '<p class="text-muted small">Aucun type configuré.</p>';
    },

    _addTypeReunion() {
        const types = this._data.types_reunions || {};
        let n = 1;
        while (types['Nouveau type ' + n]) n++;
        types['Nouveau type ' + n] = '#90caf9';
        this._data.types_reunions = types;
        this._renderTypesReunions(types);
    },

    _renderFonctions() {
        const fonctions = this._data.fonctions || ['Coordo ULIS', 'Directeur', 'Adjoint', 'RASED'];
        const container = document.getElementById('fonctions-list');
        container.innerHTML = fonctions.map((f, i) => `
            <div class="form-row fonction-row" style="margin-bottom:4px;align-items:center">
                <input type="text" class="fonction-input" value="${escapeHtml(f)}" placeholder="Nom de la fonction" style="width:250px">
                <button class="btn-sm btn-del" onclick="this.closest('.fonction-row').remove()">×</button>
            </div>
        `).join('') || '<p class="text-muted small">Aucune fonction configurée.</p>';
    },

    _addFonction() {
        const container = document.getElementById('fonctions-list');
        const row = document.createElement('div');
        row.className = 'form-row fonction-row';
        row.style.cssText = 'margin-bottom:4px;align-items:center';
        row.innerHTML = `<input type="text" class="fonction-input" value="" placeholder="Nom de la fonction" style="width:250px"><button class="btn-sm btn-del" onclick="this.closest('.fonction-row').remove()">×</button>`;
        container.appendChild(row);
        row.querySelector('input').focus();
    },

    async _loadNotreEtablissement() {
        const select = document.getElementById('param-notre-etablissement');
        if (!select) return;
        try {
            const etabs = await API.get('etablissements.php');
            const currentId = this._data.notre_etablissement_id;
            select.innerHTML = '<option value="">— Non configuré —</option>' +
                etabs.filter(e => e.actif !== 0).map(e =>
                    `<option value="${e.id}" ${e.id === currentId ? 'selected' : ''}>${escapeHtml(e.nom)}${e.ville ? ' (' + escapeHtml(e.ville) + ')' : ''}</option>`
                ).join('');

            const info = document.getElementById('notre-etablissement-info');
            if (info) {
                const selected = etabs.find(e => e.id === currentId);
                if (selected) {
                    const parts = [selected.type ? selected.type.replace(/_/g, ' ') : ''];
                    if (selected.telephone) parts.push('📞 ' + selected.telephone);
                    if (selected.email) parts.push('✉ ' + selected.email);
                    info.textContent = '✓ ' + selected.nom + (parts.length ? ' — ' + parts.join(' · ') : '');
                } else {
                    info.textContent = currentId ? '⚠ Établissement sélectionné introuvable' : '';
                }
            }
        } catch {
            if (document.getElementById('notre-etablissement-info')) {
                document.getElementById('notre-etablissement-info').textContent = '⚠ Erreur de chargement';
            }
        }
    },

    _defaults() {
        return {
            couleurs_types: { ULIS: '#bbdefb', INCLUSION: '#c8e6c9', DECLOISONNEMENT: '#fff9c4', PEC: '#ffccbc', AUTRE: '#e0e0e0' },
            types_reunions: { 'ESS': '#bbdefb', 'Équipe éducative': '#c8e6c9', 'RDV famille': '#fff9c4', 'Partenariat': '#ffccbc', 'Autre': '#e0e0e0' },
            fonctions: ['Coordo ULIS', 'Directeur', 'Adjoint', 'RASED'],
            horaires: { debut: '08:30', fin_matin: '11:30', debut_aprem: '13:30', fin: '16:30', duree_creneau: 15 },
            jours_affiches: ['lundi', 'mardi', 'jeudi', 'vendredi'],
            theme: 'clair',
        };
    },

    async _loadSnapshotsList() {
        const select = document.getElementById('param-db-snapshot');
        const status = document.getElementById('db-status');
        if (!select) return;
        select.innerHTML = '<option value="">Chargement...</option>';
        try {
            const snapshots = await API.get('db-loader.php');
            select.innerHTML = snapshots.map(s =>
                `<option value="${s.id}" data-description="${escapeHtml(s.description)}">${escapeHtml(s.label)}</option>`
            ).join('');
            if (status) {
                const first = snapshots[0];
                if (first) status.textContent = first.description;
            }
        } catch {
            select.innerHTML = '<option value="">Erreur de chargement</option>';
            if (status) status.textContent = '⚠ Impossible de charger la liste des snapshots';
        }
    },

    async _loadSnapshot() {
        const select = document.getElementById('param-db-snapshot');
        const status = document.getElementById('db-status');
        const btn = document.getElementById('btn-load-snapshot');
        const snapshot = select?.value;
        if (!snapshot) { status.textContent = '⚠ Sélectionne un snapshot d\'abord'; return; }

        const label = select.options[select.selectedIndex]?.text || snapshot;
        if (!await Modal.confirm('Charger', `Charger le snapshot « ${label} » ?\n\nToutes les données non sauvegardées seront perdues.`)) return;

        btn.disabled = true;
        btn.textContent = '⏳ Chargement...';
        status.textContent = 'Chargement en cours...';

        try {
            const res = await API.post('db-loader.php', { snapshot });
            status.textContent = '✅ ' + (res.message || 'Snapshot chargé');
            status.style.color = 'var(--success)';
            State.emit('db:loaded', res.counts);
        } catch (e) {
            status.textContent = '❌ ' + e.message;
            status.style.color = 'var(--danger)';
        } finally {
            btn.disabled = false;
            btn.textContent = '🔄 Charger cette base';
        }
    },

    async _exportDB() {
        const msg = document.getElementById('db-export-msg');
        try {
            const res = await fetch('api/db-export.php');
            if (!res.ok) throw new Error("Le serveur a refusé l'export (HTTP " + res.status + ").");
            const blob = await res.blob();
            const a = document.createElement('a');
            a.href = URL.createObjectURL(blob);
            a.download = 'calulis-backup-' + new Date().toISOString().slice(0, 10) + '.sql';
            document.body.appendChild(a);
            a.click();
            a.remove();
            setTimeout(() => URL.revokeObjectURL(a.href), 5000);
            if (msg) { msg.textContent = '✅ Téléchargement lancé'; msg.style.color = 'var(--success)'; }
            setTimeout(() => { if (msg) { msg.textContent = ''; msg.style.color = ''; } }, 3000);
        } catch (e) {
            if (msg) { msg.textContent = '❌ ' + e.message; msg.style.color = 'var(--danger)'; }
        }
    },

    async _importDB() {
        const fileInput = document.getElementById('db-import-file');
        const file = fileInput.files[0];
        if (!file) return;

        if (!await Modal.confirm('Restaurer', `Restaurer la base depuis « ${file.name} » ?\n\n⚠️ Toutes les données actuelles seront remplacées. Cette action est irréversible.`)) return;

        const status = document.getElementById('db-import-status');
        const btn = document.getElementById('btn-db-import-go');
        btn.disabled = true;
        btn.textContent = '⏳ Restauration...';
        status.textContent = 'Import en cours...';

        const form = new FormData();
        form.append('sqlfile', file);

        try {
            const res = await fetch('api/db-import.php', { method: 'POST', body: form });
            const data = await res.json();
            if (res.ok) {
                status.textContent = '✅ ' + data.message;
                status.style.color = 'var(--success)';
                State.emit('db:loaded', data.counts);
                Toast.success('Base restaurée avec succès');
            } else {
                status.textContent = '❌ ' + (data.error || 'Échec');
                status.style.color = 'var(--danger)';
                Toast.error(data.error || 'Échec de la restauration');
            }
        } catch (e) {
            status.textContent = '❌ ' + e.message;
            status.style.color = 'var(--danger)';
            Toast.error(e.message);
        } finally {
            btn.disabled = false;
            btn.textContent = '📤 Restaurer cette sauvegarde';
            fileInput.value = '';
            document.getElementById('db-import-name').textContent = '';
            btn.style.display = 'none';
        }
    },

    // ── Purge anciens élèves ────────────────────────

    async _purgeAnciensEleves() {
        const dateInput = document.getElementById('purge-avant-date');
        const dateAvant = dateInput.value;
        if (!dateAvant) {
            Toast.error('Veuillez sélectionner une date limite.');
            return;
        }
        if (!await Modal.confirm('🧹 Purger les anciens élèves',
            `Supprimer définitivement les données des élèves inactifs dont la dernière inscription est antérieure au ${dateAvant} ?\n\n`
            + `⚠️ Cette action est irréversible.\n👉 Faites une sauvegarde avant.`)) return;

        const status = document.getElementById('purge-status');
        status.textContent = '⏳ Purge en cours...';
        const btn = document.getElementById('btn-purge-anciens');
        btn.disabled = true;

        try {
            const res = await fetch('api/eleves.php?action=purge&before=' + dateAvant, { method: 'POST' });
            const data = await res.json();
            if (res.ok) {
                const msg = `✅ ${data.purged} élève(s) supprimé(s).`;
                status.textContent = msg;
                status.style.color = 'var(--success)';
                Toast.success(msg);
                State.emit('eleves:changed');
            } else {
                status.textContent = '❌ ' + (data.error || 'Échec');
                status.style.color = 'var(--danger)';
                Toast.error(data.error || 'Échec de la purge');
            }
        } catch (e) {
            status.textContent = '❌ ' + e.message;
            status.style.color = 'var(--danger)';
            Toast.error(e.message);
        } finally {
            btn.disabled = false;
        }
    },

    // ── Import CSV (élèves) ──────────────────────────

    async _importGenscol() {
        const fileInput = document.getElementById('genscol-file');
        const file = fileInput.files[0];
        if (!file) return;

        const status = document.getElementById('genscol-status');
        const btn = document.getElementById('btn-genscol-import');
        btn.disabled = true;
        btn.textContent = '⏳ Import...';
        status.textContent = 'Import en cours...';

        try {
            // Lire le fichier CSV
            const text = await file.text();
            const res = await fetch('/api/import-genscol.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ csv_content: text }),
            });
            const data = await res.json();
            if (data.ok) {
                const r = data.result;
                status.innerHTML = `✅ ${r.imported}/${r.total} élèves importés (${r.matched} matchés)`;
                if (r.errors.length) {
                    status.innerHTML += '<br><span style="color:var(--warning)">⚠ ' + r.errors.slice(0, 5).join('<br>') + '</span>';
                }
                status.style.color = 'var(--success)';
                Toast.success(data.message);
            } else {
                status.textContent = '❌ ' + (data.error || 'Échec');
                status.style.color = 'var(--danger)';
                Toast.error(data.error || 'Échec');
            }
        } catch (e) {
            status.textContent = '❌ ' + e.message;
            status.style.color = 'var(--danger)';
            Toast.error(e.message);
        } finally {
            btn.disabled = false;
            btn.textContent = '📥 Importer';
        }
    },

    // ── Années scolaires ──────────────────────────────

    _renderAnnees() {
        const container = document.getElementById('annees-list');
        if (!container) return;

        // Toujours vider le message d'erreur résiduel
        const msgEl = document.getElementById('annee-msg');
        if (msgEl) msgEl.textContent = '';

        const annees = State.get('annees') || [];
        const activeId = State.get('annee_scolaire_id');

        if (annees.length === 0) {
            container.innerHTML = '<p class="text-muted small">Aucune année scolaire configurée. Créez votre première année avec le bouton ci-dessous.</p>';
            return;
        }

        // Trier : année active en premier, puis ordre chronologique décroissant
        const sorted = [...annees].sort((a, b) => {
            if (a.id == activeId) return -1;
            if (b.id == activeId) return 1;
            return (b.date_debut || '').localeCompare(a.date_debut || '');
        });

        container.innerHTML = sorted.map(a => {
            const isActive = a.id == activeId;
            // Style spécial pour l'année active : fond bleu clair + bordure
            const rowStyle = isActive
                ? 'background:#e8eaf6;border:2px solid var(--primary);border-radius:var(--radius);padding:10px 12px'
                : 'padding:8px 12px;border-bottom:1px solid var(--border)';
            return `
                <div style="display:flex;align-items:center;gap:12px;${rowStyle}" data-annee-id="${a.id}">
                    <span style="font-weight:600;font-size:14px;min-width:110px">
                        ${escapeHtml(a.nom)}
                    </span>
                    <span style="color:var(--primary);font-weight:700;font-size:12px;min-width:65px">
                        ${isActive ? '● Année active' : ''}
                    </span>
                    <span class="text-muted small" style="min-width:130px">
                        📆 ${a.date_debut ? a.date_debut.slice(0, 4) + ' → ' + (a.date_fin ? a.date_fin.slice(0, 4) : '') : ''}
                    </span>
                    ${!isActive ? `
                        <button class="btn btn-sm btn-primary btn-activate-annee" data-id="${a.id}">
                            ✅ Définir comme active
                        </button>
                        <button class="btn btn-sm btn-del btn-delete-annee" data-id="${a.id}" title="Supprimer cette année">
                            ×
                        </button>
                    ` : ''}
                </div>
            `;
        }).join('');

        // Activer une année
        container.querySelectorAll('.btn-activate-annee').forEach(btn => {
            btn.addEventListener('click', async () => {
                const id = parseInt(btn.dataset.id);
                try {
                    await API.put('annees_scolaires.php?action=activate&id=' + id, {});
                    await State.initAnneeScolaire(); // Recharger
                    this._renderAnnees();
                    Toast.success('Année activée');
                } catch (e) {
                    Toast.error(e.message);
                }
            });
        });

        // Supprimer une année
        container.querySelectorAll('.btn-delete-annee').forEach(btn => {
            btn.addEventListener('click', async () => {
                const id = parseInt(btn.dataset.id);
                const row = btn.closest('[data-annee-id]');
                const nomEl = row?.querySelector('span');
                const nom = nomEl?.textContent?.trim() || 'cette année';
                if (!await Modal.confirm('Supprimer', `Supprimer l'année « ${nom} » ?\n\nLes données liées (élèves, semaines, créneaux) seront également supprimées.`)) return;
                try {
                    await API.del('annees_scolaires.php?id=' + id);
                    await State.initAnneeScolaire();
                    this._renderAnnees();
                    Toast.success('Année supprimée');
                } catch (e) {
                    Toast.error(e.message);
                }
            });
        });
    },

    _addAnnee() {
        const now = new Date();
        const currentYear = now.getMonth() >= 8 ? now.getFullYear() : now.getFullYear() - 1;
        const anneeCourante = currentYear + '-' + (currentYear + 1);

        Modal.open({
            title: '➕ Nouvelle année scolaire',
            body: `
                <div class="form-row" style="margin-bottom:12px">
                    <div class="form-group"><label>Nom</label>
                        <input type="text" id="new-annee-nom" class="form-input" value="${anneeCourante}" placeholder="ex: 2027-2028" style="width:100%">
                    </div>
                </div>
                <div class="form-row" style="gap:12px">
                    <div class="form-group"><label>Date début</label>
                        <input type="date" id="new-annee-debut" class="form-input" value="${currentYear}-08-31" style="width:100%">
                    </div>
                    <div class="form-group"><label>Date fin</label>
                        <input type="date" id="new-annee-fin" class="form-input" value="${currentYear + 1}-07-04" style="width:100%">
                    </div>
                </div>
                <div class="form-row" style="margin-top:8px">
                    <label><input type="checkbox" id="new-annee-activer" checked> Activer immédiatement</label>
                </div>
                <div class="form-row" style="margin-top:8px">
                    <label><input type="checkbox" id="new-annee-reconduire" checked> Copier les élèves depuis l'année active</label>
                </div>
            `,
            footer: `
                <button class="btn btn-secondary" onclick="Modal.close()">Annuler</button>
                <button class="btn btn-primary" id="btn-create-annee">Créer</button>
            `,
        });

        document.getElementById('btn-create-annee').addEventListener('click', async () => {
            const nom = document.getElementById('new-annee-nom').value.trim();
            const debut = document.getElementById('new-annee-debut').value;
            const fin = document.getElementById('new-annee-fin').value;
            const activer = document.getElementById('new-annee-activer').checked;
            const reconduire = document.getElementById('new-annee-reconduire').checked;

            if (!nom || !debut || !fin) { Toast.error('Nom, date début et date fin requis'); return; }

            try {
                const res = await API.post('annees_scolaires.php', {
                    nom, date_debut: debut, date_fin: fin, est_active: activer ? 1 : 0,
                });
                const newId = res.id;

                // Copier les élèves dans la nouvelle année si demandé.
                // IMPORTANT : récupérer TOUS les élèves actifs, pas seulement ceux de l'année
                // active. Un élève créé avant l'existence d'une année n'est lié à AUCUNE année
                // (aucune entrée eleve_annees) et disparaîtrait du roster du nouveau roster
                // (bug : « créer une année → les élèves disparaissent »).
                if (reconduire) {
                    try {
                        const res = await fetch('api/eleves.php?inclure_inactifs=0');
                        const eleves = res.ok ? await res.json() : [];
                        for (const el of eleves) {
                            // Construire le body : les champs de l'élève + la nouvelle année
                            const body = { ...el, annee_scolaire_id: newId };
                            await fetch('/api/eleves.php?id=' + el.id, {
                                method: 'PUT',
                                headers: { 'Content-Type': 'application/json' },
                                body: JSON.stringify(body),
                            });
                        }
                    } catch (e) {
                        console.warn('Reconduction partielle:', e);
                    }
                }

                await State.initAnneeScolaire();
                Modal.close();
                this._renderAnnees();
                Toast.success('Année « ' + nom + ' » créée' + (reconduire ? ' avec reconduction' : ''));
                document.getElementById('annee-msg').textContent = '✅ Créée';
            } catch (e) {
                Toast.error(e.message);
            }
        });
    },

    async _runMigration() {
        try {
            const res = await fetch('/api/run-migration.php', { method: 'POST' });
            const data = await res.json();
            if (data.ok) {
                Toast.success(data.message || 'Migration appliquée');
                document.getElementById('annee-msg').textContent = '✅ Migration OK';
                // Recharger les années
                await State.initAnneeScolaire();
                this._renderAnnees();
            } else {
                const errMsg = data.errors?.join('; ') || 'Erreur inconnue';
                Toast.error('Migration partielle: ' + errMsg);
                document.getElementById('annee-msg').textContent = '⚠ Erreurs: ' + errMsg;
            }
        } catch (e) {
            Toast.error('Erreur: ' + e.message);
            document.getElementById('annee-msg').textContent = '❌ ' + e.message;
        }
    },

    async _importCalendrier() {
        const anneeId = State.get('annee_scolaire_id');
        if (!anneeId) { Toast.error('Aucune année scolaire sélectionnée'); return; }

        const zoneSelect = document.getElementById('param-zone-calendrier');
        const zone = zoneSelect?.value || 'Zone B';

        // Vérifier si l'année a déjà des semaines
        const annees = State.get('annees') || [];
        const active = annees.find(a => a.id == anneeId);
        const nomAnnee = active?.nom || 'cette année';

        if (!await Modal.confirm('Importer le calendrier',
            `Importer les semaines et les vacances depuis le site de l'Éducation Nationale (${zone}) pour l'année « ${nomAnnee} » ?\n\n` +
            `Cette opération va créer automatiquement toutes les semaines scolaires et les périodes de vacances.\n\n` +
            `⚠️ Si l'année a déjà des semaines, l'import sera refusé pour ne pas effacer vos créneaux.`
        )) return;

        document.getElementById('annee-msg').textContent = '⏳ Import du calendrier officiel (' + zone + ')...';
        try {
            const res = await API.post('calendrier-scolaire.php', {
                annee_scolaire_id: anneeId,
                zone: zone,
            });
            document.getElementById('annee-msg').textContent =
                `✅ ${res.semaines_creees} semaines importées (${res.vacances?.length || 0} périodes de vacances)`;
            Toast.success('Calendrier importé : ' + res.semaines_creees + ' semaines');
            await State.initAnneeScolaire();
            this._renderAnnees();
        } catch (e) {
            Toast.error('Import échoué: ' + e.message);
            document.getElementById('annee-msg').textContent = '❌ ' + e.message;
        }
    },

    async _deleteCalendrier() {
        const anneeId = State.get('annee_scolaire_id');
        if (!anneeId) { Toast.error('Aucune année scolaire sélectionnée'); return; }
        if (!await Modal.confirm('🗑️ Supprimer le calendrier', 'Supprimer les semaines et les vacances importées pour l\'année active ?\n\nVous pourrez réimporter le calendrier avec la bonne zone ou la bonne année.')) return;
        try {
            const res = await API.del('calendrier-scolaire.php?annee_scolaire_id=' + anneeId);
            await State.initAnneeScolaire();
            this._renderAnnees();
            Toast.success('Calendrier supprimé (' + (res.semaines_supprimees || 0) + ' semaines)');
            const el = document.getElementById('annee-msg');
            if (el) { el.textContent = '🗑️ Calendrier supprimé. Vous pouvez le réimporter.'; el.style.color = 'var(--danger)'; }
        } catch (e) {
            Toast.error(e.message);
            const el = document.getElementById('annee-msg');
            if (el) { el.textContent = '❌ ' + e.message; el.style.color = 'var(--danger)'; }
        }
    },

};
