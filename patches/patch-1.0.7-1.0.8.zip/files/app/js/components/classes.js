/**
 * Calulis — Composant Classes
 */
/** Niveaux scolaires disponibles, regroupés par cycle (ULIS maternelle → lycée pro) */
const NIVEAUX_GROUPES = [
    { label: 'Maternelle', niveaux: ['tps', 'ps', 'ms', 'gs'] },
    { label: 'Élémentaire', niveaux: ['cp', 'ce1', 'ce2', 'cm1', 'cm2'] },
    { label: 'Collège', niveaux: ['6e', '5e', '4e', '3e'] },
    { label: 'Lycée', niveaux: ['2nde', '1ere', 'tle'] },
    { label: 'Lycée professionnel', niveaux: ['cap1', 'cap2', '2nde_pro', '1ere_pro', 'tle_pro'] },
];
const NIVEAUX_KEYS = NIVEAUX_GROUPES.flatMap(g => g.niveaux);
const NIVEAU_LABELS = {
    tps: 'TPS', ps: 'PS', ms: 'MS', gs: 'GS',
    cp: 'CP', ce1: 'CE1', ce2: 'CE2', cm1: 'CM1', cm2: 'CM2',
    '6e': '6e', '5e': '5e', '4e': '4e', '3e': '3e',
    '2nde': '2nde', '1ere': '1ère', tle: 'Tle',
    cap1: 'CAP 1', cap2: 'CAP 2',
    '2nde_pro': '2de Pro', '1ere_pro': '1re Pro', tle_pro: 'Tle Pro',
};

const ClassesView = {
    _classes: [],
    _adultes: [],
    _etablissements: [],
    _searchTerm: '',

    async render() {
        const view = document.getElementById('view-classes');
        try {
            const [classes, adultes, etabs] = await Promise.all([
                API.get('classes.php'),
                API.get('adultes.php'),
                API.get('etablissements.php'),
            ]);
            this._classes = classes;
            this._adultes = adultes;
            this._etablissements = etabs;
        } catch (e) {
            view.innerHTML = `<div class="placeholder-text">Erreur : ${escapeHtml(e.message)}</div>`;
            return;
        }

        const notreId = this._notreEtablissementId();
        this._refresh(notreId);
    },

    _notreEtablissementId() {
        try {
            const raw = localStorage.getItem('calulis_params');
            if (raw) {
                const params = JSON.parse(raw);
                return params.notre_etablissement_id;
            }
        } catch {}
        return null;
    },

    _refresh(notreId) {
        const view = document.getElementById('view-classes');
        const q = this._searchTerm.toLowerCase();
        let classes = this._classes.filter(c => {
            if (q) {
                return (c.nom || '').toLowerCase().includes(q)
                    || (c.niveaux || '').toLowerCase().includes(q)
                    || (c.enseignants || []).map(a => ((a.prenom || '') + ' ' + (a.nom || '')).toLowerCase()).join(' ').includes(q);
            }
            return true;
        });

        // Trier : notre établissement d'abord, puis par niveau
        classes.sort((a, b) => {
            if (notreId) {
                const aNous = a.etablissement_id === notreId ? 0 : 1;
                const bNous = b.etablissement_id === notreId ? 0 : 1;
                if (aNous !== bNous) return aNous - bNous;
            }
            return (a.nom || '').localeCompare(b.nom || '');
        });

        const niveauxLabel = (n) => {
            try {
                const arr = typeof n === 'string' ? JSON.parse(n) : n;
                if (Array.isArray(arr)) return arr.map(x => NIVEAU_LABELS[x] || x).join('+');
            } catch {}
            return n || '?';
        };

        view.innerHTML = `
            <div style="max-width:800px">
                <div class="form-row" style="margin-bottom:12px;align-items:center">
                    <div class="form-group" style="flex:1;max-width:300px">
                        <input type="text" id="classes-search" placeholder="🔍 Rechercher..." value="${escapeHtml(this._searchTerm)}"
                               style="width:100%;font-size:13px;padding-right:28px">
                    </div>
                    ${this._searchTerm ? `<button class="btn btn-sm btn-secondary" id="btn-clear-search" style="margin-left:4px">✕</button>` : ''}
                    <button class="btn btn-primary" id="btn-new-classe" style="margin-left:auto">+ Nouvelle classe</button>
                </div>
                <div id="classes-list"></div>
            </div>
        `;

        // Liste
        const list = document.getElementById('classes-list');
        if (!classes.length) {
            const hasFilter = q.length > 0;
            const cta = hasFilter ? '' : '<button class="btn btn-primary" onclick="ClassesView._openFiche({})" style="margin-top:12px">+ Nouvelle classe</button>';
            list.innerHTML = `<div style="text-align:center;padding:32px;color:var(--text-muted)">${hasFilter ? 'Aucun résultat trouvé.' : `Aucune classe enregistrée.<br>${cta}`}</div>`;
        } else {
            list.innerHTML = classes.map(c => {
                const isNotre = notreId && c.etablissement_id == notreId;
                const ens = (c.enseignants || []).map(a => ((a.prenom || '') + ' ' + (a.nom || '')).trim()).filter(Boolean);
                const enseignant = ens.length ? ens.join(' · ') : '—';
                const roleLabel = '👩‍🏫 ' + escapeHtml(enseignant);
                return `
                <div class="card card-hover" style="margin-bottom:6px;padding:10px 14px;cursor:pointer"
                     data-id="${c.id}" data-action="edit-classe"
                     style="${isNotre ? 'border-left:3px solid var(--primary)' : ''}">
                    <div style="display:flex;align-items:center;gap:12px">
                        <span class="badge" style="background:${isNotre ? 'var(--primary)' : '#666'};color:#fff;min-width:48px;text-align:center">${escapeHtml(niveauxLabel(c.niveaux))}</span>
                        <strong style="flex:1">${escapeHtml(c.nom)}</strong>
                        <span style="color:var(--text-muted);font-size:13px">${roleLabel}</span>
                        <span style="color:var(--text-muted);font-size:12px">${escapeHtml(c.etablissement_nom || '')}</span>
                        <span class="text-muted" style="font-size:11px" title="Double-clic pour éditer">📋</span>
                    </div>
                </div>`;
            }).join('');
        }

        // Events
        document.getElementById('btn-new-classe')?.addEventListener('click', () => this._openFiche({}));
        document.getElementById('btn-clear-search')?.addEventListener('click', () => { this._searchTerm = ''; this._refresh(notreId); });
        document.getElementById('classes-search')?.addEventListener('input', (e) => {
            this._searchTerm = e.target.value;
            this._refresh(notreId);
        });

        document.querySelectorAll('[data-action="edit-classe"]').forEach(card => {
            card.addEventListener('click', () => {
                const id = parseInt(card.dataset.id);
                const c = this._classes.find(x => x.id === id);
                if (c) this._openFiche(c);
            });
        });
    },

    async _openFiche(classe) {
        const isNew = !classe.id;
        const title = isNew ? 'Nouvelle classe' : `Classe : ${classe.nom}`;
        const notreId = this._notreEtablissementId();

        const enseignants = this._adultes.filter(a => a.actif != 0 && (a.role === 'enseignant' || a.role === 'coordo_ulis'));
        const etabs = this._etablissements.filter(e => e.actif !== 0);

        const selectedEns = classe.enseignant_id || '';
        const selectedEtab = classe.etablissement_id || notreId || '';

        // Parser les niveaux existants
        let currentNiveaux = [];
        try {
            const raw = classe.niveaux;
            if (typeof raw === 'string') currentNiveaux = JSON.parse(raw);
            else if (Array.isArray(raw)) currentNiveaux = raw;
        } catch { currentNiveaux = []; }

        const btnSuppr = !isNew ? `<button class="btn btn-danger" id="fc-delete" style="margin-right:auto">Supprimer</button>` : '';
        const footer = `
            ${btnSuppr}
            <button class="btn btn-secondary" id="fc-cancel">Annuler</button>
            <button class="btn btn-primary" id="fc-save">Enregistrer</button>
        `;

        Modal.open({
            title,
            body: `
                <div class="form-group"><label>Nom</label>
                    <input type="text" id="fc-nom" value="${escapeHtml(classe.nom || '')}" placeholder="ex: 6e-5e, CP-CE1...">
                    <span class="text-muted small">Cosmétique, pour l'affichage</span>
                </div>
                <div class="form-group"><label>Niveaux</label>
                    <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:12px">
                        ${NIVEAUX_GROUPES.map(g => `
                            <div>
                                <div class="text-muted small" style="font-weight:600;margin-bottom:4px;padding-bottom:2px;border-bottom:1px solid rgba(0,0,0,.15)">${g.label}</div>
                                <div style="display:flex;flex-direction:column;gap:3px">
                                    ${g.niveaux.map(n => `
                                        <label style="display:flex;align-items:center;gap:4px;cursor:pointer;font-size:14px">
                                            <input type="checkbox" class="fc-niveau" value="${n}" ${currentNiveaux.includes(n) ? 'checked' : ''}>
                                            ${NIVEAU_LABELS[n]}
                                        </label>
                                    `).join('')}
                                </div>
                            </div>
                        `).join('')}
                    </div>
                    <span class="text-muted small">Coche tous les niveaux présents dans cette classe</span>
                </div>
                <div class="form-group">
                    <label style="display:flex;justify-content:space-between;align-items:center">
                        <span>Enseignant(s)</span>
                        <button type="button" class="btn btn-sm btn-secondary" id="fc-add-enseignant">➕ Ajouter</button>
                    </label>
                    <div id="fc-enseignants-rows"></div>
                </div>
                <div class="form-group"><label>Établissement</label>
                    <select id="fc-etablissement_id">
                        <option value="">— Aucun —</option>
                        ${etabs.map(e =>
                            `<option value="${e.id}" ${e.id === selectedEtab ? 'selected' : ''}>${escapeHtml(e.nom)}${e.ville ? ' (' + escapeHtml(e.ville) + ')' : ''}</option>`
                        ).join('')}
                    </select>
                </div>
                ${!isNew ? `<p class="text-muted small" style="margin-top:8px">Élèves dans cette classe : <span id="fc-eleves-count">...</span></p><div id="fc-aesh-staff" style="margin-top:8px"></div>` : ''}
            `,
            footer,
        });
        const ensOptions = enseignants.map(a =>
            '<option value="' + a.id + '">' + escapeHtml(a.prenom) + ' ' + escapeHtml(a.nom) + ' (' + escapeHtml(a.fonction ? this._formatFonction(a.fonction) : a.role) + ')</option>'
        ).join('');
        const joursListe = ['lundi', 'mardi', 'jeudi', 'vendredi'];
        const buildEnsRow = (ens) => {
            const jours = Array.isArray(ens.jours) ? ens.jours : [];
            const joursHtml = joursListe.map(jr => {
                const checked = jours.includes(jr) ? ' checked' : '';
                return '<label style="display:flex;align-items:center;gap:3px;cursor:pointer"><input type="checkbox" class="fc-ens-jour" value="' + jr + '"' + checked + '> ' + jr.charAt(0).toUpperCase() + jr.slice(1, 3) + '</label>';
            }).join('');
            const plage = ens.plage || 'journee';
            return '<div class="fc-ens-row" style="border:1px solid var(--border-color);border-radius:6px;padding:8px;margin-bottom:6px">'
                + '<div style="display:flex;gap:6px;align-items:center;margin-bottom:6px">'
                + '<select class="fc-ens-adulte" style="flex:1"><option value="">— Aucun —</option>' + ensOptions + '</select>'
                + '<button type="button" class="btn btn-sm btn-danger fc-ens-rm" title="Retirer">✕</button>'
                + '</div>'
                + '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap;font-size:13px">'
                + joursHtml
                + '<select class="fc-ens-plage">'
                + '<option value="journee"' + (plage === 'journee' ? ' selected' : '') + '>Journée</option>'
                + '<option value="matin"' + (plage === 'matin' ? ' selected' : '') + '>Matin</option>'
                + '<option value="apres_midi"' + (plage === 'apres_midi' ? ' selected' : '') + '>Après-midi</option>'
                + '</select>'
                + '</div>'
                + '</div>';
        };
        const ensRows = document.getElementById('fc-enseignants-rows');
        const existing = Array.isArray(classe.enseignants) ? classe.enseignants : [];
        const initial = existing.length ? existing : [{ adulte_id: '', jours: [], plage: 'journee' }];
        ensRows.innerHTML = initial.map(buildEnsRow).join('');
        initial.forEach((ens, i) => {
            const row = ensRows.querySelectorAll('.fc-ens-row')[i];
            if (row && ens.adulte_id) row.querySelector('.fc-ens-adulte').value = String(ens.adulte_id);
        });
        const bindRow = (row) => { row.querySelector('.fc-ens-rm')?.addEventListener('click', () => row.remove()); };
        ensRows.querySelectorAll('.fc-ens-row').forEach(bindRow);
        document.getElementById('fc-add-enseignant')?.addEventListener('click', () => {
            ensRows.insertAdjacentHTML('beforeend', buildEnsRow({ adulte_id: '', jours: [], plage: 'journee' }));
            bindRow(ensRows.lastElementChild);
        });

        // Events
        document.getElementById('fc-save').addEventListener('click', async () => {
            const niveaux = Array.from(document.querySelectorAll('.fc-niveau:checked')).map(cb => cb.value);
            const enseignantsData = [];
            document.querySelectorAll('#fc-enseignants-rows .fc-ens-row').forEach(row => {
                const adulte_id = row.querySelector('.fc-ens-adulte')?.value;
                if (!adulte_id) return;
                const jours = Array.from(row.querySelectorAll('.fc-ens-jour:checked')).map(cb => cb.value);
                const plage = row.querySelector('.fc-ens-plage')?.value || 'journee';
                enseignantsData.push({ adulte_id: parseInt(adulte_id), jours, plage });
            });
            const data = {
                nom: document.getElementById('fc-nom').value.trim(),
                niveaux: JSON.stringify(niveaux),
                enseignants: enseignantsData,
                etablissement_id: document.getElementById('fc-etablissement_id').value || null,
            };
            if (!data.nom) { Modal.alert('Erreur', 'Le nom est requis'); return; }
            if (niveaux.length === 0) { Modal.alert('Erreur', 'Sélectionne au moins un niveau'); return; }
            try {
                if (isNew) {
                    await API.post('classes.php', data);
                } else {
                    await API.put(`classes.php?id=${classe.id}`, data);
                }
                Modal.close();
                this.render();
            } catch (e) { Modal.alert('Erreur', e.message); }
        });
        document.getElementById('fc-cancel').addEventListener('click', () => Modal.close());

        const btnDel = document.getElementById('fc-delete');
        if (btnDel) {
            btnDel.addEventListener('click', async () => {
                if (!await Modal.confirm('Confirmer', `Supprimer la classe « ${classe.nom} » ?`)) return;
                await API.del(`classes.php?id=${classe.id}`);
                Modal.close();
                this.render();
            });
        }

        // Charger le nombre d'élèves + AESH pour le dispositif ULIS
        if (!isNew && classe.id) {
            try {
                const full = await API.get(`classes.php?id=${classe.id}`);
                const el = document.getElementById('fc-eleves-count');
                if (el) el.textContent = (full.eleves || []).length;

                // Afficher le personnel AESH
                const aeshStaff = full.aesh_staff || [];
                if (aeshStaff.length > 0) {
                    const aeshContainer = document.getElementById('fc-aesh-staff');
                    if (aeshContainer) {
                        aeshContainer.innerHTML = aeshStaff.map(a => {
                            const typeLabel = a.role === 'aeshco' ? 'AESHco' : 'AESHi';
                            const elevesList = (a.eleves || []).map(e =>
                                `${e.prenom} ${e.nom} (${e.type || '?'}, ${e.heures || '?'})`
                            ).join('<br>');
                            return `<div style="margin-bottom:8px;font-size:13px">
                                <strong>${escapeHtml(a.prenom)} ${escapeHtml(a.nom)}</strong>
                                <span class="badge" style="margin-left:6px;font-size:10px">${typeLabel}</span>
                                ${a.telephone ? ' 📞 ' + escapeHtml(a.telephone) : ''}
                                ${a.email ? ' ✉ ' + escapeHtml(a.email) : ''}
                                ${elevesList ? `<div style="margin-left:16px;color:var(--text-muted);font-size:12px">${elevesList}</div>` : '<div style="margin-left:16px;color:var(--text-muted);font-size:12px">Aucun élève rattaché</div>'}
                            </div>`;
                        }).join('');
                    }
                }
            } catch {}
        }
    },

    _formatFonction(f) {
        if (!f) return '';
        return f.split(/[_-]/).map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
    },
};
