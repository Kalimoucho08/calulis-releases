/**
 * Calulis — Agenda Clipboard : copier/couper/coller
 * Ajouté à Agenda via Object.assign
 */

Object.assign(Agenda, {

    _copySelection() {
        const creneaux = this._getSelectedCreneaux();
        if (creneaux.length > 0) {
            this._clipboard = {
                creneaux: creneaux.map(c => ({
                    eleve_id: c.eleve_id,
                    matiere: c.matiere,
                    groupe: c.groupe,
                    adulte: c.adulte,
                    role_adulte: c.role_adulte,
                    type: c.type,
                    regroupement_type: c.regroupement_type,
                    couleur_override: c.couleur_override,
                    commentaire: c.commentaire,
                    duree: c.duree,
                })),
                mode: 'copy',
            };
            const status = document.getElementById('status-selection');
            if (status) status.textContent = `${creneaux.length} créneau(x) copié(s)`;
        }
    },

    async _cutSelection() {
        const creneaux = this._getSelectedCreneaux();
        if (creneaux.length === 0) return;

        this._clipboard = {
            creneaux: creneaux.map(c => ({
                eleve_id: c.eleve_id,
                matiere: c.matiere,
                groupe: c.groupe,
                adulte: c.adulte,
                role_adulte: c.role_adulte,
                type: c.type,
                regroupement_type: c.regroupement_type,
                couleur_override: c.couleur_override,
                commentaire: c.commentaire,
                duree: c.duree,
            })),
            mode: 'cut',
        };

        // Supprimer les originaux
        const tasks = creneaux.map(c => API.del('creneaux.php?id=' + c.id));
        try {
            await Promise.all(tasks);
            await this._markModified();
            this._clearSelection();
            this._creneaux = await API.get('creneaux.php' + (this._semaineId !== null ? '?semaine_id=' + this._semaineId : '?semaine_id=null'));
            this._creneaux = this._creneaux.map(c => ({ ...c, heure_debut: c.heure_debut?.substring(0, 5) }));
            this._rebuildGrid();
            const status = document.getElementById('status-selection');
            if (status) status.textContent = `${creneaux.length} créneau(x) coupé(s)`;
        } catch (e) {
            Toast.error('Erreur couper : ' + (e.message || ''));
        }
    },

    _findPasteConflicts(targets) {
        const conflicts = new Map();
        const occupancy = this._buildOccupancy();
        targets.forEach((t, i) => {
            const col = this._getCol(parseInt(t.eleve));
            const row = this._getRow(t.heure);
            if (col >= 0 && row >= 0 && occupancy[row + ':' + col] != null) {
                conflicts.set(i, occupancy[row + ':' + col]);
            }
        });
        return conflicts;
    },

    _askPasteConflict(n) {
        return new Promise(resolve => {
            Modal.open({
                title: 'Coller',
                body: '<p>' + n + ' cible(s) déjà occupée(s). Que faire ?</p>',
                footer: '<button class="btn btn-secondary" id="paste-cancel">Annuler</button>'
                    + '<button class="btn btn-secondary" id="paste-skip">Ignorer les occupées</button>'
                    + '<button class="btn btn-primary" id="paste-overwrite">Écraser</button>',
                onClose: () => resolve('cancel'),
            });
            const bind = (id, val) => {
                document.getElementById(id).addEventListener('click', () => {
                    Modal._onClose = null;
                    Modal.close();
                    resolve(val);
                });
            };
            bind('paste-cancel', 'cancel');
            bind('paste-skip', 'skip');
            bind('paste-overwrite', 'overwrite');
        });
    },

    async _pasteClipboard() {
        if (!this._clipboard || !this._clipboard.creneaux || this._clipboard.creneaux.length === 0) return;

        const targets = Array.from(this._selection.cells.values());
        const sources = this._clipboard.creneaux;
        if (targets.length === 0) return;

        // Détection de conflit : cibles déjà occupées
        const conflicts = this._findPasteConflicts(targets);
        let skip = new Set();
        let overwriteIds = [];
        if (conflicts.size > 0) {
            const choice = await this._askPasteConflict(conflicts.size);
            if (choice === 'cancel') return;
            if (choice === 'skip') skip = new Set(conflicts.keys());
            if (choice === 'overwrite') overwriteIds = Array.from(conflicts.values());
        }

        const tasks = [];
        for (let i = 0; i < Math.min(sources.length, targets.length); i++) {
            if (skip.has(i)) continue;
            tasks.push(API.post('creneaux.php', {
                ...sources[i],
                eleve_id: parseInt(targets[i].eleve),
                heure_debut: targets[i].heure,
                jour: this._currentDay,
                semaine_id: this._semaineId !== null ? this._semaineId : undefined,
            }));
        }

        if (tasks.length === 0) { this._clearSelection(); return; }

        const deleteTasks = overwriteIds.map(id => API.del('creneaux.php?id=' + id));

        try {
            await Promise.all([...deleteTasks, ...tasks]);
            await this._markModified();
            this._clearSelection();
            this._creneaux = await API.get('creneaux.php' + (this._semaineId !== null ? '?semaine_id=' + this._semaineId : '?semaine_id=null'));
            this._creneaux = this._creneaux.map(c => ({ ...c, heure_debut: c.heure_debut?.substring(0, 5) }));
            this._rebuildGrid();
            const status = document.getElementById('status-selection');
            if (status) status.textContent = `${tasks.length} créneau(x) collé(s)`;
        } catch (e) {
            Toast.error('Erreur collage : ' + (e.message || ''));
        }
    },

    _hasClipboard() {
        return this._clipboard && this._clipboard.creneaux && this._clipboard.creneaux.length > 0;
    },

});
