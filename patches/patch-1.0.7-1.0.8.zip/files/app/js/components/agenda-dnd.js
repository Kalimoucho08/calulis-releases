/**
 * Calulis — Agenda Drag & Drop (souris pure + touch)
 * Ghost visuel + preview verte/rouge + collision + découpage
 * Ajouté à Agenda via Object.assign
 */

Object.assign(Agenda, {

    /* ─── Init ─── */

    _bindDnD() {
        // Nettoyage préalable (évite les doublons de listeners après rebuild)
        if (this._dndBound) return;
        this._dndBound = true;

        document.addEventListener('mousedown', this._dndOnPointerDown.bind(this));
        document.addEventListener('mousemove', this._dndOnPointerMove.bind(this));
        document.addEventListener('mouseup', this._dndOnPointerUp.bind(this));

        // Touch support (tablette)
        document.addEventListener('touchstart', this._dndOnTouchStart.bind(this), { passive: false });
        document.addEventListener('touchmove', this._dndOnTouchMove.bind(this), { passive: false });
        document.addEventListener('touchend', this._dndOnTouchEnd.bind(this));

        // Annulation par Escape
        document.addEventListener('keydown', this._dndOnKeyDown.bind(this));
    },

    /* ─── État interne du drag ─── */

    _dndReset() {
        this._drag = null;
        this._dndClearPreview();
        this._dndRemoveGhost();
        // Restaurer l'opacité du créneau source
        if (this._dndSourceEl) {
            this._dndSourceEl.classList.remove('slot-dragging');
            this._dndSourceEl = null;
        }
    },

    /* ─── Pointer events (souris) ─── */

    _dndOnPointerDown(e) {
        if (State.get('consultation')) return;
        if (e.button !== 0) return;
        if (e.target && e.target.closest && e.target.closest('input, select, textarea, button, .ctx-menu')) return;

        const target = this._dndFindSlotByRect(e.clientX, e.clientY);
        if (!target || !target.creneauId) return;

        const cell = target.element;
        const creneau = this._creneaux.find(c => c.id === target.creneauId);
        if (!creneau) return;

        // Collecter tous les IDs de créneaux fusionnés visuellement dans ce bloc
        const allIds = this._getMergedCreneauIds(creneau);

        this._drag = {
            creneauId: creneau.id,
            creneauIds: allIds,
            creneau: { ...creneau },
            isCopy: e.ctrlKey || e.metaKey,
            startX: e.clientX,
            startY: e.clientY,
            active: false,
            targetRow: null,
            targetCol: null,
            isValid: false,
        };

        this._dndSourceEl = cell;
        cell.classList.add('slot-dragging');
        document.getElementById('status-selection').textContent = '🔽 Déplacez pour déplacer le créneau...';
    },

    _dndOnPointerMove(e) {
        if (!this._drag) return;

        if (!this._drag.active) {
            const dx = e.clientX - this._drag.startX;
            const dy = e.clientY - this._drag.startY;
            if (Math.abs(dx) < 5 && Math.abs(dy) < 5) return;

            this._drag.active = true;
            this._dndCreateGhost(e.clientX, e.clientY);
        }

        this._dndMoveGhost(e.clientX, e.clientY);
        this._dndUpdatePreview(e.clientX, e.clientY);
    },

    async _dndOnPointerUp(e) {
        if (!this._drag) return;

        if (this._drag.active && this._drag.targetRow !== null && this._drag.targetCol !== null && this._drag.isValid) {
            await this._dndExecuteDrop();
        } else if (!this._drag.active) {
            // Clic simple sans déplacement → rien à faire (le click handler fera la sélection)
        }

        this._dndReset();
    },

    /* ─── Touch events (tablette) ─── */

    _dndOnTouchStart(e) {
        if (State.get('consultation')) return;
        const touch = e.touches[0];
        const target = this._dndFindSlotByRect(touch.clientX, touch.clientY);
        if (!target || !target.creneauId) return;

        const creneau = this._creneaux.find(c => c.id === target.creneauId);
        if (!creneau) return;

        const allTouchIds = this._getMergedCreneauIds(creneau);
        this._drag = {
            creneauId: target.creneauId,
            creneauIds: allTouchIds,
            creneau: { ...creneau },
            isCopy: false,
            startX: touch.clientX,
            startY: touch.clientY,
            active: false,
            targetRow: null,
            targetCol: null,
            isValid: false,
        };

        this._dndSourceEl = target.element;
        target.element.classList.add('slot-dragging');
    },

    _dndOnTouchMove(e) {
        if (!this._drag) return;
        e.preventDefault();
        const touch = e.touches[0];

        if (!this._drag.active) {
            const dx = touch.clientX - this._drag.startX;
            const dy = touch.clientY - this._drag.startY;
            if (Math.abs(dx) < 5 && Math.abs(dy) < 5) return;

            this._drag.active = true;
            this._dndCreateGhost(touch.clientX, touch.clientY);
        }

        this._dndMoveGhost(touch.clientX, touch.clientY);
        this._dndUpdatePreview(touch.clientX, touch.clientY);
    },

    async _dndOnTouchEnd(e) {
        if (!this._drag) return;

        if (this._drag.active && this._drag.targetRow !== null && this._drag.targetCol !== null && this._drag.isValid) {
            await this._dndExecuteDrop();
        }

        this._dndReset();
    },

    /* ─── Clavier ─── */

    _dndOnKeyDown(e) {
        if (e.key === 'Escape' && this._drag) {
            this._dndReset();
            document.getElementById('status-selection').textContent = 'Déplacement annulé';
        }
    },

    /* ─── Ghost ─── */

    /**
     * Collecte les IDs de tous les créneaux visuellement fusionnés avec celui-ci
     * (même matière, groupe, adulte, type, sur le même jour et élève, consécutifs)
     */
    _getMergedCreneauIds(creneau) {
        const dureePas = this._params?.horaires?.duree_creneau || 15;
        const ids = [creneau.id];
        if (!creneau) return ids;

        const heures = this._heures;
        if (heures.length === 0) return ids;

        const row = this._getRow(creneau.heure_debut);
        if (row < 0) return ids;

        // Chercher les créneaux identiques consécutifs VERS LE HAUT
        for (let r = row - 1; r >= 0; r--) {
            const prev = this._creneaux.find(c =>
                c.eleve_id === creneau.eleve_id && c.jour === this._currentDay &&
                c.heure_debut === heures[r] &&
                c.matiere === creneau.matiere && c.groupe === creneau.groupe &&
                c.adulte === creneau.adulte && c.regroupement_type === creneau.regroupement_type
            );
            if (prev && !ids.includes(prev.id)) ids.unshift(prev.id);
            else break;
        }

        // Chercher les créneaux identiques consécutifs VERS LE BAS
        for (let r = row + 1; r < heures.length; r++) {
            const next = this._creneaux.find(c =>
                c.eleve_id === creneau.eleve_id && c.jour === this._currentDay &&
                c.heure_debut === heures[r] &&
                c.matiere === creneau.matiere && c.groupe === creneau.groupe &&
                c.adulte === creneau.adulte && c.regroupement_type === creneau.regroupement_type
            );
            if (next && !ids.includes(next.id)) ids.push(next.id);
            else break;
        }

        return ids;
    },

    _dndCreateGhost(clientX, clientY) {
        this._dndRemoveGhost();

        const ghost = document.createElement('div');
        ghost.className = 'drag-ghost';
        ghost.style.position = 'fixed';
        ghost.style.pointerEvents = 'none';
        ghost.style.zIndex = '1000';
        ghost.style.opacity = '0.85';
        ghost.style.transform = 'rotate(2deg) scale(1.05)';
        ghost.style.boxShadow = '0 8px 24px rgba(0,0,0,0.25)';
        ghost.style.borderRadius = '4px';
        ghost.style.fontSize = '11px';
        ghost.style.padding = '4px 8px';
        ghost.style.whiteSpace = 'nowrap';
        ghost.style.maxWidth = '200px';
        ghost.style.overflow = 'hidden';
        ghost.style.textOverflow = 'ellipsis';

        const c = this._drag.creneau;
        const creneauSource = this._creneaux.find(cc => cc.id === this._drag.creneauId);
        if (creneauSource) {
            const eleve = this._eleves.find(e => e.id === creneauSource.eleve_id);
            const nomEleve = eleve ? `${eleve.prenom} ${eleve.nom}` : '';
            const couleur = creneauSource.couleur_override || this._params?.couleurs_types?.[creneauSource.regroupement_type] || '#e0e0e0';
            ghost.style.background = couleur;
            ghost.style.color = '#000';
            ghost.innerHTML = `<strong>${escapeHtml(creneauSource.matiere || '')}</strong>
                ${nomEleve ? `<br><small>${escapeHtml(nomEleve)}</small>` : ''}
                ${this._drag.isCopy ? '<br><small style="font-weight:700">📋 Copie</small>' : ''}`;
        }

        document.body.appendChild(ghost);
        this._dndGhost = ghost;
        this._dndMoveGhost(clientX, clientY);
    },

    _dndMoveGhost(clientX, clientY) {
        if (!this._dndGhost) return;
        this._dndGhost.style.left = (clientX + 12) + 'px';
        this._dndGhost.style.top = (clientY + 12) + 'px';
    },

    _dndRemoveGhost() {
        if (this._dndGhost) {
            this._dndGhost.remove();
            this._dndGhost = null;
        }
    },

    /* ─── Résolution de cible ─── */

    /**
     * Calcule la position (row, col) dans la grille à partir des coordonnées souris.
     * Utilise le bounding rect de la grille et la hauteur des cellules heure.
     */
    _dndResolveTarget(clientX, clientY) {
        const grid = document.getElementById('agenda-grid-css');
        if (!grid) return null;

        const rect = grid.getBoundingClientRect();
        const nCols = this._filteredEleves.length;
        if (nCols === 0) return null;

        // Colonne : se base sur les bounding rects des en-têtes
        const headers = grid.querySelectorAll('.agenda-gh-cell');
        let col = -1;
        for (let i = 0; i < headers.length; i++) {
            const hRect = headers[i].getBoundingClientRect();
            if (clientX >= hRect.left - 2 && clientX < hRect.right + 2) {
                col = i;
                break;
            }
        }
        if (col < 0 || col >= nCols) return null;

        // Ligne : se base sur les cellules heure (utilise data-heure pour éviter
        // le décalage d'index causé par les lignes de pause sans .agenda-hour-cell)
        const heureCells = grid.querySelectorAll('.agenda-hour-cell');
        let row = -1;
        for (let i = 0; i < heureCells.length; i++) {
            const hRect = heureCells[i].getBoundingClientRect();
            if (clientY >= hRect.top - 2 && clientY < hRect.bottom + 2) {
                // Lire le data-heure pour retrouver le vrai row dans _heures
                const hVal = heureCells[i].dataset.heure;
                row = this._getRow(hVal);
                break;
            }
        }
        if (row < 0) return null;

        return { row, col };
    },

    /**
     * Trouve le slot sous les coordonnées en testant les bounding rects
     * de tous les .agenda-slot[data-id]. Plus fiable que elementFromPoint
     * avec display:contents sur les rows.
     */
    _dndFindSlotByRect(clientX, clientY) {
        const slots = document.querySelectorAll('.agenda-slot[data-id]');
        for (const slot of slots) {
            const r = slot.getBoundingClientRect();
            // Inflater légèrement la zone de détection (2px) pour les bordures
            if (clientX >= r.left - 2 && clientX < r.right + 2 &&
                clientY >= r.top - 2 && clientY < r.bottom + 2) {
                const creneauId = parseInt(slot.dataset.id);
                if (!creneauId) continue;
                return { element: slot, creneauId };
            }
        }
        // Essayer aussi sur les empty slots (pour l'éventuel drop sur case vide)
        const empties = document.querySelectorAll('.agenda-slot-empty');
        for (const slot of empties) {
            const r = slot.getBoundingClientRect();
            if (clientX >= r.left - 2 && clientX < r.right + 2 &&
                clientY >= r.top - 2 && clientY < r.bottom + 2) {
                return { element: slot, creneauId: null };
            }
        }
        return null;
    },

    _dndUpdatePreview(clientX, clientY) {
        this._dndClearPreview();
        if (!this._drag) return;

        // Résoudre la cible avec les coordonnées dans la grille
        const target = this._dndResolveTarget(clientX, clientY);
        if (!target) {
            this._drag.targetRow = null;
            this._drag.targetCol = null;
            this._drag.isValid = false;
            document.getElementById('status-selection').textContent = '❌ Hors grille';
            return;
        }

        this._drag.targetRow = target.row;
        this._drag.targetCol = target.col;

        const dureePas = this._params?.horaires?.duree_creneau || 15;
        const { span } = this._getDragBlock(this._drag.creneau, this._drag.creneauIds);

        const sourceIds = this._drag.creneauIds || [this._drag.creneauId];
        const occupancy = this._buildOccupancy();
        const result = this._canPlace(sourceIds, target.row, target.col, span, occupancy);
        this._drag.isValid = result.ok;

        const hasOverlap = (result.reason === 'overlap');
        const className = hasOverlap ? 'drop-target-warning' : 'drop-target-valid';

        // Appliquer la classe sur les cellules concernées
        const eleveId = this._getEleveId(target.col);
        if (eleveId !== null) {
            for (let r = target.row; r < target.row + span && r < this._heures.length; r++) {
                const heureVal = this._getHeure(r);
                if (!heureVal) continue;
                const slot = document.querySelector(
                    `.agenda-slot[data-eleve="${eleveId}"][data-heure="${heureVal}"], ` +
                    `.agenda-slot-empty[data-eleve="${eleveId}"][data-heure="${heureVal}"]`
                );
                if (slot) slot.classList.add(className);
            }
        }

        const status = document.getElementById('status-selection');
        if (status) {
            if (hasOverlap) {
                const noms = result.conflicts.map(c => {
                    const cr = this._creneaux.find(x => x.id === c.creneauId);
                    if (!cr) return '?';
                    return cr.type === 'pause' ? (cr.matiere || 'Pause') : (cr.matiere || 'créneau');
                }).join(', ');
                status.textContent = `⚠️ Chevauche ${result.conflicts.length} créneau(x) : ${noms} — Relâchez pour confirmer`;
            } else {
                status.textContent = '✅ Déposer ici  ' + (this._drag.isCopy ? '(Copie)' : '(Déplacement)');
            }
        }
    },

    _dndClearPreview() {
        document.querySelectorAll('.drop-target-valid, .drop-target-warning, .drop-target-invalid').forEach(el => {
            el.classList.remove('drop-target-valid', 'drop-target-warning', 'drop-target-invalid');
        });
    },

    /* ─── Exécution du drop ─── */

    async _dndExecuteDrop() {
        if (!this._drag) return;

        // ⚠️ Sauvegarder TOUTES les données AVANT tout await
        const dragTargetCol = this._drag.targetCol;
        const dragTargetRow = this._drag.targetRow;
        const dragCreneau = this._drag.creneau;
        const dragIsCopy = this._drag.isCopy;
        const dragCreneauId = this._drag.creneauId;

        const targetEleveId = this._getEleveId(dragTargetCol);
        const targetHeure = this._getHeure(dragTargetRow);
        if (!targetEleveId || !targetHeure || !dragCreneau) return;

        // Vérifier si c'est un no-op (même position, pas de copie)
        if (!dragIsCopy &&
            dragCreneau.eleve_id === targetEleveId &&
            dragCreneau.heure_debut === targetHeure) {
            return; // no-op: même position, pas de copie
        }

        // Calculer les opérations
        const friendlyIds = dragCreneauId ? [dragCreneauId] : [];
        if (this._drag?.creneauIds) friendlyIds.push(...this._drag.creneauIds.filter(id => id !== dragCreneauId));
        const ops = this._computeDropOps(dragCreneau, targetEleveId, targetHeure, dragIsCopy, friendlyIds);
        if (ops.length === 0) return;

        // Vérifier s'il y a des conflits (écrasement d'autres créneaux)
        // Exclure les updates du bloc déplacé (créneau saisi + voisins fusionnés)
        const blockIds = new Set(friendlyIds || [dragCreneauId]);
        const conflicts = ops.filter(op => {
            if (op.type === 'delete') return true;
            if (op.type === 'update' && !blockIds.has(op.id)) return true;
            return false;
        });
        if (conflicts.length > 0) {
            const msg = conflicts.length === 1
                ? 'Ce déplacement va écraser un créneau existant. Les parties non chevauchées seront conservées automatiquement. Continuer ?'
                : `Ce déplacement va écraser ${conflicts.length} créneaux existants. Les parties non chevauchées seront conservées automatiquement. Continuer ?`;

            if (!await Modal.confirm('⚠️ Chevauchement', msg)) {
                return;
            }
        }

        try {
            await this._executeOps(ops);
            document.getElementById('status-selection').textContent =
                dragIsCopy ? '📋 Créneau copié' : '🔀 Créneau déplacé';
        } catch (e) {
            Toast.error('Échec du déplacement : ' + (e.message || 'erreur serveur'));
        }
    },

});
