<?php
/**
 * Calulis — Import de base de données
 * POST /db-import.php (multipart: sqlfile) → charge un .sql
 */
require_once __DIR__ . '/../config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    jsonError('Méthode non supportée', 405);
}

if (getenv('CALULIS_ENV') === 'production' && getenv('CALULIS_ALLOW_IMPORT') !== '1') {
    jsonError('Import désactivé en production', 403);
}

$file = $_FILES['sqlfile'] ?? null;
if (!$file || $file['error'] !== UPLOAD_ERR_OK) {
    jsonError('Fichier manquant ou erreur d\'upload (code ' . ($file['error'] ?? 'inconnu') . ')', 400);
}

$sql = file_get_contents($file['tmp_name']);
if (!$sql || trim($sql) === '') {
    jsonError('Fichier vide', 400);
}
// Supprimer les lignes de commentaires (-- ...) : sinon un DROP TABLE fusionné avec
// le bloc de commentaire précédent est ignoré (str_starts_with '--') et le CREATE TABLE
// qui suit échoue avec « Table already exists ».
$sql = preg_replace('/^--.*$/m', '', $sql);

$pdo = getDB();
$pdo->exec("SET FOREIGN_KEY_CHECKS = 0");

// Split par instruction (; en début de ligne après un saut de ligne)
$statements = preg_split('/;\s*\n/', $sql);
$ok = 0;
$errors = [];

foreach ($statements as $stmt) {
    $stmt = trim($stmt);
    if ($stmt === '' || str_starts_with($stmt, '--')) continue;
    try {
        $pdo->exec($stmt);
        $ok++;
    } catch (\Throwable $e) {
        $errors[] = substr($stmt, 0, 80) . '... — ' . $e->getMessage();
    }
}

$pdo->exec("SET FOREIGN_KEY_CHECKS = 1");

if (count($errors) > 0) {
    jsonError($ok . ' instructions exécutées, ' . count($errors) . ' erreurs : ' . implode(' | ', array_slice($errors, 0, 5)), 500);
}

// Comptes post-import
$eleves = $pdo->query("SELECT COUNT(*) FROM eleves")->fetchColumn();
$adultes = $pdo->query("SELECT COUNT(*) FROM adultes")->fetchColumn();
$creneaux = $pdo->query("SELECT COUNT(*) FROM creneaux")->fetchColumn();

jsonResponse([
    'ok' => true,
    'message' => "{$ok} instructions exécutées — {$eleves} élèves, {$adultes} adultes, {$creneaux} créneaux",
    'counts' => compact('eleves', 'adultes', 'creneaux'),
]);
