/**
 * Calulis — Guide d'aide complet
 * Accessible depuis la sidebar (📖 Aide)
 * Cible : enseignants, coordonnateurs ULIS — pas de jargon informatique
 */
const AideView = {

    async render() {
        const view = document.getElementById('view-aide');
        view.innerHTML = this._buildHTML();
        this._bindEvents();
    },

    _buildHTML() {
        return `
        <div class="aide-container">
            <div class="aide-sidebar">
                <h2 class="aide-title">📖 Guide Calulis</h2>
                <div class="aide-nav">
                    <button class="aide-nav-item active" data-section="demarrage">🚀 Premier démarrage</button>
                    <button class="aide-nav-item" data-section="concepts">🧠 Comprendre Calulis</button>
                    <button class="aide-nav-item" data-section="dashboard-2">📋 Tableau de bord</button>
                    <button class="aide-nav-item" data-section="eleves-2">👥 Élèves</button>
                    <button class="aide-nav-item" data-section="listes-2">🗂️ Listes</button>
                    <button class="aide-nav-item" data-section="agenda-2">📅 Agenda (EDT)</button>
                    <button class="aide-nav-item" data-section="adultes-2">👩‍🏫 Adultes</button>
                    <button class="aide-nav-item" data-section="reunions-2">🤝 Réunions</button>
                    <button class="aide-nav-item" data-section="evenements-2">📆 Événements</button>
                    <button class="aide-nav-item" data-section="stats-2">📊 Statistiques</button>
                    <button class="aide-nav-item" data-section="impression-2">🖨️ Impression</button>
                    <button class="aide-nav-item" data-section="params-2">⚙️ Paramètres</button>
                    <button class="aide-nav-item" data-section="scenarios">📋 Scénarios pas à pas</button>
                    <button class="aide-nav-item" data-section="raccourcis">⌨️ Raccourcis</button>
                    <button class="aide-nav-item" data-section="rgpd">🔒 Données personnelles</button>
                    <button class="aide-nav-item" data-section="licences">🧩 Sources des composants</button>
                    <button class="aide-nav-item" data-section="etapres">🧭 Et après ?</button>
                    <button class="aide-nav-item" data-section="astuces">💡 Astuces</button>
                    <button class="aide-nav-item" data-section="nouveautes">🎉 Nouveautés</button>
                </div>
            </div>
            <div class="aide-content" id="aide-content">
                ${this._sectionDemarrage()}
            </div>
        </div>`;
    },

    _card(title, body) {
        return '<div class="aide-card"><h4>' + escapeHtml(title) + '</h4>' + body + '</div>';
    },
    _li(item) { return '<li>' + item + '</li>'; },
    _ol(items) { return '<ol>' + items.map(i => this._li(i)).join('') + '</ol>'; },
    _ul(items) { return '<ul>' + items.map(i => this._li(i)).join('') + '</ul>'; },

    /* =========================== SECTIONS =========================== */

    _sectionDashboard() {
        return '<section class="aide-section" id="aide-dashboard-2">' +
            '<h3>📋 Tableau de bord</h3>' +
            '<p>Le tableau de bord est la page d\'accueil de Calulis. Il donne une vue d\'ensemble de votre dispositif ULIS en un coup d\'œil.</p>' +
            this._card('Widget Effectifs',
                '<p>Affiche le nombre d\'élèves actifs et le nombre de classes distinctes pour l\'année en cours. Cliquez pour accéder à la liste des élèves.</p>') +
            this._card('Widget Prochaines réunions',
                '<p>Liste les 3 prochaines réunions planifiées avec leur date et statut. Cliquez pour accéder au module Réunions.</p>') +
            this._card('Widget Agenda — semaine en cours',
                '<p>Affiche la semaine scolaire actuelle avec son contexte : période en cours (ex: « Période 5 — Semaine 8/10 · S36 ») et les événements de la semaine. La numérotation <strong>S1→S36</strong> ne compte que les semaines de cours (hors vacances).</p>') +
            this._card('Widget « À relancer »',
                '<p>L\'échéancier du dispositif, en trois listes : les <strong>droits MDPH</strong> expirés ou qui expirent dans moins de 60 jours, les <strong>ESS à programmer</strong> (aucune ESS enregistrée pour l\'élève, ou la dernière date de plus d\'un an) et les <strong>documents à compléter</strong> (PAI déclaré sans document joint, notification MDPH non renseignée). <strong>Cliquez sur une ligne</strong> pour ouvrir directement la fiche de l\'élève sur l\'onglet MDPH — pratique pour anticiper les renouvellements.</p>') +
        '</section>';
    },

    _sectionDemarrage() {
        return '<section class="aide-section" id="aide-demarrage">' +
            '<h3>🚀 Premier démarrage</h3>' +
            '<p>Bienvenue dans <strong>Calulis</strong> ! Cette application vous aide à gérer votre dispositif ULIS au quotidien : emplois du temps, suivi des élèves, réunions, statistiques.</p>' +
            this._card('1. Configurez votre établissement',
                '<p>Allez dans <strong>⚙️ Paramètres</strong> → section <em>Notre établissement</em>. Sélectionnez votre école dans la liste. Si elle n\'existe pas encore, créez-la dans <strong>🏫 Établissements</strong>.</p>') +
            this._card('2. Créez vos classes',
                '<p>Allez dans <strong>🏷️ Classes</strong>. Créez les classes de votre école (CP, CE1, CE2…). Associez chaque classe à son enseignant. Ces classes servent de référence pour le rattachement des élèves (obligation légale : chaque élève ULIS est inscrit dans une classe ordinaire).</p>') +
            this._card('3. Ajoutez vos élèves',
                '<p>Allez dans <strong>👥 Élèves</strong> → <em>+ Nouvel élève</em>. Remplissez la fiche : identité, date de naissance, classe de référence, date d\'entrée ULIS. Les autres onglets (AESH, MDPH, Médical, Représentants) peuvent être complétés plus tard.</p>') +
            this._card('4. Ajoutez les adultes',
                '<p>Allez dans <strong>👩‍🏫 Adultes</strong> → <em>+ Nouvel adulte</em>. Ajoutez les enseignants, les AESH, les intervenants extérieurs (orthophoniste, psychomotricien, éducateur…).</p>') +
            this._card('5. Configurez l\'agenda',
                '<p>Allez dans <strong>⚙️ Paramètres</strong> : définissez les horaires de l\'école, les jours travaillés et les couleurs des types de regroupement. Les pauses (récréation, pause du midi) s\'ajoutent ensuite dans l\'agenda avec le bouton « ⏸️ Pause ».</p>') +
            this._card('6. Créez votre semaine type',
                '<p>Dans l\'<strong>📅 Agenda</strong>, commencez par la <strong>Semaine type 📋</strong> (le modèle). Double-cliquez dans une case vide pour créer un créneau. Une fois votre modèle prêt, utilisez <em>Appliquer le template</em> pour le copier sur les semaines souhaitées.</p>') +
        '</section>';
    },

    _sectionConcepts() {
        return '<section class="aide-section" id="aide-concepts">' +
            '<h3>🧠 Comprendre Calulis</h3>' +
            this._card('Qu\'est-ce qu\'un créneau ?',
                '<p>Un <strong>créneau</strong> est une case dans l\'emploi du temps. Il contient : un ou plusieurs élèves, un ou plusieurs adultes, une activité (ex: "Français ULIS"), un type de regroupement (ex: ULIS, Inclusion) et une couleur. C\'est l\'unité de base de l\'agenda.</p>') +
            this._card('Types de regroupement',
                '<p>Chaque créneau a un <strong>type</strong> qui indique comment l\'élève est regroupé :</p>' +
                this._ul(['<strong>ULIS</strong> — l\'élève est dans le dispositif, avec le coordonnateur',
                          '<strong>Inclusion</strong> — l\'élève est dans sa classe de référence',
                          '<strong>Décloisonnement</strong> — l\'élève est dans une autre classe que la sienne',
                          '<strong>PEC</strong> — Prise En Charge extérieure (orthophonie, CMPP, SESSAD…)',
                          '<strong>Regroupement</strong>, <strong>Atelier</strong>, <strong>Projet</strong> — personnalisables dans les Paramètres']) +
            this._card('Pauses (récréation, midi)',
                this._ul(['Le bouton <strong>⏸️ Pause</strong> de l\'agenda crée une pause : nom, type (Récréation / Pause midi), début, fin, jours.',
                    'Les pauses sont des créneaux normaux (Récréation = orange, Pause midi = marron clair) — elles s\'impriment et se filtrent comme les autres.'])) +
                '<p>Ces types servent aux <strong>statistiques</strong> : Calulis compte automatiquement le temps passé par chaque élève dans chaque type.</p>') +
            this._card('Année scolaire',
                '<p>Le sélecteur en haut à droite permet de changer d\'année scolaire. Chaque année a ses propres élèves, classes, réunions et emplois du temps. Les données sont <strong>indépendantes</strong> : modifier 2026-2027 ne touche pas 2025-2026. Vous pouvez préparer la rentrée suivante sans perdre l\'historique.</p>') +
            this._card('Semaine type (template 📋)',
                '<p>La <strong>Semaine type</strong> est un modèle qui sert de base pour remplir les semaines réelles. Construisez votre EDT idéal une fois, puis appliquez-le aux semaines souhaitées. Les semaines déjà modifiées ne sont pas écrasées si vous choisissez <em>Appliquer aux semaines non modifiées</em>.</p>') +
            this._card('Mode consultation 🔓',
                '<p>Le bouton <strong>🔓</strong> dans la barre du haut verrouille l\'interface : plus aucune modification possible. Idéal pour présenter l\'EDT en réunion sans risque de clic malencontreux.</p>') +
        '</section>';
    },

    _sectionEleves() {
        return '<section class="aide-section" id="aide-eleves-2">' +
            '<h3>👥 Élèves</h3>' +
            '<p>La page Élèves affiche la liste de tous les élèves suivis par le dispositif ULIS pour l\'année scolaire en cours.</p>' +
            this._card('Filtrer la liste',
                this._ul(['<strong>Niveau</strong> (CP, CE1, CE2…) — filtre par niveau de classe',
                          '<strong>Classe</strong> (CP — Marie Martin…) — filtre par classe spécifique',
                          '<strong>ULIS / Non ULIS</strong> — filtre par statut dispositif',
                          '<strong>Actifs / Inactifs</strong> — un élève inactif est sorti du dispositif (il reste en base pour l\'historique)'])) +
            this._card('La fiche élève (6 onglets)',
                '<p>Cliquez sur <strong>Fiche</strong> pour consulter, ou <strong>Modifier</strong> pour éditer :</p>' +
                this._ul(['<strong>Identité</strong> — nom, prénom, date de naissance, téléphone, adresse, transport, cantine',
                          '<strong>Scolarité</strong> — classe de référence, établissement, date d\'entrée ULIS, école d\'origine',
                          '<strong>AESH & PEC</strong> — accompagnants et prises en charge extérieures (orthophonie, psychomot…)',
                          '<strong>MDPH & Plans</strong> — dates de droits (ULIS, SESSAD, AESH, Transport), notifications',
                          '<strong>Médical</strong> — PAI, traitements, pathologies (restreint au personnel autorisé)',
                          '<strong>Représentants légaux</strong> — parents, tuteurs, contacts d\'urgence'])) +
            this._card('Colonnes du tableau',
                this._ul(['<strong>Âge</strong> — calculé automatiquement depuis la date de naissance',
                          '<strong>Années ULIS</strong> — temps passé dans le dispositif, en mois (« 1 an et 5 mois », « 0 mois » pour le 1ᵉʳ mois)',
                          '<strong>Tri</strong> — cliquez sur un en-tête pour trier (▲ ascendant, ▼ descendant)'])) +
        '</section>';
    },

    _sectionAgenda() {
        return '<section class="aide-section" id="aide-agenda-2">' +
            '<h3>📅 Agenda (Emploi du temps)</h3>' +
            '<p>L\'agenda est le cœur de Calulis. C\'est ici que vous construisez et visualisez les emplois du temps de vos élèves.</p>' +
            this._card('Créer un créneau',
                '<p><strong>Double-cliquez</strong> dans une case vide de la grille. Remplissez le formulaire : activité, type, élève(s), adulte(s). Le créneau apparaît avec la couleur de son type de regroupement.</p>') +
            this._card('Modifier un créneau',
                '<p><strong>Double-cliquez</strong> sur un créneau existant pour l\'éditer.</p>') +
            this._card('Case déjà occupée : Calulis demande avant d\'écrire',
                '<p>Si la case visée est déjà prise — par un <strong>élève</strong> ou par un <strong>adulte</strong> déjà occupé ailleurs au même moment — Calulis affiche une petite boîte : <strong>Annuler</strong>, <strong>Ignorer les occupées</strong> (n\'écrit que les cases libres) ou <strong>Écraser</strong> (remplace le contenu).</p>' +
                '<p>La question est posée à la <strong>création</strong>, à la <strong>modification</strong>, à l\'<strong>ajout d\'une pause</strong> et au <strong>collage</strong>. Elle dit aussi <em>pourquoi</em> la case est occupée, ce qui compte avant de choisir « Écraser ». La fenêtre de saisie reste ouverte derrière : « Annuler » ne fait perdre aucune donnée déjà tapée.</p>') +
            this._card('Déplacer ou copier',
                this._ul(['<strong>Glisser-déposer</strong> — déplace un créneau vers une autre case',
                          '<strong>Ctrl + glisser</strong> — copie le créneau au lieu de le déplacer',
                          '<strong>Clic droit</strong> — menu Couper / Copier / Coller'])) +
            this._card('Vue élèves vs Vue adultes',
                this._ul(['<strong>👥 Élèves</strong> — l\'EDT est organisé par élève (chaque élève a sa colonne)',
                          '<strong>👤 Adultes</strong> — l\'EDT est organisé par adulte. Pratique pour vérifier la charge d\'un AESH'])) +
            this._card('Filtres',
                '<p>Tous les filtres sont <strong>cumulatifs</strong> :</p>' +
                this._ul(['<strong>Élève</strong> — n\'affiche que les créneaux de cet élève',
                          '<strong>Groupe</strong> — filtre par groupe (ULIS, CP-CE1, Rouge…)',
                          '<strong>Intervenant</strong> — n\'affiche que les créneaux où cet adulte est présent'])) +
            this._card('Appliquer le template',
                '<p>Une fois votre Semaine type construite, utilisez les boutons <em>Appliquer</em> pour la copier :</p>' +
                this._ul(['<strong>Toutes</strong> — écrase toutes les semaines (attention !)',
                          '<strong>Non modifiées</strong> — ne touche pas aux semaines déjà personnalisées',
                          '<strong>Choisir…</strong> — sélectionnez les semaines une par une'])) +
        '</section>';
    },

    _sectionAdultes() {
        return '<section class="aide-section" id="aide-adultes-2">' +
            '<h3>👩‍🏫 Adultes</h3>' +
            '<p>Gérez tous les adultes qui interviennent auprès des élèves ULIS.</p>' +
            this._card('Catégories',
                this._ul(['<strong>Enseignants</strong> — de votre école (filtre 👩‍🏫)',
                          '<strong>Personnel</strong> — AESH, AESHco, coordonnateur ULIS, directeur… (filtre 👥)',
                          '<strong>Externes</strong> — orthophoniste, psychomotricien, éducateur ASE… (filtre 🌍)'])) +
            this._card('Co-intervention',
                '<p>Un créneau peut avoir <strong>plusieurs adultes</strong> (ex: enseignant + AESH). Dans le formulaire de créneau, ajoutez les intervenants et attribuez un rôle à chacun.</p>') +
            this._card('Fiche adulte',
                '<p>La fiche contient : nom, prénom, civilité, rôle, fonction, téléphone, email, établissement de rattachement, commentaires. Un adulte peut être rattaché à <strong>plusieurs établissements</strong> (ex: un AESH qui intervient dans deux écoles).</p>') +
        '</section>';
    },

    _sectionReunions() {
        return '<section class="aide-section" id="aide-reunions-2">' +
            '<h3>🤝 Réunions</h3>' +
            '<p>Toutes les réunions liées au dispositif ULIS, avec filtres par type, statut et élève.</p>' +
            this._card('Types de réunions',
                this._ul(['<strong>ESS</strong> — Équipe de Suivi de Scolarisation (obligatoire, présidée par l\'enseignant référent MDPH)',
                          '<strong>Équipe éducative</strong> — réunion élargie (enseignants, AESH, parents, partenaires)',
                          '<strong>Équipe de suivi</strong> — suivi interne ULIS (coordo, AESH, enseignants)',
                          '<strong>RDV famille</strong> — rendez-vous avec les parents',
                          '<strong>Partenariat</strong> — réunion avec un partenaire extérieur (SESSAD, CMPP, ASE…)',
                          '<strong>Autre</strong> — personnalisable'])) +
            this._card('Statuts',
                this._ul(['<strong>Prévue</strong> — date fixée, en attente',
                          '<strong>En cours</strong> — la réunion se prépare (ordre du jour envoyé)',
                          '<strong>Réalisée</strong> — compte-rendu rédigé',
                          '<strong>Annulée</strong> — ne compte plus',
                          '<strong>Reportée</strong> — nouvelle date à fixer'])) +
            this._card('📆 Les retrouver sur votre téléphone (.ics)',
                '<p>Le bouton <strong>Exporter (.ics)</strong> fabrique un fichier que votre téléphone, Google Agenda ou Outlook savent ouvrir : les réunions <strong>affichées</strong> (vos filtres font foi) s\'ajoutent à votre agenda personnel.</p>' +
                '<p>Le fichier est fabriqué <strong>sur votre ordinateur</strong> : rien n\'est envoyé sur Internet, aucun compte n\'est nécessaire.</p>') +
        '</section>';
    },

    _sectionEvenements() {
        return '<section class="aide-section" id="aide-evenements-2">' +
            '<h3>📆 Événements</h3>' +
            '<p>L\'agenda des événements de l\'année : jours fériés, vacances, sorties, examens, anniversaires…</p>' +
            this._card('Modèles prédéfinis',
                '<p>Calulis fournit ~60 événements modèles (jours fériés, semaines thématiques, examens…). Cochez la case pour <strong>activer</strong> un modèle : il devient un événement daté. Décochez pour le désactiver. Les modèles inactifs restent disponibles pour plus tard.</p>') +
            this._card('Anniversaires',
                '<p>Le bouton <strong>🎂 Générer les anniversaires</strong> crée automatiquement un événement par élève actif. Vous pouvez le réutiliser sans risque de doublons.</p>') +
            this._card('Événements personnalisés',
                '<p>Cliquez sur <strong>+ Événement</strong> pour créer vos propres événements (sortie scolaire, spectacle, conseil d\'école…).</p>') +
            this._card('📆 Les retrouver sur votre téléphone (.ics)',
                '<p>Le bouton <strong>Exporter (.ics)</strong> fabrique un fichier que votre téléphone, Google Agenda ou Outlook savent ouvrir : les événements <strong>affichés</strong> (vos filtres font foi) s\'ajoutent à votre agenda personnel. Les modèles sans date ne sont pas exportés — ils ne se placeraient nulle part.</p>' +
                '<p>Le fichier est fabriqué <strong>sur votre ordinateur</strong> : rien n\'est envoyé sur Internet.</p>') +
        '</section>';
    },

    _sectionStats() {
        return '<section class="aide-section" id="aide-stats-2">' +
            '<h3>📊 Statistiques</h3>' +
            '<p>Les statistiques calculent automatiquement le temps passé par chaque élève dans les différents types de regroupement, à partir des créneaux de l\'agenda.</p>' +
            this._card('Ce qui est compté',
                '<p>Calulis additionne les durées de tous les créneaux et les répartit par <strong>type</strong> : ULIS, Inclusion, Décloisonnement, PEC… Les résultats sont utilisables pour :</p>' +
                this._ul(['Les <strong>rapports administratifs</strong> — justifier le temps de scolarisation',
                          'Les <strong>ESS</strong> — présenter la répartition du temps de l\'élève',
                          'Le <strong>pilotage</strong> — vérifier l\'équilibre inclusion / dispositif ULIS'])) +
        '</section>';
    },

    _sectionListes() {
        return '<section class="aide-section" id="aide-listes-2">' +
            '<h3>🗂️ Listes (générateur de listes d\'élèves)</h3>' +
            '<p>Créez vos propres listes d\'élèves en quelques clics : filtres, colonnes au choix, mise en page, export PDF ou CSV. Idéal pour les sorties, les groupes de travail, et les feuilles à compléter à la main (observations).</p>' +
            this._card('1. Filtres',
                this._ul(['<strong>Recherche</strong>, <strong>Niveau / Classe / Groupe</strong>',
                    '<strong>ULIS</strong> — élèves du dispositif uniquement',
                    '<strong>Cantine, Transport, PAI, Allergies, Droit à l\'image</strong>',
                    '<strong>Inclure les élèves inactifs</strong> si besoin'])) +
            this._card('2. Colonnes',
                '<p>Cochez / décochez les colonnes, <strong>glissez les en-têtes</strong> dans l\'aperçu pour les réordonner, et <strong>« ＋ Ajouter une colonne libre »</strong> pour une colonne vide à compléter (ex. Observations).</p>') +
            this._card('3. Mise en page',
                this._ul(['<strong>Orientation</strong> — paysage ou portrait',
                    '<strong>Espace pour écrire</strong> — lignes hautes (idéal pour remplir à la main)',
                    '<strong>Taille du texte</strong> — petit, normal, grand, très grand',
                    'Les colonnes de données s\'ajustent à leur contenu ; les colonnes libres occupent toute la largeur restante de la feuille'])) +
            this._card('4. Groupes enregistrés',
                '<p>Un groupe est un <strong>template</strong> qui mémorise vos filtres, vos colonnes et la mise en page. Boutons : <strong>Charger</strong>, <strong>Mettre à jour</strong>, <strong>Suppr.</strong>, <strong>Enregistrer comme nouveau groupe</strong>.</p>') +
            this._card('5. Export',
                this._ul(['<strong>PDF</strong> — feuille imprimable, ajustée à la page',
                    '<strong>CSV</strong> — tableur (Excel, LibreOffice)'])) +
        '</section>';
    },

    _sectionImpression() {
        return '<section class="aide-section" id="aide-impression-2">' +
            '<h3>🖨️ Impression (Export PDF)</h3>' +
            '<p>Exportez les emplois du temps en PDF pour les afficher, les transmettre aux familles ou les joindre aux dossiers. L\'onglet <strong>Fiches</strong> génère les fiches d\'urgence / renseignements (par élève ou en lot).</p>' +
            this._card('Types d\'export',
                this._ul(['<strong>Semaine · Élève</strong> — EDT complet d\'un élève sur une semaine, A4 portrait',
                          '<strong>Semaine · Adulte</strong> — EDT d\'un adulte, A4 portrait',
                          '<strong>Jour · Élève(s)</strong> — un jour pour un ou plusieurs élèves, A4 paysage',
                          '<strong>Jour · Adulte(s)</strong> — un jour pour un ou plusieurs adultes',
                          '<strong>📊 Statistiques</strong> — tableau de bord, inclusion détaillée, évolution multi-année'])) +
            this._card('Marche à suivre',
                this._ol(['Sélectionnez le type d\'export',
                          'Choisissez l\'élève (ou l\'adulte) et la semaine',
                          'Cliquez sur <strong>Générer l\'aperçu</strong>',
                          'Vérifiez le rendu dans le panneau de droite',
                          'Utilisez le zoom et la navigation entre les pages',
                          'Cliquez sur <strong>Télécharger PDF</strong>'])) +
        '</section>';
    },

    _sectionParams() {
        return '<section class="aide-section" id="aide-params-2">' +
            '<h3>⚙️ Paramètres</h3>' +
            '<p>Configurez Calulis selon le fonctionnement de votre école.</p>' +
            this._card('Couleurs par type',
                '<p>Chaque type de regroupement a une couleur. Elle s\'applique automatiquement dans l\'agenda. Choisissez des teintes distinctes, lisibles à l\'écran comme à l\'impression.</p>') +
            this._card('Horaires',
                '<p>Définissez l\'heure de début, l\'heure de fin et la durée d\'un créneau (15 minutes recommandé). La grille de l\'agenda s\'adapte automatiquement.</p>') +
            this._card('Jours affichés',
                '<p>Cochez les jours qui apparaissent dans l\'agenda. Décochez les jours sans cours (mercredi, samedi) pour une grille plus lisible.</p>') +
            this._card('APC',
                '<p>Les <strong>Activités Pédagogiques Complémentaires</strong> sont des créneaux hors temps scolaire : le midi, le soir après la classe, ou le mercredi matin. Activez-les ici.</p>') +
        '</section>';
    },

    _sectionScenarios() {
        return '<section class="aide-section" id="aide-scenarios">' +
            '<h3>📋 Scénarios pas à pas</h3>' +
            '<p>Des exemples concrets pour vous guider dans les tâches quotidiennes.</p>' +

            this._card('📌 Scénario 1 — Préparer la rentrée de septembre',
                this._ol(['Créez la <strong>nouvelle année scolaire</strong> (sélecteur en haut → + Nouvelle année)',
                          'Dans <strong>⚙️ Paramètres</strong>, vérifiez votre établissement, les horaires, les jours travaillés',
                          'Dans <strong>🏷️ Classes</strong>, mettez à jour les classes avec les nouveaux enseignants',
                          'Dans <strong>👥 Élèves</strong>, ajoutez les nouveaux élèves',
                          'Dans <strong>👩‍🏫 Adultes</strong>, mettez à jour les AESH et intervenants',
                          'Dans <strong>📅 Agenda</strong>, construisez la <em>Semaine type</em> pour cette nouvelle année',
                          'Appliquez le template aux premières semaines (bouton <em>Toutes</em> ou <em>Non modifiées</em>)',
                          'Dans <strong>📆 Événements</strong>, générez les anniversaires et activez les événements de l\'année'])) +

            this._card('📌 Scénario 2 — Préparer une ESS',
                this._ol(['Dans <strong>🤝 Réunions</strong>, créez la réunion (type ESS, date, heure, élève concerné)',
                          'Dans <strong>🖨️ Impression</strong>, exportez l\'EDT de l\'élève (Semaine · Élève)',
                          'Dans <strong>📊 Statistiques</strong>, exportez le tableau de bord ou l\'inclusion détaillée',
                          'Imprimez ou enregistrez les PDF pour le dossier de l\'élève',
                          'Après la réunion, passez la réunion en statut <em>Réalisée</em>',
                          'Dans la fiche élève, onglet MDPH, mettez à jour les dates de droits si nécessaire'])) +

            this._card('📌 Scénario 3 — Modifier l\'EDT d\'un élève en cours d\'année',
                this._ol(['Dans <strong>📅 Agenda</strong>, choisissez la semaine concernée',
                          'Double-cliquez sur le créneau à modifier → faites vos changements',
                          'Pour un changement permanent, modifiez aussi la <em>Semaine type</em>',
                          'Utilisez <em>Appliquer le template → Choisir les semaines cibles</em> pour propager'])) +

            this._card('📌 Scénario 4 — Vérifier la charge d\'un AESH',
                this._ol(['Dans <strong>📅 Agenda</strong>, basculez en vue <strong>👤 Adultes</strong>',
                          'Dans le filtre <em>Intervenant</em>, sélectionnez l\'AESH concerné',
                          'Parcourez les semaines : vous voyez tous ses créneaux',
                          'Dans <strong>🖨️ Impression → Semaine · Adulte</strong>, exportez son EDT pour justifier son temps'])) +

            this._card('📌 Scénario 5 — Bilan de fin d\'année',
                this._ol(['Dans <strong>📊 Statistiques</strong>, consultez les temps par type de regroupement',
                          'Dans <strong>🖨️ Impression → Statistiques</strong>, exportez le tableau de bord',
                          'Exportez l\'évolution multi-année pour le rapport d\'activité',
                          'Dans <strong>👥 Élèves</strong>, exportez la liste en CSV (bouton 📥)'])) +

            this._card('📌 Scénario 6 — Recevoir un nouvel élève en cours d\'année',
                this._ol(['Dans <strong>👥 Élèves → + Nouvel élève</strong>, créez sa fiche complète',
                          'Onglet <strong>Scolarité</strong> : renseignez sa classe de référence et l\'école d\'origine',
                          'Onglet <strong>MDPH</strong> : saisissez les dates de droits (notification MDPH)',
                          'Onglet <strong>AESH & PEC</strong> : ajoutez ses accompagnants',
                          'Dans <strong>📅 Agenda</strong>, ajoutez-le aux créneaux existants (double-clic → ajouter l\'élève)',
                          'Adaptez son EDT si ses temps de présence sont différents'])) +
        '</section>';
    },

    _sectionRaccourcis() {
        return '<section class="aide-section" id="aide-raccourcis">' +
            '<h3>⌨️ Raccourcis clavier</h3>' +
            this._card('Généraux',
                '<table class="aide-table"><tr><th>Touche</th><th>Action</th></tr>' +
                '<tr><td><kbd>Alt+1</kbd> à <kbd>Alt+5</kbd></td><td>Navigation rapide (Dashboard, Élèves, Agenda, Réunions, Paramètres)</td></tr>' +
                '<tr><td><kbd>Ctrl+F</kbd></td><td>Recherche globale (élève, adulte, établissement)</td></tr>' +
                '<tr><td><kbd>?</kbd></td><td>Afficher / masquer les bulles d\'aide contextuelle</td></tr>' +
                '<tr><td><kbd>Échap</kbd></td><td>Fermer la recherche globale</td></tr>' +
                '</table>') +
            this._card('Dans l\'agenda',
                '<table class="aide-table"><tr><th>Action</th><th>Raccourci</th></tr>' +
                '<tr><td>Créer un créneau</td><td>Double-clic dans une case vide</td></tr>' +
                '<tr><td>Modifier un créneau</td><td>Double-clic sur un créneau</td></tr>' +
                '<tr><td>Déplacer un créneau</td><td>Glisser-déposer</td></tr>' +
                '<tr><td>Copier un créneau</td><td>Ctrl + glisser-déposer</td></tr>' +
                '<tr><td>Couper/Copier/Coller</td><td>Clic droit sur un créneau</td></tr>' +
                '</table>') +
        '</section>';
    },

    _sectionAstuces() {
        return '<section class="aide-section" id="aide-astuces">' +
            '<h3>💡 Astuces</h3>' +
            this._card('🔍 Recherche globale',
                '<p>La barre de recherche en haut à droite permet de trouver rapidement un élève, un adulte ou un établissement. Tapez quelques lettres du nom.</p>') +
            this._card('🌙 Mode sombre',
                '<p>Le bouton 🌙 bascule en mode sombre. Confortable pour travailler le soir. Le mode clair est recommandé pour la vidéoprojection en classe.</p>') +
            this._card('📥 Export CSV',
                '<p>Sur les pages Élèves et Adultes, le bouton 📥 CSV exporte la liste au format tableur (Excel, LibreOffice). Pratique pour les listes de rentrée.</p>') +
            this._card('🔄 Préparer l\'année suivante',
                '<p>Créez la nouvelle année scolaire via le sélecteur. Vous pouvez y travailler librement : vos données actuelles ne sont pas affectées. Idéal pour anticiper la rentrée pendant l\'été.</p>') +
            this._card('📋 Dupliquer des créneaux',
                '<p>Construisez votre Semaine type, puis <em>Appliquer le template → Non modifiées</em>. Les semaines déjà personnalisées (sortie, absence…) restent intactes.</p>') +
            this._card('👥 Co-intervention',
                '<p>Un créneau peut avoir plusieurs adultes (enseignant + AESH par exemple). Dans le formulaire, ajoutez tous les intervenants nécessaires.</p>') +
            this._card('⚠️ Droits MDPH',
                '<p>Le tableau de bord (« À relancer ») liste les droits MDPH expirés ou proches de l\'expiration, les ESS à programmer et les documents à compléter. Anticipez les renouvellements.</p>') +
        '</section>';
    },

    _sectionRgpd() {
        return '<section class="aide-section" id="aide-rgpd">' +
            '<h3>🔒 Données personnelles et RGPD</h3>' +
            this._card('🛡️ Quelles données sont collectées ?',
                '<p>Calulis stocke uniquement les données nécessaires au suivi pédagogique et administratif ULIS : nom, prénom, classe, coordonnées des représentants légaux, dates de droits MDPH, précautions médicales pour la vie scolaire (hors diagnostic).</p>' +
                '<p><strong>Calulis ne collecte pas</strong> : de photos, de vidéos, de diagnostics médicaux, ou de données de connexion.</p>') +
            this._card('⚖️ Base légale',
                '<p>Le traitement repose sur la <strong>mission d\'intérêt public</strong> (RGPD art. 6.1.e) dans le cadre des missions ULIS définies par le code de l\'éducation.</p>' +
                '<p>Les données MDPH sont traitées dans le cadre de l\'obligation réglementaire de suivi des notifications CDAPH.</p>') +
            this._card('🔐 Sécurité',
                '<p>L\'application fonctionne <strong>entièrement en local</strong> sur votre poste. Aucune donnée n\'est transmise à des serveurs distants. Les sauvegardes (.sql) doivent être stockées dans un endroit sécurisé.</p>' +
                '<p>Pas d\'analytics, pas de cookies, pas de télémétrie.</p>') +
            this._card('📄 En savoir plus',
                '<p>Consultez la page <strong>Mentions RGPD</strong> (sidebar → 📄 Mentions RGPD) pour le détail complet des traitements, durées de conservation, droits des personnes et coordonnées du DPD académique.</p>') +
        '</section>';
    },

    /* ====================== SOURCES DES COMPOSANTS ====================== */
    /* Calulis embarque des composants libres : leurs licences imposent de citer les
       auteurs et de rendre les sources accessibles. Le texte complet est livré à la
       racine du dossier Calulis, dans THIRD-PARTY-NOTICES.md. Versions relevées sur
       le paquet le 29/09/2026 — si elles changent, mettre à jour CE tableau ET le
       fichier THIRD-PARTY-NOTICES.md (les deux disent la même chose). */
    _sectionLicences() {
        const liens = [
            ['FrankenPHP', '1.12.4', 'MIT', 'https://github.com/dunglas/frankenphp'],
            ['Caddy', '2.11.4', 'Apache-2.0', 'https://github.com/caddyserver/caddy'],
            ['PHP', '8.5.8', 'PHP License 3.01', 'https://github.com/php/php-src'],
            ['MySQL Community Server', '8.0.41', 'GPLv2 (exception FOSS)', 'https://github.com/mysql/mysql-server'],
            ['pdfmake', '0.2.12', 'MIT', 'https://github.com/bpampuch/pdfmake'],
            ['PDF.js', '3.11.174', 'Apache-2.0', 'https://github.com/mozilla/pdf.js'],
            ['Polices Roboto', '—', 'Apache-2.0', 'https://github.com/googlefonts/roboto'],
            ['Runtime Microsoft Visual C++', '2015-2022 (x64)', 'Redistribuable Microsoft', 'https://learn.microsoft.com/cpp/windows/latest-supported-vc-redist'],
            ['Runtime .NET 8', '8.0', 'MIT', 'https://github.com/dotnet/runtime'],
        ];
        const lignes = liens.map(l =>
            '<tr><td>' + l[0] + '</td><td>' + l[1] + '</td><td>' + l[2] + '</td>' +
            '<td><a href="' + l[3] + '" target="_blank" rel="noopener">' + l[3].replace('https://', '') + '</a></td></tr>'
        ).join('');
        return '<section class="aide-section" id="aide-licences">' +
            '<h3>🧩 Sources des composants</h3>' +
            '<p>Calulis est une application <strong>locale</strong> : tout ce dont elle a besoin est livré dans son dossier, sans rien installer. Elle embarque pour cela des composants libres, publiés par d\'autres auteurs. Voici lesquels, et sous quelle licence.</p>' +
            this._card('Composants embarqués',
                '<table class="aide-table"><tr><th>Composant</th><th>Version</th><th>Licence</th><th>Sources</th></tr>' +
                lignes +
                '</table>') +
            this._card('Où lire les licences complètes',
                this._ul([
                    'Le fichier <strong>THIRD-PARTY-NOTICES.md</strong>, à la racine du dossier Calulis, contient les textes complets (MIT, Apache-2.0, PHP License 3.01) et les renvois vers les sources.',
                    'La licence de MySQL est aussi livrée dans <strong>mysql\\LICENSE</strong>, et celle de PHP dans <strong>frankenphp\\license.txt</strong>.',
                    'Calulis ne modifie aucun de ces composants : ils sont livrés tels qu\'ils sont publiés par leurs auteurs.',
                ])) +
            this._card('Et Calulis ?',
                '<p>Calulis est développé par une seule personne, bénévolement. Il est <strong>gratuit</strong> et fonctionne hors ligne, sans compte, sans publicité et sans télémétrie. Voir la page <strong>❤️ Soutenir</strong>.</p>') +
        '</section>';
    },

    /* ====================== ET APRÈS ? ====================== */
    /**
     * Section « Et après ? » : les projets satellites (SCANULIS, BILANULIS, PLANULIS) et le
     * carnet de souhaits **local**.
     *
     * Règles de rédaction, arrêtées avec Jérôme le 29/09/2026 :
     * - **aucune date** annoncée : ce serait une promesse impossible à tenir seul ;
     * - « facultatif » écrit noir sur blanc : Calulis fonctionne seul, rien ne change ;
     * - l'IA est **locale**, et c'est la contrainte structurante (aucune donnée ne sort) ;
     * - le carnet **ne collecte rien** : il vit dans la base locale, et ne part que si
     *   l'utilisateur clique sur « Copier » ou « Envoyer par mail ».
     */
    _sectionEtApres() {
        return '<section class="aide-section" id="aide-etapres">' +
            '<h3>🧭 Et après ?</h3>' +
            '<p>Calulis est complet et le restera. Ce qui suit est <strong>facultatif</strong> : ce sont ' +
            'des <strong>pistes à l\'étude</strong>, sans aucune date annoncée et sans engagement. ' +
            'Si vous n\'installez rien, <strong>rien ne change</strong> dans Calulis.</p>' +
            this._card('📄 SCANULIS — lire les documents',
                '<p>Lire les documents officiels (notification MDPH, bilan, courrier, compte-rendu) et ' +
                '<strong>proposer</strong> de remplir les fiches à partir de ce qu\'ils contiennent. ' +
                'Vous relisez, vous corrigez, vous validez : rien n\'entre dans Calulis sans votre accord.</p>') +
            this._card('🗂️ BILANULIS — écrire et suivre dans le temps',
                '<p>Un atelier documentaire : ranger les documents et les observations d\'un élève, suivre ' +
                'ses objectifs d\'une année sur l\'autre, rédiger et versionner les bilans et les ' +
                'comptes-rendus, et adapter chaque document à son destinataire. Les sources que ' +
                '<em>vous</em> choisissez, un document daté, relu par vous.</p>') +
            this._card('📅 PLANULIS — construire les emplois du temps',
                '<p>Concevoir et comparer plusieurs semaines types, puis publier dans Calulis celle que ' +
                'vous retenez.</p>') +
            this._card('🧠 Pourquoi une IA locale, et pas un service en ligne',
                '<p>SCANULIS et BILANULIS n\'ont de sens que si le modèle tourne <strong>sur votre ' +
                'ordinateur</strong> : c\'est la même règle que Calulis — <strong>aucune donnée d\'élève ' +
                'ne sort de la machine</strong>.</p>' +
                '<p>C\'est aussi la principale difficulté : un modèle local demande de la place disque, de ' +
                'la mémoire et une installation plus lourde. C\'est ce point qu\'il faut trancher avant ' +
                'd\'écrire quoi que ce soit.</p>' +
                '<p>Et dans tous les cas : <strong>l\'IA propose, vous décidez</strong>. Aucun texte ne ' +
                'sera écrit dans un bilan sans votre relecture.</p>') +
            this._card('🤝 Et Calulis dans tout ça ?',
                '<p>Calulis reste l\'application centrale et <strong>fonctionne seule</strong>. Les modules ' +
                'satellites seraient <strong>facultatifs</strong>, gratuits, et sans aucune fonction ' +
                'réservée : ils ajouteraient du confort, ils ne retireraient rien.</p>') +
            this._carnetSouhaits() +
        '</section>';
    },

    /** Le carnet de souhaits : local, sauvegardé avec la base, envoyé UNIQUEMENT à la main. */
    _carnetSouhaits() {
        return this._card('✍️ Vos souhaits, vos besoins',
            '<p>Écrivez ce qui vous manque, ce qui vous ferait gagner du temps, ce que vous aimeriez voir ' +
            'dans ces modules. Un besoin exprimé vaut mieux qu\'une fonctionnalité devinée.</p>' +
            '<p class="text-muted small">Ce carnet <strong>reste sur cet ordinateur</strong> : il est ' +
            'enregistré dans votre base Calulis (donc dans vos sauvegardes), et il ne quitte la machine ' +
            'que si <strong>vous</strong> cliquez sur « Copier » ou « Envoyer par mail ». N\'y mettez pas ' +
            'de nom d\'élève : ce sont des idées, pas des données.</p>' +
            '<label for="souhaits-texte" style="display:block;margin-top:4px">Votre carnet</label>' +
            '<textarea id="souhaits-texte" rows="6" style="width:100%;font-family:inherit" ' +
            'placeholder="Exemple : je voudrais que Calulis…"></textarea>' +
            '<div style="display:flex;gap:8px;margin-top:8px;flex-wrap:wrap">' +
            '<button class="btn btn-primary" id="btn-souhaits-enregistrer">💾 Enregistrer</button>' +
            '<button class="btn btn-secondary" id="btn-souhaits-copier">📋 Copier</button>' +
            '<button class="btn btn-secondary" id="btn-souhaits-mail">📧 Envoyer par mail</button>' +
            '<button class="btn btn-sm btn-secondary" id="btn-souhaits-vider">Vider le carnet</button>' +
            '</div>' +
            '<div id="souhaits-msg" class="text-muted small" style="margin-top:8px;min-height:1.2em"></div>');
    },

    /**
     * Branche le carnet de souhaits — appelé APRÈS l'affichage de la section (son contenu
     * n'existe pas avant).
     */
    async _bindCarnetSouhaits() {
        const zone = document.getElementById('souhaits-texte');
        if (!zone) return;
        const msg = document.getElementById('souhaits-msg');
        const dire = (texte, couleur) => {
            if (!msg) return;
            msg.textContent = texte;
            msg.style.color = couleur || '';
        };

        // Carnet enregistré (silencieux : un échec ici laisse simplement le carnet vide)
        try {
            const params = await API.get('params.php');
            const ligne = (params || []).find(p => p.cle === 'souhaits');
            if (ligne && ligne.valeur) zone.value = String(ligne.valeur);
        } catch { /* base injoignable : l'enregistrement le dira */ }

        document.getElementById('btn-souhaits-enregistrer')?.addEventListener('click', async () => {
            try {
                await API.put('params.php', { souhaits: zone.value });
                dire('✅ Carnet enregistré — il part dans vos sauvegardes de base.', 'var(--success)');
            } catch (e) {
                dire('⚠ Enregistrement impossible : ' + (e.message || ''), 'var(--danger)');
            }
        });

        document.getElementById('btn-souhaits-copier')?.addEventListener('click', async () => {
            const texte = zone.value.trim();
            if (!texte) { dire('Le carnet est vide.', 'var(--danger)'); return; }
            const ok = await copierTexte(texte);
            dire(ok ? '✅ Copié : collez-le où vous voulez (Discord, Facebook, mail).'
                    : '⚠ Copie impossible : sélectionnez le texte et copiez-le à la main.',
                 ok ? 'var(--success)' : 'var(--danger)');
        });

        document.getElementById('btn-souhaits-mail')?.addEventListener('click', async () => {
            const texte = zone.value.trim();
            if (!texte) { dire('Le carnet est vide.', 'var(--danger)'); return; }
            const email = await obtenirEmailSupport();
            const version = (typeof Changelog !== 'undefined' && Changelog.latest) ? Changelog.latest : '';
            const corps = 'Souhaits et besoins pour Calulis :\n\n' + texte + '\n\n---\n'
                + 'Calulis ' + version + ' · ' + new Date().toLocaleString('fr-FR');
            const ouvert = await ouvrirMailto(email, '[Calulis] Souhaits et besoins', corps);
            if (ouvert) {
                dire('✅ Message préparé pour ' + email + ' : vérifiez et envoyez.', 'var(--success)');
            } else {
                await copierTexte(corps);
                dire('📧 Messagerie non ouverte : le texte a été copié, envoyez-le à ' + email + '.');
            }
        });

        document.getElementById('btn-souhaits-vider')?.addEventListener('click', async () => {
            if (!await Modal.confirm('Vider le carnet', 'Effacer tout le contenu du carnet ?')) return;
            zone.value = '';
            try {
                await API.put('params.php', { souhaits: '' });
                dire('Carnet vidé.', 'var(--success)');
            } catch (e) {
                dire('⚠ Vidé à l\'écran, mais non enregistré : ' + (e.message || ''), 'var(--danger)');
            }
        });
    },

    /* =========================== NAVIGATION =========================== */

    /* ====================== NOUVEAUTÉS ====================== */
    _sectionNouveautes() {
        const entries = (typeof Changelog !== 'undefined' ? Changelog.entries : []).slice(0, 5);
        if (entries.length === 0) {
            return '<section class="aide-section" id="aide-nouveautes"><h3>🎉 Nouveautés</h3><p>Aucune information disponible.</p></section>';
        }
        const html = entries.map(en => {
            const items = en.items.map(i => '<li>' + escapeHtml(i) + '</li>').join('');
            return '<div class="aide-card">' +
                '<h4>Version ' + escapeHtml(en.version) + (en.date ? ' — ' + escapeHtml(en.date) : '') + '</h4>' +
                '<ul>' + items + '</ul>' +
                '</div>';
        }).join('');
        return '<section class="aide-section" id="aide-nouveautes">' +
            '<h3>🎉 Quoi de neuf ?</h3>' +
            '<p>Les nouveautés des dernières versions de Calulis.</p>' +
            html +
            '</section>';
    },

    /**
     * Table des sections du guide — **une seule source**, utilisée par le clic sur le menu
     * ET par l'ouverture directe (`State.set('aide-section', …)`).
     *
     * Pourquoi : la table existait deux fois ; le chemin d'ouverture directe ne connaissait
     * que « nouveautés » et retombait sinon sur « Premier démarrage ». Le défaut était
     * dormant — un seul lien l'empruntait — mais il aurait affiché la mauvaise page dès
     * qu'un deuxième lien aurait visé une section (constaté le 29/09/2026).
     */
    _sections() {
        return {
            demarrage: this._sectionDemarrage(),
            concepts: this._sectionConcepts(),
            'dashboard-2': this._sectionDashboard(),
            'eleves-2': this._sectionEleves(),
            'agenda-2': this._sectionAgenda(),
            'adultes-2': this._sectionAdultes(),
            'reunions-2': this._sectionReunions(),
            'evenements-2': this._sectionEvenements(),
            'stats-2': this._sectionStats(),
            'listes-2': this._sectionListes(),
            'impression-2': this._sectionImpression(),
            'params-2': this._sectionParams(),
            scenarios: this._sectionScenarios(),
            raccourcis: this._sectionRaccourcis(),
            rgpd: this._sectionRgpd(),
            licences: this._sectionLicences(),
            etapres: this._sectionEtApres(),
            astuces: this._sectionAstuces(),
            nouveautes: this._sectionNouveautes(),
        };
    },

    /** Affiche une section du guide : entrée de menu active + contenu. */
    _afficherSection(nom) {
        const sections = this._sections();
        if (!sections[nom]) return false;
        document.querySelectorAll('.aide-nav-item').forEach(b => b.classList.remove('active'));
        document.querySelector('.aide-nav-item[data-section="' + nom + '"]')?.classList.add('active');
        const content = document.getElementById('aide-content');
        content.innerHTML = sections[nom];
        content.scrollTop = 0;
        // Le carnet n'existe qu'après l'affichage : ses boutons se branchent ici.
        if (nom === 'etapres') this._bindCarnetSouhaits();
        return true;
    },

    _bindEvents() {
        // Ouverture directe d'une section (ex. : « Quoi de neuf ? » depuis le tableau de bord)
        const requested = State.get('aide-section');
        if (requested) {
            this._afficherSection(requested);
            State.set('aide-section', null);
        }
        document.querySelectorAll('.aide-nav-item').forEach(btn => {
            btn.addEventListener('click', () => this._afficherSection(btn.dataset.section));
        });
    },
};