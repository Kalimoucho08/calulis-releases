/**
 * Calulis — Composant Mentions Légales & RGPD
 * Accessible depuis la sidebar (📄 Mentions RGPD)
 */
const MentionsRGPD = {

    render() {
        const view = document.getElementById('view-mentions-rgpd');
        view.innerHTML = this._buildHTML();
        this._bindEvents();
    },

    _buildHTML() {
        return `
        <div class="page-header">
            <h1>📄 Mentions légales & RGPD</h1>
        </div>
        <div class="aide-container">
            <div class="aide-nav">
                <a href="#" class="aide-nav-item active" data-section="responsable">Responsable</a>
                <a href="#" class="aide-nav-item" data-section="finalites">Finalités</a>
                <a href="#" class="aide-nav-item" data-section="donnees">Données traitées</a>
                <a href="#" class="aide-nav-item" data-section="base-legale">Base légale</a>
                <a href="#" class="aide-nav-item" data-section="conservation">Conservation</a>
                <a href="#" class="aide-nav-item" data-section="destinataires">Destinataires</a>
                <a href="#" class="aide-nav-item" data-section="droits">Vos droits</a>
                <a href="#" class="aide-nav-item" data-section="securite">Sécurité</a>
                <a href="#" class="aide-nav-item" data-section="tiers">Services tiers</a>
                <a href="#" class="aide-nav-item" data-section="dpd">DPD</a>
            </div>
            <div class="aide-content">
                <div id="section-responsable" class="aide-section">
                    <h2>🔑 Responsable de traitement</h2>
                    <p>Dans le cadre de l'utilisation de <strong>Calulis</strong> en établissement scolaire, le responsable de traitement est :</p>
                    <ul>
                        <li><strong>Pour le second degré (collège, lycée)</strong> : le chef d'établissement, en sa qualité de responsable de la mise en œuvre des dispositifs ULIS au sein de l'établissement.</li>
                        <li><strong>Pour le premier degré (école)</strong> : le DASEN (Directeur Académique des Services de l'Éducation Nationale), par délégation du recteur d'académie.</li>
                    </ul>
                    <p>L'utilisation de Calulis s'inscrit dans le cadre des missions de l'Éducation nationale et du service public de l'enseignement.</p>
                    <div class="aide-note">
                        <strong>📌 À personnaliser :</strong> Indiquez ici le nom de votre établissement, son UAI, et le nom du chef d'établissement ou du référent ULIS.
                    </div>
                </div>

                <div id="section-finalites" class="aide-section" style="display:none">
                    <h2>🎯 Finalités du traitement</h2>
                    <p>Calulis est un outil de gestion destiné aux coordonnateurs ULIS. Les finalités poursuivies sont les suivantes :</p>
                    <ul>
                        <li><strong>Suivi pédagogique</strong> — organisation des emplois du temps des élèves ULIS, gestion des inclusions en classe ordinaire, suivi des progressions.</li>
                        <li><strong>Coordination des accompagnements</strong> — gestion des AESH (Accompagnants des Élèves en Situation de Handicap) et des PEC (Prise en Charge) extérieures.</li>
                        <li><strong>Gestion administrative</strong> — suivi des notifications MDPH (dates de droits ULIS, SESSAD, AESH, transport), organisation des ESS (Équipes de Suivi de la Scolarisation).</li>
                        <li><strong>Organisation scolaire</strong> — gestion des transports, cantine, contacts d'urgence, représentants légaux.</li>
                        <li><strong>Suivi des réunions</strong> — comptes rendus ESS, équipes éducatives, rendez-vous familles.</li>
                        <li><strong>Tableau de bord</strong> — statistiques anonymisées à l'échelle de la structure pour le pilotage du dispositif ULIS.</li>
                    </ul>
                    <p>Ces finalités sont conformes aux missions définies par la <strong>circulaire n° 2015-129 du 21 août 2015</strong> relative aux ULIS.</p>
                </div>

                <div id="section-donnees" class="aide-section" style="display:none">
                    <h2>📋 Données personnelles traitées</h2>
                    <h3>Catégories de données</h3>
                    <table class="data-table" style="font-size:14px">
                        <thead>
                            <tr><th>Catégorie</th><th>Données concernées</th><th>Finalité</th></tr>
                        </thead>
                        <tbody>
                            <tr><td>Identité</td><td>Nom, prénom, date de naissance</td><td>Suivi scolaire, identification</td></tr>
                            <tr><td>Scolarité</td><td>Classe, niveau, ULIS, école d'origine</td><td>Organisation pédagogique</td></tr>
                            <tr><td>Handicap</td><td>Dates et statuts MDPH (ULIS, SESSAD, AESH, transport)</td><td>Suivi des notifications CDAPH — obligation réglementaire</td></tr>
                            <tr><td>Santé</td><td>Allergies, PAI, précautions médicales pour la vie scolaire</td><td>Sécurité de l'élève — uniquement les précautions nécessaires à la vie scolaire</td></tr>
                            <tr><td>Coordonnées</td><td>Téléphone, email, adresse (élève et représentants)</td><td>Contact d'urgence, communication école-famille</td></tr>
                            <tr><td>Accompagnement</td><td>AESH, PEC, transport, cantine</td><td>Coordination des accompagnements</td></tr>
                            <tr><td>Protection enfance</td><td>ASE (statut, référent)</td><td>Coordination avec les services de protection de l'enfance</td></tr>
                        </tbody>
                    </table>
                    <p class="aide-note" style="margin-top:12px">
                        ⚠️ <strong>Précision importante</strong> : Calulis ne stocke <em>aucun diagnostic médical</em> (pathologie, trouble, syndrome). Les seules informations de santé conservées sont les précautions nécessaires à la vie scolaire (allergies, traitements en cours, aménagements). Les diagnostics relèvent du dossier médical de l'école/de l'établissement.
                    </p>
                </div>

                <div id="section-base-legale" class="aide-section" style="display:none">
                    <h2>⚖️ Base légale des traitements</h2>
                    <p>Les traitements mis en œuvre dans Calulis reposent sur les bases légales suivantes :</p>
                    <ul>
                        <li><strong>Mission d'intérêt public</strong> (Article 6.1.e du RGPD) — pour l'ensemble des traitements liés à la scolarisation des élèves ULIS, conformément aux missions définies par le code de l'éducation et les circulaires relatives aux ULIS.</li>
                        <li><strong>Obligation légale</strong> (Article 6.1.c du RGPD) — pour le suivi des notifications MDPH et l'organisation des ESS, conformément aux dispositions du code de l'éducation (articles L.112-1 et suivants).</li>
                        <li><strong>Intérêts vitaux</strong> (Article 6.1.d du RGPD) — pour les données de contact d'urgence et les précautions médicales (allergies, traitements).</li>
                    </ul>
                    <div class="aide-note">
                        <strong>📌 Note :</strong> Le recueil du consentement individuel des familles n'est pas requis lorsque le traitement est nécessaire à l'exécution d'une mission d'intérêt public. Toutefois, les familles doivent être informées du traitement de leurs données (cf. section "Vos droits").
                    </div>
                </div>

                <div id="section-conservation" class="aide-section" style="display:none">
                    <h2>⏱️ Durée de conservation</h2>
                    <table class="data-table" style="font-size:14px">
                        <thead>
                            <tr><th>Catégorie de données</th><th>Durée de conservation</th></tr>
                        </thead>
                        <tbody>
                            <tr><td>Données élève (actif)</td><td>Année scolaire en cours + année suivante (pour continuité)</td></tr>
                            <tr><td>Données élève (sorti)</td><td>1 an après la sortie du dispositif, puis anonymisation ou suppression</td></tr>
                            <tr><td>Comptes rendus de réunions</td><td>5 ans (archivage courant, puis archivage intermédiaire)</td></tr>
                            <tr><td>Données de connexion/logs</td><td>Non conservées (application locale)</td></tr>
                            <tr><td>Sauvegardes (exports .sql)</td><td>Durée de conservation définie par l'établissement, à purger régulièrement</td></tr>
                        </tbody>
                    </table>
                    <p>L'utilisateur (coordonnateur ULIS) peut à tout moment supprimer les données d'un élève sorti du dispositif via l'interface.</p>
                </div>

                <div id="section-destinataires" class="aide-section" style="display:none">
                    <h2>👥 Destinataires des données</h2>
                    <p>Les données traitées dans Calulis sont destinées aux personnes suivantes, dans le cadre de leurs fonctions :</p>
                    <ul>
                        <li><strong>Coordonnateur ULIS</strong> — accès complet à l'ensemble des données pour la gestion du dispositif.</li>
                        <li><strong>AESH</strong> — accès limité aux emplois du temps et aux informations nécessaires à leur mission d'accompagnement.</li>
                        <li><strong>Chef d'établissement / Directeur d'école</strong> — accès aux données statistiques et au suivi global du dispositif.</li>
                        <li><strong>Enseignants de classe de référence</strong> — informations sur les temps d'inclusion et les aménagements pédagogiques.</li>
                    </ul>
                    <p><strong>Non-destinataires :</strong> Les données ne sont en aucun cas transmises à des tiers non autorisés, ni vendues, ni louées, ni partagées à des fins commerciales.</p>
                    <div class="aide-note">
                        <strong>🔒 Application locale :</strong> Calulis fonctionne sur le poste de l'utilisateur (serveur local). Aucune donnée n'est transmise à des serveurs distants, à l'exception des bibliothèques JavaScript chargées depuis CDN (cf. section "Services tiers").
                    </div>
                </div>

                <div id="section-droits" class="aide-section" style="display:none">
                    <h2>🛡️ Vos droits</h2>
                    <p>Conformément au RGPD (Règlement Général sur la Protection des Données) et à la loi Informatique et Libertés, les personnes concernées (élèves et leurs représentants légaux) disposent des droits suivants :</p>
                    <table class="data-table" style="font-size:14px">
                        <thead>
                            <tr><th>Droit</th><th>Description</th><th>Procédure</th></tr>
                        </thead>
                        <tbody>
                            <tr><td><strong>Accès</strong></td><td>Obtenir la confirmation que des données sont traitées et en recevoir une copie</td><td>Contacter le chef d'établissement ou le DPD</td></tr>
                            <tr><td><strong>Rectification</strong></td><td>Demander la correction de données inexactes ou incomplètes</td><td>Contacter le coordonnateur ULIS ou le chef d'établissement</td></tr>
                            <tr><td><strong>Effacement</strong></td><td>Demander la suppression des données (dans la limite des obligations légales de conservation)</td><td>Contacter le chef d'établissement ou le DPD</td></tr>
                            <tr><td><strong>Limitation</strong></td><td>Demander le gel temporaire du traitement</td><td>Contacter le DPD</td></tr>
                            <tr><td><strong>Opposition</strong></td><td>S'opposer au traitement pour des motifs tenant à la situation particulière</td><td>Contacter le chef d'établissement ou le DPD</td></tr>
                            <tr><td><strong>Portabilité</strong></td><td>Recevoir les données dans un format structuré (sur demande)</td><td>Contacter le DPD</td></tr>
                        </tbody>
                    </table>
                    <div class="aide-note">
                        <strong>✉️ Pour exercer vos droits :</strong> Adressez-vous d'abord au chef d'établissement ou au coordonnateur ULIS. Vous pouvez également contacter le Délégué à la Protection des Données (DPD) de votre académie — voir coordonnées dans la section "DPD".
                        <br><br>
                        Si vous estimez que vos droits ne sont pas respectés, vous avez la possibilité d'introduire une réclamation auprès de la <strong>CNIL</strong> (Commission Nationale de l'Informatique et des Libertés) : <a href="https://www.cnil.fr" target="_blank" rel="noopener">www.cnil.fr</a>.
                    </div>
                </div>

                <div id="section-securite" class="aide-section" style="display:none">
                    <h2>🔐 Sécurité des données</h2>
                    <p>Calulis met en œuvre les mesures de sécurité suivantes pour protéger les données personnelles :</p>
                    <ul>
                        <li>✅ <strong>Protection contre les injections SQL</strong> — toutes les requêtes utilisent des requêtes préparées (PDO) avec désactivation de l'émulation.</li>
                        <li>✅ <strong>Protection XSS</strong> — toutes les données affichées sont échappées (fonction <code>escapeHtml()</code>).</li>
                        <li>✅ <strong>Application locale</strong> — pas d'exposition sur Internet, les données ne quittent pas le poste de l'utilisateur.</li>
                        <li>✅ <strong>Absence de télémétrie</strong> — pas d'analytics, pas de tracking, pas de cookies.</li>
                        <li>✅ <strong>Pas de données dans le navigateur</strong> — le navigateur ne garde qu'un réglage d'affichage (le thème clair ou sombre). Aucune donnée d'élève n'y est enregistrée.</li>
                        <li>✅ <strong>Pas de photos ni fichiers uploadés</strong> — aucun contenu multimédia des élèves n'est stocké.</li>
                    </ul>
                    <p><strong>Recommandations :</strong></p>
                    <ul>
                        <li>Utiliser un poste de travail dont l'accès est protégé par un mot de passe.</li>
                        <li>Verrouiller la session en cas d'absence.</li>
                        <li>Les exports PDF ou CSV contenant des données personnelles doivent être stockés de manière sécurisée et supprimés dès que leur usage est terminé.</li>
                    </ul>
                </div>

                <div id="section-tiers" class="aide-section" style="display:none">
                    <h2>🔗 Services tiers</h2>
                    <p>Calulis utilise les services tiers suivants, strictement nécessaires à son fonctionnement :</p>
                    <p><strong>✅ Aucun service tiers.</strong> Calulis fonctionne entièrement en local. Toutes les bibliothèques nécessaires (pdfmake, pdf.js) sont servies depuis le serveur local. Aucune donnée n'est transmise à un service externe.</p>
                    <p style="font-size:13px;color:var(--text-muted)">Les seules requêtes externes sont les mises à jour logicielles (dépôt GitHub) et les liens d'aide (Discord, Facebook), qui ne contiennent aucune donnée personnelle.</p>
                </div>

                <div id="section-dpd" class="aide-section" style="display:none">
                    <h2>👤 Délégué à la Protection des Données (DPD)</h2>
                    <p>Le Délégué à la Protection des Données (DPD, ou DPO en anglais) de votre académie est l'interlocuteur privilégié pour toutes les questions relatives à la protection des données personnelles.</p>
                    <div class="aide-info-box" style="background:var(--surface);border:1px solid var(--border);border-radius:8px;padding:16px;margin:12px 0">
                        <p style="margin:0 0 8px"><strong>📧 Contacter le DPD de votre académie :</strong></p>
                        <p style="margin:0 0 4px">Académie de Poitiers : <code>dpd@ac-poitiers.fr</code></p>
                        <p style="margin:0 0 4px">Académie de Paris : <code>dpd@ac-paris.fr</code></p>
                        <p style="margin:0 0 4px">Académie de Lyon : <code>dpd@ac-lyon.fr</code></p>
                        <p style="margin:0;font-size:13px;color:var(--text-muted)">→ Remplacer par l'adresse de votre académie. La liste complète des DPD académiques est disponible sur le site de votre rectorat.</p>
                    </div>
                    <p><strong>Informations générales :</strong></p>
                    <ul>
                        <li>Le DPD est chargé de veiller à la conformité RGPD au sein de l'académie.</li>
                        <li>Il doit être informé de tout nouveau traitement de données personnelles ou de toute modification substantielle d'un traitement existant (Eduscol).</li>
                        <li>Il est joignable pour toute question relative à l'utilisation de Calulis et au respect des droits des personnes.</li>
                    </ul>
                    <p class="aide-note">
                        <strong>📌 Action recommandée :</strong> Avant de déployer Calulis dans votre établissement, contactez votre DPD académique pour l'informer de ce traitement et vous assurer de la conformité avec les règles locales.
                    </p>
                </div>
            </div>
        </div>
        <div class="aide-footer" style="border-top:1px solid var(--border);margin-top:32px;padding-top:16px;font-size:13px;color:var(--text-muted);text-align:center">
            <p style="margin:0">Calulis — Application de gestion ULIS. Dernière mise à jour : juillet 2026.</p>
            <p style="margin:4px 0 0">Conformément au RGPD et à la loi Informatique et Libertés.</p>
        </div>
        `;
    },

    _bindEvents() {
        document.querySelectorAll('.aide-nav-item').forEach(item => {
            item.addEventListener('click', (e) => {
                e.preventDefault();
                const section = item.dataset.section;
                if (!section) return;
                // Navigation
                document.querySelectorAll('.aide-nav-item').forEach(n => n.classList.remove('active'));
                item.classList.add('active');
                document.querySelectorAll('.aide-section').forEach(s => s.style.display = 'none');
                const target = document.getElementById('section-' + section);
                if (target) target.style.display = 'block';
            });
        });
    }
};
