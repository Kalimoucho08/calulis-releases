/**
 * Calulis — Composant « Soutenir » (soutien bénévole via PayPal)
 *
 * Principe : le soutien est FACULTATIF et sans contrepartie.
 * Calulis reste gratuit, complet et utilisable avec ou sans don.
 *
 * Décision du 28/09/2026 : la page n'affiche NI objectif, NI montant reçu, NI progression.
 * Seul paramètre lu dans la table `params` :
 *   paypal_url : lien de don PayPal (JSON string)
 * Le lien par défaut ci-dessous s'applique si le paramètre est absent ou la base injoignable.
 */
const Don = {
    async render() {
        const view = document.getElementById('view-don');
        if (!view) return;

        let paypalUrl = 'https://www.paypal.com/donate/?business=3KCEHR329B9GW&currency_code=EUR';

        try {
            const params = await API.get('params.php');
            const p = params.find(x => x.cle === 'paypal_url');
            if (p && p.valeur) paypalUrl = JSON.parse(p.valeur);
        } catch {
            // Pas de base accessible : on garde le lien par défaut.
        }

        view.innerHTML = `
            <div style="max-width:640px;margin:0 auto;padding:40px 20px">
                <h2 style="margin-bottom:16px;text-align:center">Soutenir Calulis</h2>

                <p style="line-height:1.7;margin-bottom:8px">
                    Calulis est développé par <strong>une seule personne</strong>, bénévolement,
                    pour les coordonnateurs ULIS. Le logiciel est <strong>gratuit et complet</strong> :
                    il fonctionne exactement de la même façon que vous fassiez un don ou non.
                </p>

                <h3 style="margin-top:28px">À quoi sert votre soutien</h3>
                <ul style="line-height:1.8;padding-left:22px">
                    <li>l'<strong>assistant IA</strong> qui m'aide à écrire le logiciel : c'est le
                        premier poste de dépense, quelques euros par jour d'atelier ;</li>
                    <li>le <strong>temps de développement et de support</strong>, pris sur le temps libre ;</li>
                    <li>l'<strong>hébergement</strong> des téléchargements et des mises à jour ;</li>
                    <li>un <strong>certificat de signature Windows</strong> le jour où il deviendra
                        nécessaire pour éviter les avertissements à l'installation ;</li>
                    <li>les <strong>frais prélevés par PayPal</strong> sur chaque paiement.</li>
                </ul>

                <p style="line-height:1.7;margin:24px 0 8px">
                    Un geste de <strong>10 à 20 €</strong> est le plus efficace : PayPal prélève sur
                    chaque paiement une commission comprenant une part fixe, qui pèse
                    proportionnellement plus lourd sur les petits montants.
                </p>

                <p style="text-align:center;margin:28px 0 12px">
                    <a href="${escapeHtml(paypalUrl)}" target="_blank" rel="noopener" class="btn btn-primary"
                       style="font-size:18px;padding:14px 36px">
                        Soutenir avec PayPal
                    </a>
                </p>

                <p class="text-muted small" style="text-align:center">
                    Ou en copiant ce lien : <a href="${escapeHtml(paypalUrl)}" target="_blank" rel="noopener">${escapeHtml(paypalUrl)}</a>
                </p>

                <div style="margin:32px 0;padding:16px 20px;background:var(--surface-alt,#f5f5f5);border-radius:8px">
                    <p style="margin:0;line-height:1.7">
                        <strong>Calulis reste gratuit et complet, avec ou sans don.</strong>
                        Aucune fonction n'est réservée aux donateurs, aucun contenu n'est débloqué
                        par un don, et aucune donnée n'est demandée pour soutenir le projet.
                    </p>
                </div>

                <h3>Un coup de main, sans argent ?</h3>
                <ul style="line-height:1.8;padding-left:22px">
                    <li>signaler un bug ou une gêne à l'usage ;</li>
                    <li>proposer une amélioration ou un cas d'usage auquel je n'ai pas pensé ;</li>
                    <li>en parler à un collègue coordonnateur ULIS qui ne connaît pas encore Calulis.</li>
                </ul>

                <p class="text-muted small" style="line-height:1.8;margin-top:24px">
                    Pour échanger : <a href="https://discord.gg/YkJ3XgMA" target="_blank" rel="noopener">Discord</a>
                    ou <a href="https://www.facebook.com/profile.php?id=61575316486226" target="_blank" rel="noopener">Facebook</a>.
                </p>

                <p style="margin-top:32px;text-align:center"><em>Merci pour votre soutien.</em></p>
            </div>
        `;
    },
};
