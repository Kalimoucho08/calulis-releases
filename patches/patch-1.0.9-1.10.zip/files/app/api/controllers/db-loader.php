<?php
/**
 * Calulis — Sélecteur de snapshots
 *
 * GET  /db-loader.php   → liste les snapshots disponibles
 * POST /db-loader.php   → charge un snapshot (body: { snapshot: "v5" })
 */
require_once __DIR__ . '/../config.php';

$method = $_SERVER['REQUEST_METHOD'];

try {
    $snapshotFiles = [
        'v6' => [
            'id' => 'v6',
            'label' => 'Base démo V6',
            'description' => '12 élèves, 15 adultes, 11 établissements, 3 années (2024→2027), ~12500 créneaux. Horaires 08:30-16:30, pauses 10h+15h.',
            'size' => '~2.1 Mo',
            'path' => __DIR__ . '/../../data/calulis-demo-v6.sql',
            'dbType' => 'demo',
        ],
        'empty' => [
            'id' => 'empty',
            'label' => 'Base vierge (structure uniquement)',
            'description' => 'Aucune donnée — uniquement les tables vides. Pour démarrer une nouvelle base de zéro.',
            'size' => '~15 Ko',
            'path' => __DIR__ . '/../../data/calulis-vierge.sql',
            'dbType' => 'vierge',
        ],
    ];

    if ($method === 'GET') {
        // Ajouter l'option perso si la config existe
        $configPath = dirname(__DIR__, 3) . '/runtime/config.json';
        $hasPerso = false;
        $persoName = 'Ma base';
        if (file_exists($configPath)) {
            $cfg = json_decode(file_get_contents($configPath), true);
            if ($cfg && ($cfg['dbType'] ?? '') === 'perso') {
                $hasPerso = true;
                $persoName = $cfg['baseName'] ?? 'Ma base';
            }
        }
        $list = array_values(array_map(function ($s) { unset($s['path']); return $s; }, $snapshotFiles));
        if ($hasPerso) {
            $list[] = [
                'id' => 'perso',
                'label' => $persoName,
                'description' => 'Vos données personnelles. Aucune importation, conserve tout en l\'état.',
                'dbType' => 'perso',
            ];
        }
        jsonResponse($list);
    }

    if ($method === 'POST') {
        if (getenv('CALULIS_ENV') === 'production') {
            jsonError('Accès interdit en production', 403);
        }

        $input = json_decode(file_get_contents('php://input'), true);
        $id = $input['snapshot'] ?? 'v6';

        if (!isset($snapshotFiles[$id])) {
            jsonError('Snapshot inconnu : ' . $id, 400);
        }

        // Si le fichier n'existe pas et que c'est 'empty', le générer depuis la base live
        if ($id === 'empty' && !file_exists($snapshotFiles['empty']['path'])) {
            $pdo = getDB();
            $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
            $sql = "SET FOREIGN_KEY_CHECKS = 0;\n\n";
            foreach ($tables as $table) {
                $create = $pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_NUM);
                $sql .= "DROP TABLE IF EXISTS `$table`;\n";
                $sql .= $create[1] . ";\n\n";
            }
            $sql .= "SET FOREIGN_KEY_CHECKS = 1;\n";
            file_put_contents($snapshotFiles['empty']['path'], $sql);
        }

        $file = $snapshotFiles[$id]['path'];
        if (!file_exists($file)) {
            jsonError('Fichier SQL introuvable : ' . $file, 500);
        }

        $cmd = 'mysql -u calulis -pcalulis -S /var/run/mysqld/mysqld.sock calulis < ' . escapeshellarg($file) . ' 2>/dev/null';
        exec($cmd, $output, $code);

        if ($code !== 0) {
            // Fallback PHP : charger ligne par ligne
            $pdo = getDB();
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 0");
            $sql = file_get_contents($file);
            $statements = preg_split('/;\s*\n/', $sql);
            foreach ($statements as $stmt) {
                $stmt = trim($stmt);
                if ($stmt === '' || str_starts_with($stmt, '--') || str_starts_with($stmt, '/*')) continue;
                try { $pdo->exec($stmt); } catch (\Throwable $e) {}
            }
            $pdo->exec("SET FOREIGN_KEY_CHECKS = 1");
        }

        // Appliquer les migrations en attente : certaines tables (classe_enseignants, groupes, eleve_groupes)
        // sont creees par migration (003-006) et absentes des dumps demo/vierge. On les cree ici pour que
        // l'onglet Classes et les Listes fonctionnent sur une base fraichement chargee.
        try {
            require_once __DIR__ . '/../models/Migration.php';
            (new Migration())->run();
        } catch (\Throwable $me) {
            // Ne pas bloquer le chargement du snapshot si une migration echoue (le detail est journalise par l'API migrate)
        }

        // Mettre à jour runtime/config.json (pour le launcher)
        $configPath = dirname(__DIR__, 3) . '/runtime/config.json';
        $dbType = $snapshotFiles[$id]['dbType'] ?? 'demo';
        $config = [
            'dbType' => $dbType,
            'dbInitDone' => true,
            'createdAt' => gmdate('Y-m-d\TH:i:s\Z'),
            'version' => '1.0',
        ];
        @file_put_contents($configPath, json_encode($config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));

        // Comptes
        $pdo = getDB();
        $creneaux = $pdo->query("SELECT COUNT(*) FROM creneaux")->fetchColumn();
        $eleves = $pdo->query("SELECT COUNT(*) FROM eleves")->fetchColumn();
        $adultes = $pdo->query("SELECT COUNT(*) FROM adultes")->fetchColumn();
        $etabs = $pdo->query("SELECT COUNT(*) FROM etablissements")->fetchColumn();
        $reunions = $pdo->query("SELECT COUNT(*) FROM reunions")->fetchColumn();

        jsonResponse([
            'ok' => true,
            'snapshot' => $id,
            'message' => "Snapshot V5 chargé — $creneaux créneaux, $eleves élèves, $adultes adultes, $etabs établissements, $reunions réunions",
            'counts' => compact('creneaux', 'eleves', 'adultes', 'etabs'),
        ]);
    }

    jsonError('Méthode non supportée', 405);
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
