<?php
/** Calulis — Setup : crée les tables (compatible SQLite et MySQL) */
require_once __DIR__ . '/../config.php';

try {
    $pdo = getDB();
    $isMySQL = USE_MYSQL;
    $ai = $isMySQL ? 'INT AUTO_INCREMENT PRIMARY KEY' : 'INTEGER PRIMARY KEY AUTOINCREMENT';
    $engine = $isMySQL ? ' ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci' : '';
    $ts = $isMySQL ? 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP' : 'TIMESTAMP DEFAULT CURRENT_TIMESTAMP';
    $now = $isMySQL ? 'CURRENT_TIMESTAMP' : "CURRENT_TIMESTAMP";

    $tables = [];

    $tables[] = "CREATE TABLE IF NOT EXISTS annees_scolaires (
        id $ai, nom VARCHAR(50) NOT NULL, date_debut DATE NOT NULL, date_fin DATE NOT NULL,
        est_active INTEGER DEFAULT 0
    )$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS eleves (
        id $ai,
        nom VARCHAR(100) NOT NULL, prenom VARCHAR(100) NOT NULL, date_naissance DATE,
        classe VARCHAR(20), ulis INTEGER DEFAULT 0, groupe VARCHAR(50),
        niveau_scolaire VARCHAR(20), ecole_origine VARCHAR(100), date_entree_ulis DATE,
        suivi_par VARCHAR(100),
        aesh_type VARCHAR(10), aesh_nom VARCHAR(100), aesh_heures VARCHAR(20),
        aesh_mutualise_avec TEXT,
        pec_specialite VARCHAR(50), pec_organisme VARCHAR(50), pec_frequence VARCHAR(30),
        pec_lieu VARCHAR(50), pec_duree VARCHAR(20), pec_commentaires TEXT,
        transport VARCHAR(100), cantine INTEGER DEFAULT 0,
        telephone_urgence VARCHAR(20), telephone VARCHAR(20), email VARCHAR(100), adresse TEXT,
        allergies TEXT, regime_alimentaire VARCHAR(100), suivi_medical TINYINT DEFAULT 0, precautions_medicales TEXT,
        pai INTEGER DEFAULT 0, lien_pai VARCHAR(500), liens_mdph TEXT, remarques TEXT,
        notifications TEXT,
        mdph_ulis_date_fin DATE, mdph_ulis_statut VARCHAR(30),
        mdph_sessad_date_fin DATE, mdph_sessad_statut VARCHAR(30),
        mdph_aesh_date_fin DATE, mdph_aesh_statut VARCHAR(30),
        mdph_transport_date_fin DATE, mdph_transport_statut VARCHAR(30),
        mdph_autre_date_fin DATE, mdph_autre_statut VARCHAR(30), mdph_autre_libelle VARCHAR(100),
        ase_place INTEGER DEFAULT 0, ase_type_placement VARCHAR(50),
        ase_structure_nom VARCHAR(200), ase_structure_adresse TEXT, ase_structure_telephone VARCHAR(20),
        ase_referent_nom VARCHAR(100), ase_referent_telephone VARCHAR(20), ase_referent_email VARCHAR(100),
        ase_lien_ppe VARCHAR(500), ase_notes TEXT,
        actif INTEGER DEFAULT 1, ordre INTEGER DEFAULT 0,
        created_at $ts, updated_at $ts
    )$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS representants (
        id $ai, eleve_id INTEGER NOT NULL,
        nom VARCHAR(100) NOT NULL, prenom VARCHAR(100), lien VARCHAR(50),
        telephone VARCHAR(20), telephone_urgence VARCHAR(20), email VARCHAR(100), adresse TEXT,
        ordre INTEGER DEFAULT 0, created_at $ts, updated_at $ts" .
        ($isMySQL ? ", FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE CASCADE" : "") .
    ")$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS aesh_eleves (
        id $ai, eleve_id INTEGER NOT NULL,
        type VARCHAR(10) NOT NULL, nom VARCHAR(100), heures VARCHAR(20), mutualise_avec TEXT,
        ordre INTEGER DEFAULT 0, created_at $ts, updated_at $ts" .
        ($isMySQL ? ", FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE CASCADE" : "") .
    ")$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS pec_eleves (
        id $ai, eleve_id INTEGER NOT NULL,
        specialite VARCHAR(50), organisme VARCHAR(50), frequence VARCHAR(30),
        lieu VARCHAR(50), duree VARCHAR(20), commentaires TEXT,
        ordre INTEGER DEFAULT 0, created_at $ts, updated_at $ts" .
        ($isMySQL ? ", FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE CASCADE" : "") .
    ")$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS semaines (
        id $ai, annee_scolaire_id INTEGER NOT NULL, numero INTEGER NOT NULL,
        date_debut DATE NOT NULL, date_fin DATE NOT NULL,
        est_vacances INTEGER DEFAULT 0, est_modifiee INTEGER DEFAULT 0, notes TEXT" .
        ($isMySQL ? ", FOREIGN KEY (annee_scolaire_id) REFERENCES annees_scolaires(id) ON DELETE CASCADE" : "") .
    ")$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS creneaux (
        id $ai, eleve_id INTEGER NOT NULL, semaine_id INTEGER,
        jour VARCHAR(10) NOT NULL, heure_debut TIME NOT NULL, duree INTEGER DEFAULT 15,
        matiere VARCHAR(100), groupe VARCHAR(50), adulte VARCHAR(100),
        role_adulte VARCHAR(30), type VARCHAR(20) DEFAULT 'fixe',
        regroupement_type VARCHAR(30), couleur_override VARCHAR(7), commentaire TEXT,
        created_at $ts, updated_at $ts" .
        ($isMySQL ? ", FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE CASCADE, FOREIGN KEY (semaine_id) REFERENCES semaines(id) ON DELETE CASCADE" : "") .
    ")$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS evenements (
        id $ai, annee_scolaire_id INTEGER NOT NULL, nom VARCHAR(200) NOT NULL,
        description TEXT, date_debut DATE, date_fin DATE, jour_semaine VARCHAR(10),
        est_recurrent INTEGER DEFAULT 0, recurrence_type VARCHAR(30), couleur VARCHAR(7),
        affecte_semaine_type INTEGER DEFAULT 0, created_at $ts" .
        ($isMySQL ? ", FOREIGN KEY (annee_scolaire_id) REFERENCES annees_scolaires(id) ON DELETE CASCADE" : "") .
    ")$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS reunions (
        id $ai, type VARCHAR(50) NOT NULL, titre VARCHAR(200) NOT NULL,
        date_reunion DATE NOT NULL, heure TIME, duree INTEGER DEFAULT 60,
        eleve_id INTEGER, lieu VARCHAR(200), participants TEXT, statut VARCHAR(30) DEFAULT 'prevue',
        notes TEXT, documents_lies TEXT, created_at $ts, updated_at $ts" .
        ($isMySQL ? ", FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE SET NULL" : "") .
    ")$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS taches (
        id $ai, description VARCHAR(500) NOT NULL, eleve_id INTEGER, reunion_id INTEGER,
        date_creation DATE NOT NULL DEFAULT (CURRENT_DATE), echeance DATE,
        priorite VARCHAR(20) DEFAULT 'moyenne', statut VARCHAR(30) DEFAULT 'a_faire',
        responsable VARCHAR(100), notes TEXT, created_at $ts, updated_at $ts" .
        ($isMySQL ? ", FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE SET NULL, FOREIGN KEY (reunion_id) REFERENCES reunions(id) ON DELETE SET NULL" : "") .
    ")$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS notes_suivi (
        id $ai, eleve_id INTEGER NOT NULL, date_note DATE NOT NULL DEFAULT (CURRENT_DATE),
        auteur VARCHAR(100), type VARCHAR(30) DEFAULT 'observation', contenu TEXT NOT NULL,
        created_at $ts" .
        ($isMySQL ? ", FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE CASCADE" : "") .
    ")$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS documents (
        id $ai, nom VARCHAR(300) NOT NULL, type VARCHAR(50) NOT NULL,
        eleve_id INTEGER, reunion_id INTEGER, date_document DATE, version VARCHAR(20),
        statut VARCHAR(30) DEFAULT 'en_attente', reference_externe VARCHAR(500), notes TEXT,
        created_at $ts, updated_at $ts" .
        ($isMySQL ? ", FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE SET NULL, FOREIGN KEY (reunion_id) REFERENCES reunions(id) ON DELETE SET NULL" : "") .
    ")$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS templates_documents (
        id $ai, nom VARCHAR(200) NOT NULL, description TEXT, categorie VARCHAR(50),
        contenu TEXT NOT NULL, format_sortie VARCHAR(20) DEFAULT 'pdf',
        created_at $ts, updated_at $ts
    )$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS periodes (
        id $ai, annee_scolaire_id INTEGER NOT NULL,
        nom VARCHAR(50) NOT NULL, date_debut DATE NOT NULL, date_fin DATE NOT NULL, ordre INTEGER DEFAULT 0" .
        ($isMySQL ? ", FOREIGN KEY (annee_scolaire_id) REFERENCES annees_scolaires(id) ON DELETE CASCADE" : "") .
    ")$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS vacances (
        id $ai, nom VARCHAR(100) NOT NULL, date_debut DATE NOT NULL, date_fin DATE NOT NULL,
        zone VARCHAR(1), annee_scolaire_id INTEGER" .
        ($isMySQL ? ", FOREIGN KEY (annee_scolaire_id) REFERENCES annees_scolaires(id) ON DELETE CASCADE" : "") .
    ")$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS parametres (
        cle VARCHAR(50) PRIMARY KEY, valeur TEXT NOT NULL, updated_at $ts
    )$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS etablissements (
        id $ai,
        nom VARCHAR(200) NOT NULL,
        type VARCHAR(50) DEFAULT '',
        ville VARCHAR(100) DEFAULT '',
        adresse TEXT,
        telephone VARCHAR(20) DEFAULT '',
        telephone2 VARCHAR(20) DEFAULT '',
        email VARCHAR(100) DEFAULT '',
        email2 VARCHAR(100) DEFAULT '',
        description TEXT,
        actif INTEGER DEFAULT 1,
        created_at $ts, updated_at $ts
    )$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS classes (
        id $ai,
        nom VARCHAR(100) NOT NULL,
        niveaux TEXT,
        enseignant_id INTEGER DEFAULT NULL,
        etablissement_id INTEGER DEFAULT NULL,
        actif INTEGER DEFAULT 1,
        created_at $ts, updated_at $ts" .
        ($isMySQL ? ", FOREIGN KEY (enseignant_id) REFERENCES adultes(id) ON DELETE SET NULL, FOREIGN KEY (etablissement_id) REFERENCES etablissements(id) ON DELETE SET NULL" : "") .
    ")$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS classe_enseignants (
        id $ai,
        classe_id INTEGER NOT NULL,
        adulte_id INTEGER NOT NULL,
        jours TEXT,
        plage VARCHAR(20) DEFAULT 'journee',
        ordre INTEGER DEFAULT 0,
        created_at $ts, updated_at $ts" .
        ($isMySQL ? ", FOREIGN KEY (classe_id) REFERENCES classes(id) ON DELETE CASCADE, FOREIGN KEY (adulte_id) REFERENCES adultes(id) ON DELETE CASCADE" : "") .
    ")$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS adultes_etablissements (
        adulte_id INTEGER NOT NULL,
        etablissement_id INTEGER NOT NULL,
        role VARCHAR(50) DEFAULT '',
        PRIMARY KEY (adulte_id, etablissement_id)" .
        ($isMySQL ? ", FOREIGN KEY (adulte_id) REFERENCES adultes(id) ON DELETE CASCADE, FOREIGN KEY (etablissement_id) REFERENCES etablissements(id) ON DELETE CASCADE" : "") .
    ")$engine";

    $tables[] = "CREATE TABLE IF NOT EXISTS pauses (
        id $ai, nom VARCHAR(100) NOT NULL, heure_debut TIME NOT NULL, heure_fin TIME NOT NULL,
        couleur VARCHAR(7) DEFAULT '#e0e0e0', actif INTEGER DEFAULT 1,
        jours VARCHAR(100) DEFAULT 'lundi,mardi,jeudi,vendredi', ordre INTEGER DEFAULT 0
    )$engine";

    foreach ($tables as $sql) {
        $pdo->exec($sql);
    }

    // Ajout des colonnes FK (compatibilité montée de version)
    try { $pdo->exec("ALTER TABLE eleves ADD COLUMN etablissement_id INTEGER DEFAULT NULL"); } catch (Exception $e) {}
    try { $pdo->exec("ALTER TABLE adultes ADD COLUMN etablissement_id INTEGER DEFAULT NULL"); } catch (Exception $e) {}
    try { $pdo->exec("ALTER TABLE adultes ADD COLUMN fonction VARCHAR(50) DEFAULT '' AFTER role"); } catch (Exception $e) {}
    try { $pdo->exec("ALTER TABLE eleves ADD COLUMN ecole_origine_id INTEGER DEFAULT NULL AFTER ecole_origine"); } catch (Exception $e) {}
    try { $pdo->exec("ALTER TABLE eleves ADD COLUMN classe_id INTEGER DEFAULT NULL AFTER classe"); } catch (Exception $e) {}
    if ($isMySQL) {
        try { $pdo->exec("ALTER TABLE eleves ADD FOREIGN KEY (etablissement_id) REFERENCES etablissements(id) ON DELETE SET NULL"); } catch (Exception $e) {}
        try { $pdo->exec("ALTER TABLE adultes ADD FOREIGN KEY (etablissement_id) REFERENCES etablissements(id) ON DELETE SET NULL"); } catch (Exception $e) {}
        try { $pdo->exec("ALTER TABLE eleves ADD FOREIGN KEY (ecole_origine_id) REFERENCES etablissements(id) ON DELETE SET NULL"); } catch (Exception $e) {}
        try { $pdo->exec("ALTER TABLE eleves ADD FOREIGN KEY (classe_id) REFERENCES classes(id) ON DELETE SET NULL"); } catch (Exception $e) {}
    }

    // Données initiales
    $ignore = $isMySQL ? 'INSERT IGNORE' : 'INSERT OR IGNORE';
    $pdo->exec("$ignore INTO parametres (cle, valeur) VALUES
        ('couleurs_types', '{\"ULIS\":\"#bbdefb\",\"INCLUSION\":\"#c8e6c9\",\"DECLOISONNEMENT\":\"#fff9c4\",\"PEC\":\"#ffccbc\",\"RECREATION\":\"#ffe0b2\",\"PAUSE MIDI\":\"#d7ccc8\",\"AUTRE\":\"#e0e0e0\"}'),
        ('theme', '\"clair\"'),
        ('horaires', '{\"debut\":\"08:30\",\"fin\":\"16:30\",\"duree_creneau\":15}'),
        ('jours_affiches', '[\"lundi\",\"mardi\",\"jeudi\",\"vendredi\"]'),
        ('zones_enseignement', '{\"academie\":\"\",\"departement\":\"\",\"ville\":\"\"}'),
        ('notre_etablissement_id', 'null')
    ");

    jsonResponse(['ok' => true, 'message' => 'Tables créées (mode ' . ($isMySQL ? 'MySQL' : 'SQLite') . ')']);
} catch (Exception $e) {
    jsonError('Erreur setup : ' . $e->getMessage(), 500);
}
