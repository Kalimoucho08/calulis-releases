-- Migration 006 : rattrapage table classe_enseignants
-- (table de liaison classes <-> enseignants, many-to-many + jours)
-- Contexte : la migration 003 (livree en 1.0.8) etait dans un patch a migrations vide
-- et n'a donc pas ete executee sur certaines installs (bases demo/vierge et bases perso)
-- La table manque -> onglet Classes en erreur 500 (table introuvable)
-- Idempotent : CREATE TABLE IF NOT EXISTS (no-op si la table existe deja)
-- NB : on ne re-migre PAS les donnees (classes.enseignant_id -> classe_enseignants) ici
-- pour ne pas dupliquer si 003 a deja tourne (la migration 003 s en charge si elle est en attente)

CREATE TABLE IF NOT EXISTS classe_enseignants (
  id INT NOT NULL AUTO_INCREMENT,
  classe_id INT NOT NULL,
  adulte_id INT NOT NULL,
  jours TEXT,
  plage VARCHAR(20) DEFAULT 'journee',
  ordre INT DEFAULT 0,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY classe_id (classe_id),
  KEY adulte_id (adulte_id),
  CONSTRAINT ce_classe_fk FOREIGN KEY (classe_id) REFERENCES classes(id) ON DELETE CASCADE,
  CONSTRAINT ce_adulte_fk FOREIGN KEY (adulte_id) REFERENCES adultes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
