-- Migration 005 : groupes multiples par élève (plusieurs noms libres, ex. « Lecture 1 », « Math 2 »)
-- Idempotent : s'applique sur les nouvelles installs et les existantes lors de la MàJ.
CREATE TABLE IF NOT EXISTS eleve_groupes (
  id INT NOT NULL AUTO_INCREMENT,
  eleve_id INT NOT NULL,
  annee_scolaire_id INT DEFAULT NULL,
  nom VARCHAR(100) NOT NULL,
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY eg_eleve_idx (eleve_id),
  KEY eg_annee_idx (annee_scolaire_id),
  CONSTRAINT eg_eleve_fk FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE CASCADE,
  CONSTRAINT eg_annee_fk FOREIGN KEY (annee_scolaire_id) REFERENCES annees_scolaires(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
