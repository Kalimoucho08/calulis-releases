-- Migration 004 : table des groupes d'élèves enregistrés (Lot 1 « Listes & fiches »)
-- Idempotent : s'applique sur les nouvelles installs et sur les existantes lors de la MàJ.
CREATE TABLE IF NOT EXISTS groupes (
  id INT NOT NULL AUTO_INCREMENT,
  nom VARCHAR(200) NOT NULL,
  criteres LONGTEXT COMMENT 'JSON: criteres de filtrage du groupe',
  eleves_ids LONGTEXT COMMENT 'JSON: liste des id eleves du groupe',
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
