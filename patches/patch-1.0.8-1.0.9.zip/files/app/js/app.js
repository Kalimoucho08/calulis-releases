/**
 * Calulis — Point d'entrée
 */
const App = {

    async init() {
        // Buffer d'erreurs pour le bug report
        this._initErrorBuffer();

        // Composants de base
        Modal.init();
        Sidebar.init();
        Router.init();

        // Vérification backend
        this.updateDBStatus();

        // Multi-année : charger année active
        await State.initAnneeScolaire();

        // Topbar
        this.initTopbar();
        this.initAnneeSelector();
        this.updateDate();

        // Recherche globale
        this.initGlobalSearch();

        // Détection hors-ligne
        this.initOfflineDetection();

        // Raccourcis clavier
        this.bindKeyboard();

        // Routage : charger le composant quand la vue change
        const loadView = async (name) => {
            if (name === 'dashboard') await Dashboard.render().catch(e => console.error('[App] Dashboard.render failed:', e));
            if (name === 'eleves') await ElevesList.render().catch(e => console.error('[App] ElevesList.render failed:', e));
            if (name === 'adultes') await AdultesList.render().catch(e => console.error('[App] AdultesList.render failed:', e));
            if (name === 'agenda') await Agenda.render().catch(e => console.error('[App] Agenda.render failed:', e));
            if (name === 'evenements') await EvenementsView.render().catch(e => console.error('[App] EvenementsView.render failed:', e));
            if (name === 'reunions') await ReunionsList.render().catch(e => console.error('[App] ReunionsList.render failed:', e));
            if (name === 'etablissements') await EtablissementsList.render().catch(e => console.error('[App] EtablissementsList.render failed:', e));
            if (name === 'classes') await ClassesView.render().catch(e => console.error('[App] ClassesView.render failed:', e));
            if (name === 'annuaire') {
                const searchTerm = State.get('global-search-term');
                if (searchTerm) State.set('global-search-term', null);
                await Annuaire.render({ search: searchTerm || '' }).catch(e => console.error('[App] Annuaire.render failed:', e));
            }
            if (name === 'params') await ParamsView.render().catch(e => console.error('[App] ParamsView.render failed:', e));
            if (name === 'print') await Print.render().catch(e => console.error('[App] Print.render:', e));
    if (name === 'listes') await Listes.render().catch(e => console.error('[App] Listes.render:', e));
            if (name === 'don') await Don.render().catch(e => console.error('[App] Don.render:', e));
            if (name === 'stats') await StatsView.render().catch(e => console.error('[App] StatsView.render:', e));
            if (name === 'aide') AideView.render().catch(e => console.error('[App] AideView.render:', e));
            if (name === 'mentions-rgpd') { try { MentionsRGPD.render(); } catch(e) { console.error('[App] MentionsRGPD.render:', e); } }
            // Rafraîchir les badges d'aide après le rendu
            setTimeout(() => HelpBubble.refresh(), 100);
        };
        // Re-render agenda quand les params changent
        State.on('params:changed', () => {
            if (Router.current === 'agenda') Agenda.render().catch(() => {});
        });
        State.on('currentView:changed', (data) => loadView(data.value));
        // Re-render quand l'année change
        State.on('annee_scolaire_id:changed', () => {
            this.updateAnneeSelector();
            loadView(Router.current);
        });
        State.on('toutes_periodes:changed', () => {
            loadView(Router.current);
        });
        // Charger la vue initiale
        loadView(Router.current);

        // Marquer prêt
        console.log('Calulis — multi-année — Prêt');
    },

    initAnneeSelector() {
        const select = document.getElementById('select-annee');
        const toggle = document.getElementById('toggle-toutes-periodes');
        if (!select) return;

        // Remplir le select
        this.updateAnneeSelector();

        // Changer d'année
        select.addEventListener('change', () => {
            const val = select.value;
            if (val === '__new__') {
                // Rediriger vers les params pour créer une nouvelle année
                Router.go('params');
                return;
            }
            if (val) {
                State.set('annee_scolaire_id', parseInt(val));
            }
        });

        // Toggle toutes périodes
        if (toggle) {
            toggle.addEventListener('change', () => {
                State.set('toutes_periodes', toggle.checked);
                // Quand toutes périodes est activé, on peut désactiver le filtre année
                if (toggle.checked) {
                    select.disabled = true;
                } else {
                    select.disabled = false;
                }
            });
        }

        // Réagir au chargement des années
        State.on('annees:changed', () => this.updateAnneeSelector());
    },

    updateAnneeSelector() {
        const select = document.getElementById('select-annee');
        if (!select) return;
        const annees = State.get('annees') || [];
        const activeId = State.get('annee_scolaire_id');
        const currentValue = select.value;

        // Sauvegarder la valeur courante pour la restaurer si possible
        select.innerHTML = '';
        if (annees.length === 0) {
            const opt = document.createElement('option');
            opt.value = '';
            opt.textContent = 'Aucune année';
            select.appendChild(opt);
            return;
        }
        annees.forEach(a => {
            const opt = document.createElement('option');
            opt.value = a.id;
            opt.textContent = a.nom + (a.est_active == 1 ? ' ✅' : '');
            if (a.id == activeId) opt.selected = true;
            select.appendChild(opt);
        });
        // Option "Nouvelle année"
        const optNew = document.createElement('option');
        optNew.value = '__new__';
        optNew.textContent = '➕ Nouvelle année…';
        select.appendChild(optNew);

        // Restaurer la valeur si elle était déjà sélectionnée
        if (currentValue && currentValue !== '__new__') {
            select.value = currentValue;
        }
    },

    /** Buffer d'erreurs circulaire pour le bug report */
    _initErrorBuffer() {
        window._calulisErrors = [];
        const origError = console.error;
        console.error = function(...args) {
            window._calulisErrors.push({
                ts: new Date().toISOString(),
                msg: args.map(a => typeof a === 'object' ? (a?.message || JSON.stringify(a)) : String(a)).join(' ')
            });
            if (window._calulisErrors.length > 20) window._calulisErrors.shift();
            origError.apply(console, args);
        };
        window.onerror = (msg, source, line, col, err) => {
            window._calulisErrors.push({
                ts: new Date().toISOString(),
                msg: `[uncaught] ${msg} (${source}:${line}:${col})` + (err?.stack ? '\n' + err.stack : '')
            });
            if (window._calulisErrors.length > 20) window._calulisErrors.shift();
        };
    },

    initTopbar() {
        // Aide contextuelle
        const btnHelp = document.getElementById('btn-help');
        btnHelp.addEventListener('click', () => {
            HelpBubble.toggle();
            btnHelp.classList.toggle('active', HelpBubble._active);
        });
        if (State.get('help-mode')) { HelpBubble._active = true; btnHelp.classList.add('active'); }

        // Thème
        const btnTheme = document.getElementById('btn-theme');
        btnTheme.addEventListener('click', () => {
            document.body.classList.toggle('dark');
            const isDark = document.body.classList.contains('dark');
            btnTheme.textContent = isDark ? '☀️' : '🌙';
            State.set('theme', isDark ? 'dark' : 'light');
            try { localStorage.setItem('calulis_theme', isDark ? 'dark' : 'light'); } catch {}
        });
        // Restaurer le thème
        const savedTheme = State.get('theme') || (() => { try { return localStorage.getItem('calulis_theme'); } catch { return null; } })();
        if (savedTheme === 'dark') {
            document.body.classList.add('dark');
            btnTheme.textContent = '☀️';
            State.set('theme', 'dark');
        }

        // Mode consultation
        const btnConsult = document.getElementById('btn-consultation');
        btnConsult.addEventListener('click', () => {
            const isLocked = !State.get('consultation');
            State.set('consultation', isLocked);
            btnConsult.textContent = isLocked ? '🔒' : '🔓';
            document.getElementById('status-context').textContent = isLocked ? '🔒 Consultation' : '';
            // Re-render la vue courante pour appliquer/bloquer les interactions
            loadView(Router.current);
        });

        // Bug report
        const btnBug = document.getElementById('btn-bug');
        if (btnBug) {
            btnBug.addEventListener('click', () => BugReport.open());
        }
    },

    initOfflineDetection() {
        const app = this;
        const showBanner = (online) => {
            let banner = document.getElementById('offline-banner');
            if (online) {
                if (banner) banner.remove();
                app.updateDBStatus();
                return;
            }
            if (!banner) {
                banner = document.createElement('div');
                banner.id = 'offline-banner';
                banner.className = 'offline-banner';
                banner.textContent = '📡 Mode hors-ligne — Impossible de contacter le serveur.';
                document.body.prepend(banner);
            }
        };
        window.addEventListener('online', () => showBanner(true));
        window.addEventListener('offline', () => showBanner(false));
    },

    initGlobalSearch() {
        const input = document.getElementById('global-search');
        if (!input) return;
        input.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' && input.value.trim()) {
                const q = input.value.trim();
                if (Router.current === 'annuaire') {
                    Annuaire.render({ search: q }).catch(() => {});
                } else {
                    State.set('global-search-term', q);
                    Router.go('annuaire');
                }
            }
        });
    },

    updateDate() {
        const now = new Date();
        const options = { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' };
        const el = document.getElementById('topbar-date');
        el.textContent = now.toLocaleDateString('fr-FR', options);
        el.title = 'Aller à l\'agenda du jour';
        el.addEventListener('click', () => {
            State.set('agenda-goto-today', true);
            // Forcer le re-render même si déjà sur l'agenda
            if (Router.current === 'agenda') {
                Agenda.render().catch(() => {});
            } else {
                Router.go('agenda');
            }
        });
    },

    async updateDBStatus() {
        const dot = document.querySelector('#status-db .status-dot');
        const label = document.querySelector('#status-db span:last-child');
        if (!dot || !label) return;
        const ok = await API.health();
        dot.className = ok ? 'status-dot ok' : 'status-dot disconnected';
        label.textContent = ok ? 'MySQL' : 'Offline';
    },

    bindKeyboard() {
        document.addEventListener('keydown', (e) => {
            // Ignorer si on est dans un input (sauf global-search)
            if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA' || e.target.tagName === 'SELECT') {
                if (e.target.id === 'global-search' && e.key === 'Escape') { e.target.blur(); }
                return;
            }
            // Undo/Redo désactivé — pas encore implémenté pour les opérations CRUD
            // if (e.ctrlKey && e.key === 'z') { e.preventDefault(); State.undo(); }
            // if (e.ctrlKey && e.key === 'y') { e.preventDefault(); State.redo(); }
            // Navigation Alt+1-5
            if (e.altKey && e.key >= '1' && e.key <= '5') {
                e.preventDefault();
                const views = ['dashboard', 'eleves', 'agenda', 'reunions', 'params'];
                Router.go(views[parseInt(e.key) - 1]);
            }
            // Ctrl+F → global search
            if (e.ctrlKey && e.key === 'f') {
                e.preventDefault();
                const input = document.getElementById('global-search');
                if (input) input.focus();
            }
            // ? → aide
            if (e.key === '?') {
                e.preventDefault();
                HelpBubble.toggle();
            }
        });

        // Undo/Redo désactivé — pas encore implémenté pour les opérations CRUD
        // State.on('history:changed', ({ canUndo, canRedo }) => {
        //     document.getElementById('btn-undo').disabled = !canUndo;
        //     document.getElementById('btn-redo').disabled = !canRedo;
        // });
    },

};

document.addEventListener('DOMContentLoaded', () => App.init());