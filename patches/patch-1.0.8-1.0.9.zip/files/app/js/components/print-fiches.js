
/**
 * Calulis — Lot 1 : Fiches de renseignements / urgence (onglet « Fiches » du module Impression)
 * Greffé sur l'objet Print. Génère un PDF A4 portrait par élève (ou en lot, une fiche par page).
 */
Object.assign(Print, {

  _buildFichesCard() {
    const elevesOpts = (this._eleves || []).map(e => '<option value="' + e.id + '">' + escapeHtml((e.prenom||'') + ' ' + (e.nom||'')) + (e.classe_nom ? ' (' + escapeHtml(e.classe_nom) + ')' : '') + '</option>').join('');
    return '' +
      '<h3 style="margin:0 0 6px 0">1. Type de fiche</h3>' +
      '<div class="export-cards">' +
        '<label class="export-card active"><input type="radio" name="print-fiche-type" value="urgence" class="export-card-radio" hidden checked><span class="export-card-icon">🚑</span><span class="export-card-label">Fiche urgence</span><span class="export-card-desc">Médical + représentants + transport</span></label>' +
        '<label class="export-card"><input type="radio" name="print-fiche-type" value="renseignement" class="export-card-radio" hidden><span class="export-card-icon">📝</span><span class="export-card-label">Fiche renseignements</span><span class="export-card-desc">Identité + scolarité + contacts</span></label>' +
      '</div>' +
      '<div class="form-group" style="margin-top:10px"><label>Élève(s)</label>' +
        '<div style="display:flex;gap:4px;margin-bottom:4px"><button type="button" class="btn btn-sm btn-secondary" data-select="print-fiche-eleves" data-action="all">Tout</button><button type="button" class="btn btn-sm btn-secondary" data-select="print-fiche-eleves" data-action="none">Aucun</button></div>' +
        '<select id="print-fiche-eleves" style="width:100%" multiple size="7">' + elevesOpts + '</select>' +
      '</div>' +
      '<p class="text-muted small" style="margin:8px 0 0 0">🔒 Document confidentiel : données de vie scolaire uniquement (pas de diagnostic). À détruire en fin d&#39;année scolaire.</p>';
  },

  async _generateFiches() {
    const type = (document.querySelector('input[name="print-fiche-type"]:checked') || {}).value || 'urgence';
    const sel = document.getElementById('print-fiche-eleves');
    if (!sel) return;
    const ids = Array.from(sel.selectedOptions).map(o => parseInt(o.value));
    if (!ids.length) { Modal.alert('Erreur', 'Sélectionnez au moins un élève.'); return; }

    const btn = document.getElementById('btn-print-generate');
    btn.disabled = true; btn.textContent = '⏳ Génération…';
    try {
      const eleves = await API.get('listes.php?ids=' + ids.join(','));
      const ordered = ids.map(id => (eleves || []).find(e => e.id === id)).filter(Boolean);
      if (!ordered.length) { Modal.alert('Erreur', 'Aucun élève trouvé.'); return; }
      const def = this._buildFichesDoc(type, ordered);
      const fname = 'fiches_' + type + '_' + new Date().toISOString().slice(0,10) + '.pdf';
      if (def) this._showPreview(def, fname);
    } finally {
      btn.disabled = false; btn.textContent = '🖨️ Générer l\'aperçu';
    }
  },

  _buildFichesDoc(type, eleves) {
    const content = [];
    eleves.forEach((e, i) => {
      if (i > 0) content.push({ text: '', pageBreak: 'before' });
      content.push(type === 'urgence' ? this._buildFicheUrgence(e) : this._buildFicheRenseignement(e));
    });
    return {
      pageSize: 'A4', pageMargins: [18, 18, 18, 18],
      content,
      defaultStyle: { fontSize: 9 },
      styles: {
        header: { fontSize: 15, bold: true, alignment: 'center' },
        name: { fontSize: 12, bold: true, alignment: 'center', margin: [0, 2, 0, 6] },
        muted: { fontSize: 8, italics: true, color: '#777', alignment: 'center', margin: [0, 0, 0, 8] },
        sectionTitle: { fontSize: 10, bold: true, margin: [0, 10, 0, 3], color: '#2c3e50' },
        kvLabel: { fontSize: 9, bold: true, color: '#555' },
        kvValue: { fontSize: 9 },
        th: { fontSize: 8, bold: true, fillColor: '#eee', alignment: 'center' },
      },
    };
  },

  _kv(label, value) {
    return { columns: [ { text: label, style: 'kvLabel', width: 110 }, { text: value || '—', style: 'kvValue', width: '*' } ], margin: [0, 1, 0, 1] };
  },

  _repsFor(e) {
    const reps = e.representants || [];
    if (!reps.length) return { text: 'Aucun représentant renseigné.', style: 'muted', alignment: 'left' };
    const body = [[
      { text: 'Nom', style: 'th' }, { text: 'Lien', style: 'th' }, { text: 'Téléphone', style: 'th' }, { text: 'Urgence', style: 'th' },
    ]];
    reps.forEach(r => body.push([
      { text: (r.prenom ? r.prenom + ' ' : '') + (r.nom || '') },
      { text: r.lien || '' },
      { text: (r.telephone && r.telephone !== '0') ? r.telephone : '' },
      { text: (r.telephone_urgence && r.telephone_urgence !== '0') ? '☎' : '' },
    ]));
    return { table: { headerRows: 1, widths: [90, 60, 80, 40], body }, fontSize: 8 };
  },

  _droitText(d) {
    const m = { autorise: 'Autorisé', refuse: 'Refusé', limite: 'Limité', en_attente: 'En attente', retire: 'Retiré' };
    return d ? (m[d.statut] || d.statut) : 'Non renseigné';
  },

  _buildFicheUrgence(e) {
    return {
      stack: [
        { text: 'FICHE D\'URGENCE', style: 'header' },
        { text: (e.nom || '') + ' ' + (e.prenom || ''), style: 'name' },
        { text: 'Document confidentiel — précautions pour la vie scolaire uniquement. À détruire en fin d\'année.', style: 'muted' },
        this._kv('Classe', e.classe_nom || e.classe),
        this._kv('Naissance', formatDate(e.date_naissance)),
        this._kv('Groupe', e.groupe),
        { text: 'Représentants légaux', style: 'sectionTitle' },
        this._repsFor(e),
        { text: 'Santé & vie scolaire', style: 'sectionTitle' },
        this._kv('Allergies', e.allergies),
        this._kv('Régime alimentaire', e.regime_alimentaire),
        this._kv('PAI', e.pai ? 'Oui' : 'Non'),
        this._kv('Précautions', e.precautions_medicales),
        this._kv('Transport', e.transport),
        this._kv('Cantine', e.cantine ? 'Oui' : 'Non'),
        this._kv('Droit à l\'image', this._droitText(e.droit_image)),
      ],
      unbreakable: true,
    };
  },

  _buildFicheRenseignement(e) {
    const reps = e.representants || [];
    const repEmail = reps.map(r => r.email).filter(Boolean).join(', ');
    return {
      stack: [
        { text: 'FICHE DE RENSEIGNEMENTS', style: 'header' },
        { text: (e.nom || '') + ' ' + (e.prenom || ''), style: 'name' },
        { text: 'Année scolaire en cours — à compléter et signer par la famille.', style: 'muted' },
        { text: 'Identité', style: 'sectionTitle' },
        this._kv('Nom', e.nom), this._kv('Prénom', e.prenom),
        this._kv('Date de naissance', formatDate(e.date_naissance)),
        this._kv('Numéro INE', e.ine), this._kv('N° dossier MDPH', e.numero_dossier_mdph),
        { text: 'Scolarité', style: 'sectionTitle' },
        this._kv('Classe', e.classe_nom || e.classe), this._kv('Établissement', e.etablissement_nom),
        this._kv('ULIS', e.ulis ? 'Oui' : 'Non'), this._kv('Groupe', e.groupe),
        { text: 'Représentants légaux', style: 'sectionTitle' },
        this._repsFor(e),
        this._kv('Email (représentants)', repEmail),
        this._kv('Adresse', e.adresse),
        { text: 'Divers', style: 'sectionTitle' },
        this._kv('Droit à l\'image', this._droitText(e.droit_image)),
      ],
      unbreakable: true,
    };
  },
});