/**
 * Calulis — Agenda Grid : rendu CSS grid + rebuild
 * Ajouté à Agenda via Object.assign
 */

Object.assign(Agenda, {

    /* ─── Rendu principal ─── */

    _buildGrid(heures, jours, couleurs, _unused) {
        this._heures = heures;
        this._filteredEleves = this._getFilteredEleves();

        if (this._viewMode === 'adultes') {
            this._buildAdultGrid(heures, jours, couleurs);
        } else {
            this._buildEleveGrid(heures, jours, couleurs);
        }
    },

    _buildEleveGrid(heures, jours, couleurs) {
        const container = document.getElementById('agenda-grid-css');
        const jour = this._currentDay;
        const dureePas = this._params?.horaires?.duree_creneau || 15;
        const eleves = this._filteredEleves;
        const nEleves = eleves.length;

        container.style.gridTemplateColumns = `55px repeat(${nEleves}, 1fr)`;
        container.style.setProperty('--agenda-cols', nEleves);

        const creneauxByEleve = {};
        eleves.forEach(e => {
            creneauxByEleve[e.id] = this._creneaux.filter(c => c.eleve_id === e.id && c.jour === jour);
        });

        const slotCovered = new Set();
        let html = '';

        // Ligne d'en-tête
        html += '<div class="agenda-header-row">';
        html += '<div class="agenda-gh-hour">Heure</div>';
        eleves.forEach(e => {
            html += `<div class="agenda-gh-cell" data-eleve="${e.id}" draggable="true">${e.numero ? e.numero + '. ' : ''}${escapeHtml(e.prenom)}<span class="nom">${escapeHtml(e.nom)}</span></div>`;
        });
        html += '</div>';

        // Lignes de données
        for (let hIdx = 0; hIdx < heures.length; hIdx++) {
            html += '<div class="agenda-row">';
            html += `<div class="agenda-hour-cell" data-heure="${heures[hIdx]}">${formatHeure(heures[hIdx])}</div>`;

            eleves.forEach((eleve, eIdx) => {
                if (slotCovered.has(hIdx + '_' + eIdx)) return;

                const c = (creneauxByEleve[eleve.id] || []).find(cc => cc.heure_debut === heures[hIdx]);

                if (c) {
                    let rowSpan = Math.max(1, Math.floor((c.duree || dureePas) / dureePas));
                    for (let j = hIdx + 1; j < heures.length && j < hIdx + rowSpan + 5; j++) {
                        const next = creneauxByEleve[eleve.id]?.find(cc => cc.heure_debut === heures[j]);
                        if (next && next.matiere === c.matiere && next.groupe === c.groupe &&
                            next.adulte === c.adulte && next.regroupement_type === c.regroupement_type) {
                            rowSpan = Math.max(rowSpan, j - hIdx + 1);
                        } else if (j < hIdx + rowSpan) {
                            rowSpan = Math.max(rowSpan, j - hIdx + 1);
                        } else break;
                    }
                    for (let s = 1; s < rowSpan; s++) slotCovered.add((hIdx + s) + '_' + eIdx);

                    const color = c.couleur_override || couleurs[c.regroupement_type] || '#e0e0e0';
                    const slotClass = 'agenda-slot';
                    html += `<div class="${slotClass}" style="grid-row:span ${rowSpan};background:${color};color:#000"
                        data-id="${c.id || ''}" data-eleve="${eleve.id}" data-heure="${heures[hIdx]}" data-jour="${jour}"
                        title="${escapeHtml(c.matiere || '')}${c.adulte ? ' - ' + escapeHtml(c.adulte) : ''}">
                        <strong>${escapeHtml(c.matiere || '')}</strong>
                        ${c.adulte ? `<small>${escapeHtml(c.adulte)}</small>` : ''}
                        ${c.groupe ? `<small>${escapeHtml(c.groupe)}</small>` : ''}
                    </div>`;
                } else {
                    html += `<div class="agenda-slot-empty"
                        data-eleve="${eleve.id}" data-heure="${heures[hIdx]}" data-jour="${jour}"></div>`;
                }
            });

            html += '</div>';
        }

        container.innerHTML = html;
    },

    _buildAdultGrid(heures, jours, couleurs) {
        const container = document.getElementById('agenda-grid-css');
        const jour = this._currentDay;
        const dureePas = this._params?.horaires?.duree_creneau || 15;
        const adultes = this._extractAdultes();
        const nAdultes = adultes.length;

        if (nAdultes === 0) {
            container.innerHTML = '<p style="padding:32px;text-align:center;color:var(--text-muted);grid-column:1/-1">Aucun adulte référencé dans les créneaux.</p>';
            return;
        }

        container.style.gridTemplateColumns = `55px repeat(${nAdultes}, 1fr)`;
        container.style.setProperty('--agenda-cols', nAdultes);

        const adultCreneaux = {};
        const adultePrefixMap = {};
        adultes.forEach(a => { adultePrefixMap[a.name] = a.name; });
        this._creneaux.forEach(c => {
            if (!c.adulte || !c.adulte.trim() || c.jour !== jour) return;
            let matchedName = c.adulte.trim();
            for (const a of adultes) {
                if (c.adulte.trim().endsWith(a.name)) {
                    matchedName = a.name;
                    if (!adultePrefixMap[a.name] || adultePrefixMap[a.name] === a.name) {
                        adultePrefixMap[a.name] = c.adulte.trim();
                    }
                    break;
                }
            }
            const key = matchedName + '|' + c.heure_debut;
            if (!adultCreneaux[key]) adultCreneaux[key] = [];
            adultCreneaux[key].push(c);
        });

        const eleveMap = {};
        this._eleves.forEach(e => { eleveMap[e.id] = e; });

        const slotCovered = new Set();
        let html = '';

        html += '<div class="agenda-header-row">';
        html += '<div class="agenda-gh-hour">Heure</div>';
        adultes.forEach(a => {
            const roleLabel = a.role ? (roleLabels[a.role] || a.role) : '';
            html += `<div class="agenda-gh-cell" data-adulte-id="${a.id}" draggable="true">${escapeHtml(a.name)}${roleLabel ? `<span class="nom">${escapeHtml(roleLabel)}</span>` : ''}</div>`;
        });
        html += '</div>';

        for (let hIdx = 0; hIdx < heures.length; hIdx++) {
            html += '<div class="agenda-row">';
            html += `<div class="agenda-hour-cell" data-heure="${heures[hIdx]}">${formatHeure(heures[hIdx])}</div>`;

            adultes.forEach((adulte, aIdx) => {
                if (slotCovered.has(hIdx + '_' + aIdx)) return;

                const key = adulte.name + '|' + heures[hIdx];
                const creneauxList = adultCreneaux[key] || [];

                if (creneauxList.length > 0) {
                    const c = creneauxList[0];
                    let rowSpan = Math.max(1, Math.floor((c.duree || dureePas) / dureePas));
                    for (let s = 1; s < rowSpan; s++) slotCovered.add((hIdx + s) + '_' + aIdx);

                    const color = c.couleur_override || couleurs[c.regroupement_type] || '#e0e0e0';
                    const elevesNoms = creneauxList.map(cc => {
                        const e = eleveMap[cc.eleve_id];
                        return e ? (e.prenom || e.nom) : '?';
                    }).join(', ');

                    html += `<div class="agenda-slot" style="grid-row:span ${rowSpan};background:${color};color:#000"
                        data-adulte="${escapeHtml(adultePrefixMap[adulte.name] || adulte.name)}" data-heure="${heures[hIdx]}" data-jour="${jour}">
                        <strong>${elevesNoms}</strong>
                        ${creneauxList[0].matiere ? `<small>${escapeHtml(creneauxList[0].matiere)}</small>` : ''}
                    </div>`;
                } else {
                    html += `<div class="agenda-slot-empty" data-adulte="${escapeHtml(adultePrefixMap[adulte.name] || adulte.name)}" data-heure="${heures[hIdx]}" data-jour="${jour}"></div>`;
                }
            });

            html += '</div>';
        }

        container.innerHTML = html;
    },

    _rebuildGrid() {
        const horaires = this._params?.horaires || { debut: '08:30', fin: '16:30', duree_creneau: 15 };
        const couleurs = { ...COULEURS_TYPES_DEFAUT, ...(this._params?.couleurs_types || {}) };
        const jours = this._params?.jours_affiches || ['lundi', 'mardi', 'jeudi', 'vendredi'];
        const { heures } = this._computeGridHeures(horaires);

        this._buildGrid(heures, jours, couleurs, []);
        this._bindGridEvents();
    },

});
