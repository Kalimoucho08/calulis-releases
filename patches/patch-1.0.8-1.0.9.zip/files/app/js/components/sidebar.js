/**
 * Calulis — Sidebar de navigation
 * 8 entrées : Dashboard, Élèves, Agenda, Réunions, Stats, Suivi, Documents, Paramètres
 */
const Sidebar = {
    _items: [
        { id: 'dashboard', icon: '📋', label: 'Tableau de bord', phase: 13, help: 'Tableau de bord|Vue d\'ensemble de votre année scolaire. Vous voyez d\'un coup d\'œil : le nombre d\'élèves et de classes, les prochaines réunions, la semaine en cours dans l\'agenda, et une alerte si des droits MDPH arrivent à expiration. C\'est la page d\'accueil.' },
        { id: 'eleves',    icon: '👥', label: 'Élèves', phase: 2, help: 'Élèves|Liste de tous les élèves suivis en ULIS cette année. En haut, des filtres pour affiner : par niveau (CP, CE1…), par classe précise, ou par statut (ULIS / non ULIS, actif / inactif). Les colonnes Âge et Années ULIS sont calculées automatiquement. Cliquez sur un en-tête pour trier. Les boutons : Fiche = consulter sans pouvoir modifier, Modifier = éditer la fiche, Supprimer = retirer de l\'année en cours.' },
        { id: 'listes',    icon: '📋', label: 'Listes', phase: 14, help: 'Listes|Générez vos listes d\'élèves en un clic : filtrez par niveau, classe, groupe, ULIS, cantine, transport, PAI, allergies, droit à l\'image, cochez vos élèves, choisissez les colonnes et exportez en PDF paysage ou CSV. Vous pouvez enregistrer un groupe (ex. « Sortie piscine ») pour le réutiliser toute l\'année.' },
        { id: 'adultes',   icon: '👩‍🏫', label: 'Adultes', phase: 8, help: 'Adultes|Tous les adultes qui interviennent auprès des élèves : enseignants, AESH, orthophonistes, psychomotriciens, éducateurs… Filtrez par catégorie : 👩‍🏫 enseignants de l\'école, 👥 autre personnel (AESH, directeur), 🌍 intervenants extérieurs (libéraux, SESSAD, ASE). Un adulte peut être rattaché à plusieurs établissements.' },
        { id: 'agenda',    icon: '📅', label: 'Agenda', phase: 3, help: 'Agenda|Le cœur de Calulis : l\'emploi du temps de la semaine. Double-cliquez dans une case vide pour créer un créneau (activité, élèves, adultes). Glissez-déposez pour déplacer un créneau. Ctrl+glisser pour le copier. Clic droit pour couper/copier/coller. La barre du haut permet de changer de semaine (flèches ◀▶), de basculer entre vue Élèves et vue Adultes, et de filtrer par élève, groupe ou intervenant.' },
        { id: 'evenements', icon: '📆', label: 'Événements', phase: 10, help: 'Événements|Calendrier des événements de l\'année scolaire. 60 modèles prédéfinis (jours fériés, vacances, examens, semaines thématiques) que vous activez d\'un simple clic. Le bouton 🎂 génère automatiquement les anniversaires des élèves. Vous pouvez aussi créer vos propres événements (sortie, spectacle, conseil d\'école…). Filtrez par catégorie pour vous y retrouver.' },
        { id: 'reunions',  icon: '🤝', label: 'Réunions', phase: 5, help: 'Réunions|Toutes les réunions liées au dispositif : ESS (Équipe de Suivi de Scolarisation), équipes éducatives, rendez-vous avec les familles, réunions partenariales. Chaque réunion a un type, une date, un statut (prévue, en cours, réalisée, annulée, reportée) et peut être liée à un élève. Filtrez pour retrouver facilement une réunion passée ou à venir.' },
        { id: 'stats',     icon: '📊', label: 'Statistiques', phase: 11, help: 'Statistiques|Temps de présence des élèves par type de regroupement, calculé automatiquement à partir de l\'agenda. Permet de justifier le temps de scolarisation pour les rapports administratifs, de présenter la répartition inclusion/ULIS en ESS, et de piloter votre dispositif. Les données sont exportables en PDF.' },
        { id: 'etablissements', icon: '🏫', label: 'Établissements', phase: 7, help: 'Établissements|Tous les établissements partenaires : votre école (repérée par le badge 🏫 NOTRE ÉCOLE), les autres écoles, les collèges, les structures médico-sociales (CMP, CMPP, SESSAD, IME), l\'Aide Sociale à l\'Enfance… Double-cliquez sur une ligne pour voir la fiche détaillée avec les intervenants rattachés.' },
        { id: 'classes',   icon: '🏷️', label: 'Classes', phase: 8, help: 'Classes|Les classes de votre école. Chaque classe a un nom (ex: CE1), un niveau, un enseignant et un établissement. Les élèves ULIS sont rattachés à leur classe de référence — c\'est une obligation légale. Cela permet de savoir dans quelle classe chaque élève est inscrit administrativement.' },
        { id: 'annuaire',  icon: '📖', label: 'Annuaire', phase: 6, help: 'Annuaire|Annuaire complet et interrogeable. Tapez un nom, un prénom ou un établissement dans la barre de recherche pour trouver instantanément un élève, un adulte ou une structure. Cliquez sur Fiche pour voir tous les détails. Pratique pour retrouver un contact rapidement.' },
        { id: 'documents', icon: '📄', label: 'Documents', phase: 9, help: 'Documents|Espace de stockage des documents importants : GEVASCO, PPS, PAI, bilans orthophoniques, comptes-rendus de réunions, convocations. Centralisez tous les fichiers au même endroit pour les retrouver facilement.' },
        { id: 'aide',      icon: '📖', label: 'Aide', phase: 13, help: 'Aide|Guide complet de Calulis. Vous y trouverez : un pas-à-pas pour démarrer, des explications détaillées sur chaque module, des scénarios concrets (préparer la rentrée, organiser une ESS, vérifier la charge d\'un AESH…), la liste des raccourcis clavier, et des astuces pour gagner du temps au quotidien.' },
        { id: 'mentions-rgpd', icon: '📄', label: 'Mentions RGPD', phase: 99, help: 'Mentions RGPD|Informations légales sur le traitement des données personnelles dans Calulis. Finalités, base légale, durée de conservation, destinataires, droits des personnes, coordonnées du DPD académique. Conformité RGPD et réglementation Éducation nationale.' },
        { id: 'print',     icon: '🖨️', label: 'Impression', phase: 12, help: 'Impression|Exportez les emplois du temps en PDF. Choisissez le type d\'export (semaine complète pour un élève ou un adulte, journée comparative pour plusieurs élèves, statistiques détaillées), sélectionnez l\'élève et la semaine, générez l\'aperçu, puis téléchargez. Idéal pour afficher l\'EDT en classe, le transmettre aux familles, ou le joindre à un dossier.' },
        { id: 'params',    icon: '⚙️', label: 'Paramètres', phase: 4, help: 'Paramètres|Configurez Calulis selon votre école : choisissez les couleurs des types de regroupement, les horaires (début, fin, durée d\'un créneau), les jours travaillés, les APC, et votre établissement principal. Les pauses (récréation, pause du midi) se placent dans l\'agenda avec le bouton « ⏸️ Pause ». Les modifications s\'appliquent immédiatement dans l\'agenda.' },
        { id: 'don',       icon: '❤️', label: 'Soutenir', phase: 0, help: 'Soutenir|Si Calulis vous est utile, vous pouvez soutenir son développement par un don PayPal. Le logiciel reste gratuit et libre.' },
    ],

    init() {
        const nav = document.getElementById('sidebar-nav');
        nav.innerHTML = this._items.map(item => `
            <button class="sidebar-item" data-view="${item.id}" data-help="${item.help || ''}">
                <span class="icon">${item.icon}</span>
                <span class="label">${item.label}</span>
            </button>
        `).join('');

        nav.querySelectorAll('.sidebar-item').forEach(btn => {
            btn.addEventListener('click', () => {
                Router.go(btn.dataset.view);
            });
        });

        // Synchroniser l'état actif avec le routeur
        State.on('currentView:changed', (data) => this._setActive(data.value));
        this._setActive(Router.current);

        // Footer sidebar
        document.getElementById('sidebar-footer').innerHTML = `
            <div style="margin-bottom:4px" id="sidebar-version">Calulis v1</div>
            <div style="display:flex;gap:10px;justify-content:center;font-size:14px">
                <a href="https://discord.gg/YkJ3XgMA" target="_blank" rel="noopener" title="Discord" style="text-decoration:none;opacity:0.7">🎮</a>
                <a href="https://www.facebook.com/profile.php?id=61575316486226" target="_blank" rel="noopener" title="Facebook" style="text-decoration:none;opacity:0.7">📘</a>
            </div>
        `;

        // Version réelle (silencieux si indisponible)
        API.get('version.php').then(v => {
            const el = document.getElementById('sidebar-version');
            if (el && v && v.appVersion) el.textContent = 'Calulis v' + v.appVersion;
        }).catch(() => {});
    },

    _setActive(name) {
        document.querySelectorAll('.sidebar-item').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.view === name);
        });
    },
};