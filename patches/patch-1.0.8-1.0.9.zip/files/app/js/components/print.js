/**
 * Calulis — Phase 12 : Export PDF des emplois du temps
 * Sidebar `#print` — 5 types d'export avec aperçu canvas PDF.js avant téléchargement
 * Utilise pdfmake (MIT) pour générer des PDF A4 + PDF.js pour le rendu d'aperçu
 */
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js';

/** Police minimum pour la lisibilité des tableaux pdfmake */
const MIN_PDF_FONT = 6.5;

/** Styles pdfmake de base partagés par tous les exports */
const BASE_STYLES = {
    header:      { fontSize: 13, bold: true, alignment: 'center', margin: [0, 0, 0, 4] },
    subheader:   { fontSize: 9, alignment: 'center', margin: [0, 0, 0, 8], color: '#666' },
    tableHeader: { fontSize: 7, bold: true, fillColor: '#eee', alignment: 'center' },
    hourCell:    { fontSize: 6.5, bold: true, alignment: 'center', fillColor: '#fafafa' },
    slotCell:    { fontSize: MIN_PDF_FONT, alignment: 'center', margin: [1, 1] },
    midiPause:   { fontSize: 7, bold: true, alignment: 'center', margin: [1, 2] },
    legendTitle: { fontSize: 8, bold: true },
};

const Print = {
    _eleves: [],
    _adultes: [],
    _semaines: [],
    _params: null,
    _loading: false,
    _pendingDef: null,
    _pendingFilename: null,
    _pdfDoc: null,
    _currentPage: 1,
    _currentTab: 'edt',
    _zoom: 1,
    _zoomStep: 0.25,

    async render() {
        const view = document.getElementById('view-print');
        view.innerHTML = '<div class="placeholder-view"><div class="placeholder-icon">⏳</div><div class="placeholder-title">Chargement…</div></div>';
        await this._loadData();
        view.innerHTML = this._buildHTML();
        this._bindEvents();
    },

    async _loadData() {
        this._loading = true;
        try {
            const [eleves, adultes, semaines, paramsRaw, classes] = await Promise.all([
                API.get('eleves.php'),
                API.get('adultes.php'),
                API.get('semaines.php'),
                API.get('params.php'),
                API.get('classes.php'),
            ]);
            this._eleves = (eleves || []).filter(e => e.actif);
            this._adultes = adultes || [];
            this._semaines = semaines || [];
            this._classes = classes || [];
            const params = {};
            (paramsRaw || []).forEach(p => {
                try { params[p.cle] = JSON.parse(p.valeur); } catch { params[p.cle] = p.valeur; }
            });
            this._params = params;
        } catch (e) {
            console.error('[Print] load error:', e);
            if (typeof Modal !== 'undefined' && Modal.alert) {
                Modal.alert('Erreur de chargement', 'Impossible de charger les données. Vérifiez votre connexion au serveur.');
            }
        }
        this._loading = false;
    },

    _buildHTML() {
        const jours = this._params?.jours_affiches || ['lundi','mardi','mercredi','jeudi','vendredi','samedi'];
        const semaines = this._semaines.filter(s => !s.est_vacances);
        const today = new Date();
        const currentSemaine = semaines.find(s => s.date_debut <= today.toISOString().slice(0,10) && s.date_fin >= today.toISOString().slice(0,10));
        const jourOpts = jours.map(j => `<option value="${j}">${j.charAt(0).toUpperCase() + j.slice(1)}</option>`).join('');

        const types = [
            { value: 'semaine-eleve', icon: '👤', label: 'Semaine · Élève', desc: 'A4 portrait · grille complète' },
            { value: 'semaine-adulte', icon: '👩‍🏫', label: 'Semaine · Adulte', desc: 'A4 portrait · élèves dans les cellules' },
            { value: 'jour-eleves', icon: '👥', label: 'Jour · Élève(s)', desc: 'A4 paysage · vue comparative' },
            { value: 'jour-adultes', icon: '🔄', label: 'Jour · Adulte(s)', desc: 'A4 portrait/paysage · 1 ou plusieurs' },
        ];

        const tabs = [
            { id: 'edt', icon: '📅', label: 'Emplois du temps' },
            { id: 'stats', icon: '📊', label: 'Statistiques' },
            { id: 'fiches', icon: '📋', label: 'Fiches' },
            { id: 'docs', icon: '📄', label: 'Documents' },
        ];

        const semaineTypes = types.filter(t => t.value.startsWith('semaine-'));
        const jourTypes = types.filter(t => t.value.startsWith('jour-'));

        return `
        <div class="print-header">
            <div class="print-tabs">
                ${tabs.map(t => `
                <button class="print-tab${t.id === this._currentTab ? ' active' : ''}" data-tab="${t.id}">
                    ${t.icon} ${t.label}
                </button>`).join('')}
            </div>
            <span class="text-muted" style="font-size:12px;white-space:nowrap">${this._eleves.length} élèves · ${this._adultes.length} adultes</span>
        </div>
        <div class="print-layout">
            <div class="print-options-panel">
                <div class="card" id="print-card-edt">
                    <h3 style="margin:0 0 6px 0">1. Type d'export</h3>
                    <p class="text-muted small" style="margin:0 0 12px 0">Choisissez ce que vous voulez exporter</p>
                    <div class="export-group-label">📅 Semaine</div>
                    <div class="export-cards">
                        ${semaineTypes.map(t => `
                        <label class="export-card${t.value === 'semaine-eleve' ? ' active' : ''}">
                            <input type="radio" name="print-type" value="${t.value}"${t.value === 'semaine-eleve' ? ' checked' : ''} class="export-card-radio" hidden>
                            <span class="export-card-icon">${t.icon}</span>
                            <span class="export-card-label">${t.label}</span>
                            <span class="export-card-desc">${t.desc}</span>
                        </label>`).join('')}
                    </div>
                    <div class="export-group-label" style="margin-top:10px">📅 Jour</div>
                    <div class="export-cards">
                        ${jourTypes.map(t => `
                        <label class="export-card">
                            <input type="radio" name="print-type" value="${t.value}" class="export-card-radio" hidden>
                            <span class="export-card-icon">${t.icon}</span>
                            <span class="export-card-label">${t.label}</span>
                            <span class="export-card-desc">${t.desc}</span>
                        </label>`).join('')}
                    </div>
                </div>
                <div class="card" id="print-card-stats" style="display:none">
                    <h3 style="margin:0 0 6px 0">1. Type d'export</h3>
                    <p class="text-muted small" style="margin:0 0 12px 0">Export de tableaux de bord et statistiques</p>
                    <div class="export-cards">
                        <label class="export-card active">
                            <input type="radio" name="print-stats-type" value="stats-dashboard" class="export-card-radio" hidden checked>
                            <span class="export-card-icon">📊</span>
                            <span class="export-card-label">Tableau de bord</span>
                            <span class="export-card-desc">A4 portrait · KPI + résumés</span>
                        </label>
                        <label class="export-card">
                            <input type="radio" name="print-stats-type" value="stats-inclusion" class="export-card-radio" hidden>
                            <span class="export-card-icon">📈</span>
                            <span class="export-card-label">Inclusion détaillée</span>
                            <span class="export-card-desc">A4 paysage · heures par élève</span>
                        </label>
                        <label class="export-card">
                            <input type="radio" name="print-stats-type" value="stats-evolution" class="export-card-radio" hidden>
                            <span class="export-card-icon">📉</span>
                            <span class="export-card-label">Évolution multi-année</span>
                            <span class="export-card-desc">A4 paysage · historique</span>
                        </label>
                        <label class="export-card">
                            <input type="radio" name="print-stats-type" value="stats-periodes" class="export-card-radio" hidden>
                            <span class="export-card-icon">📆</span>
                            <span class="export-card-label">Inclusion par période</span>
                            <span class="export-card-desc">A4 paysage · trimestres</span>
                        </label>
                    </div>
                </div>
                <div class="card" id="print-card-fiches" style="display:none">
                    ${this._buildFichesCard()}
                </div>
                <div class="card" id="print-card-docs" style="display:none">
                    <div class="placeholder-view" style="padding:40px 20px">
                        <div class="placeholder-icon">📄</div>
                        <div class="placeholder-title">Documents — à venir</div>
                        <p class="text-muted small">Génération de documents divers.</p>
                    </div>
                </div>

                <div class="card" id="print-card-options">
                    <div id="print-opts-edt-group">
                    <h3 style="margin:0 0 6px 0">2. Options</h3>

                    <div id="print-opts-eleve">
                        <div class="form-group">
                            <label>Élève</label>
                            <select id="print-eleve" style="width:100%">
                                ${this._eleves.map(e => `<option value="${e.id}">${escapeHtml(e.prenom || '')} ${escapeHtml(e.nom || '')}${e.classe ? ' (' + escapeHtml(e.classe) + ')' : ''}</option>`).join('')}
                            </select>
                        </div>
                    </div>

                    <div id="print-opts-adulte" style="display:none">
                        <div class="form-group">
                            <label>Adulte</label>
                            <select id="print-adulte" style="width:100%">${this._buildAdultOptions()}</select>
                        </div>
                        <div class="form-group" id="print-group-adulte-jour" style="display:none">
                            <label>Jour</label>
                            <select id="print-adulte-jour" style="width:100%">${jourOpts}</select>
                        </div>
                        <div class="form-group" id="print-group-adulte-multi" style="display:none">
                            <div class="form-group" style="margin-bottom:6px">
                                <label>Jour</label>
                                <select id="print-multi-adulte-jour" style="width:100%">${jourOpts}</select>
                            </div>
                            <div class="form-group" style="margin-bottom:0">
                                <label>Adultes</label>
                                <div style="display:flex;gap:4px;margin-bottom:4px">
                                    <button type="button" class="btn btn-sm btn-secondary" data-select="print-multi-adultes" data-action="all">Tout</button>
                                    <button type="button" class="btn btn-sm btn-secondary" data-select="print-multi-adultes" data-action="none">Aucun</button>
                                </div>
                                <select id="print-multi-adultes" style="width:100%" multiple size="5">${this._buildAdultMultiOptions()}</select>
                            </div>
                        </div>
                    </div>

                    <div id="print-opts-multi" style="display:none">
                        <div class="form-row">
                            <div class="form-group">
                                <label>Jour</label>
                                <select id="print-jour" style="width:100%">${jourOpts}</select>
                            </div>
                            <div class="form-group">
                                <label>Élèves</label>
                                <div style="display:flex;gap:4px;margin-bottom:4px">
                                    <button type="button" class="btn btn-sm btn-secondary" data-select="print-multi-eleves" data-action="all">Tout</button>
                                    <button type="button" class="btn btn-sm btn-secondary" data-select="print-multi-eleves" data-action="none">Aucun</button>
                                </div>
                                <select id="print-multi-eleves" style="width:100%" multiple size="5">
                                    ${this._eleves.map(e => `<option value="${e.id}" selected>${escapeHtml(e.prenom || '')} ${escapeHtml(e.nom || '')}</option>`).join('')}
                                </select>
                            </div>
                        </div>
                    </div>

                    <div class="form-group" style="margin-top:8px">
                        <label>Semaine</label>
                        <input type="text" id="print-semaine-search" class="filter-input" placeholder="Rechercher une semaine..." style="margin-bottom:4px;width:100%">
                        <select id="print-semaine" style="width:100%">
                            <option value="template">Semaine type (template)</option>
                            ${currentSemaine ? `<option value="${currentSemaine.id}" selected>Semaine courante (S${getSchoolWeekNumber(currentSemaine, this._semaines) || ''})</option>` : ''}
                            ${semaines.filter(s => s.id !== currentSemaine?.id).slice(0,20).map(s => `<option value="${s.id}">Semaine S${getSchoolWeekNumber(s, this._semaines)}${s.est_modifiee ? ' ⚡' : ''}</option>`).join('')}
                        </select>
                    </div>
                </div>
                    </div><!-- /print-opts-edt-group -->

                <div style="display:flex;gap:8px">
                    <button class="btn btn-primary" id="btn-print-generate" style="flex:1">🖨️ Générer l'aperçu</button>
                </div>
            </div>

            <div class="print-preview-panel">
                <div class="card" style="display:flex;flex-direction:column;height:100%">
                    <h3 style="margin:0 0 6px 0">3. Aperçu</h3>
                    <p class="text-muted small" id="print-preview-label">Cliquez sur Générer pour prévisualiser le PDF.</p>
                    <div id="print-preview-placeholder" style="flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:12px;color:var(--text-muted);min-height:0;user-select:none">
                        <svg width="80" height="100" viewBox="0 0 80 100" fill="none" opacity="0.3" style="display:block">
                            <rect x="2" y="2" width="76" height="96" rx="4" stroke="currentColor" stroke-width="2" fill="none"/>
                            <line x1="12" y1="25" x2="68" y2="25" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            <line x1="12" y1="33" x2="55" y2="33" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            <line x1="12" y1="41" x2="60" y2="41" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            <line x1="12" y1="49" x2="45" y2="49" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            <line x1="12" y1="57" x2="65" y2="57" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            <line x1="12" y1="65" x2="40" y2="65" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            <line x1="12" y1="73" x2="58" y2="73" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                            <line x1="12" y1="81" x2="30" y2="81" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                        </svg>
                        <span style="font-size:14px;font-weight:500">Aucun aperçu</span>
                        <span style="font-size:12px;text-align:center">Sélectionnez un type d'export et les options,<br>puis cliquez sur Générer.</span>
                    </div>
                    <div id="print-preview-area" style="display:none;flex:1;flex-direction:column;margin-top:8px;min-height:0;overflow:hidden">
                        <div class="print-canvas-wrapper" style="flex:1;overflow:auto;border:1px solid var(--border);border-radius:6px;background:#f5f5f5;padding:16px;min-width:0">
                            <canvas id="print-preview-canvas" style="display:block;margin:0 auto;box-shadow:0 2px 12px rgba(0,0,0,.15)"></canvas>
                        </div>
                        <div style="display:flex;gap:6px;justify-content:space-between;align-items:center;margin-top:8px;flex-wrap:wrap">
                            <div style="display:flex;gap:4px;align-items:center">
                                <button class="btn btn-sm" id="btn-zoom-out" title="Zoom avant">🔍−</button>
                                <span id="print-zoom-label" class="text-muted small" style="min-width:44px;text-align:center">100%</span>
                                <button class="btn btn-sm" id="btn-zoom-in" title="Zoom arrière">🔍+</button>
                                <button class="btn btn-sm" id="btn-zoom-fit" title="Ajuster à la largeur">↔</button>
                            </div>
                            <div id="print-page-nav" style="display:none;display:flex;gap:8px;align-items:center">
                                <button class="btn btn-sm" id="btn-prev-page">◀ Page précédente</button>
                                <span id="print-page-info" class="text-muted small"></span>
                                <button class="btn btn-sm" id="btn-next-page">Page suivante ▶</button>
                            </div>
                            <button class="btn btn-secondary" id="btn-print-download" disabled>⬇ Télécharger le PDF</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>`;
    },

    _bindEvents() {
        // Onglets
        document.querySelectorAll('.print-tab').forEach(btn => {
            btn.addEventListener('click', () => this._switchTab(btn.dataset.tab));
        });
        // Cartes export
        document.querySelectorAll('.export-card-radio').forEach(radio => {
            radio.addEventListener('change', () => this._toggleOpts());
        });
        document.getElementById('btn-print-generate').addEventListener('click', () => this._generate());
        document.getElementById('btn-print-download').addEventListener('click', () => {
            if (this._pendingDef && this._pendingFilename) this._download(this._pendingDef, this._pendingFilename);
        });
        document.getElementById('btn-prev-page').addEventListener('click', () => this._navigatePage(-1));
        document.getElementById('btn-next-page').addEventListener('click', () => this._navigatePage(1));
        // Zoom
        document.getElementById('btn-zoom-in').addEventListener('click', () => this._zoomChange(0.25));
        document.getElementById('btn-zoom-out').addEventListener('click', () => this._zoomChange(-0.25));
        document.getElementById('btn-zoom-fit').addEventListener('click', () => this._zoomFit());
        document.querySelectorAll('[data-select]').forEach(btn => {
            btn.addEventListener('click', () => this._selectAllToggle(btn.dataset.select, btn.dataset.action !== 'none'));
        });
        this._bindWeekSearch();

        // Initialiser la visibilité des options selon le type par défaut
        this._toggleOpts();
    },

    _switchTab(tabId) {
        this._currentTab = tabId;
        document.querySelectorAll('.print-tab').forEach(t => t.classList.toggle('active', t.dataset.tab === tabId));
        ['edt','stats','fiches','docs'].forEach(id => {
            const el = document.getElementById('print-card-' + id);
            if (el) el.style.display = id === tabId ? '' : 'none';
        });
        // Afficher/masquer le groupe d'options EDT (visible uniquement sur l'onglet EDT)
        const edtGroup = document.getElementById('print-opts-edt-group');
        if (edtGroup) edtGroup.style.display = tabId === 'edt' ? '' : 'none';
        // Restaurer les options EDT si onglet EDT
        if (tabId === 'edt') {
            this._toggleOpts();
        }
    },

    _toggleOpts() {
        const type = document.querySelector('input[name="print-type"]:checked')?.value || 'semaine-eleve';
        document.querySelectorAll('.export-card').forEach(c => c.classList.toggle('active', c.querySelector(':checked')));
        document.getElementById('print-opts-eleve').style.display = type === 'semaine-eleve' ? '' : 'none';
        document.getElementById('print-opts-adulte').style.display = (type === 'semaine-adulte' || type === 'jour-adultes') ? '' : 'none';
        document.getElementById('print-group-adulte-jour').style.display = 'none';
        document.getElementById('print-opts-multi').style.display = type === 'jour-eleves' ? '' : 'none';
        const adulteSingle = document.querySelector('#print-opts-adulte > .form-group:first-child');
        if (adulteSingle) adulteSingle.style.display = type === 'semaine-adulte' ? '' : 'none';
        document.getElementById('print-group-adulte-multi').style.display = type === 'jour-adultes' ? '' : 'none';
    },

    async _generate() {
        const type = document.querySelector('input[name="print-type"]:checked')?.value || 'semaine-eleve';

        // Onglet Statistiques
        if (this._currentTab === 'stats') {
            return this._generateStats();
        }
        // Onglet Fiches (Lot 1) : fiches de renseignements / urgence
        if (this._currentTab === 'fiches') {
            return this._generateFiches();
        }

        const semaineVal = document.getElementById('print-semaine').value;
        const semaineId = semaineVal === 'template' ? null : parseInt(semaineVal);

        const btn = document.getElementById('btn-print-generate');
        btn.disabled = true;
        btn.textContent = '⏳ Génération…';

        try {
            let def, filename;

            if (type === 'semaine-eleve') {
                const id = parseInt(document.getElementById('print-eleve').value);
                const eleve = this._eleves.find(e => e.id === id);
                const label = eleve ? `${eleve.prenom || ''} ${eleve.nom || ''}`.trim() : `Élève #${id}`;
                filename = `edt_${label.toLowerCase().replace(/\s+/g, '_')}.pdf`;
                def = await this._buildStudentWeek(id, semaineId);
            } else if (type === 'semaine-adulte') {
                const nom = document.getElementById('print-adulte').value;
                filename = `edt_${nom.toLowerCase().replace(/\s+/g, '_')}.pdf`;
                def = await this._buildAdultWeekFromAPI(nom, semaineId);
            } else if (type === 'jour-eleves') {
                const jour = document.getElementById('print-jour').value;
                const select = document.getElementById('print-multi-eleves');
                const ids = Array.from(select.selectedOptions).map(o => parseInt(o.value));
                if (!ids.length) { Modal.alert('Erreur', 'Sélectionnez au moins un élève.'); return; }
                filename = `edt_${jour}_${ids.length}_eleves.pdf`;
                def = await this._buildMultiDayFromAPI(jour, semaineId, ids);
            } else if (type === 'jour-adultes') {
                const jour = document.getElementById('print-multi-adulte-jour').value;
                const select = document.getElementById('print-multi-adultes');
                const noms = Array.from(select.selectedOptions).map(o => o.value);
                if (!noms.length) { Modal.alert('Erreur', 'Sélectionnez au moins un adulte.'); return; }
                filename = `edt_${jour}_${noms.length}_adultes.pdf`;
                if (noms.length === 1) {
                    def = await this._buildAdultWeekFromAPI(noms[0], semaineId, jour);
                } else {
                    def = await this._buildMultiAdultDay(jour, semaineId, noms);
                }
            }

            if (def) this._showPreview(def, filename);
        } finally {
            btn.disabled = false;
            btn.textContent = '🖨️ Générer l\'aperçu';
        }
    },



    async _ensureParams() {
        if (this._params) return this._params;
        const raw = await API.get('params.php');
        const params = {};
        (raw || []).forEach(p => {
            try { params[p.cle] = JSON.parse(p.valeur); } catch { params[p.cle] = p.valeur; }
        });
        this._params = params;
        return params;
    },

};