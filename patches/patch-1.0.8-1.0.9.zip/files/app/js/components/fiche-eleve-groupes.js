
/**
 * Calulis — Groupes multiples d'un élève (noms libres, par année)
 * Greffé sur FicheEleve. Section « Groupes » dans l'onglet Scolarité.
 */
Object.assign(FicheEleve, {

  _loadGroupes() {
    const box = document.getElementById('fiche-groupes-list');
    if (!box) return;
    if (!this._eleve || !this._eleve.id) { this._renderGroupes([]); return; }
    API.get('eleve_groupes.php?eleve_id=' + this._eleve.id).then(items => {
      this._renderGroupes((items || []).map(function(g){ return g.nom; }));
    }).catch(function(){ this && this._renderGroupes([]); });
  },

  _renderGroupes(items) {
    const box = document.getElementById('fiche-groupes-list');
    if (!box) return;
    box.innerHTML = (items && items.length ? items : ['']).map(function(nom){
      return '<div class="sub-row groupe-row" style="display:flex;gap:6px;margin-bottom:4px;align-items:center">' +
        '<input type="text" class="groupe-nom" value="' + escapeHtml(nom || '') + '" placeholder="Nom du groupe (ex. Lecture 1)" maxlength="100" style="flex:1">' +
        '<button class="btn-sm btn-del" onclick="this.closest(\'.groupe-row\').remove()">✕</button>' +
      '</div>';
    }).join('');
  },

  _addGroupeRow() {
    const box = document.getElementById('fiche-groupes-list');
    if (!box) return;
    const div = document.createElement('div');
    div.className = 'sub-row groupe-row';
    div.style.cssText = 'display:flex;gap:6px;margin-bottom:4px;align-items:center';
    div.innerHTML = '<input type="text" class="groupe-nom" value="" placeholder="Nom du groupe (ex. Math 2)" maxlength="100" style="flex:1">' +
      '<button class="btn-sm btn-del" onclick="this.closest(\'.groupe-row\').remove()">✕</button>';
    box.appendChild(div);
    const inp = div.querySelector('.groupe-nom'); if (inp) inp.focus();
  },

  _getGroupesFromDOM() {
    const out = [];
    document.querySelectorAll('#fiche-groupes-list .groupe-nom').forEach(function(i){
      const v = (i.value || '').trim();
      if (v) out.push(v);
    });
    return out;
  },

  async _saveGroupes(eleveId) {
    // On remplace TOUS les groupes de l'élève (peu importe l'année) puis on recrée
    await API.del('eleve_groupes.php?eleve_id=' + eleveId);
    const items = this._getGroupesFromDOM();
    for (const nom of items) {
      await API.post('eleve_groupes.php', { eleve_id: eleveId, nom: nom });
    }
  },

});