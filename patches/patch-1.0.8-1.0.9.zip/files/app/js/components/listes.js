
/**
 * Calulis — Lot 1 : Générateur de listes d'élèves multicritères
 * Filtres cumulés + colonnes personnalisables (réordonnables, colonnes libres/vides)
 * + export PDF (paysage/portrait, hauteur de ligne, plein format) + CSV + groupes enregistrés.
 */
const Listes = {
  _classes: [], _groupes: [], _groupesSaved: [], _eleves: [], _selected: new Set(),
  _cols: [], _customIdx: 0, _filters: {},
  _orient: 'paysage', _rowH: 'grande', _fontSize: 8,

  // Définition des colonnes intégrées (clé -> { label, w, get }).
  // w = largeur relative (points) servant de base quand on "remplit" la page.
  COLUMNS: {
    numero:        { label: 'N°',                  w: 30, get: function(e){ return e.numero || ''; } },
    nom:           { label: 'Nom',                 w: 78, get: function(e){ return e.nom || ''; } },
    prenom:        { label: 'Prénom',              w: 78, get: function(e){ return e.prenom || ''; } },
    classe:        { label: 'Classe',              w: 52, get: function(e){ return e.classe_nom || e.classe || ''; } },
    date_naissance:{ label: 'Naissance',           w: 62, get: function(e){ return formatDate(e.date_naissance); } },
    age:           { label: 'Âge',                 w: 32, get: function(e){ return Listes._age(e.date_naissance); } },
    groupe:        { label: 'Groupe',              w: 58, get: function(e){ return (e.groupes && e.groupes.length) ? e.groupes.join(', ') : (e.groupe || ''); } },
    niveau:        { label: 'Niveau',              w: 46, get: function(e){ return NIVEAU_LABELS[e.niveau_scolaire] || e.niveau_scolaire || ''; } },
    transport:     { label: 'Transport',           w: 70, get: function(e){ return e.transport || ''; } },
    cantine:       { label: 'Cantine',             w: 44, get: function(e){ return e.cantine ? 'Oui' : 'Non'; } },
    pai:           { label: 'PAI',                 w: 32, get: function(e){ return e.pai ? 'Oui' : 'Non'; } },
    allergies:     { label: 'Allergies',           w: 90, get: function(e){ return e.allergies || ''; } },
    regime:        { label: 'Régime',              w: 70, get: function(e){ return e.regime_alimentaire || e.regime_scolaire || ''; } },
    droit_image:   { label: 'Droit image',         w: 58, get: function(e){ return Listes._droitLabel(e.droit_image); } },
    tel:           { label: 'Tél. représentants',  w: 92, get: function(e){ return Listes._repsTel(e); } },
    prevenir:      { label: 'Personne à prévenir', w: 96, get: function(e){ return Listes._repsNom(e); } },
  },

  async render() {
    const view = document.getElementById('view-listes');
    view.innerHTML = '<div class="placeholder-view"><div class="placeholder-icon">⏳</div><div class="placeholder-title">Chargement…</div></div>';
    try { await this._loadOptions(); await this._reload(); }
    catch (e) { console.error('[Listes] load error:', e); }
    if (!this._cols.length) this._cols = this._defaultCols();
    view.innerHTML = this._buildHTML();
    this._bindEvents();
    this._renderResults();
  },

  async _loadOptions() {
    const [opts, saved] = await Promise.all([ API.get('listes.php?action=options'), API.get('groupes.php') ]);
    this._classes = (opts && opts.classes) || [];
    this._groupes = (opts && opts.groupes) || [];
    this._groupesSaved = saved || [];
  },

  async _reload() {
    const qs = this._buildQuery();
    this._eleves = await API.get('listes.php' + (qs ? '?' + qs : ''));
    this._selected = new Set(this._eleves.map(function(e){ return e.id; }));
  },

  _buildQuery() {
    const f = this._filters, p = [];
    const add = function(k, v){ if (v !== undefined && v !== null && v !== '') p.push(k + '=' + encodeURIComponent(v)); };
    add('q', f.q); add('classe', f.niveau); add('classe_id', f.classe_id); add('groupe', f.groupe);
    if (f.ulis === 0 || f.ulis === 1) add('ulis', f.ulis);
    if (f.droit_image) add('droit_image', f.droit_image);
    if (f.transport === 'has') add('transport', 'has');
    if (f.cantine === 0 || f.cantine === 1) add('cantine', f.cantine);
    if (f.pai === 0 || f.pai === 1) add('pai', f.pai);
    if (f.allergies === 0 || f.allergies === 1) add('allergies', f.allergies);
    if (f.inclure_inactifs) add('inclure_inactifs', 1);
    return p.join('&');
  },

  _defaultCols() {
    return ['numero','nom','prenom','classe','date_naissance','groupe','pai','allergies','tel','droit_image']
      .map(function(k){ const c = Listes.COLUMNS[k]; return { id: k, label: c.label, w: c.w, get: c.get, blank: false }; });
  },

  _colById(id) { return this._cols.find(function(c){ return c.id === id; }); },
  _colIndex(id) { for (let i=0;i<this._cols.length;i++) if (this._cols[i].id===id) return i; return -1; },

  _buildHTML() {
    const classesOpts = this._classes.map(function(c){ return '<option value="' + c.id + '">' + escapeHtml(c.nom) + '</option>'; }).join('');
    const niveauOpts = this._distinctNiveaux().map(function(n){ return '<option value="' + escapeHtml(n.raw) + '">' + escapeHtml(n.label) + '</option>'; }).join('');
    const groupeOpts = this._groupes.map(function(g){ return '<option value="' + escapeHtml(g) + '">' + escapeHtml(g) + '</option>'; }).join('');
    const groupesSavedOpts = this._groupesSaved.map(function(g){ return '<option value="' + g.id + '">' + escapeHtml(g.nom) + '</option>'; }).join('');
    return '' +
    '<div class="print-header"><div class="print-tabs"><span class="print-tab active">📋 Listes</span></div><span class="text-muted" style="font-size:12px;white-space:nowrap">' + this._eleves.length + ' élève(s) · ' + this._cols.length + ' colonne(s)</span></div>' +
    '<div class="print-layout"><div class="print-options-panel">' +
      '<div class="card"><h3 style="margin:0 0 6px 0">1. Filtres</h3>' +
        '<div class="form-row">' +
          '<div class="form-group"><label>Recherche</label><input type="text" id="l-q" class="filter-input" placeholder="Nom, prénom…" style="width:100%"></div>' +
          '<div class="form-group"><label>Niveau</label><select id="l-niveau" style="width:100%"><option value="">Tous</option>' + niveauOpts + '</select></div>' +
          '<div class="form-group"><label>Classe</label><select id="l-classe" style="width:100%"><option value="">Toutes</option>' + classesOpts + '</select></div>' +
          '<div class="form-group"><label>Groupe</label><select id="l-groupe" style="width:100%"><option value="">Tous</option>' + groupeOpts + '</select></div>' +
        '</div>' +
        '<div class="form-row">' +
          '<div class="form-group"><label>ULIS</label><select id="l-ulis" style="width:100%"><option value="">Tous</option><option value="1">Oui</option><option value="0">Non</option></select></div>' +
          '<div class="form-group"><label>Droit à l&#39;image</label><select id="l-droit" style="width:100%"><option value="">Tous</option><option value="autorise">Autorisé</option><option value="refuse">Refusé</option><option value="en_attente">En attente</option></select></div>' +
          '<div class="form-group"><label>Transport</label><select id="l-transport" style="width:100%"><option value="">Tous</option><option value="has">Avec transport</option></select></div>' +
          '<div class="form-group"><label>Cantine</label><select id="l-cantine" style="width:100%"><option value="">Tous</option><option value="1">Oui</option><option value="0">Non</option></select></div>' +
        '</div>' +
        '<div class="form-row">' +
          '<div class="form-group"><label>PAI</label><select id="l-pai" style="width:100%"><option value="">Tous</option><option value="1">Oui</option><option value="0">Non</option></select></div>' +
          '<div class="form-group"><label>Allergies</label><select id="l-allergies" style="width:100%"><option value="">Tous</option><option value="1">Avec</option><option value="0">Sans</option></select></div>' +
          '<div class="form-group" style="display:flex;align-items:flex-end"><label style="margin-bottom:6px"><input type="checkbox" id="l-inactifs"> Inclure inactifs</label></div>' +
        '</div>' +
        '<div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap"><button class="btn btn-sm btn-secondary" id="l-apply">🔍 Appliquer</button><button class="btn btn-sm btn-secondary" id="l-reset">↺ Réinitialiser</button></div>' +
      '</div>' +
      '<div class="card"><h3 style="margin:0 0 6px 0">2. Colonnes <span style="font-weight:400;font-size:11px">(cochez, ordonnez, ajoutez)</span></h3><div id="l-cols" class="col-list"></div></div>' +
      '<div class="card"><h3 style="margin:0 0 6px 0">3. Mise en page</h3>' +
        '<div class="form-row">' +
          '<div class="form-group"><label>Orientation</label><select id="l-orient" style="width:100%"><option value="paysage">Paysage</option><option value="portrait">Portrait</option></select></div>' +
          '<div class="form-group"><label>Espace pour écrire</label><select id="l-rowh" style="width:100%"><option value="compact">Compact</option><option value="normale" selected>Normale</option><option value="grande">Grande</option><option value="tresgrande">Très grande (feuille)</option></select></div>' +
          '<div class="form-group"><label>Taille du texte</label><select id="l-font" style="width:100%"><option value="7">Petit</option><option value="8" selected>Normal</option><option value="9.5">Grand</option><option value="11">Très grand</option></select></div>' +
        '</div>' +
        '<p class="text-muted small" style="margin:6px 0 0 0">Choisissez « Grande » ou « Très grande » et le format paysage pour des listes à compléter à la main : les lignes sont hautes et les colonnes occupent toute la feuille.</p>' +
      '</div>' +
      '<div class="card"><h3 style="margin:0 0 6px 0">4. Groupes enregistrés <span style="font-weight:400;font-size:11px">(template : filtres + colonnes + mise en page)</span></h3>' +
        '<div style="display:flex;gap:6px;margin-bottom:6px"><select id="l-groupes" style="flex:1">' + groupesSavedOpts + '</select><button class="btn btn-sm btn-secondary" id="l-group-load">Charger</button><button class="btn btn-sm btn-secondary" id="l-group-update">Mettre à jour</button><button class="btn btn-sm btn-secondary" id="l-group-del">Suppr.</button></div>' +
        '<button class="btn btn-sm btn-primary" id="l-group-save">💾 Enregistrer comme nouveau groupe…</button>' +
      '</div>' +
      '<div class="card"><h3 style="margin:0 0 6px 0">5. Export</h3><button class="btn btn-primary" id="l-pdf" style="width:100%;margin-bottom:6px">🖨️ Télécharger le PDF</button><button class="btn btn-secondary" id="l-csv" style="width:100%">📥 Exporter CSV</button></div>' +
    '</div>' +
    '<div class="print-preview-panel"><div class="card" style="display:flex;flex-direction:column;height:100%">' +
      '<h3 style="margin:0 0 6px 0">Aperçu <span class="text-muted small" style="font-weight:400">— glissez les en-têtes pour réordonner</span></h3>' +
      '<div style="display:flex;gap:6px;margin-bottom:8px;align-items:center"><button class="btn btn-sm btn-secondary" id="l-all">Tout</button><button class="btn btn-sm btn-secondary" id="l-none">Aucun</button><span class="text-muted small" id="l-count" style="margin-left:auto"></span></div>' +
      '<div style="flex:1;overflow:auto;border:1px solid var(--border);border-radius:6px" id="l-results"></div>' +
    '</div></div>' +
    '</div>';
  },

  _renderColumns() {
    const box = document.getElementById('l-cols'); if (!box) return;
    const self = this;
    let html = '<div class="col-row col-head"><span>Colonnes affichées — glissez les en-têtes dans l&#39;aperçu pour réordonner</span><span></span></div>';
    this._cols.forEach(function(c, i){
      html += '<div class="col-row">' +
        '<label style="flex:1;display:flex;align-items:center;gap:6px"><input type="checkbox" data-col="' + c.id + '" checked> ' + escapeHtml(c.label) + '</label>' +
        (c.blank ? '<button class="btn-xs btn-outline col-del" data-id="' + c.id + '" title="Supprimer">✕</button>' : '<span style="width:20px"></span>') +
      '</div>';
    }, this);
    // Colonnes disponibles (non cochées)
    const avail = Object.keys(this.COLUMNS).filter(function(k){ return !self._colById(k); });
    if (avail.length) html += '<div class="col-avail"><div class="col-avail-title">Ajouter :</div>' + avail.map(function(k){ return '<label class="col-toggle"><input type="checkbox" data-col="' + k + '"> ' + escapeHtml(self.COLUMNS[k].label) + '</label>'; }).join('') + '</div>';
    html += '<button class="btn btn-sm btn-secondary" id="l-add-custom" style="margin-top:8px">＋ Ajouter une colonne libre</button>';
    box.innerHTML = html;
    // Bind
    box.querySelectorAll('[data-col]').forEach(cb => cb.addEventListener('change', function(){ self._toggleCol(cb.dataset.col, cb.checked); }));
    box.querySelectorAll('.col-del').forEach(b => b.addEventListener('click', function(){ self._delCustom(b.dataset.id); }));
    const add = document.getElementById('l-add-custom'); if (add) add.addEventListener('click', function(){ self._addCustom(); });
  },

  _toggleCol(id, on) {
    if (on) { const c = this.COLUMNS[id]; if (c && !this._colById(id)) this._cols.push({ id: id, label: c.label, w: c.w, get: c.get, blank: false }); }
    else { this._cols = this._cols.filter(function(c){ return c.id !== id; }); }
    this._renderColumns(); this._renderResults();
  },

  _moveCol(id, dir) {
    const i = this._colIndex(id); if (i < 0) return;
    const j = i + dir; if (j < 0 || j >= this._cols.length) return;
    const tmp = this._cols[i]; this._cols[i] = this._cols[j]; this._cols[j] = tmp;
    this._renderColumns(); this._renderResults();
  },

  _reorderCol(draggedId, targetId) {
    if (draggedId === targetId) return;
    const from = this._colIndex(draggedId); if (from < 0) return;
    const it = this._cols.splice(from, 1)[0];
    let to = this._colIndex(targetId);
    if (to < 0) to = this._cols.length;
    this._cols.splice(to, 0, it);
    this._renderResults();
    this._renderColumns();
  },

  _addCustom() {
    const label = window.prompt('Nom de la colonne libre (ex. « Observations », « Notes de l’enseignant »…) :');
    if (label === null) return;
    this._customIdx++;
    const id = 'custom_' + this._customIdx;
    this._cols.push({ id: id, label: label.trim() || 'Colonne libre', w: 120, get: function(){ return ''; }, blank: true });
    this._renderColumns(); this._renderResults();
  },

  _delCustom(id) {
    const idx = this._colIndex(id); if (idx < 0) return;
    const c = this._cols[idx]; if (!c.blank) return;
    this._cols.splice(idx, 1);
    this._renderColumns(); this._renderResults();
  },

  _distinctNiveaux() {
    const seen = {}, out = [];
    this._classes.forEach(function(c){ const raw = c.niveaux; if (!raw || seen[raw]) return; seen[raw] = true; let label = raw; try { const arr = JSON.parse(raw); label = arr.map(function(n){ return NIVEAU_LABELS[n] || n; }).join(', '); } catch (e) {} out.push({ raw: raw, label: label }); });
    return out;
  },

  _bindEvents() {
    const on = function(id, fn){ const el = document.getElementById(id); if (el) el.addEventListener('change', fn); };
    const onC = function(id, fn){ const el = document.getElementById(id); if (el) el.addEventListener('click', fn); };
    on('l-q', function(){ Listes._filters.q = document.getElementById('l-q').value.trim(); });
    on('l-niveau', function(){ Listes._filters.niveau = document.getElementById('l-niveau').value; });
    on('l-classe', function(){ Listes._filters.classe_id = document.getElementById('l-classe').value || ''; });
    on('l-groupe', function(){ Listes._filters.groupe = document.getElementById('l-groupe').value; });
    on('l-ulis', function(){ const v = document.getElementById('l-ulis').value; Listes._filters.ulis = v === '' ? '' : parseInt(v); });
    on('l-droit', function(){ Listes._filters.droit_image = document.getElementById('l-droit').value; });
    on('l-transport', function(){ Listes._filters.transport = document.getElementById('l-transport').value; });
    on('l-cantine', function(){ const v = document.getElementById('l-cantine').value; Listes._filters.cantine = v === '' ? '' : parseInt(v); });
    on('l-pai', function(){ const v = document.getElementById('l-pai').value; Listes._filters.pai = v === '' ? '' : parseInt(v); });
    on('l-allergies', function(){ const v = document.getElementById('l-allergies').value; Listes._filters.allergies = v === '' ? '' : parseInt(v); });
    on('l-inactifs', function(){ Listes._filters.inclure_inactifs = document.getElementById('l-inactifs').checked; });
    on('l-orient', function(){ Listes._orient = document.getElementById('l-orient').value; });
    on('l-rowh', function(){ Listes._rowH = document.getElementById('l-rowh').value; });
    on('l-font', function(){ Listes._fontSize = parseFloat(document.getElementById('l-font').value) || 8; });
    onC('l-apply', function(){ Listes._apply(); });
    onC('l-reset', function(){ Listes._reset(); });
    onC('l-all', function(){ Listes._selectAll(true); });
    onC('l-none', function(){ Listes._selectAll(false); });
    onC('l-pdf', function(){ Listes._exportPDF(); });
    onC('l-csv', function(){ Listes._exportCSV(); });
    onC('l-group-save', function(){ Listes._saveGroup(false); });
    onC('l-group-update', function(){ Listes._saveGroup(true); });
    onC('l-group-load', function(){ Listes._loadGroup(); });
    onC('l-group-del', function(){ Listes._deleteGroup(); });
    const q = document.getElementById('l-q');
    if (q) q.addEventListener('keydown', function(ev){ if (ev.key === 'Enter') Listes._apply(); });
    this._renderColumns();
  },

  async _apply() { await this._reload(); this._renderResults(); },
  async _reset() {
    this._filters = {};
    ['l-q','l-niveau','l-classe','l-groupe','l-ulis','l-droit','l-transport','l-cantine','l-pai','l-allergies'].forEach(function(id){ const el = document.getElementById(id); if (el) el.value = ''; });
    const inact = document.getElementById('l-inactifs'); if (inact) inact.checked = false;
    await this._reload(); this._renderResults();
  },
  _selectAll(all) { this._eleves.forEach(function(e){ all ? Listes._selected.add(e.id) : Listes._selected.delete(e.id); }); this._renderResults(); },

  _renderResults() {
    const box = document.getElementById('l-results'); if (!box) return;
    const cols = this._cols;
    const thStyle = 'border:1px solid var(--border);padding:5px 10px;background:var(--bg-card,#eceff1);text-align:left;white-space:nowrap;font-weight:600;min-width:40px';
    const tdStyle = 'border:1px solid var(--border);padding:3px 10px;white-space:nowrap';
    let html = '<table class="filter-table" style="border-collapse:collapse;width:100%"><thead><tr><th style="border:1px solid var(--border);width:32px;background:var(--bg-card,#eceff1)"></th>';
    cols.forEach(function(c){ html += '<th data-col="' + escapeHtml(c.id) + '" style="' + thStyle + '">' + escapeHtml(c.label) + '</th>'; });
    html += '</tr></thead><tbody>';
    this._eleves.forEach(function(e){
      const chk = Listes._selected.has(e.id) ? ' checked' : '';
      html += '<tr class="list-row" data-id="' + e.id + '"><td style="border:1px solid var(--border)"><input type="checkbox" class="l-row" data-id="' + e.id + '"' + chk + '></td>';
      cols.forEach(function(c){ html += '<td style="' + tdStyle + '">' + escapeHtml(String(c.get.call(Listes, e) || '')) + '</td>'; });
      html += '</tr>';
    });
    html += '</tbody></table>';
    box.innerHTML = html;
    box.querySelectorAll('.l-row').forEach(function(cb){
      cb.addEventListener('change', function(){ const id = parseInt(cb.dataset.id); if (cb.checked) Listes._selected.add(id); else Listes._selected.delete(id); const c = document.getElementById('l-count'); if (c) c.textContent = Listes._selected.size + ' sélectionné(s)'; });
    });
    const count = document.getElementById('l-count'); if (count) count.textContent = this._selected.size + ' sélectionné(s)';
    if (typeof linkLabels === 'function') linkLabels(box);
    // Réordonner les colonnes par glisser-déposer sur les en-têtes (comme l'agenda)
    const ths = box.querySelectorAll('thead th[data-col]');
    ths.forEach(th => {
      th.setAttribute('draggable', 'true');
      th.style.cursor = 'grab';
      th.title = 'Glisser pour réordonner';
      th.addEventListener('dragstart', function(ev){ ev.dataTransfer.setData('text/plain', this.dataset.col); this.classList.add('dragging'); ev.dataTransfer.effectAllowed = 'move'; });
      th.addEventListener('dragend', function(){ this.classList.remove('dragging'); box.querySelectorAll('th.drag-over').forEach(function(t){ t.classList.remove('drag-over'); t.style.outline = ''; }); });
      th.addEventListener('dragover', function(ev){ ev.preventDefault(); ev.dataTransfer.dropEffect = 'move'; box.querySelectorAll('th.drag-over').forEach(function(t){ t.classList.remove('drag-over'); t.style.outline = ''; }); this.classList.add('drag-over'); this.style.outline = '2px solid var(--primary)'; });
      th.addEventListener('dragleave', function(){ this.classList.remove('drag-over'); this.style.outline = ''; });
      th.addEventListener('drop', function(ev){ ev.preventDefault(); const d = ev.dataTransfer.getData('text/plain'); if (d) Listes._reorderCol(d, this.dataset.col); });
    });
  },

  _droitLabel: function(d){ const m = { autorise: '✅ Autorisé', refuse: '⛔ Refusé', limite: '⚠️ Limité', en_attente: '⏳ En attente', retire: '↩️ Retiré' }; return d ? (m[d.statut] || d.statut) : '—'; },
  _repsTel: function(e){ return (e.representants || []).map(function(r){ return r.telephone || r.telephone_urgence || ''; }).filter(Boolean).join(' / '); },
  _repsNom: function(e){ return (e.representants || []).map(function(r){ return (r.prenom ? r.prenom + ' ' : '') + (r.nom || ''); }).join(', '); },
  _age: function(birth){ if (!birth) return ''; const b = new Date(birth + 'T00:00:00'); const now = new Date(); let a = now.getFullYear() - b.getFullYear(); if (a < 0) return ''; const m = now.getMonth() - b.getMonth(); if (m < 0 || (m === 0 && now.getDate() < b.getDate())) a--; return a >= 0 ? a : ''; },

  _rowPad() {
    const map = { compact: 2, normale: 10, grande: 22, tresgrande: 34 };
    return map[this._rowH] || 10;
  },

  _computeWidths(cols, sel, orient, fontSize) {
    fontSize = fontSize || 8;
    // Largeur utile = largeur de la page A4 MINUS les marges (pageMargins [12,12,12,12])
    const margin = 12;
    const pageW = orient === 'landscape' ? 841.89 : 595.28;
    const avail = Math.floor(pageW - margin * 2) - 2;
    // Largeur moyenne d'un caractère (généreuse : chiffres/gras plus larges) + marge d'épaisseur
    const charW = fontSize * 0.62, cellPad = 10;
    const minW = 28;
    const tw = function(s){ return (String(s || '').length * charW) + cellPad; };
    // Largeur naturelle : au contenu le plus large (colonne de données) ;
    // espace généreux pour écrire (colonne libre).
    let w = cols.map(function(c){
      if (c.blank) return Math.max(80, c.w);
      let m = tw(c.label);
      sel.forEach(function(e){ const v = String(c.get.call(Listes, e) || ''); if (v) m = Math.max(m, tw(v)); });
      return Math.min(m, avail * 0.5);
    });
    let sum = w.reduce(function(a,b){ return a + b; }, 0);
    if (sum === 0) sum = 1;
    // Mettre à l'échelle pour tenir dans la page
    const scale = avail / sum;
    w = w.map(function(x){ return Math.max(minW, Math.round(x * scale)); });
    // Rééquilibrer le résidu sur TOUTES les colonnes (jamais une seule minuscule)
    let cur = w.reduce(function(a,b){ return a + b; }, 0);
    let diff = avail - cur;
    let guard = 0;
    while (diff !== 0 && guard < w.length * 12) {
      for (let k = 0; k < w.length && diff !== 0; k++) {
        if (diff > 0) { w[k] += 1; diff -= 1; }
        else if (w[k] > minW) { w[k] -= 1; diff += 1; }
      }
      guard++;
    }
    return w;
  },

  async _exportPDF() {
    const ids = this._selected.size ? Array.from(this._selected) : this._eleves.map(function(e){ return e.id; });
    const sel = this._eleves.filter(function(e){ return ids.indexOf(e.id) >= 0; });
    if (!sel.length) { if (typeof Modal !== 'undefined' && Modal.alert) Modal.alert('Export', 'Aucun élève sélectionné.'); return; }
    const cols = this._cols;
    const pad = this._rowPad();
    const orient = this._orient === 'portrait' ? 'portrait' : 'landscape';
    // Largeur utile de page (points) : A4 paysage ≈ 775, portrait ≈ 516 (marges déduites)
    const fontSize = this._fontSize || 8;
    // Ajustement au contenu (comme Word) : colonnes de données = 'auto' (à leur contenu),
    // colonnes libres = '*' (elles remplissent le reste de la page pour écrire).
    const widths = cols.map(function(c){ return c.blank ? '*' : 'auto'; });
    const header = cols.map(function(c){ return { text: c.label, style: 'th' }; });
    const body = [header];
    sel.forEach(function(e){
      body.push(cols.map(function(c){ return { text: String(c.get.call(Listes, e) || ''), style: 'cell', margin: [1, 1, 1, pad] }; }));
    });
    const def = {
      pageSize: 'A4', pageOrientation: orient, pageMargins: [12, 12, 12, 12],
      content: [
        { text: 'Liste des élèves', style: 'header' },
        { text: (this._filters.q ? 'Recherche : ' + this._filters.q + ' · ' : '') + sel.length + ' élève(s) · ' + new Date().toLocaleDateString('fr-FR'), style: 'subheader' },
        { table: { headerRows: 1, widths: widths, body: body, dontBreakRows: true, layout: 'lightHorizontalLines' }, fontSize: fontSize },
        { text: ' ', margin: [0, 8, 0, 0] },
        { text: 'Renseigné par : ____________________    Date : ______', style: 'foot' },
      ],
      styles: {
        header: { fontSize: 14, bold: true, alignment: 'center', margin: [0,0,0,4] },
        subheader: { fontSize: 9, alignment: 'center', color: '#666', margin: [0,0,0,8] },
        th: { fontSize: fontSize, bold: true, fillColor: '#eee', alignment: 'center' },
        cell: { fontSize: fontSize, margin: [1,1] },
        foot: { fontSize: 8, alignment: 'left', color: '#777', margin: [0, 6, 0, 0] },
      },
    };
    this._lastDef = def;
    if (typeof pdfMake !== 'undefined') pdfMake.createPdf(def).download('liste_eleves_' + new Date().toISOString().slice(0,10) + '.pdf');
  },

  async _exportCSV() {
    const ids = this._selected.size ? Array.from(this._selected) : this._eleves.map(function(e){ return e.id; });
    const sel = this._eleves.filter(function(e){ return ids.indexOf(e.id) >= 0; });
    if (!sel.length) { if (typeof Modal !== 'undefined' && Modal.alert) Modal.alert('Export', 'Aucun élève sélectionné.'); return; }
    const headers = this._cols.map(function(c){ return c.label; });
    const rows = sel.map(function(e){ const r = {}; Listes._cols.forEach(function(c){ r[c.label] = String(c.get.call(Listes, e) || ''); }); return r; });
    exportCSV('liste_eleves_' + new Date().toISOString().slice(0,10) + '.csv', headers, rows);
  },

  _buildGroupState() {
    return {
      filtres: Object.assign({}, this._filters),
      colonnes: this._cols.map(function(c){ return { id: c.id, label: c.label, blank: !!c.blank, w: c.w }; }),
      mise_en_page: { orient: this._orient, rowH: this._rowH, fontSize: this._fontSize },
    };
  },

  _refreshGroupSelect() {
    const sel = document.getElementById('l-groupes');
    if (sel) sel.innerHTML = this._groupesSaved.map(function(g){ return '<option value="' + g.id + '">' + escapeHtml(g.nom) + '</option>'; }).join('');
  },

  async _saveGroup(isUpdate) {
    const sel = document.getElementById('l-groupes');
    let nom;
    if (isUpdate) {
      const g = this._groupesSaved.find(function(x){ return String(x.id) === sel.value; });
      if (!g) { if (typeof Modal !== 'undefined' && Modal.alert) Modal.alert('Groupes', "Choisissez d'abord un groupe à mettre à jour."); return; }
      nom = g.nom;
    } else {
      nom = window.prompt('Nom du nouveau groupe enregistré :');
      if (!nom) return;
    }
    const ids = this._selected.size ? Array.from(this._selected) : [];
    const body = { nom: nom, criteres: this._buildGroupState(), eleves_ids: ids };
    try {
      if (isUpdate) { await API.put('groupes.php?id=' + sel.value, body); }
      else { await API.post('groupes.php', body); }
      await this._loadOptions();
      this._refreshGroupSelect();
      if (typeof Toast !== 'undefined' && Toast.success) Toast.success(isUpdate ? 'Groupe mis à jour' : 'Groupe enregistré');
    } catch (e) { console.error('[Listes] save group:', e); }
  },

  _refreshLayoutUI() {
    const set = function(id, v){ const el = document.getElementById(id); if (el && v) el.value = v; };
    set('l-orient', this._orient); set('l-rowh', this._rowH); set('l-font', String(this._fontSize));
  },

  async _loadGroup() {
    const sel = document.getElementById('l-groupes'); if (!sel || !sel.value) return;
    const g = this._groupesSaved.find(function(x){ return String(x.id) === sel.value; }); if (!g) return;
    let ids = []; try { ids = JSON.parse(g.eleves_ids || '[]'); } catch (e) {}
    let crit = {}; try { crit = JSON.parse(g.criteres || '{}'); } catch (e) {}
    // Un groupe = un template : filtres + colonnes (et leur ordre) + mise en page
    this._filters = crit.filtres || crit || {};
    if (crit.colonnes && crit.colonnes.length) {
      this._cols = crit.colonnes;
    }
    if (crit.mise_en_page) {
      if (crit.mise_en_page.orient) this._orient = crit.mise_en_page.orient;
      if (crit.mise_en_page.rowH) this._rowH = crit.mise_en_page.rowH;
      if (crit.mise_en_page.fontSize) this._fontSize = crit.mise_en_page.fontSize;
    }
    this._rebuildFilterUIFromState();
    this._refreshLayoutUI();
    this._renderColumns();
    await this._reload();
    this._selected = new Set(this._eleves.map(function(e){ return e.id; }).filter(function(id){ return ids.indexOf(id) >= 0; }));
    this._renderResults();
  },

  _rebuildFilterUIFromState() {
    const set = function(id, v){ const el = document.getElementById(id); if (el && v !== undefined && v !== null) el.value = v; };
    set('l-q', this._filters.q || ''); set('l-niveau', this._filters.niveau || ''); set('l-classe', this._filters.classe_id || ''); set('l-groupe', this._filters.groupe || '');
    if (this._filters.ulis === 0 || this._filters.ulis === 1) set('l-ulis', String(this._filters.ulis));
    set('l-droit', this._filters.droit_image || ''); set('l-transport', this._filters.transport || '');
    if (this._filters.cantine === 0 || this._filters.cantine === 1) set('l-cantine', String(this._filters.cantine));
    if (this._filters.pai === 0 || this._filters.pai === 1) set('l-pai', String(this._filters.pai));
    if (this._filters.allergies === 0 || this._filters.allergies === 1) set('l-allergies', String(this._filters.allergies));
    const inact = document.getElementById('l-inactifs'); if (inact) inact.checked = !!this._filters.inclure_inactifs;
  },

  async _deleteGroup() {
    const sel = document.getElementById('l-groupes'); if (!sel || !sel.value) return;
    if (!window.confirm('Supprimer ce groupe enregistré ?')) return;
    try {
      await API.del('groupes.php?id=' + sel.value);
      await this._loadOptions();
      sel.innerHTML = this._groupesSaved.map(function(g){ return '<option value="' + g.id + '">' + escapeHtml(g.nom) + '</option>'; }).join('');
    } catch (e) { console.error('[Listes] delete group:', e); }
  },
};