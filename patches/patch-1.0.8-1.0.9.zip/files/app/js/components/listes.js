
/**
 * Calulis — Lot 1 : Générateur de listes d'élèves multicritères
 * Filtres cumulés + cases à cocher + colonnes personnalisables + PDF paysage + CSV + groupes enregistrés.
 */
const Listes = {
  _classes: [],
  _groupes: [],
  _groupesSaved: [],
  _eleves: [],
  _selected: new Set(),
  _activeCols: ['numero','nom','prenom','classe','date_naissance','groupe','pai','allergies','tel','droit_image'],
  _filters: {},

  COLUMNS: {
    numero:        { label: 'N°',                  w: 24, get: function(e){ return e.numero || ''; } },
    nom:           { label: 'Nom',                 w: 78, get: function(e){ return e.nom || ''; } },
    prenom:        { label: 'Prénom',              w: 78, get: function(e){ return e.prenom || ''; } },
    classe:        { label: 'Classe',              w: 52, get: function(e){ return e.classe_nom || e.classe || ''; } },
    date_naissance:{ label: 'Naissance',           w: 60, get: function(e){ return formatDate(e.date_naissance); } },
    age:           { label: 'Âge',                 w: 30, get: function(e){ return Listes._age(e.date_naissance); } },
    groupe:        { label: 'Groupe',              w: 60, get: function(e){ return e.groupe || ''; } },
    niveau:        { label: 'Niveau',              w: 46, get: function(e){ return NIVEAU_LABELS[e.niveau_scolaire] || e.niveau_scolaire || ''; } },
    transport:     { label: 'Transport',           w: 70, get: function(e){ return e.transport || ''; } },
    cantine:       { label: 'Cantine',             w: 42, get: function(e){ return e.cantine ? 'Oui' : 'Non'; } },
    pai:           { label: 'PAI',                 w: 32, get: function(e){ return e.pai ? 'Oui' : 'Non'; } },
    allergies:     { label: 'Allergies',           w: 90, get: function(e){ return e.allergies || ''; } },
    regime:        { label: 'Régime',              w: 70, get: function(e){ return e.regime_alimentaire || e.regime_scolaire || ''; } },
    droit_image:   { label: 'Droit image',         w: 58, get: function(e){ return Listes._droitLabel(e.droit_image); } },
    tel:           { label: 'Tél. représentants',  w: 92, get: function(e){ return Listes._repsTel(e); } },
    prevenir:      { label: 'Personne à prévenir', w: 96, get: function(e){ return Listes._repsNom(e); } },
  },

  async render() {
    const view = document.getElementById('view-listes');
    view.innerHTML = '<div class="placeholder-view"><div class="placeholder-icon">⏳</div><div class="placeholder-title">Chargement…</div></div>';
    try { await this._loadOptions(); await this._reload(); }
    catch (e) { console.error('[Listes] load error:', e); }
    view.innerHTML = this._buildHTML();
    this._bindEvents();
    this._renderResults();
  },

  async _loadOptions() {
    const [opts, saved] = await Promise.all([ API.get('listes.php?action=options'), API.get('groupes.php') ]);
    this._classes = (opts && opts.classes) || [];
    this._groupes = (opts && opts.groupes) || [];
    this._groupesSaved = saved || [];
  },

  async _reload() {
    const qs = this._buildQuery();
    this._eleves = await API.get('listes.php' + (qs ? '?' + qs : ''));
    this._selected = new Set(this._eleves.map(function(e){ return e.id; }));
  },

  _buildQuery() {
    const f = this._filters, p = [];
    const add = function(k, v){ if (v !== undefined && v !== null && v !== '') p.push(k + '=' + encodeURIComponent(v)); };
    add('q', f.q); add('classe', f.niveau); add('classe_id', f.classe_id); add('groupe', f.groupe);
    if (f.ulis === 0 || f.ulis === 1) add('ulis', f.ulis);
    if (f.droit_image) add('droit_image', f.droit_image);
    if (f.transport === 'has') add('transport', 'has');
    if (f.cantine === 0 || f.cantine === 1) add('cantine', f.cantine);
    if (f.pai === 0 || f.pai === 1) add('pai', f.pai);
    if (f.allergies === 0 || f.allergies === 1) add('allergies', f.allergies);
    if (f.inclure_inactifs) add('inclure_inactifs', 1);
    return p.join('&');
  },

  _buildHTML() {
    const classesOpts = this._classes.map(function(c){ return '<option value="' + c.id + '">' + escapeHtml(c.nom) + '</option>'; }).join('');
    const niveauOpts = this._distinctNiveaux().map(function(n){ return '<option value="' + escapeHtml(n.raw) + '">' + escapeHtml(n.label) + '</option>'; }).join('');
    const groupeOpts = this._groupes.map(function(g){ return '<option value="' + escapeHtml(g) + '">' + escapeHtml(g) + '</option>'; }).join('');
    const groupesSavedOpts = this._groupesSaved.map(function(g){ return '<option value="' + g.id + '">' + escapeHtml(g.nom) + '</option>'; }).join('');
    const colOpts = Object.keys(this.COLUMNS).map(function(k){ const c = Listes.COLUMNS[k]; const on = Listes._activeCols.indexOf(k) >= 0; return '<label class="col-toggle"><input type="checkbox" data-col="' + k + '"' + (on ? ' checked' : '') + '> ' + escapeHtml(c.label) + '</label>'; }).join('');
    return '' +
    '<div class="print-header"><div class="print-tabs"><span class="print-tab active">📋 Listes</span></div><span class="text-muted" style="font-size:12px;white-space:nowrap">' + this._eleves.length + ' élève(s)</span></div>' +
    '<div class="print-layout"><div class="print-options-panel">' +
      '<div class="card"><h3 style="margin:0 0 6px 0">1. Filtres</h3>' +
        '<div class="form-row">' +
          '<div class="form-group"><label>Recherche</label><input type="text" id="l-q" class="filter-input" placeholder="Nom, prénom…" style="width:100%"></div>' +
          '<div class="form-group"><label>Niveau</label><select id="l-niveau" style="width:100%"><option value="">Tous</option>' + niveauOpts + '</select></div>' +
          '<div class="form-group"><label>Classe</label><select id="l-classe" style="width:100%"><option value="">Toutes</option>' + classesOpts + '</select></div>' +
          '<div class="form-group"><label>Groupe</label><select id="l-groupe" style="width:100%"><option value="">Tous</option>' + groupeOpts + '</select></div>' +
        '</div>' +
        '<div class="form-row">' +
          '<div class="form-group"><label>ULIS</label><select id="l-ulis" style="width:100%"><option value="">Tous</option><option value="1">Oui</option><option value="0">Non</option></select></div>' +
          '<div class="form-group"><label>Droit à l&#39;image</label><select id="l-droit" style="width:100%"><option value="">Tous</option><option value="autorise">Autorisé</option><option value="refuse">Refusé</option><option value="en_attente">En attente</option></select></div>' +
          '<div class="form-group"><label>Transport</label><select id="l-transport" style="width:100%"><option value="">Tous</option><option value="has">Avec transport</option></select></div>' +
          '<div class="form-group"><label>Cantine</label><select id="l-cantine" style="width:100%"><option value="">Tous</option><option value="1">Oui</option><option value="0">Non</option></select></div>' +
        '</div>' +
        '<div class="form-row">' +
          '<div class="form-group"><label>PAI</label><select id="l-pai" style="width:100%"><option value="">Tous</option><option value="1">Oui</option><option value="0">Non</option></select></div>' +
          '<div class="form-group"><label>Allergies</label><select id="l-allergies" style="width:100%"><option value="">Tous</option><option value="1">Avec</option><option value="0">Sans</option></select></div>' +
          '<div class="form-group" style="display:flex;align-items:flex-end"><label style="margin-bottom:6px"><input type="checkbox" id="l-inactifs"> Inclure inactifs</label></div>' +
        '</div>' +
        '<div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap"><button class="btn btn-sm btn-secondary" id="l-apply">🔍 Appliquer</button><button class="btn btn-sm btn-secondary" id="l-reset">↺ Réinitialiser</button></div>' +
      '</div>' +
      '<div class="card"><h3 style="margin:0 0 6px 0">2. Colonnes</h3><div class="col-grid">' + colOpts + '</div></div>' +
      '<div class="card"><h3 style="margin:0 0 6px 0">3. Groupes enregistrés</h3>' +
        '<div style="display:flex;gap:6px;margin-bottom:6px"><select id="l-groupes" style="flex:1">' + groupesSavedOpts + '</select><button class="btn btn-sm btn-secondary" id="l-group-load">Charger</button><button class="btn btn-sm btn-secondary" id="l-group-del">Suppr.</button></div>' +
        '<button class="btn btn-sm btn-primary" id="l-group-save">💾 Enregistrer ce groupe…</button>' +
      '</div>' +
      '<div class="card"><h3 style="margin:0 0 6px 0">4. Export</h3><button class="btn btn-primary" id="l-pdf" style="width:100%;margin-bottom:6px">🖨️ Télécharger PDF (paysage)</button><button class="btn btn-secondary" id="l-csv" style="width:100%">📥 Exporter CSV</button></div>' +
    '</div>' +
    '<div class="print-preview-panel"><div class="card" style="display:flex;flex-direction:column;height:100%">' +
      '<h3 style="margin:0 0 6px 0">Résultat</h3>' +
      '<div style="display:flex;gap:6px;margin-bottom:8px;align-items:center"><button class="btn btn-sm btn-secondary" id="l-all">Tout</button><button class="btn btn-sm btn-secondary" id="l-none">Aucun</button><span class="text-muted small" id="l-count" style="margin-left:auto"></span></div>' +
      '<div style="flex:1;overflow:auto;border:1px solid var(--border);border-radius:6px" id="l-results"></div>' +
    '</div></div>' +
    '</div>';
  },

  _distinctNiveaux() {
    const seen = {}, out = [];
    this._classes.forEach(function(c){
      const raw = c.niveaux; if (!raw || seen[raw]) return; seen[raw] = true;
      let label = raw;
      try { const arr = JSON.parse(raw); label = arr.map(function(n){ return NIVEAU_LABELS[n] || n; }).join(', '); } catch (e) {}
      out.push({ raw: raw, label: label });
    });
    return out;
  },

  _bindEvents() {
    const on = function(id, fn){ const el = document.getElementById(id); if (el) el.addEventListener('change', fn); };
    const onC = function(id, fn){ const el = document.getElementById(id); if (el) el.addEventListener('click', fn); };
    on('l-q', function(){ Listes._filters.q = document.getElementById('l-q').value.trim(); });
    on('l-niveau', function(){ Listes._filters.niveau = document.getElementById('l-niveau').value; });
    on('l-classe', function(){ Listes._filters.classe_id = document.getElementById('l-classe').value || ''; });
    on('l-groupe', function(){ Listes._filters.groupe = document.getElementById('l-groupe').value; });
    on('l-ulis', function(){ const v = document.getElementById('l-ulis').value; Listes._filters.ulis = v === '' ? '' : parseInt(v); });
    on('l-droit', function(){ Listes._filters.droit_image = document.getElementById('l-droit').value; });
    on('l-transport', function(){ Listes._filters.transport = document.getElementById('l-transport').value; });
    on('l-cantine', function(){ const v = document.getElementById('l-cantine').value; Listes._filters.cantine = v === '' ? '' : parseInt(v); });
    on('l-pai', function(){ const v = document.getElementById('l-pai').value; Listes._filters.pai = v === '' ? '' : parseInt(v); });
    on('l-allergies', function(){ const v = document.getElementById('l-allergies').value; Listes._filters.allergies = v === '' ? '' : parseInt(v); });
    on('l-inactifs', function(){ Listes._filters.inclure_inactifs = document.getElementById('l-inactifs').checked; });
    onC('l-apply', function(){ Listes._apply(); });
    onC('l-reset', function(){ Listes._reset(); });
    onC('l-all', function(){ Listes._selectAll(true); });
    onC('l-none', function(){ Listes._selectAll(false); });
    onC('l-pdf', function(){ Listes._exportPDF(); });
    onC('l-csv', function(){ Listes._exportCSV(); });
    onC('l-group-save', function(){ Listes._saveGroup(); });
    onC('l-group-load', function(){ Listes._loadGroup(); });
    onC('l-group-del', function(){ Listes._deleteGroup(); });
    document.querySelectorAll('[data-col]').forEach(function(cb){
      cb.addEventListener('change', function(){
        const k = cb.dataset.col;
        if (cb.checked) Listes._activeCols.push(k);
        else Listes._activeCols = Listes._activeCols.filter(function(x){ return x !== k; });
        Listes._renderResults();
      });
    });
    const q = document.getElementById('l-q');
    if (q) q.addEventListener('keydown', function(ev){ if (ev.key === 'Enter') Listes._apply(); });
  },

  async _apply() { await this._reload(); this._renderResults(); },
  async _reset() {
    this._filters = {};
    ['l-q','l-niveau','l-classe','l-groupe','l-ulis','l-droit','l-transport','l-cantine','l-pai','l-allergies'].forEach(function(id){ const el = document.getElementById(id); if (el) el.value = ''; });
    const inact = document.getElementById('l-inactifs'); if (inact) inact.checked = false;
    await this._reload(); this._renderResults();
  },
  _selectAll(all) { this._eleves.forEach(function(e){ all ? Listes._selected.add(e.id) : Listes._selected.delete(e.id); }); this._renderResults(); },

  _renderResults() {
    const box = document.getElementById('l-results'); if (!box) return;
    const cols = this._activeCols.filter(function(k){ return Listes.COLUMNS[k]; });
    let html = '<table class="filter-table"><thead><tr><th style="width:26px"></th>';
    cols.forEach(function(k){ html += '<th>' + escapeHtml(Listes.COLUMNS[k].label) + '</th>'; });
    html += '</tr></thead><tbody>';
    this._eleves.forEach(function(e){
      const chk = Listes._selected.has(e.id) ? ' checked' : '';
      html += '<tr class="list-row" data-id="' + e.id + '"><td><input type="checkbox" class="l-row" data-id="' + e.id + '"' + chk + '></td>';
      cols.forEach(function(k){ html += '<td>' + escapeHtml(String((Listes.COLUMNS[k].get(e) || '') + '')) + '</td>'; });
      html += '</tr>';
    });
    html += '</tbody></table>';
    box.innerHTML = html;
    box.querySelectorAll('.l-row').forEach(function(cb){
      cb.addEventListener('change', function(){
        const id = parseInt(cb.dataset.id);
        if (cb.checked) Listes._selected.add(id); else Listes._selected.delete(id);
        const c = document.getElementById('l-count'); if (c) c.textContent = Listes._selected.size + ' sélectionné(s)';
      });
    });
    const count = document.getElementById('l-count'); if (count) count.textContent = this._selected.size + ' sélectionné(s)';
    if (typeof linkLabels === 'function') linkLabels(box);
  },

  _droitLabel: function(d){ const m = { autorise: '✅ Autorisé', refuse: '⛔ Refusé', limite: '⚠️ Limité', en_attente: '⏳ En attente', retire: '↩️ Retiré' }; return d ? (m[d.statut] || d.statut) : '—'; },
  _repsTel: function(e){ return (e.representants || []).map(function(r){ return r.telephone || r.telephone_urgence || ''; }).filter(Boolean).join(' / '); },
  _repsNom: function(e){ return (e.representants || []).map(function(r){ return (r.prenom ? r.prenom + ' ' : '') + (r.nom || ''); }).join(', '); },
  _age: function(birth){ if (!birth) return ''; const b = new Date(birth + 'T00:00:00'); const now = new Date(); let a = now.getFullYear() - b.getFullYear(); if (a < 0) return ''; const m = now.getMonth() - b.getMonth(); if (m < 0 || (m === 0 && now.getDate() < b.getDate())) a--; return a >= 0 ? a : ''; },

  async _exportPDF() {
    const ids = this._selected.size ? Array.from(this._selected) : this._eleves.map(function(e){ return e.id; });
    const sel = this._eleves.filter(function(e){ return ids.indexOf(e.id) >= 0; });
    if (!sel.length) { if (typeof Modal !== 'undefined' && Modal.alert) Modal.alert('Export', 'Aucun élève sélectionné.'); return; }
    const cols = this._activeCols.filter(function(k){ return Listes.COLUMNS[k]; });
    const header = cols.map(function(k){ return { text: Listes.COLUMNS[k].label, style: 'tableHeader' }; });
    const body = [header];
    sel.forEach(function(e){ body.push(cols.map(function(k){ return { text: String(Listes.COLUMNS[k].get(e) || ''), style: 'cell' }; })); });
    const avail = 774;
    const widthSum = cols.reduce(function(s,k){ return s + Listes.COLUMNS[k].w; }, 0);
    const widths = cols.map(function(k){ return Math.max(24, Math.round(Listes.COLUMNS[k].w * (avail / widthSum))); });
    const def = {
      pageSize: 'A4', pageOrientation: 'landscape', pageMargins: [12,12,12,12],
      content: [
        { text: 'Liste des élèves', style: 'header' },
        { text: (Listes._filters.q ? 'Recherche : ' + Listes._filters.q + ' · ' : '') + sel.length + ' élève(s) · ' + new Date().toLocaleDateString('fr-FR'), style: 'subheader' },
        { table: { headerRows: 1, widths: widths, body: body, dontBreakRows: true }, fontSize: 7.5 },
      ],
      styles: {
        header: { fontSize: 14, bold: true, alignment: 'center', margin: [0,0,0,4] },
        subheader: { fontSize: 9, alignment: 'center', color: '#666', margin: [0,0,0,8] },
        tableHeader: { fontSize: 7.5, bold: true, fillColor: '#eee', alignment: 'center' },
        cell: { fontSize: 7.5, margin: [1,1] },
      },
    };
    if (typeof pdfMake !== 'undefined') pdfMake.createPdf(def).download('liste_eleves_' + new Date().toISOString().slice(0,10) + '.pdf');
  },

  async _exportCSV() {
    const ids = this._selected.size ? Array.from(this._selected) : this._eleves.map(function(e){ return e.id; });
    const sel = this._eleves.filter(function(e){ return ids.indexOf(e.id) >= 0; });
    if (!sel.length) { if (typeof Modal !== 'undefined' && Modal.alert) Modal.alert('Export', 'Aucun élève sélectionné.'); return; }
    const cols = this._activeCols.filter(function(k){ return Listes.COLUMNS[k]; });
    const headers = cols.map(function(k){ return Listes.COLUMNS[k].label; });
    const rows = sel.map(function(e){ const r = {}; cols.forEach(function(k){ r[Listes.COLUMNS[k].label] = String(Listes.COLUMNS[k].get(e) || ''); }); return r; });
    exportCSV('liste_eleves_' + new Date().toISOString().slice(0,10) + '.csv', headers, rows);
  },

  async _saveGroup() {
    const nom = window.prompt('Nom du groupe enregistré :'); if (!nom) return;
    const ids = this._selected.size ? Array.from(this._selected) : [];
    try {
      await API.post('groupes.php', { nom: nom, criteres: Object.assign({}, this._filters), eleves_ids: ids });
      await this._loadOptions();
      const sel = document.getElementById('l-groupes');
      if (sel) sel.innerHTML = this._groupesSaved.map(function(g){ return '<option value="' + g.id + '">' + escapeHtml(g.nom) + '</option>'; }).join('');
    } catch (e) { console.error('[Listes] save group:', e); }
  },

  async _loadGroup() {
    const sel = document.getElementById('l-groupes'); if (!sel || !sel.value) return;
    const g = this._groupesSaved.find(function(x){ return String(x.id) === sel.value; }); if (!g) return;
    let ids = []; try { ids = JSON.parse(g.eleves_ids || '[]'); } catch (e) {}
    let crit = {}; try { crit = JSON.parse(g.criteres || '{}'); } catch (e) {}
    this._filters = crit || {};
    this._rebuildFilterUIFromState();
    await this._reload();
    this._selected = new Set(this._eleves.map(function(e){ return e.id; }).filter(function(id){ return ids.indexOf(id) >= 0; }));
    this._renderResults();
  },

  _rebuildFilterUIFromState() {
    const set = function(id, v){ const el = document.getElementById(id); if (el && v !== undefined && v !== null) el.value = v; };
    set('l-q', this._filters.q || ''); set('l-niveau', this._filters.niveau || ''); set('l-classe', this._filters.classe_id || ''); set('l-groupe', this._filters.groupe || '');
    if (this._filters.ulis === 0 || this._filters.ulis === 1) set('l-ulis', String(this._filters.ulis));
    set('l-droit', this._filters.droit_image || ''); set('l-transport', this._filters.transport || '');
    if (this._filters.cantine === 0 || this._filters.cantine === 1) set('l-cantine', String(this._filters.cantine));
    if (this._filters.pai === 0 || this._filters.pai === 1) set('l-pai', String(this._filters.pai));
    if (this._filters.allergies === 0 || this._filters.allergies === 1) set('l-allergies', String(this._filters.allergies));
    const inact = document.getElementById('l-inactifs'); if (inact) inact.checked = !!this._filters.inclure_inactifs;
  },

  async _deleteGroup() {
    const sel = document.getElementById('l-groupes'); if (!sel || !sel.value) return;
    if (!window.confirm('Supprimer ce groupe enregistré ?')) return;
    try {
      await API.del('groupes.php?id=' + sel.value);
      await this._loadOptions();
      sel.innerHTML = this._groupesSaved.map(function(g){ return '<option value="' + g.id + '">' + escapeHtml(g.nom) + '</option>'; }).join('');
    } catch (e) { console.error('[Listes] delete group:', e); }
  },
};
