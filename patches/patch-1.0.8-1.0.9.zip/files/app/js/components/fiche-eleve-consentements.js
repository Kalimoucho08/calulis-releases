
/**
 * Calulis — Lot 1 : Droit à l'image (consentements) dans la fiche élève
 * Greffé sur FicheEleve. Ajoute une section « Droit à l'image » dans l'onglet Médical.
 */
Object.assign(FicheEleve, {

  _loadDroitImage() {
    if (!this._eleve || !this._eleve.id) return;
    API.get('consentements.php?eleve_id=' + this._eleve.id + '&type=droit_image').then(items => {
      const latest = (items && items.length) ? items[items.length - 1] : null;
      const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = (v || ''); };
      set('di-statut', latest ? latest.statut : '');
      set('di-date_debut', latest ? latest.date_debut : '');
      set('di-date_fin', latest ? latest.date_fin : '');
      set('di-document_reference', latest ? latest.document_reference : '');
      set('di-commentaires', latest ? latest.commentaires : '');
    }).catch(e => console.error('[FicheEleve] load droit image:', e));
  },

  _getDroitImageFromDOM() {
    const statut = (document.getElementById('di-statut') || {}).value || '';
    if (!statut) return null;
    return {
      type: 'droit_image',
      statut,
      date_debut: (document.getElementById('di-date_debut') || {}).value || '',
      date_fin: (document.getElementById('di-date_fin') || {}).value || '',
      document_reference: (document.getElementById('di-document_reference') || {}).value || '',
      commentaires: (document.getElementById('di-commentaires') || {}).value || '',
    };
  },

  async _saveDroitImage(eleveId) {
    // Remplacer le droit à l'image existant (sans toucher aux autres types de consentement)
    const existing = await API.get('consentements.php?eleve_id=' + eleveId + '&type=droit_image');
    for (const c of (existing || [])) {
      await API.del('consentements.php?id=' + c.id);
    }
    const di = this._getDroitImageFromDOM();
    if (di && di.statut) {
      await API.post('consentements.php', Object.assign({ eleve_id: eleveId }, di));
    }
  },

});
