/**
 * Calulis — Changelog (Nouveautés)
 * Résumé des nouveautés depuis la v1.0. À mettre à jour à CHAQUE release
 * (voir scripts/release-checklist.sh — étape « quoi de neuf »).
 * NOTE : utiliser l'apostrophe typographique ' (U+2019) dans les textes —
 * jamais l'apostrophe droite ' qui casse les chaînes JS.
 */
const Changelog = {
    /** Dernière version connue (mise à jour à chaque release) */
    latest: '1.0.9',
    /** Entrées de la plus récente à la plus ancienne */
    entries: [
        {
            version: '1.0.9', date: '1 septembre 2026',
            items: [
                'Faites vos listes d’élèves en un clic : filtrez (niveau, classe, groupe, ULIS, cantine, transport, PAI, allergies, droit à l’image), cochez, choisissez les colonnes, et exportez en PDF paysage ou CSV',
                'Enregistrez des groupes d’élèves (ex. « Sortie piscine ») pour les réutiliser toute l’année',
                'Fiche de renseignements et fiche d’urgence imprimable pour un élève ou pour toute une liste (mention confidentielle)',
                'Suivi du droit à l’image par élève : autorisé, refusé, en attente, avec dates et document signé',
                'Les pauses sont plus simples : un bouton « Pause » dans l’agenda, et deux couleurs pour la récréation et le midi',
                'Calendrier scolaire corrigé : la dernière semaine de classe ne disparaît plus dans les vacances',
                'Correction : la fiche d’un élève s’ouvre à nouveau correctement',
            ],
        },
        {
            version: '1.0.8', date: '31 août 2026',
            items: [
                'Plusieurs enseignants par classe, avec leurs jours et leurs demi-journées (postes partagés)',
                'Copier un créneau sur plusieurs jours en une seule fois (ex. : un rituel tous les matins)',
                'Avertissement quand on colle un créneau sur une case déjà occupée',
                'Numéro pour chaque élève, affiché et utilisé pour classer le calendrier',
                'Correction de la propagation du modèle vers des semaines choisies',
                'Correction du déplacement de bloc de créneaux (tout le bloc se déplace)',
                'Adresse de signalement de bug réglable dans les Paramètres',
            ],
        },
        {
            version: '1.0.7', date: '27 août 2026',
            items: [
                'Mise à jour plus fiable : le lanceur peut se mettre à jour depuis un second serveur (pCloud) si le premier est indisponible',
                'Le lanceur se réduit dans la barre d’état système (en bas à droite) — Calulis continue de tourner',
                'Messages plus simples et plus rassurants, moins de jargon technique',
                'Un bouton « Vérifier la mise à jour » permet de rechercher une version sans redémarrer',
                'Les champs de saisie limitent automatiquement leur longueur (plus d’erreur « données non enregistrées »)',
                'Accessibilité améliorée : les champs sont correctement étiquetés pour les lecteurs d’écran',
            ],
        },
        {
            version: '1.0.6', date: '26 août 2026',
            items: [
                'Protection renforcée : vos données ne peuvent plus être modifiées par une page web externe (sécurité CSRF)',
                'Sauvegarde plus fiable : plus d’erreurs d’enregistrement mystérieuses quand un champ est trop long (ils sont tronqués proprement)',
                'Les erreurs techniques sont maintenant journalisées pour un dépannage plus rapide',
                'Correction de l’affichage de la version (1.0.5 s’affichait à tort)',
            ],
        },
        {
            version: '1.0.5', date: '26 août 2026',
            items: [
                'Rattachement d’un élève à une classe corrigé (l’enregistrement échouait avec une erreur de base de données)',
            ],
        },
        {
            version: '1.0.4', date: '19 août 2026',
            items: [
                'Messages d’erreur enfin compréhensibles : plus de « Internal Server Error », Calulis explique quoi faire',
                'Bouton « Signaler un bug » sur les écrans d’erreur (infos techniques envoyées à l’équipe)',
                'Lanceur : bouton « Copier le rapport », aide intégrée, erreurs de démarrage claires',
                'Le lanceur se met à jour automatiquement, comme l’application',
                'Version de l’application affichée + cette page « Quoi de neuf »',
            ],
        },
        {
            version: '1.0.3', date: '17 août 2026',
            items: [
                'Calendrier scolaire (vacances) réparé sur toutes les machines Windows',
                'Messages d’erreur qui guident (connexion, certificat, DNS…)',
                'Les pages se rafraîchissent correctement après chaque mise à jour',
            ],
        },
        {
            version: '1.0.2', date: '17 août 2026',
            items: [
                'Établissements : ensembles scolaires, statut public/privé',
                'Tous les niveaux : maternelle, élémentaire, collège (6e→3e), lycée, lycée professionnel',
                'Création d’élève guidée (bouton « + Créer » pour l’établissement manquant)',
            ],
        },
        {
            version: '1.0.1', date: '16 août 2026',
            items: [
                'Correction du bug « ID requis » (modification/suppression élève, adulte, classe)',
            ],
        },
        {
            version: '1.0.0', date: '10 août 2026',
            items: [
                'Première version portable, sans installation : élèves, emploi du temps, réunions, annuaire, impression PDF',
                'Mises à jour automatiques, sauvegarde/restauration des données',
            ],
        },
    ],
};