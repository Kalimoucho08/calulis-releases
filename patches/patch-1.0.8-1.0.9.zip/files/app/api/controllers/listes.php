<?php
/** Calulis — Controller Liste (générateur de listes d'élèves multicritères, Lot 1) */
require_once __DIR__ . '/../models/Liste.php';

$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method !== 'GET') {
        jsonError('Méthode non supportée', 405);
    }

    $anneeId = isset($_GET['annee_scolaire_id']) ? (int)$_GET['annee_scolaire_id'] : null;

    // Action « options » : alimente les filtres du générateur de listes
    if (($_GET['action'] ?? '') === 'options') {
        $pdo = getDB();
        $classes = $pdo->query('SELECT id, nom, niveaux FROM classes ORDER BY nom')->fetchAll();
        if ($anneeId !== null) {
            $stmt = $pdo->prepare('SELECT DISTINCT ea.groupe FROM eleve_annees ea WHERE ea.groupe IS NOT NULL AND ea.groupe <> \'\' AND ea.annee_scolaire_id = :annee ORDER BY ea.groupe');
            $stmt->execute(['annee' => $anneeId]);
        } else {
            $stmt = $pdo->query('SELECT DISTINCT ea.groupe FROM eleve_annees ea WHERE ea.groupe IS NOT NULL AND ea.groupe <> \'\' ORDER BY ea.groupe');
        }
        $groupes = array_column($stmt->fetchAll(), 'groupe');
        jsonResponse(['classes' => $classes, 'groupes' => $groupes]);
    }

    $filters = [
        'q'               => isset($_GET['q']) ? trim((string)$_GET['q']) : '',
        'classe'          => isset($_GET['classe']) ? trim((string)$_GET['classe']) : '',
        'classe_id'       => isset($_GET['classe_id']) ? (int)$_GET['classe_id'] : null,
        'groupe'          => isset($_GET['groupe']) ? trim((string)$_GET['groupe']) : '',
        'ulis'            => isset($_GET['ulis']) && $_GET['ulis'] !== '' ? (int)$_GET['ulis'] : null,
        'transport'       => isset($_GET['transport']) ? trim((string)$_GET['transport']) : '',
        'cantine'         => isset($_GET['cantine']) && $_GET['cantine'] !== '' ? (int)$_GET['cantine'] : null,
        'pai'             => isset($_GET['pai']) && $_GET['pai'] !== '' ? (int)$_GET['pai'] : null,
        'allergies'       => isset($_GET['allergies']) && $_GET['allergies'] !== '' ? (int)$_GET['allergies'] : null,
        'droit_image'     => isset($_GET['droit_image']) ? trim((string)$_GET['droit_image']) : '',
        'inclure_inactifs'=> isset($_GET['inclure_inactifs']) ? (bool)$_GET['inclure_inactifs'] : false,
        'ids'             => isset($_GET['ids']) ? array_filter(array_map('intval', explode(',', $_GET['ids']))) : null,
    ];

    $eleves = Liste::get($filters, $anneeId);
    jsonResponse($eleves);
} catch (\Throwable $e) {
    calulis_handle_error($e);
}