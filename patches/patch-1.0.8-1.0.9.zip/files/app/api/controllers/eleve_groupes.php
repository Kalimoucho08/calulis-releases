<?php
/** Calulis — Controller Groupes d'élève (multi-groupes libres) */
require_once __DIR__ . '/../models/EleveGroupe.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$eleveId = isset($_GET['eleve_id']) ? (int)$_GET['eleve_id'] : null;
$anneeId = isset($_GET['annee_scolaire_id']) ? (int)$_GET['annee_scolaire_id'] : null;

try {
    switch ($method) {
        case 'GET':
            if (!$eleveId) jsonError('eleve_id requis');
            jsonResponse(EleveGroupe::getByEleve($eleveId, $anneeId));
            break;
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (empty($input['eleve_id'])) jsonError('eleve_id requis');
            if (empty($input['nom'])) jsonError('Nom de groupe requis');
            $newId = EleveGroupe::create($input);
            jsonResponse(['ok' => true, 'id' => $newId], 201);
            break;
        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            if (!$id) jsonError('ID requis');
            EleveGroupe::update($id, $input);
            jsonResponse(['ok' => true]);
            break;
        case 'DELETE':
            if ($eleveId) {
                EleveGroupe::deleteByEleve($eleveId, $anneeId);
                jsonResponse(['ok' => true]);
            }
            if (!$id) jsonError('ID ou eleve_id requis');
            EleveGroupe::delete($id);
            jsonResponse(['ok' => true]);
            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
