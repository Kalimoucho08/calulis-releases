<?php
/** Calulis — Controller Consentements (droit à l'image, sorties, soins...) */
require_once __DIR__ . '/../models/Consentement.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$eleveId = isset($_GET['eleve_id']) ? (int)$_GET['eleve_id'] : null;
$type = isset($_GET['type']) ? trim((string)$_GET['type']) : null;

try {
    switch ($method) {

        case 'GET':
            if ($id) {
                $c = Consentement::find($id);
                if (!$c) jsonError('Consentement non trouvé', 404);
                jsonResponse($c);
            }
            if (isset($_GET['eleve_ids'])) {
                $ids = array_filter(array_map('intval', explode(',', $_GET['eleve_ids'])), fn($v) => $v > 0);
                $types = isset($_GET['types']) ? array_filter(explode(',', $_GET['types'])) : null;
                jsonResponse(Consentement::forEleves($ids, $types));
            }
            if ($eleveId) {
                jsonResponse(Consentement::getByEleve($eleveId, $type));
            }
            jsonError('eleve_id, eleve_ids ou id requis');

            break;
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (empty($input['eleve_id'])) jsonError('eleve_id requis');
            if (empty($input['type'])) jsonError('type requis');
            if (!in_array($input['type'], Consentement::TYPES, true)) {
                jsonError('Type de consentement inconnu : ' . $input['type']);
            }
            if (!empty($input['statut']) && !in_array($input['statut'], Consentement::STATUTS, true)) {
                jsonError('Statut de consentement inconnu : ' . $input['statut']);
            }
            $newId = Consentement::create($input);
            jsonResponse(['ok' => true, 'id' => $newId], 201);

            break;
        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            if (!$id) jsonError('ID requis');
            Consentement::update($id, $input);
            jsonResponse(['ok' => true]);

            break;
        case 'DELETE':
            if ($eleveId) {
                Consentement::deleteByEleve($eleveId);
                jsonResponse(['ok' => true]);
            }
            if (!$id) jsonError('ID ou eleve_id requis');
            Consentement::delete($id);
            jsonResponse(['ok' => true]);

            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
