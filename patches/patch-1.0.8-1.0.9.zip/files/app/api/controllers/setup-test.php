<?php
/**
 * Setup base de données test — ULIS école primaire réaliste
 * 12 élèves, 8 adultes, emploi du temps complet
 */
require_once __DIR__ . '/../config.php';

$pdo = getDB();

echo "=== Création base test ULIS ===\n";

// 1. Nettoyer la base
$pdo->exec('DELETE FROM creneaux');
$pdo->exec('DELETE FROM adultes');
$pdo->exec('DELETE FROM eleves');
$pdo->exec('DELETE FROM semaines');
$pdo->exec('DELETE FROM periodes');
$pdo->exec('DELETE FROM parametres');
$pdo->exec('DELETE FROM pauses');
$pdo->exec('DELETE FROM vacances');
echo "✓ Base nettoyée\n";

// 2. Paramètres globaux
$params = [
    ['couleurs_types', '{"ULIS":"#bbdefb","INCLUSION":"#c8e6c9","DECLOISONNEMENT":"#fff9c4","PEC":"#ffccbc","RECREATION":"#ffe0b2","PAUSE MIDI":"#d7ccc8","AUTRE":"#e0e0e0"}'],
    ['theme', '"clair"'],
    ['horaires', '{"debut":"08:30","fin":"16:30","duree_creneau":15}'],
    ['jours_affiches', '["lundi","mardi","jeudi","vendredi"]'],
    ['format_semaine', '"scolaire"'],
];
$stmt = $pdo->prepare('INSERT INTO parametres (cle, valeur) VALUES (?, ?)');
foreach ($params as $p) $stmt->execute($p);
echo "✓ Paramètres\n";

// 3. Année scolaire et semaines
$pdo->exec("INSERT INTO annees_scolaires (nom, date_debut, date_fin, est_active) VALUES ('2026-2027', '2026-08-31', '2027-07-04', 1)");
$anneeId = (int)$pdo->lastInsertId();

// Générer 36 semaines scolaires (avec vacances Toussaint, Noël, Hiver, Printemps)
$semaines = [];
$debut = new DateTime('2026-08-31');
for ($i = 1; $i <= 36; $i++) {
    $fin = clone $debut;
    $fin->modify('+4 days');
    $semaines[] = [
        'numero' => $i,
        'date_debut' => $debut->format('Y-m-d'),
        'date_fin' => $fin->format('Y-m-d'),
        'annee_scolaire_id' => $anneeId,
        // Vacances : Toussaint S7-8, Noël S16-17, Hiver S25-26, Printemps S33-34
        'est_vacances' => in_array($i, [7,8,16,17,25,26,33,34]) ? 1 : 0,
    ];
    $debut->modify('+7 days');
}
$stmt = $pdo->prepare('INSERT INTO semaines (numero, date_debut, date_fin, annee_scolaire_id, est_vacances) VALUES (?,?,?,?,?)');
foreach ($semaines as $s) $stmt->execute([$s['numero'], $s['date_debut'], $s['date_fin'], $s['annee_scolaire_id'], $s['est_vacances']]);
echo "✓ 36 semaines\n";

// 4. Périodes (5 périodes scolaires)
$periodes = [
    ['Période 1', '2026-08-31', '2026-10-16'],
    ['Période 2', '2026-11-02', '2026-12-18'],
    ['Période 3', '2027-01-04', '2027-02-12'],
    ['Période 4', '2027-03-08', '2027-04-09'],
    ['Période 5', '2027-04-26', '2027-07-04'],
];
$stmt = $pdo->prepare('INSERT INTO periodes (annee_scolaire_id, nom, date_debut, date_fin, ordre) VALUES (?,?,?,?,?)');
foreach ($periodes as $i => $p) $stmt->execute([$anneeId, $p[0], $p[1], $p[2], $i+1]);
echo "✓ 5 périodes\n";

// 5. Élèves (12 — ULIS primaire)
$eleves = [
    // CP
    ['nom' => 'Lemoine', 'prenom' => 'Léa', 'classe' => 'CP', 'ulis' => 1, 'groupe' => 'CP', 'niveau_scolaire' => 'CP', 'date_naissance' => '2019-05-12', 'transport' => 'Car'],
    ['nom' => 'Moreau', 'prenom' => 'Thomas', 'classe' => 'CP', 'ulis' => 1, 'groupe' => 'CP', 'niveau_scolaire' => 'CP', 'date_naissance' => '2019-09-03', 'cantine' => 1],
    ['nom' => 'Petit', 'prenom' => 'Emma', 'classe' => 'CP', 'ulis' => 1, 'groupe' => 'CP', 'niveau_scolaire' => 'CP', 'date_naissance' => '2019-02-28', 'transport' => 'Taxi', 'cantine' => 1],
    // CE1
    ['nom' => 'Garcia', 'prenom' => 'Noah', 'classe' => 'CE1', 'ulis' => 1, 'groupe' => 'CE1', 'niveau_scolaire' => 'CE1', 'date_naissance' => '2018-07-14', 'cantine' => 1],
    ['nom' => 'Dubois', 'prenom' => 'Inès', 'classe' => 'CE1', 'ulis' => 1, 'groupe' => 'CE1', 'niveau_scolaire' => 'CE1', 'date_naissance' => '2018-11-22', 'transport' => 'Car'],
    ['nom' => 'Bernard', 'prenom' => 'Lucas', 'classe' => 'CE1', 'ulis' => 1, 'groupe' => 'CE1', 'niveau_scolaire' => 'CE1', 'date_naissance' => '2017-12-05', 'cantine' => 1, 'aesh_type' => 'AESHco', 'aesh_nom' => 'Sophie'],
    // CE2
    ['nom' => 'Martin', 'prenom' => 'Chloé', 'classe' => 'CE2', 'ulis' => 1, 'groupe' => 'CE2', 'niveau_scolaire' => 'CE2', 'date_naissance' => '2017-03-18', 'cantine' => 1],
    ['nom' => 'Robert', 'prenom' => 'Hugo', 'classe' => 'CE2', 'ulis' => 1, 'groupe' => 'CE2', 'niveau_scolaire' => 'CE2', 'date_naissance' => '2016-09-30', 'transport' => 'Car', 'cantine' => 1, 'pec_specialite' => 'orthophoniste', 'pec_organisme' => 'prive', 'pec_frequence' => 'hebdomadaire'],
    ['nom' => 'Durand', 'prenom' => 'Maëlys', 'classe' => 'CE2', 'ulis' => 1, 'groupe' => 'CE2', 'niveau_scolaire' => 'CE2', 'date_naissance' => '2017-06-08', 'cantine' => 1, 'pec_specialite' => 'psychologue', 'pec_organisme' => 'CMPP', 'pec_frequence' => 'mensuel'],
    // CM1
    ['nom' => 'Leroy', 'prenom' => 'Mathis', 'classe' => 'CM1', 'ulis' => 1, 'groupe' => 'CM', 'niveau_scolaire' => 'CM1', 'date_naissance' => '2016-01-15', 'cantine' => 1],
    ['nom' => 'Simon', 'prenom' => 'Jade', 'classe' => 'CM1', 'ulis' => 1, 'groupe' => 'CM', 'niveau_scolaire' => 'CM1', 'date_naissance' => '2015-08-22', 'transport' => 'Taxi', 'cantine' => 1, 'aesh_type' => 'AESHi', 'aesh_nom' => 'Sophie', 'pec_specialite' => 'orthophoniste', 'pec_organisme' => 'prive', 'pec_frequence' => 'hebdomadaire'],
    // CM2
    ['nom' => 'Laurent', 'prenom' => 'Noé', 'classe' => 'CM2', 'ulis' => 1, 'groupe' => 'CM', 'niveau_scolaire' => 'CM2', 'date_naissance' => '2015-04-30', 'cantine' => 1, 'pec_specialite' => 'psychologue', 'pec_organisme' => 'CMPP', 'pec_frequence' => 'mensuel'],
];

$stmt = $pdo->prepare('INSERT INTO eleves (nom, prenom, classe, ulis, groupe, niveau_scolaire, date_naissance, transport, cantine, aesh_type, aesh_nom, pec_specialite, pec_organisme, pec_frequence, ordre, actif) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)');
foreach ($eleves as $i => $e) {
    $stmt->execute([
        $e['nom'], $e['prenom'], $e['classe'], $e['ulis'], $e['groupe'] ?? '', $e['niveau_scolaire'] ?? '',
        $e['date_naissance'] ?? null, $e['transport'] ?? '', $e['cantine'] ?? 0,
        $e['aesh_type'] ?? '', $e['aesh_nom'] ?? '', $e['pec_specialite'] ?? '', $e['pec_organisme'] ?? '', $e['pec_frequence'] ?? '',
        $i
    ]);
}
echo "✓ 12 élèves\n";

// 6. Adultes (8)
$adultes = [
    ['nom' => 'M. Dupont', 'role' => 'enseignant', 'ordre' => 0],
    ['nom' => 'Mme Martin', 'role' => 'enseignant', 'ordre' => 1],
    ['nom' => 'Mme Bernard', 'role' => 'enseignant', 'ordre' => 2],
    ['nom' => 'M. Petit', 'role' => 'enseignant', 'ordre' => 3],
    ['nom' => 'Mme Robert', 'role' => 'enseignant', 'ordre' => 4],
    ['nom' => 'Sophie', 'role' => 'aeshco', 'ordre' => 5],
    ['nom' => 'Dr. Laurent', 'role' => 'specialiste', 'ordre' => 6],
    ['nom' => 'Mme Legrand', 'role' => 'specialiste', 'ordre' => 7],
];
$stmt = $pdo->prepare('INSERT INTO adultes (nom, role, ordre) VALUES (?,?,?)');
foreach ($adultes as $a) $stmt->execute([$a['nom'], $a['role'], $a['ordre']]);
echo "✓ 8 adultes\n";

// 7. Récupérer les IDs
$elevesIds = $pdo->query('SELECT id, prenom, classe, groupe FROM eleves ORDER BY id')->fetchAll();
$adultesIds = $pdo->query('SELECT id, nom, role FROM adultes ORDER BY id')->fetchAll();

// 8. Créneaux — Template semaine type (semaine_id=NULL)
// Fonction helper pour créer un créneau
function creneau($eleve_id, $jour, $heure, $duree, $matiere, $adulte, $role, $groupe, $type_regroupement, $groupe_eleve = '', $commentaire = '') {
    global $pdo;
    $type = in_array($matiere, ['Récréation', 'Cantine']) ? 'pause' : 'fixe';
    $couleur = null;
    if ($type === 'pause') $couleur = '#e8e8e8';
    if ($type_regroupement === 'PEC') $couleur = '#ffccbc';

    $stmt = $pdo->prepare('INSERT INTO creneaux (eleve_id, semaine_id, jour, heure_debut, duree, matiere, groupe, adulte, role_adulte, type, regroupement_type, couleur_override, commentaire) VALUES (?, NULL, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
    $stmt->execute([$eleve_id, $jour, $heure, $duree, $matiere, $groupe_eleve, $adulte, $role, $type, $type_regroupement, $couleur, $commentaire]);
}

// Helper: créer pour un groupe d'élèves
function creneauGroupe($elevesIds, $jour, $heure, $duree, $matiere, $adulte, $role, $groupe_label, $type_regroupement, $commentaire = '') {
    foreach ($elevesIds as $eid) {
        creneau($eid, $jour, $heure, $duree, $matiere, $adulte, $role, $groupe_label, $type_regroupement, '', $commentaire);
    }
}

$tous = array_column($elevesIds, 'id');
$cp = array_column(array_filter($elevesIds, fn($e) => $e['groupe'] === 'CP'), 'id');
$ce1 = array_column(array_filter($elevesIds, fn($e) => $e['groupe'] === 'CE1'), 'id');
$ce2 = array_column(array_filter($elevesIds, fn($e) => $e['groupe'] === 'CE2'), 'id');
$cm = array_column(array_filter($elevesIds, fn($e) => $e['groupe'] === 'CM'), 'id');
$ce1ce2 = array_merge($ce1, $ce2);
$cpce1 = array_merge($cp, $ce1);

// Noms des adultes
$ulis = 'M. Dupont';
$cpRef = 'Mme Martin';
$ce1Ref = 'Mme Bernard';
$ce2Ref = 'M. Petit';
$cmRef = 'Mme Robert';
$sessad = 'Sophie';
$psy = 'Dr. Laurent';
$ortho = 'Mme Legrand';

$jours = ['lundi', 'mardi', 'jeudi', 'vendredi'];
$count = 0;

foreach ($jours as $jour) {
    // === MATIN ===
    // 8h30-9h00 Regroupement ULIS (tous)
    creneauGroupe($tous, $jour, '08:30', 30, 'Regroupement ULIS', $ulis, 'enseignant', 'ULIS', 'ULIS', 'Accueil, rituels, présentation de la journée');

    // 9h00-10h00 Ateliers ULIS (groupes de niveau)
    if ($jour === 'lundi' || $jour === 'jeudi') {
        // Lundi/Jeudi : Français CP/CE1, Maths CE2/CM
        creneauGroupe($cpce1, $jour, '09:00', 60, 'Français ULIS', $ulis, 'enseignant', 'CP-CE1', 'ULIS', 'Lecture, phonologie, dictée');
        creneauGroupe($ce2, $jour, '09:00', 60, 'Maths ULIS', $ulis, 'enseignant', 'CE2', 'ULIS', 'Numération, calcul');
        creneauGroupe($cm, $jour, '09:00', 60, 'Maths ULIS', $ulis, 'enseignant', 'CM', 'ULIS', 'Résolution de problèmes');
    } else {
        // Mardi/Vendredi : Maths CP/CE1, Français CE2/CM
        creneauGroupe($cpce1, $jour, '09:00', 60, 'Maths ULIS', $ulis, 'enseignant', 'CP-CE1', 'ULIS', 'Numération, calcul mental');
        creneauGroupe($ce2, $jour, '09:00', 60, 'Français ULIS', $ulis, 'enseignant', 'CE2', 'ULIS', 'Lecture compréhension, grammaire');
        creneauGroupe($cm, $jour, '09:00', 60, 'Français ULIS', $ulis, 'enseignant', 'CM', 'ULIS', 'Lecture inférence, conjugaison');
    }

    // === RÉCRÉATION 10h00-10h15 ===
    creneauGroupe($tous, $jour, '10:00', 15, 'Récréation', '', '', '', 'AUTRE');

    // 10h15-11h30 Inclusion classes de référence
    if ($jour === 'lundi') {
        // Lundi matin : CP en classe CP (français), CE1 en CE1, CE2/CM en co-intervention ULIS
        foreach ($cp as $eid) creneau($eid, $jour, '10:15', 75, 'Français', $cpRef, 'enseignant', 'CP', 'INCLUSION', 'CP', "Inclusion classe de $cpRef");
        foreach ($ce1 as $eid) creneau($eid, $jour, '10:15', 75, 'Français', $ce1Ref, 'enseignant', 'CE1', 'INCLUSION', 'CE1', "Inclusion classe de $ce1Ref");
        creneauGroupe($ce2, $jour, '10:15', 75, 'Français', $ce2Ref, 'enseignant', 'CE2', 'INCLUSION', 'CE2', "Co-intervention $ulis + $ce2Ref — français CE2");
        creneauGroupe($cm, $jour, '10:15', 75, 'Français', $cmRef, 'enseignant', 'CM1-CM2', 'INCLUSION', 'CM', "Inclusion classe de $cmRef");
    } elseif ($jour === 'mardi') {
        // Mardi matin : co-intervention maths dans toutes les classes
        foreach ($cp as $eid) creneau($eid, $jour, '10:15', 75, 'Maths', $cpRef, 'enseignant', 'CP', 'INCLUSION', 'CP', "Co-intervention $ulis + $cpRef");
        foreach ($ce1 as $eid) creneau($eid, $jour, '10:15', 75, 'Maths', $ce1Ref, 'enseignant', 'CE1', 'INCLUSION', 'CE1', "Co-intervention $ulis + $ce1Ref");
        creneauGroupe($ce2, $jour, '10:15', 75, 'Maths', $ulis, 'enseignant', 'CE2', 'ULIS', '', "Retour ULIS — maths renforcées CE2");
        creneauGroupe($cm, $jour, '10:15', 75, 'Maths', $cmRef, 'enseignant', 'CM1-CM2', 'INCLUSION', 'CM', "Inclusion classe de $cmRef");
    } elseif ($jour === 'jeudi') {
        // Jeudi matin : inclusion maths
        foreach ($cp as $eid) creneau($eid, $jour, '10:15', 75, 'Maths', $cpRef, 'enseignant', 'CP', 'INCLUSION', 'CP', "Inclusion classe de $cpRef");
        creneauGroupe($ce1, $jour, '10:15', 75, 'Maths', $ulis, 'enseignant', 'CE1', 'ULIS', '', "Maths renforcées CE1 en ULIS");
        creneauGroupe($ce2, $jour, '10:15', 75, 'Maths', $ce2Ref, 'enseignant', 'CE2', 'INCLUSION', 'CE2', "Co-intervention $ulis + $ce2Ref");
        foreach ($cm as $eid) creneau($eid, $jour, '10:15', 75, 'Maths', $cmRef, 'enseignant', 'CM1-CM2', 'INCLUSION', 'CM', "Inclusion classe de $cmRef");
    } else { // vendredi
        // Vendredi matin : inclusion français
        foreach ($cp as $eid) creneau($eid, $jour, '10:15', 75, 'Français', $cpRef, 'enseignant', 'CP', 'INCLUSION', 'CP', "Inclusion classe de $cpRef");
        foreach ($ce1 as $eid) creneau($eid, $jour, '10:15', 75, 'Français', $ce1Ref, 'enseignant', 'CE1', 'INCLUSION', 'CE1', "Inclusion classe de $ce1Ref");
        creneauGroupe($ce2, $jour, '10:15', 75, 'Français', $ce2Ref, 'enseignant', 'CE2', 'INCLUSION', 'CE2', "Co-intervention $ulis + $ce2Ref — écriture CE2");
        foreach ($cm as $eid) creneau($eid, $jour, '10:15', 45, 'Français', $cmRef, 'enseignant', 'CM1-CM2', 'INCLUSION', 'CM', "Inclusion classe de $cmRef");
        // CM : 11h00-11h30 EPS en inclusion
        foreach ($cm as $eid) creneau($eid, $jour, '11:00', 30, 'EPS', $cmRef, 'enseignant', 'CM1-CM2', 'INCLUSION', 'CM', "EPS avec la classe de $cmRef");
    }

    // === CANTINE 12h00-13h30 ===
    creneauGroupe($tous, $jour, '12:00', 90, 'Cantine', '', '', '', 'AUTRE');

    // === APRÈS-MIDI ===
    if ($jour === 'lundi') {
        // Lundi PM : 13h30-14h30 ULIS (tous) + 14h45-16h00 projets / PEC
        creneauGroupe($tous, $jour, '13:30', 60, 'Lecture offerte', $ulis, 'enseignant', 'ULIS', 'ULIS', 'Lecture plaisir, compréhension orale');
        // Récréation 14h30-14h45
        creneauGroupe($tous, $jour, '14:30', 15, 'Récréation', '', '', '', 'AUTRE');
        // 14h45-16h00 : ateliers tournants
        // CP-CE1 : art visuel ULIS
        creneauGroupe($cpce1, $jour, '14:45', 75, 'Arts visuels', $ulis, 'enseignant', 'CP-CE1', 'ULIS', 'Projet fresque murale');
        // CE2-CM : sciences / EMC en inclusion
        creneauGroupe($ce2, $jour, '14:45', 75, 'Questionner le monde', $ce2Ref, 'enseignant', 'CE2', 'INCLUSION', 'CE2', "Sciences en classe de $ce2Ref");
        creneauGroupe($cm, $jour, '14:45', 75, 'Sciences', $cmRef, 'enseignant', 'CM1-CM2', 'INCLUSION', 'CM', "Sciences en classe de $cmRef");
    } elseif ($jour === 'mardi') {
        // Mardi PM : 13h30-14h30 inclusion EPS + PEC
        creneauGroupe($cp, $jour, '13:30', 60, 'EPS', $cpRef, 'enseignant', 'CP', 'INCLUSION', 'CP', "Motricité/EPS avec $cpRef");
        creneauGroupe($ce1ce2, $jour, '13:30', 60, 'EPS', $ulis, 'enseignant', 'CE1-CE2', 'ULIS', '', "EPS — jeux collectifs avec $ulis");
        creneauGroupe($cm, $jour, '13:30', 60, 'EPS', $cmRef, 'enseignant', 'CM1-CM2', 'INCLUSION', 'CM', "EPS avec la classe de $cmRef");
        // Récréation
        creneauGroupe($tous, $jour, '14:30', 15, 'Récréation', '', '', '', 'AUTRE');
        // 14h45-15h30 : PEC orthophonie (Hugo, Jade) + autonomie ULIS pour les autres
        // Hugo (CE2, id=8) orthophonie
        $hugo = $elevesIds[7]['id'];
        creneau($hugo, $jour, '14:45', 45, 'Orthophonie', $ortho, 'specialiste', '', 'PEC', '', "Séance hebdomadaire — cabinet");
        // Jade (CM1, id=11) orthophonie
        $jade = $elevesIds[10]['id'];
        creneau($jade, $jour, '14:45', 45, 'Orthophonie', $ortho, 'specialiste', '', 'PEC', '', "Séance hebdomadaire — cabinet");
        // Autres CM : autonomie ULIS
        $cmSansPEC = array_diff($cm, [$jade]);
        creneauGroupe($cmSansPEC, $jour, '14:45', 45, 'Autonomie', $ulis, 'enseignant', 'CM', 'ULIS', '', 'Plan de travail');
        // Autres CE1-CE2 sans Hugo : autonomie
        $ce1ce2SansHugo = array_diff($ce1ce2, [$hugo]);
        creneauGroupe($ce1ce2SansHugo, $jour, '14:45', 45, 'Autonomie', $ulis, 'enseignant', 'CE1-CE2', 'ULIS', '', 'Plan de travail, jeux éducatifs');
        // CP : autonomie
        creneauGroupe($cp, $jour, '14:45', 45, 'Autonomie', $ulis, 'enseignant', 'CP', 'ULIS', '', 'Ateliers manipulation');
        // 15h30-16h00 regroupement
        creneauGroupe($tous, $jour, '15:30', 60, 'Regroupement', $ulis, 'enseignant', 'ULIS', 'ULIS', 'Bilan de la journée, devoirs');
    } elseif ($jour === 'jeudi') {
        // Jeudi PM : 13h30-14h30 ULIS (tous)
        creneauGroupe($tous, $jour, '13:30', 60, 'EMC / Vivre ensemble', $ulis, 'enseignant', 'ULIS', 'ULIS', 'Conseil de coopération, émotions');
        // Récréation
        creneauGroupe($tous, $jour, '14:30', 15, 'Récréation', '', '', '', 'AUTRE');
        // 14h45-15h30 : PEC psychologue CMPP (Maëlys CE2, Noé CM2) + autonomie
        $maelys = $elevesIds[8]['id'];
        $noe = $elevesIds[11]['id'];
        creneau($maelys, $jour, '14:45', 45, 'Suivi psy CMPP', $psy, 'specialiste', '', 'PEC', '', "Suivi mensuel — bureau CMPP");
        creneau($noe, $jour, '14:45', 45, 'Suivi psy CMPP', $psy, 'specialiste', '', 'PEC', '', "Suivi mensuel — bureau CMPP");
        // Autres : autonomie
        $sansPsy = array_diff($tous, [$maelys, $noe]);
        creneauGroupe($sansPsy, $jour, '14:45', 45, 'Ateliers autonomes', $ulis, 'enseignant', 'ULIS', 'ULIS', '', 'Ateliers tournants : lecture, maths, logique');
        // 15h30-16h00 EPS ULIS
        creneauGroupe($tous, $jour, '15:30', 60, 'EPS', $ulis, 'enseignant', 'ULIS', 'ULIS', 'Parcours de motricité');
    } else { // vendredi
        // Vendredi PM : sortie / projet
        creneauGroupe($tous, $jour, '13:30', 60, 'Projet interdisciplinaire', $ulis, 'enseignant', 'ULIS', 'ULIS', 'Projet nature / jardin pédagogique');
        // Récréation
        creneauGroupe($tous, $jour, '14:30', 15, 'Récréation', '', '', '', 'AUTRE');
        // 14h45-15h15 : PEC SESSAD (Lucas CE1 — aesh Sophie)
        $lucas = $elevesIds[5]['id'];
        creneau($lucas, $jour, '14:45', 30, 'Suivi SESSAD', $sessad, 'aeshco', '', 'PEC', '', "Suivi éducatif SESSAD");
        // 14h45-15h30 : Inclusion arts plastiques CE2/CM
        creneauGroupe($ce2, $jour, '14:45', 45, 'Arts plastiques', $ce2Ref, 'enseignant', 'CE2', 'INCLUSION', 'CE2', "Arts plastiques en classe de $ce2Ref");
        creneauGroupe($cm, $jour, '14:45', 45, 'Arts plastiques', $cmRef, 'enseignant', 'CM1-CM2', 'INCLUSION', 'CM', "Arts plastiques en classe de $cmRef");
        // CP-CE1 : jeux de société ULIS
        creneauGroupe($cpce1, $jour, '14:45', 45, 'Jeux de société', $ulis, 'enseignant', 'CP-CE1', 'ULIS', '', 'Jeux coopératifs, respect des règles');
        // 15h30-16h00 Conseil de semaine
        creneauGroupe($tous, $jour, '15:30', 60, 'Conseil de semaine', $ulis, 'enseignant', 'ULIS', 'ULIS', 'Bilan de la semaine, ceintures de compétences, félicitations');
    }
}

// Compter
$count = (int)$pdo->query('SELECT COUNT(*) FROM creneaux')->fetchColumn();
echo "✓ $count créneaux créés\n";

echo "\n=== Base test prête ! ===\n";
echo "Élèves : 12 | Adultes : 8 | Créneaux template : $count | Semaines : 36\n";
echo "→ Propager le template vers les semaines depuis l'interface.\n";
