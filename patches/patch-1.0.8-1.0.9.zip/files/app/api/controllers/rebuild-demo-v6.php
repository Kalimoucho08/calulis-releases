<?php
/**
 * Rebuild base demo v6
 * Horaires : 08:30-11:30 | 13:30-16:30 (cantine auto 11:30-13:30)
 * Pauses : Récréation matin 10:00-10:15 | Récréation aprèm 15:00-15:15
 * APC : OFF
 * Années : 2024-2025, 2025-2026, 2026-2027 (active)
 */
require_once __DIR__ . '/../config.php';
$pdo = getDB();
echo "=== Rebuild demo v6 ===\n\n";

// 1. WIPE
echo "1. Nettoyage...\n";
$tables = ['creneaux','aesh_eleves','pec_eleves','representants','eleve_annees','documents',
           'notes_suivi','taches','reunions','evenements',
           'adultes_etablissements','adultes','classes','eleves','etablissements',
           'semaines','periodes','vacances','pauses','parametres','annees_scolaires'];
$pdo->exec('SET FOREIGN_KEY_CHECKS = 0');
foreach ($tables as $t) $pdo->exec("TRUNCATE TABLE $t");
$pdo->exec('SET FOREIGN_KEY_CHECKS = 1');
echo "   OK\n";

// 2. ETABLISSEMENTS
echo "2. Établissements...\n";
$etabs = [
    [1, "Ecole maternelle Les Tilleuls", "ecole_maternelle", "Ruffec", "1 rue des Tilleuls, 16700 Ruffec", "0545123456", "maternelle.tilleuls@academie.fr"],
    [2, "Ecole primaire Jules Ferry", "ecole_primaire", "Ruffec", "12 avenue Jules Ferry, 16700 Ruffec", "0545987654", "ecole.julesferry@academie.fr"],
    [3, "Ecole primaire Paul Bert", "ecole_primaire", "Ruffec", "8 rue Paul Bert, 16700 Ruffec", "0545112233", "paul.bert@academie.fr"],
    [4, "Ecole primaire Victor Hugo", "ecole_primaire", "Ruffec", "5 boulevard Victor Hugo, 16700 Ruffec", "0545223344", "victor.hugo@academie.fr"],
    [5, "CMPP Angouleme", "cmpp", "Angouleme", "25 rue de la Paix, 16000 Angouleme", "0545334455", "cmpp.angouleme@ch-angouleme.fr"],
    [6, "CMP Angouleme", "cmp", "Angouleme", "18 avenue du Gal de Gaulle, 16000 Angouleme", "0545445566", "cmp.angouleme@ch-angouleme.fr"],
    [7, "SESSAD APA 16", "sessad", "Angouleme", "42 rue des Remparts, 16000 Angouleme", "0545556677", "sessad.apa16@association.fr"],
    [8, "ASE Charente", "foyer_ase", "Angouleme", "14 bd de l'Entente, 16000 Angouleme", "0545667788", "ase.charente@cd16.fr"],
    [9, "Foyer Les Hirondelles", "foyer_ase", "Ruffec", "2 rue de l'Enfance, 16700 Ruffec", "0545112233", "foyer.hirondelles@ase16.fr"],
    [10, "MDA Angouleme", "association", "Angouleme", "6 rue des Arts, 16000 Angouleme", "0545778899", "contact@mda-angouleme.fr"],
    [11, "College Jean Rostand", "college", "Ruffec", "15 avenue de la Gare, 16700 Ruffec", "0545889900", "ce.0160000c@ac-poitiers.fr"],
];
$s = $pdo->prepare("INSERT INTO etablissements (id,nom,type,ville,adresse,telephone,email,actif) VALUES (?,?,?,?,?,?,?,1)");
foreach ($etabs as $e) $s->execute($e);
echo "   OK " . count($etabs) . "\n";

// 3. ANNEES + SEMAINES
echo "3. Années + semaines...\n";
$annees = [
    [1, '2024-2025', '2024-09-02', '2025-07-04', 0],
    [2, '2025-2026', '2025-09-01', '2026-07-04', 0],
    [3, '2026-2027', '2026-08-31', '2027-07-04', 1],
];
$s = $pdo->prepare("INSERT INTO annees_scolaires (id,nom,date_debut,date_fin,est_active) VALUES (?,?,?,?,?)");
foreach ($annees as $a) $s->execute($a);

$sSem = $pdo->prepare("INSERT INTO semaines (annee_scolaire_id,numero,date_debut,date_fin,est_vacances) VALUES (?,?,?,?,?)");
$totalSem = 0;
foreach ($annees as $a) {
    $aid = $a[0];
    $debut = new DateTime($a[2]);
    $finLimite = new DateTime($a[3]);
    $sem = new DateTime($debut->format('Y-m-d'));
    $js = (int)$sem->format('N');
    if ($js > 1 && $js < 7) $sem->modify('-' . ($js - 1) . ' days');
    if ($js == 7) $sem->modify('+1 day');
    $num = 0;
    $toussaint = $a[1] === '2024-2025' ? [7,8] : [7,8];
    $noel      = $a[1] === '2024-2025' ? [16,17] : [16,17];
    $hiver     = $a[1] === '2024-2025' ? [25,26] : [24,25];
    $printemps = $a[1] === '2024-2025' ? [33,34] : [32,33];
    $vac = array_merge($toussaint, $noel, $hiver, $printemps);
    while ($sem <= $finLimite) {
        $num++;
        $finSem = clone $sem;
        $finSem->modify('+4 days');
        if ($sem > $finLimite) break;
        if ($finSem > $finLimite) $finSem = clone $finLimite;
        $estVac = in_array($num, $vac) ? 1 : 0;
        $sSem->execute([$aid, $num, $sem->format('Y-m-d'), $finSem->format('Y-m-d'), $estVac]);
        $totalSem++;
        $sem->modify('+7 days');
    }
    echo "   {$a[1]} : $num semaines\n";
}
echo "   Total : $totalSem semaines\n";

// 4. PERIODES
echo "4. Périodes...\n";
$periodes = [
    1 => [['Période 1','2024-09-02','2024-10-18',1],['Période 2','2024-11-04','2024-12-20',2],['Période 3','2025-01-06','2025-02-14',3],['Période 4','2025-03-10','2025-04-11',4],['Période 5','2025-04-28','2025-07-04',5]],
    2 => [['Période 1','2025-09-01','2025-10-17',1],['Période 2','2025-11-03','2025-12-19',2],['Période 3','2026-01-05','2026-02-13',3],['Période 4','2026-03-09','2026-04-10',4],['Période 5','2026-04-27','2026-07-03',5]],
    3 => [['Période 1','2026-08-31','2026-10-16',1],['Période 2','2026-11-02','2026-12-18',2],['Période 3','2027-01-04','2027-02-12',3],['Période 4','2027-03-08','2027-04-09',4],['Période 5','2027-04-26','2027-07-04',5]],
];
$s = $pdo->prepare("INSERT INTO periodes (annee_scolaire_id,nom,date_debut,date_fin,ordre) VALUES (?,?,?,?,?)");
foreach ($periodes as $aid => $pers) {
    foreach ($pers as $p) $s->execute([$aid, $p[0], $p[1], $p[2], $p[3]]);
}
echo "   OK 15\n";

// 5. PARAMETRES
echo "5. Paramètres...\n";
$params = [
    ['couleurs_types', '{"ULIS":"#bbdefb","INCLUSION":"#c8e6c9","DECLOISONNEMENT":"#fff9c4","PEC":"#ffccbc","RECREATION":"#ffe0b2","PAUSE MIDI":"#d7ccc8","AUTRE":"#e0e0e0"}'],
    ['theme', '"clair"'],
    ['horaires', '{"debut":"08:30","fin":"16:30","duree_creneau":15}'],
    ['jours_affiches', '["lundi","mardi","jeudi","vendredi"]'],
    ['format_semaine', '"scolaire"'],
    ['notre_etablissement_id', '2'],
    ['apc', '{"actif":false,"slots":[]}'],
    ['types_reunions', '{"ESS":"#bbdefb","Équipe éducative":"#c8e6c9","RDV famille":"#fff9c4","Partenariat":"#ffccbc","Autre":"#e0e0e0"}'],
    ['zones_enseignement', '{"academie":"Poitiers","departement":"Charente","ville":"Ruffec"}'],
];
$s = $pdo->prepare("INSERT INTO parametres (cle,valeur) VALUES (?,?)");
foreach ($params as $p) $s->execute($p);
echo "   OK " . count($params) . "\n";

// 7. ADULTES
echo "7. Adultes...\n";
$adultes = [
    [1,'Dupont','Jean','enseignant','directeur','0612345678','jean.dupont@ecole.fr',0,'Enseignant référent ULIS, directeur'],
    [2,'Martin','Marie','enseignant','','0623456789','marie.martin@ecole.fr',1,'Enseignante CP'],
    [3,'Bernard','Sophie','enseignant','','0634567890','sophie.bernard@ecole.fr',2,'Enseignante CE1-CE2'],
    [4,'Petit','Pierre','enseignant','','0645678901','pierre.petit@ecole.fr',3,'Enseignant CE2-CM1'],
    [5,'Robert','Isabelle','enseignant','coordo_ulis','0656789012','isabelle.robert@ecole.fr',4,'Coordinatrice ULIS'],
    [6,'Moreau','Sophie','aeshco','','0667890123','sophie.aesh@academie.fr',5,'AESH collective'],
    [7,'Laurent','Philippe','specialiste','','0678901234','p.laurent@ch-ruffec.fr',6,'Médecin scolaire'],
    [8,'Legrand','Catherine','specialiste','','0689012345','c.legrand@cg16.fr',7,'Ergothérapeute'],
    [9,'Rousseau','Nathalie','aeshi','','0611223344','n.rousseau@academie.fr',8,'AESH individuelle Léa L.'],
    [10,'Lefebvre','Karim','aeshco','','0622334455','k.lefebvre@academie.fr',9,'AESH collective CE1-CE2'],
    [11,'Girard','Audrey','aeshi','','0633445566','a.girard@academie.fr',10,'AESH Lucas + Hugo'],
    [12,'Morel','Emilie','enseignant','','0644556677','e.morel@ecole.fr',11,'Enseignante CP-CE1'],
    [13,'Mercier','Anne','specialiste','','0655667788','a.mercier@cmp-ruffec.fr',12,'Pédopsychiatre CMP'],
    [14,'Dumont','Sylvain','educateur','','0666778899','s.dumont@ase16.fr',13,'Éducateur ASE'],
    [15,'Lambert','Celine','assistant_familial','','0677889900','c.lambert@ase16.fr',14,'Assistante familiale'],
];
$s = $pdo->prepare("INSERT INTO adultes (id,nom,prenom,role,fonction,telephone,email,ordre,commentaires,actif) VALUES (?,?,?,?,?,?,?,?,?,1)");
foreach ($adultes as $a) $s->execute($a);
echo "   OK " . count($adultes) . "\n";

// 8. ADULTES ETABLISSEMENTS
echo "8. Rattachements adultes...\n";
$r = [
    [1,2,'enseignant',3],[2,2,'enseignant',3],[3,2,'enseignant',3],[4,2,'enseignant',3],
    [5,2,'enseignant',3],[12,2,'enseignant',3],[6,1,'aeshco',3],[6,2,'aeshco',3],
    [9,2,'aeshi',3],[10,2,'aeshco',3],[11,2,'aeshi',3],[7,2,'intervenant',3],
    [7,5,'specialiste',3],[8,2,'intervenant',3],[8,10,'specialiste',3],[13,6,'specialiste',3],
    [14,8,'educateur',3],[15,8,'assistant_familial',3],
];
$s = $pdo->prepare("INSERT INTO adultes_etablissements (adulte_id,etablissement_id,role,annee_scolaire_id) VALUES (?,?,?,?)");
foreach ($r as $rr) $s->execute($rr);
echo "   OK " . count($r) . "\n";

// 9. CLASSES
echo "9. Classes...\n";
$classes = [
    ['CP','CP',2,2],
    ['CE1','CE1',3,2],
    ['CE2','CE2',4,2],

];
$s = $pdo->prepare("INSERT INTO classes (nom,niveaux,enseignant_id,etablissement_id) VALUES (?,?,?,?)");
foreach ($classes as $c) $s->execute($c);
echo "   OK " . count($classes) . "\n";

// 10. ELEVES
echo "10. Élèves...\n";
$eleves = [
    [1,'Lemoine','Léa','2019-05-12','CP',1,'CP','CP',1,2,1,'Taxi',1,'0611112233','lemoine.famille@email.fr','12 rue des Lilas, 16700 Ruffec','Arachide, acariens','',1,'Traitement antihistaminique si crise. Trousse urgence dans le cartable.',1,0],
    [2,'Moreau','Thomas','2019-09-03','CP',1,'CP','CP',1,2,1,'Bus',1,'0622223344','moreau.parents@email.fr','3 impasse des Ecoles, 16700 Ruffec','','',1,'Suivi orthophonique 2x/semaine.',0,1],
    [3,'Petit','Emma','2019-02-28','CP',1,'CP','CP',1,2,1,'Bus',1,'0633334455','petit.famille@email.fr','8 rue de la Mairie, 16700 Ruffec','Pollen','',1,'Lunettes : vérifier port quotidien.',0,2],
    [4,'Garcia','Noah','2018-07-14','CE1',1,'CE1','CE1',2,2,2,'Bus',1,'0644445566','garcia.famille@email.fr','22 av. de la Gare, 16700 Ruffec','','',1,'Traitement LP pris le matin à la maison.',0,3],
    [5,'Dubois','Inès','2018-11-22','CE1',1,'CE1','CE1',3,2,2,'Taxi',1,'0655556677','','Chez Mme Lambert, 5 chemin du Moulin, 16700 Ruffec','','Sans porc',1,'',0,4],
    [6,'Bernard','Lucas','2017-12-05','CE1',1,'CE1','CE1',2,2,2,'Bus',1,'0666667788','bernard.parents@email.fr','15 rue du Stade, 16700 Ruffec','','',1,'Police OpenDys, tiers-temps.',1,5],
    [7,'Martin','Chloé','2017-03-18','CE2',1,'CE2','CE2',2,2,3,'Taxi',1,'0677778899','martin.famille@email.fr','7 place Eglise, 16700 Ruffec','Latex','',1,'Kinésithérapie 2x/semaine. Temps suppl. déplacements.',1,6],
    [8,'Robert','Hugo','2016-09-30','CE2',1,'CE2','CE2',4,2,3,'Taxi',1,'0688889900','robert.parents@email.fr','28 rue du Bois, 16700 Ruffec','Gluten','Sans gluten',1,'Casque anti-bruit disponible. Routines visuelles.',1,7],
    [9,'Durand','Maëlys','2017-06-08','CE2',1,'CE2','CE2',2,2,3,'Bus',1,'0699990011','durand.famille@email.fr','4 allée des Platanes, 16700 Ruffec','','',1,'Police adaptée, tiers-temps, dictée à ladulte.',0,8],
    [10,'Leroy','Mathis','2016-01-15','CM1',1,'CM','CM1',3,2,4,'Taxi',1,'','','Foyer Les Hirondelles, 2 rue Enfance, 16700 Ruffec','','',1,'Gestion frustration : temps calme si besoin.',0,9],
    [11,'Simon','Jade','2015-08-22','CM1',1,'CM','CM1',2,2,4,'Bus',1,'0610101112','simon.famille@email.fr','10 rue des Tilleuls, 16700 Ruffec','','',1,'Parents séparés : garde alternée sem. A/B.',0,10],
    [12,'Laurent','Noé','2015-04-30','CM2',1,'CM','CM2',4,2,4,'Bus',1,'0611111213','laurent.parents@email.fr','18 bd de la Liberté, 16700 Ruffec','','',1,'Ordi MDPH. Logiciels : Balabolka, Geogebra.',0,11],
];
$s = $pdo->prepare("INSERT INTO eleves (id,nom,prenom,date_naissance,classe,ulis,groupe,niveau_scolaire,ecole_origine_id,etablissement_id,classe_id,transport,cantine,telephone,email,adresse,allergies,regime_alimentaire,suivi_medical,precautions_medicales,pai,ordre,actif) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,1)");
foreach ($eleves as $e) $s->execute($e);
echo "   OK " . count($eleves) . "\n";

// 11. ELEVE_ANNEES
echo "11. Rattachements élèves/années...\n";
$s = $pdo->prepare("INSERT INTO eleve_annees (eleve_id,annee_scolaire_id,classe,ulis,groupe,niveau_scolaire,etablissement_id,classe_id) VALUES (?,?,?,1,?,?,?,?)");
foreach ([1,2,3,4,5,6,7,8,9,10,11,12] as $eid) {
    foreach ([1,2,3] as $aid) {
        $s->execute([$eid, $aid, 'CP', 'CP', 'CP', 2, 1]);
    }
}
echo "   OK 36\n";

// 12. AESH + PEC
echo "12. AESH / PEC...\n";
$aesh = [
    [1,'AESHi','Nathalie Rousseau','12h','',0],
    [7,'AESHm','Audrey Girard','6h','8',0],
    [8,'AESHm','Audrey Girard','6h','7',0],
    [6,'AESHco','Karim Lefebvre','3h','4',0],
    [12,'AESHi','Audrey Girard','9h','',0],
];
$s = $pdo->prepare("INSERT INTO aesh_eleves (eleve_id,type,nom,heures,mutualise_avec,ordre) VALUES (?,?,?,?,?,?)");
foreach ($aesh as $a) $s->execute($a);
$pec = [
    [8,'orthophoniste','prive','hebdomadaire','','45min','Cabinet libéral'],
    [9,'psychologue','CMPP','mensuel','','45min','Bureau CMPP'],
    [10,'pedopsychiatre','CMP','bimensuel','','60min','Suivi CMP'],
    [11,'orthophoniste','prive','hebdomadaire','','45min','Cabinet libéral'],
    [12,'psychologue','CMPP','mensuel','','45min','Bureau CMPP'],
];
$s2 = $pdo->prepare("INSERT INTO pec_eleves (eleve_id,specialite,organisme,frequence,lieu,duree,commentaires) VALUES (?,?,?,?,?,?,?)");
foreach ($pec as $p) $s2->execute($p);
echo "   OK AESH:" . count($aesh) . " PEC:" . count($pec) . "\n";

// 13. CRENEAUX TEMPLATE
echo "13. Créneaux template...\n";

function c($pdo, $eid, $j, $h, $d, $m, $ad, $role, $grp, $type, $cmt='') {
    $coul = $type === 'PEC' ? '#ffccbc' : null;
    $pdo->prepare("INSERT INTO creneaux (eleve_id,semaine_id,jour,heure_debut,duree,matiere,groupe,adulte,role_adulte,type,regroupement_type,couleur_override,commentaire) VALUES (?,NULL,?,?,?,?,?,?,?,?,?,?,?)")
        ->execute([$eid,$j,$h,$d,$m,$grp,$ad,$role,'fixe',$type,$coul,$cmt]);
}
function cg($pdo, $ids, $j, $h, $d, $m, $ad, $role, $grp, $type, $cmt='') {
    foreach ($ids as $id) c($pdo, $id, $j, $h, $d, $m, $ad, $role, $grp, $type, $cmt);
}

$T  = [1,2,3,4,5,6,7,8,9,10,11,12];
$CP = [1,2,3]; $CE1 = [4,5,6]; $CE2 = [7,8,9]; $CM = [10,11,12];
$CE1CE2 = [4,5,6,7,8,9]; $CPCE1 = [1,2,3,4,5,6];

$ULIS = 'M. Dupont'; $COORD = 'Mme Robert';
$CPR = 'Mme Martin'; $CE1R = 'Mme Bernard';
$CE2R = 'M. Petit'; $CMR = 'Mme Morel';
$ORTHO = 'Mme Legrand'; $PSY = 'Dr. Laurent'; $PEDOPSY = 'Dr. Mercier';

foreach (['lundi','mardi','jeudi','vendredi'] as $j) {
    // 08:30 Regroupement
    cg($pdo, $T, $j, '08:30', 30, 'Regroupement ULIS', $ULIS, 'enseignant', 'ULIS', 'ULIS', 'Accueil, rituels');
    // 09:00 Ateliers
    if ($j === 'lundi' || $j === 'jeudi') {
        cg($pdo, $CPCE1, $j, '09:00', 60, 'Français ULIS', $ULIS, 'enseignant', 'CP-CE1', 'ULIS', 'Lecture, phonologie');
        cg($pdo, $CE2, $j, '09:00', 60, 'Maths ULIS', $COORD, 'enseignant', 'CE2', 'ULIS', 'Numération');
        cg($pdo, $CM, $j, '09:00', 60, 'Maths ULIS', $ULIS, 'enseignant', 'CM', 'ULIS', 'Problèmes');
    } else {
        cg($pdo, $CPCE1, $j, '09:00', 60, 'Maths ULIS', $ULIS, 'enseignant', 'CP-CE1', 'ULIS', 'Calcul mental');
        cg($pdo, $CE2, $j, '09:00', 60, 'Français ULIS', $COORD, 'enseignant', 'CE2', 'ULIS', 'Compréhension');
        cg($pdo, $CM, $j, '09:00', 60, 'Français ULIS', $ULIS, 'enseignant', 'CM', 'ULIS', 'Inférence');
    }
    // Récréations : créneaux normaux, type de regroupement RECREATION
    cg($pdo, $T, $j, '10:00', 15, 'Récréation', '', '', '', 'RECREATION');
    cg($pdo, $T, $j, '15:00', 15, 'Récréation', '', '', '', 'RECREATION');
    // 10:15 Inclusion
    if ($j === 'lundi') {
        cg($pdo, $CP, $j, '10:15', 75, 'Français', $CPR, 'enseignant', 'CP', 'INCLUSION', "Classe de $CPR");
        cg($pdo, $CE1, $j, '10:15', 75, 'Français', $CE1R, 'enseignant', 'CE1', 'INCLUSION', "Classe de $CE1R");
        cg($pdo, $CE2, $j, '10:15', 75, 'Français', $ULIS, 'enseignant', 'CE2', 'ULIS', "Co-inter $ULIS + $CE2R");
        cg($pdo, $CM, $j, '10:15', 75, 'Français', $CMR, 'enseignant', 'CM1-CM2', 'INCLUSION', "Classe de $CMR");
    } elseif ($j === 'mardi') {
        cg($pdo, $CP, $j, '10:15', 75, 'Maths', $CPR, 'enseignant', 'CP', 'INCLUSION', "Co-inter avec $CPR");
        cg($pdo, $CE1, $j, '10:15', 75, 'Maths', $CE1R, 'enseignant', 'CE1', 'INCLUSION', "Co-inter avec $CE1R");
        cg($pdo, $CE2, $j, '10:15', 75, 'Maths', $ULIS, 'enseignant', 'CE2', 'ULIS', "Maths renforcées CE2");
        cg($pdo, $CM, $j, '10:15', 75, 'Maths', $CMR, 'enseignant', 'CM1-CM2', 'INCLUSION', "Classe de $CMR");
    } elseif ($j === 'jeudi') {
        cg($pdo, $CP, $j, '10:15', 75, 'Maths', $CPR, 'enseignant', 'CP', 'INCLUSION', "Classe de $CPR");
        cg($pdo, $CE1, $j, '10:15', 75, 'Maths', $ULIS, 'enseignant', 'CE1', 'ULIS', "Maths renforcées CE1");
        cg($pdo, $CE2, $j, '10:15', 75, 'Maths', $CE2R, 'enseignant', 'CE2', 'INCLUSION', "Co-inter avec $CE2R");
        cg($pdo, $CM, $j, '10:15', 75, 'Maths', $CMR, 'enseignant', 'CM1-CM2', 'INCLUSION', "Classe de $CMR");
    } else {
        cg($pdo, $CP, $j, '10:15', 75, 'Français', $CPR, 'enseignant', 'CP', 'INCLUSION', "Classe de $CPR");
        cg($pdo, $CE1, $j, '10:15', 75, 'Français', $CE1R, 'enseignant', 'CE1', 'INCLUSION', "Classe de $CE1R");
        cg($pdo, $CE2, $j, '10:15', 75, 'Français', $ULIS, 'enseignant', 'CE2', 'ULIS', "Co-inter avec $CE2R");
        cg($pdo, $CM, $j, '10:15', 45, 'Français', $CMR, 'enseignant', 'CM1-CM2', 'INCLUSION', "Classe de $CMR");
        cg($pdo, $CM, $j, '11:00', 30, 'EPS', $CMR, 'enseignant', 'CM1-CM2', 'INCLUSION', "EPS avec $CMR");
    }
    // PAS de créneau cantine → auto horaires 11:30-13:30
    // APRES-MIDI
    if ($j === 'lundi') {
        cg($pdo, $T, $j, '13:30', 60, 'Lecture offerte', $ULIS, 'enseignant', 'ULIS', 'ULIS', 'Lecture plaisir');
        c($pdo, 8, $j, '14:30', 30, 'Orthophonie', $ORTHO, 'specialiste', '', 'PEC', 'Séance hebdo');
        c($pdo, 11, $j, '14:30', 30, 'Orthophonie', $ORTHO, 'specialiste', '', 'PEC', 'Séance hebdo');
        cg($pdo, array_diff($T, [8,11]), $j, '14:30', 30, 'Autonomie', $ULIS, 'enseignant', 'ULIS', 'ULIS', 'Plan travail');
        cg($pdo, $T, $j, '15:15', 45, 'Arts visuels', $ULIS, 'enseignant', 'ULIS', 'ULIS', 'Fresque murale');
        cg($pdo, $T, $j, '16:00', 30, 'Bilan journée', $ULIS, 'enseignant', 'ULIS', 'ULIS', 'Devoirs');
    } elseif ($j === 'mardi') {
        cg($pdo, $CP, $j, '13:30', 60, 'EPS', $CPR, 'enseignant', 'CP', 'INCLUSION', 'Motricité');
        cg($pdo, $CE1CE2, $j, '13:30', 60, 'EPS', $ULIS, 'enseignant', 'CE1-CE2', 'ULIS', 'Jeux collectifs');
        cg($pdo, $CM, $j, '13:30', 60, 'EPS', $CMR, 'enseignant', 'CM', 'INCLUSION', "EPS avec $CMR");
        c($pdo, 10, $j, '14:30', 30, 'Suivi pédopsy', $PEDOPSY, 'specialiste', '', 'PEC', 'CMP');
        c($pdo, 5, $j, '14:30', 30, 'Suivi pédopsy', $PEDOPSY, 'specialiste', '', 'PEC', 'CMP');
        cg($pdo, array_diff($T, [10,5]), $j, '14:30', 30, 'Autonomie', $COORD, 'enseignant', 'ULIS', 'ULIS', 'Plan travail');
        cg($pdo, $T, $j, '15:15', 45, 'EMC', $ULIS, 'enseignant', 'ULIS', 'ULIS', 'Conseil coopération');
        cg($pdo, $T, $j, '16:00', 30, 'Bilan journée', $ULIS, 'enseignant', 'ULIS', 'ULIS', 'Devoirs');
    } elseif ($j === 'jeudi') {
        cg($pdo, $T, $j, '13:30', 45, 'QLM', $ULIS, 'enseignant', 'ULIS', 'ULIS', 'Sciences');
        cg($pdo, $CE2, $j, '14:15', 30, 'Anglais', $CE2R, 'enseignant', 'CE2', 'INCLUSION', "Anglais $CE2R");
        cg($pdo, $CM, $j, '14:15', 30, 'Anglais', $CMR, 'enseignant', 'CM', 'INCLUSION', "Anglais $CMR");
        cg($pdo, $CPCE1, $j, '14:15', 45, 'QLM', $COORD, 'enseignant', 'CP-CE1', 'ULIS', 'Découverte monde');
        cg($pdo, $T, $j, '15:15', 45, 'EPS', $ULIS, 'enseignant', 'ULIS', 'ULIS', 'Motricité');
        cg($pdo, $T, $j, '16:00', 30, 'Conseil', $ULIS, 'enseignant', 'ULIS', 'ULIS', 'Bilan');
    } else {
        cg($pdo, $T, $j, '13:30', 60, 'Projet', $ULIS, 'enseignant', 'ULIS', 'ULIS', 'Jardin pédagogique');
        c($pdo, 9, $j, '14:30', 30, 'Suivi psy', $PSY, 'specialiste', '', 'PEC', 'CMPP');
        c($pdo, 12, $j, '14:30', 30, 'Suivi psy', $PSY, 'specialiste', '', 'PEC', 'CMPP');
        cg($pdo, array_diff($T, [9,12]), $j, '14:30', 30, 'Jeux éducatifs', $COORD, 'enseignant', 'ULIS', 'ULIS', 'Coopération');
        cg($pdo, $T, $j, '15:15', 45, 'Conseil semaine', $ULIS, 'enseignant', 'ULIS', 'ULIS', 'Ceintures');
        cg($pdo, $T, $j, '16:00', 30, 'Félicitations', $ULIS, 'enseignant', 'ULIS', 'ULIS', 'Devoirs');
    }
}
$nbTpl = $pdo->query("SELECT COUNT(*) FROM creneaux WHERE semaine_id IS NULL")->fetchColumn();
echo "   OK $nbTpl créneaux template\n";

// 14. PROPAGATION
echo "14. Propagation année active...\n";
require_once __DIR__ . '/../models/Creneau.php';
$semActives = $pdo->query("SELECT id FROM semaines WHERE annee_scolaire_id=3 AND est_vacances=0 ORDER BY numero")->fetchAll(PDO::FETCH_COLUMN);
foreach ($semActives as $sid) Creneau::copyFromTemplate($sid);
echo "   OK " . count($semActives) . " semaines\n";

// 15. VARIATIONS
echo "15. Variations...\n";
$jours = ['lundi','mardi','jeudi','vendredi'];
$cnt = 0;
foreach ($semActives as $idx => $sid) {
    $num = $idx + 1;
    $r = ($num * 7 + 3) % 10;
    if ($r >= 3) continue;
    $cnt++;
    $limit = rand(2, 5);
    $cren = $pdo->query("SELECT id,eleve_id,jour,heure_debut,duree FROM creneaux WHERE semaine_id=$sid ORDER BY RAND() LIMIT $limit")->fetchAll();
    foreach ($cren as $c) {
        if ($r == 0) {
            $nh = date('H:i', strtotime($c['heure_debut']) + 900);
            if ($nh < '16:30') $pdo->exec("UPDATE creneaux SET heure_debut='$nh' WHERE id={$c['id']}");
        } elseif ($r == 1) {
            $other = $T[array_rand($T)];
            if ($other != $c['eleve_id']) $pdo->exec("UPDATE creneaux SET eleve_id=$other WHERE id={$c['id']}");
        } else {
            $eid = $T[array_rand($T)];
            $j = $jours[array_rand($jours)];
            $h = ['08:30','09:00','10:15','11:00','13:30','14:00','15:15'][array_rand(range(0,6))];
            $m = ['Sortie','Projet','Évaluation','Atelier','Intervention'][array_rand(range(0,4))];
            $pdo->exec("INSERT INTO creneaux (eleve_id,semaine_id,jour,heure_debut,duree,matiere,type,regroupement_type) VALUES ($eid,$sid,'$j','$h',".(rand(1,4)*15).",'$m','exception','AUTRE')");
        }
    }
    $pdo->exec("UPDATE semaines SET est_modifiee=1 WHERE id=$sid");
}
echo "   OK $cnt semaines variées\n";

// 16. TOTAL
$total = $pdo->query("SELECT COUNT(*) FROM creneaux")->fetchColumn();
echo "\n=== DEMO V6 PRÊTE ===\n";
echo "Années:3 Semaines:$totalSem Créneaux tpl:$nbTpl Total:$total\n";
echo "Pauses: 2 (10:00+15:00) + midi auto\n";
echo "Horaires: 08:30-11:30 | 13:30-16:30\n";
echo "APC: OFF\n";
echo "\n→ mysqldump calulis > data/calulis-demo-v6.sql\n";
