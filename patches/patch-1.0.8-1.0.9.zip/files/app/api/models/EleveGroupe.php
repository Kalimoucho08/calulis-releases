<?php
/** Calulis — Model Groupe d'élève (plusieurs groupes libres par élève, par année) */
require_once __DIR__ . '/../config.php';

class EleveGroupe {
    public static function getByEleve(int $eleveId, ?int $anneeId = null): array {
        $pdo = getDB();
        $sql = 'SELECT * FROM eleve_groupes WHERE eleve_id = :eid';
        $params = ['eid' => $eleveId];
        $sql .= ' ORDER BY id';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Pour une liste d'élèves : noms de groupes indexés par eleve_id */
    public static function forEleves(array $eleveIds, ?int $anneeId = null): array {
        if (empty($eleveIds)) return [];
        $pdo = getDB();
        $phs = implode(',', array_fill(0, count($eleveIds), '?'));
        // Groupes d'un élève : on les liste quel que soit l'exercice (robuste)
        $sql = 'SELECT eleve_id, nom FROM eleve_groupes WHERE eleve_id IN (' . $phs . ')';
        $params = array_map('intval', $eleveIds);
        $sql .= ' ORDER BY id';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $out = [];
        foreach ($stmt->fetchAll() as $row) {
            $out[(int)$row['eleve_id']][] = $row['nom'];
        }
        return $out;
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO eleve_groupes (eleve_id, annee_scolaire_id, nom) VALUES (:eleve_id, :annee, :nom)');
        $stmt->execute([
            'eleve_id' => isset($data['eleve_id']) ? (int)$data['eleve_id'] : 0,
            'annee' => (isset($data['annee_scolaire_id']) && $data['annee_scolaire_id'] !== '') ? (int)$data['annee_scolaire_id'] : null,
            'nom' => mb_substr(trim((string)($data['nom'] ?? '')), 0, 100),
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('UPDATE eleve_groupes SET nom=:nom, annee_scolaire_id=:annee, updated_at=CURRENT_TIMESTAMP WHERE id=:id');
        return $stmt->execute([
            'nom' => mb_substr(trim((string)($data['nom'] ?? '')), 0, 100),
            'annee' => (isset($data['annee_scolaire_id']) && $data['annee_scolaire_id'] !== '') ? (int)$data['annee_scolaire_id'] : null,
            'id' => $id,
        ]);
    }

    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM eleve_groupes WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    public static function deleteByEleve(int $eleveId, ?int $anneeId = null): bool {
        $pdo = getDB();
        if ($anneeId === null) {
            $stmt = $pdo->prepare('DELETE FROM eleve_groupes WHERE eleve_id = :eid');
            return $stmt->execute(['eid' => $eleveId]);
        }
        $stmt = $pdo->prepare('DELETE FROM eleve_groupes WHERE eleve_id = :eid AND annee_scolaire_id = :annee');
        return $stmt->execute(['eid' => $eleveId, 'annee' => $anneeId]);
    }
}