<?php
/** Calulis — Model Groupe de liste (groupe d'élèves enregistré, réutilisable) */
require_once __DIR__ . '/../config.php';

class Groupe {
    public static function all(): array {
        $pdo = getDB();
        return $pdo->query('SELECT * FROM groupes ORDER BY nom')->fetchAll();
    }

    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM groupes WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(array $data): int {
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO groupes (nom, criteres, eleves_ids) VALUES (:nom, :criteres, :eleves_ids)');
        $stmt->execute([
            'nom' => mb_substr(trim((string)($data['nom'] ?? '')), 0, 200),
            'criteres' => isset($data['criteres']) ? json_encode($data['criteres']) : null,
            'eleves_ids' => isset($data['eleves_ids']) ? json_encode($data['eleves_ids']) : null,
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('UPDATE groupes SET nom=:nom, criteres=:criteres, eleves_ids=:eleves_ids, updated_at=CURRENT_TIMESTAMP WHERE id=:id');
        return $stmt->execute([
            'nom' => mb_substr(trim((string)($data['nom'] ?? '')), 0, 200),
            'criteres' => isset($data['criteres']) ? json_encode($data['criteres']) : null,
            'eleves_ids' => isset($data['eleves_ids']) ? json_encode($data['eleves_ids']) : null,
            'id' => $id,
        ]);
    }

    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM groupes WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }
}
