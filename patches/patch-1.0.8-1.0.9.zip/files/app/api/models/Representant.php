<?php
/** Calulis — Model Représentant */
require_once __DIR__ . '/../config.php';

class Representant {
    public static function getByEleve(int $eleveId): array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM representants WHERE eleve_id = :eid ORDER BY ordre');
        $stmt->execute(['eid' => $eleveId]);
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM representants WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO representants
            (eleve_id, nom, prenom, lien, telephone, telephone_urgence, email, adresse, ordre)
            VALUES (:eleve_id, :nom, :prenom, :lien, :telephone, :telephone_urgence, :email, :adresse, :ordre)');
        $stmt->execute(self::_bind($data, false));
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $data['id'] = $id;
        $stmt = $pdo->prepare('UPDATE representants SET
            eleve_id=:eleve_id, nom=:nom, prenom=:prenom, lien=:lien,
            telephone=:telephone, telephone_urgence=:telephone_urgence,
            email=:email, adresse=:adresse, ordre=:ordre, updated_at=CURRENT_TIMESTAMP
            WHERE id=:id');
        return $stmt->execute(self::_bind($data));
    }

    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM representants WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    public static function deleteByEleve(int $eleveId): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM representants WHERE eleve_id = :eid');
        return $stmt->execute(['eid' => $eleveId]);
    }


    /** Pour une liste d'élèves : tous les représentants, indexés par eleve_id */
    public static function forEleves(array $eleveIds): array {
        if (empty($eleveIds)) return [];
        $pdo = getDB();
        $placeholders = implode(',', array_fill(0, count($eleveIds), '?'));
        $stmt = $pdo->prepare('SELECT * FROM representants WHERE eleve_id IN (' . $placeholders . ') ORDER BY ordre');
        $stmt->execute(array_map('intval', $eleveIds));
        $out = [];
        foreach ($stmt->fetchAll() as $row) {
            $out[(int)$row['eleve_id']][] = $row;
        }
        return $out;
    }

    private static function _bind(array $data, bool $includeId = true): array {
        $strFields = ['nom', 'prenom', 'lien', 'telephone', 'telephone_urgence', 'email', 'adresse'];
        $intFields = ['eleve_id', 'ordre'];
        if ($includeId) $intFields[] = 'id';
        $params = [];
        foreach ($strFields as $f) {
            $params[$f] = isset($data[$f]) ? trim($data[$f]) : '';
        }
        $intDefaults = ['eleve_id' => 0, 'telephone_urgence' => 0, 'ordre' => 0];
        foreach ($intFields as $f) {
            $params[$f] = isset($data[$f]) ? (int)$data[$f] : ($intDefaults[$f] ?? 0);
        }
        if ($includeId) $params['id'] = isset($data['id']) ? (int)$data['id'] : 0;
        return $params;
    }
}