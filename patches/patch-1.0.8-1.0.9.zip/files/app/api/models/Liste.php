<?php
/** Calulis — Model Liste (générateur de listes d'élèves multicritères)
 *  Retourne des élèves enrichis (representants + consentement droit à l'image)
 *  pour le générateur de listes du Lot 1. */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/Representant.php';
require_once __DIR__ . '/Consentement.php';
require_once __DIR__ . '/EleveGroupe.php';

class Liste {
    /** Champs versionnés à surcharger depuis eleve_annees (comme Eleve::_augment) */
    private const VERSIONED = [
        'classe', 'classe_id', 'ulis', 'niveau_scolaire', 'etablissement_id',
        'aesh_type', 'aesh_nom', 'aesh_heures', 'aesh_mutualise_avec',
        'transport', 'cantine', 'groupe',
    ];

    /**
     * @param array $f  Filtres : q, classe (niveau), classe_id, groupe, ulis,
     *                  transport ('has' ou valeur), cantine, pai, allergies,
     *                  droit_image (autorise/refuse/en_attente), inclure_inactifs
     * @param int|null $anneeId
     */
    public static function get(array $f, ?int $anneeId): array {
        $pdo = getDB();
        $cond = ['1=1'];
        $params = [];

        $sql = 'SELECT e.*, ea.classe AS ea_classe, ea.classe_id AS ea_classe_id,
             ea.ulis AS ea_ulis, ea.niveau_scolaire AS ea_niveau,
             ea.groupe AS ea_groupe, ea.transport AS ea_transport,
             ea.cantine AS ea_cantine
             FROM eleves e
             JOIN eleve_annees ea ON ea.eleve_id = e.id';

        if ($anneeId !== null) {
            $cond[] = 'ea.annee_scolaire_id = :annee';
            $params['annee'] = $anneeId;
        }

        if (!empty($f['ids']) && is_array($f['ids'])) {
            $ids = array_filter(array_map('intval', $f['ids']), function ($v) { return $v > 0; });
            if ($ids) {
                $phs = [];
                foreach ($ids as $i => $v) { $pk = 'id_' . $i; $phs[] = ':' . $pk; $params[$pk] = $v; }
                $cond[] = 'e.id IN (' . implode(',', $phs) . ')';
            }
        }

        $joinClasse = false;
        if (!empty($f['q'])) {
            $cond[] = '(e.nom LIKE :q OR e.prenom LIKE :q2)';
            $params['q'] = '%' . $f['q'] . '%';
            $params['q2'] = '%' . $f['q'] . '%';
        }
        if (!empty($f['classe'])) {
            $joinClasse = true;
            $cond[] = 'c.niveaux = :classe';
            $params['classe'] = $f['classe'];
        }
        if (!empty($f['classe_id'])) {
            $cond[] = 'ea.classe_id = :classe_id';
            $params['classe_id'] = (int)$f['classe_id'];
        }
        if (!empty($f['groupe'])) {
            // Filtre par groupe : un élève est retenu s'il appartient à un groupe correspondant
            $cond[] = 'EXISTS (SELECT 1 FROM eleve_groupes eg WHERE eg.eleve_id = e.id AND eg.nom LIKE :groupe)';
            $params['groupe'] = '%' . $f['groupe'] . '%';
        }
        if (isset($f['ulis']) && $f['ulis'] !== '') {
            $cond[] = 'ea.ulis = :ulis';
            $params['ulis'] = $f['ulis'] ? 1 : 0;
        }
        if (!empty($f['transport'])) {
            if ($f['transport'] === 'has') {
                $cond[] = '(ea.transport IS NOT NULL AND LENGTH(TRIM(ea.transport)) > 0)';
            } else {
                $cond[] = 'ea.transport LIKE :transport';
                $params['transport'] = '%' . $f['transport'] . '%';
            }
        }
        if (isset($f['cantine']) && $f['cantine'] !== '') {
            $cond[] = 'ea.cantine = :cantine';
            $params['cantine'] = $f['cantine'] ? 1 : 0;
        }
        if (isset($f['pai']) && $f['pai'] !== '') {
            $cond[] = 'e.pai = :pai';
            $params['pai'] = $f['pai'] ? 1 : 0;
        }
        if (isset($f['allergies']) && $f['allergies'] !== '') {
            if ($f['allergies']) {
                $cond[] = '(e.allergies IS NOT NULL AND LENGTH(TRIM(e.allergies)) > 0)';
            } else {
                $cond[] = '(e.allergies IS NULL OR LENGTH(TRIM(e.allergies)) = 0)';
            }
        }

        if ($joinClasse) {
            $sql .= ' JOIN classes c ON c.id = ea.classe_id';
        }
        if (!empty($f['droit_image'])) {
            $sql .= ' LEFT JOIN (
                SELECT c2.eleve_id, c2.statut AS di_statut
                FROM consentements c2
                INNER JOIN (
                    SELECT eleve_id, MAX(id) AS m
                    FROM consentements WHERE type = :type_di
                    GROUP BY eleve_id
                ) d2 ON d2.eleve_id = c2.eleve_id AND d2.m = c2.id
            ) di ON di.eleve_id = e.id';
            $cond[] = 'di.di_statut = :droit_image';
            $params['type_di'] = 'droit_image';
            $params['droit_image'] = $f['droit_image'];
        }

        if (empty($f['inclure_inactifs'])) {
            $cond[] = 'e.actif = 1';
        }

        $sql .= ' WHERE ' . implode(' AND ', $cond);
        $sql .= ' ORDER BY e.ordre, e.nom, e.prenom';

        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();

        return self::_enrich($rows, $pdo, $anneeId);
    }

    /** Complète chaque élève : classe_nom + champs année + representants + droit à l'image */
    private static function _enrich(array $rows, \PDO $pdo, ?int $anneeId = null): array {
        if (empty($rows)) return [];

        // Nom des classes
        $classMap = [];
        foreach ($pdo->query('SELECT id, nom FROM classes')->fetchAll() as $c) {
            $classMap[(int)$c['id']] = $c['nom'];
        }

        $ids = array_map('intval', array_column($rows, 'id'));
        $reps = Representant::forEleves($ids);
        $consents = Consentement::forEleves($ids, ['droit_image']);
        $groups = EleveGroupe::forEleves($ids, $anneeId);

        foreach ($rows as &$row) {
            $eid = (int)$row['id'];
            // Surcharger les champs avec la valeur de l'année (eleve_annees)
            foreach (self::VERSIONED as $vf) {
                $src = 'ea_' . $vf;
                if (array_key_exists($src, $row)) {
                    $row[$vf] = $row[$src];
                    unset($row[$src]);
                }
            }
            $cid = isset($row['classe_id']) ? (int)$row['classe_id'] : 0;
            $row['classe_nom'] = $cid > 0 && isset($classMap[$cid]) ? $classMap[$cid] : ($row['classe'] ?? '');
            if (isset($classMap[$cid])) $row['classe'] = $row['classe_nom'];

            $row['representants'] = $reps[$eid] ?? [];
            $row['droit_image'] = $consents[$eid]['droit_image'] ?? null;
            $row['groupes'] = $groups[$eid] ?? [];
        }
        return $rows;
    }
}