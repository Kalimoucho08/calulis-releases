<?php
/** Calulis — Model Consentement (droit à l'image, sorties, soins, partage d'infos...) */
require_once __DIR__ . '/../config.php';

class Consentement {
    /** Types connus (pour la fiche élève et les listes) */
    public const TYPES = ['droit_image', 'sorties', 'soins', 'partage_infos', 'communication_mail', 'photos_reseaux', 'autre'];
    public const STATUTS = ['autorise', 'refuse', 'limite', 'en_attente', 'retire'];

    /** Tous les consentements d'un élève, triés par type puis date */
    public static function getByEleve(int $eleveId, ?string $type = null): array {
        $pdo = getDB();
        $sql = 'SELECT * FROM consentements WHERE eleve_id = :eid';
        $params = ['eid' => $eleveId];
        if ($type !== null) { $sql .= ' AND type = :type'; $params['type'] = $type; }
        $sql .= ' ORDER BY type, date_debut DESC, id DESC';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Pour une liste d'élèves : renvoie la derniere décision de chaque type demandé */
    public static function forEleves(array $eleveIds, ?array $types = null): array {
        if (empty($eleveIds)) return [];
        $pdo = getDB();
        $placeholders = implode(',', array_fill(0, count($eleveIds), '?'));
        $sql = "SELECT c.* FROM consentements c
                INNER JOIN (
                    SELECT eleve_id, type, MAX(id) AS max_id
                    FROM consentements WHERE eleve_id IN ($placeholders)
                    GROUP BY eleve_id, type
                ) d ON d.max_id = c.id";
        $params = array_map('intval', $eleveIds);
        if ($types && !empty($types)) {
            $tPh = implode(',', array_fill(0, count($types), '?'));
            $sql = "SELECT c.* FROM consentements c
                    INNER JOIN (
                        SELECT eleve_id, type, MAX(id) AS max_id
                        FROM consentements WHERE eleve_id IN ($placeholders) AND type IN ($tPh)
                        GROUP BY eleve_id, type
                    ) d ON d.max_id = c.id";
            $params = array_merge(array_map('intval', $eleveIds), $types);
        }
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
        $out = [];
        foreach ($rows as $r) {
            $out[(int)$r['eleve_id']][$r['type']] = $r;
        }
        return $out;
    }

    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM consentements WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Le consentement actuel d'un élève pour un type donné (dernière décision) */
    public static function current(int $eleveId, string $type): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM consentements WHERE eleve_id = :eid AND type = :type ORDER BY id DESC LIMIT 1');
        $stmt->execute(['eid' => $eleveId, 'type' => $type]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO consentements
            (eleve_id, type, statut, date_debut, date_fin, document_reference, commentaires, created_at, updated_at)
            VALUES (:eleve_id, :type, :statut, :date_debut, :date_fin, :document_reference, :commentaires, NOW(), NOW())');
        $stmt->execute(self::_bind($data, false));
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $data['id'] = $id;
        $stmt = $pdo->prepare('UPDATE consentements SET
            eleve_id=:eleve_id, type=:type, statut=:statut,
            date_debut=:date_debut, date_fin=:date_fin,
            document_reference=:document_reference, commentaires=:commentaires,
            updated_at=NOW() WHERE id=:id');
        return $stmt->execute(self::_bind($data));
    }

    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM consentements WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    public static function deleteByEleve(int $eleveId): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM consentements WHERE eleve_id = :eid');
        return $stmt->execute(['eid' => $eleveId]);
    }

    private static function _bind(array $data, bool $includeId): array {
        $strFields = ['type', 'statut', 'document_reference', 'commentaires'];
        $params = [];
        // Par défaut : type requis, statut 'en_attente'
        $params['type'] = isset($data['type']) ? trim((string)$data['type']) : '';
        $params['statut'] = isset($data['statut']) ? trim((string)$data['statut']) : 'en_attente';
        foreach (['document_reference', 'commentaires'] as $f) {
            $params[$f] = isset($data[$f]) ? trim((string)$data[$f]) : null;
        }
        $params['eleve_id'] = isset($data['eleve_id']) ? (int)$data['eleve_id'] : 0;
        foreach (['date_debut', 'date_fin'] as $f) {
            $v = isset($data[$f]) ? trim((string)$data[$f]) : '';
            $params[$f] = ($v === '' || !preg_match('/^\\d{4}-\\d{2}-\\d{2}$/', $v)) ? null : $v;
        }
        if ($includeId) $params['id'] = isset($data['id']) ? (int)$data['id'] : 0;
        return $params;
    }
}