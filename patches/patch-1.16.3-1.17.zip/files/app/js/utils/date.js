/**
 * Calulis — Utilitaires dates et calculs de semaine
 */

/** Formatte une date ISO (YYYY-MM-DD) en jour/mois */
function formatDate(dateStr) {
    if (!dateStr) return '';
    const [y, m, d] = dateStr.split('-');
    return `${d}/${m}/${y}`;
}

/** Formatte une heure TIME (HH:MM) en affichage HHhMM */
function formatHeure(timeStr) {
    if (!timeStr) return '';
    const [h, m] = timeStr.split(':');
    return `${parseInt(h)}h${m}`;
}

/** Retourne la date du lundi de la semaine pour une date donnée */
function getLundi(date = new Date()) {
    const d = new Date(date);
    const day = d.getDay(); // 0=dimanche
    const diff = (day === 0 ? -6 : 1 - day);
    d.setDate(d.getDate() + diff);
    return d;
}

/** Format YYYY-MM-DD, en HEURE LOCALE (l'application affiche et filtre en local).
 *  `toISOString()` donnait la veille entre minuit et 1-2 h du matin (UTC+1/+2) :
 *  le tableau de bord croyait encore être la veille, et les tâches du jour
 *  passaient « en retard ». Constaté le 23/10/2026 à 00 h 20. */
function toDateStr(date) {
    const d = new Date(date);
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0')
        + '-' + String(d.getDate()).padStart(2, '0');
}

/** Retourne le numéro de semaine ISO */
function getWeekNumber(date = new Date()) {
    const d = new Date(date);
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() + 3 - (d.getDay() + 6) % 7);
    const week1 = new Date(d.getFullYear(), 0, 4);
    return 1 + Math.round(((d - week1) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
}

/** Nom du jour en français */
const JOURS = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
function nomJour(date) { return JOURS[new Date(date).getDay()]; }

/** Aujourd'hui en YYYY-MM-DD */
function aujourdhui() { return toDateStr(new Date()); }

/** Numéro de semaine ISO 8601 à partir d'une date YYYY-MM-DD */
function getISOWeek(dateStr) {
    const d = new Date(dateStr + 'T00:00:00');
    d.setHours(0, 0, 0, 0);
    d.setDate(d.getDate() + 3 - (d.getDay() + 6) % 7);
    const week1 = new Date(d.getFullYear(), 0, 4);
    return 1 + Math.round(((d - week1) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
}

/**
 * Rang scolaire d'une semaine (1→36). Ne compte que les semaines de cours
 * (est_vacances != 1), jamais les vacances. Retourne null si la semaine
 * n'est pas trouvée dans la liste.
 * @param {Object} semaine - Objet semaine avec id, annee_scolaire_id
 * @param {Array} allSemaines - Toutes les semaines de l'année scolaire
 * @returns {number|null} Rang 1-based parmi les semaines de cours
 */
function getSchoolWeekNumber(semaine, allSemaines) {
    const schoolWeeks = allSemaines
        .filter(s => s.annee_scolaire_id === semaine.annee_scolaire_id && parseInt(s.est_vacances) !== 1)
        .sort((a, b) => (a.numero || 0) - (b.numero || 0));
    const idx = schoolWeeks.findIndex(s => s.id === semaine.id);
    return idx >= 0 ? idx + 1 : null;
}
