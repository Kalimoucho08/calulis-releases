-- Calulis — 011 : un événement modèle n'appartient à aucune année scolaire
--
-- Le front enregistre un « événement modèle » avec annee_scolaire_id = NULL
-- (app/js/components/evenements.js, création et désactivation), et le contrôleur
-- l'accepte explicitement (« annee_scolaire_id peut être null pour les modèles »).
-- La colonne était restée NOT NULL dans la base de référence 1.15 : en SQL strict
-- (le MySQL 8 du paquet), l'import de la démo par l'API et la création/désactivation
-- d'un modèle échouaient — et le lanceur écrivait des modèles rattachés à l'année 0.
--
-- Aucune donnée existante n'est modifiée : les lignes déjà là gardent leur année.
-- GARDE D'IDEMPOTENCE : si la migration est interrompue puis rejouée, la colonne
-- déjà nullable ne provoque pas un second ALTER (le test des migrations l'exige).
SET @nullable = (
    SELECT IS_NULLABLE FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE()
      AND TABLE_NAME = 'evenements'
      AND COLUMN_NAME = 'annee_scolaire_id'
);
SET @sql = IF(@nullable = 'NO',
    'ALTER TABLE `evenements` MODIFY COLUMN `annee_scolaire_id` INT NULL DEFAULT NULL',
    'DO 1');
PREPARE stmt_011 FROM @sql;
EXECUTE stmt_011;
DEALLOCATE PREPARE stmt_011;
