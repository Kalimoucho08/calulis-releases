/**
 * Calulis — Composant Bug Report
 * Modale de signalement de bug avec infos techniques automatiques.
 */
const BugReport = {
    /** Ouvre la modale de signalement */
    open() {
        const infos = this._collectInfos();
        Modal.open({
            title: '🐛 Signaler un bug',
            body: `
                <p class="text-muted small" style="margin-bottom:12px">
                    Décris le problème rencontré. Les infos techniques ci-dessous aident à le reproduire.
                </p>
                <div class="form-row" style="margin-bottom:12px">
                    <textarea id="bug-description" rows="4" style="width:100%;padding:8px;border:1px solid var(--border-color);border-radius:6px;font-size:14px;font-family:inherit" placeholder="Décris le problème…"></textarea>
                </div>
                <details style="font-size:12px;color:var(--text-muted)">
                    <summary style="cursor:pointer;font-weight:600">📋 Infos techniques (automatiques)</summary>
                    <pre style="margin-top:8px;padding:8px;background:var(--bg-color);border-radius:4px;font-size:11px;overflow-x:auto;white-space:pre-wrap">${escapeHtml(JSON.stringify(infos, null, 2))}</pre>
                </details>
                <div id="bug-msg" class="text-muted small" style="margin-top:8px;min-height:1.2em"></div>
            `,
            footer: `
                <button class="btn btn-secondary" onclick="Modal.close()">Annuler</button>
                <button class="btn btn-primary" id="btn-send-bug">📧 Envoyer</button>
                <button class="btn btn-sm btn-secondary" id="btn-copy-bug" title="Copier les infos dans le presse-papier">📋 Copier</button>
            `,
        });

        document.getElementById('btn-send-bug').addEventListener('click', () => this._send(infos));
        document.getElementById('btn-copy-bug').addEventListener('click', () => this._copy(infos));
    },

    /** Collecte les infos techniques */
    _collectInfos() {
        return {
            page: window.location.hash || '#',
            url: window.location.href,
            date: new Date().toLocaleString('fr-FR'),
            navigateur: navigator.userAgent,
            resolution: `${screen.width}×${screen.height}`,
            annee_active: State.get('annee_scolaire_id'),
            annee_nom: State.get('annee_active')?.nom || '',
            toutes_periodes: State.get('toutes_periodes'),
            mode_consultation: State.get('consultation'),
            erreurs_console: (window._calulisErrors || []).slice(-10),
            derniere_erreur_api: window._calulisLastApiError || null,
            composant: Router.current || 'inconnu',
            vue: document.querySelector('.view.active')?.id || 'inconnue',
        };
    },

    /** Envoie par email */
    async _send(infos) {
        const description = document.getElementById('bug-description')?.value?.trim();
        const msg = document.getElementById('bug-msg');
        if (!description) {
            msg.textContent = '⚠ Décris le problème avant d\'envoyer.';
            msg.style.color = 'var(--danger)';
            return;
        }

        // Construction du mailto
        const sujet = encodeURIComponent('[Calulis Bug] ' + (Router.current || ''));
        const body = encodeURIComponent(
            'Description :\n' + description + '\n\n---\n' +
            JSON.stringify(infos, null, 2)
        );
        const mailto = 'mailto:kalimoucho08@gmail.com?subject=' + sujet + '&body=' + body;

        // Essayer d'ouvrir le mailto
        const win = window.open(mailto, '_blank');
        if (!win || win.closed) {
            // Fallback : copier dans le presse-papier
            await this._copy(infos, 'Email copié dans le presse-papier. Envoie-le à kalimoucho08@gmail.com');
            msg.textContent = '📧 Ouvre ton email et colle le contenu (Ctrl+V).';
            msg.style.color = '';
        } else {
            msg.textContent = '✅ Email préparé. Vérifie et envoie.';
            msg.style.color = 'var(--success)';
        }
        document.getElementById('btn-send-bug').textContent = '✅ Envoyé';
    },

    /** Copie dans le presse-papier */
    async _copy(infos, customMsg) {
        const description = document.getElementById('bug-description')?.value?.trim() || '';
        const text = 'Description :\n' + description + '\n\n---\n' + JSON.stringify(infos, null, 2);
        const msg = document.getElementById('bug-msg');

        try {
            await navigator.clipboard.writeText(text);
            msg.textContent = customMsg || '✅ Copié dans le presse-papier';
            msg.style.color = 'var(--success)';
        } catch {
            msg.textContent = '⚠ Copie manuelle : sélectionne le texte dans "Infos techniques"';
            msg.style.color = 'var(--danger)';
        }
    },
};
