/**
 * Calulis — Tableau de bord (Dashboard)
 * Page d'accueil avec compteurs, réunions à venir, lien agenda, alertes MDPH.
 */
const Dashboard = {

    async render() {
        const view = document.getElementById('view-dashboard');
        view.innerHTML = `
            <div class="dashboard-grid">
                <div class="dashboard-widget skeleton"><div class="skeleton-line skeleton-line-lg"></div><div class="skeleton-line skeleton-line-sm"></div><div class="skeleton-line skeleton-line-sm"></div></div>
                <div class="dashboard-widget skeleton"><div class="skeleton-line skeleton-line-lg"></div><div class="skeleton-line"></div><div class="skeleton-line"></div><div class="skeleton-line skeleton-line-sm"></div></div>
                <div class="dashboard-widget skeleton"><div class="skeleton-line skeleton-line-lg"></div><div class="skeleton-line"></div></div>
                <div class="dashboard-widget skeleton"><div class="skeleton-line skeleton-line-lg"></div><div class="skeleton-line"></div><div class="skeleton-line skeleton-line-sm"></div></div>
            </div>`;

        let eleves = [], reunions = [], semaines = [], periodes = [];
        try {
            [eleves, reunions, semaines, periodes] = await Promise.all([
                API.get('eleves.php'),
                API.get('reunions.php?upcoming=30'),
                API.get('semaines.php'),
                API.get('periodes.php'),
            ]);
        } catch (e) {
            view.innerHTML = `<div class="placeholder-view">
                <div class="placeholder-icon">⚠️</div>
                <div class="placeholder-title">Erreur de chargement</div>
                <div class="placeholder-text">${escapeHtml(e.message)}</div>
                <div class="placeholder-text" style="margin-top:10px;font-size:13px;max-width:520px">
                    Si le problème persiste, fermez puis relancez Calulis. Besoin d'aide ?
                    utilisez le bouton « 🐛 Signaler un bug » : il prépare un message avec
                    les informations techniques pour l'équipe.
                </div>
                <button class="btn btn-primary" style="margin-top:14px" onclick="BugReport.open()">🐛 Signaler un bug</button>
            </div>`;
            return;
        }

        // A21 : ne garder que les actifs — les élèves inactifs ont quitté le dispositif, leurs dates MDPH ne sont plus pertinentes
        const actifs = eleves.filter(e => e.actif);

        if (actifs.length === 0) {
            view.innerHTML = `
                <div class="dashboard-welcome">
                    <h2>Bienvenue dans Calulis !</h2>
                    <p>Commencez par ajouter des élèves et configurer votre établissement dans <a href="#" onclick="Router.go('params')">Paramètres</a>.</p>
                </div>`;
            return;
        }
        const ulis = actifs.filter(e => e.ulis);
        const classes = [...new Set(actifs.map(e => e.classe).filter(Boolean))];

        const now = new Date();
        const todayStr = toDateStr(now);
        const lundi = getLundi(now);

        // Semaine active dans l'année scolaire (contient aujourd'hui)
        const semaineActive = semaines.find(s => s.date_debut <= todayStr && s.date_fin >= todayStr);

        // Numérotation scolaire : ne compter que les semaines de cours (est_vacances=0),
        // jamais les semaines de vacances. Une année scolaire = 36 semaines.
        let semaineNum;
        let periodeInfo = '';
        if (semaineActive) {
            semaineNum = 'S' + getSchoolWeekNumber(semaineActive, semaines);

            // Contexte période : ne compter que les semaines de cours dans la période
            if (periodes.length > 0) {
                const periode = periodes.find(p =>
                    p.date_debut <= semaineActive.date_debut &&
                    p.date_fin >= semaineActive.date_fin
                );
                if (periode) {
                    // Filtrer les semaines de cours de cette période
                    const schoolWeeksInPeriode = semaines.filter(s =>
                        s.annee_scolaire_id === semaineActive.annee_scolaire_id &&
                        parseInt(s.est_vacances) !== 1 &&
                        s.date_debut >= periode.date_debut &&
                        s.date_fin <= periode.date_fin
                    ).sort((a, b) => a.numero - b.numero);
                    const idx = schoolWeeksInPeriode.findIndex(s => s.id === semaineActive.id);
                    const weekInPeriode = idx >= 0 ? idx + 1 : '?';
                    const total = schoolWeeksInPeriode.length;
                    periodeInfo = `${periode.nom} — Semaine ${weekInPeriode}/${total} · `;
                }
            }
        } else {
            semaineNum = getWeekNumber(now);
        }

        const mdphAlertes = actifs.filter(e => {
            const fields = ['mdph_ulis_date_fin','mdph_sessad_date_fin','mdph_aesh_date_fin','mdph_transport_date_fin','mdph_autre_date_fin'];
            return fields.some(f => e[f] && e[f] < todayStr);
        });

        view.innerHTML = `
            <div class="dashboard-grid">
                <div class="dashboard-widget">
                    <h3 class="dashboard-widget-title">Effectifs</h3>
                    <div class="dashboard-stats">
                        <div class="dashboard-stat">
                            <span class="dashboard-stat-value">${actifs.length}</span>
                            <span class="dashboard-stat-label">élèves actifs</span>
                        </div>
                        <div class="dashboard-stat">
                            <span class="dashboard-stat-value">${ulis.length}</span>
                            <span class="dashboard-stat-label">en ULIS</span>
                        </div>
                        <div class="dashboard-stat">
                            <span class="dashboard-stat-value">${classes.length}</span>
                            <span class="dashboard-stat-label">classes</span>
                        </div>
                        <div class="dashboard-stat">
                            <span class="dashboard-stat-value">${eleves.length - actifs.length}</span>
                            <span class="dashboard-stat-label">inactifs</span>
                        </div>
                    </div>
                </div>

                <div class="dashboard-widget">
                    <h3 class="dashboard-widget-title">Prochaines réunions</h3>
                    ${reunions.length === 0 ? '<p class="dashboard-empty">Aucune réunion prévue.</p>' : `
                    <ul class="dashboard-list">
                        ${reunions.slice(0, 5).map(r => `
                            <li class="dashboard-list-item">
                                <span class="reunion-date">${formatDate(r.date_reunion)}</span>
                                <span class="reunion-badge badge-sm badge-${(r.type || '').toLowerCase()}">${escapeHtml(r.type || '')}</span>
                                <span class="reunion-title">${escapeHtml(r.titre)}</span>
                                ${r.eleve_nom ? `<span class="reunion-eleve">${escapeHtml(r.eleve_prenom)} ${escapeHtml(r.eleve_nom)}</span>` : ''}
                                <span class="reunion-statut badge-sm badge-${(r.statut || '').toLowerCase()}">${escapeHtml(r.statut || '')}</span>
                            </li>
                        `).join('')}
                    </ul>`}
                    ${reunions.length > 5 ? `<p class="dashboard-more">+ ${reunions.length - 5} autre(s)...</p>` : ''}
                </div>

                <div class="dashboard-widget">
                    <h3 class="dashboard-widget-title">Agenda</h3>
                    <div class="dashboard-agenda">
                        <p>${periodeInfo}<strong>${semaineNum}</strong> — du <strong>${formatDate(toDateStr(lundi))}</strong></p>
                        <button class="btn btn-primary" id="dashboard-goto-agenda">📅 Voir l'agenda</button>
                    </div>
                </div>

                <div class="dashboard-widget">
                    <h3 class="dashboard-widget-title">Droits MDPH</h3>
                    ${mdphAlertes.length === 0
                        ? '<p class="dashboard-ok">✅ Tous les droits sont à jour.</p>'
                        : `<ul class="dashboard-list">
                            ${mdphAlertes.slice(0, 5).map(e => `
                                <li class="dashboard-list-item dashboard-mdph-item" data-eleve-id="${e.id}">
                                    <span class="dashboard-alert-badge">⚠️</span>
                                    ${escapeHtml(e.prenom)} ${escapeHtml(e.nom)}
                                </li>
                            `).join('')}
                        </ul>`
                    }
                </div>
            </div>
        `;

        document.getElementById('dashboard-goto-agenda')?.addEventListener('click', () => {
            State.set('agenda-goto-today', true);
            Router.go('agenda');
        });

        // Widget MDPH → ouvrir la fiche élève sur l'onglet MDPH
        view.querySelectorAll('.dashboard-mdph-item').forEach(li => {
            li.addEventListener('click', () => {
                const eleveId = parseInt(li.dataset.eleveId);
                const eleve = actifs.find(e => e.id === eleveId);
                if (eleve) {
                    FicheEleve.open(eleve);
                    FicheEleve._switchTab('mdph');
                }
            });
        });

        // Widget réunions → aller à la page réunions
        view.querySelectorAll('.dashboard-list-item:not(.dashboard-mdph-item)').forEach(li => {
            li.addEventListener('click', () => Router.go('reunions'));
        });
    },

};
