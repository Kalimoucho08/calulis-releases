/**
 * Calulis — Guide d'aide complet
 * Accessible depuis la sidebar (📖 Aide)
 * Cible : enseignants, coordonnateurs ULIS — pas de jargon informatique
 */
const AideView = {

    async render() {
        const view = document.getElementById('view-aide');
        view.innerHTML = this._buildHTML();
        this._bindEvents();
    },

    _buildHTML() {
        return `
        <div class="aide-container">
            <div class="aide-sidebar">
                <h2 class="aide-title">📖 Guide Calulis</h2>
                <div class="aide-nav">
                    <button class="aide-nav-item active" data-section="demarrage">🚀 Premier démarrage</button>
                    <button class="aide-nav-item" data-section="concepts">🧠 Comprendre Calulis</button>
                    <button class="aide-nav-item" data-section="dashboard-2">📋 Tableau de bord</button>
                    <button class="aide-nav-item" data-section="eleves-2">👥 Élèves</button>
                    <button class="aide-nav-item" data-section="agenda-2">📅 Agenda (EDT)</button>
                    <button class="aide-nav-item" data-section="adultes-2">👩‍🏫 Adultes</button>
                    <button class="aide-nav-item" data-section="reunions-2">🤝 Réunions</button>
                    <button class="aide-nav-item" data-section="evenements-2">📆 Événements</button>
                    <button class="aide-nav-item" data-section="stats-2">📊 Statistiques</button>
                    <button class="aide-nav-item" data-section="impression-2">🖨️ Impression</button>
                    <button class="aide-nav-item" data-section="params-2">⚙️ Paramètres</button>
                    <button class="aide-nav-item" data-section="scenarios">📋 Scénarios pas à pas</button>
                    <button class="aide-nav-item" data-section="raccourcis">⌨️ Raccourcis</button>
                    <button class="aide-nav-item" data-section="rgpd">🔒 Données personnelles</button>
                    <button class="aide-nav-item" data-section="astuces">💡 Astuces</button>
                    <button class="aide-nav-item" data-section="nouveautes">🎉 Nouveautés</button>
                </div>
            </div>
            <div class="aide-content" id="aide-content">
                ${this._sectionDemarrage()}
            </div>
        </div>`;
    },

    _card(title, body) {
        return '<div class="aide-card"><h4>' + escapeHtml(title) + '</h4>' + body + '</div>';
    },
    _li(item) { return '<li>' + item + '</li>'; },
    _ol(items) { return '<ol>' + items.map(i => this._li(i)).join('') + '</ol>'; },
    _ul(items) { return '<ul>' + items.map(i => this._li(i)).join('') + '</ul>'; },

    /* =========================== SECTIONS =========================== */

    _sectionDashboard() {
        return '<section class="aide-section" id="aide-dashboard-2">' +
            '<h3>📋 Tableau de bord</h3>' +
            '<p>Le tableau de bord est la page d\'accueil de Calulis. Il donne une vue d\'ensemble de votre dispositif ULIS en un coup d\'œil.</p>' +
            this._card('Widget Effectifs',
                '<p>Affiche le nombre d\'élèves actifs et le nombre de classes distinctes pour l\'année en cours. Cliquez pour accéder à la liste des élèves.</p>') +
            this._card('Widget Prochaines réunions',
                '<p>Liste les 3 prochaines réunions planifiées avec leur date et statut. Cliquez pour accéder au module Réunions.</p>') +
            this._card('Widget Agenda — semaine en cours',
                '<p>Affiche la semaine scolaire actuelle avec son contexte : période en cours (ex: « Période 5 — Semaine 8/10 · S36 ») et les événements de la semaine. La numérotation <strong>S1→S36</strong> ne compte que les semaines de cours (hors vacances).</p>') +
            this._card('Widget Alertes MDPH',
                '<p>Affiche les élèves dont les droits MDPH expirent prochainement. <strong>Cliquez sur un élève</strong> pour ouvrir directement sa fiche sur l\'onglet MDPH — pratique pour anticiper les renouvellements.</p>') +
        '</section>';
    },

    _sectionDemarrage() {
        return '<section class="aide-section" id="aide-demarrage">' +
            '<h3>🚀 Premier démarrage</h3>' +
            '<p>Bienvenue dans <strong>Calulis</strong> ! Cette application vous aide à gérer votre dispositif ULIS au quotidien : emplois du temps, suivi des élèves, réunions, statistiques.</p>' +
            this._card('1. Configurez votre établissement',
                '<p>Allez dans <strong>⚙️ Paramètres</strong> → section <em>Notre établissement</em>. Sélectionnez votre école dans la liste. Si elle n\'existe pas encore, créez-la dans <strong>🏫 Établissements</strong>.</p>') +
            this._card('2. Créez vos classes',
                '<p>Allez dans <strong>🏷️ Classes</strong>. Créez les classes de votre école (CP, CE1, CE2…). Associez chaque classe à son enseignant. Ces classes servent de référence pour le rattachement des élèves (obligation légale : chaque élève ULIS est inscrit dans une classe ordinaire).</p>') +
            this._card('3. Ajoutez vos élèves',
                '<p>Allez dans <strong>👥 Élèves</strong> → <em>+ Nouvel élève</em>. Remplissez la fiche : identité, date de naissance, classe de référence, date d\'entrée ULIS. Les autres onglets (AESH, MDPH, Médical, Représentants) peuvent être complétés plus tard.</p>') +
            this._card('4. Ajoutez les adultes',
                '<p>Allez dans <strong>👩‍🏫 Adultes</strong> → <em>+ Nouvel adulte</em>. Ajoutez les enseignants, les AESH, les intervenants extérieurs (orthophoniste, psychomotricien, éducateur…).</p>') +
            this._card('5. Configurez l\'agenda',
                '<p>Allez dans <strong>⚙️ Paramètres</strong> : définissez les horaires de l\'école, les jours travaillés, les pauses (récréations, pause méridienne).</p>') +
            this._card('6. Créez votre semaine type',
                '<p>Dans l\'<strong>📅 Agenda</strong>, commencez par la <strong>Semaine type 📋</strong> (le modèle). Double-cliquez dans une case vide pour créer un créneau. Une fois votre modèle prêt, utilisez <em>Appliquer le template</em> pour le copier sur les semaines souhaitées.</p>') +
        '</section>';
    },

    _sectionConcepts() {
        return '<section class="aide-section" id="aide-concepts">' +
            '<h3>🧠 Comprendre Calulis</h3>' +
            this._card('Qu\'est-ce qu\'un créneau ?',
                '<p>Un <strong>créneau</strong> est une case dans l\'emploi du temps. Il contient : un ou plusieurs élèves, un ou plusieurs adultes, une activité (ex: "Français ULIS"), un type de regroupement (ex: ULIS, Inclusion) et une couleur. C\'est l\'unité de base de l\'agenda.</p>') +
            this._card('Types de regroupement',
                '<p>Chaque créneau a un <strong>type</strong> qui indique comment l\'élève est regroupé :</p>' +
                this._ul(['<strong>ULIS</strong> — l\'élève est dans le dispositif, avec le coordonnateur',
                          '<strong>Inclusion</strong> — l\'élève est dans sa classe de référence',
                          '<strong>Décloisonnement</strong> — l\'élève est dans une autre classe que la sienne',
                          '<strong>PEC</strong> — Prise En Charge extérieure (orthophonie, CMPP, SESSAD…)',
                          '<strong>Regroupement</strong>, <strong>Atelier</strong>, <strong>Projet</strong> — personnalisables dans les Paramètres']) +
                '<p>Ces types servent aux <strong>statistiques</strong> : Calulis compte automatiquement le temps passé par chaque élève dans chaque type.</p>') +
            this._card('Année scolaire',
                '<p>Le sélecteur en haut à droite permet de changer d\'année scolaire. Chaque année a ses propres élèves, classes, réunions et emplois du temps. Les données sont <strong>indépendantes</strong> : modifier 2026-2027 ne touche pas 2025-2026. Vous pouvez préparer la rentrée suivante sans perdre l\'historique.</p>') +
            this._card('Semaine type (template 📋)',
                '<p>La <strong>Semaine type</strong> est un modèle qui sert de base pour remplir les semaines réelles. Construisez votre EDT idéal une fois, puis appliquez-le aux semaines souhaitées. Les semaines déjà modifiées ne sont pas écrasées si vous choisissez <em>Appliquer aux semaines non modifiées</em>.</p>') +
            this._card('Mode consultation 🔓',
                '<p>Le bouton <strong>🔓</strong> dans la barre du haut verrouille l\'interface : plus aucune modification possible. Idéal pour présenter l\'EDT en réunion sans risque de clic malencontreux.</p>') +
        '</section>';
    },

    _sectionEleves() {
        return '<section class="aide-section" id="aide-eleves-2">' +
            '<h3>👥 Élèves</h3>' +
            '<p>La page Élèves affiche la liste de tous les élèves suivis par le dispositif ULIS pour l\'année scolaire en cours.</p>' +
            this._card('Filtrer la liste',
                this._ul(['<strong>Niveau</strong> (CP, CE1, CE2…) — filtre par niveau de classe',
                          '<strong>Classe</strong> (CP — Marie Martin…) — filtre par classe spécifique',
                          '<strong>ULIS / Non ULIS</strong> — filtre par statut dispositif',
                          '<strong>Actifs / Inactifs</strong> — un élève inactif est sorti du dispositif (il reste en base pour l\'historique)'])) +
            this._card('La fiche élève (6 onglets)',
                '<p>Cliquez sur <strong>Fiche</strong> pour consulter, ou <strong>Modifier</strong> pour éditer :</p>' +
                this._ul(['<strong>Identité</strong> — nom, prénom, date de naissance, téléphone, adresse, transport, cantine',
                          '<strong>Scolarité</strong> — classe de référence, établissement, date d\'entrée ULIS, école d\'origine',
                          '<strong>AESH & PEC</strong> — accompagnants et prises en charge extérieures (orthophonie, psychomot…)',
                          '<strong>MDPH & Plans</strong> — dates de droits (ULIS, SESSAD, AESH, Transport), notifications',
                          '<strong>Médical</strong> — PAI, traitements, pathologies (restreint au personnel autorisé)',
                          '<strong>Représentants légaux</strong> — parents, tuteurs, contacts d\'urgence'])) +
            this._card('Colonnes du tableau',
                this._ul(['<strong>Âge</strong> — calculé automatiquement depuis la date de naissance',
                          '<strong>Années ULIS</strong> — nombre d\'années scolaires dans le dispositif',
                          '<strong>Tri</strong> — cliquez sur un en-tête pour trier (▲ ascendant, ▼ descendant)'])) +
        '</section>';
    },

    _sectionAgenda() {
        return '<section class="aide-section" id="aide-agenda-2">' +
            '<h3>📅 Agenda (Emploi du temps)</h3>' +
            '<p>L\'agenda est le cœur de Calulis. C\'est ici que vous construisez et visualisez les emplois du temps de vos élèves.</p>' +
            this._card('Créer un créneau',
                '<p><strong>Double-cliquez</strong> dans une case vide de la grille. Remplissez le formulaire : activité, type, élève(s), adulte(s). Le créneau apparaît avec la couleur de son type de regroupement.</p>') +
            this._card('Modifier un créneau',
                '<p><strong>Double-cliquez</strong> sur un créneau existant pour l\'éditer.</p>') +
            this._card('Déplacer ou copier',
                this._ul(['<strong>Glisser-déposer</strong> — déplace un créneau vers une autre case',
                          '<strong>Ctrl + glisser</strong> — copie le créneau au lieu de le déplacer',
                          '<strong>Clic droit</strong> — menu Couper / Copier / Coller'])) +
            this._card('Vue élèves vs Vue adultes',
                this._ul(['<strong>👥 Élèves</strong> — l\'EDT est organisé par élève (chaque élève a sa colonne)',
                          '<strong>👤 Adultes</strong> — l\'EDT est organisé par adulte. Pratique pour vérifier la charge d\'un AESH'])) +
            this._card('Filtres',
                '<p>Tous les filtres sont <strong>cumulatifs</strong> :</p>' +
                this._ul(['<strong>Élève</strong> — n\'affiche que les créneaux de cet élève',
                          '<strong>Groupe</strong> — filtre par groupe (ULIS, CP-CE1, Rouge…)',
                          '<strong>Intervenant</strong> — n\'affiche que les créneaux où cet adulte est présent'])) +
            this._card('Appliquer le template',
                '<p>Une fois votre Semaine type construite, utilisez les boutons <em>Appliquer</em> pour la copier :</p>' +
                this._ul(['<strong>Toutes</strong> — écrase toutes les semaines (attention !)',
                          '<strong>Non modifiées</strong> — ne touche pas aux semaines déjà personnalisées',
                          '<strong>Choisir…</strong> — sélectionnez les semaines une par une'])) +
        '</section>';
    },

    _sectionAdultes() {
        return '<section class="aide-section" id="aide-adultes-2">' +
            '<h3>👩‍🏫 Adultes</h3>' +
            '<p>Gérez tous les adultes qui interviennent auprès des élèves ULIS.</p>' +
            this._card('Catégories',
                this._ul(['<strong>Enseignants</strong> — de votre école (filtre 👩‍🏫)',
                          '<strong>Personnel</strong> — AESH, AESHco, coordonnateur ULIS, directeur… (filtre 👥)',
                          '<strong>Externes</strong> — orthophoniste, psychomotricien, éducateur ASE… (filtre 🌍)'])) +
            this._card('Co-intervention',
                '<p>Un créneau peut avoir <strong>plusieurs adultes</strong> (ex: enseignant + AESH). Dans le formulaire de créneau, ajoutez les intervenants et attribuez un rôle à chacun.</p>') +
            this._card('Fiche adulte',
                '<p>La fiche contient : nom, prénom, civilité, rôle, fonction, téléphone, email, établissement de rattachement, commentaires. Un adulte peut être rattaché à <strong>plusieurs établissements</strong> (ex: un AESH qui intervient dans deux écoles).</p>') +
        '</section>';
    },

    _sectionReunions() {
        return '<section class="aide-section" id="aide-reunions-2">' +
            '<h3>🤝 Réunions</h3>' +
            '<p>Toutes les réunions liées au dispositif ULIS, avec filtres par type, statut et élève.</p>' +
            this._card('Types de réunions',
                this._ul(['<strong>ESS</strong> — Équipe de Suivi de Scolarisation (obligatoire, présidée par l\'enseignant référent MDPH)',
                          '<strong>Équipe éducative</strong> — réunion élargie (enseignants, AESH, parents, partenaires)',
                          '<strong>Équipe de suivi</strong> — suivi interne ULIS (coordo, AESH, enseignants)',
                          '<strong>RDV famille</strong> — rendez-vous avec les parents',
                          '<strong>Partenariat</strong> — réunion avec un partenaire extérieur (SESSAD, CMPP, ASE…)',
                          '<strong>Autre</strong> — personnalisable'])) +
            this._card('Statuts',
                this._ul(['<strong>Prévue</strong> — date fixée, en attente',
                          '<strong>En cours</strong> — la réunion se prépare (ordre du jour envoyé)',
                          '<strong>Réalisée</strong> — compte-rendu rédigé',
                          '<strong>Annulée</strong> — ne compte plus',
                          '<strong>Reportée</strong> — nouvelle date à fixer'])) +
        '</section>';
    },

    _sectionEvenements() {
        return '<section class="aide-section" id="aide-evenements-2">' +
            '<h3>📆 Événements</h3>' +
            '<p>L\'agenda des événements de l\'année : jours fériés, vacances, sorties, examens, anniversaires…</p>' +
            this._card('Modèles prédéfinis',
                '<p>Calulis fournit ~60 événements modèles (jours fériés, semaines thématiques, examens…). Cochez la case pour <strong>activer</strong> un modèle : il devient un événement daté. Décochez pour le désactiver. Les modèles inactifs restent disponibles pour plus tard.</p>') +
            this._card('Anniversaires',
                '<p>Le bouton <strong>🎂 Générer les anniversaires</strong> crée automatiquement un événement par élève actif. Vous pouvez le réutiliser sans risque de doublons.</p>') +
            this._card('Événements personnalisés',
                '<p>Cliquez sur <strong>+ Événement</strong> pour créer vos propres événements (sortie scolaire, spectacle, conseil d\'école…).</p>') +
        '</section>';
    },

    _sectionStats() {
        return '<section class="aide-section" id="aide-stats-2">' +
            '<h3>📊 Statistiques</h3>' +
            '<p>Les statistiques calculent automatiquement le temps passé par chaque élève dans les différents types de regroupement, à partir des créneaux de l\'agenda.</p>' +
            this._card('Ce qui est compté',
                '<p>Calulis additionne les durées de tous les créneaux et les répartit par <strong>type</strong> : ULIS, Inclusion, Décloisonnement, PEC… Les résultats sont utilisables pour :</p>' +
                this._ul(['Les <strong>rapports administratifs</strong> — justifier le temps de scolarisation',
                          'Les <strong>ESS</strong> — présenter la répartition du temps de l\'élève',
                          'Le <strong>pilotage</strong> — vérifier l\'équilibre inclusion / dispositif ULIS'])) +
        '</section>';
    },

    _sectionImpression() {
        return '<section class="aide-section" id="aide-impression-2">' +
            '<h3>🖨️ Impression (Export PDF)</h3>' +
            '<p>Exportez les emplois du temps en PDF pour les afficher, les transmettre aux familles ou les joindre aux dossiers.</p>' +
            this._card('Types d\'export',
                this._ul(['<strong>Semaine · Élève</strong> — EDT complet d\'un élève sur une semaine, A4 portrait',
                          '<strong>Semaine · Adulte</strong> — EDT d\'un adulte, A4 portrait',
                          '<strong>Jour · Élève(s)</strong> — un jour pour un ou plusieurs élèves, A4 paysage',
                          '<strong>Jour · Adulte(s)</strong> — un jour pour un ou plusieurs adultes',
                          '<strong>📊 Statistiques</strong> — tableau de bord, inclusion détaillée, évolution multi-année'])) +
            this._card('Marche à suivre',
                this._ol(['Sélectionnez le type d\'export',
                          'Choisissez l\'élève (ou l\'adulte) et la semaine',
                          'Cliquez sur <strong>Générer l\'aperçu</strong>',
                          'Vérifiez le rendu dans le panneau de droite',
                          'Utilisez le zoom et la navigation entre les pages',
                          'Cliquez sur <strong>Télécharger PDF</strong>'])) +
        '</section>';
    },

    _sectionParams() {
        return '<section class="aide-section" id="aide-params-2">' +
            '<h3>⚙️ Paramètres</h3>' +
            '<p>Configurez Calulis selon le fonctionnement de votre école.</p>' +
            this._card('Couleurs par type',
                '<p>Chaque type de regroupement a une couleur. Elle s\'applique automatiquement dans l\'agenda. Choisissez des teintes distinctes, lisibles à l\'écran comme à l\'impression.</p>') +
            this._card('Horaires',
                '<p>Définissez l\'heure de début, l\'heure de fin et la durée d\'un créneau (15 minutes recommandé). La grille de l\'agenda s\'adapte automatiquement.</p>') +
            this._card('Jours affichés',
                '<p>Cochez les jours qui apparaissent dans l\'agenda. Décochez les jours sans cours (mercredi, samedi) pour une grille plus lisible.</p>') +
            this._card('Pauses',
                '<p>Ajoutez les récréations et la pause méridienne. Elles apparaissent comme des bandes dans l\'agenda. Un créneau peut chevaucher une pause (sortie scolaire, projet…).</p>') +
            this._card('APC',
                '<p>Les <strong>Activités Pédagogiques Complémentaires</strong> sont des créneaux hors temps scolaire : le midi, le soir après la classe, ou le mercredi matin. Activez-les ici.</p>') +
        '</section>';
    },

    _sectionScenarios() {
        return '<section class="aide-section" id="aide-scenarios">' +
            '<h3>📋 Scénarios pas à pas</h3>' +
            '<p>Des exemples concrets pour vous guider dans les tâches quotidiennes.</p>' +

            this._card('📌 Scénario 1 — Préparer la rentrée de septembre',
                this._ol(['Créez la <strong>nouvelle année scolaire</strong> (sélecteur en haut → + Nouvelle année)',
                          'Dans <strong>⚙️ Paramètres</strong>, vérifiez votre établissement, les horaires, les jours travaillés',
                          'Dans <strong>🏷️ Classes</strong>, mettez à jour les classes avec les nouveaux enseignants',
                          'Dans <strong>👥 Élèves</strong>, ajoutez les nouveaux élèves',
                          'Dans <strong>👩‍🏫 Adultes</strong>, mettez à jour les AESH et intervenants',
                          'Dans <strong>📅 Agenda</strong>, construisez la <em>Semaine type</em> pour cette nouvelle année',
                          'Appliquez le template aux premières semaines (bouton <em>Toutes</em> ou <em>Non modifiées</em>)',
                          'Dans <strong>📆 Événements</strong>, générez les anniversaires et activez les événements de l\'année'])) +

            this._card('📌 Scénario 2 — Préparer une ESS',
                this._ol(['Dans <strong>🤝 Réunions</strong>, créez la réunion (type ESS, date, heure, élève concerné)',
                          'Dans <strong>🖨️ Impression</strong>, exportez l\'EDT de l\'élève (Semaine · Élève)',
                          'Dans <strong>📊 Statistiques</strong>, exportez le tableau de bord ou l\'inclusion détaillée',
                          'Imprimez ou enregistrez les PDF pour le dossier de l\'élève',
                          'Après la réunion, passez la réunion en statut <em>Réalisée</em>',
                          'Dans la fiche élève, onglet MDPH, mettez à jour les dates de droits si nécessaire'])) +

            this._card('📌 Scénario 3 — Modifier l\'EDT d\'un élève en cours d\'année',
                this._ol(['Dans <strong>📅 Agenda</strong>, choisissez la semaine concernée',
                          'Double-cliquez sur le créneau à modifier → faites vos changements',
                          'Pour un changement permanent, modifiez aussi la <em>Semaine type</em>',
                          'Utilisez <em>Appliquer le template → Choisir les semaines cibles</em> pour propager'])) +

            this._card('📌 Scénario 4 — Vérifier la charge d\'un AESH',
                this._ol(['Dans <strong>📅 Agenda</strong>, basculez en vue <strong>👤 Adultes</strong>',
                          'Dans le filtre <em>Intervenant</em>, sélectionnez l\'AESH concerné',
                          'Parcourez les semaines : vous voyez tous ses créneaux',
                          'Dans <strong>🖨️ Impression → Semaine · Adulte</strong>, exportez son EDT pour justifier son temps'])) +

            this._card('📌 Scénario 5 — Bilan de fin d\'année',
                this._ol(['Dans <strong>📊 Statistiques</strong>, consultez les temps par type de regroupement',
                          'Dans <strong>🖨️ Impression → Statistiques</strong>, exportez le tableau de bord',
                          'Exportez l\'évolution multi-année pour le rapport d\'activité',
                          'Dans <strong>👥 Élèves</strong>, exportez la liste en CSV (bouton 📥)'])) +

            this._card('📌 Scénario 6 — Recevoir un nouvel élève en cours d\'année',
                this._ol(['Dans <strong>👥 Élèves → + Nouvel élève</strong>, créez sa fiche complète',
                          'Onglet <strong>Scolarité</strong> : renseignez sa classe de référence et l\'école d\'origine',
                          'Onglet <strong>MDPH</strong> : saisissez les dates de droits (notification MDPH)',
                          'Onglet <strong>AESH & PEC</strong> : ajoutez ses accompagnants',
                          'Dans <strong>📅 Agenda</strong>, ajoutez-le aux créneaux existants (double-clic → ajouter l\'élève)',
                          'Adaptez son EDT si ses temps de présence sont différents'])) +
        '</section>';
    },

    _sectionRaccourcis() {
        return '<section class="aide-section" id="aide-raccourcis">' +
            '<h3>⌨️ Raccourcis clavier</h3>' +
            this._card('Généraux',
                '<table class="aide-table"><tr><th>Touche</th><th>Action</th></tr>' +
                '<tr><td><kbd>Alt+1</kbd> à <kbd>Alt+5</kbd></td><td>Navigation rapide (Dashboard, Élèves, Agenda, Réunions, Paramètres)</td></tr>' +
                '<tr><td><kbd>Ctrl+F</kbd></td><td>Recherche globale (élève, adulte, établissement)</td></tr>' +
                '<tr><td><kbd>?</kbd></td><td>Afficher / masquer les bulles d\'aide contextuelle</td></tr>' +
                '<tr><td><kbd>Échap</kbd></td><td>Fermer la recherche globale</td></tr>' +
                '</table>') +
            this._card('Dans l\'agenda',
                '<table class="aide-table"><tr><th>Action</th><th>Raccourci</th></tr>' +
                '<tr><td>Créer un créneau</td><td>Double-clic dans une case vide</td></tr>' +
                '<tr><td>Modifier un créneau</td><td>Double-clic sur un créneau</td></tr>' +
                '<tr><td>Déplacer un créneau</td><td>Glisser-déposer</td></tr>' +
                '<tr><td>Copier un créneau</td><td>Ctrl + glisser-déposer</td></tr>' +
                '<tr><td>Couper/Copier/Coller</td><td>Clic droit sur un créneau</td></tr>' +
                '</table>') +
        '</section>';
    },

    _sectionAstuces() {
        return '<section class="aide-section" id="aide-astuces">' +
            '<h3>💡 Astuces</h3>' +
            this._card('🔍 Recherche globale',
                '<p>La barre de recherche en haut à droite permet de trouver rapidement un élève, un adulte ou un établissement. Tapez quelques lettres du nom.</p>') +
            this._card('🌙 Mode sombre',
                '<p>Le bouton 🌙 bascule en mode sombre. Confortable pour travailler le soir. Le mode clair est recommandé pour la vidéoprojection en classe.</p>') +
            this._card('📥 Export CSV',
                '<p>Sur les pages Élèves et Adultes, le bouton 📥 CSV exporte la liste au format tableur (Excel, LibreOffice). Pratique pour les listes de rentrée.</p>') +
            this._card('🔄 Préparer l\'année suivante',
                '<p>Créez la nouvelle année scolaire via le sélecteur. Vous pouvez y travailler librement : vos données actuelles ne sont pas affectées. Idéal pour anticiper la rentrée pendant l\'été.</p>') +
            this._card('📋 Dupliquer des créneaux',
                '<p>Construisez votre Semaine type, puis <em>Appliquer le template → Non modifiées</em>. Les semaines déjà personnalisées (sortie, absence…) restent intactes.</p>') +
            this._card('👥 Co-intervention',
                '<p>Un créneau peut avoir plusieurs adultes (enseignant + AESH par exemple). Dans le formulaire, ajoutez tous les intervenants nécessaires.</p>') +
            this._card('⚠️ Droits MDPH',
                '<p>Le tableau de bord affiche une alerte quand les droits MDPH d\'un élève expirent. Anticipez les renouvellements.</p>') +
        '</section>';
    },

    _sectionRgpd() {
        return '<section class="aide-section" id="aide-rgpd">' +
            '<h3>🔒 Données personnelles et RGPD</h3>' +
            this._card('🛡️ Quelles données sont collectées ?',
                '<p>Calulis stocke uniquement les données nécessaires au suivi pédagogique et administratif ULIS : nom, prénom, classe, coordonnées des représentants légaux, dates de droits MDPH, précautions médicales pour la vie scolaire (hors diagnostic).</p>' +
                '<p><strong>Calulis ne collecte pas</strong> : de photos, de vidéos, de diagnostics médicaux, ou de données de connexion.</p>') +
            this._card('⚖️ Base légale',
                '<p>Le traitement repose sur la <strong>mission d\'intérêt public</strong> (RGPD art. 6.1.e) dans le cadre des missions ULIS définies par le code de l\'éducation.</p>' +
                '<p>Les données MDPH sont traitées dans le cadre de l\'obligation réglementaire de suivi des notifications CDAPH.</p>') +
            this._card('🔐 Sécurité',
                '<p>L\'application fonctionne <strong>entièrement en local</strong> sur votre poste. Aucune donnée n\'est transmise à des serveurs distants. Les sauvegardes (.sql) doivent être stockées dans un endroit sécurisé.</p>' +
                '<p>Pas d\'analytics, pas de cookies, pas de télémétrie.</p>') +
            this._card('📄 En savoir plus',
                '<p>Consultez la page <strong>Mentions RGPD</strong> (sidebar → 📄 Mentions RGPD) pour le détail complet des traitements, durées de conservation, droits des personnes et coordonnées du DPD académique.</p>') +
        '</section>';
    },

    /* =========================== NAVIGATION =========================== */

    /* ====================== NOUVEAUTÉS ====================== */

    _sectionNouveautes() {
        const entries = (typeof Changelog !== 'undefined' ? Changelog.entries : []).slice(0, 5);
        if (entries.length === 0) {
            return '<section class="aide-section" id="aide-nouveautes"><h3>🎉 Nouveautés</h3><p>Aucune information disponible.</p></section>';
        }
        const html = entries.map(en => {
            const items = en.items.map(i => '<li>' + escapeHtml(i) + '</li>').join('');
            return '<div class="aide-card">' +
                '<h4>Version ' + escapeHtml(en.version) + (en.date ? ' — ' + escapeHtml(en.date) : '') + '</h4>' +
                '<ul>' + items + '</ul>' +
                '</div>';
        }).join('');
        return '<section class="aide-section" id="aide-nouveautes">' +
            '<h3>🎉 Quoi de neuf ?</h3>' +
            '<p>Les nouveautés des dernières versions de Calulis.</p>' +
            html +
            '</section>';
    },

    _bindEvents() {
        // Ouverture directe d'une section (ex : « Quoi de neuf ? » depuis le dashboard)
        const requested = State.get('aide-section');
        if (requested) {
            const target = document.querySelector('.aide-nav-item[data-section="' + requested + '"]');
            if (target) {
                document.querySelectorAll('.aide-nav-item').forEach(b => b.classList.remove('active'));
                target.classList.add('active');
                const content = document.getElementById('aide-content');
                content.innerHTML = (requested === 'nouveautes' ? this._sectionNouveautes() : this._sectionDemarrage());
                content.scrollTop = 0;
                State.set('aide-section', null);
            }
        }
        document.querySelectorAll('.aide-nav-item').forEach(btn => {
            btn.addEventListener('click', () => {
                document.querySelectorAll('.aide-nav-item').forEach(b => b.classList.remove('active'));
                btn.classList.add('active');
                const section = btn.dataset.section;
                const content = document.getElementById('aide-content');
                const sections = {
                    demarrage: this._sectionDemarrage(),
                    concepts: this._sectionConcepts(),
                    'dashboard-2': this._sectionDashboard(),
                    'eleves-2': this._sectionEleves(),
                    'agenda-2': this._sectionAgenda(),
                    'adultes-2': this._sectionAdultes(),
                    'reunions-2': this._sectionReunions(),
                    'evenements-2': this._sectionEvenements(),
                    'stats-2': this._sectionStats(),
                    'impression-2': this._sectionImpression(),
                    'params-2': this._sectionParams(),
                    scenarios: this._sectionScenarios(),
                    raccourcis: this._sectionRaccourcis(),
                    rgpd: this._sectionRgpd(),
                    astuces: this._sectionAstuces(),
                    nouveautes: this._sectionNouveautes(),
                };
                content.innerHTML = sections[section] || '';
                content.scrollTop = 0;
            });
        });
    },
};
