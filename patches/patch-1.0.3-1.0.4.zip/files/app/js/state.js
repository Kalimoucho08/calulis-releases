/**
 * Calulis — Store central Pub/Sub
 * Usage : state.on('event', callback) / state.emit('event', data)
 *         state.get(key) / state.set(key, value)
 */
const State = {
    _data: {},
    _listeners: {},

    get(key) {
        return this._data[key];
    },

    set(key, value) {
        const prev = this._data[key];
        this._data[key] = value;
        this.emit(key + ':changed', { prev, value });
        this.emit('state:changed', { key, prev, value });
    },

    on(event, callback) {
        if (!this._listeners[event]) this._listeners[event] = [];
        this._listeners[event].push(callback);
    },

    off(event, callback) {
        if (!this._listeners[event]) return;
        this._listeners[event] = this._listeners[event].filter(cb => cb !== callback);
    },

    emit(event, data) {
        if (!this._listeners[event]) return;
        this._listeners[event].forEach(cb => {
            try { cb(data); } catch (e) { console.error('[State] Error in listener for', event, e); }
        });
    },

    /**
     * Charge l'année active depuis l'API et initialise le state
     * Appelé au boot de l'app
     */
    async initAnneeScolaire() {
        try {
            const resp = await fetch('/api/annees_scolaires.php?active=1');
            if (!resp.ok) throw new Error('HTTP ' + resp.status);
            const active = await resp.json();
            if (active && active.id) {
                this.set('annee_scolaire_id', active.id);
                this.set('annee_active', active);
            }
            // Charger la liste des années
            const respAll = await fetch('/api/annees_scolaires.php');
            if (respAll.ok) {
                const all = await respAll.json();
                this.set('annees', all);
            }
            this.set('toutes_periodes', false);
            this.saveSnapshot('multi-année init');
        } catch (e) {
            console.warn('[State] Impossible de charger l\'année active:', e);
            this.set('annee_scolaire_id', null);
            this.set('annees', []);
            this.set('toutes_periodes', false);
            // Alerte visible au boot (sinon l'échec reste silencieux)
            if (typeof Toast !== 'undefined') {
                Toast.error('Impossible de contacter le serveur Calulis. Vérifiez que l\'application est bien démarrée.');
            }
        }
    },

    /**
     * Retourne la liste des paramètres qui changent selon l'année active
     */
    getQueryParams() {
        const params = {};
        const anneeId = this.get('annee_scolaire_id');
        const toutesPeriodes = this.get('toutes_periodes');
        if (anneeId && !toutesPeriodes) {
            params.annee_scolaire_id = anneeId;
        }
        return params;
    },

    /** Undo/Redo — historique simple (max 50 états) */
    _history: [],
    _historyIndex: -1,
    _maxHistory: 50,

    saveSnapshot(label = '') {
        // Supprime les états futurs si on est en arrière
        if (this._historyIndex < this._history.length - 1) {
            this._history = this._history.slice(0, this._historyIndex + 1);
        }
        this._history.push({ label, data: JSON.parse(JSON.stringify(this._data)) });
        if (this._history.length > this._maxHistory) this._history.shift();
        this._historyIndex = this._history.length - 1;
        this.emit('history:changed', { canUndo: this.canUndo(), canRedo: this.canRedo() });
    },

    undo() {
        if (!this.canUndo()) return;
        this._historyIndex--;
        this._data = JSON.parse(JSON.stringify(this._history[this._historyIndex].data));
        this.emit('history:changed', { canUndo: this.canUndo(), canRedo: this.canRedo() });
        this.emit('state:restored');
    },

    redo() {
        if (!this.canRedo()) return;
        this._historyIndex++;
        this._data = JSON.parse(JSON.stringify(this._history[this._historyIndex].data));
        this.emit('history:changed', { canUndo: this.canUndo(), canRedo: this.canRedo() });
        this.emit('state:restored');
    },

    canUndo() { return this._historyIndex > 0; },
    canRedo() { return this._historyIndex < this._history.length - 1; },

    /** Sauvegarde localStorage */
    save(key = 'calulis_state') {
        try {
            localStorage.setItem(key, JSON.stringify(this._data));
        } catch (e) {
            console.error('[State] localStorage save failed:', e);
        }
    },

    load(key = 'calulis_state') {
        try {
            const raw = localStorage.getItem(key);
            if (raw) { this._data = JSON.parse(raw); this.emit('state:restored', this._data); }
        } catch (e) {
            console.error('[State] localStorage load failed:', e);
        }
    },
};
