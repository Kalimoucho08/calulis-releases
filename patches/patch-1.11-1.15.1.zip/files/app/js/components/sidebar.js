/**
 * Calulis — Sidebar de navigation
 * Une entrée par vue réellement disponible (l'ordre du tableau = l'ordre affiché).
 *
 * « Documents » n'y figure PAS : le module n'existe pas encore (contrôleur vide,
 * aucune vue). Une entrée qui n'ouvre rien est un défaut visible — elle sera
 * rajoutée le jour où l'écran existera (décision du 29/09/2026).
 */
const Sidebar = {
    _items: [
        { id: 'dashboard', icon: '📋', label: 'Tableau de bord', help: 'Tableau de bord|Vue d\'ensemble de votre année scolaire. Vous voyez d\'un coup d\'œil : le nombre d\'élèves et de classes, les prochaines réunions, la semaine en cours dans l\'emploi du temps, et l\'échéancier « À relancer » : les droits MDPH expirés ou proches de l\'échéance, les ESS à programmer et les documents à compléter. Cliquez sur une ligne pour ouvrir la fiche de l\'élève. C\'est la page d\'accueil.' },
        { id: 'agenda',    icon: '📅', label: 'Emploi du temps', help: 'Emploi du temps|Le cœur de Calulis : l\'emploi du temps de la semaine. Double-cliquez dans une case vide pour créer un créneau (activité, élèves, adultes). Glissez-déposez pour déplacer un créneau. Ctrl+glisser pour le copier. Clic droit pour couper/copier/coller. Si la case est déjà prise — par un élève, ou par un adulte déjà occupé ailleurs — Calulis demande avant d\'écrire : Annuler, Ignorer les occupées ou Écraser. La barre du haut permet de changer de semaine (flèches ◀▶), de basculer entre vue Élèves et vue Adultes, et de filtrer par élève, groupe ou intervenant.' },
        { id: 'suivi',     icon: '📝', label: 'Suivi', help: 'Suivi|Les notes de suivi de vos élèves : ce que vous observez, les objectifs que vous fixez, les réussites, les alertes et les actions décidées. Chaque note est datée et rattachée à un élève. Filtrez par élève, par type ou par période, cochez les notes à emporter, puis imprimez-les en PDF : c\'est le document à avoir sous les yeux pour préparer une ESS ou remplir un livret. Les notes des années précédentes restent enregistrées.' },
        { id: 'taches',    icon: '✅', label: 'Tâches', help: 'Tâches|Vos tâches, en tableau de cartes ou en liste : à faire, plus tard, en cours, fait, annulé. Une tâche peut concerner un élève, un adulte, ou personne (commander du matériel, relancer un partenaire). Elle a une échéance, une priorité, une couleur et une précision courte. Changez le statut en glissant une carte, ou avec le menu « Déplacer vers » de chaque carte (au clavier). Cochez les tâches à emporter, puis imprimez-les en PDF : ce qui reste à faire, ce qui a été fait sur une période, ou une sélection.' },
        { id: 'eleves',    icon: '👥', label: 'Élèves', help: 'Élèves|Liste de tous les élèves suivis en ULIS cette année. En haut, des filtres pour affiner : par niveau (CP, CE1…), par classe précise, ou par statut (ULIS / non ULIS, actif / inactif). Les colonnes Âge et Années ULIS sont calculées automatiquement. Cliquez sur un en-tête pour trier. Les boutons : Fiche = consulter sans pouvoir modifier, Modifier = éditer la fiche, Supprimer = retirer de l\'année en cours.' },
        { id: 'listes',    icon: '📋', label: 'Listes', help: 'Listes|Générez vos listes d\'élèves en un clic : filtrez par niveau, classe, groupe, ULIS, cantine, transport, PAI, allergies, droit à l\'image, cochez vos élèves, choisissez les colonnes et exportez en PDF paysage ou CSV. Vous pouvez enregistrer un groupe (ex. « Sortie piscine ») pour le réutiliser toute l\'année.' },
        { id: 'reunions',  icon: '🤝', label: 'Réunions', help: 'Réunions|Toutes les réunions liées au dispositif : ESS (Équipe de Suivi de Scolarisation), équipes éducatives, rendez-vous avec les familles, réunions partenariales. Chaque réunion a un type, une date, un statut (prévue, en cours, réalisée, annulée, reportée) et peut être liée à un élève. Filtrez pour retrouver facilement une réunion passée ou à venir. Le bouton « Exporter (.ics) » met les réunions affichées dans l\'agenda de votre téléphone.' },
        { id: 'evenements', icon: '📆', label: 'Événements', help: 'Événements|Calendrier des événements de l\'année scolaire. 60 modèles prédéfinis (jours fériés, vacances, examens, semaines thématiques) que vous activez d\'un simple clic. Le bouton 🎂 génère automatiquement les anniversaires des élèves. Vous pouvez aussi créer vos propres événements (sortie, spectacle, conseil d\'école…). Filtrez par catégorie pour vous y retrouver. Le bouton « Exporter (.ics) » met les événements affichés dans l\'agenda de votre téléphone — le fichier est fabriqué sur votre ordinateur, rien n\'est envoyé sur Internet.' },
        { id: 'print',     icon: '🖨️', label: 'Impression', help: 'Impression|Exportez les emplois du temps en PDF. Trois onglets : Emplois du temps (semaine complète pour un élève ou un adulte, journée comparative pour plusieurs élèves), Statistiques (cochez les blocs à faire figurer : indicateurs clés, inclusion par élève ou par période, par adulte, PEC, cantine & transport, MDPH, ancienneté, écoles d\'origine, entrées/sorties, évolution — chaque bloc sur sa page) et Fiches (fiches d\'urgence et de renseignements, par élève ou en lot). Sélectionnez l\'élève et la semaine, générez l\'aperçu, puis téléchargez. L\'aperçu fonctionne sans Internet. Idéal pour afficher l\'EDT en classe, le transmettre aux familles, ou le joindre à un dossier.' },
        { id: 'stats',     icon: '📊', label: 'Statistiques', help: 'Statistiques|Temps de présence des élèves par type de regroupement, calculé automatiquement à partir de l\'emploi du temps. Permet de justifier le temps de scolarisation pour les rapports administratifs, de présenter la répartition inclusion/ULIS en ESS, et de piloter votre dispositif. Les données sont exportables en PDF.' },
        { id: 'annuaire',  icon: '📖', label: 'Annuaire', help: 'Annuaire|Annuaire complet et interrogeable. Tapez un nom, un prénom ou un établissement dans la barre de recherche pour trouver instantanément un élève, un adulte ou une structure. Cliquez sur Fiche pour voir tous les détails. Pratique pour retrouver un contact rapidement.' },
        { id: 'adultes',   icon: '👩‍🏫', label: 'Adultes', help: 'Adultes|Tous les adultes qui interviennent auprès des élèves : enseignants, AESH, orthophonistes, psychomotriciens, éducateurs… Filtrez par catégorie : 👩‍🏫 enseignants de l\'école, 👥 autre personnel (AESH, directeur), 🌍 intervenants extérieurs (libéraux, SESSAD, ASE). Un adulte peut être rattaché à plusieurs établissements.' },
        { id: 'classes',   icon: '🏷️', label: 'Classes', help: 'Classes|Les classes de votre école. Chaque classe a un nom (ex: CE1), un niveau, un enseignant et un établissement. Les élèves ULIS sont rattachés à leur classe de référence — c\'est une obligation légale. Cela permet de savoir dans quelle classe chaque élève est inscrit administrativement. Les classes de votre établissement (réglé dans Paramètres → Notre établissement) sont classées en tête et repérées par un liseré bleu.' },
        { id: 'etablissements', icon: '🏫', label: 'Établissements', help: 'Établissements|Tous les établissements partenaires : votre école (repérée par le badge 🏫 NOTRE ÉCOLE), les autres écoles, les collèges, les structures médico-sociales (CMP, CMPP, SESSAD, IME), l\'Aide Sociale à l\'Enfance… Double-cliquez sur une ligne pour voir la fiche détaillée avec les intervenants rattachés.' },
        { id: 'mentions-rgpd', icon: '📄', label: 'Mentions RGPD', help: 'Mentions RGPD|Informations légales sur le traitement des données personnelles dans Calulis. Finalités, base légale, durée de conservation, destinataires, droits des personnes, coordonnées du DPD académique. Conformité RGPD et réglementation Éducation nationale.' },
        { id: 'params',    icon: '⚙️', label: 'Paramètres', help: 'Paramètres|Configurez Calulis selon votre école : choisissez les couleurs des types de regroupement, les horaires (début, fin, durée d\'un créneau), les jours travaillés, les APC, et votre établissement principal. Les pauses (récréation, pause du midi) se placent dans l\'emploi du temps avec le bouton « ⏸️ Pause ». Les modifications s\'appliquent immédiatement dans l\'emploi du temps.' },
        { id: 'aide',      icon: '📖', label: 'Aide', help: 'Aide|Guide complet de Calulis. Vous y trouverez : un pas-à-pas pour démarrer, des explications détaillées sur chaque module, des scénarios concrets (préparer la rentrée, organiser une ESS, vérifier la charge d\'un AESH…), la liste des raccourcis clavier, et des astuces pour gagner du temps au quotidien.' },
        { id: 'don',       icon: '❤️', label: 'Soutenir', help: 'Soutenir|Si Calulis vous est utile, vous pouvez soutenir son développement par un don PayPal. Le logiciel reste gratuit et libre.' },

    ],

    init() {
        const nav = document.getElementById('sidebar-nav');
        nav.innerHTML = this._items.map(item => `
            <button class="sidebar-item" data-view="${item.id}" data-help="${item.help || ''}">
                <span class="icon">${item.icon}</span>
                <span class="label">${item.label}</span>
            </button>
        `).join('');

        nav.querySelectorAll('.sidebar-item').forEach(btn => {
            btn.addEventListener('click', () => {
                Router.go(btn.dataset.view);
            });
        });

        // Synchroniser l'état actif avec le routeur
        State.on('currentView:changed', (data) => this._setActive(data.value));
        this._setActive(Router.current);

        // Footer sidebar
        document.getElementById('sidebar-footer').innerHTML = `
            <div style="margin-bottom:4px" id="sidebar-version">Calulis v1</div>
            <div style="display:flex;gap:10px;justify-content:center;font-size:14px">
                <a href="https://www.facebook.com/profile.php?id=61575316486226" target="_blank" rel="noopener" title="Facebook" style="text-decoration:none">📘</a>
            </div>
        `;

        // Version réelle (silencieux si indisponible)
        API.get('version.php').then(v => {
            const el = document.getElementById('sidebar-version');
            if (el && v && v.appVersion) el.textContent = 'Calulis v' + v.appVersion;
        }).catch(() => {});
    },

    _setActive(name) {
        document.querySelectorAll('.sidebar-item').forEach(btn => {
            btn.classList.toggle('active', btn.dataset.view === name);
        });
    },
};