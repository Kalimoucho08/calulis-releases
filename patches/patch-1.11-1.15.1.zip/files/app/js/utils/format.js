/**
 * Calulis — Utilitaires formatage
 */

/**
 * Types de regroupement par défaut et leur couleur (source unique).
 * RECREATION / PAUSE MIDI servent aux pauses : ce sont des créneaux normaux
 * peints dans l'agenda (plus de système de pauses séparé).
 */
const COULEURS_TYPES_DEFAUT = {
    ULIS: '#bbdefb',
    INCLUSION: '#c8e6c9',
    DECLOISONNEMENT: '#fff9c4',
    PEC: '#ffccbc',
    RECREATION: '#ffe0b2',
    'PAUSE MIDI': '#d7ccc8',
    AUTRE: '#e0e0e0',
};

/** Convertit des minutes en format "XhYY" */
function formatMinutesToHours(minutes) {
    if (!minutes || minutes <= 0) return '0h';
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return m > 0 ? `${h}h${String(m).padStart(2, '0')}` : `${h}h`;
}

/** Calcule un pourcentage par rapport à un total */
function calculatePercentage(value, total) {
    if (!total || total <= 0) return 0;
    return Math.round((value / total) * 100);
}

/** Exporte un tableau de données en CSV avec BOM UTF-8 */
function exportCSV(filename, headers, rows) {
    const BOM = '﻿';
    const csv = [headers.join(','), ...rows.map(r => headers.map(h => {
        const v = (r[h] ?? '').toString();
        return /[,"\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
    }).join(','))].join('\n');
    const blob = new Blob([BOM + csv], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    URL.revokeObjectURL(a.href);
}

/* ══════════════════════════════════════════════════════════════════════════════
   Export iCalendar (.ics) — RFC 5545
   ──────────────────────────────────────────────────────────────────────────────
   Un fichier `.ics` est le seul format que les téléphones et les agendas (Google,
   Outlook, Apple) savent importer : c'est ce qui permet de retrouver les réunions et
   les événements de l'année sur son téléphone. Le fichier est fabriqué DANS le
   navigateur — aucun serveur, aucun compte, aucune donnée qui sort d'ici.
   ══════════════════════════════════════════════════════════════════════════════ */

/** Échappe une valeur de texte iCalendar (RFC 5545 § 3.3.11) : \ ; , et sauts de ligne. */
function icsEchapper(texte) {
    return String(texte ?? '')
        .replace(/\\/g, '\\\\')
        .replace(/;/g, '\\;')
        .replace(/,/g, '\\,')
        .replace(/\r?\n/g, '\\n');
}

/**
 * Replie une ligne à 75 OCTETS, comme l'exige la RFC 5545 § 3.1 (les octets, pas les
 * caractères : « é » en pèse deux). Une continuation commence par une espace, qui
 * compte dans la limite.
 */
function icsPlier(ligne) {
    const encodeur = new TextEncoder();
    if (encodeur.encode(ligne).length <= 75) return ligne;
    const morceaux = [];
    let courant = '';
    let octets = 0;
    let premiere = true;
    for (const caractere of ligne) {
        const taille = encodeur.encode(caractere).length;
        if (octets + taille > (premiere ? 75 : 74)) {
            morceaux.push((premiere ? '' : ' ') + courant);
            premiere = false;
            courant = '';
            octets = 0;
        }
        courant += caractere;
        octets += taille;
    }
    morceaux.push((premiere ? '' : ' ') + courant);
    return morceaux.join('\r\n');
}

/** '2026-09-29' → '20260929' (date iCalendar, journée entière). */
function icsDateJour(date) {
    return String(date || '').replace(/-/g, '');
}

/** '2026-09-29' + '14:30' → '20260929T143000' (heure LOCALE, sans Z : l'événement reste à l'heure de l'école). */
function icsDateHeure(date, heure) {
    const h = String(heure || '').substring(0, 5).replace(':', '');
    return icsDateJour(date) + 'T' + (h.length === 4 ? h : '0000') + '00';
}

/** Ajoute des jours à 'YYYY-MM-DD' (pour la fin EXCLUSIVE d'une journée entière). */
function icsAjouterJours(date, jours) {
    const [a, m, j] = String(date || '').split('-').map(Number);
    if (!a || !m || !j) return null;
    const d = new Date(Date.UTC(a, m - 1, j + jours));
    return d.toISOString().substring(0, 10);
}

/** Horodatage UTC de génération ('20260929T143000Z'), obligatoire dans un VEVENT. */
function icsMaintenant() {
    return new Date().toISOString().replace(/[-:]/g, '').replace(/\.\d+/, '');
}

/**
 * Construit le contenu d'un fichier .ics.
 *
 * @param {string} nomCalendrier nom affiché du calendrier
 * @param {Array<{uid:string, debut:string, fin?:string|null, heure?:string|null,
 *                duree?:number|null, titre:string, description?:string, lieu?:string,
 *                touteLaJournee?:boolean}>} elements
 *   - journée entière : `touteLaJournee` vrai (ou pas d'`heure`) → dates seules ;
 *   - sinon `heure` (+ `duree` en minutes) → heure locale.
 * @returns {string} le contenu complet (séparateurs CRLF, terminé par un CRLF)
 */
function icsContenu(nomCalendrier, elements) {
    const lignes = [
        'BEGIN:VCALENDAR',
        'VERSION:2.0',
        'PRODID:-//Calulis//Calulis//FR',
        'CALSCALE:GREGORIAN',
        'METHOD:PUBLISH',
        'X-WR-CALNAME:' + icsEchapper(nomCalendrier),
    ];
    const horodatage = icsMaintenant();

    for (const e of (elements || [])) {
        if (!e || !e.debut) continue;   // sans date, un événement n'a rien à faire dans un agenda
        lignes.push('BEGIN:VEVENT');
        lignes.push('UID:' + icsEchapper(e.uid || (horodatage + '-' + lignes.length) + '@calulis'));
        lignes.push('DTSTAMP:' + horodatage);
        const avecHeure = !e.touteLaJournee && !!e.heure;
        if (avecHeure) {
            lignes.push('DTSTART:' + icsDateHeure(e.debut, e.heure));
            const minutes = Number(e.duree) > 0 ? Number(e.duree) : 60;
            const [a, m, j] = e.debut.split('-').map(Number);
            const [hh, mm] = String(e.heure).substring(0, 5).split(':').map(Number);
            // Date construite en UTC avec l'heure LOCALE : le décalage de fuseau est
            // ainsi ignoré, et 14:30 reste 14:30 sur le téléphone.
            const fin = new Date(Date.UTC(a, m - 1, j, hh, mm + minutes));
            lignes.push('DTEND:' + fin.toISOString().substring(0, 19).replace(/[-:]/g, ''));
        } else {
            lignes.push('DTSTART;VALUE=DATE:' + icsDateJour(e.debut));
            // La fin d'une journée entière est EXCLUSIVE (RFC 5545) : un événement du
            // 29 septembre seul se termine le 30.
            const finJour = icsAjouterJours(e.fin || e.debut, 1);
            lignes.push('DTEND;VALUE=DATE:' + icsDateJour(finJour));
        }
        lignes.push('SUMMARY:' + icsEchapper(e.titre));
        if (e.lieu) lignes.push('LOCATION:' + icsEchapper(e.lieu));
        if (e.description) lignes.push('DESCRIPTION:' + icsEchapper(e.description));
        lignes.push('END:VEVENT');
    }

    lignes.push('END:VCALENDAR');
    return lignes.map(icsPlier).join('\r\n') + '\r\n';
}

/**
 * Fabrique et télécharge un fichier .ics.
 * @see icsContenu pour la forme des `elements`.
 */
function exportICS(filename, nomCalendrier, elements) {
    const blob = new Blob([icsContenu(nomCalendrier, elements)], { type: 'text/calendar;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    URL.revokeObjectURL(a.href);
}

// ── Limites de longueur des champs (miroir de l'API CALULIS_VARCHAR_LIMITS) ──
// maxlength à la saisie pour éviter les erreurs « data too long » (MySQL strict).
const CALULIS_MAXLEN = {
    // Champs « identité / contact » : largeur généreuse (= colonne), jamais trop courte
    nom: 100, prenom: 100, email: 100, ecole_origine: 100, motif_sortie: 100,
    suivi_par: 100, aesh_nom: 100, transport: 100, langue_maison: 100,
    orientation_demandee: 100, orientation_obtenue: 100, commentaire: 100,
    // Champs courts (colonnes varchar courtes du schéma)
    ine: 15, classe: 20, niveau_scolaire: 20, aesh_type: 10, aesh_heures: 20,
    groupe: 50, temps_scolarisation: 30, telephone: 20, telephone_urgence: 20,
    telephone2: 20, uai: 8, code_postal: 10, departement: 50,
    numero_dossier_mdph: 50, numero_dossier: 50, ase_structure_telephone: 20,
    ase_referent_telephone: 20, fonction: 50, role: 50, civilite: 10, lien: 50,
    specialite: 100, pec_specialite: 50, pec_organisme: 50, pec_frequence: 30,
    pec_lieu: 50, pec_duree: 20,
};
/** Retourne l'attribut maxlength si le champ est dans la table, sinon '' */
function maxLenAttr(name) {
    const n = CALULIS_MAXLEN[name];
    return n ? 'maxlength="' + n + '"' : '';
}

/** Accessibilité : relie chaque <label> sans for au champ suivant du même groupe de formulaire */
function linkLabels(container) {
    if (!container) return;
    container.querySelectorAll('.form-group').forEach(group => {
        const label = group.querySelector(':scope > label');
        if (!label || label.getAttribute('for')) return;
        const input = Array.from(group.children).find(el => /^(INPUT|SELECT|TEXTAREA)$/.test(el.tagName));
        if (!input) return;
        if (!input.id) input.id = 'f-' + label.textContent.trim().replace(/\s+/g, '-').toLowerCase();
        label.setAttribute('for', input.id);
    });
}

/**
 * Libellé lisible d'un rôle d'adulte — SOURCE UNIQUE.
 * Les rôles sont stockés en identifiants techniques (`aeshco`, `aeshi`…) et ne doivent
 * jamais s'afficher tels quels : la page Adultes et les statistiques passent par ici.
 */
function libelleRole(role) {
    const labels = {
        enseignant: 'Enseignant',
        aeshco: 'AESHco',
        aeshi: 'AESHi',
        aeshm: 'AESHm',
        specialiste: 'Spécialiste',
        educateur: 'Éducateur',
        assistant_familial: 'Ass. familial',
        coordo_ulis: 'Coordo ULIS',
    };
    if (!role) return '';
    return labels[role] || role.replace(/_/g, ' ');
}

/** Libellés d'une liste de rôles ("aeshco, aeshi") — pour les statistiques par adulte. */
function libellesRoles(roles) {
    if (!roles) return '—';
    const liste = String(roles).split(',').map(r => libelleRole(r.trim())).filter(Boolean);
    return liste.length ? liste.join(', ') : '—';
}
