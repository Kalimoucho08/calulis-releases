/**
 * Calulis — Changelog (Nouveautés)
 * Résumé des nouveautés depuis la v1.0. À mettre à jour à CHAQUE release
 * (voir scripts/release-checklist.sh — étape « quoi de neuf »).
 * NOTE : utiliser l'apostrophe typographique ' (U+2019) dans les textes —
 * jamais l'apostrophe droite ' qui casse les chaînes JS.
 */
const Changelog = {
    /** Dernière version connue (mise à jour à chaque release) */
    latest: '1.15.1',
    /** Entrées de la plus récente à la plus ancienne */
    entries: [
        {
            version: '1.15.1', date: '5 octobre 2026',
            items: [
                'Fiabilité : une mise à jour ne peut plus effacer vos données par erreur. Avant de remplacer la base par une base de démonstration ou une base vierge, Calulis commence par sauvegarder vos données et vous dit où elles sont rangées ; le choix « Continuer avec mes données » est proposé en premier, et les deux autres annoncent clairement qu’ils effacent',
                'Fiabilité : la mise à jour du lanceur se fait maintenant sans question quand Calulis contient déjà vos données — vous n’avez plus rien à accepter pour recevoir une correction',
                'Une seule base, et c’est la vôtre. Calulis ne vous propose plus de choisir entre plusieurs bases de données : il ouvre celle que vous utilisez, et toutes les opérations portent sur elle — importer, sauvegarder, restaurer. Le bouton « Restaurer une sauvegarde » reste dans la fenêtre de démarrage, sous cette même base',
                'Vos données sont sauvegardées avant tout remplacement. Importer un fichier .sql ou recharger une sauvegarde commence par une sauvegarde automatique de la base en cours, dont le dossier est affiché ; si cette sauvegarde échoue, rien n’est remplacé. La question nomme ce qui va être remplacé et la réponse par défaut est « Non »',
                'Si vous aviez plusieurs bases (anciens imports), Calulis vous propose de les exporter en fichier .sql au premier démarrage après la mise à jour. Il n’en supprime ni n’en renomme aucune',
                'Sécurité : la base de données MySQL embarquée n’a plus de compte sans mot de passe. Chaque installation reçoit des mots de passe tirés au hasard, conservés uniquement dans votre dossier Calulis (runtime/mysql-credentials.json) ; les installations existantes sont sécurisées au premier démarrage',
                'Sécurité : les fichiers de données et les outils internes de développement ne sont plus accessibles depuis le navigateur, et Calulis ne répond plus qu’à cette seule machine',
            ],
        },
        {
            version: '1.15', date: '4 octobre 2026',
            items: [
                'Nouveau : le suivi des élèves. Écrivez ce que vous observez, ce que vous visez, ce qui a marché, ce qui vous inquiète : chaque note est datée et rattachée à un élève, avec un type (observation, objectif, réussite, alerte, action). Filtrez par élève, par type ou par période, cochez les notes à emporter et imprimez-les en PDF — pour préparer une ESS, un PAI ou un livret',
                'Nouveau : les tâches. Un tableau de post-its en cinq colonnes (à faire, plus tard, en cours, fait, annulé) et une liste triable : échéance, priorité, six couleurs, et un lien vers un élève ou un adulte quand c’est utile. Le statut se change en glissant une carte, ou par le menu « Déplacer vers » de chaque carte — qui marche aussi au clavier. Une tâche terminée ou annulée n’est plus signalée « en retard » : une fois qu’elle est faite, elle ne l’est plus',
                'Nouveau : l’impression des tâches — ce qui reste à faire, ce qui a été fait sur une période (pour un bilan de fin d’année), ou une sélection cochée, présentées par statut, par échéance ou par personne concernée',
                'Nouveau : le tableau de bord affiche les tâches du jour, celles en retard comprises. Une case à cocher, dans le même bloc, ajoute celles de demain — le réglage est conservé',
                'Le suivi et les tâches sont rangés par année scolaire : les notes de l’année dernière restent enregistrées',
                'L’« Agenda » s’appelle maintenant « Emploi du temps » — c’est bien de l’emploi du temps de la classe dont il s’agit (l’agenda de votre téléphone, lui, garde son nom). La barre latérale est rangée par fréquence d’usage, avec le suivi et les tâches juste sous le tableau de bord',
                'Correction : les durées de conservation annoncées dans les mentions RGPD étaient fausses. Un élève suivi en ULIS y reste de cinq à sept ans, et toutes ses données sont conservées pendant ce temps ; après sa sortie, deux ans. Les comptes rendus de réunions suivent désormais l’élève (tant qu’il est suivi, puis deux ans) au lieu d’être purgés au bout de cinq ans',
            ],
        },
        {
            version: '1.14', date: '1er octobre 2026',
            items: [
                'Nouveau : la recherche du haut de page propose les résultats PENDANT la frappe (élèves, adultes, établissements et classes), sans se soucier des accents ni des majuscules. On se déplace avec les flèches ↓ ↑, on ouvre avec Entrée, on ferme avec Échap — et les élèves ou adultes archivés sont trouvés et signalés comme tels, au lieu d’être introuvables',
                'Nouveau : les statistiques par adulte — heures de service par semaine, nombre d’élèves suivis et répartition par type d’accompagnement. Une heure faite en groupe ne compte plus plusieurs fois : c’est le temps de service réel de chacun',
                'Nouveau : à l’impression des statistiques, vous choisissez les blocs à emporter (12 blocs à cocher). Chaque bloc part sur sa propre page, l’orientation bascule en paysage quand un tableau large est demandé, et le nom du fichier dit ce qu’il contient',
                'Accessibilité : le contraste des textes a été mesuré écran par écran, dans les deux thèmes, et corrigé. Le panneau d’aide s’affichait avec un fond blanc et un texte clair en thème sombre (illisible) ; les liens, les pastilles de couleur, le pied de la barre latérale et plusieurs boutons étaient sous le seuil de lisibilité recommandé',
                'Correction : la pastille de statut des réunions (Prévue, Réalisée, Annulée, Reportée) s’affiche de nouveau en couleur sur le tableau de bord et sur la fiche d’un adulte — le style attendu n’existait pas, la pastille restait grise',
                'Correction : les petits boutons d’action (Modifier, Supprimer, Fiche) reprennent l’apparence de Calulis au lieu de celle de Windows, et redeviennent lisibles en thème sombre',
                'Nettoyage : le serveur Discord du projet est retiré de l’application (barre latérale, page « Soutenir », mentions légales, aide). Le canal était abandonné depuis longtemps ; la page Facebook reste le point de contact',
            ],
        },
        {
            version: '1.13', date: '29 septembre 2026',
            items: [
                'Nouveau : export .ics — vos réunions et vos événements s’ajoutent en un clic à l’agenda de votre téléphone (Google Agenda, Outlook, Apple). Le fichier est fabriqué sur votre ordinateur, rien n’est envoyé sur Internet',
                'Nouveau : le tableau de bord « À relancer » réunit en un seul endroit les droits MDPH expirés ou proches de l’échéance, les ESS à programmer (aucune ESS enregistrée, ou la dernière qui date de plus d’un an) et les documents à compléter (PAI sans document joint, notification MDPH non renseignée)',
                'Planning : un adulte déjà occupé ailleurs au même moment est désormais signalé, exactement comme pour un élève — avec le choix Annuler / Ignorer les cases occupées / Écraser',
                'Planning : créer ou modifier un créneau (et ajouter une pause) prévient maintenant si la case est déjà occupée, au lieu d’écraser en silence',
                'Correction : l’aperçu des impressions PDF fonctionne sans connexion Internet — le moteur était pris sur Internet alors qu’il est fourni avec Calulis',
                'Nettoyage : les boutons Annuler / Rétablir, grisés depuis toujours, et l’onglet « Documents », qui n’ouvrait rien, ont été retirés — ils reviendront le jour où la fonction existera vraiment',
                'Nouveau : une page « Soutenir ». Calulis reste gratuit et complet, avec ou sans don, et aucune donnée n’est demandée pour soutenir le projet',
                'Mentions légales : les composants logiciels de Calulis (serveur web, base de données, moteur PDF, polices…) sont listés dans un fichier de notices livré avec l’application, avec leur licence et le lien vers leurs sources. L’aide contient une page « Sources des composants »',
                'Correction : dans la vue Adultes, une case dont le créneau a été enregistré sans civilité (« MARTIN » au lieu de « Mme MARTIN ») répond de nouveau au double-clic — elle restait silencieuse',
                'Correction : dans Classes, votre établissement est de nouveau mis en avant (fond bleu et classement en tête). Il était lu dans un réglage que Calulis n’écrit plus : le repère ne s’affichait jamais, et une nouvelle classe ne proposait pas votre école par défaut',
                'Correction : quand un chargement échoue (les semaines scolaires dans les Paramètres, la liste des classes dans une fiche élève), Calulis le dit maintenant au lieu de laisser une liste vide, qui ressemble à des données perdues',
                'Nettoyage : le badge « α » de la barre latérale a disparu, et deux boutons « ✕ » (effacer une recherche) sont désormais annoncés correctement aux lecteurs d’écran',
                'Nouveau : la page « Et après ? » dans l’aide présente les trois projets satellites (SCANULIS pour lire les documents, BILANULIS pour écrire et suivre les bilans, PLANULIS pour construire les emplois du temps) — tous facultatifs, sans aucune date annoncée, avec une intelligence artificielle qui tournerait sur VOTRE ordinateur',
                'Nouveau : un carnet de souhaits dans cette même page — écrivez ce qui vous manque, il reste sur votre ordinateur, et il ne part que si vous cliquez sur « Copier » ou « Envoyer par mail »',
                'Aide remise à jour : le contrôle de conflit, l’export .ics, l’échéancier « À relancer » et l’onglet Fiches de l’Impression sont expliqués là où ils se trouvent — et un contrôle automatique empêchera l’aide de reprendre du retard en silence',
            ],
        },
        {
            version: '1.12.1', date: '28 septembre 2026',
            items: [
                'Correction importante : sur certains ordinateurs, Calulis pouvait refuser de démarrer après une mise à jour — c’est corrigé : l’installation prépare ses données jusqu’au bout, même sur une machine lente',
                'Nouveau : après une mise à jour, Calulis vérifie que l’application répond vraiment. Si ce n’est pas le cas, il revient automatiquement à la version précédente et vous prévient — vos données ne sont jamais touchées',
                'Sécurité : Calulis n’arrête plus les bases de données d’autres logiciels installés sur l’ordinateur (il ne s’arrête plus que lui-même)',
                'Nouveau : mode récupération « Calulis.exe --safe-mode » — sauvegarder vos données, exporter un rapport de diagnostic, réparer le lancement, sans démarrer l’application',
                'Nouveau : « Calulis.exe --diagnostic » fabrique une archive à envoyer au support (journaux, versions, état des services) : elle ne contient aucune donnée d’élève',
                'Mise à jour : la base de données est sauvegardée automatiquement avant chaque mise à jour',
            ],
        },
        {
            version: '1.12', date: '22 septembre 2026',
            items: [
                'Correction importante : Calulis démarre désormais sur un Windows « de base », même si le composant Microsoft Visual C++ n’a jamais été installé sur l’ordinateur — il est maintenant fourni avec Calulis (rien à télécharger, rien à installer)',
                'Nouveau : si un antivirus supprime des fichiers de Calulis, un message clair indique lesquels et comment y remédier, au lieu d’une erreur Windows incompréhensible',
                'Correction : sur un ordinateur lent, ou lors du tout premier démarrage, Calulis prend maintenant le temps nécessaire pour démarrer au lieu d’échouer au bout de quelques secondes',
                'Sécurité : Calulis n’est plus accessible depuis le réseau — l’application ne fonctionne que sur l’ordinateur, vos données d’élèves restent locales',
                'Correction : la mise à jour s’installe correctement quel que soit le logiciel utilisé pour ouvrir le fichier ZIP (certains outils créaient des dossiers incorrects)',
                'Statistiques : l’ancienneté dans le dispositif ULIS s’affiche maintenant en années et en mois (« 2 ans et 3 mois »), avec la répartition « Moins d’un an / 1 an / 2 ans / 3 ans / 4 ans et + »',
                'Listes : aperçu du PDF avant téléchargement (fidèle à l’impression), tableaux qui ne débordent plus de la page, en-tête et pied de liste modifiables, et tri en cliquant sur les colonnes',
            ],
        },
        {
            version: '1.11', date: '7 septembre 2026',
            items: [
                'Correction : l’impression « Jour · Élèves » ne coupe plus les élèves — les journées s’affichent entièrement, même à 13 élèves ou plus (tableau ajusté, légende des couleurs, police adaptée)',
                'Nouveau : pour les grandes classes, l’impression « Jour · Élèves » répartit automatiquement les élèves sur plusieurs pages (jusqu’à 16 par page)',
                'Correction : le tri par numéro d’élève est maintenant numérique (1, 2, 3, …, 10, 11), et les numéros s’affichent « 01, 02, … »',
                'Amélioration : les années passées en ULIS sont comptées précisément en mois (« 1 an et 5 mois », « 0 mois » pour le premier mois), en tenant compte des arrivées en cours d’année',
            ],
        },
        {
            version: '1.10.1', date: '3 septembre 2026',
            items: [
                'Correction : la création d’un nouvel élève fonctionne à nouveau (plus de message d’erreur à l’enregistrement)',
            ],
        },
        {
            version: '1.10', date: '3 septembre 2026',
            items: [
                'Correction : l’onglet « Classes » s’affiche à nouveau et vous pouvez modifier vos classes, sans message d’erreur',
                'Correction : l’impression « Jour · Élèves » retrouve la liste des élèves — vous pouvez à nouveau générer l’aperçu et imprimer vos journées',
            ],
        },
        {
            version: '1.0.9', date: '1 septembre 2026',
            items: [
                'Faites vos listes d’élèves en un clic : filtrez (niveau, classe, groupe, ULIS, cantine, transport, PAI, allergies, droit à l’image), cochez, choisissez les colonnes, et exportez en PDF paysage ou CSV',
                'Enregistrez des groupes d’élèves (ex. « Sortie piscine ») pour les réutiliser toute l’année',
                'Fiche de renseignements et fiche d’urgence imprimable pour un élève ou pour toute une liste (mention confidentielle)',
                'Suivi du droit à l’image par élève : autorisé, refusé, en attente, avec dates et document signé',
                'Les pauses sont plus simples : un bouton « Pause » dans l’agenda, et deux couleurs pour la récréation et le midi',
                'Calendrier scolaire corrigé : la dernière semaine de classe ne disparaît plus dans les vacances',
                'Correction : la fiche d’un élève s’ouvre à nouveau correctement',
            ],
        },
        {
            version: '1.0.8', date: '31 août 2026',
            items: [
                'Plusieurs enseignants par classe, avec leurs jours et leurs demi-journées (postes partagés)',
                'Copier un créneau sur plusieurs jours en une seule fois (ex. : un rituel tous les matins)',
                'Avertissement quand on colle un créneau sur une case déjà occupée',
                'Numéro pour chaque élève, affiché et utilisé pour classer le calendrier',
                'Correction de la propagation du modèle vers des semaines choisies',
                'Correction du déplacement de bloc de créneaux (tout le bloc se déplace)',
                'Adresse de signalement de bug réglable dans les Paramètres',
            ],
        },
        {
            version: '1.0.7', date: '27 août 2026',
            items: [
                'Mise à jour plus fiable : le lanceur peut se mettre à jour depuis un second serveur (pCloud) si le premier est indisponible',
                'Le lanceur se réduit dans la barre d’état système (en bas à droite) — Calulis continue de tourner',
                'Messages plus simples et plus rassurants, moins de jargon technique',
                'Un bouton « Vérifier la mise à jour » permet de rechercher une version sans redémarrer',
                'Les champs de saisie limitent automatiquement leur longueur (plus d’erreur « données non enregistrées »)',
                'Accessibilité améliorée : les champs sont correctement étiquetés pour les lecteurs d’écran',
            ],
        },
        {
            version: '1.0.6', date: '26 août 2026',
            items: [
                'Protection renforcée : vos données ne peuvent plus être modifiées par une page web externe (sécurité CSRF)',
                'Sauvegarde plus fiable : plus d’erreurs d’enregistrement mystérieuses quand un champ est trop long (ils sont tronqués proprement)',
                'Les erreurs techniques sont maintenant journalisées pour un dépannage plus rapide',
                'Correction de l’affichage de la version (1.0.5 s’affichait à tort)',
            ],
        },
        {
            version: '1.0.5', date: '26 août 2026',
            items: [
                'Rattachement d’un élève à une classe corrigé (l’enregistrement échouait avec une erreur de base de données)',
            ],
        },
        {
            version: '1.0.4', date: '19 août 2026',
            items: [
                'Messages d’erreur enfin compréhensibles : plus de « Internal Server Error », Calulis explique quoi faire',
                'Bouton « Signaler un bug » sur les écrans d’erreur (infos techniques envoyées à l’équipe)',
                'Lanceur : bouton « Copier le rapport », aide intégrée, erreurs de démarrage claires',
                'Le lanceur se met à jour automatiquement, comme l’application',
                'Version de l’application affichée + cette page « Quoi de neuf »',
            ],
        },
        {
            version: '1.0.3', date: '17 août 2026',
            items: [
                'Calendrier scolaire (vacances) réparé sur toutes les machines Windows',
                'Messages d’erreur qui guident (connexion, certificat, DNS…)',
                'Les pages se rafraîchissent correctement après chaque mise à jour',
            ],
        },
        {
            version: '1.0.2', date: '17 août 2026',
            items: [
                'Établissements : ensembles scolaires, statut public/privé',
                'Tous les niveaux : maternelle, élémentaire, collège (6e→3e), lycée, lycée professionnel',
                'Création d’élève guidée (bouton « + Créer » pour l’établissement manquant)',
            ],
        },
        {
            version: '1.0.1', date: '16 août 2026',
            items: [
                'Correction du bug « ID requis » (modification/suppression élève, adulte, classe)',
            ],
        },
        {
            version: '1.0.0', date: '10 août 2026',
            items: [
                'Première version portable, sans installation : élèves, emploi du temps, réunions, annuaire, impression PDF',
                'Mises à jour automatiques, sauvegarde/restauration des données',
            ],
        },
    ],
};