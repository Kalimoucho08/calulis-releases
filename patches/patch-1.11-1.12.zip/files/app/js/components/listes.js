/**
 * Calulis — Lot 1 : Générateur de listes d'élèves multicritères
 * Filtres cumulés + colonnes personnalisables (réordonnables, colonnes libres/vides)
 * + export PDF (paysage/portrait, hauteur de ligne, plein format) + CSV + groupes enregistrés.
 * V2 (07/09/2026) : aperçu PDF fidèle (WYSIWYG) + anti-débordement, en-tête/fin modifiables, tri.
 */
const Listes = {
  _classes: [], _groupes: [], _groupesSaved: [], _eleves: [], _selected: new Set(),
  _cols: [], _customIdx: 0, _filters: {},
  _orient: 'paysage', _rowH: 'grande', _fontSize: 8,
  _sortKey: '', _sortDir: 1,
  _entete: 'Liste des élèves', _fin: 'Renseigné par : ____________________    Date : ______',
  _pendingDef: null, _pendingFilename: null, _previewPdf: null, _previewPage: 1, _previewZoom: 1,

  // Définition des colonnes intégrées (clé -> { label, w, get }).
  // w = largeur relative (points) servant de base quand on "remplit" la page.
  COLUMNS: {
    numero:        { label: 'N°',                  w: 30, get: function(e){ return e.numero || ''; } },
    nom:           { label: 'Nom',                 w: 78, get: function(e){ return e.nom || ''; } },
    prenom:        { label: 'Prénom',              w: 78, get: function(e){ return e.prenom || ''; } },
    classe:        { label: 'Classe',              w: 52, get: function(e){ return e.classe_nom || e.classe || ''; } },
    date_naissance:{ label: 'Naissance',           w: 62, get: function(e){ return formatDate(e.date_naissance); } },
    age:           { label: 'Âge',                 w: 32, get: function(e){ return Listes._age(e.date_naissance); } },
    groupe:        { label: 'Groupe',              w: 58, get: function(e){ return (e.groupes && e.groupes.length) ? e.groupes.join(', ') : (e.groupe || ''); } },
    niveau:        { label: 'Niveau',              w: 46, get: function(e){ return NIVEAU_LABELS[e.niveau_scolaire] || e.niveau_scolaire || ''; } },
    transport:     { label: 'Transport',           w: 70, get: function(e){ return e.transport || ''; } },
    cantine:       { label: 'Cantine',             w: 44, get: function(e){ return e.cantine ? 'Oui' : 'Non'; } },
    pai:           { label: 'PAI',                 w: 32, get: function(e){ return e.pai ? 'Oui' : 'Non'; } },
    allergies:     { label: 'Allergies',           w: 90, get: function(e){ return e.allergies || ''; } },
    regime:        { label: 'Régime',              w: 70, get: function(e){ return e.regime_alimentaire || e.regime_scolaire || ''; } },
    droit_image:   { label: 'Droit image',         w: 58, get: function(e){ return Listes._droitLabel(e.droit_image); } },
    tel:           { label: 'Tél. représentants',  w: 92, get: function(e){ return Listes._repsTel(e); } },
    prevenir:      { label: 'Personne à prévenir', w: 96, get: function(e){ return Listes._repsNom(e); } },
  },

  async render() {
    const view = document.getElementById('view-listes');
    view.innerHTML = '<div class="placeholder-view"><div class="placeholder-icon">⏳</div><div class="placeholder-title">Chargement…</div></div>';
    try { await this._loadOptions(); await this._reload(); }
    catch (e) { console.error('[Listes] load error:', e); }
    if (!this._cols.length) this._cols = this._defaultCols();
    view.innerHTML = this._buildHTML();
    this._bindEvents();
    this._renderResults();
    this._renderSortOpts();
  },

  async _loadOptions() {
    const [opts, saved] = await Promise.all([ API.get('listes.php?action=options'), API.get('groupes.php') ]);
    this._classes = (opts && opts.classes) || [];
    this._groupes = (opts && opts.groupes) || [];
    this._groupesSaved = saved || [];
  },

  async _reload() {
    const qs = this._buildQuery();
    this._eleves = await API.get('listes.php' + (qs ? '?' + qs : ''));
    this._selected = new Set(this._eleves.map(function(e){ return e.id; }));
    this._applySort();
  },

  _buildQuery() {
    const f = this._filters, p = [];
    const add = function(k, v){ if (v !== undefined && v !== null && v !== '') p.push(k + '=' + encodeURIComponent(v)); };
    add('q', f.q); add('classe', f.niveau); add('classe_id', f.classe_id); add('groupe', f.groupe);
    if (f.ulis === 0 || f.ulis === 1) add('ulis', f.ulis);
    if (f.droit_image) add('droit_image', f.droit_image);
    if (f.transport === 'has') add('transport', 'has');
    if (f.cantine === 0 || f.cantine === 1) add('cantine', f.cantine);
    if (f.pai === 0 || f.pai === 1) add('pai', f.pai);
    if (f.allergies === 0 || f.allergies === 1) add('allergies', f.allergies);
    if (f.inclure_inactifs) add('inclure_inactifs', 1);
    return p.join('&');
  },

  _defaultCols() {
    return ['numero','nom','prenom','classe','date_naissance','groupe','pai','allergies','tel','droit_image']
      .map(function(k){ const c = Listes.COLUMNS[k]; return { id: k, label: c.label, w: c.w, get: c.get, blank: false }; });
  },

  _colById(id) { return this._cols.find(function(c){ return c.id === id; }); },
  _colIndex(id) { for (let i=0;i<this._cols.length;i++) if (this._cols[i].id===id) return i; return -1; },

  _buildHTML() {
    const classesOpts = this._classes.map(function(c){ return '<option value="' + c.id + '">' + escapeHtml(c.nom) + '</option>'; }).join('');
    const niveauOpts = this._distinctNiveaux().map(function(n){ return '<option value="' + escapeHtml(n.raw) + '">' + escapeHtml(n.label) + '</option>'; }).join('');
    const groupeOpts = this._groupes.map(function(g){ return '<option value="' + escapeHtml(g) + '">' + escapeHtml(g) + '</option>'; }).join('');
    const groupesSavedOpts = this._groupesSaved.map(function(g){ return '<option value="' + g.id + '">' + escapeHtml(g.nom) + '</option>'; }).join('');
    return '' +
    '<div class="print-header"><div class="print-tabs"><span class="print-tab active">📋 Listes</span></div><span class="text-muted" style="font-size:12px;white-space:nowrap">' + this._eleves.length + ' élève(s) · ' + this._cols.length + ' colonne(s)</span></div>' +
    '<div class="print-layout"><div class="print-options-panel">' +
      '<div class="card"><h3 style="margin:0 0 6px 0">1. Filtres</h3>' +
        '<div class="form-row">' +
          '<div class="form-group"><label>Recherche</label><input type="text" id="l-q" class="filter-input" placeholder="Nom, prénom…" style="width:100%"></div>' +
          '<div class="form-group"><label>Niveau</label><select id="l-niveau" style="width:100%"><option value="">Tous</option>' + niveauOpts + '</select></div>' +
          '<div class="form-group"><label>Classe</label><select id="l-classe" style="width:100%"><option value="">Toutes</option>' + classesOpts + '</select></div>' +
          '<div class="form-group"><label>Groupe</label><select id="l-groupe" style="width:100%"><option value="">Tous</option>' + groupeOpts + '</select></div>' +
        '</div>' +
        '<div class="form-row">' +
          '<div class="form-group"><label>ULIS</label><select id="l-ulis" style="width:100%"><option value="">Tous</option><option value="1">Oui</option><option value="0">Non</option></select></div>' +
          '<div class="form-group"><label>Droit à l&#39;image</label><select id="l-droit" style="width:100%"><option value="">Tous</option><option value="autorise">Autorisé</option><option value="refuse">Refusé</option><option value="en_attente">En attente</option></select></div>' +
          '<div class="form-group"><label>Transport</label><select id="l-transport" style="width:100%"><option value="">Tous</option><option value="has">Avec transport</option></select></div>' +
          '<div class="form-group"><label>Cantine</label><select id="l-cantine" style="width:100%"><option value="">Tous</option><option value="1">Oui</option><option value="0">Non</option></select></div>' +
        '</div>' +
        '<div class="form-row">' +
          '<div class="form-group"><label>PAI</label><select id="l-pai" style="width:100%"><option value="">Tous</option><option value="1">Oui</option><option value="0">Non</option></select></div>' +
          '<div class="form-group"><label>Allergies</label><select id="l-allergies" style="width:100%"><option value="">Tous</option><option value="1">Avec</option><option value="0">Sans</option></select></div>' +
          '<div class="form-group" style="display:flex;align-items:flex-end"><label style="margin-bottom:6px"><input type="checkbox" id="l-inactifs"> Inclure inactifs</label></div>' +
        '</div>' +
        '<div style="display:flex;gap:6px;margin-top:6px;flex-wrap:wrap"><button class="btn btn-sm btn-secondary" id="l-apply">🔍 Appliquer</button><button class="btn btn-sm btn-secondary" id="l-reset">↺ Réinitialiser</button></div>' +
      '</div>' +
      '<div class="card"><h3 style="margin:0 0 6px 0">2. Colonnes <span style="font-weight:400;font-size:11px">(cochez, ordonnez, ajoutez)</span></h3><div id="l-cols" class="col-list"></div></div>' +
      '<div class="card"><h3 style="margin:0 0 6px 0">3. Mise en page</h3>' +
        '<div class="form-row">' +
          '<div class="form-group"><label>Orientation</label><select id="l-orient" style="width:100%"><option value="paysage">Paysage</option><option value="portrait">Portrait</option></select></div>' +
          '<div class="form-group"><label>Espace pour écrire</label><select id="l-rowh" style="width:100%"><option value="compact">Compact</option><option value="normale" selected>Normale</option><option value="grande">Grande</option><option value="tresgrande">Très grande (feuille)</option></select></div>' +
          '<div class="form-group"><label>Taille du texte</label><select id="l-font" style="width:100%"><option value="7">Petit</option><option value="8" selected>Normal</option><option value="9.5">Grand</option><option value="11">Très grand</option></select></div>' +
        '</div>' +
        '<div class="form-row">' +
          '<div class="form-group"><label>En-tête (titre)</label><input type="text" id="l-entete" class="filter-input" value="' + escapeHtml(this._entete) + '" style="width:100%"></div>' +
          '<div class="form-group"><label>Fin de liste (pied)</label><input type="text" id="l-fin" class="filter-input" value="' + escapeHtml(this._fin) + '" style="width:100%"></div>' +
        '</div>' +
        '<div class="form-row">' +
          '<div class="form-group"><label>Trier par</label><select id="l-sort" style="width:100%"></select></div>' +
          '<div class="form-group"><label>Sens du tri</label><select id="l-sortdir" style="width:100%"><option value="1">↑ Croissant (A→Z)</option><option value="-1">↓ Décroissant (Z→A)</option></select></div>' +
        '</div>' +
        '<p class="text-muted small" style="margin:6px 0 0 0">Sélectionnez « Grande » ou « Très grande » et le format paysage pour des listes à compléter à la main : les lignes sont hautes et les colonnes occupent toute la feuille. Cliquez sur un en-tête du tableau pour le tri.</p>' +
      '</div>' +
      '<div class="card"><h3 style="margin:0 0 6px 0">4. Groupes enregistrés <span style="font-weight:400;font-size:11px">(template : filtres + colonnes + mise en page + tri)</span></h3>' +
        '<div style="display:flex;gap:6px;margin-bottom:6px"><select id="l-groupes" style="flex:1">' + groupesSavedOpts + '</select><button class="btn btn-sm btn-secondary" id="l-group-load">Charger</button><button class="btn btn-sm btn-secondary" id="l-group-update">Mettre à jour</button><button class="btn btn-sm btn-secondary" id="l-group-del">Suppr.</button></div>' +
        '<button class="btn btn-sm btn-primary" id="l-group-save">💾 Enregistrer comme nouveau groupe…</button>' +
      '</div>' +
      '<div class="card"><h3 style="margin:0 0 6px 0">5. Export</h3><button class="btn btn-primary" id="l-preview" style="width:100%;margin-bottom:6px">👁️ Aperçu du PDF</button><button class="btn btn-secondary" id="l-download" style="width:100%;margin-bottom:6px">⬇️ Télécharger le PDF</button><button class="btn btn-secondary" id="l-csv" style="width:100%">📥 Exporter CSV</button></div>' +
    '</div>' +
    '<div class="print-preview-panel"><div class="card" style="display:flex;flex-direction:column;height:100%">' +
      '<h3 style="margin:0 0 6px 0">Sélection <span class="text-muted small" style="font-weight:400">— glissez les en-têtes pour réordonner, cliquez pour trier</span></h3>' +
      '<div style="display:flex;gap:6px;margin-bottom:8px;align-items:center"><button class="btn btn-sm btn-secondary" id="l-all">Tout</button><button class="btn btn-sm btn-secondary" id="l-none">Aucun</button><span class="text-muted small" id="l-count" style="margin-left:auto"></span></div>' +
      '<div style="flex:1;overflow:auto;border:1px solid var(--border);border-radius:6px;min-height:200px" id="l-results"></div>' +
      '<div class="card" style="margin-top:12px">' +
        '<h3 style="margin:0 0 6px 0">Aperçu du PDF <span class="text-muted small" style="font-weight:400">— rendu exact du document</span></h3>' +
        '<div id="l-preview-placeholder" class="text-muted small" style="padding:12px;text-align:center">Cliquez sur « 👁️ Aperçu du PDF » pour voir le rendu final avant téléchargement.</div>' +
        '<div id="l-preview-area" style="display:none">' +
          '<div style="display:flex;gap:6px;align-items:center;justify-content:center;margin-bottom:6px;flex-wrap:wrap">' +
            '<button class="btn btn-sm btn-secondary" id="l-page-prev" title="Page précédente">◀</button>' +
            '<span id="l-page-info" class="text-muted small">1 / 1</span>' +
            '<button class="btn btn-sm btn-secondary" id="l-page-next" title="Page suivante">▶</button>' +
            '<span style="width:6px"></span>' +
            '<button class="btn btn-sm btn-secondary" id="l-zoom-out" title="Zoom arrière">−</button>' +
            '<span id="l-zoom-label" class="text-muted small">100%</span>' +
            '<button class="btn btn-sm btn-secondary" id="l-zoom-in" title="Zoom avant">＋</button>' +
          '</div>' +
          '<div style="overflow:auto;max-height:420px;text-align:center;background:#333;border-radius:6px;padding:8px">' +
            '<canvas id="l-preview-canvas" style="display:block;margin:0 auto;box-shadow:0 2px 12px rgba(0,0,0,.3)"></canvas>' +
          '</div>' +
        '</div>' +
      '</div>' +
    '</div></div>' +
    '</div>';
  },

  _renderColumns() {
    const box = document.getElementById('l-cols'); if (!box) return;
    const self = this;
    let html = '<div class="col-row col-head"><span>Colonnes affichées — glissez les en-têtes dans l&#39;aperçu pour réordonner</span><span></span></div>';
    this._cols.forEach(function(c, i){
      html += '<div class="col-row">' +
        '<label style="flex:1;display:flex;align-items:center;gap:6px"><input type="checkbox" data-col="' + c.id + '" checked> ' + escapeHtml(c.label) + '</label>' +
        (c.blank ? '<button class="btn-xs btn-outline col-del" data-id="' + c.id + '" title="Supprimer">✕</button>' : '<span style="width:20px"></span>') +
      '</div>';
    }, this);
    // Colonnes disponibles (non cochées)
    const avail = Object.keys(this.COLUMNS).filter(function(k){ return !self._colById(k); });
    if (avail.length) html += '<div class="col-avail"><div class="col-avail-title">Ajouter :</div>' + avail.map(function(k){ return '<label class="col-toggle"><input type="checkbox" data-col="' + k + '"> ' + escapeHtml(self.COLUMNS[k].label) + '</label>'; }).join('') + '</div>';
    html += '<button class="btn btn-sm btn-secondary" id="l-add-custom" style="margin-top:8px">＋ Ajouter une colonne libre</button>';
    box.innerHTML = html;
    // Bind
    box.querySelectorAll('[data-col]').forEach(cb => cb.addEventListener('change', function(){ self._toggleCol(cb.dataset.col, cb.checked); }));
    box.querySelectorAll('.col-del').forEach(b => b.addEventListener('click', function(){ self._delCustom(b.dataset.id); }));
    const add = document.getElementById('l-add-custom'); if (add) add.addEventListener('click', function(){ self._addCustom(); });
  },

  _renderSortOpts() {
    const sel = document.getElementById('l-sort'); if (!sel) return;
    let html = '<option value="">Ordre actuel</option>';
    this._cols.forEach(function(c){
      if (c.blank) return;
      html += '<option value="' + c.id + '"' + (String(Listes._sortKey) === String(c.id) ? ' selected' : '') + '>' + escapeHtml(c.label) + '</option>';
    });
    sel.innerHTML = html;
    const dir = document.getElementById('l-sortdir');
    if (dir) dir.value = String(this._sortDir);
  },

  _toggleCol(id, on) {
    if (on) { const c = this.COLUMNS[id]; if (c && !this._colById(id)) this._cols.push({ id: id, label: c.label, w: c.w, get: c.get, blank: false }); }
    else { this._cols = this._cols.filter(function(c){ return c.id !== id; }); this._applyRemovedSort(id); }
    this._renderColumns(); this._renderSortOpts(); this._renderResults();
  },

  _applyRemovedSort(id) {
    if (String(this._sortKey) === String(id)) { this._sortKey = ''; this._sortDir = 1; this._applySort(); }
  },

  _moveCol(id, dir) {
    const i = this._colIndex(id); if (i < 0) return;
    const j = i + dir; if (j < 0 || j >= this._cols.length) return;
    const tmp = this._cols[i]; this._cols[i] = this._cols[j]; this._cols[j] = tmp;
    this._renderColumns(); this._renderSortOpts(); this._renderResults();
  },

  _reorderCol(draggedId, targetId) {
    if (draggedId === targetId) return;
    const from = this._colIndex(draggedId); if (from < 0) return;
    const it = this._cols.splice(from, 1)[0];
    let to = this._colIndex(targetId);
    if (to < 0) to = this._cols.length;
    this._cols.splice(to, 0, it);
    this._renderSortOpts(); this._renderResults();
    this._renderColumns();
  },

  _addCustom() {
    const label = window.prompt('Nom de la colonne libre (ex. « Observations », « Notes de l\u2019enseignant »…) :');
    if (label === null) return;
    this._customIdx++;
    const id = 'custom_' + this._customIdx;
    this._cols.push({ id: id, label: label.trim() || 'Colonne libre', w: 120, get: function(){ return ''; }, blank: true });
    this._renderColumns(); this._renderSortOpts(); this._renderResults();
  },

  _delCustom(id) {
    const idx = this._colIndex(id); if (idx < 0) return;
    const c = this._cols[idx]; if (!c.blank) return;
    this._cols.splice(idx, 1);
    if (String(this._sortKey) === String(id)) { this._sortKey = ''; this._applySort(); }
    this._renderColumns(); this._renderSortOpts(); this._renderResults();
  },

  _distinctNiveaux() {
    const seen = {}, out = [];
    this._classes.forEach(function(c){ const raw = c.niveaux; if (!raw || seen[raw]) return; seen[raw] = true; let label = raw; try { const arr = JSON.parse(raw); label = arr.map(function(n){ return NIVEAU_LABELS[n] || n; }).join(', '); } catch (e) {} out.push({ raw: raw, label: label }); });
    return out;
  },

  _bindEvents() {
    const on = function(id, fn){ const el = document.getElementById(id); if (el) el.addEventListener('change', fn); };
    const onC = function(id, fn){ const el = document.getElementById(id); if (el) el.addEventListener('click', fn); };
    on('l-q', function(){ Listes._filters.q = document.getElementById('l-q').value.trim(); });
    on('l-niveau', function(){ Listes._filters.niveau = document.getElementById('l-niveau').value; });
    on('l-classe', function(){ Listes._filters.classe_id = document.getElementById('l-classe').value || ''; });
    on('l-groupe', function(){ Listes._filters.groupe = document.getElementById('l-groupe').value; });
    on('l-ulis', function(){ const v = document.getElementById('l-ulis').value; Listes._filters.ulis = v === '' ? '' : parseInt(v); });
    on('l-droit', function(){ Listes._filters.droit_image = document.getElementById('l-droit').value; });
    on('l-transport', function(){ Listes._filters.transport = document.getElementById('l-transport').value; });
    on('l-cantine', function(){ const v = document.getElementById('l-cantine').value; Listes._filters.cantine = v === '' ? '' : parseInt(v); });
    on('l-pai', function(){ const v = document.getElementById('l-pai').value; Listes._filters.pai = v === '' ? '' : parseInt(v); });
    on('l-allergies', function(){ const v = document.getElementById('l-allergies').value; Listes._filters.allergies = v === '' ? '' : parseInt(v); });
    on('l-inactifs', function(){ Listes._filters.inclure_inactifs = document.getElementById('l-inactifs').checked; });
    on('l-orient', function(){ Listes._orient = document.getElementById('l-orient').value; });
    on('l-rowh', function(){ Listes._rowH = document.getElementById('l-rowh').value; });
    on('l-font', function(){ Listes._fontSize = parseFloat(document.getElementById('l-font').value) || 8; });
    on('l-entete', function(){ Listes._entete = document.getElementById('l-entete').value; });
    on('l-fin', function(){ Listes._fin = document.getElementById('l-fin').value; });
    on('l-sort', function(){ Listes._sortKey = document.getElementById('l-sort').value; Listes._applySort(); Listes._renderResults(); });
    on('l-sortdir', function(){ Listes._sortDir = parseInt(document.getElementById('l-sortdir').value, 10) || 1; Listes._applySort(); Listes._renderResults(); });
    onC('l-apply', function(){ Listes._apply(); });
    onC('l-reset', function(){ Listes._reset(); });
    onC('l-all', function(){ Listes._selectAll(true); });
    onC('l-none', function(){ Listes._selectAll(false); });
    onC('l-preview', function(){ Listes._exportPDF(); });
    onC('l-download', function(){ Listes._download(); });
    onC('l-csv', function(){ Listes._exportCSV(); });
    onC('l-group-save', function(){ Listes._saveGroup(false); });
    onC('l-group-update', function(){ Listes._saveGroup(true); });
    onC('l-group-load', function(){ Listes._loadGroup(); });
    onC('l-group-del', function(){ Listes._deleteGroup(); });
    onC('l-page-prev', function(){ Listes._navPreview(-1); });
    onC('l-page-next', function(){ Listes._navPreview(1); });
    onC('l-zoom-in', function(){ Listes._zoomChange(0.25); });
    onC('l-zoom-out', function(){ Listes._zoomChange(-0.25); });
    const q = document.getElementById('l-q');
    if (q) q.addEventListener('keydown', function(ev){ if (ev.key === 'Enter') Listes._apply(); });
    this._renderColumns();
  },

  async _apply() { await this._reload(); this._renderResults(); },
  async _reset() {
    this._filters = {};
    ['l-q','l-niveau','l-classe','l-groupe','l-ulis','l-droit','l-transport','l-cantine','l-pai','l-allergies'].forEach(function(id){ const el = document.getElementById(id); if (el) el.value = ''; });
    const inact = document.getElementById('l-inactifs'); if (inact) inact.checked = false;
    this._sortKey = ''; this._sortDir = 1;
    const s = document.getElementById('l-sort'); if (s) s.value = '';
    this._entete = 'Liste des élèves'; this._fin = 'Renseigné par : ____________________    Date : ______';
    const ei = document.getElementById('l-entete'); if (ei) ei.value = this._entete;
    const fi = document.getElementById('l-fin'); if (fi) fi.value = this._fin;
    const sd = document.getElementById('l-sortdir'); if (sd) sd.value = '1';
    await this._reload(); this._renderResults(); this._renderSortOpts();
  },
  _selectAll(all) { this._eleves.forEach(function(e){ all ? Listes._selected.add(e.id) : Listes._selected.delete(e.id); }); this._renderResults(); },

  // ── Tri ──

  _sortValue(e, c) {
    if (c.id === 'numero') { const n = parseInt(e.numero, 10); return isNaN(n) ? 0 : n; }
    if (c.id === 'age') { const n = parseInt(Listes._age(e.date_naissance), 10); return isNaN(n) ? 0 : n; }
    if (c.id === 'date_naissance') return e.date_naissance || '';
    const v = c.get.call(Listes, e);
    return v === null || v === undefined ? '' : String(v);
  },

  _applySort() {
    if (!this._sortKey) return;
    const c = this._colById(this._sortKey);
    if (!c) return;
    const dir = this._sortDir || 1;
    const self = this;
    this._eleves.sort(function(a, b){
      const av = self._sortValue(a, c), bv = self._sortValue(b, c);
      if (typeof av === 'number' && typeof bv === 'number') return (av - bv) * dir;
      return String(av).localeCompare(String(bv), 'fr') * dir;
    });
  },

  _renderResults() {
    const box = document.getElementById('l-results'); if (!box) return;
    this._resetPreview();
    const cols = this._cols;
    const thStyle = 'border:1px solid var(--border);padding:5px 10px;background:var(--bg-card,#eceff1);text-align:left;white-space:nowrap;font-weight:600;min-width:40px;cursor:pointer';
    const tdStyle = 'border:1px solid var(--border);padding:3px 10px;white-space:nowrap';
    let html = '<table class="filter-table" style="border-collapse:collapse;width:100%"><thead><tr><th style="border:1px solid var(--border);width:32px;background:var(--bg-card,#eceff1)"></th>';
    cols.forEach(function(c){
      const arrow = String(Listes._sortKey) === String(c.id) ? (Listes._sortDir === -1 ? ' ▼' : ' ▲') : '';
      html += '<th data-col="' + escapeHtml(c.id) + '" title="Trier par ' + escapeHtml(c.label) + '" style="' + thStyle + '">' + escapeHtml(c.label) + arrow + '</th>';
    });
    html += '</tr></thead><tbody>';
    this._eleves.forEach(function(e){
      const chk = Listes._selected.has(e.id) ? ' checked' : '';
      html += '<tr class="list-row" data-id="' + e.id + '"><td style="border:1px solid var(--border)"><input type="checkbox" class="l-row" data-id="' + e.id + '"' + chk + '></td>';
      cols.forEach(function(c){ html += '<td style="' + tdStyle + '">' + escapeHtml(String(c.get.call(Listes, e) || '')) + '</td>'; });
      html += '</tr>';
    });
    html += '</tbody></table>';
    box.innerHTML = html;
    box.querySelectorAll('.l-row').forEach(function(cb){
      cb.addEventListener('change', function(){ const id = parseInt(cb.dataset.id); if (cb.checked) Listes._selected.add(id); else Listes._selected.delete(id); const c = document.getElementById('l-count'); if (c) c.textContent = Listes._selected.size + ' sélectionné(s)'; });
    });
    const count = document.getElementById('l-count'); if (count) count.textContent = this._selected.size + ' sélectionné(s)';
    if (typeof linkLabels === 'function') linkLabels(box);
    // Réordonner les colonnes par glisser-déposer + trier au clic sur les en-têtes
    const ths = box.querySelectorAll('thead th[data-col]');
    ths.forEach(th => {
      th.setAttribute('draggable', 'true');
      th.style.cursor = 'grab';
      th.title = 'Glisser pour réordonner · cliquer pour trier';
      th.addEventListener('dragstart', function(ev){ ev.dataTransfer.setData('text/plain', this.dataset.col); this.classList.add('dragging'); ev.dataTransfer.effectAllowed = 'move'; });
      th.addEventListener('dragend', function(){ this.classList.remove('dragging'); box.querySelectorAll('th.drag-over').forEach(function(t){ t.classList.remove('drag-over'); t.style.outline = ''; }); });
      th.addEventListener('dragover', function(ev){ ev.preventDefault(); ev.dataTransfer.dropEffect = 'move'; box.querySelectorAll('th.drag-over').forEach(function(t){ t.classList.remove('drag-over'); t.style.outline = ''; }); this.classList.add('drag-over'); this.style.outline = '2px solid var(--primary)'; });
      th.addEventListener('dragleave', function(){ this.classList.remove('drag-over'); this.style.outline = ''; });
      th.addEventListener('drop', function(ev){ ev.preventDefault(); const d = ev.dataTransfer.getData('text/plain'); if (d) Listes._reorderCol(d, this.dataset.col); });
      th.addEventListener('click', function(){ Listes._sortByHeader(this.dataset.col); });
    });
  },

  _sortByHeader(id) {
    if (String(this._sortKey) === String(id)) {
      this._sortDir = this._sortDir === 1 ? -1 : 1;
    } else {
      this._sortKey = id; this._sortDir = 1;
    }
    this._applySort();
    this._renderSortOpts();
    this._renderResults();
  },

  _droitLabel: function(d){ const m = { autorise: '✅ Autorisé', refuse: '⛔ Refusé', limite: '⚠️ Limité', en_attente: '⏳ En attente', retire: '↩️ Retiré' }; return d ? (m[d.statut] || d.statut) : '—'; },
  _repsTel: function(e){ return (e.representants || []).map(function(r){ return r.telephone || r.telephone_urgence || ''; }).filter(Boolean).join(' / '); },
  _repsNom: function(e){ return (e.representants || []).map(function(r){ return (r.prenom ? r.prenom + ' ' : '') + (r.nom || ''); }).join(', '); },
  _age: function(birth){ if (!birth) return ''; const b = new Date(birth + 'T00:00:00'); const now = new Date(); let a = now.getFullYear() - b.getFullYear(); if (a < 0) return ''; const m = now.getMonth() - b.getMonth(); if (m < 0 || (m === 0 && now.getDate() < b.getDate())) a--; return a >= 0 ? a : ''; },

  _rowPad() {
    const map = { compact: 2, normale: 10, grande: 22, tresgrande: 34 };
    return map[this._rowH] || 10;
  },

  _computeWidths(cols, sel, orient, fontSize) {
    fontSize = fontSize || 8;
    // Largeur utile = largeur de la page A4 MINUS les marges (pageMargins [12,12,12,12])
    const margin = 12;
    const pageW = orient === 'landscape' ? 841.89 : 595.28;
    const avail = Math.floor(pageW - margin * 2) - 2;
    // Largeur moyenne d'un caractère (généreuse : chiffres/gras plus larges) + marge d'épaisseur
    const charW = fontSize * 0.62, cellPad = 10;
    const minW = 28;
    const tw = function(s){ return (String(s || '').length * charW) + cellPad; };
    // Largeur naturelle : au contenu le plus large (colonne de données) ;
    // espace généreux pour écrire (colonne libre).
    let w = cols.map(function(c){
      if (c.blank) return Math.max(80, c.w);
      let m = tw(c.label);
      sel.forEach(function(e){ const v = String(c.get.call(Listes, e) || ''); if (v) m = Math.max(m, tw(v)); });
      return Math.min(m, avail * 0.5);
    });
    let sum = w.reduce(function(a,b){ return a + b; }, 0);
    if (sum === 0) sum = 1;
    // Mettre à l'échelle pour tenir dans la page
    const scale = avail / sum;
    w = w.map(function(x){ return Math.max(minW, Math.round(x * scale)); });
    // Rééquilibrer le résidu sur TOUTES les colonnes (jamais une seule minuscule)
    let cur = w.reduce(function(a,b){ return a + b; }, 0);
    let diff = avail - cur;
    let guard = 0;
    while (diff !== 0 && guard < w.length * 12) {
      for (let k = 0; k < w.length && diff !== 0; k++) {
        if (diff > 0) { w[k] += 1; diff -= 1; }
        else if (w[k] > minW) { w[k] -= 1; diff += 1; }
      }
      guard++;
    }
    return w;
  },

  _buildPdfDef(sel) {
    const cols = this._cols;
    const pad = this._rowPad();
    const orient = this._orient === 'portrait' ? 'portrait' : 'landscape';
    const fontSize = this._fontSize || 8;
    const entete = this._entete && String(this._entete).trim() ? String(this._entete) : 'Liste des élèves';
    const fin = this._fin && String(this._fin).trim() ? String(this._fin) : 'Renseigné par : ____________________    Date : ______';
    const title = entete;
    const sub = (this._filters.q ? 'Recherche : ' + this._filters.q + ' · ' : '') + sel.length + ' élève(s) · ' + new Date().toLocaleDateString('fr-FR');
    // Largeurs calculées pour tenir dans la page (anti-débordement)
    const widths = this._computeWidths(cols, sel, orient, fontSize);
    const header = cols.map(function(c){ return { text: c.label, style: 'th' }; });
    const body = [header];
    sel.forEach(function(e){
      body.push(cols.map(function(c){ return { text: String(c.get.call(Listes, e) || ''), style: 'cell', margin: [1, 1, 1, pad] }; }));
    });
    return {
      pageSize: 'A4', pageOrientation: orient, pageMargins: [12, 12, 12, 12],
      content: [
        { text: title, style: 'header' },
        { text: sub, style: 'subheader' },
        { table: { headerRows: 1, widths: widths, body: body, dontBreakRows: true, layout: 'lightHorizontalLines' }, fontSize: fontSize },
        { text: ' ', margin: [0, 8, 0, 0] },
        { text: fin, style: 'foot' },
      ],
      styles: {
        header: { fontSize: 14, bold: true, alignment: 'center', margin: [0,0,0,4] },
        subheader: { fontSize: 9, alignment: 'center', color: '#666', margin: [0,0,0,8] },
        th: { fontSize: fontSize, bold: true, fillColor: '#eee', alignment: 'center' },
        cell: { fontSize: fontSize, margin: [1,1] },
        foot: { fontSize: 8, alignment: 'left', color: '#777', margin: [0, 6, 0, 0] },
      },
    };
  },

  _currentSel() {
    const ids = this._selected.size ? Array.from(this._selected) : this._eleves.map(function(e){ return e.id; });
    return this._eleves.filter(function(e){ return ids.indexOf(e.id) >= 0; });
  },

  async _exportPDF() {
    const sel = this._currentSel();
    if (!sel.length) { if (typeof Modal !== 'undefined' && Modal.alert) Modal.alert('Export', 'Aucun élève sélectionné.'); return; }
    const def = this._buildPdfDef(sel);
    this._pendingDef = def;
    this._pendingFilename = 'liste_eleves_' + new Date().toISOString().slice(0,10) + '.pdf';
    this._showPreview(def);
  },

  _download() {
    const filename = this._pendingFilename || 'liste_eleves_' + new Date().toISOString().slice(0,10) + '.pdf';
    if (!this._pendingDef) {
      const sel = this._currentSel();
      if (!sel.length) { if (typeof Modal !== 'undefined' && Modal.alert) Modal.alert('Export', 'Aucun élève sélectionné.'); return; }
      this._pendingDef = this._buildPdfDef(sel);
    }
    if (typeof pdfMake === 'undefined') { if (typeof Modal !== 'undefined' && Modal.alert) Modal.alert('Export', 'pdfmake non chargé. Vérifiez votre connexion.'); return; }
    pdfMake.createPdf(this._pendingDef).download(filename);
  },

  // ── Aperçu PDF (WYSIWYG) : rendu canvas PDF.js ──

  _resetPreview() {
    this._pendingDef = null; this._pendingFilename = null; this._previewPdf = null; this._previewPage = 1; this._previewZoom = 1;
    const area = document.getElementById('l-preview-area');
    const placeholder = document.getElementById('l-preview-placeholder');
    const dl = document.getElementById('l-download');
    if (area) area.style.display = 'none';
    if (placeholder) placeholder.style.display = 'block';
    if (dl) dl.disabled = true;
  },

  async _showPreview(def) {
    const area = document.getElementById('l-preview-area');
    const placeholder = document.getElementById('l-preview-placeholder');
    const dl = document.getElementById('l-download');
    if (typeof pdfMake === 'undefined' || typeof pdfjsLib === 'undefined') {
      if (typeof Modal !== 'undefined' && Modal.alert) Modal.alert('Aperçu', 'Le moteur PDF n\'est pas chargé.');
      return;
    }
    if (placeholder) placeholder.style.display = 'none';
    if (area) area.style.display = 'block';
    if (dl) dl.disabled = false;
    const pageInfo = document.getElementById('l-page-info');
    if (pageInfo) pageInfo.textContent = 'Génération…';
    pdfMake.createPdf(def).getBlob(async (blob) => {
      try {
        const arrayBuffer = await blob.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        this._previewPdf = pdf;
        this._previewPage = 1;
        this._previewZoom = 1;
        if (pageInfo) pageInfo.textContent = '1 / ' + pdf.numPages;
        await this._renderPreviewPage(1);
        this._zoomFit();
      } catch (e) {
        console.error('[Listes] preview error:', e);
        if (pageInfo) pageInfo.textContent = 'Erreur d\'aperçu.';
      }
    });
  },

  async _renderPreviewPage(pageNum) {
    const pdf = this._previewPdf; if (!pdf) return;
    const canvas = document.getElementById('l-preview-canvas'); if (!canvas) return;
    const pageInfo = document.getElementById('l-page-info');
    const dpr = window.devicePixelRatio || 1;
    const scale = (this._previewZoom * 1.5) / dpr;
    const page = await pdf.getPage(pageNum);
    const viewport = page.getViewport({ scale: scale });
    canvas.width = viewport.width * dpr;
    canvas.height = viewport.height * dpr;
    canvas.style.width = viewport.width + 'px';
    canvas.style.height = viewport.height + 'px';
    const ctx = canvas.getContext('2d');
    ctx.scale(dpr, dpr);
    ctx.clearRect(0, 0, viewport.width, viewport.height);
    await page.render({ canvasContext: ctx, viewport: viewport }).promise;
    if (pageInfo) pageInfo.textContent = 'Page ' + pageNum + ' / ' + pdf.numPages;
  },

  _navPreview(delta) {
    if (!this._previewPdf) return;
    const newPage = this._previewPage + delta;
    if (newPage < 1 || newPage > this._previewPdf.numPages) return;
    this._previewPage = newPage;
    this._renderPreviewPage(newPage);
  },

  _zoomChange(delta) {
    this._previewZoom = Math.max(0.25, Math.min(3, this._previewZoom + delta));
    this._updateZoomLabel();
    this._renderPreviewPage(this._previewPage);
  },

  _zoomFit() {
    if (!this._previewPdf) return;
    const wrapper = document.querySelector('#l-preview-area > div');
    if (!wrapper) return;
    const w = wrapper.clientWidth * 0.85;
    this._previewPdf.getPage(1).then(p => {
      const vp = p.getViewport({ scale: 1 });
      this._previewZoom = Math.max(0.25, w / vp.width);
      this._updateZoomLabel();
      this._renderPreviewPage(this._previewPage);
    });
  },

  _updateZoomLabel() {
    const lbl = document.getElementById('l-zoom-label');
    if (lbl) lbl.textContent = Math.round(this._previewZoom * 100) + '%';
  },

  async _exportCSV() {
    const sel = this._currentSel();
    if (!sel.length) { if (typeof Modal !== 'undefined' && Modal.alert) Modal.alert('Export', 'Aucun élève sélectionné.'); return; }
    const headers = this._cols.map(function(c){ return c.label; });
    const rows = sel.map(function(e){ const r = {}; Listes._cols.forEach(function(c){ r[c.label] = String(c.get.call(Listes, e) || ''); }); return r; });
    exportCSV('liste_eleves_' + new Date().toISOString().slice(0,10) + '.csv', headers, rows);
  },

  _buildGroupState() {
    return {
      filtres: Object.assign({}, this._filters),
      colonnes: this._cols.map(function(c){ return { id: c.id, label: c.label, blank: !!c.blank, w: c.w }; }),
      mise_en_page: { orient: this._orient, rowH: this._rowH, fontSize: this._fontSize, entete: this._entete, fin: this._fin },
      tri: { key: this._sortKey, dir: this._sortDir },
    };
  },

  _refreshGroupSelect() {
    const sel = document.getElementById('l-groupes');
    if (sel) sel.innerHTML = this._groupesSaved.map(function(g){ return '<option value="' + g.id + '">' + escapeHtml(g.nom) + '</option>'; }).join('');
  },

  async _saveGroup(isUpdate) {
    const sel = document.getElementById('l-groupes');
    let nom;
    if (isUpdate) {
      const g = this._groupesSaved.find(function(x){ return String(x.id) === sel.value; });
      if (!g) { if (typeof Modal !== 'undefined' && Modal.alert) Modal.alert('Groupes', "Choisissez d'abord un groupe à mettre à jour."); return; }
      nom = g.nom;
    } else {
      nom = window.prompt('Nom du nouveau groupe enregistré :');
      if (!nom) return;
    }
    const ids = this._selected.size ? Array.from(this._selected) : [];
    const body = { nom: nom, criteres: this._buildGroupState(), eleves_ids: ids };
    try {
      if (isUpdate) { await API.put('groupes.php?id=' + sel.value, body); }
      else { await API.post('groupes.php', body); }
      await this._loadOptions();
      this._refreshGroupSelect();
      if (typeof Toast !== 'undefined' && Toast.success) Toast.success(isUpdate ? 'Groupe mis à jour' : 'Groupe enregistré');
    } catch (e) { console.error('[Listes] save group:', e); }
  },

  _refreshLayoutUI() {
    const set = function(id, v){ const el = document.getElementById(id); if (el && v !== undefined && v !== null) el.value = v; };
    set('l-orient', this._orient); set('l-rowh', this._rowH); set('l-font', String(this._fontSize));
    set('l-entete', this._entete); set('l-fin', this._fin);
    const sd = document.getElementById('l-sortdir'); if (sd) sd.value = String(this._sortDir);
    this._renderSortOpts();
  },

  async _loadGroup() {
    const sel = document.getElementById('l-groupes'); if (!sel || !sel.value) return;
    const g = this._groupesSaved.find(function(x){ return String(x.id) === sel.value; }); if (!g) return;
    let ids = []; try { ids = JSON.parse(g.eleves_ids || '[]'); } catch (e) {}
    let crit = {}; try { crit = JSON.parse(g.criteres || '{}'); } catch (e) {}
    // Un groupe = un template : filtres + colonnes (et leur ordre) + mise en page + tri
    this._filters = crit.filtres || crit || {};
    if (crit.colonnes && crit.colonnes.length) {
      this._cols = crit.colonnes;
    }
    if (crit.mise_en_page) {
      if (crit.mise_en_page.orient) this._orient = crit.mise_en_page.orient;
      if (crit.mise_en_page.rowH) this._rowH = crit.mise_en_page.rowH;
      if (crit.mise_en_page.fontSize) this._fontSize = crit.mise_en_page.fontSize;
      if (crit.mise_en_page.entete) this._entete = crit.mise_en_page.entete;
      if (crit.mise_en_page.fin) this._fin = crit.mise_en_page.fin;
    }
    if (crit.tri) {
      if (crit.tri.key) this._sortKey = crit.tri.key;
      this._sortDir = crit.tri.dir && crit.tri.dir !== 0 ? crit.tri.dir : 1;
    }
    this._rebuildFilterUIFromState();
    this._refreshLayoutUI();
    this._renderColumns();
    await this._reload();
    this._selected = new Set(this._eleves.map(function(e){ return e.id; }).filter(function(id){ return ids.indexOf(id) >= 0; }));
    this._renderResults();
  },

  _rebuildFilterUIFromState() {
    const set = function(id, v){ const el = document.getElementById(id); if (el && v !== undefined && v !== null) el.value = v; };
    set('l-q', this._filters.q || ''); set('l-niveau', this._filters.niveau || ''); set('l-classe', this._filters.classe_id || ''); set('l-groupe', this._filters.groupe || '');
    if (this._filters.ulis === 0 || this._filters.ulis === 1) set('l-ulis', String(this._filters.ulis));
    set('l-droit', this._filters.droit_image || ''); set('l-transport', this._filters.transport || '');
    if (this._filters.cantine === 0 || this._filters.cantine === 1) set('l-cantine', String(this._filters.cantine));
    if (this._filters.pai === 0 || this._filters.pai === 1) set('l-pai', String(this._filters.pai));
    if (this._filters.allergies === 0 || this._filters.allergies === 1) set('l-allergies', String(this._filters.allergies));
    const inact = document.getElementById('l-inactifs'); if (inact) inact.checked = !!this._filters.inclure_inactifs;
  },

  async _deleteGroup() {
    const sel = document.getElementById('l-groupes'); if (!sel || !sel.value) return;
    if (!window.confirm('Supprimer ce groupe enregistré ?')) return;
    try {
      await API.del('groupes.php?id=' + sel.value);
      await this._loadOptions();
      sel.innerHTML = this._groupesSaved.map(function(g){ return '<option value="' + g.id + '">' + escapeHtml(g.nom) + '</option>'; }).join('');
    } catch (e) { console.error('[Listes] delete group:', e); }
  },
};
