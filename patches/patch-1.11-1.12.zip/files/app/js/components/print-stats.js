/**
 * Calulis — Print Stats : builders statistiques (pdfmake)
 * Attaché à l'objet Print via Object.assign
 */

Object.assign(Print, {

    /* ═══════════════════════════════════════════
       Export Statistiques
       ═══════════════════════════════════════════ */

    async _loadStats() {
        const anneeId = typeof State !== 'undefined' ? State.get('annee_scolaire_id') : null;
        const toutes = typeof State !== 'undefined' ? State.get('toutes_periodes') : false;
        const params = toutes ? '' : (anneeId ? '?annee_scolaire_id=' + anneeId : '');
        return API.get('stats.php' + params);
    },

    async _generateStats() {
        const statsType = document.querySelector('input[name="print-stats-type"]:checked')?.value || 'stats-dashboard';
        const btn = document.getElementById('btn-print-generate');
        btn.disabled = true;
        btn.textContent = '⏳ Génération…';

        try {
            const data = await this._loadStats();
            let def, filename;

            if (statsType === 'stats-dashboard') {
                filename = 'statistiques_tableau_de_bord.pdf';
                def = this._buildStatsDashboard(data);
            } else if (statsType === 'stats-inclusion') {
                filename = 'statistiques_inclusion.pdf';
                def = this._buildStatsInclusion(data);
            } else if (statsType === 'stats-evolution') {
                filename = 'statistiques_evolution.pdf';
                def = this._buildStatsEvolution(data);
            } else if (statsType === 'stats-periodes') {
                filename = 'statistiques_inclusion_periodes.pdf';
                def = this._buildStatsInclusionPeriodes(data);
            }

            if (def) this._showPreview(def, filename);
        } catch (e) {
            console.error('[Print] stats error:', e);
            if (typeof Modal !== 'undefined' && Modal.alert) {
                Modal.alert('Erreur', 'Impossible de générer les statistiques : ' + (e.message || 'Erreur inconnue'));
            }
        } finally {
            btn.disabled = false;
            btn.textContent = '🖨️ Générer l\'aperçu';
        }
    },

    _buildStatsDashboard(data) {
        const kpi = data.kpi || {};
        const inc = data.inclusion || {};
        const pec = data.pec || {};
        const ct = data.cantine_transport || {};
        const mdph = data.mdph || {};
        const anc = data.anciennete || {};
        const eco = data.ecoles_origine || {};
        const es = data.entrees_sorties || {};

        const today = new Date().toLocaleDateString('fr-FR');
        const content = [];

        content.push({ text: 'Tableau de bord ULIS', style: 'header', margin: [0, 0, 0, 2] });
        content.push({ text: `Généré le ${today}`, style: 'subheader', margin: [0, 0, 0, 12] });

        const _section = (title, tableDef) => {
            const items = [];
            if (title) items.push({ text: title, style: 'sectionTitle' });
            items.push(tableDef);
            return { stack: items, unbreakable: true, margin: [0, 0, 0, 6] };
        };

        // KPI
        content.push(_section('Indicateurs clés', {
            table: {
                headerRows: 0, widths: ['*', 'auto', '*', 'auto'],
                body: [
                    ['Effectif total', String(kpi.total || 0), 'Élèves ULIS', String(kpi.ulis || 0)],
                    ['Cantine', String(kpi.cantine || 0), 'Transport taxi', String(kpi.taxi || 0)],
                    ['Avec PEC', String(kpi.pec || 0), '', ''],
                ],
            },
            layout: { fillColor: (i) => i % 2 === 0 ? '#f9f9f9' : null },
        }));

        // Inclusion
        content.push(_section('Inclusion', {
            table: {
                headerRows: 0, widths: ['*', 'auto'],
                body: [
                    ['Heures totales sur l\'année', inc.total_heures_annee != null ? String(inc.total_heures_annee) + ' h' : '—'],
                    ['Heures par semaine (total)', inc.heures_par_semaine != null ? String(inc.heures_par_semaine) + ' h' : '—'],
                    ['Moyenne par élève / semaine', inc.moyenne_heures_eleve != null ? String(inc.moyenne_heures_eleve) + ' h' : '—'],
                    ['Semaines scolaires', inc.nb_semaines_scolaires != null ? String(inc.nb_semaines_scolaires) : '—'],
                    ['Heures école / semaine', inc.heures_ecole_semaine != null ? String(inc.heures_ecole_semaine) + ' h' : '—'],
                    ['% du temps total', inc.pourcentage_temps_total != null ? String(inc.pourcentage_temps_total) + ' %' : '—'],
                ],
            },
            layout: { fillColor: (i) => i % 2 === 0 ? '#f9f9f9' : null },
        }));

        // PEC
        const pecSpecs = pec.par_specialite || [];
        if (pecSpecs.length) {
            const pecBody = [['Organisme', 'Spécialités', 'Nb', 'Élèves concernés']];
            pecSpecs.forEach(p => pecBody.push([p.pec_organisme || '', p.pec_specialites || '', String(p.nb_eleves || 0), p.eleves_noms || '']));
            content.push(_section('Prises en charge (PEC)', {
                table: { headerRows: 1, widths: ['auto', 'auto', 'auto', '*'], body: pecBody },
                fontSize: 8,
            }));
        } else {
            content.push({ text: 'Aucune PEC renseignée.', margin: [0, 0, 0, 6], color: '#999' });
        }

        // Cantine & Transport
        const ctStackItems = [
            { text: 'Cantine & Transport', style: 'sectionTitle' },
            {
                table: {
                    headerRows: 0, widths: ['*', 'auto'],
                    body: [
                        ['Cantine', ct.cantine != null ? `${ct.cantine} élèves (${ct.cantine_pourcent || 0}%)` : '—'],
                    ],
                },
                layout: { fillColor: (i) => i % 2 === 0 ? '#f9f9f9' : null },
            },
        ];
        const transp = ct.transport || [];
        if (transp.length) {
            const tBody = [['Transport', 'Nb élèves']];
            transp.forEach(t => tBody.push([t.transport || '', String(t.nb || 0)]));
            ctStackItems.push({
                table: { headerRows: 1, widths: ['*', 'auto'], body: tBody },
                fontSize: 8, margin: [0, 4, 0, 0],
            });
        }
        content.push({ stack: ctStackItems, unbreakable: true, margin: [0, 0, 0, 6] });

        // MDPH
        const mdphBody = [['Type', 'Notifiés', 'Échéance ≤ 90j', 'Expirés']];
        Object.entries(mdph).forEach(([type, vals]) => {
            mdphBody.push([type, String(vals.notifies || 0), String(vals.echeance || 0), String(vals.expires || 0)]);
        });
        content.push(_section('Notifications MDPH', {
            table: { headerRows: 1, widths: ['*', 'auto', 'auto', 'auto'], body: mdphBody },
            fontSize: 8,
        }));

        // Ancienneté
        const r = anc.repartition || {};
        content.push(_section('Ancienneté dans le dispositif', {
            table: {
                headerRows: 0, widths: ['*', 'auto'],
                body: [
                    ['Moyenne', anc.moyenne != null ? String(anc.moyenne) : '—'],
                    ['Moins d’un an', String(r['moins1'] || 0)],
                    ['1 an', String(r[1] || 0)],
                    ['2 ans', String(r[2] || 0)],
                    ['3 ans', String(r[3] || 0)],
                    ['4+ ans', String(r['4plus'] || 0)],
                ],
            },
            layout: { fillColor: (i) => i % 2 === 0 ? '#f9f9f9' : null },
        }));

        // Écoles d'origine
        const ecoles = eco.ecoles || [];
        if (ecoles.length) {
            const ecoBody = [['École', 'Type', 'Nb élèves']];
            ecoles.slice(0, 10).forEach(e => ecoBody.push([e.ecole_nom || '', e.ecole_type || '', String(e.nb_eleves || 0)]));
            content.push(_section('Écoles d\'origine', {
                table: { headerRows: 1, widths: ['*', 'auto', 'auto'], body: ecoBody },
                fontSize: 8,
            }));
        }

        // Entrées/Sorties
        const parAnnee = es.par_annee || [];
        if (parAnnee.length) {
            const esBody = [['Année', 'Effectif', 'Entrées', 'Sorties']];
            parAnnee.forEach(a => esBody.push([a.nom || '', String(a.effectif || 0), String(a.entrees || 0), String(a.sorties || 0)]));
            content.push(_section('Entrées / Sorties', {
                table: { headerRows: 1, widths: ['*', 'auto', 'auto', 'auto'], body: esBody },
                fontSize: 8,
            }));
        }

        return {
            pageSize: 'A4', pageOrientation: 'portrait', pageMargins: [20, 20, 20, 20],
            content,
            defaultStyle: { fontSize: 9 },
            styles: {
                header: { fontSize: 16, bold: true, alignment: 'center', margin: [0, 0, 0, 2] },
                subheader: { fontSize: 9, alignment: 'center', color: '#666', margin: [0, 0, 0, 10] },
                sectionTitle: { fontSize: 11, bold: true, margin: [0, 12, 0, 4], color: '#2c3e50' },
            },
        };
    },

    _buildStatsInclusion(data) {
        const inc = data.inclusion || {};
        const parEleve = inc.par_eleve || [];
        const heuresEcole = inc.heures_ecole_semaine || 24;
        const tousPeriodes = data.inclusion_tous_eleves_periodes || {};
        const today = new Date().toLocaleDateString('fr-FR');

        let nbPeriodes = 0;
        for (const eid of Object.keys(tousPeriodes)) {
            nbPeriodes = Math.max(nbPeriodes, tousPeriodes[eid].length);
        }

        const content = [];
        content.push({ text: 'Inclusion — Détail par élève', style: 'header' });
        content.push({ text: `Généré le ${today} · ${inc.nb_semaines_scolaires || '?'} semaines scolaires · ${heuresEcole} h école/sem.`, style: 'subheader' });

        const headerRow = ['Élève', 'Heures totales', 'Heures/sem.', '% temps scolaire', 'Nb créneaux'];
        for (let p = 1; p <= nbPeriodes; p++) {
            headerRow.push(`P${p} h/sem`);
            headerRow.push(`P${p} %`);
        }
        const body = [headerRow];

        parEleve.forEach(e => {
            const pct = heuresEcole > 0 ? Math.round((e.heures_par_semaine || 0) / heuresEcole * 1000) / 10 : 0;
            const row = [
                `${e.prenom || ''} ${e.nom || ''}`.trim(),
                String(e.total_heures || 0) + ' h',
                String(e.heures_par_semaine || 0) + ' h/sem',
                String(pct) + ' %',
                String(e.nb_creneaux || 0),
            ];
            const elevePeriodes = tousPeriodes[e.eleve_id] || [];
            for (let p = 1; p <= nbPeriodes; p++) {
                const per = elevePeriodes.find(pp => pp.periode === p);
                const h = per ? per.heures_par_semaine || 0 : 0;
                row.push(per ? String(h) + ' h' : '—');
                row.push(per ? Math.round(h / heuresEcole * 100) + ' %' : '—');
            }
            body.push(row);
        });

        if (parEleve.length && nbPeriodes > 0) {
            const totalH = parEleve.reduce((s, e) => s + (e.total_heures || 0), 0);
            const totalC = parEleve.reduce((s, e) => s + (e.nb_creneaux || 0), 0);
            const totalRow = [
                { text: 'TOTAL', bold: true },
                { text: Math.round(totalH * 10) / 10 + ' h', bold: true },
                { text: inc.heures_par_semaine || '', bold: true },
                { text: inc.pourcentage_temps_total != null ? String(inc.pourcentage_temps_total) + ' %' : '', bold: true },
                { text: String(totalC), bold: true },
            ];
            for (let p = 1; p <= nbPeriodes; p++) {
                let sum = 0, count = 0;
                for (const eid of Object.keys(tousPeriodes)) {
                    const per = tousPeriodes[eid].find(pp => pp.periode === p);
                    if (per) { sum += per.heures_par_semaine || 0; count++; }
                }
                const avgH = count > 0 ? Math.round(sum / count * 10) / 10 : null;
                totalRow.push({ text: avgH != null ? avgH + ' h' : '—', bold: true, fontSize: 7 });
                totalRow.push({ text: avgH != null ? Math.round(avgH / heuresEcole * 100) + ' %' : '—', bold: true, fontSize: 7 });
            }
            body.push(totalRow);
        }

        const widths = ['*', 'auto', 'auto', 'auto', 'auto'];
        for (let p = 0; p < nbPeriodes; p++) { widths.push('auto'); widths.push('auto'); }

        content.push({
            table: { headerRows: 1, widths, body },
            fontSize: 7.5, margin: [0, 8, 0, 0],
        });

        content.push({
            text: `Moy/élève : ${inc.moyenne_heures_eleve || 0} h/sem · ${parEleve.length} élèves concernés${nbPeriodes > 0 ? ' · P1–P' + nbPeriodes + ' = périodes scolaires' : ''}`,
            fontSize: 8, color: '#666', margin: [0, 10, 0, 0],
        });

        return {
            pageSize: 'A4', pageOrientation: 'landscape', pageMargins: [15, 15, 15, 15],
            content, defaultStyle: { fontSize: 8 },
            styles: {
                header: { fontSize: 14, bold: true, alignment: 'center', margin: [0, 0, 0, 2] },
                subheader: { fontSize: 9, alignment: 'center', color: '#666', margin: [0, 0, 0, 12] },
            },
        };
    },

    _buildStatsInclusionPeriodes(data) {
        const periodes = data.inclusion_periodes || [];
        const inc = data.inclusion || {};
        const heuresEcole = inc.heures_ecole_semaine || 24;
        const today = new Date().toLocaleDateString('fr-FR');

        const content = [];
        content.push({ text: 'Inclusion par période', style: 'header' });
        content.push({ text: `Généré le ${today} · ${heuresEcole} h école/sem.`, style: 'subheader' });

        const body = [['Période', 'Semaines', 'Heures totales', 'Heures/sem.', '% temps scolaire', 'Nb créneaux']];
        periodes.forEach(p => {
            const pct = heuresEcole > 0 ? Math.round((p.heures_par_semaine || 0) / heuresEcole * 1000) / 10 : 0;
            body.push([
                'Période ' + (p.periode || '?'),
                String(p.nb_semaines || 0),
                String(p.total_heures || 0) + ' h',
                String(p.heures_par_semaine || 0) + ' h/sem',
                String(pct) + ' %',
                String(p.nb_creneaux || 0),
            ]);
        });

        if (periodes.length) {
            const totalH = periodes.reduce((s, p) => s + (p.total_heures || 0), 0);
            const totalS = periodes.reduce((s, p) => s + (p.nb_semaines || 0), 0);
            const totalC = periodes.reduce((s, p) => s + (p.nb_creneaux || 0), 0);
            body.push([
                { text: 'TOTAL', bold: true },
                { text: String(totalS), bold: true },
                { text: Math.round(totalH * 10) / 10 + ' h', bold: true },
                { text: totalS > 0 ? Math.round(totalH / totalS * 10) / 10 + ' h/sem' : '', bold: true },
                { text: inc.pourcentage_temps_total != null ? String(inc.pourcentage_temps_total) + ' %' : '', bold: true },
                { text: String(totalC), bold: true },
            ]);
        }

        content.push({
            table: { headerRows: 1, widths: ['auto', 'auto', 'auto', 'auto', 'auto', 'auto'], body },
            fontSize: 9, margin: [0, 8, 0, 0],
        });

        content.push({
            text: `Année complète : ${inc.total_heures_annee || 0} h · ${inc.nb_semaines_scolaires || '?'} semaines scolaires`,
            fontSize: 8, color: '#666', margin: [0, 10, 0, 0],
        });

        return {
            pageSize: 'A4', pageOrientation: 'landscape', pageMargins: [20, 20, 20, 20],
            content, defaultStyle: { fontSize: 9 },
            styles: {
                header: { fontSize: 14, bold: true, alignment: 'center', margin: [0, 0, 0, 2] },
                subheader: { fontSize: 9, alignment: 'center', color: '#666', margin: [0, 0, 0, 12] },
            },
        };
    },

    _buildStatsEvolution(data) {
        const evo = data.evolution || {};
        const parAnnee = evo.par_annee || [];
        const pecEvo = evo.pec_par_annee || [];
        const ecoEvo = evo.ecoles_par_annee || [];
        const today = new Date().toLocaleDateString('fr-FR');

        const content = [];
        content.push({ text: 'Évolution multi-année', style: 'header' });
        content.push({ text: `Généré le ${today}`, style: 'subheader' });

        if (parAnnee.length) {
            content.push({ text: 'Indicateurs par année', style: 'sectionTitle' });
            const body = [['Année', 'Effectif', 'ULIS', 'Cantine', 'Taxi', 'PEC', 'Inclusion (h)', 'MDPH', 'MDPH expr.', 'Entrées', 'Sorties']];
            parAnnee.forEach(a => {
                body.push([
                    a.nom || '', String(a.total || 0), String(a.ulis || 0), String(a.cantine || 0),
                    String(a.taxi || 0), String(a.pec || 0), String(a.inclusion_heures || 0),
                    String(a.mdph_total || 0), String(a.mdph_expires || 0),
                    String(a.entrees || 0), String(a.sorties || 0),
                ]);
            });
            content.push({
                table: { headerRows: 1, widths: ['auto', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto', 'auto'], body },
                fontSize: 7, margin: [0, 0, 0, 14],
            });
        }

        if (pecEvo.length) {
            content.push({ text: 'Évolution PEC par spécialité', style: 'sectionTitle' });
            const annees = parAnnee.map(a => a.nom);
            const header = ['Spécialité', ...annees];
            const body = [header];
            pecEvo.forEach(pec => {
                const row = [pec.specialite || ''];
                annees.forEach(nom => {
                    const v = (pec.values || []).find(v => v.nom === nom);
                    row.push(String(v ? v.nb : 0));
                });
                body.push(row);
            });
            content.push({
                table: { headerRows: 1, widths: ['*', ...annees.map(() => 'auto')], body },
                fontSize: 7, margin: [0, 0, 0, 14],
            });
        }

        if (ecoEvo.length) {
            content.push({ text: 'Écoles d\'origine par année', style: 'sectionTitle' });
            const annees = parAnnee.map(a => a.nom);
            const header = ['École', ...annees];
            const body = [header];
            ecoEvo.forEach(eco => {
                const row = [eco.ecole_nom || ''];
                annees.forEach(nom => {
                    const v = (eco.values || []).find(v => v.nom === nom);
                    row.push(String(v ? v.nb : 0));
                });
                body.push(row);
            });
            content.push({
                table: { headerRows: 1, widths: ['*', ...annees.map(() => 'auto')], body },
                fontSize: 7, margin: [0, 0, 0, 10],
            });
        }

        if (!parAnnee.length) {
            content.push({ text: 'Aucune donnée d\'évolution disponible.', color: '#999', margin: [0, 20, 0, 0] });
        }

        return {
            pageSize: 'A4', pageOrientation: 'landscape', pageMargins: [15, 15, 15, 15],
            content, defaultStyle: { fontSize: 8 },
            styles: {
                header: { fontSize: 14, bold: true, alignment: 'center', margin: [0, 0, 0, 2] },
                subheader: { fontSize: 9, alignment: 'center', color: '#666', margin: [0, 0, 0, 12] },
                sectionTitle: { fontSize: 10, bold: true, margin: [0, 10, 0, 4], color: '#2c3e50' },
            },
        };
    },

});
