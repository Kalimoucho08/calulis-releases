/**
 * Calulis — Composant Statistiques
 * Affiche KPI, inclusion, PEC, cantine/transport, MDPH, ancienneté, écoles, entrées/sorties.
 * Lignes cliquables → panneau détail avec évolution par année + par semaine.
 */
const StatsView = {
    _data: null,
    _expandedRow: null, // la <tr> actuellement expandée

    async render() {
        const view = document.getElementById('view-stats');
        if (!view) return;

        const anneeId = State.get('annee_scolaire_id');
        const toutesPeriodes = State.get('toutes_periodes');

        // Loading
        view.innerHTML = '<div style="padding:40px;text-align:center;color:var(--text-muted)">📊 Chargement des statistiques…</div>';

        try {
            const params = toutesPeriodes ? '' : (anneeId ? '?annee_scolaire_id=' + anneeId : '');
            this._data = await API.get('stats.php' + params);
            // Charger les classes pour le sélecteur de groupe
            if (!State.get('classes')) {
                try {
                    const classes = await API.get('classes.php');
                    State.set('classes', Array.isArray(classes) ? classes : []);
                } catch (e) { /* silencieux */ }
            }
            this._expandedRow = null;

            view.innerHTML = this._buildLayout();
            this._renderKPI();
            this._renderInclusion();
            this._renderPEC();
            this._renderCantineTransport();
            this._renderMDPH();
            this._renderAnciennete();
            this._renderEcoles();
            this._renderEntreesSorties();
            this._initCharts();
            this._initClickHandlers();
        } catch (e) {
            view.innerHTML = `<div style="padding:40px;text-align:center;color:var(--danger)">
                ❌ Erreur : ${escapeHtml(e.message)}</div>`;
        }
    },

    _buildLayout() {
        return `
            <div style="max-width:1000px;margin:0 auto;padding:16px">
                <h2 style="margin-bottom:16px">📊 Statistiques</h2>

                <!-- KPI cards -->
                <div class="kpi-grid" id="stats-kpi"></div>

                <!-- Sections repliables -->
                <div class="stats-section" id="section-inclusion">
                    <div class="stats-section-header" data-section="inclusion">
                        <span>1️⃣ Inclusion</span>
                        <span class="toggle-icon">▼</span>
                    </div>
                    <div class="stats-section-body" id="stats-inclusion-body"></div>
                </div>

                <div class="stats-section" id="section-pec">
                    <div class="stats-section-header" data-section="pec">
                        <span>2️⃣ Prise en charge (PEC)</span>
                        <span class="toggle-icon">▼</span>
                    </div>
                    <div class="stats-section-body" id="stats-pec-body"></div>
                </div>

                <div class="stats-section" id="section-cantine">
                    <div class="stats-section-header" data-section="cantine">
                        <span>3️⃣ Cantine & Transport</span>
                        <span class="toggle-icon">▼</span>
                    </div>
                    <div class="stats-section-body" id="stats-cantine-body"></div>
                </div>

                <div class="stats-section" id="section-mdph">
                    <div class="stats-section-header" data-section="mdph">
                        <span>4️⃣ Notifications MDPH</span>
                        <span class="toggle-icon">▼</span>
                    </div>
                    <div class="stats-section-body" id="stats-mdph-body"></div>
                </div>

                <div class="stats-section" id="section-anciennete">
                    <div class="stats-section-header" data-section="anciennete">
                        <span>5️⃣ Ancienneté dans le dispositif</span>
                        <span class="toggle-icon">▼</span>
                    </div>
                    <div class="stats-section-body" id="stats-anciennete-body"></div>
                </div>

                <div class="stats-section" id="section-ecoles">
                    <div class="stats-section-header" data-section="ecoles">
                        <span>6️⃣ Écoles d'origine</span>
                        <span class="toggle-icon">▼</span>
                    </div>
                    <div class="stats-section-body" id="stats-ecoles-body"></div>
                </div>

                <div class="stats-section" id="section-entrees">
                    <div class="stats-section-header" data-section="entrees">
                        <span>7️⃣ Entrées / Sorties</span>
                        <span class="toggle-icon">▼</span>
                    </div>
                    <div class="stats-section-body" id="stats-entrees-body"></div>
                </div>
            </div>
        `;
    },

    // ── KPI ──

    _renderKPI() {
        const kpi = this._data.kpi;
        if (!kpi) return;
        const total = Math.max(kpi.total, 1);  // A27: évite division par zéro, affiche 0 élèves quand 0
        const container = document.getElementById('stats-kpi');

        const cards = [
            { cls: 'total', icon: '👥', value: kpi.total, label: 'Élèves', pct: '', evoKey: 'total' },
            { cls: 'cantine', icon: '🍽️', value: kpi.cantine, label: 'Cantine', pct: `(${Math.round(kpi.cantine / total * 100)}%)`, evoKey: 'cantine' },
            { cls: 'taxi', icon: '🚕', value: kpi.taxi, label: 'Taxi', pct: `(${Math.round(kpi.taxi / total * 100)}%)`, evoKey: 'taxi' },
            { cls: 'pec', icon: '🏥', value: kpi.pec, label: 'PEC', pct: `(${Math.round(kpi.pec / total * 100)}%)`, evoKey: 'pec' },
        ];

        container.innerHTML = cards.map(c => `
            <div class="kpi-card clickable" data-kpi="${c.evoKey}" title="Cliquer pour voir l'évolution">
                <div class="kpi-value">${c.value} ${c.pct ? `<span class="kpi-pct">${c.pct}</span>` : ''}</div>
                <div class="kpi-label">${c.icon} ${c.label}</div>
                <div class="kpi-hint">📈 Voir évolution</div>
            </div>
        `).join('');
    },

    // ── Inclusion ──

    _renderInclusion() {
        const inc = this._data.inclusion;
        if (!inc) return;
        const body = document.getElementById('stats-inclusion-body');
        body.innerHTML = `
            <div class="stats-summary">
                <span>⏱️ Total inclusion : <strong>${inc.total_heures_annee}h/an</strong> (${inc.nb_semaines_scolaires ?? 0} semaines)</span>
                <span>📅 Par semaine : <strong>${inc.heures_par_semaine}h/sem</strong></span>
                <span>👤 Par élève/sem : <strong>${inc.moyenne_heures_eleve}h</strong></span>
                <span>📈 ${inc.pourcentage_temps_total}% du temps scolaire (${inc.heures_ecole_semaine || '?'}h/sem école)</span>
            </div>
            <div style="display:flex;gap:8px;margin-bottom:8px;align-items:center">
                <button class="detail-tab active" data-inclusion-view="eleves">👤 Par élève</button>
                <button class="detail-tab" data-inclusion-view="groupe">👥 Par groupe</button>
                <button class="detail-tab" data-inclusion-view="semaines">📅 Par semaine</button>
            </div>
            <div id="inclusion-view-eleves">
                <table class="data-table" style="margin-top:8px">
                    <thead><tr><th>Élève</th><th>h/sem</th><th>Total</th><th>Créneaux</th></tr></thead>
                    <tbody id="inclusion-table-body">
                        ${(inc.par_eleve || []).map(e => `
                            <tr class="clickable-row" data-section="inclusion-eleve" data-eleve-id="${e.eleve_id}" data-eleve-nom="${escapeHtml(e.nom)} ${escapeHtml(e.prenom)}">
                                <td>${escapeHtml(e.nom)} ${escapeHtml(e.prenom)}</td>
                                <td><strong>${e.heures_par_semaine}h</strong></td>
                                <td>${e.total_heures}h</td>
                                <td>${e.nb_creneaux}</td>
                            </tr>
                        `).join('') || '<tr><td colspan="4" class="empty">Aucune donnée</td></tr>'}
                    </tbody>
                </table>
            </div>
            <div id="inclusion-view-groupe" style="display:none">
                ${this._renderInclusionGroupe()}
            </div>
            <div id="inclusion-view-semaines" style="display:none">
                ${this._renderInclusionSemaines()}
            </div>
            <div class="chart-bar" id="chart-inclusion-bar"></div>
            ${this._renderInclusionPeriodes()}
        `;
    },

    _renderInclusionSemaines() {
        const semaines = this._data.inclusion_semaines;
        if (!semaines || !semaines.length) return '<p class="empty">Aucune donnée par semaine</p>';

        const scolaires = semaines.filter(s => !s.est_vacances);
        const totalHeures = scolaires.reduce((s, w) => s + w.heures_inclusion, 0);
        const maxH = Math.max(...semaines.map(s => s.heures_inclusion), 1);

        return `
            <div class="stats-summary" style="margin-top:8px">
                <span>📅 ${scolaires.length} semaines scolaires</span>
                <span>⏱️ ${totalHeures.toFixed(1)}h total</span>
                <span>📊 ${(totalHeures / Math.max(scolaires.length, 1)).toFixed(1)}h/sem moyenne</span>
            </div>
            <div style="margin-top:8px;font-size:11px;color:var(--text-muted)">Heatmap inclusion (survol = détail)</div>
            <div class="week-heatmap" style="margin-top:4px">
                ${semaines.map(s => {
                    const intensity = s.est_vacances ? 0 : Math.min(s.heures_inclusion / maxH, 1);
                    const r = Math.round(200 - intensity * 150);
                    const g = Math.round(200 - intensity * 180);
                    const b = Math.round(255 - intensity * 200);
                    return `<div class="week-cell ${s.est_vacances ? 'vacances' : ''}"
                        style="background:${s.est_vacances ? '' : `rgb(${r},${g},${b})`}"
                        data-tip="S${getSchoolWeekNumber(s, semaines)} : ${s.est_vacances ? 'Vacances' : s.heures_inclusion + 'h · ' + s.nb_creneaux + ' créneaux · ' + s.nb_eleves_inclus + ' élève(s)'}"
                        title="Semaine ${getSchoolWeekNumber(s, semaines)} — ${s.est_vacances ? 'Vacances' : s.heures_inclusion + 'h'}"></div>`;
                }).join('')}
            </div>
            <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--text-muted);margin-top:2px">
                <span>0h</span><span>${maxH.toFixed(0)}h</span>
            </div>
        `;
    },

    _renderInclusionGroupe() {
        const classes = State.get('classes') || [];
        const anneeId = State.get('annee_scolaire_id') || '';
        let html = `
            <div style="display:flex;gap:8px;align-items:center;margin-bottom:12px">
                <select id="inclusion-groupe-select" style="padding:6px 12px;border-radius:6px;border:1px solid var(--border-color);background:var(--card-bg);color:var(--text-color)">
                    <option value="">ULIS entière</option>
                    ${classes.map(c => `<option value="${c.id}">${escapeHtml(c.nom)}</option>`).join('')}
                </select>
                <button class="btn-sm" id="inclusion-groupe-load">🔍 Charger</button>
            </div>
            <div id="inclusion-groupe-result">
                <p style="color:var(--text-muted);font-size:13px">Sélectionne un groupe et clique sur Charger.</p>
            </div>
        `;
        // Attacher les événements après le rendu
        setTimeout(() => {
            const btn = document.getElementById('inclusion-groupe-load');
            const select = document.getElementById('inclusion-groupe-select');
            if (btn && select) {
                btn.addEventListener('click', () => this._loadGroupeStats(select.value));
            }
        }, 0);
        return html;
    },

    async _loadGroupeStats(classeId) {
        const container = document.getElementById('inclusion-groupe-result');
        if (!container) return;
        container.innerHTML = '<p style="color:var(--text-muted)">Chargement…</p>';

        try {
            const anneeId = State.get('annee_scolaire_id') || '';
            const params = [`section=inclusion_groupe`, `annee_scolaire_id=${anneeId}`];
            if (classeId) params.push(`classe_id=${classeId}`);
            const data = await API.get('stats.php?' + params.join('&'));
            const g = data.inclusion_groupe;
            if (!g || g.effectif === 0) {
                container.innerHTML = '<p style="color:var(--text-muted)">Aucun élève dans ce groupe pour l\'année sélectionnée.</p>';
                return;
            }

            const pctColor = g.pourcentage_inclusion >= 50 ? 'var(--success)' : g.pourcentage_inclusion >= 25 ? 'var(--warning,#ff9800)' : 'var(--danger)';

            container.innerHTML = `
                <div class="stats-summary" style="margin-bottom:12px">
                    <span>👥 <strong>${escapeHtml(g.nom_groupe)}</strong> · ${g.effectif} élève(s)</span>
                    <span>⏱️ <strong>${g.heures_par_semaine}h/sem</strong> (${g.total_heures_annee}h/an)</span>
                    <span>📈 <strong style="color:${pctColor}">${g.pourcentage_inclusion}%</strong> d'inclusion</span>
                    <span>🏫 ${g.heures_ecole_semaine}h école/sem · ${g.nb_semaines_scolaires} sem</span>
                </div>
                <div style="display:flex;gap:8px;margin-bottom:8px">
                    <button class="detail-tab active" data-groupe-tab="periodes">📅 Par période</button>
                    <button class="detail-tab" data-groupe-tab="annees">📆 Par année</button>
                </div>
                <div id="groupe-tab-periodes">${this._renderGroupePeriodes(g)}</div>
                <div id="groupe-tab-annees" style="display:none">${this._renderGroupeAnnees(g)}</div>
            `;

            container.querySelectorAll('[data-groupe-tab]').forEach(tab => {
                tab.addEventListener('click', () => {
                    container.querySelectorAll('[data-groupe-tab]').forEach(t => t.classList.remove('active'));
                    tab.classList.add('active');
                    const target = tab.dataset.groupeTab;
                    document.getElementById('groupe-tab-periodes').style.display = target === 'periodes' ? 'block' : 'none';
                    document.getElementById('groupe-tab-annees').style.display = target === 'annees' ? 'block' : 'none';
                });
            });
        } catch (e) {
            container.innerHTML = `<p style="color:var(--danger)">Erreur : ${escapeHtml(e.message)}</p>`;
        }
    },

    _renderGroupePeriodes(g) {
        const periodes = g.par_periode || [];
        if (!periodes.length) return '<p style="font-size:13px;color:var(--text-muted)">Aucune donnée par période.</p>';
        const maxH = Math.max(...periodes.map(p => p.heures_par_semaine), 1);
        const maxPct = Math.max(...periodes.map(p => p.pourcentage_inclusion), 1);
        return `
            <div class="mini-bars" style="height:100px">
                ${periodes.map(p => {
                    const pctH = Math.round((p.heures_par_semaine / maxH) * 100);
                    return `
                    <div class="mini-bar-group" title="P${p.periode} : ${p.heures_par_semaine}h/sem · ${p.pourcentage_inclusion}% · ${p.nb_semaines} sem">
                        <div class="mini-bar-fill" style="height:${Math.max(pctH, 4)}%;background:#2196f3">${p.heures_par_semaine}h</div>
                        <div class="mini-bar-label">P${p.periode}</div>
                    </div>`;
                }).join('')}
            </div>
            <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--text-muted);margin-top:2px">
                <span>0h/sem</span><span>${maxH}h/sem</span>
            </div>
            <div style="margin-top:4px;font-size:12px">
                ${periodes.map(p => `
                    <span style="display:inline-block;width:18%;text-align:center;font-size:11px" title="${p.pourcentage_inclusion}%">
                        <strong>${p.pourcentage_inclusion}%</strong>
                    </span>
                `).join('')}
            </div>
            <div style="margin-top:2px;font-size:11px;color:var(--text-muted)">${this._computeTrend(periodes.map(p => ({ label: 'P'+p.periode, value: p.heures_par_semaine })))}</div>
        `;
    },

    _renderGroupeAnnees(g) {
        const annees = g.par_annee || [];
        if (annees.length < 2) return '<p style="font-size:13px;color:var(--text-muted)">Pas assez de données multi-année.</p>';
        const maxH = Math.max(...annees.map(a => a.heures_par_semaine), 1);
        return `
            <div class="mini-bars" style="height:100px">
                ${annees.map(a => {
                    const pctH = Math.round((a.heures_par_semaine / maxH) * 100);
                    return `
                    <div class="mini-bar-group" title="${a.nom} : ${a.heures_par_semaine}h/sem · ${a.pourcentage_inclusion}% · ${a.effectif} élève(s)">
                        <div class="mini-bar-fill" style="height:${Math.max(pctH, 4)}%;background:#ff9800">${a.heures_par_semaine > 0 ? a.heures_par_semaine + 'h' : ''}</div>
                        <div class="mini-bar-label">${this._shortAnnee(a.nom)}</div>
                    </div>`;
                }).join('')}
            </div>
            <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--text-muted);margin-top:2px">
                <span>0h/sem</span><span>${maxH}h/sem</span>
            </div>
            <div style="margin-top:4px;font-size:12px">
                ${annees.map(a => `
                    <span style="display:inline-block;width:${Math.floor(100/annees.length)}%;text-align:center;font-size:11px" title="${a.pourcentage_inclusion}%">
                        <strong>${a.pourcentage_inclusion}%</strong>
                    </span>
                `).join('')}
            </div>
            <div style="margin-top:2px;font-size:11px;color:var(--text-muted)">${this._computeTrend(annees.map(a => ({ label: a.nom, value: a.heures_par_semaine })))}</div>
        `;
    },

    _renderInclusionPeriodes() {
        const periodes = this._data.inclusion_periodes;
        if (!periodes || !periodes.length) return '';
        const max = Math.max(...periodes.map(p => p.heures_par_semaine), 1);
        return `
            <h4 style="margin-top:20px">📅 Évolution par période</h4>
            <div class="periode-chart">
                ${periodes.map(p => {
                    const pct = Math.round(p.heures_par_semaine / max * 100);
                    return `
                    <div class="periode-bar-group">
                        <div class="periode-label">P${p.periode}</div>
                        <div class="periode-bar-track">
                            <div class="periode-bar-fill" style="width:${pct}%">${p.heures_par_semaine}h</div>
                        </div>
                        <div class="periode-meta">${p.nb_semaines} sem</div>
                    </div>`;
                }).join('')}
            </div>
        `;
    },

    // ── PEC ──

    _renderPEC() {
        const pec = this._data.pec;
        if (!pec) return;
        const body = document.getElementById('stats-pec-body');
        const total = this._data.kpi?.total || 1;
        body.innerHTML = `
            <div class="stats-summary">
                <span>🏥 Élèves avec PEC : <strong>${pec.total_avec_pec}/${total} (${Math.round(pec.total_avec_pec / total * 100)}%)</strong></span>
            </div>
            <table class="data-table" style="margin-top:12px">
                <thead><tr><th>Organisme</th><th>Spécialités</th><th>Nb élèves</th><th>%</th></tr></thead>
                <tbody>
                    ${(pec.par_specialite || []).map(s => `
                        <tr class="clickable-row" data-section="pec" data-organisme="${escapeHtml(s.pec_organisme || '')}">
                            <td>${escapeHtml(s.pec_organisme || 'Non spécifié')}</td>
                            <td>${escapeHtml(s.pec_specialites || '—')}</td>
                            <td><strong>${s.nb_eleves}</strong></td>
                            <td>${total > 0 ? Math.round(s.nb_eleves / total * 100) : 0}%</td>
                        </tr>
                    `).join('') || '<tr><td colspan="4" class="empty">Aucune donnée</td></tr>'}
                </tbody>
            </table>
        `;
    },

    // ── Cantine & Transport ──

    _renderCantineTransport() {
        const ct = this._data.cantine_transport;
        if (!ct) return;
        const body = document.getElementById('stats-cantine-body');
        body.innerHTML = `
            <div class="stats-duo">
                <div class="stats-half">
                    <h4>🍽️ Cantine</h4>
                    <div class="stats-summary">
                        <span>Oui : <strong>${ct.cantine}</strong> (${ct.cantine_pourcent}%)</span>
                        <span>Non : <strong>${ct.total - ct.cantine}</strong> (${(100 - ct.cantine_pourcent).toFixed(1)}%)</span>
                    </div>
                    <canvas id="chart-cantine" width="200" height="200" style="max-width:200px;margin:8px auto"></canvas>
                </div>
                <div class="stats-half">
                    <h4>🚌 Transport</h4>
                    <table class="data-table" style="font-size:12px">
                        <thead><tr><th>Mode</th><th>Nb</th></tr></thead>
                        <tbody>
                            ${(ct.transport || []).map(t => `
                                <tr class="clickable-row" data-section="transport" data-mode="${escapeHtml(t.transport || 'Inconnu')}">
                                    <td>${escapeHtml(t.transport || 'Inconnu')}</td><td>${t.nb}</td>
                                </tr>
                            `).join('') || '<tr><td colspan="2" class="empty">Aucun transport</td></tr>'}
                        </tbody>
                    </table>
                    <canvas id="chart-transport" width="200" height="200" style="max-width:200px;margin:8px auto"></canvas>
                </div>
            </div>
        `;
    },

    // ── MDPH ──

    _renderMDPH() {
        const mdph = this._data.mdph;
        if (!mdph) return;
        const body = document.getElementById('stats-mdph-body');
        body.innerHTML = `
            <table class="data-table">
                <thead><tr><th>Type</th><th>Notifiés</th><th>%</th><th>⚠ Échéance</th><th>🔴 Expiré</th></tr></thead>
                <tbody>
                    ${Object.entries(mdph).map(([type, d]) => {
                        const total = this._data.kpi?.total || 1;
                        return `<tr class="clickable-row" data-section="mdph" data-type="${type}">
                            <td><strong>${type}</strong></td>
                            <td>${d.notifies}</td>
                            <td>${total > 0 ? Math.round(d.notifies / total * 100) : 0}%</td>
                            <td>${d.echeance > 0 ? `<span class="badge badge-warning">${d.echeance}</span>` : '0'}</td>
                            <td>${d.expires > 0 ? `<span class="badge badge-danger">${d.expires}</span>` : '0'}</td>
                        </tr>`;
                    }).join('')}
                </tbody>
            </table>
        `;
    },

    // ── Ancienneté ──

    _renderAnciennete() {
        const anc = this._data.anciennete;
        if (!anc) return;
        const body = document.getElementById('stats-anciennete-body');
        const r = anc.repartition || {};
        const order = ['moins1', '1', '2', '3', '4plus'];
        const labels = { moins1: 'Moins d’un an', '1': '1 an', '2': '2 ans', '3': '3 ans', '4plus': '4 ans et +' };
        const maxVal = Math.max(...order.map(k => r[k] || 0), 1);
        body.innerHTML = `
            <div class="stats-summary" style="cursor:pointer" id="anciennete-summary-click" title="Voir évolution">
                <span>📊 Ancienneté moyenne : <strong>${anc.moyenne}</strong></span>
                <span>👥 Total élèves suivis : <strong>${anc.total}</strong></span>
                <span class="kpi-hint">📈 Voir évolution par année</span>
            </div>
            <div style="margin-top:12px">
                ${order.map(k => {
                    const v = r[k] || 0;
                    const pct = maxVal > 0 ? Math.round(v / maxVal * 100) : 0;
                    return `
                        <div style="display:flex;align-items:center;gap:8px;margin-bottom:6px;font-size:14px">
                            <span style="width:80px;text-align:right">${labels[k]}</span>
                            <div style="flex:1;height:24px;background:var(--bg-color);border-radius:4px;overflow:hidden">
                                <div style="height:100%;width:${pct}%;background:var(--primary);border-radius:4px;display:flex;align-items:center;padding-left:8px;color:#fff;font-size:12px;font-weight:600;min-width:30px">${v}</div>
                            </div>
                        </div>
                    `;
                }).join('')}
            </div>
            <div id="anciennete-detail-container"></div>
        `;
    },

    // ── Écoles d'origine ──

    /** Raccourcit un nom d'année scolaire "2024-2025" → "24-25" */
    _shortAnnee(label) {
        if (!label || label.length < 9) return label;
        return label.slice(2, 4) + '-' + label.slice(-2);
    },

    _typeEtabLabel(type) {
        const map = {
            ecole_primaire: 'École primaire', ecole_maternelle: 'École maternelle',
            college: 'Collège', lycee: 'Lycée',
            cmpp: 'CMPP', cmp: 'CMP', sessad: 'SESSAD',
            foyer_ase: 'Foyer ASE', association: 'Association',
            itep: 'ITEP', ime: 'IME', ulis: 'ULIS', autre: 'Autre'
        };
        return map[type] || type;
    },

    _renderEcoles() {
        const eco = this._data.ecoles_origine;
        if (!eco) return;
        const body = document.getElementById('stats-ecoles-body');
        body.innerHTML = `
            <table class="data-table">
                <thead><tr><th>École</th><th>Type</th><th>Élèves</th></tr></thead>
                <tbody>
                    ${(eco.ecoles || []).map(e => `
                        <tr class="clickable-row" data-section="ecoles" data-ecole="${escapeHtml(e.ecole_nom || 'Inconnue')}">
                            <td>${escapeHtml(e.ecole_nom || 'Inconnue')}</td>
                            <td>${escapeHtml(this._typeEtabLabel(e.ecole_type || ''))}</td>
                            <td><strong>${e.nb_eleves}</strong></td>
                        </tr>
                    `).join('') || '<tr><td colspan="3" class="empty">Aucune donnée</td></tr>'}
                </tbody>
            </table>
        `;
    },

    // ── Entrées / Sorties ──

    _renderEntreesSorties() {
        const es = this._data.entrees_sorties;
        if (!es) return;
        const body = document.getElementById('stats-entrees-body');
        const annees = es.par_annee || [];
        body.innerHTML = `
            <table class="data-table">
                <thead><tr><th>Année</th><th>Entrées</th><th>Sorties</th><th>Solde</th><th>Effectif</th></tr></thead>
                <tbody>
                    ${annees.map(a => {
                        const solde = a.entrees - a.sorties;
                        return `<tr class="clickable-row" data-section="entrees" data-annee-id="${a.annee_id}">
                            <td><strong>${escapeHtml(a.nom)}</strong></td>
                            <td style="color:var(--success)">+${a.entrees}</td>
                            <td style="color:var(--danger)">-${a.sorties}</td>
                            <td><strong>${solde >= 0 ? '+' : ''}${solde}</strong></td>
                            <td>${a.effectif}</td>
                        </tr>`;
                    }).join('') || '<tr><td colspan="5" class="empty">Aucune donnée</td></tr>'}
                </tbody>
            </table>
            <div class="chart-line" id="chart-entrees-line">
                <canvas id="chart-evolution" width="600" height="250" style="max-width:100%;margin:12px auto;display:block"></canvas>
            </div>
        `;
    },

    // ═══ GESTION DES CLIQUABLES ═══

    _initClickHandlers() {
        // KPI cards
        document.querySelectorAll('.kpi-card.clickable').forEach(card => {
            card.addEventListener('click', () => {
                const key = card.dataset.kpi;
                this._toggleDetailGlobal('kpi', key, 'KPI ' + key);
            });
        });

        // Table rows
        document.querySelectorAll('.data-table tr.clickable-row').forEach(row => {
            row.addEventListener('click', (e) => {
                if (e.target.closest('a, button, .badge')) return;
                this._handleRowClick(row);
            });
        });

        // Ancienneté summary
        const ancSummary = document.getElementById('anciennete-summary-click');
        if (ancSummary) {
            ancSummary.addEventListener('click', () => this._toggleDetailGlobal('anciennete', 'all', 'Ancienneté'));
        }
    },

    _handleRowClick(row) {
        const section = row.dataset.section;
        if (!section) return;

        if (this._expandedRow === row) {
            this._closeDetail();
            return;
        }

        this._closeDetail();

        row.classList.add('expanded');
        this._expandedRow = row;

        const detailRow = document.createElement('tr');
        detailRow.className = 'stats-detail-row';
        const colSpan = row.children.length;
        detailRow.innerHTML = `<td colspan="${colSpan}"><div class="stats-detail-panel" id="stats-detail-content">Chargement…</div></td>`;
        row.after(detailRow);

        this._fillDetailPanel(section, row);
    },

    _closeDetail() {
        if (!this._expandedRow) return;
        this._expandedRow.classList.remove('expanded');
        const detailRow = this._expandedRow.nextElementSibling;
        if (detailRow && detailRow.classList.contains('stats-detail-row')) {
            detailRow.remove();
        }
        this._expandedRow = null;
    },

    _toggleDetailGlobal(section, key, label) {
        let container;
        if (section === 'anciennete') {
            container = document.getElementById('anciennete-detail-container');
        } else if (section === 'kpi') {
            container = document.getElementById('stats-detail-global');
            if (!container) {
                const kpiGrid = document.getElementById('stats-kpi');
                container = document.createElement('div');
                container.id = 'stats-detail-global';
                container.style.cssText = 'margin-top:8px';
                kpiGrid.after(container);
            }
        }

        if (!container) return;

        if (container.dataset.activeKey === key && container.innerHTML) {
            container.innerHTML = '';
            container.dataset.activeKey = '';
            return;
        }

        container.dataset.activeKey = key;
        container.innerHTML = `<div class="stats-detail-panel" style="border:1px solid var(--border-color);border-radius:8px;margin-top:8px">
            <div class="stats-detail-header">
                <strong>📈 Évolution de « ${escapeHtml(label)} »</strong>
                <button class="stats-detail-close" onclick="this.closest('.stats-detail-panel').parentElement.innerHTML=''">✕</button>
            </div>
            <div id="stats-detail-inner-${section}">Chargement…</div>
        </div>`;

        const inner = document.getElementById(`stats-detail-inner-${section}`);
        this._renderEvolutionBars(inner, section, key);
    },

    async _fillDetailPanel(section, row) {
        const content = document.getElementById('stats-detail-content');
        if (!content) return;

        const isEleve = section === 'inclusion-eleve';
        const tab2Label = isEleve ? '📅 Par période' : '📆 Par semaine';
        const tab2Id = isEleve ? 'periodes' : 'semaines';

        content.innerHTML = `<div style="display:flex;justify-content:space-between;align-items:center">
            <strong>📈 Évolution</strong>
            <div>
                <button class="detail-tab active" data-detail-tab="annees">📆 Par année</button>
                <button class="detail-tab" data-detail-tab="${tab2Id}">${tab2Label}</button>
                <button class="stats-detail-close" onclick="StatsView._closeDetail()" style="margin-left:8px">✕</button>
            </div>
        </div>
        <div id="detail-tab-annees"></div>
        <div id="detail-tab-${tab2Id}" style="display:none"></div>`;

        const tabAnnees = document.getElementById('detail-tab-annees');
        this._renderEvolutionBars(tabAnnees, section, row);

        const tab2 = document.getElementById('detail-tab-' + tab2Id);
        if (isEleve) {
            this._renderElevePeriodes(tab2, row);
        } else {
            this._renderEvolutionSemaines(tab2, section, row);
        }

        content.querySelectorAll('.detail-tab').forEach(tab => {
            tab.addEventListener('click', () => {
                content.querySelectorAll('.detail-tab').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                const target = tab.dataset.detailTab;
                document.getElementById('detail-tab-annees').style.display = target === 'annees' ? 'block' : 'none';
                document.getElementById('detail-tab-' + tab2Id).style.display = target === tab2Id ? 'block' : 'none';
            });
        });
    },

    // ── Rendu évolution PAR ANNÉE ──

    _renderEvolutionBars(container, section, rowOrKey) {
        const evo = this._data.evolution;
        const parAnnee = evo?.par_annee || [];

        if (parAnnee.length < 2) {
            container.innerHTML = '<p style="font-size:13px;color:var(--text-muted)">Pas assez de données multi-année (1 seule année).</p>';
            return;
        }

        let title = '';
        let values = [];
        let color = '#2196f3';
        let unit = '';

        if (section === 'kpi') {
            const key = typeof rowOrKey === 'string' ? rowOrKey : '';
            const labelMap = { total: 'Élèves', cantine: 'Cantine', taxi: 'Taxi', pec: 'PEC' };
            title = labelMap[key] || key;
            values = parAnnee.map(a => ({ label: a.nom, value: a[key] || 0 }));
            unit = '';
            color = '#2196f3';
        } else if (section === 'inclusion-eleve') {
            const eleveId = rowOrKey?.dataset?.eleveId;
            const eleveNom = rowOrKey?.dataset?.eleveNom || 'Élève';
            title = eleveNom;
            this._loadEleveEvolution(container, eleveId, eleveNom);
            return;
        } else if (section === 'pec') {
            const specialite = rowOrKey?.dataset?.specialite || '';
            title = specialite;
            const pecData = evo?.pec_par_annee || [];
            const found = pecData.find(p => p.specialite === specialite);
            values = found ? found.values.map(v => ({ label: v.nom, value: v.nb })) : [];
            unit = 'élèves';
            color = '#ff9800';
        } else if (section === 'transport') {
            const mode = rowOrKey?.dataset?.mode || '';
            title = 'Transport ' + mode;
            values = parAnnee.map(a => ({ label: a.nom, value: a.total }));
            unit = 'élèves (total)';
            color = '#4caf50';
        } else if (section === 'mdph') {
            const type = rowOrKey?.dataset?.type || '';
            title = 'MDPH ' + type;
            values = parAnnee.map(a => ({ label: a.nom, value: a.mdph_total }));
            unit = 'notifications';
            color = '#9c27b0';
        } else if (section === 'ecoles') {
            const ecole = rowOrKey?.dataset?.ecole || '';
            title = ecole;
            const ecoData = evo?.ecoles_par_annee || [];
            const found = ecoData.find(e => e.ecole_nom === ecole);
            values = found ? found.values.map(v => ({ label: v.nom, value: v.nb })) : [];
            unit = 'élèves';
            color = '#00bcd4';
        } else if (section === 'entrees') {
            title = 'Entrées/Sorties';
            values = parAnnee.map(a => ({
                label: a.nom,
                value: (a.entrees || 0) - (a.sorties || 0),
            }));
            unit = 'solde';
            color = '#e91e63';
        } else if (section === 'anciennete') {
            title = 'Ancienneté';
            values = parAnnee.map(a => ({ label: a.nom, value: a.total }));
            unit = 'élèves';
            color = '#607d8b';
        }

        if (values.length === 0) {
            container.innerHTML = '<p style="font-size:13px;color:var(--text-muted)">Aucune donnée d\'évolution.</p>';
            return;
        }

        const maxVal = Math.max(...values.map(v => v.value), 1);
        const minVal = Math.min(...values.map(v => v.value), 0);
        const range = maxVal - minVal || 1;

        container.innerHTML = `
            <div style="font-size:12px;color:var(--text-muted);margin-bottom:6px">${title} ${unit ? '· ' + unit : ''}</div>
            <div class="mini-bars">
                ${values.map(v => {
                    const pct = Math.round(((v.value - minVal) / range) * 100);
                    const displayVal = v.value;
                    return `
                    <div class="mini-bar-group" title="${v.label} : ${displayVal}${unit ? ' ' + unit : ''}">
                        <div class="mini-bar-fill" style="height:${Math.max(pct, 4)}%;background:${color}">${displayVal > 0 ? displayVal : ''}</div>
                        <div class="mini-bar-label">${this._shortAnnee(v.label)}</div>
                    </div>`;
                }).join('')}
            </div>
            <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--text-muted);margin-top:2px">
                <span>${minVal}${unit ? ' ' + unit : ''}</span>
                <span>${maxVal}${unit ? ' ' + unit : ''}</span>
            </div>
            <div style="margin-top:8px;font-size:11px;color:var(--text-muted)">
                ${this._computeTrend(values)}
            </div>
        `;
    },

    _computeTrend(values) {
        if (values.length < 2) return '';
        const first = values[0].value;
        const last = values[values.length - 1].value;
        if (last > first) return `📈 En hausse : +${(last - first).toFixed(1)} depuis ${values[0].label}`;
        if (last < first) return `📉 En baisse : ${(last - first).toFixed(1)} depuis ${values[0].label}`;
        return `➡️ Stable depuis ${values[0].label}`;
    },

    async _loadEleveEvolution(container, eleveId, eleveNom) {
        try {
            const data = await API.get(`stats.php?section=inclusion_eleve_evolution&eleve_id=${eleveId}`);
            const evo = data.inclusion_eleve_evolution || [];
            if (evo.length < 2) {
                container.innerHTML = '<p style="font-size:13px;color:var(--text-muted)">Pas assez de données multi-année.</p>';
                return;
            }
            const hEcole = this._data.inclusion?.heures_ecole_semaine || 24;
            const maxH = Math.max(...evo.map(e => e.heures_par_semaine), 1);
            container.innerHTML = `
                <div style="font-size:12px;color:var(--text-muted);margin-bottom:6px">${escapeHtml(eleveNom)} · h/sem et % inclusion par année (base ${hEcole}h école/sem)</div>
                <div class="mini-bars">
                    ${evo.map(e => {
                        const pctH = Math.round((e.heures_par_semaine / maxH) * 100);
                        const pctIncl = Math.round(e.heures_par_semaine / hEcole * 100);
                        return `
                        <div class="mini-bar-group" title="${e.nom} : ${e.heures_par_semaine}h/sem · ${pctIncl}% · ${e.nb_semaines} sem · ${e.heures}h total">
                            <div class="mini-bar-fill" style="height:${Math.max(pctH, 4)}%;background:#2196f3">${e.heures_par_semaine > 0 ? e.heures_par_semaine + 'h' : ''}</div>
                            <div class="mini-bar-label" style="font-weight:600">${pctIncl}%</div>
                            <div class="mini-bar-label">${this._shortAnnee(e.nom)}</div>
                        </div>`;
                    }).join('')}
                </div>
                <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--text-muted);margin-top:2px">
                    <span>0h/sem</span><span>${maxH}h/sem</span>
                </div>
                <div style="margin-top:4px;font-size:11px;color:var(--text-muted)">${this._computeTrend(evo.map(e => ({ label: e.nom, value: e.heures_par_semaine })))}</div>
            `;
        } catch (e) {
            container.innerHTML = `<p style="color:var(--danger);font-size:13px">Erreur : ${escapeHtml(e.message)}</p>`;
        }
    },

    // ── Rendu évolution PAR PÉRIODE (élève) ──

    async _renderElevePeriodes(container, row) {
        const eleveId = row?.dataset?.eleveId;
        const eleveNom = row?.dataset?.eleveNom || 'Élève';
        if (!eleveId) {
            container.innerHTML = '<p style="font-size:13px;color:var(--text-muted)">Élève inconnu.</p>';
            return;
        }

        try {
            const anneeId = State.get('annee_scolaire_id') || '';
            const data = await API.get(`stats.php?section=inclusion_eleve_periodes&eleve_id=${eleveId}&annee_scolaire_id=${anneeId}`);
            const periodes = data.inclusion_eleve_periodes || [];
            if (!periodes.length) {
                container.innerHTML = '<p style="font-size:13px;color:var(--text-muted)">Aucune donnée par période.</p>';
                return;
            }

            const hEcole = this._data.inclusion?.heures_ecole_semaine || 24;
            const maxH = Math.max(...periodes.map(p => p.heures_par_semaine), 1);
            container.innerHTML = `
                <div style="font-size:12px;color:var(--text-muted);margin-bottom:6px">${escapeHtml(eleveNom)} · h/sem et % inclusion par période (base ${hEcole}h/sem école)</div>
                <div class="mini-bars">
                    ${periodes.map(p => {
                        const pctH = Math.round((p.heures_par_semaine / maxH) * 100);
                        const pctIncl = Math.round(p.heures_par_semaine / hEcole * 100);
                        return `
                        <div class="mini-bar-group" title="P${p.periode} : ${p.heures_par_semaine}h/sem · ${pctIncl}% · ${p.total_heures}h sur ${p.nb_semaines} sem">
                            <div class="mini-bar-fill" style="height:${Math.max(pctH, 4)}%;background:#4caf50">${p.heures_par_semaine > 0 ? p.heures_par_semaine + 'h' : ''}</div>
                            <div class="mini-bar-label" style="font-weight:600">${pctIncl}%</div>
                            <div class="mini-bar-label">P${p.periode}</div>
                        </div>`;
                    }).join('')}
                </div>
                <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--text-muted);margin-top:2px">
                    <span>0h/sem</span><span>${maxH}h/sem</span>
                </div>
                <div style="margin-top:4px;font-size:11px;color:var(--text-muted)">${this._computeTrend(periodes.map(p => ({ label: 'P' + p.periode, value: p.heures_par_semaine })))}</div>
            `;
        } catch (e) {
            container.innerHTML = `<p style="color:var(--danger);font-size:13px">Erreur : ${escapeHtml(e.message)}</p>`;
        }
    },

    // ── Rendu évolution PAR SEMAINE ──

    _renderEvolutionSemaines(container, section, row) {
        const semaines = this._data.inclusion_semaines;
        if (!semaines || !semaines.length) {
            container.innerHTML = '<p style="font-size:13px;color:var(--text-muted)">Données par semaine non disponibles pour cette section.</p>';
            return;
        }

        if (section === 'inclusion-eleve') {
            this._renderSemaineHeatmap(container, semaines);
        } else if (section === 'pec' || section === 'mdph' || section === 'transport' || section === 'ecoles') {
            container.innerHTML = '<p style="font-size:13px;color:var(--text-muted)">L\'évolution par semaine concerne principalement l\'inclusion. Consultez l\'onglet « Par année » pour cette section.</p>';
        } else {
            this._renderSemaineHeatmap(container, semaines);
        }
    },

    _renderSemaineHeatmap(container, semaines) {
        const scolaires = semaines.filter(s => !s.est_vacances);
        const maxH = Math.max(...semaines.map(s => s.heures_inclusion), 1);
        const totalH = scolaires.reduce((s, w) => s + w.heures_inclusion, 0);

        container.innerHTML = `
            <div class="stats-summary" style="font-size:12px;margin-top:4px">
                <span>📅 ${scolaires.length} semaines scolaires</span>
                <span>⏱️ Total ${totalH.toFixed(1)}h</span>
            </div>
            <div style="font-size:11px;color:var(--text-muted);margin-top:4px">Chaque carré = 1 semaine (survol pour le détail)</div>
            <div class="week-heatmap">
                ${semaines.map(s => {
                    const intensity = s.est_vacances ? 0 : Math.min(s.heures_inclusion / maxH, 1);
                    const r = Math.round(200 - intensity * 150);
                    const g = Math.round(200 - intensity * 180);
                    const b = Math.round(255 - intensity * 200);
                    return `<div class="week-cell ${s.est_vacances ? 'vacances' : ''}"
                        style="background:${s.est_vacances ? '' : `rgb(${r},${g},${b})`}"
                        data-tip="S${getSchoolWeekNumber(s, semaines)} : ${s.est_vacances ? 'Vacances' : s.heures_inclusion + 'h · ' + s.nb_creneaux + ' créneaux · ' + s.nb_eleves_inclus + ' élève(s)'}"
                        title="Semaine ${getSchoolWeekNumber(s, semaines)} — ${s.est_vacances ? 'Vacances' : s.heures_inclusion + 'h inclusion'}"></div>`;
                }).join('')}
            </div>
            <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--text-muted);margin-top:2px">
                <span>S1</span><span>S${scolaires.length}</span>
            </div>
            <div style="display:flex;justify-content:space-between;font-size:10px;color:var(--text-muted)">
                <span>0h</span><span>${maxH.toFixed(0)}h max</span>
            </div>
        `;
    },

    // ── Graphiques ──

    _initCharts() {
        this._drawPieChart('chart-cantine', this._data.cantine_transport);
        this._drawTransportChart('chart-transport', this._data.cantine_transport);
        this._drawEvolutionChart('chart-evolution', this._data.entrees_sorties);

        // Sections repliables
        document.querySelectorAll('.stats-section-header').forEach(hdr => {
            hdr.addEventListener('click', () => {
                const body = hdr.nextElementSibling;
                const icon = hdr.querySelector('.toggle-icon');
                if (body) {
                    body.classList.toggle('collapsed');
                    if (icon) icon.textContent = body.classList.contains('collapsed') ? '▶' : '▼';
                }
            });
        });

        // Tabs inclusion (élèves / groupe / semaines)
        document.querySelectorAll('[data-inclusion-view]').forEach(tab => {
            tab.addEventListener('click', () => {
                const view = tab.dataset.inclusionView;
                document.querySelectorAll('[data-inclusion-view]').forEach(t => t.classList.remove('active'));
                tab.classList.add('active');
                ['eleves', 'groupe', 'semaines'].forEach(v => {
                    const div = document.getElementById('inclusion-view-' + v);
                    if (div) div.style.display = view === v ? 'block' : 'none';
                });
            });
        });
    },

    _drawPieChart(canvasId, data) {
        const canvas = document.getElementById(canvasId);
        if (!canvas || !data) return;
        const ctx = canvas.getContext('2d');
        const total = data.total || 1;
        const oui = data.cantine;
        const non = total - oui;
        if (total === 0) return;

        const cx = 100, cy = 100, r = 80;
        const segments = [
            { value: oui, color: '#4caf50', label: 'Oui' + (oui > 0 ? ' ' + Math.round(oui / total * 100) + '%' : '') },
            { value: non > 0 ? non : 0, color: '#e0e0e0', label: 'Non' },
        ];

        let startAngle = -Math.PI / 2;
        ctx.clearRect(0, 0, 200, 200);
        segments.forEach(seg => {
            if (seg.value <= 0) return;
            const sweepAngle = (seg.value / total) * 2 * Math.PI;
            ctx.beginPath();
            ctx.moveTo(cx, cy);
            ctx.arc(cx, cy, r, startAngle, startAngle + sweepAngle);
            ctx.closePath();
            ctx.fillStyle = seg.color;
            ctx.fill();
            startAngle += sweepAngle;
        });

        // Centre blanc (effet donut)
        ctx.beginPath();
        ctx.arc(cx, cy, r * 0.5, 0, 2 * Math.PI);
        ctx.fillStyle = document.body.classList.contains('dark') ? '#1e1e2e' : '#fff';
        ctx.fill();

        // Texte au centre
        ctx.fillStyle = 'var(--text-color)';
        ctx.font = 'bold 16px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(Math.round(oui / total * 100) + '%', cx, cy);
    },

    _drawTransportChart(canvasId, data) {
        const canvas = document.getElementById(canvasId);
        if (!canvas || !data || !data.transport || data.transport.length === 0) return;
        const ctx = canvas.getContext('2d');
        const total = data.transport.reduce((s, t) => s + parseInt(t.nb), 0);
        if (total === 0) return;

        const colors = ['#2196f3', '#ff9800', '#4caf50', '#f44336', '#9c27b0', '#607d8b'];
        const cx = 100, cy = 100, r = 80;
        let startAngle = -Math.PI / 2;

        ctx.clearRect(0, 0, 200, 200);
        data.transport.forEach((t, i) => {
            const v = parseInt(t.nb);
            if (v <= 0) return;
            const sweepAngle = (v / total) * 2 * Math.PI;
            ctx.beginPath();
            ctx.moveTo(cx, cy);
            ctx.arc(cx, cy, r, startAngle, startAngle + sweepAngle);
            ctx.closePath();
            ctx.fillStyle = colors[i % colors.length];
            ctx.fill();
            startAngle += sweepAngle;
        });
    },

    _drawEvolutionChart(canvasId, data) {
        const canvas = document.getElementById(canvasId);
        if (!canvas || !data || !data.par_annee || data.par_annee.length < 2) return;
        const ctx = canvas.getContext('2d');
        const annees = data.par_annee.reverse(); // ordre chronologique
        const w = canvas.width, h = canvas.height;
        const pad = { top: 20, right: 20, bottom: 30, left: 40 };
        const cw = w - pad.left - pad.right;
        const ch = h - pad.top - pad.bottom;

        const values = annees.map(a => a.effectif);
        const maxVal = Math.max(...values, 1);
        const stepX = cw / (values.length - 1 || 1);

        ctx.clearRect(0, 0, w, h);

        // Grille
        ctx.strokeStyle = '#e0e0e0';
        ctx.lineWidth = 1;
        for (let i = 0; i <= 4; i++) {
            const y = pad.top + (ch / 4) * i;
            ctx.beginPath(); ctx.moveTo(pad.left, y); ctx.lineTo(w - pad.right, y); ctx.stroke();
            ctx.fillStyle = '#999';
            ctx.font = '10px sans-serif';
            ctx.textAlign = 'right';
            ctx.fillText(Math.round(maxVal - (maxVal / 4) * i), pad.left - 5, y + 3);
        }

        // Courbe
        ctx.beginPath();
        ctx.strokeStyle = '#2196f3';
        ctx.lineWidth = 2;
        values.forEach((v, i) => {
            const x = pad.left + i * stepX;
            const y = pad.top + ch - (v / maxVal) * ch;
            i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
        });
        ctx.stroke();

        // Points + labels
        values.forEach((v, i) => {
            const x = pad.left + i * stepX;
            const y = pad.top + ch - (v / maxVal) * ch;
            ctx.beginPath(); ctx.arc(x, y, 4, 0, 2 * Math.PI); ctx.fillStyle = '#2196f3'; ctx.fill();
            ctx.fillStyle = '#fff'; ctx.beginPath(); ctx.arc(x, y, 2, 0, 2 * Math.PI); ctx.fill();

            // Labels X
            ctx.fillStyle = '#999';
            ctx.font = '10px sans-serif';
            ctx.textAlign = 'center';
            const label = annees[i]?.nom || '';
            ctx.fillText(label, x, h - 5);
        });
    },
};
