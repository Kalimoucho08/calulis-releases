<?php
/** Calulis — Model Statistiques
 *  Toutes les méthodes retournent des tableaux associatifs prêts à être JSON-sérialisés.
 *  Chaque méthode prend un PDO en paramètre.
 *
 *  Les stats sont ANNUELLES (pas cumulatives sur plusieurs années).
 *  $anneeId = null → utilise l'année active.
 */
class Stats {

    // ── KPI ──

    public static function kpi(PDO $pdo, ?int $anneeId): array {
        if (!$anneeId) {
            $anneeId = (int)$pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
            if (!$anneeId) $anneeId = 1;
        }

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE annee_scolaire_id = ?');
        $stmt->execute([$anneeId]); $total = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE ulis = 1 AND annee_scolaire_id = ?');
        $stmt->execute([$anneeId]); $ulis = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE cantine = 1 AND annee_scolaire_id = ?');
        $stmt->execute([$anneeId]); $cantine = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleve_annees WHERE transport LIKE '%taxi%' AND annee_scolaire_id = ?");
        $stmt->execute([$anneeId]); $taxi = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT COUNT(DISTINCT eleve_id) FROM pec_eleves WHERE specialite IS NOT NULL AND specialite != '' AND annee_scolaire_id = ?");
        $stmt->execute([$anneeId]); $pec = (int)$stmt->fetchColumn();

        return ['total' => $total, 'ulis' => $ulis, 'cantine' => $cantine, 'taxi' => $taxi, 'pec' => $pec];
    }

    // ── Inclusion ──

    public static function inclusion(PDO $pdo, ?int $anneeId, ?int $classeId = null): array {
        if (!$anneeId) {
            $anneeId = (int)$pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
            if (!$anneeId) $anneeId = 1;
        }

        $classeJoin = '';
        $classeWhere = '';
        $params = [$anneeId];
        if ($classeId) {
            $classeJoin = 'JOIN eleve_annees ea ON ea.eleve_id = e.id AND ea.annee_scolaire_id = ?';
            $classeWhere = 'AND ea.classe_id = ?';
            $params = [$anneeId, $anneeId, $classeId];
        }

        $sql = "SELECT c.eleve_id, e.nom, e.prenom,
                       ROUND(SUM(c.duree) / 60, 1) AS total_heures,
                       COUNT(*) AS nb_creneaux
                FROM creneaux c
                JOIN eleves e ON e.id = c.eleve_id
                {$classeJoin}
                WHERE c.regroupement_type = 'INCLUSION'
                  AND c.semaine_id IN (SELECT id FROM semaines WHERE annee_scolaire_id = ?)
                  {$classeWhere}
                GROUP BY c.eleve_id ORDER BY total_heures DESC";
        $stmt = $pdo->prepare($sql); $stmt->execute($params);
        $parEleve = $stmt->fetchAll();

        $stmt2 = $pdo->prepare('SELECT COUNT(*) FROM semaines WHERE annee_scolaire_id = ? AND est_vacances = 0');
        $stmt2->execute([$anneeId]);
        $nbSemaines = (int)$stmt2->fetchColumn();
        if ($nbSemaines < 1) $nbSemaines = 1;

        $totalHeures = 0;
        foreach ($parEleve as &$pe) {
            $pe['total_heures'] = (float)$pe['total_heures'];
            $pe['heures_par_semaine'] = round($pe['total_heures'] / $nbSemaines, 1);
            $totalHeures += $pe['total_heures'];
        }

        $heuresEcoleParSemaine = self::_getHeuresEcoleSemaine($pdo);
        $nbEleves = count($parEleve);
        $totalDisponible = $heuresEcoleParSemaine * $nbSemaines * $nbEleves;

        return [
            'total_heures_annee' => round($totalHeures, 1),
            'heures_par_semaine' => round($totalHeures / $nbSemaines, 1),
            'moyenne_heures_eleve' => $nbEleves > 0 ? round($totalHeures / $nbSemaines / $nbEleves, 1) : 0,
            'nb_semaines_scolaires' => $nbSemaines,
            'heures_ecole_semaine' => $heuresEcoleParSemaine,
            'pourcentage_temps_total' => $totalDisponible > 0 ? round($totalHeures / $totalDisponible * 100, 1) : 0,
            'par_eleve' => $parEleve,
        ];
    }

    // ── PEC ──

    public static function pec(PDO $pdo, ?int $anneeId): array {
        if (!$anneeId) {
            $anneeId = (int)$pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
            if (!$anneeId) $anneeId = 1;
        }

        $stmt = $pdo->prepare("SELECT p.organisme AS pec_organisme,
                GROUP_CONCAT(DISTINCT p.specialite ORDER BY p.specialite SEPARATOR ', ') AS pec_specialites,
                COUNT(DISTINCT p.eleve_id) AS nb_eleves,
                GROUP_CONCAT(DISTINCT CONCAT(e.prenom, ' ', e.nom) ORDER BY e.nom SEPARATOR ', ') AS eleves_noms
            FROM pec_eleves p
            JOIN eleves e ON e.id = p.eleve_id
            WHERE p.specialite IS NOT NULL AND p.specialite != '' AND p.annee_scolaire_id = ?
            GROUP BY p.organisme
            ORDER BY nb_eleves DESC");
        $stmt->execute([$anneeId]);
        $parSpecialite = $stmt->fetchAll();
        $total = 0;
        foreach ($parSpecialite as $ps) $total += (int)$ps['nb_eleves'];
        return ['total_avec_pec' => $total, 'par_specialite' => $parSpecialite];
    }

    // ── Cantine & Transport ──

    public static function cantineTransport(PDO $pdo, ?int $anneeId): array {
        if (!$anneeId) {
            $anneeId = (int)$pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
            if (!$anneeId) $anneeId = 1;
        }

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE annee_scolaire_id = ?');
        $stmt->execute([$anneeId]); $total = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleve_annees WHERE cantine = 1 AND annee_scolaire_id = ?");
        $stmt->execute([$anneeId]); $cantine = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT transport, COUNT(*) AS nb FROM eleve_annees WHERE transport != '' AND transport IS NOT NULL AND annee_scolaire_id = ? GROUP BY transport ORDER BY nb DESC");
        $stmt->execute([$anneeId]); $transport = $stmt->fetchAll();

        return ['total' => $total, 'cantine' => $cantine, 'cantine_pourcent' => $total > 0 ? round($cantine / $total * 100, 1) : 0, 'transport' => $transport];
    }

    // ── MDPH ──

    public static function mdph(PDO $pdo, ?int $anneeId): array {
        $types = ['ULIS' => 'mdph_ulis', 'AESH' => 'mdph_aesh', 'Transport' => 'mdph_transport', 'SESSAD' => 'mdph_sessad', 'Autre' => 'mdph_autre'];
        $result = [];
        foreach ($types as $label => $prefix) {
            $sf = "{$prefix}_statut"; $df = "{$prefix}_date_fin";
            $cond = $anneeId ? ' AND id IN (SELECT eleve_id FROM eleve_annees WHERE annee_scolaire_id = ?)' : '';

            $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleves WHERE {$sf} IS NOT NULL AND {$sf} != ''{$cond}");
            $stmt->execute($anneeId ? [$anneeId] : []); $notifies = (int)$stmt->fetchColumn();

            $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleves WHERE {$sf} IS NOT NULL AND {$sf} != '' AND {$df} BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 90 DAY){$cond}");
            $stmt->execute($anneeId ? [$anneeId] : []); $echeance = (int)$stmt->fetchColumn();

            $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleves WHERE {$sf} IS NOT NULL AND {$sf} != '' AND {$df} < CURDATE(){$cond}");
            $stmt->execute($anneeId ? [$anneeId] : []); $expires = (int)$stmt->fetchColumn();

            $result[$label] = ['notifies' => $notifies, 'echeance' => $echeance, 'expires' => $expires];
        }
        return $result;
    }

    // ── Ancienneté ──

    public static function anciennete(PDO $pdo, ?int $anneeId): array {
        // Ancienneté alignée sur le per-élève (v1.11) : mois calendaires depuis date_entree_ulis (aujourd'hui).
        // Périmètre : élèves ayant une affectation (cumulée jusqu'à $anneeId si fourni, sinon toutes).
        $sql = 'SELECT e.id AS eleve_id, e.date_entree_ulis'
                . ' FROM eleves e'
                . ' JOIN eleve_annees ea ON ea.eleve_id = e.id'
                . ($anneeId ? ' WHERE ea.annee_scolaire_id <= ?' : '')
                . ' GROUP BY e.id';
        $stmt = $anneeId ? $pdo->prepare($sql) : $pdo->query($sql);
        if ($anneeId) $stmt->execute([$anneeId]);
        $rows = $stmt->fetchAll();

        $total = count($rows);
        $avecDate = 0;
        $sumMois = 0;
        $parEleve = [];
        $repartition = ['moins1' => 0, 1 => 0, 2 => 0, 3 => 0, '4plus' => 0];
        $today = new DateTime(date('Y-m-d'));

        foreach ($rows as $r) {
            if (empty($r['date_entree_ulis'])) continue;
            $entree = new DateTime($r['date_entree_ulis']);
            $mois = ((int)$today->format('Y') - (int)$entree->format('Y')) * 12
                  + ((int)$today->format('n') - (int)$entree->format('n'));
            if ((int)$today->format('j') < (int)$entree->format('j')) $mois--;
            $mois = max(0, $mois);

            $avecDate++;
            $sumMois += $mois;
            $parEleve[] = ['eleve_id' => (int)$r['eleve_id'], 'mois' => $mois];

            $ans = intdiv($mois, 12);
            if ($ans === 0) $repartition['moins1']++;
            elseif ($ans === 1) $repartition[1]++;
            elseif ($ans === 2) $repartition[2]++;
            elseif ($ans === 3) $repartition[3]++;
            else $repartition['4plus']++;
        }

        $moyenneMois = $avecDate > 0 ? (int)round($sumMois / $avecDate) : 0;
        $moyenne = $avecDate > 0 ? self::_fmtMois($moyenneMois) : '—';

        return [
            'total' => $total,
            'total_avec_date' => $avecDate,
            'moyenne_mois' => $moyenneMois,
            'moyenne' => $moyenne,
            'repartition' => $repartition,
            'par_eleve' => $parEleve,
        ];
    }

    /** Formate un nombre de mois en « X an(s) et Y mois » (aligné sur _fmtAnneesUlis du front). */
    private static function _fmtMois(int $mois): string {
        if ($mois <= 0) return '0 mois';
        $ans = intdiv($mois, 12);
        $reste = $mois % 12;
        $ansTxt = $ans > 0 ? $ans . ' an' . ($ans > 1 ? 's' : '') : '';
        $moisTxt = $reste > 0 ? $reste . ' mois' : '';
        if ($ansTxt !== '' && $moisTxt !== '') return $ansTxt . ' et ' . $moisTxt;
        return $ansTxt !== '' ? $ansTxt : $moisTxt;
    }

    // ── Écoles d'origine ──

    public static function ecolesOrigine(PDO $pdo, ?int $anneeId): array {
        if (!$anneeId) {
            $anneeId = (int)$pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
            if (!$anneeId) $anneeId = 1;
        }

        $sql = 'SELECT et.id AS ecole_origine_id, et.nom AS ecole_nom, et.type AS ecole_type, COUNT(DISTINCT ea.eleve_id) AS nb_eleves
                FROM eleve_annees ea
                JOIN eleves e ON e.id = ea.eleve_id
                LEFT JOIN etablissements et ON et.id = e.ecole_origine_id
                WHERE e.ecole_origine_id IS NOT NULL AND ea.annee_scolaire_id = ?
                GROUP BY et.id ORDER BY nb_eleves DESC';
        $stmt = $pdo->prepare($sql); $stmt->execute([$anneeId]);
        return ['ecoles' => $stmt->fetchAll()];
    }

    // ── Entrées / Sorties ──

    public static function entreesSorties(PDO $pdo, ?int $anneeId): array {
        $annees = $pdo->query('SELECT id, nom, date_debut, date_fin FROM annees_scolaires ORDER BY date_debut DESC LIMIT 5')->fetchAll();
        $result = ['par_annee' => []];
        foreach ($annees as $a) {
            $aid = (int)$a['id'];
            $s1 = $pdo->prepare("SELECT COUNT(*) FROM eleves WHERE date_entree_ulis BETWEEN ? AND ?");
            $s1->execute([$a['date_debut'], $a['date_fin']]); $entrees = (int)$s1->fetchColumn();

            $s2 = $pdo->prepare("SELECT COUNT(*) FROM eleves WHERE date_sortie_ulis BETWEEN ? AND ?");
            $s2->execute([$a['date_debut'], $a['date_fin']]); $sorties = (int)$s2->fetchColumn();

            $s3 = $pdo->prepare("SELECT COUNT(*) FROM eleve_annees WHERE annee_scolaire_id = ?");
            $s3->execute([$aid]); $effectif = (int)$s3->fetchColumn();

            $result['par_annee'][] = ['annee_id' => $aid, 'nom' => $a['nom'], 'entrees' => $entrees, 'sorties' => $sorties, 'effectif' => $effectif];
        }
        return $result;
    }

    // ── Évolution multi-année ──

    public static function evolution(PDO $pdo, ?int $currentAnneeId): array {
        $annees = $pdo->query('SELECT id, nom, date_debut, date_fin FROM annees_scolaires ORDER BY date_debut')->fetchAll();
        if (empty($annees)) return ['par_annee' => [], 'pec_par_annee' => [], 'ecoles_par_annee' => []];

        $parAnnee = [];
        $pecParAnnee = [];
        $ecolesParAnnee = [];

        foreach ($annees as $a) {
            $aid = (int)$a['id'];

            // KPI
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE annee_scolaire_id = ?');
            $stmt->execute([$aid]); $total = (int)$stmt->fetchColumn();

            $stmt = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE ulis = 1 AND annee_scolaire_id = ?');
            $stmt->execute([$aid]); $ulis = (int)$stmt->fetchColumn();

            $stmt = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE cantine = 1 AND annee_scolaire_id = ?');
            $stmt->execute([$aid]); $cantine = (int)$stmt->fetchColumn();

            $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleve_annees WHERE transport LIKE '%taxi%' AND annee_scolaire_id = ?");
            $stmt->execute([$aid]); $taxi = (int)$stmt->fetchColumn();

            $stmt = $pdo->prepare("SELECT COUNT(DISTINCT eleve_id) FROM pec_eleves WHERE specialite IS NOT NULL AND specialite != '' AND annee_scolaire_id = ?");
            $stmt->execute([$aid]); $pec = (int)$stmt->fetchColumn();

            // Inclusion heures
            $stmt = $pdo->prepare("SELECT ROUND(SUM(c.duree) / 60, 1) FROM creneaux c
                WHERE c.regroupement_type = 'INCLUSION'
                  AND c.semaine_id IN (SELECT id FROM semaines WHERE annee_scolaire_id = ?)");
            $stmt->execute([$aid]); $inclusionHeures = (float)($stmt->fetchColumn() ?: 0);

            // MDPH
            $mdphTotal = 0;
            $mdphExpires = 0;
            $types = ['ulis', 'aesh', 'transport', 'sessad', 'autre'];
            foreach ($types as $t) {
                $sf = "mdph_{$t}_statut";
                $df = "mdph_{$t}_date_fin";
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleves e
                    JOIN eleve_annees ea ON ea.eleve_id = e.id AND ea.annee_scolaire_id = ?
                    WHERE e.{$sf} IS NOT NULL AND e.{$sf} != ''");
                $stmt->execute([$aid]); $mdphTotal += (int)$stmt->fetchColumn();

                $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleves e
                    JOIN eleve_annees ea ON ea.eleve_id = e.id AND ea.annee_scolaire_id = ?
                    WHERE e.{$sf} IS NOT NULL AND e.{$sf} != '' AND e.{$df} < CURDATE()");
                $stmt->execute([$aid]); $mdphExpires += (int)$stmt->fetchColumn();
            }

            // Entrées / Sorties
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleves WHERE date_entree_ulis BETWEEN ? AND ?");
            $stmt->execute([$a['date_debut'], $a['date_fin']]); $entrees = (int)$stmt->fetchColumn();

            $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleves WHERE date_sortie_ulis BETWEEN ? AND ?");
            $stmt->execute([$a['date_debut'], $a['date_fin']]); $sorties = (int)$stmt->fetchColumn();

            $parAnnee[] = [
                'annee_id' => $aid, 'nom' => $a['nom'], 'total' => $total, 'ulis' => $ulis,
                'cantine' => $cantine, 'taxi' => $taxi, 'pec' => $pec,
                'inclusion_heures' => $inclusionHeures, 'mdph_total' => $mdphTotal,
                'mdph_expires' => $mdphExpires, 'entrees' => $entrees, 'sorties' => $sorties,
            ];

            // PEC par spécialité
            $stmtPec = $pdo->prepare("SELECT specialite AS pec_specialite, COUNT(DISTINCT eleve_id) AS nb
                FROM pec_eleves WHERE specialite IS NOT NULL AND specialite != '' AND annee_scolaire_id = ?
                GROUP BY specialite");
            $stmtPec->execute([$aid]);
            foreach ($stmtPec->fetchAll() as $row) {
                $spec = $row['pec_specialite'];
                if (!isset($pecParAnnee[$spec])) $pecParAnnee[$spec] = [];
                $pecParAnnee[$spec][$aid] = (int)$row['nb'];
            }

            // Écoles d'origine
            $stmtEco = $pdo->prepare("SELECT et.nom AS ecole_nom, COUNT(DISTINCT ea.eleve_id) AS nb
                FROM eleve_annees ea
                JOIN eleves e ON e.id = ea.eleve_id
                LEFT JOIN etablissements et ON et.id = e.ecole_origine_id
                WHERE e.ecole_origine_id IS NOT NULL AND ea.annee_scolaire_id = ?
                GROUP BY et.id ORDER BY nb DESC");
            $stmtEco->execute([$aid]);
            foreach ($stmtEco->fetchAll() as $row) {
                $nom = $row['ecole_nom'] ?: 'Inconnue';
                if (!isset($ecolesParAnnee[$nom])) $ecolesParAnnee[$nom] = [];
                $ecolesParAnnee[$nom][$aid] = (int)$row['nb'];
            }
        }

        // Formater PEC
        $pecFormatted = [];
        foreach ($pecParAnnee as $spec => $byAnnee) {
            $values = [];
            foreach ($annees as $a) {
                $values[] = ['annee_id' => (int)$a['id'], 'nom' => $a['nom'], 'nb' => $byAnnee[(int)$a['id']] ?? 0];
            }
            $pecFormatted[] = ['specialite' => $spec, 'values' => $values];
        }

        // Formater Écoles
        $ecolesFormatted = [];
        foreach ($ecolesParAnnee as $nom => $byAnnee) {
            $values = [];
            foreach ($annees as $a) {
                $values[] = ['annee_id' => (int)$a['id'], 'nom' => $a['nom'], 'nb' => $byAnnee[(int)$a['id']] ?? 0];
            }
            $ecolesFormatted[] = ['ecole_nom' => $nom, 'values' => $values];
        }

        return [
            'par_annee' => $parAnnee,
            'pec_par_annee' => $pecFormatted,
            'ecoles_par_annee' => $ecolesFormatted,
        ];
    }

    // ── Inclusion par semaine ──

    public static function inclusionParSemaine(PDO $pdo, ?int $anneeId): array {
        if (!$anneeId) {
            $anneeId = (int)$pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
            if (!$anneeId) $anneeId = 1;
        }

        $stmt = $pdo->prepare('SELECT id, numero, date_debut, date_fin, est_vacances FROM semaines WHERE annee_scolaire_id = ? ORDER BY numero');
        $stmt->execute([$anneeId]);
        $semaines = $stmt->fetchAll();

        $result = [];
        foreach ($semaines as $s) {
            $sid = (int)$s['id'];
            $vacances = (bool)$s['est_vacances'];

            if ($vacances) {
                $result[] = ['numero' => (int)$s['numero'], 'date_debut' => $s['date_debut'], 'est_vacances' => true, 'heures_inclusion' => 0, 'nb_creneaux' => 0, 'nb_eleves_inclus' => 0];
                continue;
            }

            $stmt2 = $pdo->prepare("SELECT ROUND(SUM(c.duree) / 60, 1) AS heures, COUNT(*) AS nb_creneaux, COUNT(DISTINCT c.eleve_id) AS nb_eleves FROM creneaux c WHERE c.regroupement_type = 'INCLUSION' AND c.semaine_id = ?");
            $stmt2->execute([$sid]);
            $row = $stmt2->fetch();

            $result[] = ['numero' => (int)$s['numero'], 'date_debut' => $s['date_debut'], 'est_vacances' => false, 'heures_inclusion' => (float)($row['heures'] ?? 0), 'nb_creneaux' => (int)($row['nb_creneaux'] ?? 0), 'nb_eleves_inclus' => (int)($row['nb_eleves'] ?? 0)];
        }

        return $result;
    }

    // ── Inclusion par élève × année ──

    public static function inclusionEleveEvolution(PDO $pdo, int $eleveId): array {
        $annees = $pdo->query('SELECT id, nom FROM annees_scolaires ORDER BY date_debut')->fetchAll();

        $result = [];
        foreach ($annees as $a) {
            $aid = (int)$a['id'];

            $stmt = $pdo->prepare("SELECT ROUND(SUM(c.duree) / 60, 1) AS heures, COUNT(*) AS nb_creneaux
                FROM creneaux c
                JOIN semaines s ON s.id = c.semaine_id
                WHERE c.regroupement_type = 'INCLUSION'
                  AND c.eleve_id = ?
                  AND s.annee_scolaire_id = ?");
            $stmt->execute([$eleveId, $aid]);
            $row = $stmt->fetch();
            $heures = (float)($row['heures'] ?? 0);

            $stmtNs = $pdo->prepare('SELECT COUNT(*) FROM semaines WHERE annee_scolaire_id = ? AND est_vacances = 0');
            $stmtNs->execute([$aid]);
            $nbSemaines = max((int)$stmtNs->fetchColumn(), 1);

            $result[] = ['annee_id' => $aid, 'nom' => $a['nom'], 'heures' => $heures, 'heures_par_semaine' => round($heures / $nbSemaines, 1), 'nb_creneaux' => (int)($row['nb_creneaux'] ?? 0), 'nb_semaines' => $nbSemaines];
        }

        return $result;
    }

    // ── Inclusion par élève × périodes ──

    public static function inclusionElevePeriodes(PDO $pdo, ?int $anneeId, int $eleveId): array {
        if (!$anneeId) {
            $anneeId = (int)$pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
            if (!$anneeId) $anneeId = 1;
        }

        $periodes = self::_getPeriodes($pdo, $anneeId);
        $result = [];

        foreach ($periodes as $num => $semaineIds) {
            if (empty($semaineIds)) continue;
            $placeholders = implode(',', array_fill(0, count($semaineIds), '?'));

            $sql = "SELECT ROUND(SUM(c.duree) / 60, 1) AS total_heures, COUNT(*) AS nb_creneaux
                    FROM creneaux c
                    WHERE c.regroupement_type = 'INCLUSION'
                      AND c.eleve_id = ?
                      AND c.semaine_id IN ($placeholders)";
            $params = array_merge([$eleveId], $semaineIds);
            $stmt = $pdo->prepare($sql); $stmt->execute($params);
            $row = $stmt->fetch();

            $total = (float)($row['total_heures'] ?? 0);
            $nbSemaines = count($semaineIds);

            $result[] = ['periode' => $num, 'nb_semaines' => $nbSemaines, 'total_heures' => $total, 'heures_par_semaine' => $nbSemaines > 0 ? round($total / $nbSemaines, 1) : 0, 'nb_creneaux' => (int)($row['nb_creneaux'] ?? 0)];
        }
        return $result;
    }

    // ── Inclusion tous élèves × périodes ──

    public static function inclusionTousElevesPeriodes(PDO $pdo, ?int $anneeId): array {
        if (!$anneeId) {
            $anneeId = (int)$pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
            if (!$anneeId) $anneeId = 1;
        }

        $periodes = self::_getPeriodes($pdo, $anneeId);
        $result = [];

        foreach ($periodes as $num => $semaineIds) {
            if (empty($semaineIds)) continue;
            $placeholders = implode(',', array_fill(0, count($semaineIds), '?'));

            $sql = "SELECT c.eleve_id,
                           ROUND(SUM(c.duree) / 60, 1) AS total_heures,
                           COUNT(*) AS nb_creneaux
                    FROM creneaux c
                    WHERE c.regroupement_type = 'INCLUSION'
                      AND c.semaine_id IN ($placeholders)
                    GROUP BY c.eleve_id";
            $stmt = $pdo->prepare($sql); $stmt->execute($semaineIds);
            $rows = $stmt->fetchAll();

            $nbSemaines = count($semaineIds);

            foreach ($rows as $row) {
                $eid = (int)$row['eleve_id'];
                if (!isset($result[$eid])) $result[$eid] = [];
                $result[$eid][] = [
                    'periode' => $num, 'nb_semaines' => $nbSemaines,
                    'total_heures' => (float)$row['total_heures'],
                    'heures_par_semaine' => $nbSemaines > 0 ? round((float)$row['total_heures'] / $nbSemaines, 1) : 0,
                    'nb_creneaux' => (int)$row['nb_creneaux'],
                ];
            }
        }

        return $result;
    }

    // ── Inclusion par groupe/classe ──

    public static function inclusionGroupe(PDO $pdo, ?int $anneeId, ?int $classeId): array {
        if (!$anneeId) {
            $anneeId = (int)$pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
            if (!$anneeId) $anneeId = 1;
        }

        if ($classeId) {
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE annee_scolaire_id = ? AND classe_id = ?');
            $stmt->execute([$anneeId, $classeId]);
            $effectif = (int)$stmt->fetchColumn();
            $stmtNom = $pdo->prepare('SELECT nom FROM classes WHERE id = ?');
            $stmtNom->execute([$classeId]);
            $nomGroupe = $stmtNom->fetchColumn() ?: 'Groupe';
        } else {
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE annee_scolaire_id = ?');
            $stmt->execute([$anneeId]);
            $effectif = (int)$stmt->fetchColumn();
            $nomGroupe = 'ULIS entière';
        }

        if ($effectif === 0) {
            return ['nom_groupe' => $nomGroupe, 'effectif' => 0, 'total_heures_annee' => 0, 'heures_par_semaine' => 0, 'pourcentage_inclusion' => 0, 'par_periode' => [], 'par_annee' => []];
        }

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM semaines WHERE annee_scolaire_id = ? AND est_vacances = 0');
        $stmt->execute([$anneeId]);
        $nbSemaines = max((int)$stmt->fetchColumn(), 1);

        $heuresEcole = self::_getHeuresEcoleSemaine($pdo);
        $heuresDispoAnnee = $heuresEcole * $nbSemaines * $effectif;

        $classeJoin = '';
        $classeWhere = '';
        $params = [$anneeId];
        if ($classeId) {
            $classeJoin = 'JOIN eleve_annees ea ON ea.eleve_id = c.eleve_id AND ea.annee_scolaire_id = ?';
            $classeWhere = 'AND ea.classe_id = ?';
            $params = [$anneeId, $anneeId, $classeId];
        }

        $sql = "SELECT ROUND(SUM(c.duree) / 60, 1) AS total_heures, COUNT(*) AS nb_creneaux, COUNT(DISTINCT c.eleve_id) AS nb_eleves_inclus
                FROM creneaux c {$classeJoin}
                WHERE c.regroupement_type = 'INCLUSION'
                  AND c.semaine_id IN (SELECT id FROM semaines WHERE annee_scolaire_id = ?) {$classeWhere}";
        $stmt = $pdo->prepare($sql); $stmt->execute($params);
        $row = $stmt->fetch();
        $totalHeures = (float)($row['total_heures'] ?? 0);
        $heuresParSemaine = round($totalHeures / $nbSemaines, 1);
        $pourcentInclusion = $heuresDispoAnnee > 0 ? round($totalHeures / $heuresDispoAnnee * 100, 1) : 0;

        // Par période
        $periodes = self::_getPeriodes($pdo, $anneeId);
        $parPeriode = [];
        foreach ($periodes as $num => $semaineIds) {
            if (empty($semaineIds)) continue;
            $placeholders = implode(',', array_fill(0, count($semaineIds), '?'));
            $periodeParams = $classeId ? array_merge([$anneeId, $classeId], $semaineIds) : $semaineIds;
            $periodeJoin = $classeId ? 'JOIN eleve_annees ea ON ea.eleve_id = c.eleve_id AND ea.annee_scolaire_id = ? AND ea.classe_id = ?' : '';

            $sqlP = "SELECT ROUND(SUM(c.duree) / 60, 1) AS total_heures, COUNT(*) AS nb_creneaux
                     FROM creneaux c {$periodeJoin}
                     WHERE c.regroupement_type = 'INCLUSION' AND c.semaine_id IN ($placeholders)";
            $stmtP = $pdo->prepare($sqlP); $stmtP->execute($periodeParams);
            $rowP = $stmtP->fetch();
            $totalP = (float)($rowP['total_heures'] ?? 0);
            $nbSemP = count($semaineIds);
            $heuresDispoP = $heuresEcole * $nbSemP * $effectif;

            $parPeriode[] = ['periode' => $num, 'nb_semaines' => $nbSemP, 'total_heures' => $totalP, 'heures_par_semaine' => $nbSemP > 0 ? round($totalP / $nbSemP, 1) : 0, 'pourcentage_inclusion' => $heuresDispoP > 0 ? round($totalP / $heuresDispoP * 100, 1) : 0, 'nb_creneaux' => (int)($rowP['nb_creneaux'] ?? 0)];
        }

        // Par année (historique)
        $annees = $pdo->query('SELECT id, nom, date_debut, date_fin FROM annees_scolaires ORDER BY date_debut')->fetchAll();
        $parAnnee = [];
        foreach ($annees as $a) {
            $aid = (int)$a['id'];

            if ($classeId) {
                $stmtEff = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE annee_scolaire_id = ? AND classe_id = ?');
                $stmtEff->execute([$aid, $classeId]);
                $effAnnee = (int)$stmtEff->fetchColumn();
            } else {
                $stmtEff = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE annee_scolaire_id = ?');
                $stmtEff->execute([$aid]);
                $effAnnee = (int)$stmtEff->fetchColumn();
            }

            $stmtNs = $pdo->prepare('SELECT COUNT(*) FROM semaines WHERE annee_scolaire_id = ? AND est_vacances = 0');
            $stmtNs->execute([$aid]);
            $nbSemAnnee = max((int)$stmtNs->fetchColumn(), 1);

            $heuresDispoAnneeA = $heuresEcole * $nbSemAnnee * $effAnnee;

            $paramsA = [$aid];
            $joinA = '';
            $whereA = '';
            if ($classeId) {
                $joinA = 'JOIN eleve_annees ea ON ea.eleve_id = c.eleve_id AND ea.annee_scolaire_id = ?';
                $whereA = 'AND ea.classe_id = ?';
                $paramsA = [$aid, $aid, $classeId];
            }

            $sqlA = "SELECT ROUND(SUM(c.duree) / 60, 1) AS total_heures
                     FROM creneaux c {$joinA}
                     WHERE c.regroupement_type = 'INCLUSION'
                       AND c.semaine_id IN (SELECT id FROM semaines WHERE annee_scolaire_id = ?) {$whereA}";
            $stmtA = $pdo->prepare($sqlA); $stmtA->execute($paramsA);
            $totalA = (float)($stmtA->fetchColumn() ?: 0);

            $parAnnee[] = ['annee_id' => $aid, 'nom' => $a['nom'], 'effectif' => $effAnnee, 'nb_semaines' => $nbSemAnnee, 'total_heures' => $totalA, 'heures_par_semaine' => round($totalA / $nbSemAnnee, 1), 'pourcentage_inclusion' => $heuresDispoAnneeA > 0 ? round($totalA / $heuresDispoAnneeA * 100, 1) : 0];
        }

        return ['nom_groupe' => $nomGroupe, 'effectif' => $effectif, 'nb_semaines_scolaires' => $nbSemaines, 'heures_ecole_semaine' => $heuresEcole, 'total_heures_annee' => $totalHeures, 'heures_par_semaine' => $heuresParSemaine, 'pourcentage_inclusion' => $pourcentInclusion, 'par_periode' => $parPeriode, 'par_annee' => $parAnnee];
    }

    // ── Inclusion par période (global) ──

    public static function inclusionPeriodes(PDO $pdo, ?int $anneeId): array {
        if (!$anneeId) {
            $anneeId = (int)$pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
            if (!$anneeId) $anneeId = 1;
        }

        $periodes = self::_getPeriodes($pdo, $anneeId);
        $result = [];

        foreach ($periodes as $num => $semaineIds) {
            if (empty($semaineIds)) continue;
            $placeholders = implode(',', array_fill(0, count($semaineIds), '?'));

            $sql = "SELECT ROUND(SUM(c.duree) / 60, 1) AS total_heures, COUNT(*) AS nb_creneaux
                    FROM creneaux c
                    WHERE c.regroupement_type = 'INCLUSION'
                      AND c.semaine_id IN ($placeholders)";
            $stmt = $pdo->prepare($sql); $stmt->execute($semaineIds);
            $row = $stmt->fetch();

            $total = (float)($row['total_heures'] ?? 0);
            $nbSemaines = count($semaineIds);

            $result[] = ['periode' => $num, 'nb_semaines' => $nbSemaines, 'total_heures' => $total, 'heures_par_semaine' => $nbSemaines > 0 ? round($total / $nbSemaines, 1) : 0, 'nb_creneaux' => (int)($row['nb_creneaux'] ?? 0)];
        }
        return $result;
    }

    // ── Helpers privés ──

    /** Heures école / semaine depuis paramètres */
    private static function _getHeuresEcoleSemaine(PDO $pdo): float {
        $heuresParJour = 6;
        $nbJours = 4;

        try {
            $stmt = $pdo->prepare("SELECT valeur FROM parametres WHERE cle = 'horaires'");
            $stmt->execute();
            $horaires = json_decode($stmt->fetchColumn(), true);

            if ($horaires && !empty($horaires['debut']) && !empty($horaires['fin'])) {
                if (!empty($horaires['fin_matin']) && !empty($horaires['debut_aprem'])) {
                    $debutMatin = strtotime($horaires['debut']);
                    $finMatin = strtotime($horaires['fin_matin']);
                    $debutAprem = strtotime($horaires['debut_aprem']);
                    $finAprem = strtotime($horaires['fin']);
                    $heuresParJour = ($finMatin - $debutMatin + $finAprem - $debutAprem) / 3600;
                } else {
                    $debut = strtotime($horaires['debut']);
                    $fin = strtotime($horaires['fin']);
                    $heuresParJour = ($fin - $debut) / 3600;
                    if ($heuresParJour >= 8) $heuresParJour -= 2;
                }
            }

            $stmt = $pdo->prepare("SELECT valeur FROM parametres WHERE cle = 'jours_affiches'");
            $stmt->execute();
            $jours = json_decode($stmt->fetchColumn(), true);
            if (is_array($jours) && count($jours) > 0) {
                $nbJours = count($jours);
            }
        } catch (\Throwable $e) {
            // fallback sur les valeurs par défaut
        }

        return (float)($heuresParJour * $nbJours);
    }

    /** Détecte les blocs de semaines scolaires séparés par des vacances */
    private static function _getPeriodes(PDO $pdo, int $anneeId): array {
        $stmt = $pdo->prepare('SELECT id, numero, est_vacances FROM semaines WHERE annee_scolaire_id = ? ORDER BY numero');
        $stmt->execute([$anneeId]);
        $semaines = $stmt->fetchAll();

        $periodes = [];
        $periode = 0;
        $inPeriode = false;

        foreach ($semaines as $s) {
            if (!$s['est_vacances']) {
                if (!$inPeriode) { $periode++; $periodes[$periode] = []; $inPeriode = true; }
                $periodes[$periode][] = (int)$s['id'];
            } else {
                $inPeriode = false;
            }
        }
        return $periodes;
    }
}
