<?php
/**
 * Calulis — Configuration base de données
 * Prod : lit les variables d'environnement
 * Local : MySQL 8.0 (TCP 127.0.0.1:3307)
 * Cible = MySQL 8.0 (binaire embarqué du stack portable).
 */

// Sécurité : ne pas exposer les erreurs en production
if (!in_array($_SERVER['REMOTE_ADDR'] ?? '', ['127.0.0.1', '::1', 'localhost'], true)) {
    @ini_set('display_errors', '0');
    @ini_set('log_errors', '1');
}

// Détection automatique de l'environnement
$isProd = strpos($_SERVER['HTTP_HOST'] ?? '', 'infinityfree.com') !== false
       || strpos($_SERVER['HTTP_HOST'] ?? '', 'free.nf') !== false
       || getenv('CALULIS_ENV') === 'production';

if ($isProd) {
    $dbHost = getenv('CALULIS_DB_HOST');
    $dbName = getenv('CALULIS_DB_NAME');
    $dbUser = getenv('CALULIS_DB_USER');
    $dbPass = getenv('CALULIS_DB_PASS');
    if (!$dbHost || !$dbName || !$dbUser) {
        http_response_code(500);
        header('Content-Type: application/json');
        echo json_encode(['error' => 'Configuration base de données manquante. Définir CALULIS_DB_HOST, CALULIS_DB_NAME, CALULIS_DB_USER.']);
        exit;
    }
    $dsn = "mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4";
} else {
    // Mode développement — cible MySQL 8.0 (binaire embarqué du stack portable, port 3307)
    $dbHost = getenv('CALULIS_DB_HOST') ?: '127.0.0.1';
    $dbName = getenv('CALULIS_DB_NAME') ?: 'calulis';
    $dbUser = getenv('CALULIS_DB_USER') ?: 'calulis';
    $dbPass = getenv('CALULIS_DB_PASS') ?: 'calulis';
    $dbPort = getenv('CALULIS_DB_PORT') ?: '3307';
    $dsn = "mysql:host={$dbHost};port={$dbPort};dbname={$dbName};charset=utf8mb4";
}

define('USE_MYSQL', true);
define('DB_DSN', $dsn);
define('DB_USER', $dbUser);
define('DB_PASS', $dbPass);

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(DB_DSN, DB_USER, DB_PASS, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }
    return $pdo;
}

function jsonResponse(mixed $data, int $code = 200): never {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function jsonError(string $message, int $code = 400): never {
    jsonResponse(['error' => $message], $code);
}

// ─────────────────────────────────────────────────────────────
// Helpers partagés : erreurs TOUJOURS journalisées + lisibles,
// et troncature défensive des champs varchar courts (anti
// « data too long » qui donnait des erreurs de sauvegarde).
// ─────────────────────────────────────────────────────────────

/** Limites varchar connues (colonnes courtes du schéma) */
const CALULIS_VARCHAR_LIMITS = [
    'ine' => 15, 'classe' => 20, 'niveau_scolaire' => 20, 'aesh_type' => 10,
    'aesh_heures' => 20, 'groupe' => 50, 'temps_scolarisation' => 30,
    'telephone' => 20, 'telephone_urgence' => 20, 'telephone2' => 20,
    'uai' => 8, 'code_postal' => 10, 'departement' => 50,
    'numero_dossier_mdph' => 50, 'numero_dossier' => 50,
    'ase_structure_telephone' => 20, 'ase_referent_telephone' => 20,
    'fonction' => 50, 'role' => 50, 'civilite' => 10, 'lien' => 50,
    'specialite' => 100, 'pec_specialite' => 50, 'pec_organisme' => 50,
    'pec_frequence' => 30, 'pec_lieu' => 50, 'pec_duree' => 20,
];

/** Tronque les champs varchar courts (défensif — jamais d'erreur « data too long ») */
function calulis_truncate(array $data): array {
    foreach (CALULIS_VARCHAR_LIMITS as $f => $len) {
        if (array_key_exists($f, $data) && $data[$f] !== null && $data[$f] !== '') {
            $data[$f] = mb_substr((string)$data[$f], 0, $len);
        }
    }
    return $data;
}

/** Journalise une erreur et répond un message propre (jamais de SQL brut) */
function calulis_handle_error(\Throwable $e): never {
    if (function_exists('calulis_log_error')) {
        calulis_log_error('EXCEPTION ' . get_class($e) . ': ' . $e->getMessage()
            . ' @ ' . $e->getFile() . ':' . $e->getLine());
    } else {
        @error_log('[calulis] ' . get_class($e) . ': ' . $e->getMessage());
    }
    if ($e instanceof \PDOException) {
        jsonError("Les données n'ont pas pu être enregistrées (erreur de base de données). Vérifie les champs saisis puis réessaie. Si le problème persiste, redémarre l'application.", 500);
    }
    jsonError('Erreur technique. Le détail est enregistré dans les logs (bouton « Ouvrir les logs » du lanceur).', 500);
}

/**
 * Auto-réparation du schéma DB : applique les migrations en attente une seule fois par processus.
 *
 * Appelée au démarrage (router.php en prod / dev-router.php en dev), elle garantit que les tables
 * créées par migration (classe_enseignants, groupes, eleve_groupes) existent sur TOUTE base —
 * perso, démo ou vierge, existante ou fraîche — quel que soit son état de schéma au chargement.
 * C'est le mécanisme qui réaligne TOUTES les bases sur le même schéma canonique.
 *
 * Idempotent : si tout est déjà à jour (aucune migration en attente), c'est un simple statut sans effet.
 * En cas d'erreur, on journalise et on continue (ne bloque pas l'API).
 */
function calulis_auto_migrate(): void {
    static $ran = false;
    if ($ran) { return; }
    $ran = true;
    try {
        $migrationFile = __DIR__ . '/models/Migration.php';
        if (!file_exists($migrationFile)) { return; }
        require_once $migrationFile;
        (new Migration())->run();
    } catch (\Throwable $e) {
        @error_log('[calulis] auto-migration: ' . $e->getMessage());
    }
}
