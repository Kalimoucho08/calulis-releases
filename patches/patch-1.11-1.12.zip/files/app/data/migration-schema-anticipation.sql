-- Calulis — Anticipation schéma (v1 portable)
-- Ajoute toutes les tables et colonnes imaginables pour les besoins futurs.
-- Objectif : zéro migration de schéma après la v1 portable.
-- Date : 2026-07-01

-- ⚠️ MySQL 8.0 : `ADD COLUMN IF NOT EXISTS`/`ADD INDEX IF NOT EXISTS` ne sont pas
--    supportés par MySQL 8.0 → helpers idempotents (information_schema + PREPARE) ci-dessous,
--    compatibles MySQL 8.0. Les colonnes/tables anticipées sont déjà dans la
--    base canonique (schema.sql / calulis-demo-v6.sql) ; ce script ne sert que
--    pour d'éventuelles bases antérieures en cours de montée de version.

-- ============================================================================
-- HELPERS (idempotents, MySQL 8.0)
-- ============================================================================
DELIMITER //

DROP PROCEDURE IF EXISTS `add_col_if_missing`//
CREATE PROCEDURE `add_col_if_missing`(IN p_table VARCHAR(64), IN p_column VARCHAR(64), IN p_definition VARCHAR(500))
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = p_table AND COLUMN_NAME = p_column
    ) THEN
        SET @ddl = CONCAT('ALTER TABLE `', p_table, '` ADD COLUMN `', p_column, '` ', p_definition);
        PREPARE stmt FROM @ddl;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END//

DROP PROCEDURE IF EXISTS `add_idx_if_missing`//
CREATE PROCEDURE `add_idx_if_missing`(IN p_table VARCHAR(64), IN p_index VARCHAR(64), IN p_definition VARCHAR(500))
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM information_schema.STATISTICS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = p_table AND INDEX_NAME = p_index
    ) THEN
        SET @ddl = CONCAT('ALTER TABLE `', p_table, '` ADD INDEX `', p_index, '` ', p_definition);
        PREPARE stmt FROM @ddl;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END IF;
END//

DELIMITER ;

-- ============================================================================
-- PARTIE 1 — NOUVELLES COLONNES SUR TABLES EXISTANTES
-- ============================================================================

-- 1.1/1.2 Élèves — identifiants + dates de début MDPH
CALL add_col_if_missing('eleves', 'ine', 'VARCHAR(15) NULL AFTER `id`');
CALL add_col_if_missing('eleves', 'numero_dossier_mdph', 'VARCHAR(50) NULL AFTER `ine`');
CALL add_col_if_missing('eleves', 'regime', 'VARCHAR(30) NULL AFTER `cantine`');
CALL add_col_if_missing('eleves', 'photo_path', 'VARCHAR(500) NULL AFTER `regime`');
CALL add_col_if_missing('eleves', 'langue_maison', 'VARCHAR(100) NULL AFTER `photo_path`');
CALL add_col_if_missing('eleves', 'bourse', 'INT DEFAULT 0 AFTER `langue_maison`');
CALL add_col_if_missing('eleves', 'orientation_demandee', 'VARCHAR(100) NULL AFTER `bourse`');
CALL add_col_if_missing('eleves', 'orientation_obtenue', 'VARCHAR(100) NULL AFTER `orientation_demandee`');
CALL add_col_if_missing('eleves', 'etablissement_sortie_id', 'INT NULL AFTER `orientation_obtenue`');
CALL add_col_if_missing('eleves', 'enseignant_referent_id', 'INT NULL AFTER `etablissement_sortie_id`');
CALL add_col_if_missing('eleves', 'champ_perso_1', 'VARCHAR(300) NULL AFTER `remarques`');
CALL add_col_if_missing('eleves', 'champ_perso_2', 'VARCHAR(300) NULL AFTER `champ_perso_1`');
CALL add_col_if_missing('eleves', 'mdph_ulis_date_debut', 'DATE NULL AFTER `mdph_ulis_date_fin`');
CALL add_col_if_missing('eleves', 'mdph_aesh_date_debut', 'DATE NULL AFTER `mdph_aesh_date_fin`');
CALL add_col_if_missing('eleves', 'mdph_sessad_date_debut', 'DATE NULL AFTER `mdph_sessad_date_fin`');
CALL add_col_if_missing('eleves', 'mdph_transport_date_debut', 'DATE NULL AFTER `mdph_transport_date_fin`');
CALL add_col_if_missing('eleves', 'mdph_autre_date_debut', 'DATE NULL AFTER `mdph_autre_date_fin`');

-- 1.3 Élèves — index
CALL add_idx_if_missing('eleves', 'ine_idx', '(`ine`)');
CALL add_idx_if_missing('eleves', 'mdph_dossier_idx', '(`numero_dossier_mdph`)');
CALL add_idx_if_missing('eleves', 'eleve_sortie_idx', '(`etablissement_sortie_id`)');
CALL add_idx_if_missing('eleves', 'eleve_ref_idx', '(`enseignant_referent_id`)');

-- 1.4 Élève_années
CALL add_col_if_missing('eleve_annees', 'amenagements_examens', 'TEXT NULL AFTER `cantine`');
CALL add_col_if_missing('eleve_annees', 'temps_scolarisation', 'VARCHAR(30) NULL AFTER `amenagements_examens`');

-- 1.5 Documents
CALL add_col_if_missing('documents', 'auteur_id', 'INT NULL AFTER `notes`');
CALL add_col_if_missing('documents', 'destinataire', 'VARCHAR(200) NULL AFTER `auteur_id`');
CALL add_idx_if_missing('documents', 'doc_auteur_idx', '(`auteur_id`)');

-- 1.6 Réunions — formalisme ESS
CALL add_col_if_missing('reunions', 'compte_rendu', 'TEXT NULL AFTER `documents_lies`');
CALL add_col_if_missing('reunions', 'invites', 'TEXT NULL AFTER `compte_rendu`');
CALL add_col_if_missing('reunions', 'presences', 'TEXT NULL AFTER `invites`');
CALL add_col_if_missing('reunions', 'ordre_du_jour', 'TEXT NULL AFTER `presences`');
CALL add_col_if_missing('reunions', 'preconisations', 'TEXT NULL AFTER `ordre_du_jour`');

-- 1.7 Établissements
CALL add_col_if_missing('etablissements', 'uai', 'VARCHAR(8) NULL AFTER `nom`');
CALL add_col_if_missing('etablissements', 'nature', 'VARCHAR(50) NULL AFTER `type`');
CALL add_col_if_missing('etablissements', 'secteur', 'VARCHAR(30) NULL AFTER `nature`');
CALL add_idx_if_missing('etablissements', 'uai_idx', '(`uai`)');

-- 1.8 Adultes
CALL add_col_if_missing('adultes', 'civilite', 'VARCHAR(10) NULL AFTER `prenom`');
CALL add_col_if_missing('adultes', 'specialite', 'VARCHAR(100) NULL AFTER `fonction`');

-- 1.9 AESH
CALL add_col_if_missing('aesh_eleves', 'quotite', 'VARCHAR(20) NULL AFTER `heures`');

-- ============================================================================
-- PARTIE 2 — NOUVELLES TABLES
-- ============================================================================

-- 2.1 MDPH — Historique des dossiers et décisions
CREATE TABLE IF NOT EXISTS `mdph_dossiers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `eleve_id` INT NOT NULL,
  `annee_scolaire_id` INT NULL,
  `numero_dossier` VARCHAR(50) NULL,
  `type_demande` VARCHAR(50) NULL COMMENT 'orientation ULIS, AESH, SESSAD, transport, materiel, autre',
  `date_depot` DATE NULL,
  `date_commission` DATE NULL COMMENT 'date de passage en CDAPH',
  `date_decision` DATE NULL,
  `date_debut_droit` DATE NULL,
  `date_fin_droit` DATE NULL,
  `statut` VARCHAR(30) DEFAULT 'en_cours' COMMENT 'en_cours, accepte, refuse, expire, recours',
  `commentaires` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `mdph_eleve_idx` (`eleve_id`),
  INDEX `mdph_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `mdph_dossiers_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mdph_dossiers_ibfk_2` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2.2 Dispositifs — PPS, PAP, PPRE, PAI (suivi)
CREATE TABLE IF NOT EXISTS `dispositifs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `eleve_id` INT NOT NULL,
  `annee_scolaire_id` INT NULL,
  `type` VARCHAR(30) NOT NULL COMMENT 'PPS, PAP, PPRE, PAI',
  `date_debut` DATE NULL,
  `date_fin` DATE NULL,
  `statut` VARCHAR(30) DEFAULT 'actif' COMMENT 'actif, inactif, en_redaction, en_revision, clos',
  `objectifs` TEXT NULL,
  `amenagements` TEXT NULL COMMENT 'JSON: amenagements pedagogiques specifiques',
  `notes` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `dispositifs_eleve_idx` (`eleve_id`),
  INDEX `dispositifs_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `dispositifs_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
  CONSTRAINT `dispositifs_ibfk_2` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2.3 Stages en entreprise
CREATE TABLE IF NOT EXISTS `stages` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `eleve_id` INT NOT NULL,
  `annee_scolaire_id` INT NULL,
  `entreprise_nom` VARCHAR(200) NULL,
  `entreprise_adresse` TEXT NULL,
  `entreprise_telephone` VARCHAR(20) NULL,
  `tuteur_nom` VARCHAR(100) NULL,
  `tuteur_telephone` VARCHAR(20) NULL,
  `date_debut` DATE NULL,
  `date_fin` DATE NULL,
  `nb_jours` INT NULL,
  `type` VARCHAR(30) NULL COMMENT 'decouverte, professionnel, alternance, immersion',
  `convention_path` VARCHAR(500) NULL,
  `evaluation` TEXT NULL,
  `bilan` TEXT NULL,
  `statut` VARCHAR(30) DEFAULT 'prevus' COMMENT 'prevus, en_cours, termine, abandonne',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `stages_eleve_idx` (`eleve_id`),
  INDEX `stages_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `stages_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stages_ibfk_2` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2.4 Soins & Thérapies
CREATE TABLE IF NOT EXISTS `soins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `eleve_id` INT NOT NULL,
  `annee_scolaire_id` INT NULL,
  `type` VARCHAR(50) NULL COMMENT 'orthophonie, psychomotricite, psychologue, ergotherapie, psychiatre, CMP, CMPP, SESSAD, autre',
  `professionnel_nom` VARCHAR(100) NULL,
  `structure_nom` VARCHAR(200) NULL,
  `telephone` VARCHAR(20) NULL,
  `frequence` VARCHAR(30) NULL COMMENT 'hebdomadaire, bimensuel, mensuel, ponctuel',
  `duree_seance` INT NULL COMMENT 'durée en minutes',
  `horaire` TIME NULL COMMENT 'horaire habituel si régulier',
  `jour_semaine` VARCHAR(10) NULL COMMENT 'lundi, mardi... si régulier',
  `commentaires` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `soins_eleve_idx` (`eleve_id`),
  INDEX `soins_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `soins_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
  CONSTRAINT `soins_ibfk_2` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2.5 Contacts avec les familles (historique de communication)
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `eleve_id` INT NOT NULL,
  `date_contact` DATE NOT NULL DEFAULT (CURRENT_DATE),
  `type` VARCHAR(30) NULL COMMENT 'appel, sms, mail, rdv, rencontre, carnet_liaison, autre',
  `interlocuteur` VARCHAR(100) NULL COMMENT 'mere, pere, educateur_ASE, famille_accueil...',
  `auteur_id` INT NULL COMMENT 'adulte qui a initié le contact',
  `sujet` VARCHAR(200) NULL,
  `notes` TEXT NULL,
  `action_a_faire` TEXT NULL,
  `statut` VARCHAR(30) DEFAULT 'traite' COMMENT 'traite, en_attente, escalade',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `contacts_eleve_idx` (`eleve_id`),
  INDEX `contacts_auteur_idx` (`auteur_id`),
  CONSTRAINT `contacts_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contacts_ibfk_2` FOREIGN KEY (`auteur_id`) REFERENCES `adultes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2.6 Fichiers uploadés (polymorphique — toutes les pièces jointes)
CREATE TABLE IF NOT EXISTS `fichiers` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `entite_type` VARCHAR(50) NOT NULL COMMENT 'document, reunion, eleve, stage, sortie, consentement, gabarit, materiel',
  `entite_id` INT NOT NULL,
  `nom_original` VARCHAR(500) NOT NULL,
  `nom_stocke` VARCHAR(200) NOT NULL COMMENT 'nom unique sur le disque',
  `chemin` VARCHAR(500) NOT NULL COMMENT 'chemin relatif depuis data/uploads/',
  `taille` INT NULL COMMENT 'taille en octets',
  `type_mime` VARCHAR(100) NULL,
  `categorie` VARCHAR(50) NULL COMMENT 'administratif, pedagogique, medical, photo, convention, autre',
  `uploade_par` VARCHAR(100) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `fichiers_entite_idx` (`entite_type`, `entite_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2.7 Gabarits de documents (Phase 14 — LLM)
CREATE TABLE IF NOT EXISTS `gabarits` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nom` VARCHAR(200) NOT NULL,
  `type` VARCHAR(50) NULL COMMENT 'fiche_renseignement, convocation_ESS, compte_rendu, bilan, courrier, autre',
  `description` TEXT NULL,
  `contenu` LONGTEXT NULL COMMENT 'template avec variables {nom_eleve}, {date_naissance}...',
  `variables` TEXT NULL COMMENT 'JSON: liste des variables attendues',
  `categorie` VARCHAR(50) NULL COMMENT 'administratif, pedagogique, ESS, MDPH, communication',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2.8 Absences des élèves
CREATE TABLE IF NOT EXISTS `absences` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `eleve_id` INT NOT NULL,
  `annee_scolaire_id` INT NULL,
  `date_absence` DATE NOT NULL,
  `demi_journee` VARCHAR(10) DEFAULT 'journee' COMMENT 'matin, apres_midi, journee',
  `justifie` INT DEFAULT 0 COMMENT '0=non, 1=oui',
  `motif` VARCHAR(200) NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `absences_eleve_idx` (`eleve_id`),
  INDEX `absences_annee_idx` (`annee_scolaire_id`),
  INDEX `absences_date_idx` (`date_absence`),
  CONSTRAINT `absences_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
  CONSTRAINT `absences_ibfk_2` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2.9 Matériel pédagogique adapté
CREATE TABLE IF NOT EXISTS `materiel` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `eleve_id` INT NULL COMMENT 'NULL si collectif',
  `annee_scolaire_id` INT NULL,
  `nom` VARCHAR(200) NOT NULL,
  `type` VARCHAR(50) NULL COMMENT 'informatique, mobilier, logiciel, pedagogique, autre',
  `financement` VARCHAR(50) NULL COMMENT 'dotation, subvention, pret, don, personnel',
  `cout` DECIMAL(10,2) NULL,
  `date_acquisition` DATE NULL,
  `etat` VARCHAR(30) DEFAULT 'bon' COMMENT 'bon, usage, hs, perdu',
  `commentaires` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `materiel_eleve_idx` (`eleve_id`),
  INDEX `materiel_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `materiel_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE SET NULL,
  CONSTRAINT `materiel_ibfk_2` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2.10 Budget
CREATE TABLE IF NOT EXISTS `budget` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `annee_scolaire_id` INT NULL,
  `type` VARCHAR(20) NOT NULL COMMENT 'recette, depense',
  `categorie` VARCHAR(50) NULL COMMENT 'materiel, sortie, projet, fournitures, autre',
  `montant` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  `description` TEXT NULL,
  `date_operation` DATE NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `budget_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `budget_ibfk_1` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2.11 Sorties & voyages scolaires
CREATE TABLE IF NOT EXISTS `sorties` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `annee_scolaire_id` INT NULL,
  `nom` VARCHAR(200) NOT NULL,
  `type` VARCHAR(50) NULL COMMENT 'sortie_journee, voyage, sejour, spectacle, sport, culture, autre',
  `date_debut` DATE NULL,
  `date_fin` DATE NULL,
  `lieu` VARCHAR(300) NULL,
  `eleves_ids` TEXT NULL COMMENT 'JSON: liste des eleves participants',
  `adultes_ids` TEXT NULL COMMENT 'JSON: liste des adultes accompagnants',
  `cout_total` DECIMAL(10,2) NULL,
  `cout_par_eleve` DECIMAL(10,2) NULL,
  `autorisations_recues` INT DEFAULT 0,
  `notes` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `sorties_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `sorties_ibfk_1` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2.12 Utilisateurs (multi-profils)
CREATE TABLE IF NOT EXISTS `utilisateurs` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nom` VARCHAR(100) NOT NULL,
  `prenom` VARCHAR(100) NOT NULL DEFAULT '',
  `login` VARCHAR(100) NOT NULL,
  `mot_de_passe_hash` VARCHAR(255) NULL COMMENT 'hashé avec password_hash()',
  `role` VARCHAR(30) DEFAULT 'lecture_seule' COMMENT 'admin, coordo, enseignant, aesh, lecture_seule',
  `adulte_id` INT NULL COMMENT 'lien vers un adulte existant',
  `actif` INT DEFAULT 1,
  `derniere_connexion` TIMESTAMP NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE INDEX `login_unique` (`login`),
  INDEX `utilisateurs_adulte_idx` (`adulte_id`),
  CONSTRAINT `utilisateurs_ibfk_1` FOREIGN KEY (`adulte_id`) REFERENCES `adultes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2.13 Consentements & Autorisations (RGPD)
CREATE TABLE IF NOT EXISTS `consentements` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `eleve_id` INT NOT NULL,
  `type` VARCHAR(50) NOT NULL COMMENT 'droit_image, sorties, soins, partage_infos, communication_mail, photos_reseaux, autre',
  `statut` VARCHAR(30) DEFAULT 'en_attente' COMMENT 'autorise, refuse, limite, en_attente, retire',
  `date_debut` DATE NULL,
  `date_fin` DATE NULL,
  `document_reference` VARCHAR(300) NULL COMMENT 'reference du document signé',
  `commentaires` TEXT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `consentements_eleve_idx` (`eleve_id`),
  CONSTRAINT `consentements_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2.14 Historique / Audit trail
CREATE TABLE IF NOT EXISTS `historique` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `table_concernee` VARCHAR(50) NOT NULL,
  `enregistrement_id` INT NOT NULL,
  `action` VARCHAR(20) NOT NULL COMMENT 'create, update, delete',
  `avant` LONGTEXT NULL COMMENT 'JSON: état avant modification',
  `apres` LONGTEXT NULL COMMENT 'JSON: état après modification',
  `auteur` VARCHAR(100) NULL,
  `date_action` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `historique_table_idx` (`table_concernee`, `enregistrement_id`),
  INDEX `historique_date_idx` (`date_action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2.15 Journal de bord / Cahier de notes
CREATE TABLE IF NOT EXISTS `journal` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `auteur` VARCHAR(100) NULL,
  `date_journal` DATE NOT NULL DEFAULT (CURRENT_DATE),
  `type` VARCHAR(30) NULL COMMENT 'note_perso, incident, observation, a_faire, evenement, reunion_informelle',
  `eleve_id` INT NULL,
  `contenu` TEXT NULL,
  `important` INT DEFAULT 0,
  `resolu` INT DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  INDEX `journal_eleve_idx` (`eleve_id`),
  INDEX `journal_date_idx` (`date_journal`),
  CONSTRAINT `journal_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- ============================================================================
-- VÉRIFICATION
-- ============================================================================
-- SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA='calulis' ORDER BY TABLE_NAME;
-- (Doit retourner 36 tables : les 21 existantes + 15 nouvelles)