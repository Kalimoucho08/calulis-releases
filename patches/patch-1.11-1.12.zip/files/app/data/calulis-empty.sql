-- MySQL dump (Calulis — base vide, MySQL 8.0-compatible)
--
-- Host: localhost    Database: calulis
-- ------------------------------------------------------
-- Server version	MySQL 8.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `absences`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `absences` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eleve_id` int(11) NOT NULL,
  `annee_scolaire_id` int(11) DEFAULT NULL,
  `date_absence` date NOT NULL,
  `demi_journee` varchar(10) DEFAULT 'journee' COMMENT 'matin, apres_midi, journee',
  `justifie` int(11) DEFAULT 0 COMMENT '0=non, 1=oui',
  `motif` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `absences_eleve_idx` (`eleve_id`),
  KEY `absences_annee_idx` (`annee_scolaire_id`),
  KEY `absences_date_idx` (`date_absence`),
  CONSTRAINT `absences_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
  CONSTRAINT `absences_ibfk_2` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `absences`
--

--
-- Table structure for table `adultes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `adultes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(150) NOT NULL,
  `prenom` varchar(100) NOT NULL DEFAULT '',
  `civilite` varchar(10) DEFAULT NULL COMMENT 'M., Mme, Dr...',
  `role` varchar(50) DEFAULT '',
  `fonction` varchar(50) DEFAULT '',
  `specialite` varchar(100) DEFAULT NULL COMMENT 'Neuropsychologue, Ergotherapeute, Psychomotricien...',
  `telephone` varchar(20) DEFAULT '',
  `email` varchar(100) DEFAULT '',
  `etablissements` text DEFAULT NULL,
  `etablissement_id` int(11) DEFAULT NULL,
  `commentaires` text DEFAULT NULL,
  `ordre` int(11) DEFAULT 0,
  `actif` int(11) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adultes`
--

--
-- Table structure for table `adultes_etablissements`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `adultes_etablissements` (
  `adulte_id` int(11) NOT NULL,
  `etablissement_id` int(11) NOT NULL,
  `role` varchar(50) DEFAULT '',
  `annee_scolaire_id` int(11) NOT NULL DEFAULT 1,
  PRIMARY KEY (`adulte_id`,`etablissement_id`,`annee_scolaire_id`),
  KEY `etablissement_id` (`etablissement_id`),
  KEY `ae_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `adultes_etablissements_ibfk_1` FOREIGN KEY (`adulte_id`) REFERENCES `adultes` (`id`) ON DELETE CASCADE,
  CONSTRAINT `adultes_etablissements_ibfk_2` FOREIGN KEY (`etablissement_id`) REFERENCES `etablissements` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ae_ibfk_annee` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `adultes_etablissements`
--

--
-- Table structure for table `aesh_eleves`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `aesh_eleves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eleve_id` int(11) NOT NULL,
  `type` varchar(10) NOT NULL,
  `nom` varchar(100) DEFAULT NULL,
  `heures` varchar(20) DEFAULT NULL,
  `quotite` varchar(20) DEFAULT NULL COMMENT '12h/sem, 50%, 100%...',
  `mutualise_avec` text DEFAULT NULL,
  `ordre` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `eleve_id` (`eleve_id`),
  CONSTRAINT `aesh_eleves_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `aesh_eleves`
--

--
-- Table structure for table `annees_scolaires`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `annees_scolaires` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `est_active` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `annees_scolaires`
--

--
-- Table structure for table `budget`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `budget` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `annee_scolaire_id` int(11) DEFAULT NULL,
  `type` varchar(20) NOT NULL COMMENT 'recette, depense',
  `categorie` varchar(50) DEFAULT NULL COMMENT 'materiel, sortie, projet, fournitures, autre',
  `montant` decimal(10,2) NOT NULL DEFAULT 0.00,
  `description` text DEFAULT NULL,
  `date_operation` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `budget_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `budget_ibfk_1` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `budget`
--

--
-- Table structure for table `classes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `classes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `niveaux` text DEFAULT NULL,
  `enseignant_id` int(11) DEFAULT NULL,
  `etablissement_id` int(11) DEFAULT NULL,
  `actif` int(11) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `enseignant_id` (`enseignant_id`),
  KEY `etablissement_id` (`etablissement_id`),
  CONSTRAINT `classes_ibfk_1` FOREIGN KEY (`enseignant_id`) REFERENCES `adultes` (`id`) ON DELETE SET NULL,
  CONSTRAINT `classes_ibfk_2` FOREIGN KEY (`etablissement_id`) REFERENCES `etablissements` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes`
--

--
-- Table structure for table `consentements`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `consentements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eleve_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL COMMENT 'droit_image, sorties, soins, partage_infos, communication_mail, photos_reseaux, autre',
  `statut` varchar(30) DEFAULT 'en_attente' COMMENT 'autorise, refuse, limite, en_attente, retire',
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `document_reference` varchar(300) DEFAULT NULL COMMENT 'reference du document signé',
  `commentaires` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `consentements_eleve_idx` (`eleve_id`),
  CONSTRAINT `consentements_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consentements`
--

--
-- Table structure for table `contacts`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `contacts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eleve_id` int(11) NOT NULL,
  `date_contact` date NOT NULL DEFAULT (curdate()),
  `type` varchar(30) DEFAULT NULL COMMENT 'appel, sms, mail, rdv, rencontre, carnet_liaison, autre',
  `interlocuteur` varchar(100) DEFAULT NULL COMMENT 'mere, pere, educateur_ASE, famille_accueil...',
  `auteur_id` int(11) DEFAULT NULL COMMENT 'adulte qui a initié le contact',
  `sujet` varchar(200) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `action_a_faire` text DEFAULT NULL,
  `statut` varchar(30) DEFAULT 'traite' COMMENT 'traite, en_attente, escalade',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `contacts_eleve_idx` (`eleve_id`),
  KEY `contacts_auteur_idx` (`auteur_id`),
  CONSTRAINT `contacts_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contacts_ibfk_2` FOREIGN KEY (`auteur_id`) REFERENCES `adultes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contacts`
--

--
-- Table structure for table `creneaux`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `creneaux` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eleve_id` int(11) NOT NULL,
  `semaine_id` int(11) DEFAULT NULL,
  `jour` varchar(10) NOT NULL,
  `heure_debut` time NOT NULL,
  `duree` int(11) DEFAULT 15,
  `matiere` varchar(100) DEFAULT NULL,
  `groupe` varchar(50) DEFAULT NULL,
  `adulte` varchar(100) DEFAULT NULL,
  `role_adulte` varchar(30) DEFAULT NULL,
  `type` varchar(20) DEFAULT 'fixe',
  `regroupement_type` varchar(30) DEFAULT NULL,
  `couleur_override` varchar(7) DEFAULT NULL,
  `commentaire` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `eleve_id` (`eleve_id`),
  KEY `semaine_id` (`semaine_id`),
  CONSTRAINT `creneaux_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
  CONSTRAINT `creneaux_ibfk_2` FOREIGN KEY (`semaine_id`) REFERENCES `semaines` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `creneaux`
--

--
-- Table structure for table `dispositifs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `dispositifs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eleve_id` int(11) NOT NULL,
  `annee_scolaire_id` int(11) DEFAULT NULL,
  `type` varchar(30) NOT NULL COMMENT 'PPS, PAP, PPRE, PAI',
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `statut` varchar(30) DEFAULT 'actif' COMMENT 'actif, inactif, en_redaction, en_revision, clos',
  `objectifs` text DEFAULT NULL,
  `amenagements` text DEFAULT NULL COMMENT 'JSON: amenagements pedagogiques specifiques',
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `dispositifs_eleve_idx` (`eleve_id`),
  KEY `dispositifs_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `dispositifs_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
  CONSTRAINT `dispositifs_ibfk_2` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `dispositifs`
--

--
-- Table structure for table `documents`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `annee_scolaire_id` int(11) DEFAULT NULL,
  `nom` varchar(300) NOT NULL,
  `type` varchar(50) NOT NULL,
  `eleve_id` int(11) DEFAULT NULL,
  `reunion_id` int(11) DEFAULT NULL,
  `date_document` date DEFAULT NULL,
  `version` varchar(20) DEFAULT NULL,
  `statut` varchar(30) DEFAULT 'en_attente',
  `reference_externe` varchar(500) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `auteur_id` int(11) DEFAULT NULL,
  `destinataire` varchar(200) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `eleve_id` (`eleve_id`),
  KEY `reunion_id` (`reunion_id`),
  KEY `documents_annee_idx` (`annee_scolaire_id`),
  KEY `doc_auteur_idx` (`auteur_id`),
  CONSTRAINT `documents_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE SET NULL,
  CONSTRAINT `documents_ibfk_2` FOREIGN KEY (`reunion_id`) REFERENCES `reunions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `documents_ibfk_annee` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `documents`
--

--
-- Table structure for table `eleve_annees`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `eleve_annees` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eleve_id` int(11) NOT NULL,
  `annee_scolaire_id` int(11) NOT NULL,
  `classe_id` int(11) DEFAULT NULL,
  `classe` varchar(20) DEFAULT NULL,
  `ulis` int(11) DEFAULT 0,
  `groupe` varchar(50) DEFAULT NULL,
  `niveau_scolaire` varchar(20) DEFAULT NULL,
  `etablissement_id` int(11) DEFAULT NULL,
  `aesh_type` varchar(10) DEFAULT NULL,
  `aesh_nom` varchar(100) DEFAULT NULL,
  `aesh_heures` varchar(20) DEFAULT NULL,
  `aesh_mutualise_avec` text DEFAULT NULL,
  `pec_specialite` varchar(50) DEFAULT NULL,
  `pec_organisme` varchar(50) DEFAULT NULL,
  `pec_frequence` varchar(30) DEFAULT NULL,
  `pec_lieu` varchar(50) DEFAULT NULL,
  `pec_duree` varchar(20) DEFAULT NULL,
  `pec_commentaires` text DEFAULT NULL,
  `transport` varchar(100) DEFAULT NULL,
  `cantine` int(11) DEFAULT 0,
  `amenagements_examens` text DEFAULT NULL COMMENT 'JSON: tiers_temps, ordinateur, secretaire, dictee_amenagee...',
  `temps_scolarisation` varchar(30) DEFAULT NULL COMMENT 'temps_plein, temps_partiel, decharge_horaire',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_eleve_annee` (`eleve_id`,`annee_scolaire_id`),
  KEY `eleve_annees_ibfk_2` (`annee_scolaire_id`),
  CONSTRAINT `eleve_annees_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
  CONSTRAINT `eleve_annees_ibfk_2` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eleve_annees`
--

--
-- Table structure for table `eleves`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `eleves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ine` varchar(15) DEFAULT NULL,
  `numero_dossier_mdph` varchar(50) DEFAULT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL,
  `date_naissance` date DEFAULT NULL,
  `classe` varchar(20) DEFAULT NULL,
  `ulis` int(11) DEFAULT 0,
  `groupe` varchar(50) DEFAULT NULL,
  `niveau_scolaire` varchar(20) DEFAULT NULL,
  `ecole_origine` varchar(100) DEFAULT NULL,
  `date_entree_ulis` date DEFAULT NULL,
  `date_sortie_ulis` date DEFAULT NULL,
  `motif_sortie` varchar(100) DEFAULT NULL,
  `suivi_par` varchar(100) DEFAULT NULL,
  `aesh_type` varchar(10) DEFAULT NULL,
  `aesh_nom` varchar(100) DEFAULT NULL,
  `aesh_heures` varchar(20) DEFAULT NULL,
  `aesh_mutualise_avec` text DEFAULT NULL,
  `pec_specialite` varchar(50) DEFAULT NULL,
  `pec_organisme` varchar(50) DEFAULT NULL,
  `pec_frequence` varchar(30) DEFAULT NULL,
  `pec_lieu` varchar(50) DEFAULT NULL,
  `pec_duree` varchar(20) DEFAULT NULL,
  `pec_commentaires` text DEFAULT NULL,
  `transport` varchar(100) DEFAULT NULL,
  `cantine` int(11) DEFAULT 0,
  `regime_scolaire` varchar(30) DEFAULT NULL COMMENT 'externe, demi_pensionnaire, interne',
  `photo_path` varchar(500) DEFAULT NULL,
  `langue_maison` varchar(100) DEFAULT NULL COMMENT 'langue parlée à la maison (allophone)',
  `bourse` int(11) DEFAULT 0 COMMENT '0=non, 1=oui',
  `orientation_demandee` varchar(100) DEFAULT NULL,
  `orientation_obtenue` varchar(100) DEFAULT NULL,
  `etablissement_sortie_id` int(11) DEFAULT NULL,
  `enseignant_referent_id` int(11) DEFAULT NULL,
  `telephone_urgence` varchar(20) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `allergies` text DEFAULT NULL,
  `regime_alimentaire` varchar(100) DEFAULT NULL,
  `suivi_medical` tinyint(4) DEFAULT 0,
  `precautions_medicales` text DEFAULT NULL,
  `pai` int(11) DEFAULT 0,
  `lien_pai` varchar(500) DEFAULT NULL,
  `liens_mdph` text DEFAULT NULL,
  `remarques` text DEFAULT NULL,
  `champ_perso_1` varchar(300) DEFAULT NULL COMMENT 'champ libre configurable',
  `champ_perso_2` varchar(300) DEFAULT NULL COMMENT 'champ libre configurable',
  `notifications` text DEFAULT NULL,
  `mdph_ulis_date_fin` date DEFAULT NULL,
  `mdph_ulis_date_debut` date DEFAULT NULL,
  `mdph_ulis_statut` varchar(30) DEFAULT NULL,
  `mdph_sessad_date_fin` date DEFAULT NULL,
  `mdph_sessad_date_debut` date DEFAULT NULL,
  `mdph_sessad_statut` varchar(30) DEFAULT NULL,
  `mdph_aesh_date_fin` date DEFAULT NULL,
  `mdph_aesh_date_debut` date DEFAULT NULL,
  `mdph_aesh_statut` varchar(30) DEFAULT NULL,
  `mdph_transport_date_fin` date DEFAULT NULL,
  `mdph_transport_date_debut` date DEFAULT NULL,
  `mdph_transport_statut` varchar(30) DEFAULT NULL,
  `mdph_autre_date_fin` date DEFAULT NULL,
  `mdph_autre_date_debut` date DEFAULT NULL,
  `mdph_autre_statut` varchar(30) DEFAULT NULL,
  `mdph_autre_libelle` varchar(100) DEFAULT NULL,
  `ase_place` int(11) DEFAULT 0,
  `ase_type_placement` varchar(50) DEFAULT NULL,
  `ase_structure_nom` varchar(200) DEFAULT NULL,
  `ase_structure_adresse` text DEFAULT NULL,
  `ase_structure_telephone` varchar(20) DEFAULT NULL,
  `ase_referent_nom` varchar(100) DEFAULT NULL,
  `ase_referent_telephone` varchar(20) DEFAULT NULL,
  `ase_referent_email` varchar(100) DEFAULT NULL,
  `ase_lien_ppe` varchar(500) DEFAULT NULL,
  `ase_notes` text DEFAULT NULL,
  `etablissement_id` int(11) DEFAULT NULL,
  `ecole_origine_id` int(11) DEFAULT NULL,
  `classe_id` int(11) DEFAULT NULL,
  `actif` int(11) DEFAULT 1,
  `ordre` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ine_idx` (`ine`),
  KEY `mdph_dossier_idx` (`numero_dossier_mdph`),
  KEY `eleve_sortie_idx` (`etablissement_sortie_id`),
  KEY `eleve_ref_idx` (`enseignant_referent_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `eleves`
--

--
-- Table structure for table `etablissements`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `etablissements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(200) NOT NULL,
  `uai` varchar(8) DEFAULT NULL,
  `type` varchar(50) DEFAULT '',
  `nature` varchar(50) DEFAULT NULL COMMENT 'ecole, college, lycee, IME, ITEP, SESSAD, CMP, CMPP, hopital...',
  `secteur` varchar(30) DEFAULT NULL COMMENT 'public, prive_sous_contrat, prive_hors_contrat, associatif',
  `ville` varchar(100) DEFAULT '',
  `circonscription` varchar(100) DEFAULT '',
  `departement` varchar(50) DEFAULT '',
  `code_postal` varchar(10) DEFAULT '',
  `adresse` text DEFAULT NULL,
  `telephone` varchar(20) DEFAULT '',
  `telephone2` varchar(20) DEFAULT '',
  `email` varchar(100) DEFAULT '',
  `email2` varchar(100) DEFAULT '',
  `description` text DEFAULT NULL,
  `actif` int(11) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `uai_idx` (`uai`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `etablissements`
--

--
-- Table structure for table `evenements`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `evenements` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `annee_scolaire_id` int(11) NOT NULL,
  `nom` varchar(200) NOT NULL,
  `description` text DEFAULT NULL,
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `jour_semaine` varchar(10) DEFAULT NULL,
  `est_recurrent` int(11) DEFAULT 0,
  `recurrence_type` varchar(30) DEFAULT NULL,
  `categorie` varchar(50) DEFAULT NULL COMMENT 'ferie, examen, national, scolaire, individuel, anniversaire',
  `est_modele` int(11) DEFAULT 0,
  `couleur` varchar(7) DEFAULT NULL,
  `affecte_semaine_type` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `annee_scolaire_id` (`annee_scolaire_id`),
  CONSTRAINT `evenements_ibfk_1` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `evenements`
--

--
-- Table structure for table `fichiers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `fichiers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `entite_type` varchar(50) NOT NULL COMMENT 'document, reunion, eleve, stage, sortie, consentement, gabarit, materiel',
  `entite_id` int(11) NOT NULL,
  `nom_original` varchar(500) NOT NULL,
  `nom_stocke` varchar(200) NOT NULL COMMENT 'nom unique sur le disque',
  `chemin` varchar(500) NOT NULL COMMENT 'chemin relatif depuis data/uploads/',
  `taille` int(11) DEFAULT NULL COMMENT 'taille en octets',
  `type_mime` varchar(100) DEFAULT NULL,
  `categorie` varchar(50) DEFAULT NULL COMMENT 'administratif, pedagogique, medical, photo, convention, autre',
  `uploade_par` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `fichiers_entite_idx` (`entite_type`,`entite_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fichiers`
--

--
-- Table structure for table `gabarits`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `gabarits` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(200) NOT NULL,
  `type` varchar(50) DEFAULT NULL COMMENT 'fiche_renseignement, convocation_ESS, compte_rendu, bilan, courrier, autre',
  `description` text DEFAULT NULL,
  `contenu` longtext DEFAULT NULL COMMENT 'template avec variables {nom_eleve}, {date_naissance}...',
  `variables` text DEFAULT NULL COMMENT 'JSON: liste des variables attendues',
  `categorie` varchar(50) DEFAULT NULL COMMENT 'administratif, pedagogique, ESS, MDPH, communication',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `gabarits`
--

--
-- Table structure for table `historique`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `historique` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_concernee` varchar(50) NOT NULL,
  `enregistrement_id` int(11) NOT NULL,
  `action` varchar(20) NOT NULL COMMENT 'create, update, delete',
  `avant` longtext DEFAULT NULL COMMENT 'JSON: état avant modification',
  `apres` longtext DEFAULT NULL COMMENT 'JSON: état après modification',
  `auteur` varchar(100) DEFAULT NULL,
  `date_action` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `historique_table_idx` (`table_concernee`,`enregistrement_id`),
  KEY `historique_date_idx` (`date_action`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `historique`
--

--
-- Table structure for table `journal`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `journal` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `auteur` varchar(100) DEFAULT NULL,
  `date_journal` date NOT NULL DEFAULT (curdate()),
  `type` varchar(30) DEFAULT NULL COMMENT 'note_perso, incident, observation, a_faire, evenement, reunion_informelle',
  `eleve_id` int(11) DEFAULT NULL,
  `contenu` text DEFAULT NULL,
  `important` int(11) DEFAULT 0,
  `resolu` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `journal_eleve_idx` (`eleve_id`),
  KEY `journal_date_idx` (`date_journal`),
  CONSTRAINT `journal_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `journal`
--

--
-- Table structure for table `materiel`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `materiel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eleve_id` int(11) DEFAULT NULL COMMENT 'NULL si collectif',
  `annee_scolaire_id` int(11) DEFAULT NULL,
  `nom` varchar(200) NOT NULL,
  `type` varchar(50) DEFAULT NULL COMMENT 'informatique, mobilier, logiciel, pedagogique, autre',
  `financement` varchar(50) DEFAULT NULL COMMENT 'dotation, subvention, pret, don, personnel',
  `cout` decimal(10,2) DEFAULT NULL,
  `date_acquisition` date DEFAULT NULL,
  `etat` varchar(30) DEFAULT 'bon' COMMENT 'bon, usage, hs, perdu',
  `commentaires` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `materiel_eleve_idx` (`eleve_id`),
  KEY `materiel_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `materiel_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE SET NULL,
  CONSTRAINT `materiel_ibfk_2` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `materiel`
--

--
-- Table structure for table `mdph_dossiers`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `mdph_dossiers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eleve_id` int(11) NOT NULL,
  `annee_scolaire_id` int(11) DEFAULT NULL,
  `numero_dossier` varchar(50) DEFAULT NULL,
  `type_demande` varchar(50) DEFAULT NULL COMMENT 'orientation ULIS, AESH, SESSAD, transport, materiel, autre',
  `date_depot` date DEFAULT NULL,
  `date_commission` date DEFAULT NULL COMMENT 'date de passage en CDAPH',
  `date_decision` date DEFAULT NULL,
  `date_debut_droit` date DEFAULT NULL,
  `date_fin_droit` date DEFAULT NULL,
  `statut` varchar(30) DEFAULT 'en_cours' COMMENT 'en_cours, accepte, refuse, expire, recours',
  `commentaires` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `mdph_eleve_idx` (`eleve_id`),
  KEY `mdph_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `mdph_dossiers_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
  CONSTRAINT `mdph_dossiers_ibfk_2` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mdph_dossiers`
--

--
-- Table structure for table `notes_suivi`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `notes_suivi` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `annee_scolaire_id` int(11) DEFAULT NULL,
  `eleve_id` int(11) NOT NULL,
  `date_note` date NOT NULL DEFAULT (curdate()),
  `auteur` varchar(100) DEFAULT NULL,
  `type` varchar(30) DEFAULT 'observation',
  `contenu` text NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `eleve_id` (`eleve_id`),
  KEY `notes_suivi_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `notes_suivi_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
  CONSTRAINT `notes_suivi_ibfk_annee` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `notes_suivi`
--

--
-- Table structure for table `parametres`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `parametres` (
  `cle` varchar(50) NOT NULL,
  `valeur` text NOT NULL,
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`cle`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `parametres`
--

--
-- Table structure for table `pauses`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `pauses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `heure_debut` time NOT NULL,
  `heure_fin` time NOT NULL,
  `couleur` varchar(7) DEFAULT '#e0e0e0',
  `actif` int(11) DEFAULT 1,
  `jours` varchar(100) DEFAULT 'lundi,mardi,jeudi,vendredi',
  `ordre` int(11) DEFAULT 0,
  `eleve_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `eleve_id` (`eleve_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pauses`
--

--
-- Table structure for table `pec_eleves`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `pec_eleves` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eleve_id` int(11) NOT NULL,
  `annee_scolaire_id` int(11) DEFAULT NULL,
  `specialite` varchar(50) DEFAULT NULL,
  `organisme` varchar(50) DEFAULT NULL,
  `frequence` varchar(30) DEFAULT NULL,
  `lieu` varchar(50) DEFAULT NULL,
  `duree` varchar(20) DEFAULT NULL,
  `commentaires` text DEFAULT NULL,
  `ordre` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `eleve_id` (`eleve_id`),
  KEY `pec_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `pec_eleves_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pec_ibfk_annee` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pec_eleves`
--

--
-- Table structure for table `periodes`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `periodes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `annee_scolaire_id` int(11) NOT NULL,
  `nom` varchar(50) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `ordre` int(11) DEFAULT 0,
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `annee_scolaire_id` (`annee_scolaire_id`),
  CONSTRAINT `periodes_ibfk_1` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `periodes`
--

--
-- Table structure for table `representants`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `representants` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eleve_id` int(11) NOT NULL,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) DEFAULT NULL,
  `lien` varchar(50) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `telephone_urgence` int(11) DEFAULT 0,
  `email` varchar(100) DEFAULT NULL,
  `adresse` text DEFAULT NULL,
  `ordre` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `eleve_id` (`eleve_id`),
  CONSTRAINT `representants_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `representants`
--

--
-- Table structure for table `reunions`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `reunions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `annee_scolaire_id` int(11) DEFAULT NULL,
  `type` varchar(50) NOT NULL,
  `titre` varchar(200) NOT NULL,
  `date_reunion` date NOT NULL,
  `heure` time DEFAULT NULL,
  `duree` int(11) DEFAULT 60,
  `eleve_id` int(11) DEFAULT NULL,
  `lieu` varchar(200) DEFAULT NULL,
  `participants` text DEFAULT NULL,
  `statut` varchar(30) DEFAULT 'prevue',
  `notes` text DEFAULT NULL,
  `documents_lies` text DEFAULT NULL,
  `compte_rendu` text DEFAULT NULL,
  `invites` text DEFAULT NULL COMMENT 'JSON: liste des personnes convoquées',
  `presences` text DEFAULT NULL COMMENT 'JSON: présents/excusés/absents',
  `ordre_du_jour` text DEFAULT NULL,
  `preconisations` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `eleve_id` (`eleve_id`),
  KEY `reunions_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `reunions_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE SET NULL,
  CONSTRAINT `reunions_ibfk_annee` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `reunions`
--

--
-- Table structure for table `semaines`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `semaines` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `annee_scolaire_id` int(11) NOT NULL,
  `numero` int(11) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `est_vacances` int(11) DEFAULT 0,
  `est_modifiee` int(11) DEFAULT 0,
  `notes` text DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `annee_scolaire_id` (`annee_scolaire_id`),
  CONSTRAINT `semaines_ibfk_1` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `semaines`
--

--
-- Table structure for table `soins`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `soins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eleve_id` int(11) NOT NULL,
  `annee_scolaire_id` int(11) DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL COMMENT 'orthophonie, psychomotricite, psychologue, ergotherapie, psychiatre, CMP, CMPP, SESSAD, autre',
  `professionnel_nom` varchar(100) DEFAULT NULL,
  `structure_nom` varchar(200) DEFAULT NULL,
  `telephone` varchar(20) DEFAULT NULL,
  `frequence` varchar(30) DEFAULT NULL COMMENT 'hebdomadaire, bimensuel, mensuel, ponctuel',
  `duree_seance` int(11) DEFAULT NULL COMMENT 'durée en minutes',
  `horaire` time DEFAULT NULL COMMENT 'horaire habituel si régulier',
  `jour_semaine` varchar(10) DEFAULT NULL COMMENT 'lundi, mardi... si régulier',
  `commentaires` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `soins_eleve_idx` (`eleve_id`),
  KEY `soins_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `soins_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
  CONSTRAINT `soins_ibfk_2` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `soins`
--

--
-- Table structure for table `sorties`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `sorties` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `annee_scolaire_id` int(11) DEFAULT NULL,
  `nom` varchar(200) NOT NULL,
  `type` varchar(50) DEFAULT NULL COMMENT 'sortie_journee, voyage, sejour, spectacle, sport, culture, autre',
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `lieu` varchar(300) DEFAULT NULL,
  `eleves_ids` text DEFAULT NULL COMMENT 'JSON: liste des eleves participants',
  `adultes_ids` text DEFAULT NULL COMMENT 'JSON: liste des adultes accompagnants',
  `cout_total` decimal(10,2) DEFAULT NULL,
  `cout_par_eleve` decimal(10,2) DEFAULT NULL,
  `autorisations_recues` int(11) DEFAULT 0,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `sorties_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `sorties_ibfk_1` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sorties`
--

--
-- Table structure for table `stages`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `stages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `eleve_id` int(11) NOT NULL,
  `annee_scolaire_id` int(11) DEFAULT NULL,
  `entreprise_nom` varchar(200) DEFAULT NULL,
  `entreprise_adresse` text DEFAULT NULL,
  `entreprise_telephone` varchar(20) DEFAULT NULL,
  `tuteur_nom` varchar(100) DEFAULT NULL,
  `tuteur_telephone` varchar(20) DEFAULT NULL,
  `date_debut` date DEFAULT NULL,
  `date_fin` date DEFAULT NULL,
  `nb_jours` int(11) DEFAULT NULL,
  `type` varchar(30) DEFAULT NULL COMMENT 'decouverte, professionnel, alternance, immersion',
  `convention_path` varchar(500) DEFAULT NULL,
  `evaluation` text DEFAULT NULL,
  `bilan` text DEFAULT NULL,
  `statut` varchar(30) DEFAULT 'prevus' COMMENT 'prevus, en_cours, termine, abandonne',
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `stages_eleve_idx` (`eleve_id`),
  KEY `stages_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `stages_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stages_ibfk_2` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stages`
--

--
-- Table structure for table `taches`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `taches` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `annee_scolaire_id` int(11) DEFAULT NULL,
  `description` varchar(500) NOT NULL,
  `eleve_id` int(11) DEFAULT NULL,
  `reunion_id` int(11) DEFAULT NULL,
  `date_creation` date NOT NULL DEFAULT (curdate()),
  `echeance` date DEFAULT NULL,
  `priorite` varchar(20) DEFAULT 'moyenne',
  `statut` varchar(30) DEFAULT 'a_faire',
  `responsable` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `eleve_id` (`eleve_id`),
  KEY `reunion_id` (`reunion_id`),
  KEY `taches_annee_idx` (`annee_scolaire_id`),
  CONSTRAINT `taches_ibfk_1` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE SET NULL,
  CONSTRAINT `taches_ibfk_2` FOREIGN KEY (`reunion_id`) REFERENCES `reunions` (`id`) ON DELETE SET NULL,
  CONSTRAINT `taches_ibfk_annee` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `taches`
--

--
-- Table structure for table `utilisateurs`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `utilisateurs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `prenom` varchar(100) NOT NULL DEFAULT '',
  `login` varchar(100) NOT NULL,
  `mot_de_passe_hash` varchar(255) DEFAULT NULL COMMENT 'hashé avec password_hash()',
  `role` varchar(30) DEFAULT 'lecture_seule' COMMENT 'admin, coordo, enseignant, aesh, lecture_seule',
  `adulte_id` int(11) DEFAULT NULL COMMENT 'lien vers un adulte existant',
  `actif` int(11) DEFAULT 1,
  `derniere_connexion` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `login_unique` (`login`),
  KEY `utilisateurs_adulte_idx` (`adulte_id`),
  CONSTRAINT `utilisateurs_ibfk_1` FOREIGN KEY (`adulte_id`) REFERENCES `adultes` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `utilisateurs`
--

--
-- Table structure for table `vacances`
--

/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE IF NOT EXISTS `vacances` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(100) NOT NULL,
  `date_debut` date NOT NULL,
  `date_fin` date NOT NULL,
  `zone` varchar(1) DEFAULT NULL,
  `annee_scolaire_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `annee_scolaire_id` (`annee_scolaire_id`),
  CONSTRAINT `vacances_ibfk_1` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `vacances`
--

-- Table structure for table `schema_migrations`
DROP TABLE IF EXISTS `schema_migrations`;
CREATE TABLE `schema_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `version` varchar(50) NOT NULL,
  `filename` varchar(255) NOT NULL,
  `applied_at` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_version` (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-07-01  9:48:21
