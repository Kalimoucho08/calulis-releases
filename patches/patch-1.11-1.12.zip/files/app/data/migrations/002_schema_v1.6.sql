-- Migration 002 : corrections schema v1.5.0 → v1.6.0
-- Ajoute les colonnes manquantes pour evenements (catégories + modèles)
-- Ajoute updated_at sur periodes
-- Renomme regime → regime_scolaire dans eleves
-- MySQL 8.0 compatible : pas de ADD COLUMN IF NOT EXISTS (non supporté par MySQL 8.0)

-- B6 : evenements.categorie
SET @col_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = 'calulis' AND TABLE_NAME = 'evenements' AND COLUMN_NAME = 'categorie');
SET @sql = IF(@col_exists = 0, 'ALTER TABLE evenements ADD COLUMN categorie VARCHAR(50) DEFAULT NULL COMMENT ''ferie, examen, national, scolaire, individuel, anniversaire''', 'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- B6 : evenements.est_modele
SET @col_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = 'calulis' AND TABLE_NAME = 'evenements' AND COLUMN_NAME = 'est_modele');
SET @sql = IF(@col_exists = 0, 'ALTER TABLE evenements ADD COLUMN est_modele INT DEFAULT 0', 'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- B7 : periodes.updated_at
SET @col_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = 'calulis' AND TABLE_NAME = 'periodes' AND COLUMN_NAME = 'updated_at');
SET @sql = IF(@col_exists = 0, 'ALTER TABLE periodes ADD COLUMN updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP', 'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- A11 : eleves.regime → regime_scolaire
SET @col_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = 'calulis' AND TABLE_NAME = 'eleves' AND COLUMN_NAME = 'regime');
SET @sql = IF(@col_exists > 0, 'ALTER TABLE eleves CHANGE COLUMN regime regime_scolaire VARCHAR(50) DEFAULT NULL', 'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- Si regime_scolaire n'existe pas du tout, l'ajouter
SET @col_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = 'calulis' AND TABLE_NAME = 'eleves' AND COLUMN_NAME = 'regime_scolaire');
SET @sql = IF(@col_exists = 0, 'ALTER TABLE eleves ADD COLUMN regime_scolaire VARCHAR(50) DEFAULT NULL', 'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
