/**
 * Calulis — Changelog (Nouveautés)
 * Résumé des nouveautés depuis la v1.0. À mettre à jour à CHAQUE release
 * (voir scripts/release-checklist.sh — étape « quoi de neuf »).
 * NOTE : utiliser l'apostrophe typographique ' (U+2019) dans les textes —
 * jamais l'apostrophe droite ' qui casse les chaînes JS.
 */
const Changelog = {
    /** Dernière version connue (mise à jour à chaque release) */
    latest: '1.12.1',
    /** Entrées de la plus récente à la plus ancienne */
    entries: [
        {
            version: '1.12.1', date: '28 septembre 2026',
            items: [
                'Correction importante : sur certains ordinateurs, Calulis pouvait refuser de démarrer après une mise à jour — c’est corrigé : l’installation prépare ses données jusqu’au bout, même sur une machine lente',
                'Nouveau : après une mise à jour, Calulis vérifie que l’application répond vraiment. Si ce n’est pas le cas, il revient automatiquement à la version précédente et vous prévient — vos données ne sont jamais touchées',
                'Sécurité : Calulis n’arrête plus les bases de données d’autres logiciels installés sur l’ordinateur (il ne s’arrête plus que lui-même)',
                'Nouveau : mode récupération « Calulis.exe --safe-mode » — sauvegarder vos données, exporter un rapport de diagnostic, réparer le lancement, sans démarrer l’application',
                'Nouveau : « Calulis.exe --diagnostic » fabrique une archive à envoyer au support (journaux, versions, état des services) : elle ne contient aucune donnée d’élève',
                'Mise à jour : la base de données est sauvegardée automatiquement avant chaque mise à jour',
            ],
        },
        {
            version: '1.12', date: '22 septembre 2026',
            items: [
                'Correction importante : Calulis démarre désormais sur un Windows « de base », même si le composant Microsoft Visual C++ n’a jamais été installé sur l’ordinateur — il est maintenant fourni avec Calulis (rien à télécharger, rien à installer)',
                'Nouveau : si un antivirus supprime des fichiers de Calulis, un message clair indique lesquels et comment y remédier, au lieu d’une erreur Windows incompréhensible',
                'Correction : sur un ordinateur lent, ou lors du tout premier démarrage, Calulis prend maintenant le temps nécessaire pour démarrer au lieu d’échouer au bout de quelques secondes',
                'Sécurité : Calulis n’est plus accessible depuis le réseau — l’application ne fonctionne que sur l’ordinateur, vos données d’élèves restent locales',
                'Correction : la mise à jour s’installe correctement quel que soit le logiciel utilisé pour ouvrir le fichier ZIP (certains outils créaient des dossiers incorrects)',
                'Statistiques : l’ancienneté dans le dispositif ULIS s’affiche maintenant en années et en mois (« 2 ans et 3 mois »), avec la répartition « Moins d’un an / 1 an / 2 ans / 3 ans / 4 ans et + »',
                'Listes : aperçu du PDF avant téléchargement (fidèle à l’impression), tableaux qui ne débordent plus de la page, en-tête et pied de liste modifiables, et tri en cliquant sur les colonnes',
            ],
        },
        {
            version: '1.11', date: '7 septembre 2026',
            items: [
                'Correction : l’impression « Jour · Élèves » ne coupe plus les élèves — les journées s’affichent entièrement, même à 13 élèves ou plus (tableau ajusté, légende des couleurs, police adaptée)',
                'Nouveau : pour les grandes classes, l’impression « Jour · Élèves » répartit automatiquement les élèves sur plusieurs pages (jusqu’à 16 par page)',
                'Correction : le tri par numéro d’élève est maintenant numérique (1, 2, 3, …, 10, 11), et les numéros s’affichent « 01, 02, … »',
                'Amélioration : les années passées en ULIS sont comptées précisément en mois (« 1 an et 5 mois », « 0 mois » pour le premier mois), en tenant compte des arrivées en cours d’année',
            ],
        },
        {
            version: '1.10.1', date: '3 septembre 2026',
            items: [
                'Correction : la création d’un nouvel élève fonctionne à nouveau (plus de message d’erreur à l’enregistrement)',
            ],
        },
        {
            version: '1.10', date: '3 septembre 2026',
            items: [
                'Correction : l’onglet « Classes » s’affiche à nouveau et vous pouvez modifier vos classes, sans message d’erreur',
                'Correction : l’impression « Jour · Élèves » retrouve la liste des élèves — vous pouvez à nouveau générer l’aperçu et imprimer vos journées',
            ],
        },
        {
            version: '1.0.9', date: '1 septembre 2026',
            items: [
                'Faites vos listes d’élèves en un clic : filtrez (niveau, classe, groupe, ULIS, cantine, transport, PAI, allergies, droit à l’image), cochez, choisissez les colonnes, et exportez en PDF paysage ou CSV',
                'Enregistrez des groupes d’élèves (ex. « Sortie piscine ») pour les réutiliser toute l’année',
                'Fiche de renseignements et fiche d’urgence imprimable pour un élève ou pour toute une liste (mention confidentielle)',
                'Suivi du droit à l’image par élève : autorisé, refusé, en attente, avec dates et document signé',
                'Les pauses sont plus simples : un bouton « Pause » dans l’agenda, et deux couleurs pour la récréation et le midi',
                'Calendrier scolaire corrigé : la dernière semaine de classe ne disparaît plus dans les vacances',
                'Correction : la fiche d’un élève s’ouvre à nouveau correctement',
            ],
        },
        {
            version: '1.0.8', date: '31 août 2026',
            items: [
                'Plusieurs enseignants par classe, avec leurs jours et leurs demi-journées (postes partagés)',
                'Copier un créneau sur plusieurs jours en une seule fois (ex. : un rituel tous les matins)',
                'Avertissement quand on colle un créneau sur une case déjà occupée',
                'Numéro pour chaque élève, affiché et utilisé pour classer le calendrier',
                'Correction de la propagation du modèle vers des semaines choisies',
                'Correction du déplacement de bloc de créneaux (tout le bloc se déplace)',
                'Adresse de signalement de bug réglable dans les Paramètres',
            ],
        },
        {
            version: '1.0.7', date: '27 août 2026',
            items: [
                'Mise à jour plus fiable : le lanceur peut se mettre à jour depuis un second serveur (pCloud) si le premier est indisponible',
                'Le lanceur se réduit dans la barre d’état système (en bas à droite) — Calulis continue de tourner',
                'Messages plus simples et plus rassurants, moins de jargon technique',
                'Un bouton « Vérifier la mise à jour » permet de rechercher une version sans redémarrer',
                'Les champs de saisie limitent automatiquement leur longueur (plus d’erreur « données non enregistrées »)',
                'Accessibilité améliorée : les champs sont correctement étiquetés pour les lecteurs d’écran',
            ],
        },
        {
            version: '1.0.6', date: '26 août 2026',
            items: [
                'Protection renforcée : vos données ne peuvent plus être modifiées par une page web externe (sécurité CSRF)',
                'Sauvegarde plus fiable : plus d’erreurs d’enregistrement mystérieuses quand un champ est trop long (ils sont tronqués proprement)',
                'Les erreurs techniques sont maintenant journalisées pour un dépannage plus rapide',
                'Correction de l’affichage de la version (1.0.5 s’affichait à tort)',
            ],
        },
        {
            version: '1.0.5', date: '26 août 2026',
            items: [
                'Rattachement d’un élève à une classe corrigé (l’enregistrement échouait avec une erreur de base de données)',
            ],
        },
        {
            version: '1.0.4', date: '19 août 2026',
            items: [
                'Messages d’erreur enfin compréhensibles : plus de « Internal Server Error », Calulis explique quoi faire',
                'Bouton « Signaler un bug » sur les écrans d’erreur (infos techniques envoyées à l’équipe)',
                'Lanceur : bouton « Copier le rapport », aide intégrée, erreurs de démarrage claires',
                'Le lanceur se met à jour automatiquement, comme l’application',
                'Version de l’application affichée + cette page « Quoi de neuf »',
            ],
        },
        {
            version: '1.0.3', date: '17 août 2026',
            items: [
                'Calendrier scolaire (vacances) réparé sur toutes les machines Windows',
                'Messages d’erreur qui guident (connexion, certificat, DNS…)',
                'Les pages se rafraîchissent correctement après chaque mise à jour',
            ],
        },
        {
            version: '1.0.2', date: '17 août 2026',
            items: [
                'Établissements : ensembles scolaires, statut public/privé',
                'Tous les niveaux : maternelle, élémentaire, collège (6e→3e), lycée, lycée professionnel',
                'Création d’élève guidée (bouton « + Créer » pour l’établissement manquant)',
            ],
        },
        {
            version: '1.0.1', date: '16 août 2026',
            items: [
                'Correction du bug « ID requis » (modification/suppression élève, adulte, classe)',
            ],
        },
        {
            version: '1.0.0', date: '10 août 2026',
            items: [
                'Première version portable, sans installation : élèves, emploi du temps, réunions, annuaire, impression PDF',
                'Mises à jour automatiques, sauvegarde/restauration des données',
            ],
        },
    ],
};