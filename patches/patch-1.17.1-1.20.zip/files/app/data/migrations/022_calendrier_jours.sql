-- Migration 022 : le CALENDRIER DE L'ANNÉE (décisions 8.1 à 8.5 et 15.2)
--
-- Pourquoi. Périodes, vacances et événements vivaient séparément : les périodes dans
-- periodes, les vacances dans les semaines, les événements dans evenements. La décision
-- 8.1 demande UN calendrier de l'année. Ce qui manquait, c'est le JOUR lui-même :
--   (1) un SEUL statut officiel par jour — scolaire, vacances, ferie, fermeture — qui
--       décide des calculs (15.2) ;
--   (2) plusieurs ACTIVITÉS officielles superposables sur une liste fermée — stage,
--       réunion, commémoration, sortie, banalisée, autre — à la journée ou à la
--       demi-journée, qui s'affichent sans rien calculer ;
--   (3) un COMMENTAIRE libre.
--
-- Ce qui est posé ici
--   jours_calendrier : une ligne par jour RENSEIGNÉ (pas une ligne par jour de l'année).
--                      Le statut absent se déduit des semaines de vacances et des jours
--                      fériés : on ne remplit pas 365 lignes pour ne rien dire.
--   jour_activites   : les activités superposables, avec demi-journée facultative.
--   evenements.uid_ics : l'identifiant du fichier .ics importé, pour qu'un même fichier
--                      importé deux fois ne crée pas de doublons (8.4).
--
-- Aucune donnée existante n'est modifiée.
--
-- ATTENTION : le lanceur de migrations découpe le fichier sur chaque point-virgule, y
-- compris dans les commentaires — ne jamais en mettre ailleurs qu'en fin d'instruction.

CREATE TABLE IF NOT EXISTS jours_calendrier (
  id int(11) NOT NULL AUTO_INCREMENT,
  date_jour date NOT NULL,
  statut varchar(20) DEFAULT NULL,
  commentaire text DEFAULT NULL,
  created_at timestamp NULL DEFAULT current_timestamp(),
  updated_at timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY uk_jours_calendrier_date (date_jour)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS jour_activites (
  id int(11) NOT NULL AUTO_INCREMENT,
  date_jour date NOT NULL,
  type varchar(30) NOT NULL,
  demi_journee varchar(10) DEFAULT NULL,
  libelle varchar(200) DEFAULT NULL,
  created_at timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  KEY idx_jour_activites_date (date_jour)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'evenements' AND COLUMN_NAME = 'uid_ics');
SET @sql := IF(@c = 0, 'ALTER TABLE evenements ADD COLUMN uid_ics VARCHAR(200) NULL AFTER est_modele', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @c := (SELECT COUNT(*) FROM information_schema.STATISTICS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'evenements' AND INDEX_NAME = 'uk_evenements_uid_ics');
SET @sql := IF(@c = 0, 'ALTER TABLE evenements ADD UNIQUE KEY uk_evenements_uid_ics (uid_ics)', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
