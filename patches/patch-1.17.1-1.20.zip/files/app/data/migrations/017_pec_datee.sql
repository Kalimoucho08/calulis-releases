-- Migration 017 : les prises en charge (PEC) sont DATÉES et rattachées à un adulte
-- (décisions 3.9, 3.11 et 15.3 du 27/10/2026)
--
-- Aujourd'hui une PEC est une ligne « à l'instant présent » : spécialité, organisme,
-- fréquence, lieu. Rien ne dit qu'elle a commencé en novembre et s'est arrêtée en mars,
-- et rien ne la relie à l'annuaire — le nom de l'intervenant est ressaisi à la main.
--
-- Ce qui est posé :
--   1. `adulte_id` : la PEC porte un adulte de l'annuaire (métier + structures suivent) ;
--   2. `date_debut` / `date_fin` : fin **ouverte** tant que ça dure. Une PEC qui enjambe
--      deux années apparaît dans les deux — c'est le principe général du 27/10 ;
--   3. `quitte_etablissement` : la prise en charge a lieu HORS de l'école (cabinet,
--      SESSAD…). Le créneau correspondant doit dire OÙ est l'élève, pas seulement avec qui.
--
-- Aucune colonne supprimée, aucune donnée modifiée hormis la reprise ci-dessous.

-- ── 1. Lien vers l'annuaire ─────────────────────────────────────────────────────────────────
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pec_eleves' AND COLUMN_NAME = 'adulte_id');
SET @sql := IF(@c = 0, 'ALTER TABLE pec_eleves ADD COLUMN adulte_id INT NULL AFTER eleve_id, ADD KEY idx_pec_adulte (adulte_id)', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @c := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = 'pec_eleves' AND CONSTRAINT_NAME = 'pec_ibfk_adulte');
SET @sql := IF(@c = 0, 'ALTER TABLE pec_eleves ADD CONSTRAINT pec_ibfk_adulte FOREIGN KEY (adulte_id) REFERENCES adultes (id) ON DELETE SET NULL', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ── 2. Les dates ────────────────────────────────────────────────────────────────────────────
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pec_eleves' AND COLUMN_NAME = 'date_debut');
SET @sql := IF(@c = 0, 'ALTER TABLE pec_eleves ADD COLUMN date_debut DATE NULL AFTER adulte_id', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pec_eleves' AND COLUMN_NAME = 'date_fin');
SET @sql := IF(@c = 0, 'ALTER TABLE pec_eleves ADD COLUMN date_fin DATE NULL COMMENT ''NULL = prise en charge encore en cours'' AFTER date_debut', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ── 3. Le lieu : dans l'établissement ou en dehors ─────────────────────────────────────────
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pec_eleves' AND COLUMN_NAME = 'quitte_etablissement');
SET @sql := IF(@c = 0, 'ALTER TABLE pec_eleves ADD COLUMN quitte_etablissement TINYINT(1) NOT NULL DEFAULT 0 AFTER lieu', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ── 4. Reprise : une date de début quand on peut la connaître ─────────────────────────────
-- On prend le début de SON année scolaire (la PEC était saisie « pour cette année-là »).
-- Quand la PEC n'a pas d'année, on laisse NULL : on n'invente pas une date.
UPDATE pec_eleves p
JOIN annees_scolaires a ON a.id = p.annee_scolaire_id
SET p.date_debut = a.date_debut
WHERE p.date_debut IS NULL;
