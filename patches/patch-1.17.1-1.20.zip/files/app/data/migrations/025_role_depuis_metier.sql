-- Migration 025 : la CLÉ TECHNIQUE du métier, pour les fiches déjà en base (R9)
--
-- Pourquoi. Depuis la migration 016, la fiche adulte écrit `metier` (libellé) et `roles`
-- (liste fermée) : elle n'écrit plus `role`, l'ancienne clé technique. Or cette clé porte
-- encore DEUX choses visibles : les filtres « Enseignants / Personnel / Autres » de la liste
-- des adultes, et la couleur d'un créneau d'emploi du temps. Un adulte créé depuis la 016 a
-- donc une cellule « Rôle » vide et tombe dans « Personnel », même s'il est enseignant
-- (constat R9 de l'audit du 27/10/2026).
--
-- Ce que fait cette migration : elle REMPLIT la clé quand elle est vide, en reprenant la
-- correspondance EXACTE de la migration 016, dans l'autre sens. Aucune valeur existante
-- n'est écrasée : la condition `role IS NULL OR role = ''` l'interdit.
--
-- Le code écrit désormais la clé à chaque création/modification (Adulte::roleDepuisMetier) :
-- cette reprise ne sert qu'aux fiches déjà présentes sur un poste.
--
-- ATTENTION : le lanceur de migrations découpe le fichier sur chaque point-virgule, y
-- compris dans les commentaires — ne jamais en mettre ailleurs qu'en fin d'instruction.

UPDATE adultes SET role = CASE
    WHEN LOWER(TRIM(metier)) = 'enseignant'         THEN 'enseignant'
    WHEN LOWER(TRIM(metier)) = 'aesh co'             THEN 'aeshco'
    WHEN LOWER(TRIM(metier)) = 'aesh individuel'     THEN 'aeshi'
    WHEN LOWER(TRIM(metier)) = 'aesh mutualisé'      THEN 'aeshm'
    WHEN LOWER(TRIM(metier)) = 'aesh mutualise'      THEN 'aeshm'
    WHEN LOWER(TRIM(metier)) = 'éducateur'           THEN 'educateur'
    WHEN LOWER(TRIM(metier)) = 'educateur'           THEN 'educateur'
    WHEN LOWER(TRIM(metier)) = 'assistant familial'  THEN 'assistant_familial'
    WHEN LOWER(TRIM(metier)) = 'spécialiste'         THEN 'specialiste'
    WHEN LOWER(TRIM(metier)) = 'specialiste'         THEN 'specialiste'
    WHEN LOWER(TRIM(metier)) = 'autre'               THEN 'autre'
    ELSE 'specialiste'
END
WHERE (role IS NULL OR role = '')
  AND metier IS NOT NULL
  AND TRIM(metier) <> '';
