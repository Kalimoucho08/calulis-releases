-- Migration 020 : les types de NOTES deviennent une DONNEE (decision 6.3)
--
-- Pourquoi. Les types de notes vivaient dans une constante PHP (NoteSuivi::TYPES) :
-- impossible d'ajouter « entretien famille », « bilan de periode » ou « reunion » sans
-- livrer une version. La decision 6.3 du 27/10 dit qu'ils deviennent configurables,
-- comme les types de documents depuis la 1.16 (migration 010).
--
-- Ce qui est cree ici
--   types_notes : cle (jamais modifiee), libelle (renommable), couleur, ordre, actif.
--   Les 5 types livrés jusqu'ici y sont amorces en INSERT IGNORE, donc rejouable.
--
-- Ce qui n'est pas touche
--   notes_suivi.type garde la CLE du type, jamais son libelle. Aucune note existante
--   n'est modifiee par cette migration.
--
-- ATTENTION : le lanceur de migrations decoupe le fichier sur chaque point-virgule, y
-- compris dans les commentaires : ne jamais mettre de point-virgule ailleurs qu'en fin
-- d'instruction.

CREATE TABLE IF NOT EXISTS types_notes (
  id int(11) NOT NULL AUTO_INCREMENT,
  cle varchar(50) NOT NULL,
  libelle varchar(120) NOT NULL,
  couleur varchar(20) NOT NULL DEFAULT 'neutre',
  ordre int(11) NOT NULL DEFAULT 0,
  actif tinyint(1) NOT NULL DEFAULT 1,
  created_at timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY uk_types_notes_cle (cle)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

INSERT IGNORE INTO types_notes (cle, libelle, couleur, ordre, actif) VALUES
  ('observation', 'Observation', 'observation', 1, 1),
  ('objectif', 'Objectif', 'objectif', 2, 1),
  ('reussite', 'Réussite', 'reussite', 3, 1),
  ('alerte', 'Alerte', 'alerte', 4, 1),
  ('action', 'Action', 'action', 5, 1);
