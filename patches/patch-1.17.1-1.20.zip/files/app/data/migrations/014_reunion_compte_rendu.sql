-- Migration 014 : ordre du jour, compte rendu et préconisations d'une réunion (26/10/2026)
--
-- Ces trois colonnes existent dans le dump canonique (calulis-vierge.sql) mais pas dans les
-- bases créées sans lui ; l'écran ne les lisait pas, donc elles restaient vides. On les ajoute
-- ici pour les bases existantes, et le modèle + l'écran les lisent désormais.
-- invites et presences restent pour un chantier séparé (listes structurées).
-- Chaque ajout est idempotent : la colonne n'est créée que si elle manque.

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'reunions' AND COLUMN_NAME = 'ordre_du_jour');
SET @sql := IF(@c = 0, 'ALTER TABLE reunions ADD COLUMN ordre_du_jour TEXT NULL AFTER documents_lies', 'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'reunions' AND COLUMN_NAME = 'compte_rendu');
SET @sql := IF(@c = 0, 'ALTER TABLE reunions ADD COLUMN compte_rendu TEXT NULL AFTER ordre_du_jour', 'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'reunions' AND COLUMN_NAME = 'preconisations');
SET @sql := IF(@c = 0, 'ALTER TABLE reunions ADD COLUMN preconisations TEXT NULL AFTER compte_rendu', 'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
