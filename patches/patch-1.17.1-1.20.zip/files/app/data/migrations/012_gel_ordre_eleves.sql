-- Calulis — 012 : geler l'ordre d'affichage actuel des colonnes élèves
--
-- L'emploi du temps triait les colonnes par classe, puis par numéro, puis par
-- `ordre` (app/js/components/agenda.js). Le glisser-déposer écrivait bien `ordre`,
-- mais ce tri l'écrasait au rechargement : l'ordre choisi ne tenait jamais.
--
-- À partir de la version suivante, l'écran ne lit plus que `ordre`. Pour qu'aucune
-- colonne ne saute au moment de la mise à jour, cette migration fige dans `ordre`
-- EXACTEMENT l'ordre affiché juste avant : classe, puis numéro, puis ordre, puis
-- nom et prénom (la même clé que le tri du navigateur). Les inactifs passent après.
--
-- Idempotente : le classement ne dépend pas de `ordre`… sauf en troisième clé, où
-- il ne fait que départager des numéros égaux — et ces valeurs sont alors déjà
-- rangées. Aucune donnée n'est supprimée.
UPDATE eleves e
JOIN (
    SELECT id,
           ROW_NUMBER() OVER (
               ORDER BY (actif = 1) DESC,
                        COALESCE(classe, ''),
                        COALESCE(numero, 0),
                        ordre,
                        nom,
                        prenom,
                        id
           ) - 1 AS rang
    FROM eleves
) r ON r.id = e.id
SET e.ordre = r.rang;
