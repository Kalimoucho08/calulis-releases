-- Migration 026 : les périodes ANCIENNES ne restent plus ouvertes (R13)
--
-- Pourquoi. La migration 015 a créé une période de classe par élève et par année, en
-- laissant `date_fin` à NULL — ce qui veut dire « période ENCORE OUVERTE ». Un élève qui a
-- trois années scolaires a donc reçu trois périodes ouvertes : la fiche affichait
-- « CE1 — du 01/09/2023 au aujourd'hui » pour une année terminée en juillet 2024, et
-- `EleveClasse::courante()` devait arbitrer entre plusieurs « ouvertes ».
--
-- Ce que fait cette migration : elle CLÔT chaque période à la date de FIN DE SON ANNÉE,
-- mais SEULEMENT quand cette année est terminée (est_active = 0 et date_fin < aujourd'hui).
-- Une période de l'année en cours, ou d'une année à venir, reste ouverte — c'est la vérité.
--
-- On n'invente aucune date : on écrit celle que l'année porte déjà. Rejouable sans effet
-- (une période close n'est plus NULL). Aucune ligne n'est supprimée.
--
-- La migration 015 n'est PAS modifiée : une migration publiée ne se réécrit jamais, sinon
-- deux postes migrés à des dates différentes n'ont plus le même schéma pour les mêmes
-- numéros de migration.
--
-- ATTENTION : le lanceur de migrations découpe le fichier sur chaque point-virgule, y
-- compris dans les commentaires — ne jamais en mettre ailleurs qu'en fin d'instruction.

UPDATE eleve_classes ec
JOIN annees_scolaires a ON a.id = ec.annee_scolaire_id
SET ec.date_fin = a.date_fin
WHERE ec.date_fin IS NULL
  AND a.est_active = 0
  AND a.date_fin IS NOT NULL
  AND a.date_fin < CURDATE();
