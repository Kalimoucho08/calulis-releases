-- Migration 023 : les MODÈLES DE LISTE (décisions 11.1 à 11.3)
--
-- Pourquoi. Les listes se refont chaque année (11.1), mais un MODÈLE — filtres + colonnes
-- + mise en page + tri — se conserve et se réapplique (11.2). Et un modèle ne contient
-- AUCUN élève (11.3) : on applique le modèle, puis on choisit les élèves de l'année.
--
-- Ce qui existait avant : la table groupes (nom, criteres, eleves_ids). Elle mélangeait le
-- modèle (criteres) et une sélection d'élèves (eleves_ids), et cette sélection n'était pas
-- rattachée à une année. On ne la supprime pas et on ne la modifie pas : on COPIE le nom et
-- les critères dans modeles_listes, sans les élèves.
--
-- Aucune donnée n'est supprimée. La reprise ne s'exécute qu'une fois (garde @deja).
--
-- ATTENTION : le lanceur de migrations découpe le fichier sur chaque point-virgule, y
-- compris dans les commentaires — ne jamais en mettre ailleurs qu'en fin d'instruction.

CREATE TABLE IF NOT EXISTS modeles_listes (
  id int(11) NOT NULL AUTO_INCREMENT,
  nom varchar(200) NOT NULL,
  contenu longtext DEFAULT NULL COMMENT 'JSON : filtres, colonnes, mise_en_page, tri',
  created_at timestamp NULL DEFAULT current_timestamp(),
  updated_at timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET @deja := (SELECT COUNT(*) FROM modeles_listes);
INSERT INTO modeles_listes (nom, contenu)
SELECT g.nom, g.criteres FROM groupes g
WHERE @deja = 0
  AND g.criteres IS NOT NULL
  AND TRIM(g.criteres) <> '';
