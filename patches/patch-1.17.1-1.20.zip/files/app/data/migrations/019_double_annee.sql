-- Migration 019 : les objets qui appartiennent à DEUX années (décisions 4.1, 6.1, 7.2)
--
-- Principe du 27/10 : « un objet a un début et une fin et compte dans les DEUX années ».
-- Une réunion de septembre créée en juin appartient à l'année où elle se tient ET à celle
-- où on l'a préparée. Une note s'archive sans disparaître. Une tâche fermée se lit dans
-- l'année de sa création comme dans celle de sa fermeture.
--
-- Ce qui est posé ici :
--   1. `reunions.annee_creation_id` : l'année de PRÉPARATION. L'année de réalisation n'est
--      pas stockée : elle se déduit de `date_reunion`, et c'est la même règle pour tout.
--   2. `notes_suivi.archivee` : une note archivée sort de l'affichage courant mais reste
--      trouvable (elle n'est jamais supprimée).
--   3. `taches.date_cloture` : la date de fermeture, d'où se déduit l'année de fermeture.
--
-- Aucune colonne supprimée. Reprise prudente : on ne fabrique aucune date de clôture.

-- ── 1. Réunions : l'année de création ───────────────────────────────────────────────────────
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'reunions' AND COLUMN_NAME = 'annee_creation_id');
SET @sql := IF(@c = 0, 'ALTER TABLE reunions ADD COLUMN annee_creation_id INT NULL AFTER eleve_id, ADD KEY idx_reunions_annee_creation (annee_creation_id)', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Reprise : l'année qui contient la DATE DE CRÉATION de la ligne. Si elle tombe hors de
-- toute année connue (base ancienne), on prend celle de la réunion — jamais une année inventée.
UPDATE reunions r
SET r.annee_creation_id = (
    SELECT a.id FROM annees_scolaires a
    WHERE DATE(r.created_at) BETWEEN a.date_debut AND a.date_fin
    ORDER BY a.date_debut DESC LIMIT 1
)
WHERE r.annee_creation_id IS NULL;

UPDATE reunions r
SET r.annee_creation_id = (
    SELECT a.id FROM annees_scolaires a
    WHERE r.date_reunion BETWEEN a.date_debut AND a.date_fin
    ORDER BY a.date_debut DESC LIMIT 1
)
WHERE r.annee_creation_id IS NULL;

-- ── 2. Notes : archiver sans supprimer ─────────────────────────────────────────────────────
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'notes_suivi' AND COLUMN_NAME = 'archivee');
SET @sql := IF(@c = 0, 'ALTER TABLE notes_suivi ADD COLUMN archivee TINYINT(1) NOT NULL DEFAULT 0 AFTER type', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ── 3. Tâches : la date de fermeture ───────────────────────────────────────────────────────
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'taches' AND COLUMN_NAME = 'date_cloture');
SET @sql := IF(@c = 0, 'ALTER TABLE taches ADD COLUMN date_cloture DATE NULL AFTER echeance', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- On NE remplit PAS date_cloture pour les tâches déjà terminées : la date réelle de
-- fermeture n'est pas dans la base. L'écran l'écrira à la prochaine fermeture, et les
-- anciennes lignes restent sans date plutôt qu'avec une date fausse.
