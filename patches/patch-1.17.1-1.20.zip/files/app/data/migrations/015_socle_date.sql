-- Migration 015 : le socle daté (27/10/2026) — décisions 3.3, 3.4, 3.7, 3.8
--
-- Ce que cette migration pose, et rien de plus :
--   1. `eleve_classes` : l'HISTOIRE datée de la classe d'un élève. `eleve_annees.classe_id`
--      reste la classe courante (des dizaines d'écrans la lisent) ; la période datée dit
--      « du 1er septembre au 30 novembre, puis à partir du 1er décembre » (décision 3.3).
--   2. `classe_enseignants` : période datée (l'enseignant change → on clôt et on ouvre).
--   3. `adultes` : date d'arrivée et date de départ (décision 3.8).
--   4. `adultes_etablissements` : période datée de l'appartenance à une structure.
--   5. `creneaux.adulte_id` : lien vers l'annuaire (décision 3.7), le texte `adulte` restant
--      en secours pour ce qui n'a pas pu être relié.
--
-- Aucune colonne supprimée, aucune donnée modifiée hormis ces ajouts et la reprise ci-dessous.
-- Tout est idempotent : rejouable sans effet sur une base déjà migrée.
--
-- ⚠ Dates au JOUR PRÈS (décision 15.1) : pas d'heure, pas de demi-journée.

-- ── 1. L'histoire datée de la classe ────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `eleve_classes` (
    `id` int(11) NOT NULL AUTO_INCREMENT,
    `eleve_id` int(11) NOT NULL,
    `classe_id` int(11) DEFAULT NULL,
    `annee_scolaire_id` int(11) DEFAULT NULL,
    `date_debut` date NOT NULL,
    `date_fin` date DEFAULT NULL COMMENT 'NULL = période encore ouverte',
    `created_at` timestamp NULL DEFAULT current_timestamp(),
    `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
    PRIMARY KEY (`id`),
    KEY `ec_eleve_idx` (`eleve_id`,`date_debut`),
    KEY `ec_annee_idx` (`annee_scolaire_id`),
    KEY `ec_classe_idx` (`classe_id`),
    CONSTRAINT `ec_ibfk_eleve` FOREIGN KEY (`eleve_id`) REFERENCES `eleves` (`id`) ON DELETE CASCADE,
    CONSTRAINT `ec_ibfk_classe` FOREIGN KEY (`classe_id`) REFERENCES `classes` (`id`) ON DELETE SET NULL,
    CONSTRAINT `ec_ibfk_annee` FOREIGN KEY (`annee_scolaire_id`) REFERENCES `annees_scolaires` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Reprise : une période ouverte par année et par élève, à la date de début de SON année.
-- On n'invente pas de changement en cours d'année : il n'existe pas dans les données.
INSERT INTO `eleve_classes` (`eleve_id`,`classe_id`,`annee_scolaire_id`,`date_debut`,`date_fin`)
SELECT ea.eleve_id, ea.classe_id, ea.annee_scolaire_id, a.date_debut, NULL
FROM `eleve_annees` ea
JOIN `annees_scolaires` a ON a.id = ea.annee_scolaire_id
WHERE ea.classe_id IS NOT NULL
  AND NOT EXISTS (SELECT 1 FROM `eleve_classes` ec
                  WHERE ec.eleve_id = ea.eleve_id
                    AND ec.annee_scolaire_id = ea.annee_scolaire_id);

-- ── 2. L'enseignant d'une classe est daté ──────────────────────────────────────────────────
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'classe_enseignants' AND COLUMN_NAME = 'date_debut');
SET @sql := IF(@c = 0, 'ALTER TABLE classe_enseignants ADD COLUMN date_debut DATE NULL AFTER adulte_id', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'classe_enseignants' AND COLUMN_NAME = 'date_fin');
SET @sql := IF(@c = 0, 'ALTER TABLE classe_enseignants ADD COLUMN date_fin DATE NULL AFTER date_debut', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
-- date_debut NULL = « affectation antérieure à la datation » : on ne fabrique pas une date
-- qu'aucune donnée ne porte. L'écran l'écrit « depuis l'origine », et le premier changement
-- enregistré clôt la période à sa date.

-- ── 3. Un adulte a des dates ───────────────────────────────────────────────────────────────
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'adultes' AND COLUMN_NAME = 'date_arrivee');
SET @sql := IF(@c = 0, 'ALTER TABLE adultes ADD COLUMN date_arrivee DATE NULL AFTER actif', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'adultes' AND COLUMN_NAME = 'date_depart');
SET @sql := IF(@c = 0, 'ALTER TABLE adultes ADD COLUMN date_depart DATE NULL AFTER date_arrivee', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- ── 4. L'appartenance d'un adulte à une structure est datée ───────────────────────────────
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'adultes_etablissements' AND COLUMN_NAME = 'date_debut');
SET @sql := IF(@c = 0, 'ALTER TABLE adultes_etablissements ADD COLUMN date_debut DATE NULL AFTER role', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'adultes_etablissements' AND COLUMN_NAME = 'date_fin');
SET @sql := IF(@c = 0, 'ALTER TABLE adultes_etablissements ADD COLUMN date_fin DATE NULL AFTER date_debut', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
-- La clé (adulte, établissement, année) est conservée : l'année sépare déjà deux périodes.
-- Partir et revenir dans la MÊME année reste donc impossible — cas qui ne s'est jamais
-- présenté, et qui vaut moins qu'une chirurgie de clé primaire sur une table en production.

-- ── 5. Le créneau pointe vers l'annuaire ───────────────────────────────────────────────────
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'creneaux' AND COLUMN_NAME = 'adulte_id');
SET @sql := IF(@c = 0, 'ALTER TABLE creneaux ADD COLUMN adulte_id INT NULL AFTER adulte, ADD KEY idx_creneaux_adulte (adulte_id)', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @c := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = 'creneaux' AND CONSTRAINT_NAME = 'creneaux_ibfk_adulte');
SET @sql := IF(@c = 0, 'ALTER TABLE creneaux ADD CONSTRAINT creneaux_ibfk_adulte FOREIGN KEY (adulte_id) REFERENCES adultes (id) ON DELETE SET NULL', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Reprise : on ne relie QUE ce qui est certain. Le texte d'un créneau est de la forme
-- « M. Dupont » (titre + nom, sans prénom). On le rapproche du nom d'un adulte, et seulement
-- s'il n'y a qu'UN adulte portant ce nom. Tout le reste reste NULL et la fiche le signale —
-- deviner un homonyme serait pire que ne rien relier.
-- Les titres sont écrits AVEC point dans les unes (« M. Dupont ») et SANS dans les autres
-- (« Mme Robert ») : les deux formes sont traitées, et un nom qui COMMENCE par « Dr » n'est pas
-- pris pour un titre (il faut le point ou l'espace après le titre).
UPDATE `creneaux` c
JOIN (
    SELECT c2.id AS cid, MIN(a.id) AS aid
    FROM `creneaux` c2
    JOIN `adultes` a
      ON UPPER(TRIM(a.nom)) = UPPER(TRIM(TRIM(LEADING '.' FROM TRIM(
            CASE
              WHEN UPPER(TRIM(c2.adulte)) LIKE 'MME.%'  THEN SUBSTRING(TRIM(c2.adulte), 4)
              WHEN UPPER(TRIM(c2.adulte)) LIKE 'MME %'  THEN SUBSTRING(TRIM(c2.adulte), 4)
              WHEN UPPER(TRIM(c2.adulte)) LIKE 'MLLE.%' THEN SUBSTRING(TRIM(c2.adulte), 5)
              WHEN UPPER(TRIM(c2.adulte)) LIKE 'MLLE %' THEN SUBSTRING(TRIM(c2.adulte), 5)
              WHEN UPPER(TRIM(c2.adulte)) LIKE 'M.%'    THEN SUBSTRING(TRIM(c2.adulte), 2)
              WHEN UPPER(TRIM(c2.adulte)) LIKE 'M %'    THEN SUBSTRING(TRIM(c2.adulte), 2)
              WHEN UPPER(TRIM(c2.adulte)) LIKE 'DR.%'   THEN SUBSTRING(TRIM(c2.adulte), 3)
              WHEN UPPER(TRIM(c2.adulte)) LIKE 'DR %'   THEN SUBSTRING(TRIM(c2.adulte), 3)
              ELSE TRIM(c2.adulte)
            END))))
    WHERE c2.adulte_id IS NULL
      AND c2.adulte IS NOT NULL AND TRIM(c2.adulte) <> ''
    GROUP BY c2.id
    HAVING COUNT(DISTINCT a.id) = 1
) m ON m.cid = c.id
SET c.adulte_id = m.aid
WHERE c.adulte_id IS NULL;
