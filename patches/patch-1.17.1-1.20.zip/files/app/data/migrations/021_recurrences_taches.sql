-- Migration 021 : les RÉCURRENCES des tâches (décision 7.3)
--
-- Pourquoi. Une tâche administrative revient au jour, à la semaine, à la fin d'une
-- période, à la fin ou au début de l'année. Jusqu'ici il fallait la recréer à la main.
-- Chaque occurrence est une VRAIE tâche : elle garde sa date, son statut et son année,
-- et une occurrence manquée n'est jamais effacée (décision 7.4) — on en voit deux et
-- on tranche à la main.
--
-- Ce qui est posé ici
--   taches.recurrence  : NULL (aucune) ou jour, semaine, fin_periode, fin_annee, debut_annee
--   taches.serie_id    : la tâche d'origine de la série (elle-même pour l'occurrence 0)
--   index UNIQUE (serie_id, echeance) : une seule occurrence par date et par série,
--   ce qui rend la génération rejouable sans jamais doubler une ligne.
--
-- Aucune tâche existante n'est modifiée : les anciennes restent sans récurrence.
--
-- ATTENTION : le lanceur de migrations découpe le fichier sur chaque point-virgule, y
-- compris dans les commentaires — ne jamais en mettre ailleurs qu'en fin d'instruction.

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'taches' AND COLUMN_NAME = 'recurrence');
SET @sql := IF(@c = 0, 'ALTER TABLE taches ADD COLUMN recurrence VARCHAR(20) NULL AFTER statut', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'taches' AND COLUMN_NAME = 'serie_id');
SET @sql := IF(@c = 0, 'ALTER TABLE taches ADD COLUMN serie_id INT NULL AFTER recurrence', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @c := (SELECT COUNT(*) FROM information_schema.STATISTICS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'taches' AND INDEX_NAME = 'uk_taches_serie_echeance');
SET @sql := IF(@c = 0, 'ALTER TABLE taches ADD UNIQUE KEY uk_taches_serie_echeance (serie_id, echeance)', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
