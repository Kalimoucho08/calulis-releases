-- Calulis — 013 : fusion facultative de créneaux en un seul bloc
--
-- L'emploi du temps peut afficher plusieurs créneaux comme UN SEUL bloc couvrant
-- plusieurs colonnes d'élèves (une professionnelle avec deux élèves, par exemple).
-- La fusion n'est JAMAIS automatique : elle est demandée à la création (case « un seul
-- bloc ») ou après coup (menu « Fusionner en un bloc »). `regroupement_id` ne fait que
-- porter ce choix : les lignes restent indépendantes (un élève par ligne), donc les
-- durées, les stats et l'impression par élève ne changent pas.
--
-- Aucune donnée n'est modifiée : les créneaux existants gardent regroupement_id = NULL.
-- GARDE D'IDEMPOTENCE : colonne et index ne sont créés que s'ils manquent (le test des
-- migrations rejoue le fichier).
SET @col = (SELECT COUNT(*) FROM information_schema.COLUMNS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'creneaux' AND COLUMN_NAME = 'regroupement_id');
SET @sql_col = IF(@col = 0,
    'ALTER TABLE `creneaux` ADD COLUMN `regroupement_id` VARCHAR(36) NULL DEFAULT NULL',
    'DO 1');
PREPARE stmt_col FROM @sql_col;
EXECUTE stmt_col;
DEALLOCATE PREPARE stmt_col;

SET @idx = (SELECT COUNT(*) FROM information_schema.STATISTICS
    WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'creneaux' AND INDEX_NAME = 'idx_creneaux_regroupement');
SET @sql_idx = IF(@idx = 0,
    'CREATE INDEX `idx_creneaux_regroupement` ON `creneaux` (`regroupement_id`)',
    'DO 1');
PREPARE stmt_idx FROM @sql_idx;
EXECUTE stmt_idx;
DEALLOCATE PREPARE stmt_idx;
