-- Migration 024 : « CE NE SONT PAS LES MÊMES PERSONNES » (décision 16.7)
--
-- Pourquoi. La décision 16.7 dit : quand l'utilisateur déclare que deux fiches du même nom
-- ne sont PAS la même personne, l'application ENREGISTRE la paire. Elle n'est plus proposée,
-- mais reste consultable.
--
-- Avant cette migration, aucune table, aucune colonne et aucune route ne stockait la paire :
-- l'écran fermait la fenêtre et la prochaine ouverture reproposait exactement les mêmes
-- fiches (constat R11 de l'audit du 27/10/2026). Une décision utilisateur qui ne laisse
-- aucune trace est une décision perdue.
--
-- La paire est ORDONNÉE (adulte_a < adulte_b) : deux lignes pour la même paire rendraient
-- l'exclusion dépendante du sens de lecture. Les deux clés étrangères effacent la décision
-- avec la fiche — si l'une des deux personnes disparaît, il n'y a plus de paire à exclure.
--
-- Aucune donnée n'est supprimée ni réécrite par cette migration.
--
-- ATTENTION : le lanceur de migrations découpe le fichier sur chaque point-virgule, y
-- compris dans les commentaires — ne jamais en mettre ailleurs qu'en fin d'instruction.

CREATE TABLE IF NOT EXISTS adultes_non_doublons (
  adulte_a int(11) NOT NULL,
  adulte_b int(11) NOT NULL,
  decide_le timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (adulte_a, adulte_b),
  KEY idx_nd_b (adulte_b),
  CONSTRAINT nd_ibfk_a FOREIGN KEY (adulte_a) REFERENCES adultes (id) ON DELETE CASCADE,
  CONSTRAINT nd_ibfk_b FOREIGN KEY (adulte_b) REFERENCES adultes (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
