-- Migration 018 : la SEMAINE TYPE appartient à une année (décisions 2.1 et 2.4)
--
-- Aujourd'hui la semaine type est UNE SEULE pour toute l'application : les créneaux
-- « modèle » sont ceux qui n'ont pas de semaine (`semaine_id IS NULL`), et ils ne portent
-- aucune année. Changer un modèle change donc 2023, 2024 et 2025 à la fois — ce que la
-- décision 2.1 refuse : « chaque année a sa propre semaine type, vierge ».
--
-- Ce qui est posé : `creneaux.annee_scolaire_id`, renseignée UNIQUEMENT pour les créneaux
-- modèles (semaine_id NULL). Pour une semaine réelle, l'année se lit déjà par `semaines`.
--
-- ⚠️ Cette migration PRÉPARE. Les lectures (Creneau::templateAll, templateForEleve,
-- copyFromTemplate) filtrent encore sur `semaine_id IS NULL` sans l'année : le prochain
-- pas les branche sur ce champ, sinon la colonne ne sert à rien.

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'creneaux' AND COLUMN_NAME = 'annee_scolaire_id');
SET @sql := IF(@c = 0, 'ALTER TABLE creneaux ADD COLUMN annee_scolaire_id INT NULL AFTER semaine_id, ADD KEY idx_creneaux_annee (annee_scolaire_id)', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

SET @c := (SELECT COUNT(*) FROM information_schema.TABLE_CONSTRAINTS
           WHERE CONSTRAINT_SCHEMA = DATABASE() AND TABLE_NAME = 'creneaux' AND CONSTRAINT_NAME = 'creneaux_ibfk_annee');
SET @sql := IF(@c = 0, 'ALTER TABLE creneaux ADD CONSTRAINT creneaux_ibfk_annee FOREIGN KEY (annee_scolaire_id) REFERENCES annees_scolaires (id) ON DELETE CASCADE', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Reprise : la semaine type existante est rattachée à l'ANNÉE ACTIVE. C'est un choix, et
-- il se dit : elle était commune, elle ne peut pas l'être restée. Si aucune année n'est
-- active, on la rattache à la plus récente — jamais à une année inventée.
UPDATE creneaux
SET annee_scolaire_id = (
    SELECT id FROM annees_scolaires ORDER BY est_active DESC, date_debut DESC LIMIT 1
)
WHERE semaine_id IS NULL AND annee_scolaire_id IS NULL;
