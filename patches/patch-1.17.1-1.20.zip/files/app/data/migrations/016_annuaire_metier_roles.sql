-- Migration 016 : l'annuaire — un MÉTIER, des STRUCTURES, des RÔLES (décision 15.6)
--
-- Le défaut que cette migration enlève : `adultes` impose UNIQUE(nom, role). Pour noter
-- qu'une personne est enseignante ET coordinatrice, l'application n'a donc pas d'autre
-- choix que de créer DEUX fiches au même nom — et l'emploi du temps, les PEC et les
-- réunions peuvent ensuite pointer sur l'une ou l'autre.
--
-- Ce qui est posé :
--   1. `adultes.metier` : UNE valeur (Enseignant, AESH, Orthophoniste…), déduite du
--      couple role/specialite existant ;
--   2. `adultes_roles` : plusieurs rôles par personne (Coordonnateur ULIS, Directeur…) ;
--   3. la contrainte UNIQUE(nom, role) est SUPPRIMÉE — une personne, une fiche ;
--   4. les rôles connus sont repris de `fonction` (directeur, coordo_ulis).
--
-- `role` et `fonction` ne sont PAS supprimés : les écrans les lisent encore, et une
-- colonne qu'on garde ne casse rien. Ils disparaîtront quand plus rien ne les lira.
-- Aucun doublon n'est fusionné ici : on ne décide pas à la place de l'utilisateur
-- quelle fiche garde les liens (voir `adultes.php?doublons=1`).

-- ── 1. Le métier ────────────────────────────────────────────────────────────────────────────
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'adultes' AND COLUMN_NAME = 'metier');
SET @sql := IF(@c = 0, 'ALTER TABLE adultes ADD COLUMN metier VARCHAR(50) NULL AFTER specialite', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;

-- Reprise : le métier se déduit de ce qui existe. Pour un « specialiste », c'est sa
-- spécialité qui dit le métier (orthophoniste, psychomotricien…) ; on ne l'invente pas
-- quand elle est vide : on écrit « Spécialiste » et l'écran demande de préciser.
UPDATE adultes SET metier = CASE
    WHEN role = 'enseignant'         THEN 'Enseignant'
    WHEN role = 'coordo_ulis'        THEN 'Enseignant'
    WHEN role = 'aeshco'             THEN 'AESH Co'
    WHEN role = 'aeshi'              THEN 'AESH Individuel'
    WHEN role = 'aeshm'              THEN 'AESH Mutualisé'
    WHEN role = 'educateur'          THEN 'Éducateur'
    WHEN role = 'assistant_familial' THEN 'Assistant familial'
    WHEN role = 'specialiste'        THEN COALESCE(NULLIF(TRIM(specialite), ''), 'Spécialiste')
    ELSE COALESCE(NULLIF(TRIM(role), ''), 'Autre')
END
WHERE metier IS NULL OR metier = '';

-- ── 2. Les rôles ────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS `adultes_roles` (
    `adulte_id` int(11) NOT NULL,
    `role` varchar(50) NOT NULL,
    `created_at` timestamp NULL DEFAULT current_timestamp(),
    PRIMARY KEY (`adulte_id`,`role`),
    CONSTRAINT `ar_ibfk_adulte` FOREIGN KEY (`adulte_id`) REFERENCES `adultes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Reprise : les deux fonctions connues deviennent des rôles nommés. Les autres valeurs
-- de `fonction` restent dans leur colonne — on ne les transforme pas en rôle de force.
INSERT IGNORE INTO adultes_roles (adulte_id, role)
SELECT id, 'Coordonnateur ULIS' FROM adultes WHERE fonction = 'coordo_ulis'
UNION
SELECT id, 'Directeur' FROM adultes WHERE fonction = 'directeur';

-- ── 3. Une personne = une fiche ─────────────────────────────────────────────────────────────
-- La contrainte s'appelle « nom » (MySQL nomme l'index d'après sa première colonne).
SET @c := (SELECT COUNT(*) FROM information_schema.STATISTICS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'adultes'
             AND INDEX_NAME = 'nom' AND NON_UNIQUE = 0);
SET @sql := IF(@c > 0, 'ALTER TABLE adultes DROP INDEX nom', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
-- On garde un index simple sur le nom : il sert aux recherches, il n'interdit plus rien.
SET @c := (SELECT COUNT(*) FROM information_schema.STATISTICS
           WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'adultes'
             AND INDEX_NAME = 'idx_adultes_nom');
SET @sql := IF(@c = 0, 'ALTER TABLE adultes ADD KEY idx_adultes_nom (nom)', 'DO 1');
PREPARE stmt FROM @sql; EXECUTE stmt; DEALLOCATE PREPARE stmt;
