<?php
/** Calulis — Controller Migrations
 *
 *  GET  /api/migrate        → état des migrations (status)
 *  POST /api/migrate        → exécute les migrations en attente
 *  POST /api/migrate/seed   → enregistre toutes les migrations existantes comme appliquées
 *                             (après un import de base de démonstration)
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Migration.php';

$method = $_SERVER['REQUEST_METHOD'];
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);

try {
    $migration = new Migration();

    // POST /api/migrate/seed — enregistre tout comme appliqué
    if ($method === 'POST' && preg_match('#^/api/migrate/seed$#', $uri)) {
        $all = $migration->status();
        $registered = 0;
        foreach ($all['migrations'] as $m) {
            if (!$m['applied']) {
                $migration->registerApplied($m['version'], $m['filename']);
                $registered++;
            }
        }
        jsonResponse(['ok' => true, 'registered' => $registered, 'message' => "$registered migration(s) marquée(s) comme appliquée(s)"]);
    }

    // GET /api/migrate — état
    if ($method === 'GET') {
        jsonResponse($migration->status());
    }

    // POST /api/migrate — exécute
    if ($method === 'POST') {
        $result = $migration->run();
        // Un verrou indisponible n'est PAS un succès : rien n'a été appliqué. Répondre
        // 200 faisait croire le schéma à jour alors que les migrations étaient toujours
        // en attente (défaut relevé le 26/10/2026). 503 + un message clair permettent
        // à l'appelant de réessayer.
        if (($result['verrou'] ?? true) === false) {
            jsonResponse([
                'error'  => 'Migration non exécutée : une autre requête la tient. Réessayez dans quelques secondes.',
                'result' => $result,
            ], 503);
        }
        $code = $result['errors'] > 0 ? 500 : 200;
        jsonResponse($result, $code);
    }

    jsonError('Méthode non supportée', 405);

} catch (\Throwable $e) {
    jsonError('Erreur migration : ' . $e->getMessage(), 500);
}
