<?php
/** Calulis — Controller Calendrier Scolaire
 *  GET /api/calendrier-scolaire.php?annee=2026-2027&zone=Zone+B
 *  Retourne les périodes de vacances depuis data.education.gouv.fr
 *
 *  POST /api/calendrier-scolaire.php
 *  Body: { "annee_scolaire_id": 1, "zone": "Zone B" }
 *  Génère les semaines (scolaires + vacances) pour l'année
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/JourCalendrier.php';

$method = $_SERVER['REQUEST_METHOD'];

try {
    if ($method === 'GET') {
        $annee = $_GET['annee'] ?? '2026-2027';
        $zone = $_GET['zone'] ?? 'Zone B';
        $vacances = _fetch_vacances($annee, $zone);
        jsonResponse($vacances);
    }

    if ($method === 'POST') {
        $input = json_decode(file_get_contents('php://input'), true);
        $anneeId = $input['annee_scolaire_id'] ?? null;
        $zone = $input['zone'] ?? 'Zone B';

        if (!$anneeId) jsonError('annee_scolaire_id requis');

        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT nom, date_debut, date_fin FROM annees_scolaires WHERE id = :id");
        $stmt->execute(['id' => (int)$anneeId]);
        $annee = $stmt->fetch();
        if (!$annee) jsonError('Année scolaire introuvable', 404);

        // Refus AVANT tout geste : une année qui a déjà des semaines n'est jamais écrasée.
        // Requête PRÉPARÉE : $anneeId vient du corps JSON et ne doit jamais entrer dans le SQL
        // par interpolation (revue du 28/10/2026 — la même valeur était déjà castée plus haut).
        $stmtNb = $pdo->prepare("SELECT COUNT(*) FROM semaines WHERE annee_scolaire_id = :id");
        $stmtNb->execute(['id' => (int)$anneeId]);
        $nb = (int)$stmtNb->fetchColumn();
        if ($nb > 0) {
            jsonError("L'année « {$annee['nom']} » a déjà $nb semaines. Utilisez le bouton « + Nouvelle année scolaire » pour créer une année vierge, puis importez le calendrier dessus.", 409);
        }
        $vacances = _fetch_vacances($annee['nom'], $zone);
        // La génération vit dans le MODÈLE (règle métier) : le contrôleur la valide et répond.
        $res = JourCalendrier::genererSemaines($anneeId, $annee, $vacances);

        jsonResponse([
            'ok' => true,
            'semaines_creees' => $res['semaines'],
            'jours_feries' => $res['jours_feries'],
            'vacances' => $vacances,
        ]);
    }

    if ($method === 'DELETE') {
        $anneeId = (int)($_GET['annee_scolaire_id'] ?? 0);
        if (!$anneeId) jsonError('annee_scolaire_id requis');
        $pdo = getDB();
        // Supprimer les créneaux liés aux semaines de cette année (sinon liens orphelins)
        $ids = $pdo->query("SELECT id FROM semaines WHERE annee_scolaire_id = $anneeId")->fetchAll(PDO::FETCH_COLUMN);
        if ($ids) {
            $pdo->exec("DELETE FROM creneaux WHERE semaine_id IN (" . implode(',', array_map('intval', $ids)) . ")");
        }
        $nb = $pdo->exec("DELETE FROM semaines WHERE annee_scolaire_id = $anneeId");
        jsonResponse(['ok' => true, 'semaines_supprimees' => $nb]);
    }

    jsonError('Méthode non supportée', 405);
} catch (\Throwable $e) {
    calulis_handle_error($e);
}

function _fetch_vacances(string $anneeScolaire, string $zone): array {
    // L'API attend « 2026-2027 » alors que le nom d'année en base peut être « 2026 2027 »
    // (espace). On normalise en remplaçant les espaces par des tirets.
    $anneeApi = preg_replace('/\s+/', '-', trim($anneeScolaire));
    $url = 'https://data.education.gouv.fr/api/explore/v2.1/catalog/datasets/fr-en-calendrier-scolaire/records?'
         . 'limit=100&refine=zones:' . urlencode($zone)
         . '&refine=annee_scolaire:' . urlencode($anneeApi);

    // CA bundle embarqué : le PHP portable sous Windows n'utilise pas le
    // magasin de certificats du système. (L'extension openssl doit aussi
    // être activée dans frankenphp/php.ini.)
    $cafile = dirname(__DIR__, 2) . '/data/cacert.pem';
    $context = stream_context_create([
        'ssl' => [
            'cafile' => $cafile,
            'verify_peer' => true,
            'verify_peer_name' => true,
        ],
        'http' => [
            'timeout' => 20,
            'user_agent' => 'Calulis/1.0',
            'ignore_errors' => true,
            'header' => "Accept: application/json\r\n",
        ],
    ]);

    $json = @file_get_contents($url, false, $context);
    if ($json === false) {
        $detail = error_get_last()['message'] ?? 'erreur inconnue';
        // Traduire les causes techniques en messages actionnables
        if (stripos($detail, 'wrapper') !== false) {
            $detail = 'module HTTPS de PHP manquant — appliquez la dernière mise à jour';
        } elseif (stripos($detail, 'SSL') !== false || stripos($detail, 'certificate') !== false
                  || stripos($detail, 'operation failed') !== false) {
            $detail = 'connexion sécurisée impossible (certificat SSL)';
        } elseif (stripos($detail, 'getaddrinfo') !== false || stripos($detail, 'resolve') !== false) {
            $detail = 'site du ministère introuvable (DNS)';
        } elseif (stripos($detail, 'timed out') !== false) {
            $detail = 'délai dépassé (site trop lent)';
        }
        throw new \RuntimeException('API calendrier injoignable — ' . $detail
            . '. Vérifiez la connexion internet, puis réessayez.');
    }

    // Code HTTP (populé grâce à ignore_errors)
    $status = 0;
    foreach ($http_response_header ?? [] as $h) {
        if (preg_match('#^HTTP/\S+\s+(\d{3})#', $h, $m)) { $status = (int)$m[1]; break; }
    }
    if ($status >= 400) {
        throw new \RuntimeException('API calendrier indisponible (HTTP ' . $status . '). Réessayez plus tard.');
    }

    $data = json_decode($json, true);
    if (empty($data['results'])) throw new \RuntimeException('Aucune donnée pour ' . $anneeScolaire . ' / ' . $zone);

    // Dédupliquer par description
    $seen = [];
    $vacances = [];
    foreach ($data['results'] as $r) {
        $desc = $r['description'];
        $start = substr($r['start_date'], 0, 10);
        $end = substr($r['end_date'], 0, 10);

        // Ignorer les entrées "enseignants" et les dates d'1 jour sans fin
        if (stripos($desc, 'enseignant') !== false) continue;

        if (!isset($seen[$desc])) {
            $seen[$desc] = true;
            $vacances[] = ['description' => $desc, 'date_debut' => $start, 'date_fin' => $end];
        }
    }

    return $vacances;
}

