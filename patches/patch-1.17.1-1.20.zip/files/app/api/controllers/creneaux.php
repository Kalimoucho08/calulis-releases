<?php
/** Calulis — Controller Créneaux */
require_once __DIR__ . '/../models/Creneau.php';
require_once __DIR__ . '/../models/Semaine.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$semaineId = isset($_GET['semaine_id']) ? ($_GET['semaine_id'] === 'null' ? null : (int)$_GET['semaine_id']) : null;

try {
    switch ($method) {
        case 'GET':
            if ($id) {
                // Créneau individuel — pas implémenté, on passe par findBySemaine
                jsonResponse([]);
            }
            if (!empty($_GET['adulte'])) {
                jsonResponse(Creneau::findByAdulte($_GET['adulte'], $semaineId));
            }
            if (!empty($_GET['with_eleves'])) {
                jsonResponse(Creneau::findBySemaineWithEleves($semaineId));
            }
            jsonResponse(Creneau::findBySemaine($semaineId));

            break;
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            // Batch : copier depuis template vers semaine(s)
            if (isset($input['action']) && $input['action'] === 'copy_from_template') {
                if (isset($input['semaine_ids']) && is_array($input['semaine_ids'])) {
                    // Copie batch vers plusieurs semaines
                    $today = date('Y-m-d');
                    // Décision 2.6 : par défaut on N'ÉCRASE PAS une semaine retouchée ;
                    // l'appelant envoie ecraser:1 quand l'utilisateur l'a explicitement choisi.
                    // R22 (audit du 27/10/2026) : le commentaire disait « par défaut on
                    // N'ÉCRASE PAS » mais le code écrasait quand la clé manquait. Le défaut
                    // est maintenant celui qui est écrit : un appelant qui ne parle pas
                    // d'écrasement ne détruit rien. Les deux écrans envoient la valeur.
                    $ecraser = filter_var($input['ecraser'] ?? false, FILTER_VALIDATE_BOOLEAN);
                    $counts = [];
                    $ignorees = [];
                    $passees = [];
                    foreach ($input['semaine_ids'] as $sid) {
                        $semaine = Semaine::find((int)$sid);
                        if (!$semaine) { continue; }
                        // Décision 2.5 : la propagation va vers l'avant seulement.
                        if ($semaine['date_fin'] < $today) { $passees[] = (int)$sid; continue; }
                        $n = Creneau::copyFromTemplate((int)$sid, $ecraser);
                        if ($n === -1) { $ignorees[] = (int)$sid; } else { $counts[] = $n; }
                    }
                    jsonResponse([
                        'ok' => true,
                        'count' => array_sum($counts),
                        'semaines' => count($counts),
                        'ignorees' => $ignorees,
                        'passees' => $passees,
                    ]);
                } else {
                    $count = Creneau::copyFromTemplate((int)$input['semaine_id']);
                    jsonResponse(['ok' => true, 'count' => $count]);
                }
            }
            // Création individuelle
            if (empty($input['eleve_id']) || empty($input['jour']) || empty($input['heure_debut'])) {
                jsonError('eleve_id, jour et heure_debut requis');
            }
            $id = Creneau::create($input);
            jsonResponse(['ok' => true, 'id' => $id], 201);

            break;
        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            // Fusion / séparation facultative d'un bloc (plusieurs créneaux, un seul choix)
            if (($input['action'] ?? '') === 'regroupement') {
                $ids = array_map('intval', (array)($input['ids'] ?? []));
                if (!$ids) jsonError('ids requis');
                $token = isset($input['regroupement_id']) && $input['regroupement_id'] !== ''
                    ? substr((string)$input['regroupement_id'], 0, 36) : null;
                jsonResponse(['ok' => true, 'modifies' => Creneau::setRegroupement($ids, $token)]);
            }
            if (!$id) jsonError('ID requis');
            Creneau::update($id, $input);
            jsonResponse(['ok' => true]);

            break;
        case 'DELETE':
            if (!$id) jsonError('ID requis');
            Creneau::delete($id);
            jsonResponse(['ok' => true]);

            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
