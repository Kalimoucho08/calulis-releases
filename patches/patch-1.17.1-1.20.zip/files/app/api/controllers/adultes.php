<?php
/** Calulis — Controller Adultes */
require_once __DIR__ . '/../models/Adulte.php';
require_once __DIR__ . '/../models/AdulteEtablissement.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;
$anneeId = isset($_GET['annee_scolaire_id']) ? (int)$_GET['annee_scolaire_id'] : null;

try {
    switch ($method) {

        case 'GET':
            // Détection des fiches en double (même nom, même prénom) — LECTURE seule.
            if (!empty($_GET['doublons'])) {
                $groupes = Adulte::doublons();
                jsonResponse(['groupes' => $groupes, 'nombre' => count($groupes)]);
            }
            if ($id) {
                $a = Adulte::find($id);
                if (!$a) jsonError('Adulte non trouvé', 404);
                $a['liens_etablissements'] = AdulteEtablissement::getByAdulte($id, $anneeId);
                jsonResponse($a);
            }
            // Filtres phase 8 : enseignant_notre, personnel_notre, autres
            $filtre = $_GET['filtre'] ?? '';
            $notreEtab = !empty($_GET['notre_etablissement']) ? (int)$_GET['notre_etablissement'] : null;
            $q = $_GET['q'] ?? '';
            if ($filtre && $notreEtab) {
                $adultes = Adulte::getFiltered($filtre, $notreEtab, $q ?: null);
            } elseif ($q) {
                $adultes = Adulte::search($q);
            } else {
                $adultes = Adulte::all();
            }
            // Attacher les liens établissements en une seule requête (évite N+1)
            $ids = array_map('intval', array_column($adultes, 'id'));
            $liens = AdulteEtablissement::getByAdulteIds($ids, $anneeId);
            foreach ($adultes as &$a) {
                $a['liens_etablissements'] = $liens[(int)$a['id']] ?? [];
            }
            jsonResponse($adultes);

            break;
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            // Crée les fiches des adultes cités dans l'emploi du temps (action explicite)
            if (($input['action'] ?? '') === 'sync_creneaux') {
                jsonResponse(['ok' => true, 'crees' => Adulte::syncFromCreneaux()]);
            }
            // Fusion de deux fiches qui désignent la même personne (§ 16). Les DEUX
            // identifiants doivent être désignés : aucun défaut, aucune fusion implicite.
            if (($input['action'] ?? '') === 'fusionner') {
                $garder = (int)($input['garder'] ?? 0);
                $fusionner = (int)($input['fusionner'] ?? 0);
                if ($garder <= 0 || $fusionner <= 0 || $garder === $fusionner) {
                    jsonError('Indiquez deux fiches différentes : celle à garder et celle à fusionner.', 400);
                }
                // Une fiche introuvable est une ERREUR DE SAISIE (400), pas une panne (500).
                try {
                    $resultat = Adulte::fusionner($garder, $fusionner);
                } catch (\InvalidArgumentException $e) {
                    jsonError($e->getMessage(), 400);
                }
                jsonResponse(['ok' => true] + $resultat);
            }
            // Décision 16.7 : « ce ne sont pas les mêmes personnes » ENREGISTRE la paire.
            // Elle n'est plus proposée, mais reste consultable (table adultes_non_doublons).
            if (($input['action'] ?? '') === 'non_doublons') {
                $a = (int)($input['a'] ?? $input['garder'] ?? 0);
                $b = (int)($input['b'] ?? $input['fusionner'] ?? 0);
                if ($a <= 0 || $b <= 0 || $a === $b) {
                    jsonError('Indiquez deux fiches différentes.', 400);
                }
                try {
                    Adulte::declarerNonDoublons($a, $b);
                } catch (\InvalidArgumentException $e) {
                    jsonError($e->getMessage(), 400);
                }
                jsonResponse(['ok' => true]);
            }
            if (empty($input['nom'])) jsonError('Nom requis');
            $id = Adulte::create($input);
            // Sync junction table
            if (isset($input['liens_etablissements'])) {
                $bodyAnneeId = $input['annee_scolaire_id'] ?? $anneeId;
                AdulteEtablissement::syncForAdulte($id, $input['liens_etablissements'], $bodyAnneeId);
            }
            jsonResponse(['ok' => true, 'id' => $id], 201);

            break;
        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            if (($input['action'] ?? '') === 'reorder' && !empty($input['ordres'])) {
                Adulte::reorder($input['ordres']);
                jsonResponse(['ok' => true]);
            }
            if (!$id) jsonError('ID requis');
            Adulte::update($id, $input);
            // Sync junction table
            if (isset($input['liens_etablissements'])) {
                $bodyAnneeId = $input['annee_scolaire_id'] ?? $anneeId;
                AdulteEtablissement::syncForAdulte($id, $input['liens_etablissements'], $bodyAnneeId);
            }
            jsonResponse(['ok' => true]);

            break;
        case 'DELETE':
            if (!$id) jsonError('ID requis');
            $pdo = getDB();
            $stmt = $pdo->prepare('UPDATE adultes SET actif = 0 WHERE id = :id');
            $stmt->execute(['id' => $id]);
            jsonResponse(['ok' => true]);

            break;
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
