<?php
/**
 * Calulis — Controller « Calendrier de l'année » (décisions 8.1 à 8.5)
 *
 *   GET    /api/calendrier.php?annee_scolaire_id=N     l'année entière : jours renseignés,
 *                                                      activités, événements, vacances
 *   POST   /api/calendrier.php?action=jour             { date, statut, commentaire }
 *                                                      + date_fin facultative = période
 *   POST   /api/calendrier.php?action=activite         { date, type, demi_journee, libelle }
 *   PUT    /api/calendrier.php?action=activite&id=N    les champs à modifier
 *   DELETE /api/calendrier.php?action=activite&id=N
 *   POST   /api/calendrier.php?action=importer-ics     { contenu, annee_scolaire_id }
 *
 * Le statut d'un jour est UN SEUL (scolaire, vacances, ferie, fermeture) et il décide des
 * calculs ; les activités sont superposables et ne calculent rien (décision 15.2).
 */
require_once __DIR__ . '/../models/JourCalendrier.php';

$method = $_SERVER['REQUEST_METHOD'];
$action = (string)($_GET['action'] ?? '');
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

/** Corps JSON de la requête. */
function calendrier_entree(): array
{
    $json = json_decode((string)file_get_contents('php://input'), true);
    return is_array($json) ? $json : [];
}

try {
    switch ($method) {

        case 'GET':
            $anneeId = (int)($_GET['annee_scolaire_id'] ?? 0);
            if ($anneeId <= 0) {
                jsonError('annee_scolaire_id requis', 400);
            }
            if (JourCalendrier::anneeScolaire($anneeId) === null) {
                jsonError('Année scolaire introuvable', 404);
            }
            jsonResponse(JourCalendrier::annee($anneeId));
            break;

        case 'POST':
            $entree = calendrier_entree();

            if ($action === 'importer-ics') {
                $anneeId = isset($entree['annee_scolaire_id']) && $entree['annee_scolaire_id'] !== ''
                    ? (int)$entree['annee_scolaire_id'] : null;
                $res = JourCalendrier::importerIcs((string)($entree['contenu'] ?? ''), $anneeId);
                jsonResponse(['ok' => true] + $res, 201);
            }

            if ($action === 'activite') {
                $nouvelId = JourCalendrier::ajouterActivite($entree);
                jsonResponse(['ok' => true, 'id' => $nouvelId], 201);
            }

            // Action par défaut : le statut et le commentaire du jour — ou de plusieurs
            // jours d'affilée quand une date de fin est donnée (une semaine de vacances).
            $date = (string)($entree['date'] ?? '');
            $fin = trim((string)($entree['date_fin'] ?? ''));
            if ($fin !== '' && $fin !== $date) {
                $n = JourCalendrier::definirPlage($date, $fin, $entree['statut'] ?? null, $entree['commentaire'] ?? null);
                jsonResponse(['ok' => true, 'jours_ecrits' => $n]);
            }
            $jour = JourCalendrier::definir($date, $entree['statut'] ?? null, $entree['commentaire'] ?? null);
            jsonResponse(['ok' => true, 'jour' => $jour]);
            break;

        case 'PUT':
            if ($action !== 'activite' || $id <= 0) {
                jsonError('Identifiant d\'activité manquant', 400);
            }
            if (!JourCalendrier::modifierActivite($id, calendrier_entree())) {
                jsonError('Activité non trouvée', 404);
            }
            jsonResponse(['ok' => true, 'id' => $id]);
            break;

        case 'DELETE':
            if ($action !== 'activite' || $id <= 0) {
                jsonError('Identifiant d\'activité manquant', 400);
            }
            if (!JourCalendrier::supprimerActivite($id)) {
                jsonError('Activité non trouvée', 404);
            }
            jsonResponse(['ok' => true, 'id' => $id]);
            break;

        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (InvalidArgumentException $e) {
    jsonError($e->getMessage(), 400);
} catch (\Throwable $e) {
    calulis_handle_error($e);
}