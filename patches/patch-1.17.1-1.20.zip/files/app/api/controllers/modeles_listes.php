<?php
/**
 * Calulis — Controller « Modèles de liste » (décisions 11.1 à 11.3 du 27/10/2026)
 *
 *   GET    /api/modeles_listes.php          la liste, contenu décodé (objet JSON)
 *   GET    /api/modeles_listes.php?id=N     un modèle
 *   POST   /api/modeles_listes.php          { nom, contenu }
 *   PUT    /api/modeles_listes.php?id=N     { nom?, contenu? } — envoi partiel accepté
 *   DELETE /api/modeles_listes.php?id=N
 *
 * Un modèle ne contient JAMAIS d'élève : aucune route n'accepte de sélection.
 */
require_once __DIR__ . '/../models/ModeleListe.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

function modeles_listes_entree(): array
{
    $json = json_decode((string)file_get_contents('php://input'), true);
    return is_array($json) ? $json : [];
}

try {
    switch ($method) {

        case 'GET':
            if ($id > 0) {
                $modele = ModeleListe::find($id);
                if (!$modele) jsonError('Modèle de liste non trouvé', 404);
                jsonResponse($modele);
            }
            jsonResponse(ModeleListe::all());
            break;

        case 'POST':
            $nouvelId = ModeleListe::create(modeles_listes_entree());
            jsonResponse(['ok' => true, 'id' => $nouvelId], 201);
            break;

        case 'PUT':
            if ($id <= 0) jsonError('Identifiant du modèle manquant', 400);
            if (!ModeleListe::update($id, modeles_listes_entree())) {
                jsonError('Modèle de liste non trouvé', 404);
            }
            jsonResponse(['ok' => true, 'id' => $id]);
            break;

        case 'DELETE':
            if ($id <= 0) jsonError('Identifiant du modèle manquant', 400);
            if (!ModeleListe::delete($id)) {
                jsonError('Modèle de liste non trouvé', 404);
            }
            jsonResponse(['ok' => true, 'id' => $id]);
            break;

        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (InvalidArgumentException $e) {
    jsonError($e->getMessage(), 400);
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
