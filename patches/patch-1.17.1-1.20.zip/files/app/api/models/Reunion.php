<?php
/** Calulis — Model Réunion (multi-année) */
require_once __DIR__ . '/../config.php';

class Reunion {
    /**
     * Toutes les réunions, ou celles d'une année.
     *
     * Décision 4.1 : une réunion appartient à l'année de sa DATE DE RÉALISATION et à celle
     * où elle a été CRÉÉE. Pour une année demandée, on rend donc trois cas :
     *   • créée cette année-là (préparée à l'avance pour l'année suivante) ;
     *   • rangée cette année-là (annee_scolaire_id) ;
     *   • dont la DATE tombe dans cette année-là.
     * La colonne calculée annee_date_id permet à l'écran de ranger dans un bloc à part
     * « à venir — année suivante » les réunions qui n'ont pas encore eu lieu dans l'année
     * affichée (décision 4.2).
     */
    public static function all(?int $anneeId = null): array {
        $pdo = getDB();
        $sql = 'SELECT r.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom,
                       (SELECT a.id FROM annees_scolaires a
                         WHERE r.date_reunion BETWEEN a.date_debut AND a.date_fin
                         ORDER BY a.date_debut DESC LIMIT 1) AS annee_date_id
                FROM reunions r
                LEFT JOIN eleves e ON r.eleve_id = e.id';
        $params = [];
        if ($anneeId !== null) {
            $sql .= ' WHERE (r.annee_scolaire_id = :annee_id
                              OR r.annee_creation_id = :annee_creation
                              OR EXISTS (SELECT 1 FROM annees_scolaires a2
                                          WHERE a2.id = :annee_date
                                            AND r.date_reunion BETWEEN a2.date_debut AND a2.date_fin))';
            $params['annee_id'] = $anneeId;
            $params['annee_creation'] = $anneeId;
            $params['annee_date'] = $anneeId;
        }
        $sql .= ' ORDER BY r.date_reunion DESC, r.heure';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT r.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
             FROM reunions r
             LEFT JOIN eleves e ON r.eleve_id = e.id
             WHERE r.id = :id'
        );
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Réunions liées à un élève */
    public static function getByEleve(int $eleveId, ?int $anneeId = null): array {
        $pdo = getDB();
        $sql = 'SELECT r.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
                FROM reunions r
                LEFT JOIN eleves e ON r.eleve_id = e.id
                WHERE r.eleve_id = :eleveId';
        $params = ['eleveId' => $eleveId];
        if ($anneeId !== null) {
            $sql .= ' AND r.annee_scolaire_id = :annee_id';
            $params['annee_id'] = $anneeId;
        }
        $sql .= ' ORDER BY r.date_reunion DESC, r.heure';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Réunions à venir (dans les N prochains jours) */
    public static function getUpcoming(int $days = 30): array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT r.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
             FROM reunions r
             LEFT JOIN eleves e ON r.eleve_id = e.id
             WHERE r.date_reunion BETWEEN CURRENT_DATE AND DATE_ADD(CURRENT_DATE, INTERVAL :days DAY)
               AND r.statut IN ("prevue", "reportee")
             ORDER BY r.date_reunion, r.heure'
        );
        $stmt->execute(['days' => $days]);
        return $stmt->fetchAll();
    }

    /** Réunions dans une plage de dates */
    public static function getByPeriode(string $debut, string $fin): array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT r.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
             FROM reunions r
             LEFT JOIN eleves e ON r.eleve_id = e.id
             WHERE r.date_reunion BETWEEN :debut AND :fin
             ORDER BY r.date_reunion, r.heure'
        );
        $stmt->execute(['debut' => $debut, 'fin' => $fin]);
        return $stmt->fetchAll();
    }

    /** Réunions où un adulte est participant (recherche JSON) */
    public static function getByAdulte(string $adulteNom): array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT r.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
             FROM reunions r
             LEFT JOIN eleves e ON r.eleve_id = e.id
             WHERE r.participants LIKE :q
             ORDER BY r.date_reunion DESC, r.heure'
        );
        $stmt->execute(['q' => '%' . $adulteNom . '%']);
        return $stmt->fetchAll();
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        // Décision 4.1 : une réunion porte son année de création. L'écran ne l'envoie pas :
        // sans ce défaut, une réunion neuve naissait sans année et n'apparaissait dans
        // aucune vue (le même défaut que les notes, vu par les tests du 27/10).
        if (empty($data['annee_scolaire_id'])) {
            $active = $pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
            if ($active !== false) {
                $data['annee_scolaire_id'] = (int)$active;
            }
        }
        if (empty($data['annee_creation_id'])) {
            $data['annee_creation_id'] = $data['annee_scolaire_id'] ?? null;
        }
        $stmt = $pdo->prepare('INSERT INTO reunions (
            type, titre, date_reunion, heure, duree, eleve_id, lieu,
            participants, statut, notes, documents_lies,
            ordre_du_jour, compte_rendu, preconisations, annee_scolaire_id, annee_creation_id
        ) VALUES (
            :type, :titre, :date_reunion, :heure, :duree, :eleve_id, :lieu,
            :participants, :statut, :notes, :documents_lies,
            :ordre_du_jour, :compte_rendu, :preconisations, :annee_scolaire_id, :annee_creation_id
        )');
        $stmt->execute(self::_bind($data, false));
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $existing = self::find($id);
        if (!$existing) return false;
        $data = array_merge($existing, $data);
        $data['id'] = $id;
        $stmt = $pdo->prepare('UPDATE reunions SET
            type=:type, titre=:titre, date_reunion=:date_reunion, heure=:heure,
            duree=:duree, eleve_id=:eleve_id, lieu=:lieu, participants=:participants,
            statut=:statut, notes=:notes, documents_lies=:documents_lies,
            ordre_du_jour=:ordre_du_jour, compte_rendu=:compte_rendu,
            preconisations=:preconisations, annee_scolaire_id=:annee_scolaire_id,
            annee_creation_id=:annee_creation_id,
            updated_at=CURRENT_TIMESTAMP
        WHERE id=:id');
        return $stmt->execute(self::_bind($data));
    }

    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM reunions WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    private static function _bind(array $data, bool $includeId = true): array {
        $strFields = ['type', 'titre', 'date_reunion', 'heure', 'lieu',
            'participants', 'statut', 'notes', 'documents_lies',
            'ordre_du_jour', 'compte_rendu', 'preconisations'];
        $intFields = ['duree', 'eleve_id', 'annee_scolaire_id', 'annee_creation_id'];
        if ($includeId) $intFields[] = 'id';
        $params = [];
        foreach ($strFields as $f) {
            $params[$f] = isset($data[$f]) ? trim($data[$f]) : null;
        }
        $intDefaults = ['duree' => 60, 'eleve_id' => null, 'annee_scolaire_id' => null,
            'annee_creation_id' => null, 'id' => 0];
        foreach ($intFields as $f) {
            $params[$f] = isset($data[$f]) ? (int)$data[$f] : ($intDefaults[$f] ?? null);
        }
        if ($includeId) $params['id'] = isset($data['id']) ? (int)$data['id'] : 0;
        return $params;
    }
}