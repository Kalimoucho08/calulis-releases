<?php
/**
 * Calulis — Modèle « Modèles de liste » (décisions 11.1 à 11.3 du 27/10/2026)
 *
 * Un modèle de liste = FILTRES + COLONNES + MISE EN PAGE + TRI. Il ne contient AUCUN
 * élève (11.3) : on applique le modèle, puis on choisit les élèves de l'année. Il se
 * conserve d'une année sur l'autre (11.2), alors que les listes, elles, se refont chaque
 * année (11.1).
 *
 * Les modèles enregistrés avant la 1.20 vivaient dans `groupes.criteres` et emportaient une
 * sélection d'élèves (`eleves_ids`) : la migration 023 a copié le nom et les critères, sans
 * les élèves. La table `groupes` n'est pas modifiée.
 */
require_once __DIR__ . '/../config.php';

class ModeleListe
{
    /** Tous les modèles, contenu décodé (le frontend reçoit un objet, pas une chaîne). */
    public static function all(): array
    {
        $rows = getDB()->query('SELECT id, nom, contenu, created_at, updated_at FROM modeles_listes ORDER BY nom')
            ->fetchAll(PDO::FETCH_ASSOC);
        return array_map([self::class, '_decoder'], $rows);
    }

    public static function find(int $id): ?array
    {
        $stmt = getDB()->prepare('SELECT id, nom, contenu, created_at, updated_at FROM modeles_listes WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ? self::_decoder($row) : null;
    }

    public static function create(array $data): int
    {
        $nom = self::_nom($data);
        $contenu = self::_contenu($data);
        $stmt = getDB()->prepare('INSERT INTO modeles_listes (nom, contenu) VALUES (:nom, :contenu)');
        $stmt->execute(['nom' => $nom, 'contenu' => $contenu]);
        return (int)getDB()->lastInsertId();
    }

    /** Modification partielle : un envoi sans `contenu` ne vide pas le modèle. */
    public static function update(int $id, array $data): bool
    {
        $existant = self::find($id);
        if (!$existant) {
            return false;
        }
        $nom = array_key_exists('nom', $data) ? self::_nom($data) : (string)$existant['nom'];
        $contenu = array_key_exists('contenu', $data)
            ? self::_contenu($data)
            : json_encode($existant['contenu'], JSON_UNESCAPED_UNICODE);
        $stmt = getDB()->prepare(
            'UPDATE modeles_listes SET nom = :nom, contenu = :contenu, updated_at = CURRENT_TIMESTAMP WHERE id = :id'
        );
        return $stmt->execute(['nom' => $nom, 'contenu' => $contenu, 'id' => $id]);
    }

    public static function delete(int $id): bool
    {
        $stmt = getDB()->prepare('DELETE FROM modeles_listes WHERE id = :id');
        $stmt->execute(['id' => $id]);
        return $stmt->rowCount() > 0;
    }

    private static function _nom(array $data): string
    {
        $nom = trim((string)($data['nom'] ?? ''));
        if ($nom === '') {
            throw new InvalidArgumentException('Donnez un nom au modèle de liste.');
        }
        return calulis_substr($nom, 200);
    }

    private static function _contenu(array $data): ?string
    {
        $contenu = $data['contenu'] ?? null;
        if ($contenu === null || $contenu === '') {
            return null;
        }
        if (is_string($contenu)) {
            $decode = json_decode($contenu, true);
            if (!is_array($decode)) {
                throw new InvalidArgumentException('Le contenu du modèle doit être un objet JSON.');
            }
            $contenu = $decode;
        }
        if (!is_array($contenu)) {
            throw new InvalidArgumentException('Le contenu du modèle doit être un objet JSON.');
        }
        return json_encode($contenu, JSON_UNESCAPED_UNICODE);
    }

    private static function _decoder(array $row): array
    {
        $contenu = null;
        if ($row['contenu'] !== null && $row['contenu'] !== '') {
            $contenu = json_decode((string)$row['contenu'], true);
            if (!is_array($contenu)) {
                $contenu = null;
            }
        }
        $row['contenu'] = $contenu;
        return $row;
    }
}
