<?php
/** Calulis — Model Semaine */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/Creneau.php';

class Semaine {

    public static function all(?int $anneeId = null): array {
        $pdo = getDB();
        if ($anneeId !== null) {
            $stmt = $pdo->prepare('SELECT * FROM semaines WHERE annee_scolaire_id = :aid ORDER BY date_debut');
            $stmt->execute(['aid' => $anneeId]);
            return $stmt->fetchAll();
        }
        return $pdo->query('SELECT * FROM semaines ORDER BY date_debut')->fetchAll();
    }

    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM semaines WHERE id = :id');
        $stmt->execute(['id' => $id]);
        return $stmt->fetch() ?: null;
    }

    public static function findByNumero(int $anneeId, int $numero): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM semaines WHERE annee_scolaire_id = :aid AND numero = :n');
        $stmt->execute(['aid' => $anneeId, 'n' => $numero]);
        return $stmt->fetch() ?: null;
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO semaines (annee_scolaire_id, numero, date_debut, date_fin, est_vacances, notes) VALUES (:annee_scolaire_id, :numero, :date_debut, :date_fin, :est_vacances, :notes)');
        $stmt->execute([
            'annee_scolaire_id' => $data['annee_scolaire_id'] ?? 1,
            'numero' => $data['numero'] ?? 1,
            'date_debut' => $data['date_debut'],
            'date_fin' => $data['date_fin'],
            'est_vacances' => $data['est_vacances'] ?? 0,
            'notes' => $data['notes'] ?? '',
        ]);
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        // Écriture PARTIELLE (constat R15 de la revue du 27/10/2026) : n'écrire que les clés
        // reçues. Avant, un appel qui ne portait que est_modifiee remettait est_vacances à 0
        // et vidait notes : marquer une semaine de VACANCES comme modifiée la transformait en
        // semaine scolaire, et les statistiques d'inclusion se mettaient à la compter.
        $sets = [];
        $params = ['id' => $id];
        foreach (['est_modifiee', 'est_vacances', 'notes'] as $f) {
            if (array_key_exists($f, $data)) {
                $sets[] = "$f = :$f";
                $params[$f] = $data[$f];
            }
        }
        if (empty($sets)) return true;
        $stmt = $pdo->prepare('UPDATE semaines SET ' . implode(', ', $sets) . ' WHERE id=:id');
        return $stmt->execute($params);
    }

    /** Génère toutes les semaines d'une année scolaire + copie créneaux template */
    public static function genererAnnee(int $anneeId, string $dateDebut, string $dateFin): array {
        $pdo = getDB();
        // Supprimer les anciennes semaines de cette année
        $pdo->prepare('DELETE FROM creneaux WHERE semaine_id IN (SELECT id FROM semaines WHERE annee_scolaire_id = :aid)')->execute(['aid' => $anneeId]);
        $pdo->prepare('DELETE FROM semaines WHERE annee_scolaire_id = :aid')->execute(['aid' => $anneeId]);

        $start = new DateTime($dateDebut);
        $start->modify('monday this week');
        $end = new DateTime($dateFin);
        $end->modify('sunday this week');

        $num = 1;
        $created = [];
        $current = clone $start;
        while ($current <= $end) {
            $fin = clone $current;
            $fin->modify('+6 days');
            $sid = self::create([
                'annee_scolaire_id' => $anneeId,
                'numero' => $num,
                'date_debut' => $current->format('Y-m-d'),
                'date_fin' => $fin->format('Y-m-d'),
                'est_vacances' => 0,
            ]);
            Creneau::copyFromTemplate($sid);
            $created[] = ['id' => $sid, 'numero' => $num, 'debut' => $current->format('Y-m-d')];
            $num++;
            $current->modify('+7 days');
        }
        return $created;
    }
}
