<?php
/** Calulis — Modèle Classe */
require_once __DIR__ . '/../../api/config.php';

class Classe
{
    public static function all(): array
    {
        $pdo = getDB();
        $classes = $pdo->query("SELECT c.*, e.nom as etablissement_nom
            FROM classes c LEFT JOIN etablissements e ON c.etablissement_id = e.id
            WHERE c.actif = 1 ORDER BY c.nom")->fetchAll();
        return self::_attachEnseignants($classes);
    }

    public static function find(int $id): ?array
    {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT c.*, e.nom as etablissement_nom
            FROM classes c LEFT JOIN etablissements e ON c.etablissement_id = e.id
            WHERE c.id = :id");
        $stmt->execute(['id' => $id]);
        $r = $stmt->fetch();
        if (!$r) return null;
        $r['enseignants'] = self::_enseignantsFor($id);
        return $r;
    }

    public static function getByEtablissement(int $etabId): array
    {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT * FROM classes WHERE etablissement_id = :eid AND actif = 1 ORDER BY nom");
        $stmt->execute(['eid' => $etabId]);
        return $stmt->fetchAll();
    }

    public static function getByNiveau(string $niveau): array
    {
        $pdo = getDB();
        $stmt = $pdo->prepare("SELECT * FROM classes WHERE actif = 1 AND niveaux LIKE :n ORDER BY nom");
        $stmt->execute(['n' => '%"' . $niveau . '"%']);
        return $stmt->fetchAll();
    }

    public static function getEleves(int $id): array
    {
        $pdo = getDB();
        $c = $pdo->prepare("SELECT niveaux FROM classes WHERE id = :id");
        $c->execute(['id' => $id]);
        $niveaux = json_decode($c->fetchColumn() ?: '[]', true) ?: [];

        if (count($niveaux) >= 3) {
            $stmt = $pdo->query("SELECT id, nom, prenom, classe, groupe, ulis, actif FROM eleves WHERE ulis = 1 AND actif = 1 ORDER BY nom, prenom");
        } else {
            $stmt = $pdo->prepare("SELECT id, nom, prenom, classe, groupe, ulis, actif FROM eleves WHERE classe_id = :cid ORDER BY nom, prenom");
            $stmt->execute(['cid' => $id]);
        }
        return $stmt->fetchAll();
    }

    public static function getAeshStaff(int $etablissementId): array
    {
        $pdo = getDB();
        $eleves = $pdo->query("SELECT id, nom, prenom FROM eleves WHERE actif = 1 AND ulis = 1 ORDER BY nom")->fetchAll();
        $elevesMap = [];
        foreach ($eleves as $e) $elevesMap[$e['id']] = $e;

        $stmt = $pdo->prepare("SELECT id, nom, prenom, role, telephone, email FROM adultes WHERE role IN ('aeshco','aeshi') AND etablissement_id = :eid AND actif = 1 ORDER BY role, nom");
        $stmt->execute(['eid' => $etablissementId]);
        $aesh = $stmt->fetchAll();

        foreach ($aesh as &$a) {
            $stmt2 = $pdo->prepare("SELECT ae.type, ae.heures, ae.mutualise_avec, ae.eleve_id
                FROM aesh_eleves ae
                WHERE ae.nom LIKE CONCAT('%', :prenom, '%')");
            $stmt2->execute(['prenom' => $a['prenom']]);
            $liens = $stmt2->fetchAll();
            $a['eleves'] = [];
            foreach ($liens as $l) {
                if (isset($elevesMap[$l['eleve_id']])) {
                    $a['eleves'][] = array_merge($elevesMap[$l['eleve_id']], [
                        'type_aesh' => $l['type'],
                        'heures' => $l['heures'],
                    ]);
                }
            }
        }
        return $aesh;
    }

    public static function create(array $data): int
    {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare("INSERT INTO classes (nom, niveaux, enseignant_id, etablissement_id) VALUES (:nom, :niveaux, :enseignant_id, :etablissement_id)");
        $stmt->execute(self::_bind($data, ['nom', 'niveaux', 'enseignant_id', 'etablissement_id']));
        $id = (int)$pdo->lastInsertId();
        self::_saveEnseignants($id, $data['enseignants'] ?? []);
        return $id;
    }

    public static function update(int $id, array $data): void
    {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $data['id'] = $id;
        $stmt = $pdo->prepare("UPDATE classes SET nom=:nom, niveaux=:niveaux, enseignant_id=:enseignant_id, etablissement_id=:etablissement_id, updated_at=CURRENT_TIMESTAMP WHERE id=:id");
        $stmt->execute(self::_bind($data));
        self::_saveEnseignants($id, $data['enseignants'] ?? []);
    }

    public static function delete(int $id): void
    {
        $pdo = getDB();
        $pdo->prepare("UPDATE classes SET actif = 0 WHERE id = :id")->execute(['id' => $id]);
    }

    private static function _enseignantsFor(int $classeId): array
    {
        $pdo = getDB();
        // Décision 3.4 : l'enseignement d'une classe est DATÉ. On ne lit que les périodes
        // encore ouvertes (date_fin NULL) : une période close est de l'histoire, pas le présent.
        $stmt = $pdo->prepare("SELECT ce.adulte_id, ce.date_debut, ce.date_fin, ce.jours, ce.plage, ce.ordre, a.nom, a.prenom, a.role, a.fonction
            FROM classe_enseignants ce JOIN adultes a ON ce.adulte_id = a.id
            WHERE ce.classe_id = :cid AND ce.date_fin IS NULL ORDER BY ce.ordre, a.nom");
        $stmt->execute(['cid' => $classeId]);
        $rows = $stmt->fetchAll();
        foreach ($rows as &$row) {
            $j = json_decode($row['jours'] ?? '[]', true);
            $row['jours'] = is_array($j) ? $j : [];
        }
        return $rows;
    }

    private static function _attachEnseignants(array $classes): array
    {
        if (empty($classes)) return $classes;
        $pdo = getDB();
        $ids = implode(',', array_map('intval', array_column($classes, 'id')));
        $stmt = $pdo->prepare("SELECT ce.classe_id, ce.adulte_id, ce.date_debut, ce.date_fin, ce.jours, ce.plage, a.nom, a.prenom, a.role, a.fonction
            FROM classe_enseignants ce JOIN adultes a ON ce.adulte_id = a.id
            WHERE ce.classe_id IN ($ids) AND ce.date_fin IS NULL ORDER BY ce.classe_id, ce.ordre, a.nom");
        $stmt->execute();
        $map = [];
        foreach ($stmt->fetchAll() as $row) {
            $j = json_decode($row['jours'] ?? '[]', true);
            $row['jours'] = is_array($j) ? $j : [];
            $map[$row['classe_id']][] = $row;
        }
        foreach ($classes as &$c) {
            $c['enseignants'] = $map[$c['id']] ?? [];
        }
        return $classes;
    }

    private static function _saveEnseignants(int $classeId, array $enseignants): void
    {
        $pdo = getDB();
        $aujourdhui = date('Y-m-d');
        $veille = date('Y-m-d', strtotime('-1 day'));

        // Ce qui est OUVERT aujourd'hui pour cette classe, avant modification.
        $stmt = $pdo->prepare("SELECT id, adulte_id FROM classe_enseignants
                               WHERE classe_id = :cid AND date_fin IS NULL");
        $stmt->execute(['cid' => $classeId]);
        $ouvertes = [];
        foreach ($stmt->fetchAll() as $r) { $ouvertes[(int)$r['adulte_id']] = (int)$r['id']; }

        $voulus = [];
        foreach ($enseignants as $e) {
            $adulteId = (int)($e['adulte_id'] ?? 0);
            if ($adulteId) { $voulus[$adulteId] = $e; }
        }

        $pdo->beginTransaction();
        try {
            // Décision 3.4 : quand l'enseignant change, on CLÔT la période la veille et on
            // en ouvre une autre. Aucune ligne n'est supprimée : l'histoire de la classe
            // reste lisible (« qui l'enseignait en 2024 ? »).
            $fermer = $pdo->prepare("UPDATE classe_enseignants SET date_fin = :fin, updated_at = CURRENT_TIMESTAMP WHERE id = :id");
            foreach ($ouvertes as $aid => $idLigne) {
                if (!isset($voulus[$aid])) { $fermer->execute(['fin' => $veille, 'id' => $idLigne]); }
            }
            $maj = $pdo->prepare("UPDATE classe_enseignants SET jours = :jours, plage = :plage, ordre = :ordre, updated_at = CURRENT_TIMESTAMP WHERE id = :id");
            $insert = $pdo->prepare("INSERT INTO classe_enseignants (classe_id, adulte_id, date_debut, date_fin, jours, plage, ordre)
                                     VALUES (:cid, :aid, :debut, NULL, :jours, :plage, :ordre)");
            $ordre = 0;
            $firstId = null;
            foreach ($voulus as $adulteId => $e) {
                if ($firstId === null) $firstId = $adulteId;
                $jours = $e['jours'] ?? [];
                if (is_string($jours)) { $d = json_decode($jours, true); $jours = is_array($d) ? $d : []; }
                $commun = [
                    'jours' => json_encode(array_values($jours), JSON_UNESCAPED_UNICODE),
                    'plage' => $e['plage'] ?? 'journee',
                    'ordre' => $ordre++,
                ];
                if (isset($ouvertes[$adulteId])) {
                    $commun['id'] = $ouvertes[$adulteId];
                    $maj->execute($commun);
                } else {
                    $insert->execute($commun + ['cid' => $classeId, 'aid' => $adulteId, 'debut' => $aujourdhui]);
                }
            }
            $pdo->prepare("UPDATE classes SET enseignant_id = :aid WHERE id = :cid")->execute(['aid' => $firstId, 'cid' => $classeId]);
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    private static function _bind(array $d, ?array $onlyFields = null): array
    {
        $niveaux = $d['niveaux'] ?? [];
        if (is_string($niveaux)) {
            $decoded = json_decode($niveaux, true);
            $niveaux = is_array($decoded) ? $decoded : [];
        }
        $all = [
            'id' => $d['id'] ?? null,
            'nom' => $d['nom'] ?? '',
            'niveaux' => json_encode($niveaux, JSON_UNESCAPED_UNICODE),
            'enseignant_id' => !empty($d['enseignant_id']) ? (int)$d['enseignant_id'] : null,
            'etablissement_id' => !empty($d['etablissement_id']) ? (int)$d['etablissement_id'] : null,
        ];
        if ($onlyFields !== null) {
            return array_intersect_key($all, array_flip($onlyFields));
        }
        return $all;
    }
}