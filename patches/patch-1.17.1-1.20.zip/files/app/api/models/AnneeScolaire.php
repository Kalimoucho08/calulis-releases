<?php
/** Calulis — Model Année Scolaire */
require_once __DIR__ . '/../config.php';

class AnneeScolaire {
    /** Liste toutes les années, triées par date_debut DESC */
    public static function all(): array {
        $pdo = getDB();
        return $pdo->query('SELECT * FROM annees_scolaires ORDER BY date_debut DESC')->fetchAll();
    }

    /** Trouve une année par ID */
    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM annees_scolaires WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Récupère l'année active */
    public static function getActive(): ?array {
        $pdo = getDB();
        $stmt = $pdo->query('SELECT * FROM annees_scolaires WHERE est_active = 1 LIMIT 1');
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** Crée une année, retourne l'ID */
    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO annees_scolaires (nom, date_debut, date_fin, est_active)
            VALUES (:nom, :date_debut, :date_fin, :est_active)');
        $stmt->execute([
            'nom' => trim($data['nom'] ?? ''),
            'date_debut' => $data['date_debut'] ?? null,
            'date_fin' => $data['date_fin'] ?? null,
            'est_active' => isset($data['est_active']) ? (int)$data['est_active'] : 0,
        ]);
        return (int)$pdo->lastInsertId();
    }

    /** Met à jour une année */
    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $fields = [];
        $params = ['id' => $id];
        foreach (['nom', 'date_debut', 'date_fin', 'est_active'] as $f) {
            if (array_key_exists($f, $data)) {
                $fields[] = "$f = :$f";
                $params[$f] = $f === 'est_active' ? (int)$data[$f] : trim($data[$f]);
            }
        }
        if (empty($fields)) return false;
        $sql = 'UPDATE annees_scolaires SET ' . implode(', ', $fields) . ' WHERE id = :id';
        $stmt = $pdo->prepare($sql);
        return $stmt->execute($params);
    }

    /** Définit l'année active (désactive les autres) */
    public static function setActive(int $id): bool {
        $pdo = getDB();
        $pdo->beginTransaction();
        try {
            $pdo->exec('UPDATE annees_scolaires SET est_active = 0');
            $stmt = $pdo->prepare('UPDATE annees_scolaires SET est_active = 1 WHERE id = :id');
            $stmt->execute(['id' => $id]);
            $pdo->commit();
            return true;
        } catch (\Exception $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    /**
     * Les familles de lignes rattachées à une année — SOURCE UNIQUE du compte, du
     * vidage et du refus de suppression.
     *
     * « edt »    = l'emploi du temps de l'année : semaines et créneaux. C'EST LE SEUL
     *              contenu qu'un geste explicite peut supprimer.
     * « annuel » = tout le reste : conservé indéfiniment, consultable en activant
     *              l'année (décision du 27/10/2026 : une année n'est pas une corbeille).
     *
     * La SEMAINE TYPE est comptée ICI, dans « edt » : depuis la migration 018 (décision
     * 2.4), un créneau de modèle porte l'année à laquelle il appartient (semaine_id NULL,
     * annee_scolaire_id renseignée) et il PART avec l'emploi du temps de cette année-là.
     * Vidée en 2024, elle ne touche pas le modèle de 2025.
     */
    private static function familles(): array {
        $annuel = static fn (string $table): array => [
            "SELECT COUNT(*) FROM $table WHERE annee_scolaire_id = :id", 'annuel',
        ];
        return [
            // Emploi du temps de l'année (vidable sur geste explicite)
            'semaines'               => ['SELECT COUNT(*) FROM semaines WHERE annee_scolaire_id = :id', 'edt'],
            // Les créneaux de la SEMAINE TYPE (semaine_id NULL) appartiennent à l'année qu'ils
            // portent : sans eux, une année qui n'a QUE son modèle annonçait « aucun emploi du
            // temps à vider » et gardait son modèle après le vidage (constat R6, 27/10/2026).
            // COALESCE évite de répéter :id, interdit avec les requêtes préparées natives.
            'creneaux'               => ['SELECT COUNT(*) FROM creneaux c LEFT JOIN semaines s ON s.id = c.semaine_id WHERE COALESCE(s.annee_scolaire_id, c.annee_scolaire_id) = :id', 'edt'],
            // Annuel (conservé) — ordre alphabétique pour que le compte se lise
            'absences'               => $annuel('absences'),
            'adultes_etablissements' => $annuel('adultes_etablissements'),
            'budget'                 => $annuel('budget'),
            'dispositifs'            => $annuel('dispositifs'),
            'documents'              => $annuel('documents'),
            'eleve_annees'           => $annuel('eleve_annees'),
            'eleve_groupes'          => $annuel('eleve_groupes'),
            'evenements'             => $annuel('evenements'),
            'materiel'               => $annuel('materiel'),
            'mdph_dossiers'          => $annuel('mdph_dossiers'),
            'notes_suivi'            => $annuel('notes_suivi'),
            'pec_eleves'             => $annuel('pec_eleves'),
            'periodes'               => $annuel('periodes'),
            'reunions'               => $annuel('reunions'),
            'soins'                  => $annuel('soins'),
            'sorties'                => $annuel('sorties'),
            'stages'                 => $annuel('stages'),
            'taches'                 => $annuel('taches'),
            'vacances'               => $annuel('vacances'),
        ];
    }

    /**
     * Compte, famille par famille, ce que l'année porte.
     *
     * Rendus : semaines, creneaux, edt (semaines + créneaux), donnees (tout, emploi
     * du temps compris) et total (alias de donnees, conservé pour les appelants
     * d'avant le 27/10/2026). L'écran s'en sert pour ANNONCER avant d'agir ; le
     * contrôleur s'en sert pour refuser une suppression destructive.
     */
    public static function contenu(int $id): array {
        $pdo = getDB();
        $compte = [];
        $edt = 0;
        foreach (self::familles() as $table => [$sql, $famille]) {
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['id' => $id]);
            $n = (int) $stmt->fetchColumn();
            $compte[$table] = $n;
            if ($famille === 'edt') $edt += $n;
        }
        $compte['edt'] = $edt;
        $compte['donnees'] = array_sum($compte);
        $compte['total'] = $compte['donnees'];
        return $compte;
    }

    /** Ancien nom, conservé : le compte ne sert plus à supprimer mais à DÉCRIRE. */
    public static function compterSuppression(int $id): array {
        return self::contenu($id);
    }

    /**
     * Vide l'EMPLOI DU TEMPS de l'année : semaines de l'année et leurs créneaux
     * (la suppression des semaines emporte les créneaux par la clé étrangère).
     *
     * Ne touche à RIEN d'autre : ni les élèves, ni leurs fiches de l'année, ni les
     * adultes, ni les établissements, ni les liens adulte-établissement, ni les
     * réunions, ni les documents, ni les tâches, ni les notes, ni les événements,
     * ni les périodes, ni les vacances. La semaine type de CETTE année part avec son
     * emploi du temps (décision 2.4) ; celle des autres années n'est pas touchée.
     *
     * L'appelant a compté, sauvegardé la base et confirmé.
     */
    public static function viderEmploiDuTemps(int $id): array {
        $pdo = getDB();
        $compte = self::contenu($id);
        $pdo->beginTransaction();
        try {
            $pdo->prepare('DELETE FROM semaines WHERE annee_scolaire_id = :id')->execute(['id' => $id]);
            // Décision 2.4 : la semaine type de l'année part avec son emploi du temps.
            // Depuis la migration 018, un modèle porte l'année à laquelle il appartient :
            // vider l'emploi du temps de 2024 ne touche pas la semaine type de 2025.
            $pdo->prepare('DELETE FROM creneaux WHERE semaine_id IS NULL AND annee_scolaire_id = :id')->execute(['id' => $id]);
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
        return ['semaines' => $compte['semaines'], 'creneaux' => $compte['creneaux']];
    }

    /** Supprime une année — réservé aux années VIDES (voir le contrôleur). */
    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM annees_scolaires WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }
}
