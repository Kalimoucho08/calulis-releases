<?php
/** Calulis — Model Élève / Classe : l'HISTOIRE datée de la classe d'un élève.
 *
 *  Décision 3.3 du 27/10/2026 : « la classe de référence de l'élève est datée »,
 *  et un changement en cours d'année doit pouvoir se dire. Dates au JOUR PRÈS
 *  (décision 15.1).
 *
 *  Pourquoi une table séparée : `eleve_annees` porte UNE ligne par élève et par
 *  année (contrainte UNIQUE) ; elle ne peut donc pas raconter « du 1er septembre
 *  au 30 novembre, puis à partir du 1er décembre ». `eleve_annees.classe_id` reste
 *  donc la classe COURANTE — des dizaines d'écrans la lisent — et cette table dit
 *  depuis quand.
 *
 *  Règle unique, écrite une seule fois ici : `synchroniserClasse()` recopie dans
 *  `eleve_annees` la classe de la DERNIÈRE période de l'année. Aucun écran ne
 *  décide lui-même quelle classe est « la bonne ».
 */
require_once __DIR__ . '/../config.php';

class EleveClasse {

    /** Périodes d'un élève, de la plus ancienne à la plus récente. */
    public static function historique(int $eleveId): array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT ec.*, c.nom AS classe_nom, a.nom AS annee_nom
             FROM eleve_classes ec
             LEFT JOIN classes c ON c.id = ec.classe_id
             LEFT JOIN annees_scolaires a ON a.id = ec.annee_scolaire_id
             WHERE ec.eleve_id = :eleve_id
             ORDER BY ec.date_debut, ec.id'
        );
        $stmt->execute(['eleve_id' => $eleveId]);
        return $stmt->fetchAll();
    }

    /** La période encore ouverte, s'il y en a une (il ne devrait y en avoir qu'une). */
    public static function courante(int $eleveId): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT ec.*, c.nom AS classe_nom
             FROM eleve_classes ec
             LEFT JOIN classes c ON c.id = ec.classe_id
             WHERE ec.eleve_id = :eleve_id AND ec.date_fin IS NULL
             ORDER BY ec.date_debut DESC LIMIT 1'
        );
        $stmt->execute(['eleve_id' => $eleveId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /**
     * Ouvre une période : clôt la précédente la veille, puis insère.
     *
     * @throws InvalidArgumentException si la date est invalide ou antérieure à la
     *         période encore ouverte (on ne réécrit pas l'histoire par accident)
     */
    public static function ouvrir(int $eleveId, ?int $classeId, string $dateDebut, ?int $anneeId = null): int {
        $dateDebut = self::_dateValide($dateDebut);
        if ($anneeId === null) {
            $anneeId = self::anneeDeDate($dateDebut);
        }

        $pdo = getDB();
        // Transaction IMBRIQUÉE (constat R1 de la revue du 27/10/2026) : cette méthode est
        // appelée par Eleve::create() et Eleve::update(), qui tiennent DÉJÀ une transaction
        // (via EleveAnnee::upsert → _daterClasse). En ouvrir une seconde sur le même PDO
        // lève « There is already an active transaction » → HTTP 500 et création d'élève
        // impossible. On ne prend donc la main QUE si personne ne la tient ; sinon on
        // participe à la transaction de l'appelant, qui seul valide ou annule.
        $propreTransaction = !$pdo->inTransaction();
        if ($propreTransaction) { $pdo->beginTransaction(); }
        try {
            $ouverte = self::courante($eleveId);
            // Même jour : c'est une correction, pas un changement d'histoire.
            if ($ouverte && substr((string)$ouverte['date_debut'], 0, 10) === $dateDebut) {
                $stmt = $pdo->prepare('UPDATE eleve_classes SET classe_id = :classe_id, annee_scolaire_id = :annee_id,
                                       updated_at = CURRENT_TIMESTAMP WHERE id = :id');
                $stmt->execute(['classe_id' => $classeId, 'annee_id' => $anneeId, 'id' => $ouverte['id']]);
                self::synchroniserClasse($eleveId, $anneeId);
                if ($propreTransaction) { $pdo->commit(); }
                return (int)$ouverte['id'];
            }
            if ($ouverte) {
                if ($dateDebut <= $ouverte['date_debut']) {
                    throw new InvalidArgumentException(
                        'La nouvelle période doit commencer après le ' . self::_fr($ouverte['date_debut']) . '.'
                    );
                }
                $veille = self::_veille($dateDebut);
                $stmt = $pdo->prepare('UPDATE eleve_classes SET date_fin = :fin, updated_at = CURRENT_TIMESTAMP WHERE id = :id');
                $stmt->execute(['fin' => $veille, 'id' => $ouverte['id']]);
            }

            $stmt = $pdo->prepare(
                'INSERT INTO eleve_classes (eleve_id, classe_id, annee_scolaire_id, date_debut, date_fin)
                 VALUES (:eleve_id, :classe_id, :annee_id, :date_debut, NULL)'
            );
            $stmt->execute([
                'eleve_id'  => $eleveId,
                'classe_id' => $classeId,
                'annee_id'  => $anneeId,
                'date_debut'=> $dateDebut,
            ]);
            $id = (int)$pdo->lastInsertId();

            self::synchroniserClasse($eleveId, $anneeId);
            if ($ouverte && (int)$ouverte['annee_scolaire_id'] !== (int)$anneeId) {
                self::synchroniserClasse($eleveId, (int)$ouverte['annee_scolaire_id']);
            }
            if ($propreTransaction) { $pdo->commit(); }
            return $id;
        } catch (\Throwable $e) {
            if ($propreTransaction) { $pdo->rollBack(); }
            throw $e;
        }
    }

    /** Clôt une période à la date donnée (incluse). */
    public static function clore(int $id, string $dateFin): bool {
        $dateFin = self::_dateValide($dateFin);
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM eleve_classes WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $p = $stmt->fetch();
        if (!$p) { throw new InvalidArgumentException('Période introuvable.'); }
        if ($dateFin < $p['date_debut']) {
            throw new InvalidArgumentException('La fin ne peut pas précéder le début (' . self::_fr($p['date_debut']) . ').');
        }
        $stmt = $pdo->prepare('UPDATE eleve_classes SET date_fin = :fin, updated_at = CURRENT_TIMESTAMP WHERE id = :id');
        $ok = $stmt->execute(['fin' => $dateFin, 'id' => $id]);
        self::synchroniserClasse((int)$p['eleve_id'], $p['annee_scolaire_id'] !== null ? (int)$p['annee_scolaire_id'] : null);
        return $ok;
    }

    /**
     * Recopie dans `eleve_annees` la classe de la DERNIÈRE période de l'année.
     * C'est la seule règle qui décide de « la classe actuelle » de l'élève.
     */
    public static function synchroniserClasse(int $eleveId, ?int $anneeId): void {
        if ($anneeId === null) { return; }
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT ec.classe_id, c.nom AS classe_nom
             FROM eleve_classes ec
             LEFT JOIN classes c ON c.id = ec.classe_id
             WHERE ec.eleve_id = :eleve_id AND ec.annee_scolaire_id = :annee_id
             ORDER BY ec.date_debut DESC, ec.id DESC LIMIT 1'
        );
        $stmt->execute(['eleve_id' => $eleveId, 'annee_id' => $anneeId]);
        $derniere = $stmt->fetch();

        $classeId = $derniere ? $derniere['classe_id'] : null;
        $classeNom = $derniere && $derniere['classe_nom'] !== null ? mb_substr((string)$derniere['classe_nom'], 0, 20) : null;

        $up = $pdo->prepare(
            'UPDATE eleve_annees SET classe_id = :classe_id, classe = :classe, updated_at = CURRENT_TIMESTAMP
             WHERE eleve_id = :eleve_id AND annee_scolaire_id = :annee_id'
        );
        $up->execute([
            'classe_id' => $classeId,
            'classe'    => $classeNom,
            'eleve_id'  => $eleveId,
            'annee_id'  => $anneeId,
        ]);
    }

    /** Vrai si l'élève a au moins une période enregistrée pour cette année. */
    public static function aUnePeriode(int $eleveId, int $anneeId): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT 1 FROM eleve_classes WHERE eleve_id = :eleve_id AND annee_scolaire_id = :annee_id LIMIT 1');
        $stmt->execute(['eleve_id' => $eleveId, 'annee_id' => $anneeId]);
        return (bool)$stmt->fetchColumn();
    }

    /** L'année scolaire qui contient une date, ou null si aucune. */
    public static function anneeDeDate(string $date): ?int {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT id FROM annees_scolaires WHERE :d BETWEEN date_debut AND date_fin
             ORDER BY date_debut DESC LIMIT 1'
        );
        $stmt->execute(['d' => $date]);
        $id = $stmt->fetchColumn();
        return $id === false ? null : (int)$id;
    }

    private static function _dateValide(string $date): string {
        $d = DateTime::createFromFormat('Y-m-d', $date);
        if (!$d || $d->format('Y-m-d') !== $date) {
            throw new InvalidArgumentException('Date invalide (format attendu AAAA-MM-JJ).');
        }
        return $date;
    }

    private static function _veille(string $date): string {
        $d = new DateTime($date);
        $d->modify('-1 day');
        return $d->format('Y-m-d');
    }

    private static function _fr(?string $date): string {
        if (!$date) { return ''; }
        $d = DateTime::createFromFormat('Y-m-d', substr($date, 0, 10));
        return $d ? $d->format('d/m/Y') : (string)$date;
    }
}
