<?php
/** Calulis — Model Créneau */
require_once __DIR__ . '/../config.php';

class Creneau {

    public static function findBySemaine(?int $semaineId): array {
        $pdo = getDB();
        if ($semaineId === null) {
            $stmt = $pdo->query('SELECT * FROM creneaux WHERE semaine_id IS NULL AND (annee_scolaire_id = ' . (int)self::_anneeActive() . ' OR annee_scolaire_id IS NULL) ORDER BY jour, heure_debut');
        } else {
            $stmt = $pdo->prepare('SELECT * FROM creneaux WHERE semaine_id = :sid ORDER BY jour, heure_debut');
            $stmt->execute(['sid' => $semaineId]);
        }
        return $stmt->fetchAll();
    }

    /** Comme findBySemaine, mais avec LEFT JOIN eleves pour obtenir les noms */
    public static function findBySemaineWithEleves(?int $semaineId): array {
        $pdo = getDB();
        $sql = 'SELECT c.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom, e.classe AS eleve_classe
                FROM creneaux c
                LEFT JOIN eleves e ON c.eleve_id = e.id';
        if ($semaineId === null) {
            $stmt = $pdo->query($sql . ' WHERE c.semaine_id IS NULL AND (c.annee_scolaire_id = ' . (int)self::_anneeActive() . ' OR c.annee_scolaire_id IS NULL) ORDER BY c.jour, c.heure_debut');
        } else {
            $stmt = $pdo->prepare($sql . ' WHERE c.semaine_id = :sid ORDER BY c.jour, c.heure_debut');
            $stmt->execute(['sid' => $semaineId]);
        }
        return $stmt->fetchAll();
    }

    /**
     * Créneaux d'un adulte, désigné par son nom.
     *
     * `creneaux.adulte` est une chaîne d'AFFICHAGE : « M. DUPONT Marie », ou
     * « M. MARTIN Julie, DUPONT Marc » quand le créneau est co-animé (noms séparés par
     * « , »). L'ancienne requête `LIKE '%nom'` n'acceptait le nom qu'en FIN de chaîne :
     * elle ne trouvait donc que le DERNIER adulte d'un créneau co-animé (mesuré le
     * 18/10/2026 — la fiche de l'autre co-animateur perdait ses créneaux).
     *
     * On encadre la chaîne de virgules et on cherche le nom comme un TERME de la liste,
     * civilité éventuelle devant. Conséquences vérifiées :
     *   - « MARTIN Julie » ne désigne pas « MARTIN Julien » (les virgules bornent le terme) ;
     *   - co-animé, chaque adulte retrouve le créneau, quel que soit son rang ;
     *   - la comparaison reste insensible à la casse et aux accents (collation de la base),
     *     comme avant, pour les créneaux saisis à la main dans les anciennes versions.
     */
    public static function findByAdulte(string $adulteNom, ?int $semaineId = null): array {
        $pdo = getDB();
        // « , %<nom>,% » : un terme de la liste, éventuellement précédé d'une civilité.
        $pattern = '%, %' . addcslashes($adulteNom, '%_') . ',%';
        $filtre = "CONCAT(', ', TRIM(c.adulte), ',') LIKE :pattern";
        if ($semaineId === null) {
            $stmt = $pdo->prepare(
                'SELECT c.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
                 FROM creneaux c
                 LEFT JOIN eleves e ON c.eleve_id = e.id
                 WHERE ' . $filtre . ' AND c.semaine_id IS NULL AND (c.annee_scolaire_id = ' . (int)self::_anneeActive() . ' OR c.annee_scolaire_id IS NULL)
                 ORDER BY c.jour, c.heure_debut'
            );
            $stmt->execute(['pattern' => $pattern]);
        } else {
            $stmt = $pdo->prepare(
                'SELECT c.*, e.nom AS eleve_nom, e.prenom AS eleve_prenom
                 FROM creneaux c
                 LEFT JOIN eleves e ON c.eleve_id = e.id
                 WHERE ' . $filtre . ' AND c.semaine_id = :sid
                 ORDER BY c.jour, c.heure_debut'
            );
            $stmt->execute(['pattern' => $pattern, 'sid' => $semaineId]);
        }
        return $stmt->fetchAll();
    }

    public static function findByEleve(int $eleveId, ?int $semaineId = null): array {
        $pdo = getDB();
        if ($semaineId === null) {
            $stmt = $pdo->prepare('SELECT * FROM creneaux WHERE eleve_id = :eid AND semaine_id IS NULL AND (annee_scolaire_id = ' . (int)self::_anneeActive() . ' OR annee_scolaire_id IS NULL) ORDER BY jour, heure_debut');
            $stmt->execute(['eid' => $eleveId]);
        } else {
            $stmt = $pdo->prepare('SELECT * FROM creneaux WHERE eleve_id = :eid AND semaine_id = :sid ORDER BY jour, heure_debut');
            $stmt->execute(['eid' => $eleveId, 'sid' => $semaineId]);
        }
        return $stmt->fetchAll();
    }

    /**
     * Le nom écrit dans un créneau désigne-t-il UN adulte de l'annuaire ?
     *
     * Règle prudente : on ne relie que si le texte ne contient QU'UN nom (pas de virgule,
     * donc pas de co-animation) et si ce nom ne correspond qu'à UN adulte. Un homonyme ou
     * un créneau co-animé restent en texte libre — deviner serait pire que ne rien lier.
     */
    private static function _resoudreAdulteId(?string $texte): ?int {
        $texte = trim((string)$texte);
        if ($texte === '' || strpos($texte, ',') !== false) { return null; }
        $pdo = getDB();
        $stmt = $pdo->query('SELECT id, nom FROM adultes WHERE actif = 1');
        $trouves = [];
        $cible = self::_normaliserNom($texte);
        if ($cible === '') { return null; }
        foreach ($stmt->fetchAll() as $a) {
            if (self::_normaliserNom((string)$a['nom']) === $cible) { $trouves[] = (int)$a['id']; }
        }
        return count($trouves) === 1 ? $trouves[0] : null;
    }

    /** L'année scolaire active, ou la plus récente si aucune ne l'est. */
    private static function _anneeActive(): ?int {
        $pdo = getDB();
        $id = $pdo->query('SELECT id FROM annees_scolaires ORDER BY est_active DESC, date_debut DESC LIMIT 1')->fetchColumn();
        return $id === false ? null : (int)$id;
    }

    /** « M. Dupont », « Mme ROBERT » et « dupont » désignent la même personne. */
    private static function _normaliserNom(string $nom): string {
        $n = preg_replace('/^(M\.|Mme|Mlle|Dr\.?|Pr\.?)\s+/iu', '', trim($nom));
        $n = preg_replace('/[^a-z0-9]+/iu', ' ', mb_strtolower((string)$n));
        return trim(preg_replace('/\s+/u', ' ', (string)$n));
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        if (!array_key_exists('adulte_id', $data)) {
            $data['adulte_id'] = self::_resoudreAdulteId($data['adulte'] ?? null);
        }
        // Décision 2.1 : une semaine type appartient à une année. Un créneau « modèle »
        // (sans semaine) est donc daté de l'année ACTIVE ; un créneau de semaine réelle
        // n'a pas besoin de ce champ, son année se lit par `semaines`.
        $estModele = empty($data['semaine_id']);
        if ($estModele && empty($data['annee_scolaire_id'])) {
            $data['annee_scolaire_id'] = self::_anneeActive();
        } elseif (!$estModele) {
            $data['annee_scolaire_id'] = null;
        }
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO creneaux (
            eleve_id, semaine_id, annee_scolaire_id, jour, heure_debut, duree, matiere, groupe, adulte,
            adulte_id, role_adulte, type, regroupement_type, regroupement_id, couleur_override, commentaire
        ) VALUES (
            :eleve_id, :semaine_id, :annee_scolaire_id, :jour, :heure_debut, :duree, :matiere, :groupe, :adulte,
            :adulte_id, :role_adulte, :type, :regroupement_type, :regroupement_id, :couleur_override, :commentaire
        )');
        $stmt->execute(self::_bind($data));
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        // Un client qui ne parle pas de regroupement ne doit pas l'effacer : les chemins
        // qui reconstruisent un créneau (glisser-déposer, copie) n'envoient pas la clé.
        // La séparation reste un NULL EXPLICITE (action « regroupement »).
        if (!array_key_exists('regroupement_id', $data)) {
            $cur = $pdo->prepare('SELECT regroupement_id FROM creneaux WHERE id = :id');
            $cur->execute(['id' => $id]);
            $existant = $cur->fetchColumn();
            $data['regroupement_id'] = ($existant === false || $existant === null) ? null : $existant;
        }
        if (!array_key_exists('adulte_id', $data)) {
            $data['adulte_id'] = self::_resoudreAdulteId($data['adulte'] ?? null);
        }
        // Modèle ou créneau de semaine : si le client ne parle pas de la SEMAINE (et donc
        // pas de l'année), on CONSERVE la nature et l'année de la ligne existante. Sans
        // cela, un PUT de la vue « Semaine type » — qui n'envoie pas semaine_id
        // (agenda.js) — sautait la règle 2.1 ci-dessous et écrivait annee_scolaire_id = NULL :
        // le modèle devenait COMMUNAL, lu dans toutes les années et copié n'importe où
        // (constat R5 de la revue du 27/10/2026).
        if (!array_key_exists('semaine_id', $data) || !array_key_exists('annee_scolaire_id', $data)) {
            $lue = $pdo->prepare('SELECT semaine_id, annee_scolaire_id FROM creneaux WHERE id = :id');
            $lue->execute(['id' => $id]);
            $existante = $lue->fetch();
            if ($existante) {
                if (!array_key_exists('semaine_id', $data)) {
                    $data['semaine_id'] = $existante['semaine_id'];
                }
                if (!array_key_exists('annee_scolaire_id', $data)) {
                    $data['annee_scolaire_id'] = $existante['annee_scolaire_id'];
                }
            }
        }
        // Même règle qu'à la création (2.1) : un modèle porte l'année active, un créneau
        // de semaine n'en porte pas.
        if (array_key_exists('semaine_id', $data)) {
            $data['annee_scolaire_id'] = empty($data['semaine_id'])
                ? (array_key_exists('annee_scolaire_id', $data) && $data['annee_scolaire_id']
                    ? (int)$data['annee_scolaire_id'] : self::_anneeActive())
                : null;
        }
        $data['id'] = $id;
        $stmt = $pdo->prepare('UPDATE creneaux SET
            eleve_id=:eleve_id, semaine_id=:semaine_id, annee_scolaire_id=:annee_scolaire_id,
            jour=:jour, heure_debut=:heure_debut,
            duree=:duree, matiere=:matiere, groupe=:groupe, adulte=:adulte, adulte_id=:adulte_id, role_adulte=:role_adulte,
            type=:type, regroupement_type=:regroupement_type, regroupement_id=:regroupement_id,
            couleur_override=:couleur_override, commentaire=:commentaire, updated_at=CURRENT_TIMESTAMP
        WHERE id=:id');
        return $stmt->execute(self::_bind($data, true));
    }

    /**
     * Fusion / séparation facultative : donne (ou retire) le même `regroupement_id` à
     * plusieurs créneaux. Les lignes restent indépendantes — c'est un choix D'AFFICHAGE,
     * jamais automatique, et il ne touche ni les durées, ni les stats, ni l'impression.
     *
     * @param int[] $ids
     * @param string|null $token null = séparer
     * @return int nombre de lignes modifiées
     */
    public static function setRegroupement(array $ids, ?string $token): int {
        $ids = array_values(array_filter(array_map('intval', $ids)));
        if (!$ids) return 0;
        $pdo = getDB();
        $ph = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare('UPDATE creneaux SET regroupement_id = ?, updated_at = CURRENT_TIMESTAMP
            WHERE id IN (' . $ph . ')');
        $stmt->execute(array_merge([$token], $ids));
        return $stmt->rowCount();
    }

    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM creneaux WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    /**
     * Copie les créneaux de la semaine type vers une semaine réelle.
     *
     * Décision 2.6 : une semaine DÉJÀ RETOUCHÉE ne s'écrase pas en silence. Avec
     * `$ecraser = false`, la semaine est laissée intacte et la méthode rend **-1**
     * (« ignorée, elle avait été retouchée ») ; l'appelant le dit à l'utilisateur.
     *
     * @return int nombre de créneaux copiés, ou -1 si la semaine a été préservée
     */
    public static function copyFromTemplate(int $semaineId, bool $ecraser = true): int {
        $pdo = getDB();
        if (!$ecraser) {
            $st = $pdo->prepare('SELECT est_modifiee FROM semaines WHERE id = :sid');
            $st->execute(['sid' => $semaineId]);
            $modifiee = (int)$st->fetchColumn();
            $st = $pdo->prepare('SELECT COUNT(*) FROM creneaux WHERE semaine_id = :sid');
            $st->execute(['sid' => $semaineId]);
            if ($modifiee === 1 && (int)$st->fetchColumn() > 0) {
                return -1;
            }
        }
        // Supprimer les créneaux existants de la semaine cible
        $pdo->prepare('DELETE FROM creneaux WHERE semaine_id = :sid')->execute(['sid' => $semaineId]);
        // Une semaine qui redevient la copie du modèle n'est plus « retouchée ».
        $pdo->prepare('UPDATE semaines SET est_modifiee = 0 WHERE id = :sid')->execute(['sid' => $semaineId]);
        // Copier depuis le template
        $stmt = $pdo->query('SELECT * FROM creneaux WHERE semaine_id IS NULL AND (annee_scolaire_id = ' . (int)self::_anneeActive() . ' OR annee_scolaire_id IS NULL)');
        $template = $stmt->fetchAll();
        $count = 0;
        $insert = $pdo->prepare('INSERT INTO creneaux (
            eleve_id, semaine_id, annee_scolaire_id, jour, heure_debut, duree, matiere, groupe, adulte,
            adulte_id, role_adulte, type, regroupement_type, regroupement_id, couleur_override, commentaire
        ) VALUES (
            :eleve_id, :semaine_id, :annee_scolaire_id, :jour, :heure_debut, :duree, :matiere, :groupe, :adulte,
            :adulte_id, :role_adulte, :type, :regroupement_type, :regroupement_id, :couleur_override, :commentaire
        )');
        foreach ($template as $c) {
            $c['semaine_id'] = $semaineId;
            // Un créneau de semaine RÉELLE ne porte pas d'année : elle se lit par `semaines`.
            // (Sans cette remise à zéro, la copie recopiait l'année du modèle.)
            $c['annee_scolaire_id'] = null;
            unset($c['id'], $c['created_at'], $c['updated_at']);
            $insert->execute(self::_bind($c));
            $count++;
        }
        return $count;
    }

    private static function _bind(array $data, bool $includeId = false): array {
        $strFields = ['jour','heure_debut','matiere','groupe','adulte','role_adulte','type','regroupement_type','regroupement_id','couleur_override','commentaire'];
        $intFields = ['eleve_id','semaine_id','duree'];
        // adulte_id : lien vers l'annuaire (décision 3.7). Résolu depuis le texte AVANT
        // l'appel, et seulement quand le texte ne désigne qu'UN adulte (voir _resoudreAdulteId).
        $params = [];
        foreach ($strFields as $f) {
            $params[$f] = isset($data[$f]) ? trim($data[$f]) : null;
        }
        foreach ($intFields as $f) {
            $params[$f] = isset($data[$f]) ? (int)$data[$f] : null;
        }
        $params['adulte_id'] = isset($data['adulte_id']) && $data['adulte_id'] !== null && $data['adulte_id'] !== ''
            ? (int)$data['adulte_id'] : null;
        $params['annee_scolaire_id'] = isset($data['annee_scolaire_id']) && $data['annee_scolaire_id'] !== null && $data['annee_scolaire_id'] !== ''
            ? (int)$data['annee_scolaire_id'] : null;
        if ($includeId) $params['id'] = (int)$data['id'];
        return $params;
    }
}
