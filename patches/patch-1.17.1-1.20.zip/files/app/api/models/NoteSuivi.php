<?php
/** Calulis — Modèle « Notes de suivi »
 *
 *  Le suivi ne concerne QUE des élèves : `eleve_id` est obligatoire (il est NOT NULL en base).
 *  Une note = un élève, une date, un type et un texte libre.
 *  Monoposte / monoutilisateur : la colonne `auteur` existe mais n'est plus saisie.
 *
 *  Toutes les requêtes sont préparées (PDO, émulation désactivée) et filtrées par année scolaire.
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/TypeNote.php';

class NoteSuivi {

    /** Statuts d'archivage admis par la lecture (décision 6.1). */
    public const ARCHIVES = ['0', '1', 'toutes'];

    private static function pdo(): PDO {
        return getDB();
    }

    /**
     * Liste des notes, filtrée.
     * @param int|null $anneeId Année scolaire active (null = toutes les années, cas rare)
     * @param array $filtres eleve_id, type, du, au
     */
    public static function all(?int $anneeId, array $filtres = []): array {
        $sql = "SELECT n.id, n.eleve_id, n.date_note, n.type, n.archivee, n.contenu, n.annee_scolaire_id,
                       e.nom AS eleve_nom, e.prenom AS eleve_prenom
                  FROM notes_suivi n
             LEFT JOIN eleves e ON e.id = n.eleve_id
                 WHERE 1 = 1";
        $params = [];

        if ($anneeId) {
            $sql .= " AND n.annee_scolaire_id = :annee_id";
            $params['annee_id'] = $anneeId;
        }
        // Décision 6.1 : une note archivée sort de l'affichage courant mais n'est jamais
        // supprimée. « toutes » est le seul mode qui la remet dans la liste (recherche par
        // période, par type et par mot). Le défaut est de NE PAS la montrer.
        $archivees = (string)($filtres['archivees'] ?? '0');
        if (!in_array($archivees, self::ARCHIVES, true)) {
            $archivees = '0';
        }
        if ($archivees === '1') {
            $sql .= " AND n.archivee = 1";
        } elseif ($archivees !== 'toutes') {
            $sql .= " AND n.archivee = 0";
        }
        if (!empty($filtres['eleve_id'])) {
            $sql .= " AND n.eleve_id = :eleve_id";
            $params['eleve_id'] = (int)$filtres['eleve_id'];
        }
        if (!empty($filtres['type']) && TypeNote::estConnu((string)$filtres['type'])) {
            $sql .= " AND n.type = :type";
            $params['type'] = $filtres['type'];
        }
        if (!empty($filtres['du'])) {
            $sql .= " AND n.date_note >= :du";
            $params['du'] = $filtres['du'];
        }
        if (!empty($filtres['au'])) {
            $sql .= " AND n.date_note <= :au";
            $params['au'] = $filtres['au'];
        }

        $sql .= " ORDER BY n.date_note DESC, n.id DESC";

        $stmt = self::pdo()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    /** Une note par son identifiant (null si absente) */
    public static function find(int $id): ?array {
        $stmt = self::pdo()->prepare(
            "SELECT n.id, n.eleve_id, n.date_note, n.type, n.archivee, n.contenu, n.annee_scolaire_id,
                    e.nom AS eleve_nom, e.prenom AS eleve_prenom
               FROM notes_suivi n
          LEFT JOIN eleves e ON e.id = n.eleve_id
              WHERE n.id = :id"
        );
        $stmt->execute(['id' => $id]);
        $note = $stmt->fetch(PDO::FETCH_ASSOC);
        return $note ?: null;
    }

    /** Crée une note et retourne son identifiant */
    public static function create(array $data, ?int $anneeId): int {
        $propre = self::_valider($data, true);
        // Décision 6.4 : une note créée porte TOUJOURS son année, déduite de sa date.
        // L'écran n'envoie pas l'année : sans cette règle, la note naissait sans année et
        // disparaissait du filtre « année en cours » (défaut vu par le test du 27/10).
        if (!$anneeId) {
            $anneeId = self::anneeDeDate($propre['date_note']);
        }

        $stmt = self::pdo()->prepare(
            "INSERT INTO notes_suivi (annee_scolaire_id, eleve_id, date_note, type, archivee, contenu)
             VALUES (:annee_id, :eleve_id, :date_note, :type, :archivee, :contenu)"
        );
        $stmt->execute([
            'annee_id'  => $anneeId,
            'eleve_id'  => $propre['eleve_id'],
            'date_note' => $propre['date_note'],
            'type'      => $propre['type'],
            'archivee'  => $propre['archivee'] ?? 0,
            'contenu'   => $propre['contenu'],
        ]);
        return (int)self::pdo()->lastInsertId();
    }

    /** Met à jour une note existante */
    public static function update(int $id, array $data): bool {
        $propre = self::_valider($data, false);

        // Changer la date change l'année : elle est recalculée, jamais laissée en arrière.
        if (array_key_exists('date_note', $propre)) {
            $annee = self::anneeDeDate($propre['date_note']);
            if ($annee) {
                $propre['annee_scolaire_id'] = $annee;
            }
        }

        $sets = [];
        $params = ['id' => $id];
        foreach (['eleve_id', 'date_note', 'type', 'contenu', 'archivee', 'annee_scolaire_id'] as $colonne) {
            if (array_key_exists($colonne, $propre)) {
                $sets[] = "$colonne = :$colonne";
                $params[$colonne] = $propre[$colonne];
            }
        }
        if (!$sets) {
            return false;
        }

        $stmt = self::pdo()->prepare(
            "UPDATE notes_suivi SET " . implode(', ', $sets) . " WHERE id = :id"
        );
        $stmt->execute($params);
        return $stmt->rowCount() >= 0; // 0 ligne modifiée = valeurs identiques, ce n'est pas une erreur
    }

    /** Supprime une note */
    public static function delete(int $id): bool {
        $stmt = self::pdo()->prepare("DELETE FROM notes_suivi WHERE id = :id");
        $stmt->execute(['id' => $id]);
        return $stmt->rowCount() > 0;
    }

    /** L'année scolaire qui contient une date, ou null si aucune ne la contient. */
    public static function anneeDeDate(string $date): ?int {
        $stmt = self::pdo()->prepare(
            "SELECT id FROM annees_scolaires
              WHERE :date BETWEEN date_debut AND date_fin
              ORDER BY date_debut DESC LIMIT 1"
        );
        $stmt->execute(['date' => $date]);
        $id = $stmt->fetchColumn();
        return $id === false ? null : (int)$id;
    }

    /** Champs autorisés, contrôlés et normalisés */
    private static function _valider(array $data, bool $creation): array {
        $propre = [];

        if ($creation || array_key_exists('eleve_id', $data)) {
            $eleveId = (int)($data['eleve_id'] ?? 0);
            if ($eleveId <= 0) {
                throw new InvalidArgumentException('La note doit concerner un élève');
            }
            $propre['eleve_id'] = $eleveId;
        }

        if ($creation || array_key_exists('contenu', $data)) {
            $contenu = trim((string)($data['contenu'] ?? ''));
            if ($contenu === '') {
                throw new InvalidArgumentException('La note est vide');
            }
            $propre['contenu'] = $contenu;
        }

        // Les types sont une DONNÉE (migration 020, décision 6.3) : on accepte toute clé
        // connue, y compris désactivée — une note ancienne doit rester modifiable.
        if ($creation || array_key_exists('type', $data)) {
            $type = trim((string)($data['type'] ?? ''));
            if ($type === '') {
                $type = TypeNote::cleParDefaut();
            }
            if (!TypeNote::estConnu($type)) {
                throw new InvalidArgumentException('Type de note inconnu : ' . $type);
            }
            $propre['type'] = $type;
        }

        // Décision 6.1 : archiver sort la note de l'affichage courant, sans la détruire.
        if ($creation || array_key_exists('archivee', $data)) {
            $propre['archivee'] = (int)(bool)($data['archivee'] ?? false);
        }

        if ($creation || array_key_exists('date_note', $data)) {
            $date = trim((string)($data['date_note'] ?? ''));
            if ($date === '') {
                $date = date('Y-m-d');
            }
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
                throw new InvalidArgumentException('Date invalide : ' . $date);
            }
            $propre['date_note'] = $date;
        }

        return $propre;
    }
}