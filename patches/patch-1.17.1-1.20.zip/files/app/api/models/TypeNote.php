<?php
/**
 * Calulis — Modèle « Types de notes » (table `types_notes`, décision 6.3 du 27/10/2026)
 *
 * POURQUOI UNE TABLE, ET PAS UNE CONSTANTE
 * Les types de notes vivaient dans `NoteSuivi::TYPES` : impossible d'ajouter « entretien
 * famille », « bilan de période » ou « réunion » sans livrer une version. La décision 6.3
 * demande de les rendre configurables, comme les types de documents depuis la 1.16.
 *
 * LA CLÉ NE CHANGE JAMAIS, LE LIBELLÉ SI
 * Une note enregistre la CLÉ de son type (`reussite`), jamais son libellé : renommer un
 * type change son affichage PARTOUT, y compris sur les notes déjà écrites, sans y toucher.
 * La couleur accompagne le libellé (pastille + liseré de la carte) : elle reste un choix
 * de présentation, jamais une information — le libellé est toujours écrit à côté.
 *
 * SUPPRIMER : on refuse tant que des notes portent le type, en disant combien et en
 * proposant de les réaffecter. Désactiver est la sortie douce : le type n'est plus proposé
 * à la saisie, les notes déjà écrites restent lisibles.
 */
require_once __DIR__ . '/../config.php';

class TypeNote
{
    /** Couleurs admises — les mêmes classes CSS que les notes (`t-<couleur>`). */
    public const COULEURS = ['observation', 'objectif', 'reussite', 'alerte', 'action', 'neutre'];

    private const LONGUEUR_CLE = 50;

    public static function tous(bool $actifsSeulement = false): array
    {
        $pdo = getDB();
        $sql = 'SELECT * FROM types_notes';
        if ($actifsSeulement) {
            $sql .= ' WHERE actif = 1';
        }
        $sql .= ' ORDER BY ordre, libelle';
        return $pdo->query($sql)->fetchAll();
    }

    /** Le référentiel attendu par le modèle : [cle => libellé]. */
    public static function referentiel(bool $actifsSeulement = true): array
    {
        $ref = [];
        foreach (self::tous($actifsSeulement) as $t) {
            $ref[(string)$t['cle']] = (string)$t['libelle'];
        }
        return $ref;
    }

    public static function find(int $id): ?array
    {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM types_notes WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function parCle(string $cle): ?array
    {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM types_notes WHERE cle = :cle');
        $stmt->execute(['cle' => $cle]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    /** La clé existe-t-elle, même désactivée ? Une note ancienne doit rester valide. */
    public static function estConnu(string $cle): bool
    {
        return self::parCle($cle) !== null;
    }

    /** Clé à utiliser quand aucun type n'est fourni : le premier actif, sinon « observation ». */
    public static function cleParDefaut(): string
    {
        foreach (self::tous(true) as $t) {
            return (string)$t['cle'];
        }
        return 'observation';
    }

    public static function creer(string $libelle, ?string $couleur = null, ?int $ordre = null): int
    {
        $libelle = trim($libelle);
        if ($libelle === '') {
            throw new InvalidArgumentException('Donnez un nom au type de note.');
        }
        $pdo = getDB();
        $cle = self::cleUnique($libelle);
        if ($ordre === null) {
            $ordre = 1 + (int)$pdo->query('SELECT COALESCE(MAX(ordre), 0) FROM types_notes')->fetchColumn();
        }
        $stmt = $pdo->prepare(
            'INSERT INTO types_notes (cle, libelle, couleur, ordre, actif)
             VALUES (:cle, :libelle, :couleur, :ordre, 1)'
        );
        $stmt->execute([
            'cle'     => $cle,
            'libelle' => calulis_substr($libelle, 120),
            'couleur' => self::couleurValide($couleur),
            'ordre'   => (int)$ordre,
        ]);
        return (int)$pdo->lastInsertId();
    }

    /** Modifie libellé, couleur, ordre ou actif. La CLÉ n'est jamais modifiable. */
    public static function modifier(int $id, array $data): bool
    {
        $existant = self::find($id);
        if (!$existant) {
            return false;
        }
        $libelle = array_key_exists('libelle', $data) ? trim((string)$data['libelle']) : (string)$existant['libelle'];
        if ($libelle === '') {
            throw new InvalidArgumentException('Le nom du type de note est obligatoire.');
        }
        $couleur = array_key_exists('couleur', $data) && $data['couleur'] !== null
            ? self::couleurValide((string)$data['couleur']) : (string)$existant['couleur'];
        $ordre = array_key_exists('ordre', $data) && $data['ordre'] !== null && $data['ordre'] !== ''
            ? (int)$data['ordre'] : (int)$existant['ordre'];
        $actif = array_key_exists('actif', $data) && $data['actif'] !== null
            ? (int)(bool)$data['actif'] : (int)$existant['actif'];

        $stmt = getDB()->prepare(
            'UPDATE types_notes SET libelle = :libelle, couleur = :couleur, ordre = :ordre, actif = :actif
             WHERE id = :id'
        );
        return $stmt->execute([
            'libelle' => calulis_substr($libelle, 120),
            'couleur' => $couleur,
            'ordre'   => $ordre,
            'actif'   => $actif,
            'id'      => $id,
        ]);
    }

    /** Nombre de notes qui portent ce type — TOUTES années confondues. */
    public static function compterNotes(string $cle): int
    {
        $stmt = getDB()->prepare('SELECT COUNT(*) FROM notes_suivi WHERE type = :cle');
        $stmt->execute(['cle' => $cle]);
        return (int)$stmt->fetchColumn();
    }

    public static function reaffecter(string $cleSource, string $cleCible): int
    {
        if ($cleSource === $cleCible) {
            return 0;
        }
        if (self::parCle($cleCible) === null) {
            throw new InvalidArgumentException('Le type de destination est inconnu.');
        }
        $stmt = getDB()->prepare('UPDATE notes_suivi SET type = :cible WHERE type = :source');
        $stmt->execute(['cible' => $cleCible, 'source' => $cleSource]);
        return $stmt->rowCount();
    }

    public static function supprimer(int $id): bool
    {
        $type = self::find($id);
        if (!$type) {
            return false;
        }
        if (self::compterNotes((string)$type['cle']) > 0) {
            throw new RuntimeException('Ce type est encore utilisé par des notes.');
        }
        $stmt = getDB()->prepare('DELETE FROM types_notes WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    /** Couleur inconnue = « neutre » : on n'invente pas une couleur qui n'existe pas en CSS. */
    private static function couleurValide(?string $couleur): string
    {
        $couleur = (string)$couleur;
        return in_array($couleur, self::COULEURS, true) ? $couleur : 'neutre';
    }

    public static function cleUnique(string $libelle): string
    {
        $base = self::slug($libelle);
        $stmt = getDB()->prepare('SELECT COUNT(*) FROM types_notes WHERE cle = :cle');
        $cle = $base;
        for ($i = 2; $i < 100; $i++) {
            $stmt->execute(['cle' => $cle]);
            if ((int)$stmt->fetchColumn() === 0) {
                return $cle;
            }
            $suffixe = '_' . $i;
            $cle = calulis_substr($base, self::LONGUEUR_CLE - strlen($suffixe)) . $suffixe;
        }
        return calulis_substr($base, self::LONGUEUR_CLE - 4) . '_' . random_int(1000, 9999);
    }

    /**
     * Règle de fabrication d'une clé IDENTIQUE aux types de documents : une seule
     * implémentation (TypeDocument::slug), pour que « Compte rendu d'ESS » donne la même
     * clé dans les deux référentiels.
     */
    public static function slug(string $libelle): string
    {
        require_once __DIR__ . '/TypeDocument.php';
        return TypeDocument::slug($libelle);
    }
}
