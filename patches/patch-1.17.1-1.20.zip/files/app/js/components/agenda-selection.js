/**
 * Calulis — Agenda Selection : clic, Ctrl+clic, Shift+clic
 * Ajouté à Agenda via Object.assign
 */

Object.assign(Agenda, {

    _select(cell, event) {
        const eleve = cell.dataset.eleve;
        const heure = cell.dataset.heure;
        const jour = cell.dataset.jour;
        const key = eleve + '_' + heure + '_' + jour;

        if (event.ctrlKey || event.metaKey) {
            // Ctrl+Click : toggle cette cellule
            if (this._selection.cells.has(key)) {
                this._selection.cells.delete(key);
            } else {
                this._selection.cells.set(key, { eleve, heure, jour });
                if (!this._selection.anchor) this._selection.anchor = { eleve, heure, jour };
            }
        } else if (event.shiftKey && this._selection.anchor) {
            // Shift+Click : rectangle depuis l'ancre
            const a = this._selection.anchor;
            // Les colonnes AFFICHÉES : avec un filtre actif, la grille ne montre
            // qu'une partie des élèves — l'ancien calcul sur tous les élèves
            // sélectionnait donc les mauvaises colonnes (corrigé le 26/10/2026).
            const source = (this._filteredEleves && this._filteredEleves.length ? this._filteredEleves : this._eleves);
            const eleves = source.map(e => String(e.id));
            const heures = Array.from(document.querySelectorAll('.agenda-hour-cell')).map(c => c.dataset.heure);
            const eIdxStart = eleves.indexOf(a.eleve);
            const eIdxEnd = eleves.indexOf(eleve);
            const hIdxStart = heures.indexOf(a.heure);
            const hIdxEnd = heures.indexOf(heure);
            if (eIdxStart >= 0 && eIdxEnd >= 0 && hIdxStart >= 0 && hIdxEnd >= 0) {
                const [eMin, eMax] = [Math.min(eIdxStart, eIdxEnd), Math.max(eIdxStart, eIdxEnd)];
                const [hMin, hMax] = [Math.min(hIdxStart, hIdxEnd), Math.max(hIdxStart, hIdxEnd)];
                this._selection.cells = new Map();
                for (let ei = eMin; ei <= eMax; ei++) {
                    for (let hi = hMin; hi <= hMax; hi++) {
                        const k = eleves[ei] + '_' + heures[hi] + '_' + jour;
                        this._selection.cells.set(k, { eleve: eleves[ei], heure: heures[hi], jour });
                    }
                }
            }
        } else {
            // Clic simple
            if (this._selection.cells.has(key) && this._selection.cells.size > 1) {
                return; // déjà dans la multi-sélection
            }
            this._selection.cells = new Map();
            this._selection.cells.set(key, { eleve, heure, jour });
            this._selection.anchor = { eleve, heure, jour };
        }

        this._highlightSelection();
        const status = document.getElementById('status-selection');
        if (status) {
            status.textContent = this._selection.cells.size > 0 ? this._selection.cells.size + ' sélectionné(s)' : '';
        }
    },

    _clearSelection() {
        this._selection = { anchor: null, cells: new Map() };
        this._highlightSelection();
        const status = document.getElementById('status-selection');
        if (status) status.textContent = '';
    },

    _highlightSelection() {
        document.querySelectorAll('.agenda-slot.selected, .agenda-slot-empty.selected').forEach(c => c.classList.remove('selected'));
        this._selection.cells.forEach((_, k) => {
            const [e, h, j] = k.split('_');
            const el = document.querySelector(
                `.agenda-slot[data-eleve="${e}"][data-heure="${h}"][data-jour="${j}"], ` +
                `.agenda-slot-empty[data-eleve="${e}"][data-heure="${h}"][data-jour="${j}"]`
            );
            if (el) el.classList.add('selected');
        });
    },

    _getSelectedCreneaux() {
        const result = [];
        this._selection.cells.forEach(({ eleve, heure }) => {
            const c = this._creneaux.find(cc =>
                cc.eleve_id === parseInt(eleve) && cc.jour === this._currentDay && cc.heure_debut === heure
            );
            if (c) result.push(c);
        });
        return result;
    },

});
