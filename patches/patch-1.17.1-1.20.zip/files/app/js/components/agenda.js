/**
 * Calulis — Composant Agenda (orchestrateur)
 * Orchestre les sous-modules : state, grid, selection, dnd, clipboard, keyboard, contextmenu
 * Rendu CSS Grid row-by-row — pas de positionnement absolu
 */
const roleLabels = {
    enseignant: 'Enseignant', aeshco: 'AESH Co', aeshi: 'AESH I',
    aeshm: 'AESH M', specialiste: 'Spécialiste', educateur: 'Éducateur',
    coordo_ulis: 'Coordo ULIS', assistant_familial: 'Ass. familial', autre: 'Autre'
};
const Agenda = {
    _eleves: [],
    _creneaux: [],
    _params: null,
    _semaineId: null,
    _semaines: [],
    _selection: { anchor: null, cells: new Map() },
    _clipboard: null,
    _periodes: [],
    _currentDay: 'lundi',
    _adultes: [],
    _viewMode: 'eleves',
    _filters: { eleve: '', groupe: '', adulte: '' },
    _heures: [],
    _filteredEleves: [],
    _dndBound: false,
    _kbBound: false,
    _dndGhost: null,
    _dndSourceEl: null,

    _roleLabel(role) {
        return roleLabels[role] || role?.replace(/_/g, ' ') || 'Autre';
    },

    /**
     * Ordre des colonnes élèves : `ordre` d'abord — c'est le choix de l'utilisatrice,
     * écrit par le glisser-déposer ou par le bouton « Classer par N° » —, puis nom et
     * prénom pour départager des valeurs égales.
     *
     * Historique : jusqu'au 26/10/2026, le tri lisait classe → numero → ordre. Le
     * glisser écrivait bien `ordre`, mais ce tri l'écrasait au rechargement ; et la
     * classe passait avant le numéro, donc aucune numérotation ne pouvait imposer
     * l'ordre voulu. La migration 012 a figé l'ordre affiché dans `ordre` pour que
     * rien ne saute au moment de la bascule.
     *
     * Séparé dans une méthode pour que le test (tests/verif-ordre-colonnes.mjs)
     * puisse réintroduire l'ancien tri en mode --negatif.
     */
    _cmpColonnes(a, b) {
        const oa = (a.ordre ?? 0) - (b.ordre ?? 0);
        if (oa !== 0) return oa;
        return (a.nom || '').localeCompare(b.nom || '')
            || (a.prenom || '').localeCompare(b.prenom || '');
    },

    async render(semaineId = null) {
        const view = document.getElementById('view-agenda');
        const gotoToday = State.get('agenda-goto-today');
        this._viewMode = State.get('agenda-view-mode') || 'eleves';
        this._initState();

        if (gotoToday) {
            State.set('agenda-goto-today', false);
            const today = nomJour(new Date());
            const jours = this._params?.jours_affiches || ['lundi', 'mardi', 'jeudi', 'vendredi'];
            if (jours.includes(today)) this._currentDay = today;
        }

        // Charger données
        try {
            const [eleves, rawParams] = await Promise.all([
                API.get('eleves.php?actif=1'),
                API.get('params.php'),
            ]);
            // L'ordre des colonnes est celui que l'utilisatrice a choisi : `ordre`,
            // écrit par le glisser-déposer ou par le bouton « Classer par N° ».
            // La classe et le numéro ne trient PLUS : la migration 012 a figé dans
            // `ordre` l'ordre affiché au moment de la mise à jour, donc aucune
            // colonne ne saute, et un glisser tient désormais au rechargement.
            this._eleves = eleves.filter(e => e.actif).sort((a, b) => this._cmpColonnes(a, b));
            this._params = {};
            rawParams.forEach(p => {
                try { this._params[p.cle] = JSON.parse(p.valeur); } catch { this._params[p.cle] = p.valeur; }
            });
        } catch (e) {
            view.innerHTML = `<p class="text-danger" style="padding:16px">Erreur chargement : ${escapeHtml(e.message)}</p>`;
            return;
        }

        try { this._semaines = await API.get('semaines.php'); } catch { this._semaines = []; }
        try { this._periodes = await API.get('periodes.php'); } catch { this._periodes = []; }
        try { this._adultes = await API.get('adultes.php'); } catch { this._adultes = []; }

        if (gotoToday && semaineId === null && this._semaines.length > 0) {
            const todayStr = aujourdhui();
            const semaineActuelle = this._semaines.find(s => s.date_debut <= todayStr && s.date_fin >= todayStr);
            if (semaineActuelle) semaineId = semaineActuelle.id;
        }
        this._semaineId = semaineId;

        try {
            const creneaux = await API.get('creneaux.php' + (semaineId !== null ? '?semaine_id=' + semaineId : '?semaine_id=null'));
            this._creneaux = creneaux.map(c => ({ ...c, heure_debut: c.heure_debut?.substring(0, 5) }));
        } catch (e) {
            view.innerHTML = `<p class="text-danger" style="padding:16px">Erreur chargement créneaux : ${escapeHtml(e.message)}</p>`;
            return;
        }

        const horaires = this._params.horaires || { debut: '08:30', fin: '16:30', duree_creneau: 15 };
        const couleurs = { ...COULEURS_TYPES_DEFAUT, ...(this._params.couleurs_types || {}) };
        const jours = this._params.jours_affiches || ['lundi', 'mardi', 'jeudi', 'vendredi'];
        const { heures, hasExtension, debutGrille, finGrille, debutStandard, finStandard } = this._computeGridHeures(horaires);
        const semaine = this._semaineId ? this._semaines.find(s => s.id === this._semaineId) : null;
        const formatSemaine = this._params?.format_semaine || 'scolaire';
        const fmtLabel = s => this._formatSemaineLabel(s, formatSemaine);
        const estVacances = semaine?.est_vacances;

        // Dates des jours
        const dayDates = {};
        if (semaine?.date_debut) {
            const lundi = new Date(semaine.date_debut + 'T00:00:00');
            const joursMap = { lundi: 0, mardi: 1, mercredi: 2, jeudi: 3, vendredi: 4 };
            jours.forEach(j => {
                const d = new Date(lundi);
                d.setDate(d.getDate() + (joursMap[j] || 0));
                dayDates[j] = d.getDate() + '/' + (d.getMonth() + 1);
            });
        }

        const semainesScolaires = this._semaines.filter(s => !s.est_vacances);

        // Numéro de période pour coloration alternée
        const periodColors = ['transparent', '#e8eaf0'];
        const getPeriodeNum = (() => {
            const all = [...this._semaines].sort((a, b) => a.date_debut.localeCompare(b.date_debut));
            let pNum = 1;
            const map = {};
            for (let i = 0; i < all.length; i++) {
                const prev = all[i - 1];
                if (prev && prev.est_vacances && !all[i].est_vacances) pNum++;
                if (!all[i].est_vacances) map[all[i].id] = pNum;
            }
            return map;
        })();

        const semaineOptions = [
            `<option value="">Semaine type 📋</option>`,
            ...semainesScolaires.map(s => {
                const bg = periodColors[(getPeriodeNum[s.id] || 1) % 2];
                const mod = s.est_modifiee ? ' ⚡' : '';
                return `<option value="${s.id}" ${s.id === this._semaineId ? 'selected' : ''} style="background:${bg}">${fmtLabel(s)}${mod}</option>`;
            })
        ].join('');

        // Événements de la semaine
        let evenementsSemaine = [];
        try {
            const asId = State.get('annee_scolaire_id');
            this._evenements = await API.get('evenements.php' + (asId ? '?annee_scolaire_id=' + asId : ''));
            if (semaine?.date_debut && semaine?.date_fin) {
                evenementsSemaine = this._evenements.filter(ev => {
                    if (!ev.date_debut) return false;
                    return ev.date_debut <= semaine.date_fin && (ev.date_fin || ev.date_debut) >= semaine.date_debut;
                });
            }
        } catch { this._evenements = []; }

        const adultesUniques = this._extractAdultes();
        const groupesList = [...new Set((this._creneaux || []).map(c => c.groupe).filter(Boolean))].filter(g => g.trim()).sort();
        const adulteFullNames = this._adultes.map(a => {
            const civilite = a.civilite ? a.civilite.trim() + ' ' : '';
            return civilite + escapeHtml(a.nom);
        });

        view.innerHTML = `
            <div class="toolbar">
                <div style="display:flex;align-items:center;gap:3px">
                    <button class="btn btn-sm btn-secondary" id="btn-prev-week">◀</button>
                    <select id="select-week" style="font-weight:600;font-size:13px;max-width:220px;padding:4px 6px;${estVacances ? 'color:var(--danger)' : ''}" data-help="Semaine|Choisissez une semaine pour voir son emploi du temps. La Semaine type 📋 est le modèle de base — commencez par elle, construisez votre EDT idéal, puis appliquez-le aux autres semaines. Les semaines avec ⚡ contiennent déjà des créneaux. Les vacances sont en rouge.">${semaineOptions}</select>
                    <button class="btn btn-sm btn-secondary" id="btn-next-week">▶</button>
                    <button class="btn btn-sm btn-secondary" id="btn-minical" data-help="Mini-calendrier|Naviguez rapidement entre les semaines et les périodes de l'année. Les zones de vacances sont rayées. Les pastilles de couleur indiquent les événements de la période.">📅</button>
                    ${semaine ? `<button class="btn btn-sm btn-secondary" id="btn-template-week">📋</button>` : ''}
                    <div class="view-toggle" id="view-toggle" data-help="Vue|👥 Élèves : l'emploi du temps est organisé par élève. 👤 Adultes : l'emploi du temps est organisé par adulte.">
                        <button class="view-toggle-btn btn-sm ${this._viewMode === 'eleves' ? 'active' : ''}" data-view="eleves" title="Vue élèves">👥</button>
                        <button class="view-toggle-btn btn-sm ${this._viewMode === 'adultes' ? 'active' : ''}" data-view="adultes" title="Vue adultes">👤</button>
                    </div>
                    ${this._viewMode === 'eleves' ? `<button class="btn btn-sm btn-secondary" id="btn-trier-numero" title="Ranger les colonnes selon les numéros d'élève (N°)" data-help="Trier par numéro|Range les colonnes dans l'ordre des numéros d'élève (champ N° de la fiche élève) ; les élèves sans numéro passent à la fin. Ensuite, glissez les colonnes pour ajuster : l'ordre choisi est conservé au rechargement.">Trier par N°</button>` : ''}
                    ${jours.map(j => `
                        <div class="day-tab-wrapper">
                            <button class="btn btn-sm day-tab ${j === this._currentDay ? 'btn-primary' : 'btn-secondary'}" data-day="${j}">${j.charAt(0).toUpperCase() + j.slice(1,3)}</button>
                            ${dayDates[j] ? `<span class="day-date">${dayDates[j]}</span>` : ''}
                        </div>
                    `).join('')}
                    <button class="btn btn-sm btn-secondary" id="btn-add-pause" title="Ajouter une récréation ou une pause du midi" data-help="Ajouter une pause|Ajoute une récréation ou une pause du midi à tous les élèves affichés, sur les jours de votre choix. Une pause est un créneau normal : sa couleur et son étiquette viennent du type de regroupement (RECREATION, PAUSE MIDI…), réglable dans Paramètres > Couleurs par type.">⏸️ Pause</button>
                </div>
            </div>
            <div class="filter-bar" data-help="Filtres de l'agenda|Filtre Élève, Groupe ou Intervenant. Cumulatifs (ET logique).">
                <span class="filter-wrap">
                    <input type="text" class="filter-input" id="filter-eleve" placeholder="🔍 Élève…" list="filter-eleve-list" value="${escapeHtml(this._filters.eleve)}" autocomplete="off">
                    <button class="filter-clear" id="filter-eleve-clear" style="display:${this._filters.eleve ? '' : 'none'}" title="Effacer">✕</button>
                </span>
                <datalist id="filter-eleve-list">${this._eleves.map(e => `<option value="${escapeHtml(e.prenom + ' ' + e.nom)}">`).join('')}</datalist>
                <select class="filter-input" id="filter-groupe">
                    <option value="">Tous les groupes</option>
                    ${groupesList.map(g => `<option value="${escapeHtml(g)}" ${this._filters.groupe === g ? 'selected' : ''}>${escapeHtml(g)}</option>`).join('')}
                </select>
                <select class="filter-input" id="filter-adulte">
                    <option value="">Tous les intervenants</option>
                    ${adulteFullNames.map(n => `<option value="${n}" ${this._filters.adulte === n ? 'selected' : ''}>${n}</option>`).join('')}
                </select>
                ${(this._filters.eleve || this._filters.groupe || this._filters.adulte) ? '<button class="btn btn-sm btn-secondary" id="filter-reset" title="Réinitialiser">✕</button>' : ''}
            </div>
            ${evenementsSemaine.length > 0 ? `
            <div class="events-strip" id="events-strip">
                ${evenementsSemaine.map(ev => `
                    <span class="event-pill" style="background:${ev.couleur || '#e3f2fd'}" title="${escapeHtml(ev.description || ev.nom)}">
                        📌 ${escapeHtml(ev.nom)}
                        ${ev.date_debut ? ' · ' + formatDate(ev.date_debut) : ''}
                        ${ev.date_fin && ev.date_fin !== ev.date_debut ? ' → ' + formatDate(ev.date_fin) : ''}
                    </span>
                `).join('')}
            </div>` : ''}
            ${!semaine ? `
            <div class="toolbar" style="padding-top:0;margin-top:-8px">
                <span style="font-size:11px;color:var(--text-muted);margin-right:8px">Appliquer le template :</span>
                <button class="btn btn-sm btn-primary" id="btn-propagate-all">Toutes</button>
                <button class="btn btn-sm btn-secondary" id="btn-propagate-unmodified">Non modifiées</button>
                <button class="btn btn-sm btn-secondary" id="btn-propagate-select">Choisir...</button>
            </div>` : ''}
            <div class="card" style="flex:1;overflow:auto;padding:0" id="agenda-scroll" data-help="Grille|Double-clic case vide = créer un créneau. Double-clic créneau = modifier. Clic droit = copier/couper/coller. Drag & drop = déplacer (Ctrl = copier). Survol = détail du créneau.">
                <div class="agenda-grid-css" id="agenda-grid-css" style="--agenda-cols:${this._viewMode === 'eleves' ? this._eleves.length : adultesUniques.length}"></div>
            </div>
            <div class="minical-popover hidden" id="minical-popover">
                <div class="minical-header">📅 Calendrier scolaire</div>
                <div class="minical-body" id="minical-body"></div>
            </div>
        `;

        // Les pauses sont des créneaux normaux (type de regroupement RECREATION / PAUSE MIDI)
        this._buildGrid(heures, jours, couleurs, []);
        this._bindEvents();
    },

    /* ─── Helpers ─── */

    _formatSemaineLabel(s, format) {
        if (format === 'iso') {
            const wn = getISOWeek(s.date_debut);
            return `S${s.date_debut.substring(0, 4)}-W${wn} · ${formatDate(s.date_debut)} → ${formatDate(s.date_fin)}`;
        }
        if (format === 'periode') {
            const all = [...this._semaines].sort((a, b) => a.date_debut.localeCompare(b.date_debut));
            let pNum = 1, sInP = 0;
            for (let i = 0; i < all.length; i++) {
                const prev = all[i - 1];
                if (prev && prev.est_vacances && !all[i].est_vacances) { pNum++; sInP = 0; }
                if (all[i].id === s.id && !all[i].est_vacances) {
                    sInP++;
                    return `P${pNum}S${sInP} · ${formatDate(s.date_debut)} → ${formatDate(s.date_fin)}`;
                }
                if (!all[i].est_vacances) sInP++;
            }
        }
        return `S${getSchoolWeekNumber(s, this._semaines)} · ${formatDate(s.date_debut)} → ${formatDate(s.date_fin)}`;
    },

    _heureToMin(t) { const [h, m] = (t || '00:00').split(':').map(Number); return h * 60 + m; },

    _minToHeure(min) { const mm = Math.max(0, min); return String(Math.floor(mm / 60)).padStart(2, '0') + ':' + String(mm % 60).padStart(2, '0'); },

    _buildHeures(debut, fin, pas) {
        const h = [];
        const [dh, dm] = debut.split(':').map(Number);
        const [fh, fm] = fin.split(':').map(Number);
        let cur = dh * 60 + dm;
        const end = fh * 60 + fm;
        while (cur < end) {
            h.push(String(Math.floor(cur / 60)).padStart(2, '0') + ':' + String(cur % 60).padStart(2, '0'));
            cur += pas;
        }
        return h;
    },

    _computeGridHeures(horaires) {
        const fmtHM = m => String(Math.floor(m / 60)).padStart(2, '0') + ':' + String(m % 60).padStart(2, '0');
        const pas = horaires.duree_creneau || 15;
        const minDebut = this._heureToMin(horaires.debut || '08:30');
        const maxFin = this._heureToMin(horaires.fin || '16:30');
        let extendedDebut = minDebut;
        let extendedFin = maxFin;

        (this._creneaux || []).forEach(c => {
            const cd = this._heureToMin(c.heure_debut);
            const cf = cd + (c.duree || pas);
            if (cd < extendedDebut) extendedDebut = cd;
            if (cf > extendedFin) extendedFin = cf;
        });

        const apc = this._params?.apc;
        if (apc?.actif && apc?.slots) {
            apc.slots.forEach(s => {
                const cd = this._heureToMin(s.debut);
                const cf = this._heureToMin(s.fin);
                if (cd < extendedDebut) extendedDebut = cd;
                if (cf > extendedFin) extendedFin = cf;
            });
        }

        extendedDebut = Math.floor(extendedDebut / pas) * pas;
        extendedFin = Math.ceil(extendedFin / pas) * pas;

        // Grille continue du matin au soir : plus de compression de la pause méridienne.
        // Les pauses (récréation, pause du midi) sont des créneaux normaux, ce qui permet
        // de faire chevaucher une prise en charge avec le temps du midi.
        const heures = this._buildHeures(fmtHM(extendedDebut), fmtHM(extendedFin), pas);

        return {
            heures,
            hasExtension: extendedDebut < minDebut || extendedFin > maxFin,
            debutGrille: fmtHM(extendedDebut),
            finGrille: fmtHM(extendedFin),
            debutStandard: horaires.debut || '08:30',
            finStandard: horaires.fin || '16:30',
        };
    },

    _getFilteredEleves() {
        return this._eleves.filter(e => {
            if (this._filters.groupe && !this._creneaux.some(c => c.eleve_id === e.id && c.groupe === this._filters.groupe)) return false;
            if (this._filters.eleve) {
                const q = this._filters.eleve.toLowerCase();
                if (!(e.prenom + ' ' + e.nom).toLowerCase().includes(q)) return false;
            }
            if (this._filters.adulte) {
                if (!this._creneaux.some(c => c.eleve_id === e.id && c.adulte && c.adulte.trim().endsWith(this._filters.adulte.trim()))) return false;
            }
            return true;
        });
    },

    _extractAdultes() {
        // Le filtre « Intervenant » doit agir AUSSI en vue Adultes (scénario 4 de l'aide) :
        // il ne garde alors que la colonne de la personne choisie. La comparaison passe par
        // _nomsAdultes(), qui ignore la civilité et la casse : le filtre porte « Mme MARTIN »
        // quand la colonne s'appelle « MARTIN ».
        const filtre = this._filters?.adulte ? this._nomsAdultes(this._filters.adulte) : [];
        return this._adultes.filter(a => a.actif).map(a => ({
            id: a.id,
            name: a.nom,
            role: a.role || '',
        })).filter(a => !filtre.length || this._nomsAdultes(a.name).some(n => filtre.includes(n)));
    },

    /* ─── Bind events (hors DnD, clavier, sélection — gérés par les sous-modules) ─── */

    _bindEvents() {
        const selectWeek = document.getElementById('select-week');
        if (selectWeek) {
            selectWeek.addEventListener('change', () => {
                const val = selectWeek.value;
                this.render(val !== '' ? parseInt(val) : null);
            });
        }

        document.getElementById('btn-template-week')?.addEventListener('click', () => this.render(null));

        document.getElementById('btn-propagate-all')?.addEventListener('click', () => this._propagateTemplate('all'));
        document.getElementById('btn-propagate-unmodified')?.addEventListener('click', () => this._propagateTemplate('unmodified'));
        document.getElementById('btn-propagate-select')?.addEventListener('click', () => this._propagateSelect());

        const btnMiniCal = document.getElementById('btn-minical');
        const popover = document.getElementById('minical-popover');
        btnMiniCal?.addEventListener('click', (e) => {
            e.stopPropagation();
            popover.classList.toggle('hidden');
        });
        if (this._miniCalDocHandler) document.removeEventListener('click', this._miniCalDocHandler);
        this._miniCalDocHandler = (e) => {
            if (popover && !popover.classList.contains('hidden') && !popover.contains(e.target) && e.target !== btnMiniCal) {
                popover.classList.add('hidden');
            }
        };
        document.addEventListener('click', this._miniCalDocHandler);

        document.querySelectorAll('.view-toggle-btn').forEach(btn => {
            btn.addEventListener('click', () => {
                const newView = btn.dataset.view;
                if (newView === this._viewMode) return;
                this._viewMode = newView;
                State.set('agenda-view-mode', newView);
                this._selection = { anchor: null, cells: new Map() };
                this.render(this._semaineId);
            });
        });

        document.querySelectorAll('.day-tab').forEach(btn => {
            btn.addEventListener('click', () => {
                this._currentDay = btn.dataset.day;
                this._selection = { anchor: null, cells: new Map() };
                this.render(this._semaineId);
            });
        });

        // Filtres
        const filterEleve = document.getElementById('filter-eleve');
        const filterGroupe = document.getElementById('filter-groupe');
        const filterAdulte = document.getElementById('filter-adulte');
        const filterEleveClear = document.getElementById('filter-eleve-clear');

        filterEleve?.addEventListener('input', () => {
            this._filters.eleve = filterEleve.value;
            if (filterEleveClear) filterEleveClear.style.display = filterEleve.value ? '' : 'none';
            this._rebuildGrid();
        });
        filterEleveClear?.addEventListener('click', () => {
            filterEleve.value = '';
            this._filters.eleve = '';
            filterEleveClear.style.display = 'none';
            this._rebuildGrid();
        });
        filterGroupe?.addEventListener('change', () => {
            this._filters.groupe = filterGroupe.value;
            this._rebuildGrid();
        });
        filterAdulte?.addEventListener('change', () => {
            this._filters.adulte = filterAdulte.value;
            this._rebuildGrid();
        });
        document.getElementById('filter-reset')?.addEventListener('click', () => {
            this._filters = { eleve: '', groupe: '', adulte: '' };
            this.render(this._semaineId);
        });

        this._buildMiniCal();
        this._bindNav();
        this._bindGridEvents();
        // Sous-modules
        this._bindDnD();
        this._bindKeyboard();
    },

    _bindGridEvents() {
        const isConsult = State.get('consultation');

        if (this._viewMode === 'adultes') {
            this._bindColumnDrag('adulte');
            if (!isConsult) {
                document.querySelectorAll('.agenda-slot').forEach(cell => {
                    cell.addEventListener('dblclick', () => {
                        const adulte = cell.dataset.adulte;
                        const heure = cell.dataset.heure;
                        const jour = cell.dataset.jour;
                        // Comparaison NORMALISÉE (civilité et casse ignorées), comme le contrôle
                        // de conflit : le libellé de la colonne vient du PREMIER créneau rencontré
                        // (`adultePrefixMap`), alors que les créneaux d'une même colonne peuvent
                        // avoir été enregistrés avec ou sans civilité (« Mme MARTIN » et
                        // « MARTIN »). Une comparaison exacte laissait des cases SANS réponse au
                        // double-clic (relevé du 29/09/2026, corrigé le même jour).
                        const nomsColonne = new Set(this._nomsAdultes(adulte));
                        const creneaux = this._creneaux.filter(c =>
                            c.heure_debut === heure && c.jour === jour
                            && this._nomsAdultes(c.adulte).some(n => nomsColonne.has(n))
                        );
                        if (creneaux.length > 0) this._showAdultCellDetail(adulte, heure, jour, creneaux);
                    });
                });
            }
            return;
        }

        // Vue élèves : drag & drop des colonnes + double-clic fiche
        this._bindColumnDrag('eleve');

        if (isConsult) return;

        // Clic, double-clic, clic droit sur les cellules
        document.querySelectorAll('.agenda-slot-empty, .agenda-slot[data-id]').forEach(cell => {
            cell.addEventListener('click', (e) => this._select(cell, e));
            cell.addEventListener('dblclick', (e) => this._openEditModal(cell));
            cell.addEventListener('contextmenu', (e) => { e.preventDefault(); this._showContextMenu(cell, e); });
        });

        // Bouton explicite « ⏸️ Pause » + raccourci : clic sur la colonne des heures
        document.getElementById('btn-trier-numero')?.addEventListener('click', () => {
            this._trierColonnesParNumero();
        });

        document.getElementById('btn-add-pause')?.addEventListener('click', () => {
            this._openPauseModal(this._params?.horaires?.debut || '10:00');
        });
        document.querySelectorAll('.agenda-hour-cell').forEach(cell => {
            cell.addEventListener('click', () => {
                const h = cell.dataset.heure;
                if (h && !State.get('consultation')) this._openPauseModal(h);
            });
        });
    },

    /* ─── Drag & drop des colonnes (élèves/adultes) ─── */

    _bindColumnDrag(type) {
        let draggedId = null;
        document.querySelectorAll('.agenda-gh-cell').forEach(th => {
            th.addEventListener('dblclick', () => {
                if (type === 'eleve') {
                    const id = parseInt(th.dataset.eleve);
                    const eleve = this._eleves.find(e => e.id === id);
                    if (eleve) FicheEleve.open(eleve, true);
                }
            });
            th.addEventListener('dragstart', e => {
                if (State.get('consultation')) { e.preventDefault(); return; }
                draggedId = parseInt(th.dataset.eleve || th.dataset.adulteId);
                e.dataTransfer.setData('text/plain', 'drag');
                e.dataTransfer.effectAllowed = 'move';
                th.classList.add('dragging');
            });
            th.addEventListener('dragend', () => {
                th.classList.remove('dragging');
                draggedId = null;
                document.querySelectorAll('.agenda-gh-cell').forEach(c => c.classList.remove('drag-over'));
            });
            th.addEventListener('dragover', e => {
                if (State.get('consultation')) return;
                e.preventDefault();
                e.dataTransfer.dropEffect = 'move';
                th.classList.add('drag-over');
            });
            th.addEventListener('dragleave', () => th.classList.remove('drag-over'));
            th.addEventListener('drop', async e => {
                if (State.get('consultation')) return;
                e.preventDefault();
                th.classList.remove('drag-over');
                const targetId = parseInt(th.dataset.eleve || th.dataset.adulteId);
                if (!draggedId || draggedId === targetId) return;

                const items = type === 'eleve' ? this._eleves : this._adultes;
                const dIdx = items.findIndex(x => x.id === draggedId);
                const tIdx = items.findIndex(x => x.id === targetId);
                if (dIdx < 0 || tIdx < 0) return;

                const ordreAvant = items.map(x => ({ id: x.id, ordre: x.ordre }));
                const [dragged] = items.splice(dIdx, 1);
                items.splice(tIdx, 0, dragged);
                items.forEach((x, i) => x.ordre = i);

                try {
                    const ordres = items.map(x => ({ id: x.id, ordre: x.ordre }));
                    const endpoint = type === 'eleve' ? 'eleves.php' : 'adultes.php';
                    await API.put(endpoint, { action: 'reorder', ordres });
                } catch (e) {
                    // L'ordre est désormais LA donnée de l'écran : un échec silencieux
                    // laissait croire à un enregistrement qui n'avait pas eu lieu
                    // (relevé le 26/10/2026). On remet l'ordre précédent et on le dit.
                    ordreAvant.forEach(o => {
                        const it = items.find(x => x.id === o.id);
                        if (it) it.ordre = o.ordre;
                    });
                    items.sort((a, b) => (a.ordre ?? 0) - (b.ordre ?? 0));
                    if (typeof Toast !== 'undefined') Toast.error('Ordre non enregistré : ' + e.message);
                }

                this._selection = { anchor: null, cells: new Map() };
                this._rebuildGrid();
            });
        });
    },

    /* ─── Durées réelles d'une sélection multi-cases ─── */

    /**
     * Durée réellement obtenue pour CHAQUE élève d'une sélection de plusieurs cases.
     * Les cases d'un même élève ne comptent que si elles sont CONTIGUËS (même règle
     * que l'enregistrement, qui écrit un créneau par plage continue).
     * @returns {Object<string, number>} durée en minutes, par identifiant d'élève
     */
    _dureesParEleve(cells, dureePas) {
        const byEleve = {};
        cells.forEach(({ eleve, heure }) => {
            (byEleve[eleve] = byEleve[eleve] || []).push(heure);
        });
        const minutes = (h) => {
            const [a, b] = String(h).split(':').map(Number);
            return a * 60 + b;
        };
        const out = {};
        Object.entries(byEleve).forEach(([eleve, heures]) => {
            heures.sort();
            let total = 0;
            let debut = heures[0], fin = heures[0];
            for (let i = 1; i <= heures.length; i++) {
                if (i < heures.length && minutes(heures[i]) === minutes(fin) + dureePas) {
                    fin = heures[i];
                    continue;
                }
                total += minutes(fin) - minutes(debut) + dureePas;
                if (i < heures.length) { debut = heures[i]; fin = heures[i]; }
            }
            out[eleve] = total;
        });
        return out;
    },

    /** Les créneaux sélectionnés peuvent-ils former un bloc ? (même début, même durée, colonnes voisines) */
    _peutFusionner(liste) {
        if (!liste || liste.length < 2) return false;
        const dureePas = this._params?.horaires?.duree_creneau || 15;
        const premier = liste[0];
        const debut = String(premier.heure_debut || '').substring(0, 5);
        const duree = Number(premier.duree || dureePas);
        const identiques = liste.every(c => c.jour === premier.jour
            && String(c.heure_debut || '').substring(0, 5) === debut
            && Number(c.duree || dureePas) === duree);
        if (!identiques) return false;
        if (new Set(liste.map(c => Number(c.eleve_id))).size !== liste.length) return false;
        const cols = liste
            .map(c => (this._filteredEleves || []).findIndex(e => Number(e.id) === Number(c.eleve_id)))
            .sort((a, b) => a - b);
        return cols.every(col => col >= 0) && cols.every((col, i) => i === 0 || col === cols[i - 1] + 1);
    },

    /** Recharge les créneaux puis redessine la grille (après une fusion, une séparation…). */
    async _rechargerCreneaux() {
        this._creneaux = await API.get('creneaux.php' + (this._semaineId !== null ? '?semaine_id=' + this._semaineId : '?semaine_id=null'));
        this._creneaux = this._creneaux.map(c => ({ ...c, heure_debut: c.heure_debut?.substring(0, 5) }));
        this._rebuildGrid();
    },

    /** Jeton court et unique pour un bloc fusionné (choix facultatif). */
    _nouveauToken() {
        return 'r' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
    },

    /** Détache les blocs qui ne contiennent plus qu'un créneau (après une suppression). */
    async _nettoyerGroupes() {
        const parToken = {};
        (this._creneaux || []).forEach(c => {
            if (!c.regroupement_id) return;
            (parToken[c.regroupement_id] = parToken[c.regroupement_id] || []).push(c);
        });
        for (const liste of Object.values(parToken)) {
            if (liste.length >= 2) continue;
            try {
                await API.put('creneaux.php', {
                    action: 'regroupement',
                    ids: liste.map(c => c.id),
                    regroupement_id: null,
                });
                liste.forEach(c => { c.regroupement_id = null; });
            } catch { /* silencieux */ }
        }
        this._rebuildGrid();
    },

    /** Texte lisible quand les élèves n'ont pas la même durée dans la sélection. */
    _dureesTexte(parEleve) {
        return Object.entries(parEleve || {}).map(([id, d]) => {
            const e = (this._eleves || []).find(x => String(x.id) === String(id));
            return (e ? e.prenom : 'Élève ' + id) + ' : ' + d + ' min';
        }).join(' · ');
    },

    /* ─── Classer les colonnes selon le numéro d'élève ─── */

    /**
     * Range les colonnes dans l'ordre des numéros d'élève (champ N° de la fiche).
     * Les élèves sans numéro passent à la fin. L'ordre est écrit en base (action
     * reorder), donc il tient au rechargement — et l'utilisatrice peut ensuite
     * glisser les colonnes pour ajuster.
     */
    async _trierColonnesParNumero() {
        if (State.get('consultation')) return;
        const rang = (e) => {
            const n = e.numero;
            return (n === null || n === undefined || n === '') ? Infinity : Number(n);
        };
        const ordonnes = [...this._eleves].sort((a, b) => {
            const ra = rang(a), rb = rang(b);
            if (ra !== rb) return (ra === Infinity ? 1 : rb === Infinity ? -1 : ra - rb);
            return (a.nom || '').localeCompare(b.nom || '')
                || (a.prenom || '').localeCompare(b.prenom || '');
        });
        const ordreAvant = this._eleves.map(e => ({ id: e.id, ordre: e.ordre }));
        ordonnes.forEach((e, i) => { e.ordre = i; });
        try {
            await API.put('eleves.php', {
                action: 'reorder',
                ordres: ordonnes.map(e => ({ id: e.id, ordre: e.ordre })),
            });
            if (typeof Toast !== 'undefined') Toast.info('Colonnes rangées selon les numéros d’élève.');
        } catch (e) {
            // Ne pas afficher un ordre que rien n'a enregistré : on remet le précédent.
            ordreAvant.forEach(o => {
                const el = this._eleves.find(x => x.id === o.id);
                if (el) el.ordre = o.ordre;
            });
            if (typeof Modal !== 'undefined') Modal.alert('Ordre non enregistré', e.message);
        }
        this.render(this._semaineId);
    },

    /* ─── Mini calendrier ─── */

    _buildMiniCal() {
        const body = document.getElementById('minical-body');
        if (!body || !this._periodes.length) return;

        const all = [...this._semaines].sort((a, b) => a.date_debut.localeCompare(b.date_debut));
        const currentId = this._semaineId;
        const fmt = this._params?.format_semaine || 'scolaire';

        const eventsParSemaine = {};
        (this._evenements || []).forEach(ev => {
            if (!ev.date_debut) return;
            all.forEach(s => {
                if (ev.date_debut <= s.date_fin && (ev.date_fin || ev.date_debut) >= s.date_debut) {
                    if (!eventsParSemaine[s.id]) eventsParSemaine[s.id] = [];
                    eventsParSemaine[s.id].push(ev);
                }
            });
        });

        let html = '';
        this._periodes.sort((a, b) => a.ordre - b.ordre).forEach(periode => {
            const semainesPeriode = all.filter(s =>
                s.date_debut >= periode.date_debut && s.date_fin <= periode.date_fin
            );
            if (!semainesPeriode.length) return;

            html += `<div class="minical-periode">
                <div class="minical-periode-name">${escapeHtml(periode.nom)}</div>
                <div class="minical-weeks">`;

            semainesPeriode.forEach(s => {
                let label;
                if (fmt === 'iso') label = getISOWeek(s.date_debut);
                else if (fmt === 'periode') {
                    const scolaires = semainesPeriode.filter(ss => !ss.est_vacances);
                    const idx = scolaires.indexOf(s) + 1;
                    label = s.est_vacances ? 'V' : 'S' + idx;
                } else label = s.est_vacances ? 'V' : 'S' + getSchoolWeekNumber(s, all);

                const active = s.id === currentId ? ' active' : '';
                const modifiee = s.est_modifiee ? ' modifiee' : '';
                const vacances = s.est_vacances ? ' vacances' : '';
                const hasEvent = eventsParSemaine[s.id] ? ' has-event' : '';
                const eventTitle = eventsParSemaine[s.id] ? ' — ' + eventsParSemaine[s.id].map(e => e.nom).join(', ') : '';
                html += `<button class="minical-week${active}${modifiee}${vacances}${hasEvent}" data-id="${s.id}" title="${escapeHtml(this._formatSemaineLabel(s, fmt))}${eventTitle}">${label}</button>`;
            });

            html += '</div></div>';
        });

        body.innerHTML = html || '<p style="padding:16px;color:var(--text-muted)">Aucune semaine</p>';

        body.querySelectorAll('.minical-week').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = parseInt(btn.dataset.id);
                if (id && id !== this._semaineId) this.render(id);
                document.getElementById('minical-popover').classList.add('hidden');
            });
        });
    },

    _bindNav() {
        const semainesScolaires = this._semaines.filter(s => !s.est_vacances);
        if (semainesScolaires.length > 0) {
            document.getElementById('btn-prev-week')?.addEventListener('click', () => {
                const idx = semainesScolaires.findIndex(s => s.id === this._semaineId);
                if (idx > 0) this.render(semainesScolaires[idx - 1].id);
            });
            document.getElementById('btn-next-week')?.addEventListener('click', () => {
                const idx = semainesScolaires.findIndex(s => s.id === this._semaineId);
                if (idx < semainesScolaires.length - 1) this.render(semainesScolaires[idx + 1].id);
            });
        } else {
            document.getElementById('btn-prev-week')?.addEventListener('click', () => this.render(null));
            document.getElementById('btn-next-week')?.addEventListener('click', () => this.render(null));
        }
    },

    /* ─── Propagation du template ─── */

    async _propagateTemplate(mode) {
        if (!await Modal.confirm('Propager', mode === 'all'
            ? 'Appliquer le template à TOUTES les semaines (les modifications locales seront écrasées) ?'
            : 'Appliquer le template aux semaines NON MODIFIÉES uniquement ?')) return;
        const today = aujourdhui();
        const scolaires = this._semaines.filter(s => s.date_fin >= today && !s.est_vacances);
        let ids;
        if (mode === 'all') ids = scolaires.map(s => s.id);
        else ids = scolaires.filter(s => !s.est_modifiee).map(s => s.id);
        if (ids.length === 0) { Modal.alert('Info', 'Aucune semaine à mettre à jour.'); return; }
        try {
            // R22 (audit du 27/10/2026) : le défaut du serveur n'écrase plus. Le mode « tout »
            // ANNONCE dans sa question que les semaines retouchées seront écrasées : il doit
            // donc le demander explicitement, sinon la fenêtre mentirait.
            const res = await API.post('creneaux.php', {
                action: 'copy_from_template',
                semaine_ids: ids,
                ecraser: mode === 'all' ? 1 : 0,
            });
            Modal.alert('Succès', `${res.count} créneaux copiés vers ${res.semaines} semaines.`);
            this.render(null);
        } catch (e) { Modal.alert('Erreur', e.message); }
    },

    async _propagateSelect() {
        let periodes = [];
        const asId2 = State.get('annee_scolaire_id') || (this._semaines[0]?.annee_scolaire_id) || 1;
        try { periodes = await API.get('periodes.php?annee_scolaire_id=' + asId2); } catch {}
        const today = aujourdhui();
        const semainesFutures = this._semaines.filter(s => s.date_fin >= today && !s.est_vacances);

        let periodeGroups = periodes.map(p => {
            const semaines = semainesFutures.filter(s => s.date_debut >= p.date_debut && s.date_fin <= p.date_fin);
            if (semaines.length === 0) return null;
            return `<optgroup label="${p.nom} (${formatDate(p.date_debut)} → ${formatDate(p.date_fin)})">
                ${semaines.map(s => {
                    const fmt = this._formatSemaineLabel(s, this._params?.format_semaine || 'scolaire');
                    return `<option value="${s.id}">${fmt}${s.est_modifiee ? ' ⚡' : ''}${s.est_vacances ? ' 🏖️' : ''}</option>`;
                }).join('')}
            </optgroup>`;
        }).filter(Boolean).join('');

        // Fallback sans périodes définies : liste plate des semaines futures
        if (!periodeGroups) {
            periodeGroups = semainesFutures.map(s => {
                const fmt = this._formatSemaineLabel(s, this._params?.format_semaine || 'scolaire');
                return `<option value="${s.id}">${fmt}${s.est_modifiee ? ' ⚡' : ''}${s.est_vacances ? ' 🏖️' : ''}</option>`;
            }).join('');
        }

        Modal.open({
            title: 'Propager le template vers...',
            body: `
                <p class="text-muted" style="margin-bottom:8px">Choisis les semaines cibles (Ctrl+Click pour sélection multiple)</p>
                <select id="propagate-targets" multiple style="width:100%;min-height:250px;font-size:13px">
                    ${periodeGroups}
                </select>
                <p class="text-muted" style="margin-top:4px;font-size:11px">⚡ = modifiée · 🏖️ = vacances · Passé = exclu</p>
                <label style="display:flex;align-items:center;gap:6px;margin-top:8px;font-size:13px">
                    <input type="checkbox" id="propagate-ecraser"> Écraser aussi les semaines retouchées (⚡)
                </label>
                <p class="text-muted small" style="margin:2px 0 0 22px">Sans cette case, une semaine retouchée est <strong>laissée intacte</strong> : vous êtes averti à la fin, semaine par semaine.</p>
            `,
            footer: `
                <button class="btn btn-secondary" onclick="Modal.close()">Annuler</button>
                <button class="btn btn-primary" id="btn-propagate-confirm">Appliquer</button>
            `,
        });

        document.getElementById('btn-propagate-confirm').addEventListener('click', async () => {
            const select = document.getElementById('propagate-targets');
            const ids = Array.from(select.selectedOptions).map(o => parseInt(o.value));
            if (ids.length === 0) return;
            const ecraser = document.getElementById('propagate-ecraser')?.checked ? 1 : 0;
            try {
                const res = await API.post('creneaux.php', { action: 'copy_from_template', semaine_ids: ids, ecraser });
                Modal.close();
                // Décision 2.6 : on NOMME les semaines préservées, on n'affiche pas un total muet.
                const nommer = (liste) => (liste || []).map(id => {
                    const s = this._semaines.find(x => x.id === id);
                    return s ? this._formatSemaineLabel(s, this._params?.format_semaine || 'scolaire') : ('#' + id);
                }).join(', ');
                let msg = `${res.count} créneaux copiés vers ${res.semaines} semaine(s).`;
                if ((res.ignorees || []).length) {
                    msg += `\n\nPréservée(s) car retouchée(s) : ${nommer(res.ignorees)}.`;
                }
                if ((res.passees || []).length) {
                    msg += `\n\nNon modifiée(s) car passée(s) : ${nommer(res.passees)}.`;
                }
                Modal.alert('Propagation', msg);
                this.render(null);
            } catch (e) { Modal.alert('Erreur', e.message); }
        });
    },

    /* ─── Marquer semaine modifiée ─── */

    async _markModified() {
        if (!this._semaineId) return;
        try {
            await API.put('semaines.php?id=' + this._semaineId, { est_modifiee: 1 });
        } catch { /* silencieux */ }
    },

    /* ─── Modale édition créneau ─── */

    async _openEditModal(cell) {
        const isConsult = State.get('consultation');
        const cid = cell.dataset.id;
        const creneau = cid ? this._creneaux.find(c => c.id === parseInt(cid)) : null;
        if (isConsult) return;

        // Un bloc fusionné est UN objet à l'écran mais N lignes en base. « Modifier »
        // doit donc écrire sur les N lignes : l'ancien chemin n'en modifiait qu'une et
        // le bloc affichait la nouvelle valeur pour tout le monde (bloquant du 26/10/2026).
        const tokenBloc = cell.dataset.groupe || '';
        const lignesBloc = tokenBloc
            ? (this._creneaux || []).filter(c => c.regroupement_id === tokenBloc)
            : [];
        this._editionBloc = (creneau && lignesBloc.length > 1)
            ? { token: tokenBloc, lignes: lignesBloc.map(c => ({ id: c.id, eleve_id: c.eleve_id })) }
            : null;

        const multi = !creneau && this._selection.cells.size > 1;
        const cellCount = this._selection.cells.size;
        const dureePas = this._params?.horaires?.duree_creneau || 15;

        // Durée annoncée = celle que l'enregistrement écrira, élève par élève.
        // L'ancien calcul prenait l'UNION des cases : 10:00 pour l'un + 10:15 pour
        // l'autre affichait 30 min alors que chaque élève n'avait que 15 min
        // (défaut signalé par l'utilisatrice le 26/10/2026).
        let multiDuree = dureePas;
        let multiDureesDiffer = null;
        let multiFusionnable = false;
        if (multi) {
            const parEleve = this._dureesParEleve(this._selection.cells, dureePas);
            const valeurs = [...new Set(Object.values(parEleve))];
            // La fusion facultative exige des durées identiques ET au moins deux élèves.
            multiFusionnable = valeurs.length === 1 && Object.keys(parEleve).length >= 2;
            if (valeurs.length === 1) {
                multiDuree = valeurs[0];
            } else {
                multiDuree = null;
                multiDureesDiffer = parEleve;
            }
        }

        // Heure de fin calculée pour le créneau simple
        let finHeure = '';
        if (!multi) {
            const debutStr = creneau?.heure_debut || cell.dataset.heure || '';
            if (debutStr) {
                const debutMin = this._heureToMin(debutStr);
                const dureeMin = creneau?.duree || dureePas;
                const finMin = debutMin + dureeMin;
                finHeure = String(Math.floor(finMin / 60)).padStart(2, '0') + ':' + String(finMin % 60).padStart(2, '0');
            }
        }

        const ro = isConsult ? 'disabled' : '';
        const types = Object.keys({ ...COULEURS_TYPES_DEFAUT, ...(this._params?.couleurs_types || {}) });
        const roles = ['enseignant','aeshco','aeshi','aeshm','specialiste','educateur','autre'];

        const buildAdultOpts = () => {
            const activeAdultes = (this._adultes || []).filter(a => a.actif !== false);
            const opts = activeAdultes.map(a => {
                const suffix = a.fonction ? ` · ${a.fonction}` : (a.role ? ` · ${this._roleLabel(a.role)}` : '');
                const label = [a.prenom, a.nom].filter(Boolean).join(' ') + suffix;
                return `<option value="${escapeHtml(a.nom)}" data-role="${escapeHtml(a.role||'')}">${escapeHtml(label)}</option>`;
            }).join('');
            return '<option value="">— Aucun —</option>' + opts;
        };

        const roleOptsHtml = roles.map(r => `<option value="${r}">${this._roleLabel(r)}</option>`).join('');

        const buildAdulteRow = (adulteNom, roleVal, canRemove) => {
            const activeAdultes = (this._adultes || []).filter(a => a.actif !== false);
            let opts = buildAdultOpts();
            if (adulteNom && !activeAdultes.some(a => a.nom === adulteNom)) {
                opts = opts.replace('</select>', `<option value="${escapeHtml(adulteNom)}" selected>${escapeHtml(adulteNom)}</option></select>`);
            }
            const rmBtn = canRemove ? '<button type="button" class="btn btn-sm btn-danger btn-rm-adulte" title="Retirer" style="flex-shrink:0">✕</button>' : '';
            return `<div class="adulte-row" style="display:flex;gap:4px;align-items:flex-end;margin-bottom:4px">
                <div style="flex:3"><select class="edit-adulte-sel" ${ro} style="width:100%">${opts}</select></div>
                <div style="flex:1"><select class="edit-role-sel" ${ro} style="width:100%">${roleOptsHtml}</select></div>
                ${rmBtn}
            </div>`;
        };

        const adultesExistants = (creneau?.adulte || '').split(', ').filter(Boolean);
        const rolesExistants = (creneau?.role_adulte || '').split(', ').filter(Boolean);
        if (adultesExistants.length === 0) adultesExistants.push('');
        let adultesRowsHtml = '';
        adultesExistants.forEach((nom, i) => {
            adultesRowsHtml += buildAdulteRow(nom, rolesExistants[i] || '', i > 0);
        });

        const groupesExistants = [...new Set((this._creneaux || []).map(c => c.groupe).filter(Boolean))].sort();
        const currentGroupe = creneau?.groupe || '';
        if (currentGroupe && !groupesExistants.includes(currentGroupe)) groupesExistants.push(currentGroupe);

        const joursAffiches = this._params?.jours_affiches || ['lundi', 'mardi', 'jeudi', 'vendredi'];
        let joursHtml = '';
        if (!creneau) {
            const curJour = cell.dataset.jour || this._currentDay;
            joursHtml = '<div class="form-group"><label>Jours</label><div style="display:flex;gap:10px;flex-wrap:wrap">'
                + joursAffiches.map(j => {
                    const checked = j === curJour ? ' checked' : '';
                    const lbl = j.charAt(0).toUpperCase() + j.slice(1);
                    return '<label style="display:flex;align-items:center;gap:4px;font-size:13px;cursor:pointer"><input type="checkbox" class="edit-jour-cb" value="' + j + '"' + checked + '> ' + lbl + '</label>';
                }).join('')
                + '</div></div>';
        }
        const groupesDatalistOpts = groupesExistants.map(g => `<option value="${escapeHtml(g)}">`).join('');

        Modal.open({
            title: isConsult ? 'Détail' : (creneau
                ? (this._editionBloc ? `Modifier le bloc (${this._editionBloc.lignes.length} élèves)` : 'Modifier')
                : (multi ? `Nouveaux créneaux (${cellCount} cellules)` : 'Nouveau créneau')),
            body: `
                ${multi ? `<p class="text-muted" style="margin-bottom:12px">Création groupée sur ${cellCount} cellules</p>` : ''}
                ${this._editionBloc ? `<p class="text-muted" style="margin-bottom:12px">Ce bloc réunit <strong>${this._editionBloc.lignes.length} élèves</strong> : les champs ci-dessous seront écrits sur les ${this._editionBloc.lignes.length} créneaux. Changer l'heure ou la durée détache le bloc.</p>` : ''}
                <input type="hidden" id="edit-id" value="${creneau?.id || ''}">
                <input type="hidden" id="edit-jour" value="${creneau?.jour || cell.dataset.jour || this._currentDay}">
                ${multi ? '<input type="hidden" id="edit-multi" value="1">' : `<input type="hidden" id="edit-eleve" value="${creneau?.eleve_id || cell.dataset.eleve || ''}">`}
                <div class="form-row">
                    <div class="form-group"><label>Matière</label><input type="text" id="edit-matiere" value="${escapeHtml(creneau?.matiere || '')}" ${ro}></div>
                    <div class="form-group">
                        <label>Groupe</label>
                        ${ro ? `<span>${escapeHtml(currentGroupe) || '—'}</span>` : `
                            <input type="text" id="edit-groupe" list="groupes-datalist" value="${escapeHtml(currentGroupe)}" placeholder="Nom du groupe…" autocomplete="off" style="width:100%">
                            <datalist id="groupes-datalist">${groupesDatalistOpts}</datalist>
                        `}
                    </div>
                </div>
                <div class="form-group">
                    <label style="display:flex;justify-content:space-between;align-items:center">
                        <span>Adulte(s)</span>
                        ${!ro ? '<button type="button" class="btn btn-sm btn-secondary" id="btn-add-adulte">➕ Ajouter</button>' : ''}
                    </label>
                    <div id="adultes-rows">${adultesRowsHtml}</div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label>Type</label><select id="edit-type" ${ro}><option value="fixe" ${creneau?.type === 'fixe' ? 'selected' : ''}>Fixe</option><option value="exception" ${creneau?.type === 'exception' ? 'selected' : ''}>Exception</option><option value="ponctuel" ${creneau?.type === 'ponctuel' ? 'selected' : ''}>Ponctuel</option></select></div>
                    <div class="form-group"><label>Regroupement</label><select id="edit-regroupement" ${ro}>${types.map(t => `<option ${creneau?.regroupement_type === t ? 'selected' : ''}>${t}</option>`).join('')}</select></div>
                </div>
                ${joursHtml}
                <div class="form-group"><label>Commentaire</label><textarea id="edit-commentaire" rows="2" ${ro}>${escapeHtml(creneau?.commentaire || '')}</textarea></div>
                ${multi ? `
                <div class="form-group"><label>Durée</label><span>${multiDuree !== null ? multiDuree + ' min' : this._dureesTexte(multiDureesDiffer)}</span></div>
                <div class="form-group">
                    <label style="display:flex;align-items:center;gap:6px;cursor:${multiFusionnable ? 'pointer' : 'not-allowed'}" data-help="Un seul bloc|Facultatif : affiche les créneaux de plusieurs élèves comme un seul bloc continu. Ils restent enregistrés élève par élève — statistiques et emplois du temps individuels ne changent pas. Décochez pour garder un bloc par élève.">
                        <input type="checkbox" id="edit-fusionner" ${multiFusionnable ? '' : 'disabled'}>
                        <span>Un seul bloc</span>
                    </label>
                    <p class="text-muted" style="margin:2px 0 0 22px;font-size:12px">${multiFusionnable
                        ? 'Facultatif : les créneaux restent enregistrés élève par élève, mais s’affichent en un seul bloc continu.'
                        : 'Indisponible : les élèves n’ont pas la même durée dans la sélection.'}</p>
                </div>
                ` : (ro ? `
                <div class="form-row">
                    <div class="form-group"><label>Début</label><span>${creneau?.heure_debut || cell.dataset.heure || ''}</span></div>
                    <div class="form-group"><label>Fin</label><span>${finHeure}</span></div>
                </div>
                <div class="form-group"><label>Durée</label><span>${creneau?.duree || dureePas} min</span></div>
                ` : `
                <div class="form-row">
                    <div class="form-group"><label>Début</label><input type="time" id="edit-debut" step="${dureePas * 60}" value="${creneau?.heure_debut || cell.dataset.heure || ''}"></div>
                    <div class="form-group"><label>Fin</label><input type="time" id="edit-fin" step="${dureePas * 60}" value="${finHeure}"></div>
                </div>
                <input type="hidden" id="edit-duree" value="${creneau?.duree || dureePas}">
                <div style="margin-top:4px;font-size:13px;color:var(--text-muted)">Durée : <strong id="edit-duree-display">${creneau?.duree || dureePas} min</strong></div>
                `)}
            `,
            footer: isConsult ? '<button class="btn btn-secondary" onclick="Modal.close()">Fermer</button>' : `
                ${creneau ? '<button class="btn btn-danger" id="btn-del-creneau">Supprimer</button>' : ''}
                <button class="btn btn-secondary" onclick="Modal.close()">Annuler</button>
                <button class="btn btn-primary" id="btn-save-creneau">Enregistrer</button>
            `,
        });

        if (adultesExistants.length > 0) {
            const rows = document.querySelectorAll('#adultes-rows .adulte-row');
            rows.forEach((row, i) => {
                const sel = row.querySelector('.edit-adulte-sel');
                const roleSel = row.querySelector('.edit-role-sel');
                if (sel && adultesExistants[i]) sel.value = adultesExistants[i];
                if (roleSel && rolesExistants[i]) roleSel.value = rolesExistants[i];
            });
        }

        if (!isConsult) {
            const bindRow = (row) => {
                const adulteSel = row.querySelector('.edit-adulte-sel');
                const roleSel = row.querySelector('.edit-role-sel');
                adulteSel?.addEventListener('change', function () {
                    const role = this.selectedOptions[0]?.dataset?.role;
                    if (role && roleSel) roleSel.value = role;
                });
            };
            document.querySelectorAll('#adultes-rows .adulte-row').forEach(bindRow);

            if (!multi) {
                const debutInput = document.getElementById('edit-debut');
                const finInput = document.getElementById('edit-fin');
                const dureeHidden = document.getElementById('edit-duree');
                const dureeDisplay = document.getElementById('edit-duree-display');

                const updateFinFromDebut = () => {
                    if (!debutInput || !finInput || !dureeHidden) return;
                    const duree = parseInt(dureeHidden.value) || dureePas;
                    const [h, m] = debutInput.value.split(':').map(Number);
                    if (isNaN(h) || isNaN(m)) return;
                    const finMin = h * 60 + m + duree;
                    finInput.value = String(Math.floor(finMin / 60)).padStart(2, '0') + ':' + String(finMin % 60).padStart(2, '0');
                };

                const updateDureeFromFin = () => {
                    if (!debutInput || !finInput || !dureeHidden) return;
                    const [dh, dm] = debutInput.value.split(':').map(Number);
                    const [fh, fm] = finInput.value.split(':').map(Number);
                    if (isNaN(dh) || isNaN(dm) || isNaN(fh) || isNaN(fm)) return;
                    let dureeMin = (fh * 60 + fm) - (dh * 60 + dm);
                    const duree = Math.round(dureeMin / dureePas) * dureePas;
                    if (duree <= 0) return;
                    dureeHidden.value = duree;
                    if (dureeDisplay) dureeDisplay.textContent = duree + ' min';
                };

                debutInput?.addEventListener('change', updateFinFromDebut);
                finInput?.addEventListener('change', updateDureeFromFin);
            }

            document.getElementById('btn-add-adulte')?.addEventListener('click', () => {
                const container = document.getElementById('adultes-rows');
                const rowCount = container.querySelectorAll('.adulte-row').length;
                const newRow = buildAdulteRow('', '', rowCount > 0);
                container.insertAdjacentHTML('beforeend', newRow);
                const added = container.lastElementChild;
                bindRow(added);
                added.querySelector('.btn-rm-adulte')?.addEventListener('click', () => added.remove());
            });

            document.querySelectorAll('#adultes-rows .btn-rm-adulte').forEach(btn => {
                btn.addEventListener('click', () => btn.closest('.adulte-row')?.remove());
            });

            // Deux clics rapides ne doivent pas créer DEUX créneaux (js/utils/actions.js).
            const boutonEnregistrerCreneau = document.getElementById('btn-save-creneau');
            boutonEnregistrerCreneau?.addEventListener('click', () => Action.uneSeule(boutonEnregistrerCreneau, () => this._saveCreneau()));
            document.getElementById('btn-del-creneau')?.addEventListener('click', async () => {
                if (await Modal.confirm('Supprimer', 'Supprimer ce créneau ?')) {
                    await API.del('creneaux.php?id=' + creneau.id);
                    await this._markModified();
                    Modal.close();
                    await this._rechargerCreneaux();
                    await this._nettoyerGroupes();
                }
            });
        }
    },

    async _saveCreneau() {
        const isMulti = document.getElementById('edit-multi')?.value === '1';
        const dureePas = this._params?.horaires?.duree_creneau || 15;

        // Jours sélectionnés (création multi-jours) — sinon jour unique
        let joursSel = [document.getElementById('edit-jour').value];
        const joursCbs = Array.from(document.querySelectorAll('.edit-jour-cb:checked')).map(cb => cb.value);
        if (joursCbs.length > 0) joursSel = joursCbs;

        const groupe = document.getElementById('edit-groupe')?.value?.trim() || '';

        const adultesNoms = [];
        const adultesRoles = [];
        document.querySelectorAll('#adultes-rows .adulte-row').forEach(row => {
            const nom = row.querySelector('.edit-adulte-sel')?.value?.trim();
            const role = row.querySelector('.edit-role-sel')?.value?.trim();
            if (nom) { adultesNoms.push(nom); adultesRoles.push(role || 'autre'); }
        });
        // Construit le nom affiché avec civilité (M., Mme, Dr...)
        const buildAdulteDisplay = (nom) => {
            // Si le nom a déjà un préfixe (ex: "M. Dupont"), le conserver
            if (/^(M\.|Mme|Dr\.?)\s/.test(nom)) return nom;
            const adulte = (this._adultes || []).find(a => a.nom === nom);
            if (adulte && adulte.civilite) {
                return adulte.civilite.trim() + ' ' + nom;
            }
            return nom;
        };
        const adulte = adultesNoms.map(buildAdulteDisplay).join(', ');
        const role_adulte = adultesRoles.join(', ');

        // Une entrée par créneau à écrire : la cible (contrôle de conflit) et l'action.
        const idExistant = document.getElementById('edit-id')?.value || '';
        const aFaire = [];
        let separationGroupe = null;   // bloc à détacher parce que sa durée/ heure change

        if (isMulti) {
            // Fusion facultative : la case n'existe que si les durées sont identiques.
            const fusionner = document.getElementById('edit-fusionner')?.checked === true;
            const tokenFusion = fusionner ? this._nouveauToken() : null;
            const baseData = {
                matiere: document.getElementById('edit-matiere').value,
                groupe, adulte, role_adulte,
                type: document.getElementById('edit-type').value,
                regroupement_type: document.getElementById('edit-regroupement').value,
                commentaire: document.getElementById('edit-commentaire').value,
                regroupement_id: tokenFusion,
            };
            if (this._semaineId !== null) baseData.semaine_id = this._semaineId;

            const byEleve = {};
            this._selection.cells.forEach(({ eleve, heure }) => {
                if (!byEleve[eleve]) byEleve[eleve] = [];
                byEleve[eleve].push(heure);
            });

            for (const jour of joursSel) {
                Object.entries(byEleve).forEach(([eleve, heures]) => {
                    heures.sort();
                    let runStart = heures[0];
                    let runEnd = heures[0];
                    for (let i = 1; i <= heures.length; i++) {
                        const [eh, em] = runEnd.split(':').map(Number);
                        const nextMin = eh * 60 + em + dureePas;
                        const expected = String(Math.floor(nextMin / 60)).padStart(2, '0') + ':' + String(nextMin % 60).padStart(2, '0');
                        if (i < heures.length && heures[i] === expected) {
                            runEnd = heures[i];
                        } else {
                            const [sh, sm] = runStart.split(':').map(Number);
                            const [eh2, em2] = runEnd.split(':').map(Number);
                            const dureeTotale = (eh2 * 60 + em2) - (sh * 60 + sm) + dureePas;
                            const cible = { eleve_id: parseInt(eleve), jour, heure_debut: runStart, duree: dureeTotale, adulte };
                            const data = { ...baseData, ...cible };
                            aFaire.push({ cible, executer: () => API.post('creneaux.php', data) });
                            if (i < heures.length) { runStart = heures[i]; runEnd = heures[i]; }
                        }
                    }
                });
            }
        } else {
            const baseData = {
                eleve_id: parseInt(document.getElementById('edit-eleve').value),
                heure_debut: document.getElementById('edit-debut').value,
                matiere: document.getElementById('edit-matiere').value,
                groupe, adulte, role_adulte,
                type: document.getElementById('edit-type').value,
                regroupement_type: document.getElementById('edit-regroupement').value,
                commentaire: document.getElementById('edit-commentaire').value,
                duree: parseInt(document.getElementById('edit-duree').value) || 15,
            };
            if (this._semaineId !== null) baseData.semaine_id = this._semaineId;
            // Fusion facultative : modifier l'heure ou la durée d'une ligne d'un bloc
            // SÉPARE le bloc — un bloc ne peut pas couvrir des durées différentes.
            const avantModif = idExistant ? this._creneaux.find(c => c.id === parseInt(idExistant)) : null;
            const tokenAvant = avantModif?.regroupement_id || null;
            const bloc = this._editionBloc;
            const horaireChange = !!tokenAvant && (
                String(baseData.heure_debut).substring(0, 5) !== String(avantModif.heure_debut).substring(0, 5)
                || Number(baseData.duree) !== Number(avantModif.duree)
            );
            if (bloc && bloc.lignes.length > 1) {
                // Édition d'un BLOC : un objet à l'écran, N créneaux en base. Les champs
                // communs sont écrits sur les N lignes ; changer l'heure ou la durée
                // détache le bloc (il n'a de sens qu'à horaire unique).
                const idsBloc = bloc.lignes.map(l => l.id);
                for (const jour of joursSel) {
                    for (const ligne of bloc.lignes) {
                        const cible = {
                            eleve_id: ligne.eleve_id,
                            jour,
                            heure_debut: baseData.heure_debut,
                            duree: baseData.duree,
                            adulte,
                            // Tout le bloc est ignoré : il ne se signale pas lui-même.
                            ignorer: idsBloc,
                        };
                        const data = {
                            ...baseData,
                            eleve_id: ligne.eleve_id,
                            jour,
                            regroupement_id: horaireChange ? null : bloc.token,
                        };
                        aFaire.push({
                            cible,
                            executer: () => API.put('creneaux.php?id=' + ligne.id, data),
                        });
                    }
                }
                if (horaireChange && typeof Toast !== 'undefined') {
                    Toast.info('Bloc détaché : changer l’heure ou la durée sépare les élèves.');
                }
            } else {
                for (const jour of joursSel) {
                    const cible = {
                        eleve_id: baseData.eleve_id,
                        jour,
                        heure_debut: baseData.heure_debut,
                        duree: baseData.duree,
                        // Le contrôle porte aussi sur les adultes : un adulte déjà occupé
                        // ailleurs au même moment est un conflit (29/09/2026).
                        adulte,
                        // Le créneau modifié ne doit pas se signaler lui-même comme conflit.
                        ignorer: idExistant ? [parseInt(idExistant)] : [],
                    };
                    const separe = !!tokenAvant && (
                        jour !== avantModif.jour
                        || String(baseData.heure_debut).substring(0, 5) !== String(avantModif.heure_debut).substring(0, 5)
                        || Number(baseData.duree) !== Number(avantModif.duree)
                    );
                    if (separe) separationGroupe = tokenAvant;
                    const data = { ...baseData, jour, regroupement_id: separe ? null : tokenAvant };
                    aFaire.push({
                        cible,
                        executer: () => (idExistant
                            ? API.put('creneaux.php?id=' + idExistant, data)
                            : API.post('creneaux.php', data)),
                    });
                }
            }
        }

        // Un professionnel peut travailler avec plusieurs élèves au même moment (binôme,
        // groupe, durées différentes). Un chevauchement d'ADULTE n'est donc plus bloquant :
        //  - même début ET même durée  -> c'est la même séance, on ne demande rien ;
        //  - durées différentes        -> on demande « ajouter quand même ? », sans rien effacer.
        // Seul le conflit d'ÉLÈVE (le même élève deux fois) reste bloquant.
        const conflits = this._chevauchements(aFaire.map(x => x.cible));
        const dureePasConflit = this._params?.horaires?.duree_creneau || 15;
        const memeSeance = (cible, occ) =>
            String(cible.heure_debut).substring(0, 5) === String(occ.heure_debut || '').substring(0, 5)
            && Number(cible.duree || dureePasConflit) === Number(occ.duree || dureePasConflit);

        let aExecuter = aFaire;
        let aSupprimer = [];

        // 1) Conflits d'ÉLÈVE : le même élève deux fois au même moment.
        const conflitsEleve = conflits
            .map(c => ({
                ...c,
                occupants: c.occupants.filter(o => Number(o.eleve_id) === Number(c.cible.eleve_id)),
            }))
            .filter(c => c.occupants.length > 0);
        if (conflitsEleve.length > 0) {
            const choix = await this._askConflit(conflitsEleve.length, {
                titre: idExistant ? 'Modifier le créneau' : 'Créer un créneau',
                question: this._questionConflit(conflitsEleve),
            });
            if (choix === 'annuler') return;   // la fenêtre de saisie reste ouverte
            if (choix === 'ignorer') {
                const enConflit = new Set(conflitsEleve.map(c => c.cible));
                aExecuter = aFaire.filter(x => !enConflit.has(x.cible));
                if (aExecuter.length === 0) {
                    Toast.info('Aucun créneau écrit : toutes les cases visées étaient occupées.');
                    return;
                }
            }
            if (choix === 'ecraser') {
                // On n'efface QUE les créneaux du MÊME élève. Effacer la ligne d'un
                // autre élève parce que l'adulte y figure aussi détruisait un binôme
                // (défaut constaté le 26/10/2026) : ce n'est plus possible.
                const ids = [];
                conflitsEleve.forEach(c => c.occupants.forEach(o => {
                    if (Number(o.eleve_id) === Number(c.cible.eleve_id)) ids.push(o.id);
                }));
                aSupprimer = [...new Set(ids)];
            }
        }

        // 2) Chevauchements d'ADULTE seulement : jamais de suppression, une question.
        const conflitsAdulte = conflits.filter(c =>
            c.occupants.some(o => Number(o.eleve_id) !== Number(c.cible.eleve_id))
            && c.occupants.some(o => !memeSeance(c.cible, o)));
        if (conflitsAdulte.length > 0) {
            const choix = await this._askPartageAdulte(conflitsAdulte,
                idExistant ? 'Modifier le créneau' : 'Créer un créneau');
            if (choix === 'annuler') return;
        }

        try {
            if (aSupprimer.length > 0) {
                await Promise.all(aSupprimer.map(id => API.del('creneaux.php?id=' + id)));
            }
            await Promise.all(aExecuter.map(x => x.executer()));
            if (separationGroupe) {
                // Le bloc ne peut plus tenir : on détache les autres lignes du groupe.
                const autres = this._creneaux
                    .filter(c => c.regroupement_id === separationGroupe && c.id !== parseInt(idExistant))
                    .map(c => c.id);
                if (autres.length) {
                    try {
                        await API.put('creneaux.php', { action: 'regroupement', ids: autres, regroupement_id: null });
                    } catch { /* silencieux : le créneau est écrit, le bloc se séparera au rendu */ }
                    if (typeof Toast !== 'undefined') Toast.info('Bloc séparé : les durées ne sont plus les mêmes.');
                }
            }
            await this._markModified();
            this._editionBloc = null;
            Modal.close();
            this._selection = { anchor: null, cells: new Map() };
            this.render(this._semaineId);
        } catch (e) { Modal.alert('Erreur', e.message); }
    },

    /**
     * Ajout explicite d'une pause (récréation, pause du midi…).
     * Une pause est un créneau NORMAL : sa couleur et son étiquette viennent du
     * type de regroupement (RECREATION, PAUSE MIDI…). Aucun système séparé.
     */
    async _openPauseModal(heure, eleveId = null) {
        const dureePas = this._params?.horaires?.duree_creneau || 15;
        const types = Object.keys({ ...COULEURS_TYPES_DEFAUT, ...(this._params?.couleurs_types || {}) });
        const typeDefaut = types.includes('RECREATION') ? 'RECREATION' : types[types.length - 1];
        const joursAffiches = this._params?.jours_affiches || ['lundi', 'mardi', 'jeudi', 'vendredi'];
        const finDefaut = this._minToHeure(this._heureToMin(heure) + dureePas);

        Modal.open({
            title: eleveId ? 'Ajouter une pause (cet élève)' : 'Ajouter une pause (tous les élèves)',
            body: `<p class="text-muted small" style="margin-bottom:12px">Récréation, pause du midi, temps calme… La pause est un créneau comme un autre : sa couleur vient du type de regroupement (réglable dans Paramètres).</p>
                   <div class="form-row">
                       <div class="form-group"><label>Nom</label><input type="text" id="pause-nom" value="Récréation"></div>
                       <div class="form-group"><label>Type de regroupement</label><select id="pause-type">${types.map(t => `<option ${t === typeDefaut ? 'selected' : ''}>${escapeHtml(t)}</option>`).join('')}</select></div>
                   </div>
                   <div class="form-row">
                       <div class="form-group"><label>Début</label><input type="time" id="pause-debut" step="${dureePas * 60}" value="${heure}"></div>
                       <div class="form-group"><label>Fin</label><input type="time" id="pause-fin" step="${dureePas * 60}" value="${finDefaut}"></div>
                   </div>
                   <div class="form-group"><label>Jours</label><div style="display:flex;gap:10px;flex-wrap:wrap">
                       ${joursAffiches.map(j => `<label style="display:flex;align-items:center;gap:4px;font-size:13px;cursor:pointer"><input type="checkbox" class="pause-jour-cb" value="${j}" checked> ${j.charAt(0).toUpperCase() + j.slice(1)}</label>`).join('')}
                   </div></div>`,
            footer: '<button class="btn btn-secondary" onclick="Modal.close()">Annuler</button><button class="btn btn-primary" id="btn-save-pause">Ajouter</button>',
        });

        document.getElementById('btn-save-pause').addEventListener('click', async () => {
            const nom = document.getElementById('pause-nom').value.trim();
            const debut = document.getElementById('pause-debut').value;
            const fin = document.getElementById('pause-fin').value;
            const type = document.getElementById('pause-type').value;
            const jours = Array.from(document.querySelectorAll('.pause-jour-cb:checked')).map(cb => cb.value);
            if (!nom || !debut || !fin) { Toast.error('Nom, début et fin sont obligatoires.'); return; }
            if (jours.length === 0) { Toast.error('Choisissez au moins un jour.'); return; }
            const duree = Math.round((this._heureToMin(fin) - this._heureToMin(debut)) / dureePas) * dureePas;
            if (duree <= 0) { Toast.error('La fin doit être après le début.'); return; }

            const baseData = {
                type: 'fixe',
                heure_debut: debut,
                duree: duree,
                matiere: nom,
                regroupement_type: type,
            };

            const cibles = eleveId ? [{ id: eleveId }] : this._eleves;
            let aCreer = [];
            cibles.forEach(e => {
                jours.forEach(jour => { aCreer.push({ ...baseData, eleve_id: e.id, jour }); });
            });

            // Une pause est un créneau comme un autre : même contrôle de conflit que la
            // saisie et le collage (demande de Jérôme, 29/09/2026).
            const conflits = this._chevauchements(aCreer);
            let aSupprimer = [];
            if (conflits.length > 0) {
                const choix = await this._askConflit(conflits.length, {
                    titre: 'Ajouter une pause',
                    question: this._questionConflit(conflits),
                });
                if (choix === 'annuler') return;   // la fenêtre reste ouverte
                if (choix === 'ignorer') {
                    const enConflit = new Set(conflits.map(c => c.cible));
                    aCreer = aCreer.filter(d => !enConflit.has(d));
                    if (aCreer.length === 0) {
                        Toast.info('Aucune pause créée : toutes les cases visées étaient occupées.');
                        return;
                    }
                }
                if (choix === 'ecraser') {
                    aSupprimer = [...new Set(conflits.flatMap(c => c.occupants.map(o => o.id)))];
                }
            }

            Modal.close();
            // Envoi par petits paquets : MySQL portable est limité en connexions
            // simultanées, un Promise.all sur tout le lot provoque « Too many connections ».
            let crees = 0, echecs = 0;
            if (aSupprimer.length > 0) {
                await Promise.allSettled(aSupprimer.map(id => API.del('creneaux.php?id=' + id)));
            }
            const LOT = 3;
            for (let i = 0; i < aCreer.length; i += LOT) {
                const lot = aCreer.slice(i, i + LOT);
                const res = await Promise.allSettled(lot.map(d => API.post('creneaux.php', d)));
                res.forEach(r => { if (r.status === 'fulfilled') crees++; else echecs++; });
            }
            if (echecs > 0) Toast.error(echecs + ' créneau(x) non créé(s) — réessayez.');
            else Toast.success('Pause ajoutée (' + crees + ' créneaux)');
            await this._markModified();
            this.render(this._semaineId);
        });
    },

    _showAdultCellDetail(adulte, heure, jour, creneaux) {
        const eleveMap = {};
        this._eleves.forEach(e => { eleveMap[e.id] = e; });
        const lignes = creneaux.map(c => {
            const e = eleveMap[c.eleve_id];
            const nom = e ? `${e.prenom} ${e.nom}` : 'Élève inconnu';
            return `<tr><td>${escapeHtml(nom)}</td><td>${escapeHtml(c.matiere || '-')}</td><td>${escapeHtml(c.groupe || '-')}</td><td><span class="badge" style="background:${this._params?.couleurs_types?.[c.regroupement_type] || '#e0e0e0'};color:#000">${escapeHtml(c.regroupement_type || '-')}</span></td></tr>`;
        }).join('');
        Modal.open({
            title: `${escapeHtml(adulte)} — ${formatHeure(heure)} (${jour})`,
            body: `<table class="data-table" style="margin-bottom:0"><thead><tr><th>Élève</th><th>Matière</th><th>Groupe</th><th>Type</th></tr></thead><tbody>${lignes}</tbody></table>`,
            footer: '<button class="btn btn-secondary" onclick="Modal.close()">Fermer</button>',
        });
    },

    _defaultParams() {
        return {
            horaires: { debut: '08:30', fin: '16:30', duree_creneau: 15 },
            couleurs_types: { ...COULEURS_TYPES_DEFAUT },
            jours_affiches: ['lundi', 'mardi', 'jeudi', 'vendredi'],
            format_semaine: 'scolaire',
        };
    },
};
