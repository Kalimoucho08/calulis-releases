/**
 * Calulis — Fiche Élève : onglet AESH & PEC
 * Attaché à FicheEleve via Object.assign
 */

Object.assign(FicheEleve, {

    _buildAeshPecTab() {
        const ro = this._readonly ? 'disabled' : '';
        return `
        <div class="tab-panel" data-tab="aeshpec" style="display:none" data-help="AESH & PEC (Prises en charge)|Cet onglet liste les accompagnants et les prises en charge extérieures de l'élève. AESH : type (individuel, mutualisé, collectif), nom de l'accompagnant, nombre d'heures par semaine, autres élèves mutualisés. PEC : spécialité (orthophoniste, psychomotricien, psychologue…), organisme (CMPP, SESSAD, libéral, hôpital de jour…), fréquence (hebdomadaire, mensuelle…), lieu. Cliquez sur + pour ajouter. et plusieurs prises en charge. AESH : type (individuel, mutualisé, collectif), nom, heures/semaine, élèves mutualisés. PEC : spécialité (orthophoniste, psychomot...), organisme (CMPP, SESSAD, libéral...), fréquence, lieu. Clique + pour ajouter une ligne.">
            <div class="form-section">
                <div class="form-section-title">AESH</div>
                <div id="fiche-aesh-list"><p class="text-muted small">Chargement...</p></div>
                ${ro ? '' : '<button class="btn btn-sm btn-secondary" id="btn-add-aesh" style="margin-top:6px">+ Ajouter un AESH</button>'}
            </div>
            <div class="form-section">
                <div class="form-section-title">PEC (Prise en charge)</div>
                <div id="fiche-pec-list"><p class="text-muted small">Chargement...</p></div>
                ${ro ? '' : '<button class="btn btn-sm btn-secondary" id="btn-add-pec" style="margin-top:6px">+ Ajouter une PEC</button>'}
            </div>
        </div>`;
    },

    /* ---- AESH (multi-lignes) ---- */

    async _loadAESH() {
        const container = document.getElementById('fiche-aesh-list');
        if (!container) return;
        try {
            const items = await API.get('aesh_eleves.php?eleve_id=' + this._eleve.id);
            this._renderAESH(items);
        } catch { this._renderAESH([]); }
    },

    _renderAESH(items) {
        const container = document.getElementById('fiche-aesh-list');
        if (!container) return;
        const ro = this._readonly ? 'disabled' : '';
        container.innerHTML = (!items || !items.length)
            ? '<p class="text-muted small">Aucun AESH.</p>'
            : items.map((a, i) => `
                <div class="sub-row" data-index="${i}">
                    <select class="aesh-type" ${ro}>
                        <option value="">Type</option>
                        <option value="AESHi" ${a.type === 'AESHi' ? 'selected' : ''}>AESHi</option>
                        <option value="AESHm" ${a.type === 'AESHm' ? 'selected' : ''}>AESHm</option>
                        <option value="AESHco" ${a.type === 'AESHco' ? 'selected' : ''}>AESHco</option>
                    </select>
                    <input type="text" class="aesh-nom" value="${escapeHtml(a.nom || '')}" placeholder="Nom" ${ro}>
                    <input type="text" class="aesh-heures" value="${escapeHtml(a.heures || '')}" placeholder="Heures/sem" style="width:100px" ${ro}>
                    <input type="text" class="aesh-mutualise" value="${escapeHtml(a.mutualise_avec || '')}" placeholder="Mutualisé avec (IDs)" ${ro}>
                    ${!ro ? '<button class="btn-sm btn-del" onclick="this.closest(\'.sub-row\').remove()">x</button>' : ''}
                </div>
            `).join('');

        if (!ro) {
            document.getElementById('btn-add-aesh').onclick = () => {
                const current = this._getAESHFromDOM();
                current.push({ type: '', nom: '', heures: '', mutualise_avec: '' });
                this._renderAESH(current);
            };
        }
    },

    _getAESHFromDOM() {
        const items = [];
        document.querySelectorAll('#fiche-aesh-list .sub-row').forEach(row => {
            items.push({
                type: row.querySelector('.aesh-type')?.value || '',
                nom: row.querySelector('.aesh-nom')?.value?.trim() || '',
                heures: row.querySelector('.aesh-heures')?.value?.trim() || '',
                mutualise_avec: row.querySelector('.aesh-mutualise')?.value?.trim() || '',
            });
        });
        return items;
    },

    /* ---- PEC (multi-lignes) ---- */

    async _loadPEC() {
        const container = document.getElementById('fiche-pec-list');
        if (!container) return;
        try {
            const items = await API.get('pec_eleves.php?eleve_id=' + this._eleve.id);
            this._renderPEC(items);
        } catch { this._renderPEC([]); }
    },

    _renderPEC(items) {
        const container = document.getElementById('fiche-pec-list');
        if (!container) return;
        const ro = this._readonly ? 'disabled' : '';
        container.innerHTML = (!items || !items.length)
            ? '<p class="text-muted small">Aucune PEC.</p>'
            : items.map((p, i) => `
                <div class="sub-row" data-index="${i}">
                    <select class="pec-specialite" ${ro}>
                        <option value="">Spécialité</option>
                        ${(()=>{const opts=['Orthophoniste','Orthophonie','Psychologue','Psychomotricien','Psychomotricité','Pédopsychiatre','Ergothérapie','Suivi éducatif','Educateur','Autre'];if(p.specialite&&!opts.some(o=>o.toLowerCase()===p.specialite.toLowerCase()))opts.push(p.specialite);return opts.map(o=>`<option value="${o}" ${(p.specialite||'').toLowerCase()===o.toLowerCase()?'selected':''}>${o}</option>`).join('');})()}
                    </select>
                    <select class="pec-organisme" ${ro}>
                        <option value="">Organisme</option>
                        ${(()=>{const opts=['CMPP','CMP','SESSAD','CAMSP','Cabinet libéral','Privé','Autre'];if(p.organisme&&!opts.some(o=>o.toLowerCase()===p.organisme.toLowerCase()))opts.push(p.organisme);return opts.map(o=>`<option value="${o}" ${(p.organisme||'').toLowerCase()===o.toLowerCase()?'selected':''}>${o}</option>`).join('');})()}
                    </select>
                    <select class="pec-frequence" ${ro}>
                        <option value="">Fréquence</option>
                        ${(()=>{const opts=['hebdomadaire','1x/sem','bimensuel','2x/sem','mensuel','1x/mois','ponctuel'];if(p.frequence&&!opts.some(o=>o.toLowerCase()===p.frequence.toLowerCase()))opts.push(p.frequence);return opts.map(o=>`<option value="${o}" ${(p.frequence||'').toLowerCase()===o.toLowerCase()?'selected':''}>${o}</option>`).join('');})()}
                    </select>
                    <select class="pec-lieu" ${ro}>
                        <option value="">Lieu</option>
                        ${(()=>{const opts=['École','Cabinet','CAMSP','SESSAD','CMPP','Domicile','Autre'];if(p.lieu&&!opts.some(o=>o.toLowerCase()===p.lieu.toLowerCase()))opts.push(p.lieu);return opts.map(o=>`<option value="${o}" ${(p.lieu||'').toLowerCase()===o.toLowerCase()?'selected':''}>${o}</option>`).join('');})()}
                    </select>
                    <input type="date" class="pec-date_debut" value="${(p.date_debut || '').substring(0,10)}" title="Début de la prise en charge" style="width:140px" ${ro}>
                    <input type="date" class="pec-date_fin" value="${(p.date_fin || '').substring(0,10)}" title="Fin (vide = encore en cours)" style="width:140px" ${ro}>
                    <label style="display:flex;align-items:center;gap:4px;white-space:nowrap" title="La prise en charge a lieu HORS de l'école : le créneau doit dire où est l'élève"><input type="checkbox" class="pec-quitte" ${p.quitte_etablissement ? 'checked' : ''} ${ro}> hors école</label>
                    <input type="text" class="pec-duree" value="${escapeHtml(p.duree || '')}" placeholder="Durée" style="width:100px" ${ro}>
                    <input type="text" class="pec-commentaires" value="${escapeHtml(p.commentaires || '')}" placeholder="Commentaires" ${ro}>
                    ${!ro ? '<button class="btn-sm btn-del" onclick="this.closest(\'.sub-row\').remove()">x</button>' : ''}
                </div>
            `).join('');

        if (!ro) {
            document.getElementById('btn-add-pec').onclick = () => {
                const current = this._getPECFromDOM();
                current.push({ specialite: '', organisme: '', frequence: '', lieu: '', duree: '', commentaires: '',
                               date_debut: '', date_fin: '', quitte_etablissement: 0 });
                this._renderPEC(current);
            };
        }
    },

    _getPECFromDOM() {
        const items = [];
        document.querySelectorAll('#fiche-pec-list .sub-row').forEach(row => {
            items.push({
                specialite: row.querySelector('.pec-specialite')?.value || '',
                organisme: row.querySelector('.pec-organisme')?.value || '',
                frequence: row.querySelector('.pec-frequence')?.value || '',
                lieu: row.querySelector('.pec-lieu')?.value || '',
                date_debut: row.querySelector('.pec-date_debut')?.value || '',
                date_fin: row.querySelector('.pec-date_fin')?.value || '',
                quitte_etablissement: row.querySelector('.pec-quitte')?.checked ? 1 : 0,
                duree: row.querySelector('.pec-duree')?.value?.trim() || '',
                commentaires: row.querySelector('.pec-commentaires')?.value?.trim() || '',
            });
        });
        return items;
    },

});
