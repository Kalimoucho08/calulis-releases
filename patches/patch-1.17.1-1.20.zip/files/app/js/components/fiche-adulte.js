/**
 * Calulis — Composant Fiche Adulte (formulaire à onglets)
 */
const FicheAdulte = {
    _adulte: null,
    _isNew: false,
    _readonly: false,
    _etablissementsList: [],
    _fonctions: [],

    async open(data = {}, readonly = false) {
        this._isNew = !data || !data.id;
        this._adulte = this._isNew ? {} : { ...data };
        this._readonly = readonly;
        this._etablissementsList = [];
        this._fonctions = [];

        // Charger les fonctions depuis l'API (paramètres)
        try {
            const raw = await API.get('params.php');
            const row = Array.isArray(raw) ? raw.find(p => p.cle === 'fonctions') : null;
            if (row && row.valeur) {
                const p = JSON.parse(row.valeur);
                if (Array.isArray(p) && p.length) this._fonctions = p;
            }
        } catch {}
        if (!this._fonctions.length) this._fonctions = ['Coordo ULIS', 'Directeur', 'Adjoint', 'RASED'];

        const label = data.prenom ? data.prenom + ' ' + data.nom : (data.nom || '');
        Modal.open({
            title: this._isNew ? 'Nouvel adulte' : (readonly ? 'Fiche : ' : 'Modifier : ') + label,
            body: this._buildHTML(),
            footer: readonly
                ? '<button class="btn btn-secondary" onclick="Modal.close()">Fermer</button>'
                : `<button class="btn btn-secondary" onclick="Modal.close()">Annuler</button>
                   <button class="btn btn-primary" id="btn-save-adulte">Enregistrer</button>`,
        });

        document.querySelectorAll('#modal .tab').forEach(tab => {
            tab.addEventListener('click', () => this._switchTab(tab.dataset.tab));
        });

        if (!readonly) {
            // Deux clics rapides ne doivent pas envoyer DEUX enregistrements (js/utils/actions.js).
            const boutonEnregistrer = document.getElementById('btn-save-adulte');
            boutonEnregistrer.addEventListener('click', () => Action.uneSeule(boutonEnregistrer, () => this._save()));
        }

        // Charger les données des onglets dynamiques
        this._loadEtablissements(data);
        this._loadInterventions(data);
        this._loadReunions(data);
    },

    _switchTab(name) {
        document.querySelectorAll('#modal .tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
        document.querySelectorAll('#modal .tab-panel').forEach(p => {
            p.style.display = p.dataset.tab === name ? '' : 'none';
        });
    },

    _buildHTML() {
        const a = this._adulte;
        const ro = this._readonly ? 'disabled' : '';
        const f = (name, val) => `<input type="text" id="fa-${name}" value="${escapeHtml(val !== undefined ? val : (a[name] || ''))}" ${maxLenAttr(name)} ${ro}>`;
        const d = (name, val) => `<input type="date" id="fa-${name}" value="${val || a[name] || ''}" ${ro}>`;
        const s = (name, options, val) => {
            const current = ((val !== undefined ? val : a[name]) || '').toString();
            const norm = x => x.toLowerCase().replace(/[\s_-]+/g, '');
            const matched = options.find(o => norm(o) === norm(current)) || '';
            const opts = options.map(o => `<option value="${o}" ${o === matched ? 'selected' : ''}>${o}</option>`).join('');
            return `<select id="fa-${name}" ${ro}><option value="">—</option>${opts}</select>`;
        };
        // Le MÉTIER est une valeur LIBRE depuis la décision 15.6 (migration 016) : un libellé
        // connu (« Enseignant », « AESH Co »…) ou une spécialité (« Orthophoniste »). Le
        // sélecteur proposait les ANCIENNES CLÉS (enseignant, aeshco…), qui ne correspondaient
        // plus à ce que la base contient : il repartait donc à vide et l'enregistrement
        // suivant ÉCRASAIT le métier (constat R2 de la revue du 27/10/2026). On propose les
        // libellés connus ET on conserve la valeur enregistrée, même hors liste.
        const metiersConnus = ['Enseignant', 'AESH Co', 'AESH Individuel', 'AESH Mutualisé',
            'Spécialiste', 'Éducateur', 'Assistant familial', 'Autre'];
        const metierActuel = ((a.metier || a.role) || '').toString();
        const metierOptions = (metierActuel && !metiersConnus.includes(metierActuel))
            ? [metierActuel, ...metiersConnus]
            : metiersConnus;
        const civOptions = ['M.','Mme','Dr.'];
        const txt = (name, val) => `<textarea id="fa-${name}" rows="2" ${ro}>${escapeHtml(val !== undefined ? val : (a[name] || ''))}</textarea>`;

        return `
        <div class="tabs">
            <button class="tab active" data-tab="identite">Identité</button>
            <button class="tab" data-tab="etablissements">Établissements</button>
            <button class="tab" data-tab="interventions">Interventions</button>
            <button class="tab" data-tab="reunions">Réunions</button>
        </div>

        <div class="tab-panel active" data-tab="identite">
            <div class="form-row">
                <div class="form-group"><label>Civilité</label>${s('civilite', civOptions)}</div>
                <div class="form-group" style="flex:0.5"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Nom *</label>${f('nom')}</div>
                <div class="form-group"><label>Prénom</label>${f('prenom')}</div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Métier</label>${s('metier', metierOptions, metierActuel)}</div>
                <div class="form-group"><label>Rôles</label>
                    <div style="display:flex;flex-wrap:wrap;gap:10px;padding-top:6px">
                        ${['Coordonnateur ULIS','Directeur','Enseignant référent',"Membre de l'ESS",'Intervenant extérieur'].map(r =>
                            `<label style="display:flex;align-items:center;gap:6px;font-weight:400"><input type="checkbox" class="fa-role" value="${r}" ${(a.roles||[]).includes(r) ? 'checked' : ''} ${ro}> ${r}</label>`).join('')}
                    </div>
                    <p class="text-muted small" style="margin:4px 0 0 0">Une personne a <strong>un</strong> métier et peut avoir <strong>plusieurs</strong> rôles. Un directeur d'école est enseignant : son métier est Enseignant, son rôle est Directeur.</p>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Téléphone</label>${f('telephone')}</div>
                <div class="form-group"><label>Email</label>${f('email')}</div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Date d'arrivée</label><input type="date" id="fa-date_arrivee" value="${escapeHtml((a.date_arrivee || '').substring(0,10))}" ${ro}></div>
                <div class="form-group"><label>Date de départ</label><input type="date" id="fa-date_depart" value="${escapeHtml((a.date_depart || '').substring(0,10))}" ${ro}></div>
            </div>
            <p class="text-muted small" style="margin:0 0 8px 0">Un adulte a des <strong>dates</strong> : elles disent qui était là quand, et gardent son histoire après son départ. Une date de départ ne supprime rien.</p>
            <div class="form-group"><label>Établissement de rattachement</label>
                <select id="fa-etablissement_id" ${ro} style="width:100%">
                    <option value="">— Aucun (intervenant externe) —</option>
                </select>
                <p class="text-muted small" style="margin-top:4px">À remplir pour les enseignants et AESH de l'établissement. Laisser vide pour les intervenants extérieurs.</p>
            </div>
            <div class="form-group"><label>Commentaires</label>${txt('commentaires')}</div>
            ${!this._isNew ? `<div class="form-row" style="margin-top:12px">
                <div class="form-group"><label style="display:flex;align-items:center;gap:8px">
                    <input type="checkbox" id="fa-actif" ${a.actif === 1 ? 'checked' : ''} ${ro}> Actif
                </label></div>
            </div>` : ''}
        </div>

        <div class="tab-panel" data-tab="etablissements" style="display:none">
            <p class="text-muted small" style="margin-bottom:12px">Établissements et structures où intervient cet adulte (écoles, CMPP, cabinets, associations...).</p>
            <div id="fa-etablissements-list"></div>
            ${!ro ? '<div style="margin-top:8px;display:flex;gap:6px"><button class="btn btn-sm btn-secondary" id="btn-fa-add-etab">+ Ajouter une structure</button><button class="btn btn-sm btn-secondary" id="btn-fa-refresh-etabs" title="Rafraîchir la liste">⟳</button></div>' : ''}
        </div>

        <div class="tab-panel" data-tab="interventions" style="display:none">
            <p class="text-muted small" style="margin-bottom:8px">Créneaux d'intervention dans l'emploi du temps.</p>
            <div id="fa-interventions-content"><p class="text-muted">Chargement...</p></div>
        </div>

        <div class="tab-panel" data-tab="reunions" style="display:none">
            <p class="text-muted small" style="margin-bottom:8px">Réunions où cet adulte est participant.</p>
            <div id="fa-reunions-content"><p class="text-muted">Chargement...</p></div>
        </div>`;
    },

    _renderEtablissements(liens) {
        const container = document.getElementById('fa-etablissements-list');
        const ro = this._readonly ? 'disabled' : '';
        const items = liens || [];
        const etabs = this._etablissementsList;

        container.innerHTML = items.length === 0
            ? '<p class="text-muted small">Aucun établissement.</p>'
            : items.map((item, i) => {
                const etabId = item.etablissement_id || '';
                const role = item.role || '';
                return `<div class="form-row etablissement-row" style="margin-bottom:6px;align-items:center">
                    <select class="etab-select" ${ro} style="flex:2">
                        <option value="">— Sélectionner —</option>
                        ${etabs.filter(e => e.actif !== 0).map(e =>
                            `<option value="${e.id}" ${e.id === etabId ? 'selected' : ''}>${escapeHtml(e.nom)}${e.ville ? ' (' + escapeHtml(e.ville) + ')' : ''}</option>`
                        ).join('')}
                    </select>
                    <select class="etab-role" ${ro} style="flex:1;margin-left:6px">
                        ${['enseignant_referent','psychologue','orthophoniste','educateur','aesh','specialiste','autre'].map(r =>
                            `<option value="${r}" ${role === r ? 'selected' : ''}>${r.replace(/_/g, ' ')}</option>`
                        ).join('')}
                    </select>
                    ${!ro ? `<button class="btn-sm btn-del" onclick="this.closest('.etablissement-row').remove()">×</button>` : ''}
                </div>`;
            }).join('');

        if (!ro) {
            const addBtn = document.getElementById('btn-fa-add-etab');
            if (addBtn) {
                addBtn.onclick = null;
                addBtn.addEventListener('click', () => {
                    const current = this._getEtablissementsFromDOM();
                    current.push({ etablissement_id: '', role: 'enseignant_referent' });
                    this._renderEtablissements(current);
                });
            }
            document.getElementById('btn-fa-refresh-etabs')?.addEventListener('click', async () => {
                await this._loadEtablissementsList();
                const current = this._getEtablissementsFromDOM();
                this._renderEtablissements(current);
            });
        }
    },

    async _loadEtablissements(data) {
        await this._loadEtablissementsList();

        // Remplir le select de rattachement
        const select = document.getElementById('fa-etablissement_id');
        if (select) {
            const currentId = data && data.etablissement_id;
            select.innerHTML = '<option value="">— Aucun (intervenant externe) —</option>' +
                this._etablissementsList.filter(e => e.actif !== 0).map(e =>
                    `<option value="${e.id}" ${e.id === currentId ? 'selected' : ''}>${escapeHtml(e.nom)}${e.ville ? ' (' + escapeHtml(e.ville) + ')' : ''}</option>`
                ).join('');
        }

        // Remplir l'onglet etablissements
        const liens = (data && data.liens_etablissements) || [];
        this._renderEtablissements(liens);
    },

    async _loadEtablissementsList() {
        try {
            this._etablissementsList = await API.get('etablissements.php');
        } catch {
            this._etablissementsList = [];
        }
    },

    async _loadInterventions(data) {
        const container = document.getElementById('fa-interventions-content');
        if (!container) return;
        try {
            const creneaux = await API.get('creneaux.php?adulte=' + encodeURIComponent(data.nom || ''));
            if (!creneaux.length) {
                container.innerHTML = '<p class="text-muted small">Aucun créneau trouvé.</p>';
                return;
            }
            // Grouper par jour
            const parJour = {};
            creneaux.forEach(c => {
                const j = c.jour || '?';
                if (!parJour[j]) parJour[j] = [];
                parJour[j].push(c);
            });
            const jours = ['lundi','mardi','mercredi','jeudi','vendredi','samedi'];
            container.innerHTML = `
                <table class="data-table" style="font-size:13px">
                    <thead><tr><th>Jour</th><th>Heure</th><th>Élève</th><th>Matière</th><th>Type</th></tr></thead>
                    <tbody>
                        ${jours.filter(j => parJour[j]).map(j =>
                            parJour[j].sort((a,b) => (a.heure_debut||'').localeCompare(b.heure_debut||'')).map(c => `
                                <tr>
                                    <td>${j.charAt(0).toUpperCase()+j.slice(1,3)}</td>
                                    <td>${c.heure_debut || ''}</td>
                                    <td>${c.eleve_prenom || ''} ${c.eleve_nom || ''}</td>
                                    <td>${c.matiere || ''}</td>
                                    <td>${c.regroupement_type || ''}</td>
                                </tr>
                            `).join('')
                        ).join('')}
                    </tbody>
                </table>`;
        } catch {
            container.innerHTML = '<p class="text-muted small">Impossible de charger les créneaux.</p>';
        }
    },

    async _loadReunions(data) {
        const container = document.getElementById('fa-reunions-content');
        if (!container) return;
        try {
            const nom = data.prenom ? data.prenom + ' ' + data.nom : data.nom;
            const reunions = await API.get('reunions.php?adulte=' + encodeURIComponent(nom || ''));
            if (!reunions || !reunions.length) {
                container.innerHTML = '<p class="text-muted small">Aucune réunion trouvée.</p>';
                return;
            }
            container.innerHTML = reunions.map(r => `
                <div class="reunion-mini" style="padding:4px 0;border-bottom:1px solid var(--border);font-size:13px">
                    <span style="font-weight:600">${formatDate(r.date_reunion)}</span>
                    <span class="badge reunion-statut-${r.statut || 'prevue'}">${r.statut || 'prévue'}</span>
                    <strong>${escapeHtml(r.titre)}</strong>
                    ${r.eleve_nom ? ` — ${escapeHtml(r.eleve_prenom)} ${escapeHtml(r.eleve_nom)}` : ''}
                </div>
            `).join('');
        } catch {
            container.innerHTML = '<p class="text-muted small">Impossible de charger les réunions.</p>';
        }
    },

    _getEtablissementsFromDOM() {
        const items = [];
        document.querySelectorAll('.etablissement-row').forEach(row => {
            const select = row.querySelector('.etab-select');
            const etabId = select ? parseInt(select.value) : 0;
            if (etabId > 0) {
                items.push({
                    etablissement_id: etabId,
                    role: row.querySelector('.etab-role')?.value || 'enseignant_referent',
                });
            }
        });
        return items;
    },

    async _save() {
        const data = this._collect();
        if (!data.nom) {
            Modal.alert('Erreur', 'Le nom est requis.');
            return;
        }
        try {
            if (this._isNew) {
                await API.post('adultes.php', data);
            } else {
                await API.put('adultes.php?id=' + this._adulte.id, data);
            }
            Modal.close();
            State.emit('adultes:changed');
            Toast.success(this._isNew ? 'Adulte créé' : 'Adulte modifié');
        } catch (e) {
            Modal.alert('Erreur', e.message);
        }
    },

    _getFonctions() {
        return this._fonctions;
    },

    _collect() {
        const data = {};
        ['nom','prenom','civilite','role','fonction','telephone','email','commentaires','date_arrivee','date_depart'].forEach(f => {
            const el = document.getElementById('fa-' + f);
            if (el) data[f] = el.value;
        });
        data.metier = document.getElementById('fa-metier')?.value || '';
        data.roles = Array.from(document.querySelectorAll('.fa-role:checked')).map(c => c.value);
        // Les colonnes historiques role/fonction ne sont plus saisies ici, mais on ne les
        // efface pas : d'autres écrans les lisent encore. Elles partiront quand plus rien
        // ne les lira (décision 15.6).
        if (this._adulte) {
            data.role = this._adulte.role || '';
            data.fonction = this._adulte.fonction || '';
        }
        data.actif = document.getElementById('fa-actif')?.checked ? 1 : 0;
        const etabId = document.getElementById('fa-etablissement_id')?.value;
        data.etablissement_id = etabId ? parseInt(etabId) : null;
        data.liens_etablissements = this._getEtablissementsFromDOM();
        return data;
    },
};
