/**
 * Calulis — Impression
 *
 * Écran unique : la liste des documents à gauche (avec le résumé de leurs réglages), les
 * réglages du document sélectionné, et l'aperçu A4 à droite (la fenêtre d'aperçu globale,
 * amarrée à droite par la classe `impression-ouverte`).
 *
 * Règles : docs/impression-specification-2026-10-18.md.
 * Le moteur de page vit dans print-socle.js — ici, on ne décide que de l'écran et des réglages.
 */
// Le moteur pdf.js est livré DANS le paquet (app/vendor) : jamais depuis Internet.
// La version du worker DOIT être identique à celle de pdf.min.js (vérifié : 3.11.174).
pdfjsLib.GlobalWorkerOptions.workerSrc = 'vendor/pdf.worker.min.js';

/** Police minimum pour la lisibilité des tableaux pdfmake */
const MIN_PDF_FONT = 6.5;

/** Styles pdfmake de base partagés par tous les exports */
const BASE_STYLES = {
    header:      { fontSize: 13, bold: true, alignment: 'center', margin: [0, 0, 0, 4] },
    subheader:   { fontSize: 9, alignment: 'center', margin: [0, 0, 0, 8], color: '#666' },
    tableHeader: { fontSize: 7, bold: true, fillColor: '#eee', alignment: 'center' },
    hourCell:    { fontSize: 6.5, bold: true, alignment: 'center', fillColor: '#fafafa' },
    slotCell:    { fontSize: MIN_PDF_FONT, alignment: 'center', margin: [1, 1] },
    midiPause:   { fontSize: 7, bold: true, alignment: 'center', margin: [1, 2] },
    legendTitle: { fontSize: 8, bold: true },
    sectionTitle: { fontSize: 11, bold: true, margin: [0, 6, 0, 4], color: '#2c3e50' },
};

const Print = {
    _eleves: [],
    _adultes: [],
    _semaines: [],
    _classes: [],
    _etablissements: [],
    _params: null,
    _loading: false,
    _pendingDef: null,
    _pendingFilename: null,
    /** Numéro de la dernière génération demandée : une réponse plus ancienne est ignorée. */
    _demande: 0,
    /** Sélections mémorisées par document (blocs, élèves, adultes). */
    _memoireChamps: {},
    _sauvegardeEnEchec: false,
    /** Message « N pages » à afficher sous l'aperçu (spec § 2.4, étape 5). */
    _avertissementApercu: null,
    /** L'utilisateur a demandé l'aperçu (fenêtre flottante sous 1100 px). */
    _apercuOuvert: false,
    /** L'utilisateur a fermé l'aperçu : ne pas le rouvrir tout seul au changement suivant. */
    _apercuFerme: false,
    _pdfDoc: null,
    _currentPage: 1,
    _zoom: 1,
    _zoomStep: 0.25,

    /** Document sélectionné dans la liste (clé de réglages, voir print-socle.js). */
    _docSel: 'edt_semaine_eleve',
    _semaineChoisie: null,
    _sauvegardeTimer: null,
    _apercuTimer: null,

    /** Les 7 documents de la page Impression (les 3 autres s'impriment depuis leur page). */
    _DOCUMENTS: [
        { cle: 'edt_semaine_eleve',  groupe: 'Emplois du temps', icone: '👤', label: 'Semaine · Élève',  desc: 'la grille complète d\'un élève' },
        { cle: 'edt_semaine_adulte', groupe: 'Emplois du temps', icone: '👩‍🏫', label: 'Semaine · Adulte', desc: 'la grille d\'un adulte, élèves dans les cases' },
        { cle: 'edt_jour_eleves',    groupe: 'Emplois du temps', icone: '👥', label: 'Jour · Élève(s)',  desc: 'une journée, plusieurs élèves côte à côte' },
        { cle: 'edt_jour_adultes',   groupe: 'Emplois du temps', icone: '🔄', label: 'Jour · Adulte(s)', desc: 'une journée, plusieurs adultes côte à côte' },
        { cle: 'statistiques',       groupe: 'Statistiques',     icone: '📊', label: 'Statistiques',      desc: 'les blocs cochés, enchaînés ou un par page' },
        { cle: 'fiche_urgence',      groupe: 'Fiches',           icone: '🚑', label: 'Fiche d\'urgence',  desc: 'médical, représentants, transport' },
        { cle: 'fiche_renseignements', groupe: 'Fiches',         icone: '📝', label: 'Fiche de renseignements', desc: 'identité, scolarité, contacts' },
    ],

    async render() {
        const vueDemandee = location.hash;
        const view = document.getElementById('view-print');
        view.innerHTML = '<div class="placeholder-view"><div class="placeholder-icon">⏳</div><div class="placeholder-title">Chargement…</div></div>';
        await this._loadData();
        // On a pu quitter l'écran pendant le chargement : ne pas rouvrir l'aperçu ailleurs.
        if (location.hash !== vueDemandee || !this._surImpression()) return;
        view.innerHTML = this._buildHTML();
        this._pendingDef = null;
        this._pendingFilename = null;
        this._demande = (this._demande || 0) + 1;
        this._afficherDocument();
        this._bindEvents();
        this._majBoutonsApercu();
        // L'écran partagé n'a de sens qu'avec la place de deux colonnes. En dessous de
        // 1100 px, l'aperçu resterait une fenêtre flottante, ouverte par « Aperçu ».
        if (window.innerWidth > 1100) this._ouvrirApercuAmarre();
        this._genererAuto();
    },

    /** Amarre la fenêtre d'aperçu globale à droite de la page Impression. */
    _ouvrirApercuAmarre() {
        if (!this._surImpression()) return;
        this._apercuOuvert = true;
        this._apercuFerme = false;   // le bouton « Aperçu » rouvre ce que l'utilisateur a fermé
        const voile = document.getElementById('apercu-voile');
        if (!voile) return;
        this._brancherApercu();
        voile.classList.remove('cache');
        // Sous 1100 px, on ne peut pas tenir réglages + aperçu côte à côte : la fenêtre
        // reste FLOTTANTE (bouton Fermer visible) au lieu de recouvrir les réglages.
        document.body.classList.toggle('impression-ouverte', window.innerWidth > 1100);
        // Un PDF déjà généré alors que la fenêtre était fermée a été ajusté sur une largeur
        // nulle (zoom 25 %) : le réajuster une fois la fenêtre réellement affichée.
        if (this._pdfDoc) setTimeout(() => this._zoomFit(), 30);
    },

    async _loadData() {
        this._loading = true;
        try {
            // Données indispensables : si l'une échoue, la page d'impression ne peut pas fonctionner.
            const [eleves, adultes, semaines, paramsRaw] = await Promise.all([
                API.get('eleves.php'),
                API.get('adultes.php'),
                API.get('semaines.php'),
                API.get('params.php'),
            ]);
            this._eleves = (eleves || []).filter(e => e.actif);
            this._adultes = adultes || [];
            this._semaines = semaines || [];
            // classes.php est optionnelle (utilisée seulement pour associer les classes aux adultes en vue semaine).
            // Un échec ici ne doit jamais vider la liste des élèves (bug « jour / élèves » sans élèves).
            this._classes = [];
            try { this._classes = (await API.get('classes.php')) || []; }
            catch (e) { console.warn('[Print] classes.php indisponible :', e); }
            const params = {};
            (paramsRaw || []).forEach(p => {
                try { params[p.cle] = JSON.parse(p.valeur); } catch { params[p.cle] = p.valeur; }
            });
            this._params = params;

            // Établissement principal et année scolaire : facultatifs, servent aux bandeaux.
            // Un échec ici ne doit jamais empêcher d'imprimer.
            this._notreEtablissementId = params.notre_etablissement_id || null;
            this._etablissements = [];
            try { this._etablissements = (await API.get('etablissements.php')) || []; }
            catch (e) { console.warn('[Print] etablissements.php indisponible :', e); }
            this._anneeLibelle = '';
            try {
                const annee = typeof State !== 'undefined' && State.get('annee_active');
                this._anneeLibelle = (annee && annee.libelle) || '';
            } catch (e) { /* année inconnue : le bandeau l'omettra */ }
        } catch (e) {
            console.error('[Print] load error:', e);
            if (typeof Modal !== 'undefined' && Modal.alert) {
                Modal.alert('Erreur de chargement', 'Impossible de charger les données. Vérifiez votre connexion au serveur.');
            }
        }
        this._loading = false;
    },

    _buildHTML() {
        return `
        <div class="print-entete">
            <h2 style="margin:0">🖨️ Impression</h2>
            <span class="text-muted small">L'aperçu est la feuille qui sortira — il se met à jour à chaque changement.</span>
        </div>
        <div class="print-split">
            <div class="print-reglages">
                <div class="print-actions">
                    <button class="btn btn-primary" id="btn-print-imprimer" disabled>🖨️ Imprimer</button>
                    <button class="btn btn-secondary" id="btn-print-telecharger" disabled>⬇️ Télécharger</button>
                    <button class="btn btn-sm btn-secondary" id="btn-print-apercu" title="Afficher l'aperçu">👁️ Aperçu</button>
                    <button class="btn btn-sm btn-secondary" id="btn-print-generate" title="Régénérer l'aperçu">↻ Actualiser</button>
                </div>
                <div id="print-doc-liste">${this._listeDocuments()}</div>
                <div class="card print-doc-panneau">
                    <h3 id="print-doc-titre" style="margin:0 0 4px 0"></h3>
                    <p id="print-doc-desc" class="text-muted small" style="margin:0 0 10px 0"></p>
                    <div id="print-doc-contenu"></div>
                    <h4 id="print-mep-titre" style="margin:14px 0 6px 0">Mise en page</h4>
                    <div id="print-mep-champs">${this._champsMiseEnPage()}</div>
                </div>
            </div>
            <div class="print-apercu-vide" aria-hidden="true"></div>
        </div>`;
    },

    _listeDocuments() {
        const groupes = [];
        this._DOCUMENTS.forEach(d => {
            if (!groupes[d.groupe]) groupes[d.groupe] = [];
            groupes[d.groupe].push(d);
        });
        return Object.entries(groupes).map(([groupe, docs]) => `
            <div class="print-doc-groupe">${escapeHtml(groupe)}</div>
            ${docs.map(d => `
                <button type="button" class="print-doc-item${d.cle === this._docSel ? ' active' : ''}" data-doc="${d.cle}">
                    <span class="print-doc-icone">${d.icone}</span>
                    <span class="print-doc-texte">
                        <span class="print-doc-label">${escapeHtml(d.label)}</span>
                        <span class="print-doc-resume">${escapeHtml(this._resumeDocument(d.cle))}</span>
                    </span>
                </button>`).join('')}
        `).join('');
    },

    /** Résumé d'un document dans la liste : ce qui est réglé, sans entrer dedans. */
    _resumeDocument(cle) {
        const r = this._reglagesImpression(cle);
        const orientation = (r.orientation || (cle.startsWith('edt_jour') ? 'landscape' : 'portrait')) === 'landscape' ? 'paysage' : 'portrait';
        if (cle === 'fiche_urgence' || cle === 'fiche_renseignements') {
            return `A4 ${orientation} · une fiche par page`;
        }
        if (cle === 'statistiques') {
            const pagination = r.blocsParPage === 'un' ? 'un bloc par page' : 'blocs enchaînés';
            return `${pagination} · orientation par bloc`;
        }
        const cote = r.bas.actif ? 'pied' : (r.haut.actif ? 'en-tête' : 'sans bandeau');
        return `A4 ${orientation} · ${cote}`;
    },

    /* ---- Champs de contenu, par document ---- */

    _semaineOptions() {
        const semaines = this._semaines.filter(s => !s.est_vacances);
        const today = new Date();
        const courante = semaines.find(s => s.date_debut <= today.toISOString().slice(0, 10) && s.date_fin >= today.toISOString().slice(0, 10));
        const choisie = this._semaineChoisie ?? (courante ? String(courante.id) : 'template');
        return `
            <option value="template"${choisie === 'template' ? ' selected' : ''}>Semaine type (modèle)</option>
            ${courante ? `<option value="${courante.id}"${choisie === String(courante.id) ? ' selected' : ''}>Semaine courante (S${getSchoolWeekNumber(courante, this._semaines) || ''})</option>` : ''}
            ${semaines.filter(s => s.id !== courante?.id).map(s => `<option value="${s.id}"${choisie === String(s.id) ? ' selected' : ''}>Semaine S${getSchoolWeekNumber(s, this._semaines)}${s.est_modifiee ? ' ⚡' : ''}</option>`).join('')}`;
    },

    _champsSemaine() {
        return `<div class="form-group">
            <label for="print-semaine">Semaine</label>
            <input type="text" id="print-semaine-search" class="filter-input" placeholder="Rechercher une semaine…" aria-label="Rechercher une semaine" style="width:100%;margin-bottom:4px">
            <select id="print-semaine" style="width:100%">${this._semaineOptions()}</select>
        </div>`;
    },

    _champsContenu(cle) {
        const elevesOpts = this._eleves.map(e => `<option value="${e.id}">${escapeHtml(e.prenom || '')} ${escapeHtml(e.nom || '')}${e.classe ? ' (' + escapeHtml(e.classe) + ')' : ''}</option>`).join('');
        const multiEleves = this._eleves.map(e => `<option value="${e.id}" selected>${escapeHtml(e.prenom || '')} ${escapeHtml(e.nom || '')}</option>`).join('');

        if (cle === 'edt_semaine_eleve') {
            return `<div class="form-group"><label for="print-eleve">Élève</label><select id="print-eleve" style="width:100%">${elevesOpts}</select></div>${this._champsSemaine()}`;
        }
        if (cle === 'edt_semaine_adulte') {
            return `<div class="form-group"><label for="print-adulte">Adulte</label><select id="print-adulte" style="width:100%">${this._buildAdultOptions()}</select></div>${this._champsSemaine()}`;
        }
        if (cle === 'edt_jour_eleves') {
            return '<div class="form-group"><label for="print-jours-eleves">Jour(s)</label>'
                + '<div style="display:flex;gap:4px;margin-bottom:4px">'
                + '<button type="button" class="btn btn-sm btn-secondary" data-select="print-jours-eleves" data-action="all">Tout</button>'
                + '<button type="button" class="btn btn-sm btn-secondary" data-select="print-jours-eleves" data-action="none">Aucun</button>'
                + '</div>'
                + '<select id="print-jours-eleves" style="width:100%" multiple size="5">' + this._joursMultiOptions() + '</select>'
                + '<div class="text-muted small" style="margin-top:4px">Un jour sélectionné = une page. Plusieurs jours = un seul document, une page par jour.</div>'
                + '</div>'
                + '<div class="form-group"><label for="print-multi-eleves">Élèves</label>'
                + '<div style="display:flex;gap:4px;margin-bottom:4px">'
                + '<button type="button" class="btn btn-sm btn-secondary" data-select="print-multi-eleves" data-action="all">Tout</button>'
                + '<button type="button" class="btn btn-sm btn-secondary" data-select="print-multi-eleves" data-action="none">Aucun</button>'
                + '</div>'
                + '<select id="print-multi-eleves" style="width:100%" multiple size="6">' + multiEleves + '</select>'
                + '</div>' + this._champsSemaine();
        }
        if (cle === 'edt_jour_adultes') {
            return '<div class="form-group"><label for="print-jours-adultes">Jour(s)</label>'
                + '<div style="display:flex;gap:4px;margin-bottom:4px">'
                + '<button type="button" class="btn btn-sm btn-secondary" data-select="print-jours-adultes" data-action="all">Tout</button>'
                + '<button type="button" class="btn btn-sm btn-secondary" data-select="print-jours-adultes" data-action="none">Aucun</button>'
                + '</div>'
                + '<select id="print-jours-adultes" style="width:100%" multiple size="5">' + this._joursMultiOptions() + '</select>'
                + '<div class="text-muted small" style="margin-top:4px">Un jour sélectionné = une page. Plusieurs jours = un seul document, une page par jour.</div>'
                + '</div>'
                + '<div class="form-group"><label for="print-multi-adultes">Adultes</label>'
                + '<div style="display:flex;gap:4px;margin-bottom:4px">'
                + '<button type="button" class="btn btn-sm btn-secondary" data-select="print-multi-adultes" data-action="all">Tout</button>'
                + '<button type="button" class="btn btn-sm btn-secondary" data-select="print-multi-adultes" data-action="none">Aucun</button>'
                + '</div>'
                + '<select id="print-multi-adultes" style="width:100%" multiple size="6">' + this._buildAdultMultiOptions() + '</select>'
                + '</div>' + this._champsSemaine();
        }
        if (cle === 'statistiques') {
            const blocs = this._statsBlocs().map(b => `
                <label class="export-card${b.defaut ? ' active' : ''}">
                    <input type="checkbox" name="print-stats-bloc" value="${b.id}" class="export-card-radio"${b.defaut ? ' checked' : ''}>
                    <span class="export-card-icon">${b.icone}</span>
                    <span class="export-card-label">${escapeHtml(b.label)}</span>
                    <span class="export-card-desc">${escapeHtml(b.desc)}</span>
                </label>`).join('');
            const pagination = this._reglagesImpression('statistiques').blocsParPage === 'un' ? 'un' : 'enchaines';
            return `<p class="text-muted small" style="margin:0 0 6px 0">Cochez les blocs à imprimer. Chaque bloc large ouvre sa propre page en paysage ; les blocs étroits peuvent s'enchaîner.</p>
                <div class="form-group">
                    <label>Pagination des blocs</label>
                    <label class="regl-case"><input type="radio" name="print-stats-pagination" value="enchaines"${pagination === 'enchaines' ? ' checked' : ''}> Enchaîner les blocs (2 à 3 par page)</label>
                    <label class="regl-case"><input type="radio" name="print-stats-pagination" value="un"${pagination === 'un' ? ' checked' : ''}> Un bloc par page</label>
                </div>
                <div style="display:flex;gap:4px;margin-bottom:8px">
                    <button type="button" class="btn btn-sm btn-secondary" data-stats-select="all">Tout</button>
                    <button type="button" class="btn btn-sm btn-secondary" data-stats-select="none">Aucun</button>
                </div>
                <div class="export-cards">${blocs}</div>`;
        }
        if (cle === 'fiche_urgence' || cle === 'fiche_renseignements') {
            return `<div class="form-group"><label for="print-fiche-eleves">Élève(s)</label>
                    <div style="display:flex;gap:4px;margin-bottom:4px">
                        <button type="button" class="btn btn-sm btn-secondary" data-select="print-fiche-eleves" data-action="all">Tout</button>
                        <button type="button" class="btn btn-sm btn-secondary" data-select="print-fiche-eleves" data-action="none">Aucun</button>
                    </div>
                    <select id="print-fiche-eleves" style="width:100%" multiple size="8">${multiEleves}</select>
                </div>
                <p class="text-muted small">🔒 Document confidentiel : données de vie scolaire uniquement (pas de diagnostic).</p>`;
        }
        return '';
    },

    /** Tous les jours affichés, TOUS cochés : l'affiche de la semaine est le cas courant. */
    _joursMultiOptions() {
        const jours = this._params?.jours_affiches || ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
        return jours.map(j => '<option value="' + j + '" selected>' + j.charAt(0).toUpperCase() + j.slice(1) + '</option>').join('');
    },

    /** Les champs de mise en page, communs à tous les documents (réglés séparément pour chacun). */
    _champsMiseEnPage() {
        const elements = [
            ['etablissement', 'Établissement'], ['annee', 'Année'], ['nom', 'Nom'],
            ['semaine', 'Semaine'], ['classe', 'Classe'], ['titre', 'Titre'],
            ['date', 'Date d\'impression'], ['page', 'Numéro de page'],
        ];
        const cases = (cote) => elements.map(([cle, label]) => `
            <label class="regl-case"><input type="checkbox" data-cote="${cote}" value="${cle}"> ${label}</label>`).join('');
        return `
            <div class="regl-bandeau">
                <label class="regl-titre"><input type="checkbox" id="regl-haut-actif"> Bandeau en haut</label>
                <div class="regl-corps" id="regl-haut-corps">
                    <div class="regl-cases">${cases('haut')}</div>
                    <input type="text" id="regl-haut-texte" class="filter-input" placeholder="Texte libre (facultatif)" aria-label="Texte libre du bandeau en haut" style="width:100%">
                </div>
            </div>
            <div class="regl-bandeau">
                <label class="regl-titre"><input type="checkbox" id="regl-bas-actif"> Bandeau en bas</label>
                <div class="regl-corps" id="regl-bas-corps">
                    <div class="regl-cases">${cases('bas')}</div>
                    <input type="text" id="regl-bas-texte" class="filter-input" placeholder="Texte libre (facultatif)" aria-label="Texte libre du bandeau en bas" style="width:100%">
                </div>
            </div>
            <div class="form-row" style="margin-top:8px">
                <div class="form-group"><label for="regl-marges">Marges (mm)</label>
                    <input type="number" id="regl-marges" min="5" max="25" step="1" style="width:90px"></div>
                <div class="form-group" id="regl-orientation-groupe"><label for="regl-orientation">Orientation</label>
                    <select id="regl-orientation"><option value="portrait">Portrait</option><option value="landscape">Paysage</option></select></div>
            </div>
            <label class="regl-case" id="regl-tenir-label" style="margin-top:4px"><input type="checkbox" id="regl-tenir"> Tout faire tenir sur une page</label>`;
    },

    /* ---- Affichage du document sélectionné ---- */

    _afficherDocument(cle) {
        const doc = this._DOCUMENTS.find(d => d.cle === (cle || this._docSel)) || this._DOCUMENTS[0];
        // Mémoriser les cases et sélections du document qu'on quitte : revenir sur
        // « Statistiques » ne doit pas recocher les 8 blocs par défaut (constat 18/10/2026).
        // Appelé AVANT de changer `_docSel` : sinon les champs de l'ancien document étaient
        // rangés sous la clé du nouveau (trouvé par la revue du 18/10/2026).
        this._memoriserChamps();
        this._docSel = doc.cle;
        document.querySelectorAll('.print-doc-item').forEach(b => b.classList.toggle('active', b.dataset.doc === doc.cle));
        document.getElementById('print-doc-titre').textContent = doc.label;
        document.getElementById('print-doc-desc').textContent = doc.desc;
        document.getElementById('print-doc-contenu').innerHTML = this._champsContenu(doc.cle);
        // Depuis la phase 3, TOUTES les sorties de cet écran passent par le socle : les bandeaux,
        // les marges et l'orientation ont donc un effet partout. Seules les cases sans objet sont
        // masquées : l'orientation des statistiques vient de leurs blocs, une fiche est toujours
        // en portrait, et une fiche occupe sa page (pas de « tenir sur une page »).
        document.getElementById('print-mep-titre').style.display = '';
        document.getElementById('print-mep-champs').style.display = '';
        const sansOrientation = doc.cle === 'statistiques' || doc.cle.startsWith('fiche_');
        const sansTenir = doc.cle === 'statistiques' || doc.cle.startsWith('fiche_');
        document.getElementById('regl-orientation-groupe').style.display = sansOrientation ? 'none' : '';
        document.getElementById('regl-tenir-label').style.display = sansTenir ? 'none' : '';
        this._masquerElementsBandeau(doc.cle);
        this._remplirMiseEnPage();
        this._bindContenu();
        this._restaurerChamps(doc.cle);
    },

    /**
     * Éléments de bandeau qui ont réellement une valeur pour ce document.
     * `classe` n'est fourni par AUCUN builder : le proposer partout était un réglage sans
     * effet (constat de revue du 18/10/2026). `nom` n'a de sens que pour une personne.
     */
    _elementsBandeau(cle) {
        const base = ['etablissement', 'annee', 'titre', 'date', 'page'];
        if (cle === 'edt_semaine_eleve') return ['nom', 'semaine', 'classe', ...base];
        if (cle === 'edt_semaine_adulte') return ['nom', 'semaine', ...base];
        if (cle.startsWith('edt_jour')) return ['jour', 'semaine', ...base];
        return base;   // statistiques et fiches : ni nom ni semaine
    },

    _masquerElementsBandeau(cle) {
        const permis = this._elementsBandeau(cle);
        document.querySelectorAll('input[data-cote]').forEach(c => {
            const label = c.closest('label');
            if (label) label.style.display = permis.includes(c.value) ? '' : 'none';
        });
    },

    /** Sélections courantes (blocs, élèves, adultes), par document. */
    _memoriserChamps() {
        const memo = {};
        ['print-jours-eleves', 'print-jours-adultes', 'print-multi-eleves', 'print-multi-adultes', 'print-fiche-eleves'].forEach(id => {
            const el = document.getElementById(id);
            if (el) memo[id] = [...el.selectedOptions].map(o => o.value);
        });
        const blocs = [...document.querySelectorAll('input[name="print-stats-bloc"]')];
        if (blocs.length) memo.blocs = blocs.filter(c => c.checked).map(c => c.value);
        this._memoireChamps[this._docSel] = memo;
    },

    _restaurerChamps(cle) {
        const memo = this._memoireChamps[cle];
        if (!memo) return;
        Object.entries(memo).forEach(([id, valeurs]) => {
            if (id === 'blocs') {
                const set = new Set(valeurs);
                document.querySelectorAll('input[name="print-stats-bloc"]').forEach(c => {
                    c.checked = set.has(c.value);
                    c.closest('.export-card')?.classList.toggle('active', c.checked);
                });
                return;
            }
            const el = document.getElementById(id);
            if (!el) return;
            const set = new Set(valeurs);
            [...el.options].forEach(o => { o.selected = set.has(o.value); });
        });
    },

    /** Recopie les réglages du document dans les champs de mise en page. */
    _remplirMiseEnPage() {
        const r = this._reglagesImpression(this._docSel);
        const permis = this._elementsBandeau(this._docSel);
        const poser = (cote) => {
            const conf = r[cote] || { actif: false, elements: [], texte: '' };
            document.getElementById(`regl-${cote}-actif`).checked = !!conf.actif;
            const corps = document.getElementById(`regl-${cote}-corps`);
            corps.style.display = conf.actif ? '' : 'none';
            document.querySelectorAll(`input[data-cote="${cote}"]`).forEach(c => {
                c.checked = permis.includes(c.value) && (conf.elements || []).includes(c.value);
            });
            document.getElementById(`regl-${cote}-texte`).value = conf.texte || '';
        };
        poser('haut');
        poser('bas');
        document.getElementById('regl-marges').value = r.marges || 10;
        const defautOrientation = this._docSel.startsWith('edt_jour') ? 'landscape' : 'portrait';
        document.getElementById('regl-orientation').value = r.orientation || defautOrientation;
        document.getElementById('regl-tenir').checked = r.tenirSurUnePage !== false;
    },

    /** Lit les champs de mise en page et les enregistre pour le document courant. */
    _lireMiseEnPage() {
        const permis = this._elementsBandeau(this._docSel);
        const lireCote = (cote) => ({
            actif: document.getElementById(`regl-${cote}-actif`).checked,
            elements: [...document.querySelectorAll(`input[data-cote="${cote}"]:checked`)]
                .map(c => c.value).filter(v => permis.includes(v)),
            texte: document.getElementById(`regl-${cote}-texte`).value.trim(),
        });
        const margeLue = parseInt(document.getElementById('regl-marges').value);
        const patch = {
            haut: lireCote('haut'),
            bas: lireCote('bas'),
            // Le champ accepte 5..25 mm (attributs HTML) : une valeur vidée ou hors bornes
            // est ramenée dans la plage, au lieu d'être enregistrée telle quelle ou ignorée.
            marges: Number.isFinite(margeLue) ? Math.min(25, Math.max(5, margeLue)) : 10,
        };
        // Orientation : celle des statistiques vient de leurs blocs, et les fiches sont
        // toujours en portrait (décision de la spec). On n'enregistre donc rien pour elles.
        if (this._docSel !== 'statistiques' && !this._docSel.startsWith('fiche_')) {
            patch.orientation = document.getElementById('regl-orientation').value;
            patch.tenirSurUnePage = document.getElementById('regl-tenir').checked;
        }
        this._params.impression = this._params.impression || {};
        this._params.impression[this._docSel] = { ...(this._params.impression[this._docSel] || {}), ...patch };
        document.getElementById('regl-haut-corps').style.display = patch.haut.actif ? '' : 'none';
        document.getElementById('regl-bas-corps').style.display = patch.bas.actif ? '' : 'none';
        this._sauverMiseEnPage();
        this._majResume();
    },

    _majResume() {
        document.querySelectorAll('.print-doc-item').forEach(b => {
            const r = b.querySelector('.print-doc-resume');
            if (r) r.textContent = this._resumeDocument(b.dataset.doc);
        });
    },

    /** Enregistrement des réglages (une seule requête, après une pause de frappe). */
    _sauverMiseEnPage() {
        clearTimeout(this._sauvegardeTimer);
        // L'objet visé est capturé MAINTENANT : `_loadData()` remplace `this._params` en
        // revenant sur l'écran, et la minuterie relisait alors un blob qui ne contenait pas
        // le réglage qu'on venait de changer (perte silencieuse, trouvée le 18/10/2026).
        const impression = this._params.impression;
        this._sauvegardeTimer = setTimeout(async () => {
            try {
                await API.put('params.php', { impression });
                this._sauvegardeEnEchec = false;
            } catch (e) {
                // Un échec silencieux ferait croire à des réglages enregistrés : on le dit
                // UNE fois (pas à chaque frappe), et on réessaiera au changement suivant.
                console.warn('[Print] réglages non enregistrés :', e);
                if (!this._sauvegardeEnEchec) {
                    this._sauvegardeEnEchec = true;
                    if (typeof Toast !== 'undefined' && Toast.show) {
                        Toast.show('Réglages d\'impression non enregistrés (serveur injoignable).', 'error');
                    }
                }
            }
        }, 800);
    },

    /* ---- Événements ---- */

    _bindEvents() {
        document.querySelectorAll('.print-doc-item').forEach(btn => {
            btn.addEventListener('click', () => {
                this._afficherDocument(btn.dataset.doc);
                this._genererAuto();
            });
        });
        document.getElementById('btn-print-generate').addEventListener('click', () => this._actualiser());
        document.getElementById('btn-print-imprimer').addEventListener('click', () => this._imprimer());
        document.getElementById('btn-print-telecharger').addEventListener('click', () => this._telecharger());
        document.getElementById('btn-print-apercu').addEventListener('click', () => {
            this._ouvrirApercuAmarre();
            if (!this._pendingDef) this._genererAuto();
        });

        ['regl-haut-actif', 'regl-bas-actif', 'regl-marges', 'regl-orientation', 'regl-tenir'].forEach(id => {
            document.getElementById(id).addEventListener('change', () => { this._lireMiseEnPage(); this._genererAuto(); });
        });
        document.querySelectorAll('input[data-cote]').forEach(c => {
            c.addEventListener('change', () => { this._lireMiseEnPage(); this._genererAuto(); });
        });
        ['regl-haut-texte', 'regl-bas-texte'].forEach(id => {
            document.getElementById(id).addEventListener('input', () => { this._lireMiseEnPage(); this._genererAuto(); });
        });
    },

    /** Événements du bloc de contenu (recréé à chaque changement de document). */
    _bindContenu() {
        document.querySelectorAll('[data-select]').forEach(btn => {
            btn.addEventListener('click', () => {
                this._selectAllToggle(btn.dataset.select, btn.dataset.action !== 'none');
                this._genererAuto();
            });
        });
        document.querySelectorAll('[data-stats-select]').forEach(btn => {
            btn.addEventListener('click', () => {
                const tout = btn.dataset.statsSelect !== 'none';
                document.querySelectorAll('input[name="print-stats-bloc"]').forEach(c => {
                    c.checked = tout;
                    const carte = c.closest('.export-card');
                    if (carte) carte.classList.toggle('active', tout);
                });
                this._genererAuto();
            });
        });
        // Pagination des statistiques : un réglage PAR DOCUMENT, enregistré comme les autres.
        document.querySelectorAll('input[name="print-stats-pagination"]').forEach(radio => {
            radio.addEventListener('change', () => {
                if (!radio.checked) return;
                this._params.impression = this._params.impression || {};
                this._params.impression.statistiques = {
                    ...(this._params.impression.statistiques || {}),
                    blocsParPage: radio.value,
                };
                this._sauverMiseEnPage();
                this._majResume();
                this._genererAuto();
            });
        });
        ['print-eleve', 'print-adulte', 'print-semaine'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.addEventListener('change', () => {
                if (id === 'print-semaine') this._semaineChoisie = el.value;
                this._genererAuto();
            });
        });
        ['print-multi-eleves', 'print-multi-adultes', 'print-fiche-eleves'].forEach(id => {
            const el = document.getElementById(id);
            if (el) el.addEventListener('change', () => this._genererAuto());
        });
        document.querySelectorAll('input[name="print-stats-bloc"]').forEach(c => {
            c.addEventListener('change', () => {
                const carte = c.closest('.export-card');
                if (carte) carte.classList.toggle('active', c.checked);
                this._genererAuto();
            });
        });
        this._bindWeekSearch();
    },

    _bindWeekSearch() {
        const input = document.getElementById('print-semaine-search');
        const select = document.getElementById('print-semaine');
        if (!input || !select) return;
        const allOpts = Array.from(select.options).map(o => ({ value: o.value, text: o.text }));
        input.addEventListener('input', () => {
            const q = input.value.toLowerCase();
            const courant = select.value;
            const visibles = allOpts.filter(o => !q || o.text.toLowerCase().includes(q));
            // La sélection courante reste TOUJOURS dans la liste : filtrer ne doit pas changer
            // la semaine imprimée en silence (défaut trouvé le 18/10/2026). Si elle ne
            // correspond pas au filtre, on la garde en tête pour pouvoir la désélectionner.
            const garder = allOpts.find(o => o.value === courant);
            if (garder && !visibles.some(o => o.value === courant)) visibles.unshift(garder);
            select.innerHTML = visibles
                .map(o => `<option value="${o.value}">${escapeHtml(o.text)}</option>`)
                .join('');
            if (visibles.some(o => o.value === courant)) select.value = courant;
            else if (visibles.length) select.value = visibles[0].value;
        });
    },

    _selectAllToggle(selectId, selectAll) {
        const el = document.getElementById(selectId);
        if (!el) return;
        Array.from(el.options).forEach(o => { o.selected = selectAll; });
    },

    /* ---- Génération ---- */

    /**
     * Tout changement de contenu ou de réglage invalide l'aperçu COURANT : Imprimer et
     * Télécharger ne doivent jamais utiliser le document précédent. Sans cela, choisir
     * l'élève B puis cliquer « Imprimer » dans les 450 ms sortait la fiche de A
     * (confidentialité — constat de la revue du 18/10/2026).
     */
    _invaliderApercu() {
        this._pendingDef = null;
        this._pendingFilename = null;
        this._avertissementApercu = null;
        this._demande = (this._demande || 0) + 1;
        this._majBoutonsApercu();
        // L'aperçu affiché ne correspond plus au document : il ne doit ni se dire « prêt »
        // ni laisser croire qu'on peut le télécharger (le bouton de la fenêtre restait actif
        // et ne faisait rien). Trouvé par la revue du 18/10/2026.
        const label = document.getElementById('print-preview-label');
        if (label) label.textContent = 'Mise à jour de l’aperçu…';
        const dlBtn = document.getElementById('btn-print-download');
        if (dlBtn) dlBtn.disabled = true;
        const zone = document.getElementById('print-preview-area');
        const placeholder = document.getElementById('print-preview-placeholder');
        if (zone) zone.style.display = 'none';
        if (placeholder) placeholder.style.display = 'flex';
        return this._demande;
    },

    /** Les deux boutons ne s'activent qu'avec l'aperçu du document affiché. */
    _majBoutonsApercu() {
        const pret = !!this._pendingDef;
        ['btn-print-imprimer', 'btn-print-telecharger'].forEach(id => {
            const b = document.getElementById(id);
            if (b) b.disabled = !pret;
        });
    },

    /** Bouton « Actualiser » : même garde que la génération automatique. */
    _actualiser() {
        // Les statistiques ont leur propre message, plus précis (« Cochez au moins une
        // statistique ») : on les laisse à `_generateStats`.
        if (this._docSel !== 'statistiques' && !this._contenuPret()) {
            const quoi = (this._docSel === 'edt_semaine_adulte' || this._docSel === 'edt_jour_adultes') ? 'adulte' : 'élève';
            this._prevenirSelectionVide(quoi);
            return;
        }
        return this._generate();
    },

    /** Régénère l'aperçu après une pause (frappe, clic) : pas à chaque touche. */
    _genererAuto() {
        clearTimeout(this._apercuTimer);
        const demande = this._invaliderApercu();
        this._apercuTimer = setTimeout(() => {
            if (demande !== this._demande) return;           // un autre changement a pris la main
            if (!this._surImpression()) return;              // on a quitté l'écran
            if (this._contenuPret()) this._generate(demande);
        }, 450);
    },

    _surImpression() {
        return location.hash === '#print' || location.hash === '#impression';
    },

    /** Message unique quand la sélection est vide (les statistiques alertaient déjà). */
    _prevenirSelectionVide(quoi) {
        if (typeof Modal !== 'undefined' && Modal.alert) {
            Modal.alert('Rien à imprimer', 'Sélectionnez au moins un' + (quoi === 'élève' ? ' élève' : ' ' + quoi) + '.');
        }
    },

    /** Évite d'afficher une alerte quand une sélection est encore vide. */
    _contenuPret() {
        // Les documents à UNE personne : sans élève ni adulte choisi, on ne fabrique rien.
        // Sans cette garde, une base neuve produisait « Élève #NaN » et un fichier
        // `edt_eleve_nan_…pdf` (mesuré le 18/10/2026).
        if (this._docSel === 'edt_semaine_eleve') return !!document.getElementById('print-eleve')?.value;
        if (this._docSel === 'edt_semaine_adulte') return !!document.getElementById('print-adulte')?.value;
        if (this._docSel === 'edt_jour_eleves') {
            return (document.getElementById('print-jours-eleves')?.selectedOptions.length || 0) > 0
                && (document.getElementById('print-multi-eleves')?.selectedOptions.length || 0) > 0;
        }
        if (this._docSel === 'edt_jour_adultes') {
            return (document.getElementById('print-jours-adultes')?.selectedOptions.length || 0) > 0
                && (document.getElementById('print-multi-adultes')?.selectedOptions.length || 0) > 0;
        }
        if (this._docSel === 'statistiques') return [...document.querySelectorAll('input[name="print-stats-bloc"]')].some(c => c.checked);
        if (this._docSel.startsWith('fiche_')) return (document.getElementById('print-fiche-eleves')?.selectedOptions.length || 0) > 0;
        return true;
    },

    async _generate(demande) {
        if (demande == null) demande = this._invaliderApercu();
        const cle = this._docSel;

        if (cle === 'statistiques') return this._generateStats(demande);
        if (cle === 'fiche_urgence' || cle === 'fiche_renseignements') {
            return this._generateFiches(cle === 'fiche_urgence' ? 'urgence' : 'renseignement', demande);
        }

        const semaineVal = document.getElementById('print-semaine')?.value || 'template';
        const semaineId = semaineVal === 'template' ? null : parseInt(semaineVal);
        this._semaineChoisie = semaineVal;

        try {
            let def, filename;
            if (cle === 'edt_semaine_eleve') {
                const id = parseInt(document.getElementById('print-eleve').value);
                const eleve = this._eleves.find(e => e.id === id);
                const label = eleve ? `${eleve.prenom || ''} ${eleve.nom || ''}`.trim() : `Élève #${id}`;
                filename = this._nomFichier(cle, { detail: label, semaine: this._semaineFichier(semaineId) });
                def = await this._buildStudentWeek(id, semaineId);
            } else if (cle === 'edt_semaine_adulte') {
                const nom = document.getElementById('print-adulte').value;
                filename = this._nomFichier(cle, { detail: nom, semaine: this._semaineFichier(semaineId) });
                def = await this._buildAdultWeekFromAPI(nom, semaineId);
            } else if (cle === 'edt_jour_eleves') {
                const jours = [...document.getElementById('print-jours-eleves').selectedOptions].map(o => o.value);
                const ids = [...document.getElementById('print-multi-eleves').selectedOptions].map(o => parseInt(o.value));
                if (!jours.length) return this._prevenirSelectionVide('jour');
                if (!ids.length) return this._prevenirSelectionVide('élève');
                filename = this._nomFichier(cle, { detail: jours.join('-') + ' ' + ids.length + ' eleves', semaine: this._semaineFichier(semaineId) });
                def = await this._buildMultiDaysFromAPI(jours, semaineId, ids);
            } else if (cle === 'edt_jour_adultes') {
                const jours = [...document.getElementById('print-jours-adultes').selectedOptions].map(o => o.value);
                const noms = [...document.getElementById('print-multi-adultes').selectedOptions].map(o => o.value);
                if (!jours.length) return this._prevenirSelectionVide('jour');
                if (!noms.length) return this._prevenirSelectionVide('adulte');
                filename = this._nomFichier(cle, { detail: jours.join('-') + ' ' + noms.length + ' adultes', semaine: this._semaineFichier(semaineId) });
                // Toujours la grille « jour » : même avec UN adulte, c'est le document
                // « Jour · Adulte(s) » (A4 paysage, réglages à lui). L'ancien raccourci passait
                // par la semaine adulte — donc portrait, avec les réglages d'un autre document
                // et un titre sans le jour (trouvé le 18/10/2026).
                def = await this._buildMultiAdultDays(jours, semaineId, noms);
            }
            // Une génération plus récente a pris la main : ce résultat est périmé.
            if (demande !== this._demande) return;
            if (def) this._showPreview(def, filename);
        } catch (e) {
            if (demande !== this._demande) return;
            console.error('[Print] generate error:', e);
            if (typeof Modal !== 'undefined' && Modal.alert) {
                Modal.alert('Erreur', 'Impossible de générer le document : ' + (e.message || 'Erreur inconnue'));
            }
        }
    },

    /** « s12 » ou « semaine-type » : le numéro SCOLAIRE, jamais l'identifiant de base. */
    _semaineFichier(semaineId) {
        const s = semaineId && this._semaines.find(x => x.id === semaineId);
        return s ? `s${getSchoolWeekNumber(s, this._semaines)}` : 'semaine-type';
    },

    _imprimer() {
        if (!this._pendingDef) {
            if (typeof Toast !== 'undefined' && Toast.show) {
                Toast.show('L\'aperçu du document est en cours de préparation…', 'info');
            }
            this._genererAuto();
            return;
        }
        try { pdfMake.createPdf(this._pendingDef).print(); }
        catch (e) { if (typeof Modal !== 'undefined' && Modal.alert) Modal.alert('Impression', 'L\'impression directe n\'a pas pu s\'ouvrir : utilisez « Télécharger le PDF ».'); }
    },

    _telecharger() {
        if (!this._pendingDef || !this._pendingFilename) {
            if (typeof Toast !== 'undefined' && Toast.show) {
                Toast.show('L\'aperçu du document est en cours de préparation…', 'info');
            }
            this._genererAuto();
            return;
        }
        this._download(this._pendingDef, this._pendingFilename);
    },

    async _ensureParams() {
        if (this._params) return this._params;
        const raw = await API.get('params.php');
        const params = {};
        (raw || []).forEach(p => {
            try { params[p.cle] = JSON.parse(p.valeur); } catch { params[p.cle] = p.valeur; }
        });
        this._params = params;
        return params;
    },
};

// En quittant la page Impression, on rend la fenêtre d'aperçu à son usage normal (flottante).
window.addEventListener('hashchange', () => {
    const surImpression = location.hash === '#print' || location.hash === '#impression';
    const voile = document.getElementById('apercu-voile');
    if (!surImpression) {
        // Un aperçu programmé (débounce) ne doit pas s'ouvrir sur un autre écran.
        clearTimeout(Print._apercuTimer);
        Print._apercuOuvert = false;
    }
    if (!surImpression && document.body.classList.contains('impression-ouverte')) {
        document.body.classList.remove('impression-ouverte');
        if (voile) voile.classList.add('cache');
    }
});

// Redimensionner la fenêtre ne doit pas laisser l'aperçu amarré recouvrir les réglages
// (ou l'inverse). On repasse en fenêtre flottante sous 1100 px, et on réamarre au-dessus.
window.addEventListener('resize', () => {
    if (typeof Print === 'undefined' || !Print._apercuOuvert) return;
    const surImpression = location.hash === '#print' || location.hash === '#impression';
    if (!surImpression) return;
    document.body.classList.toggle('impression-ouverte', window.innerWidth > 1100);
});
