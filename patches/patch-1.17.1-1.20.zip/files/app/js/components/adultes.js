/**
 * Calulis — Phase 8 : Page Adultes dédiée
 * Liste des adultes avec filtres par catégorie (enseignant/personnel/autres de notre école)
 * CRUD complet via FicheAdulte existante
 */
const AdultesList = {
    _adultes: [],
    _notreId: null,
    _activeFilter: '', // '', 'enseignant_notre', 'personnel_notre', 'autres'
    _searchTerm: '',
    _sort: { col: 'nom', dir: 'asc' },

    async render() {
        const view = document.getElementById('view-adultes');
        view.innerHTML = '<div class="placeholder-view"><div class="placeholder-icon">⏳</div><div class="placeholder-title">Chargement des adultes…</div></div>';

        // Charger notre_etablissement_id
        try {
            const params = await API.get('params.php');
            const row = Array.isArray(params) ? params.find(p => p.cle === 'notre_etablissement_id') : null;
            this._notreId = (row && row.valeur !== 'null') ? parseInt(row.valeur) : null;
        } catch {
            this._notreId = null;
        }

        this._activeFilter = '';
        this._searchTerm = '';
        view.innerHTML = this._buildHTML();
        this._bandeauDoublons(view);
        this._bindEvents();
        await this._load();
    },

    /** Bandeau discret : des fiches portent le même nom (§ 16). On informe, on ne bloque pas. */
    async _bandeauDoublons(view) {
        try {
            const d = await API.get('adultes.php?doublons=1');
            const n = (d && d.groupes) ? d.groupes.length : 0;
            if (!n) { return; }
            const b = document.createElement('div');
            b.style.cssText = 'margin:0 0 12px 0;padding:10px 14px;border-radius:8px;background:#fff8e1;border:1px solid #ffe082';
            b.innerHTML = '<strong>' + n + ' fiche(s) portent le même nom.</strong> Les fusionner donne une seule ' +
                'fiche qui porte tout. <button type="button" class="btn btn-sm btn-secondary" onclick="FusionAdultes.open()">Voir</button>';
            view.insertBefore(b, view.firstChild);
        } catch (e) { /* un bandeau qui échoue ne doit pas casser l'annuaire */ }
    },

    _buildHTML() {
        const f = this._activeFilter;
        const hasEtab = !!this._notreId;
        return `
            <div class="toolbar" data-help="Adultes|Tous les adultes qui interviennent auprès des élèves ULIS. Filtrez par catégorie : 👩‍🏫 Enseignants (ceux de votre école), 👥 Personnel (AESH, directeur, coordonnateur ULIS…), 🌍 Autres (intervenants extérieurs : orthophonistes, psychomotriciens, éducateurs ASE, SESSAD…).">
                <button class="btn btn-primary" id="btn-new-adulte">+ Nouvel adulte</button>
                <button class="btn btn-sm btn-secondary" id="btn-sync-adultes" title="Créer les fiches des adultes cités dans l'emploi du temps" data-help="Créer depuis l'emploi du temps|Chaque nom cité dans un créneau mais absent de cette liste reçoit une fiche (orthophoniste, SESSAD, CMPP…). Les noms déjà présents ne sont pas dupliqués, même écrits avec ou sans civilité. Rien n'est modifié dans l'emploi du temps ; les fiches créées sont à compléter (prénom, rôle, coordonnées).">＋ Depuis l'emploi du temps</button>
                <input type="text" id="filter-adultes-search" class="topbar-search" placeholder="Rechercher un adulte…" style="max-width:200px" value="${escapeHtml(this._searchTerm)}">
                <span class="toggle-group" id="toggle-adultes-filtre">
                    <button data-value="enseignant_notre" class="${f === 'enseignant_notre' ? 'active' : ''}" ${!hasEtab ? 'disabled title="Configurer l\'établissement dans Paramètres"' : ''}>👩‍🏫 Enseignants</button>
                    <button data-value="personnel_notre" class="${f === 'personnel_notre' ? 'active' : ''}" ${!hasEtab ? 'disabled title="Configurer l\'établissement dans Paramètres"' : ''}>👥 Personnel</button>
                    <button data-value="autres" class="${f === 'autres' ? 'active' : ''}" ${!hasEtab ? 'disabled title="Configurer l\'établissement dans Paramètres"' : ''}>🌍 Autres</button>
                </span>
                ${!hasEtab ? '<span class="text-warning small" style="margin-left:8px">⚠ Configurer l\'établissement dans Paramètres pour les filtres</span>' : ''}
                <button class="btn btn-sm btn-secondary" id="btn-csv-adultes" title="Exporter en CSV">📥 CSV</button>
                <span class="text-muted" id="adultes-count" style="margin-left:auto"></span>
            </div>
            <div class="card" style="flex:1;overflow:auto;padding:0" data-help="Fiche adulte|Clic sur Fiche = consultation en lecture seule. Clic sur Modifier = édition complète. La colonne Actif : ✅ = en activité, Inactif = archivé.">
                <table class="data-table" id="table-adultes">
                    <thead>
                        <tr>
                            <th data-sort="civilite" class="sortable">Civilité</th>
                            <th data-sort="nom" class="sortable">Nom</th>
                            <th data-sort="prenom" class="sortable">Prénom</th>
                            <th data-sort="metier" class="sortable">Métier / rôle</th>
                            <th data-sort="fonction" class="sortable">Fonction</th>
                            <th data-sort="classe_nom" class="sortable">Classe</th>
                            <th>Établissement</th>
                            <th>Contact</th>
                            <th>Commentaire</th>
                            <th data-sort="actif" class="sortable">Actif</th>
                            <th style="width:130px">Actions</th>
                        </tr>
                    </thead>
                    <tbody id="tbody-adultes"><tr><td colspan="11" class="empty">Chargement…</td></tr></tbody>
                </table>
            </div>`;
    },

    _bindEvents() {
        document.getElementById('btn-new-adulte').addEventListener('click', () => {
            FicheAdulte.open({});
        });

        document.getElementById('btn-csv-adultes').addEventListener('click', () => this._exportCSV());

        // Créer les fiches des adultes cités dans l'emploi du temps (26/10/2026).
        // Une professionnelle absente de cette liste n'a AUCUNE colonne dans la vue
        // Adultes de l'emploi du temps : ce bouton répare cet oubli, sans rien
        // inventer (les noms déjà connus, même écrits autrement, ne sont pas dupliqués).
        document.getElementById('btn-sync-adultes')?.addEventListener('click', async () => {
            // Confirmation à bouton NORMAL (pas Modal.confirm, réservé aux actions
            // dangereuses : il affiche un bouton ROUGE — ici, on ne supprime rien).
            const ok = await new Promise((resolve) => {
                let choisi = false;
                Modal.open({
                    title: 'Créer les adultes de l’emploi du temps',
                    body: '<p>Chaque nom cité dans un créneau mais absent de cette liste recevra une fiche adulte, avec le rôle du créneau (« Autre » s’il n’est pas reconnu). Les personnes déjà présentes ne sont pas dupliquées, même écrites avec ou sans civilité. Rien n’est modifié dans l’emploi du temps.</p>',
                    footer: '<button class="btn btn-secondary" id="btn-sync-cancel">Annuler</button>' +
                            '<button class="btn btn-primary" id="btn-sync-ok">Créer les fiches</button>',
                    onClose: () => resolve(choisi),
                });
                document.getElementById('btn-sync-cancel').addEventListener('click', () => { Modal.close(); resolve(false); });
                document.getElementById('btn-sync-ok').addEventListener('click', () => { choisi = true; Modal.close(); resolve(true); });
            });
            if (!ok) return;
            try {
                const res = await API.post('adultes.php', { action: 'sync_creneaux' });
                if (res.crees > 0) Toast.success(res.crees + ' fiche(s) adulte créée(s) — à compléter.');
                else Toast.info('Aucune fiche à créer : chaque nom de l’emploi du temps a déjà son adulte.');
                await this._load();
            } catch (e) {
                Modal.alert('Erreur', e.message);
            }
        });

        document.getElementById('filter-adultes-search').addEventListener('input', () => {
            this._searchTerm = document.getElementById('filter-adultes-search').value;
            this._load();
        });

        // Toggle group : un seul actif à la fois, re-clic désélectionne
        const group = document.getElementById('toggle-adultes-filtre');
        group.addEventListener('click', (e) => {
            const btn = e.target.closest('button');
            if (!btn) return;
            if (btn.classList.contains('active')) {
                btn.classList.remove('active');
                this._activeFilter = '';
            } else {
                group.querySelector('.active')?.classList.remove('active');
                btn.classList.add('active');
                this._activeFilter = btn.dataset.value;
            }
            this._load();
        });

        // Re-render après création/modification
        State.off('adultes:changed', this._onChanged);
        this._onChanged = () => this._load();
        State.on('adultes:changed', this._onChanged);

        // Tri par colonnes
        document.querySelectorAll('#table-adultes th.sortable').forEach(th => {
            th.addEventListener('click', () => {
                const col = th.dataset.sort;
                if (this._sort.col === col) this._sort.dir = this._sort.dir === 'asc' ? 'desc' : 'asc';
                else { this._sort.col = col; this._sort.dir = 'asc'; }
                this._renderTable();
            });
        });
    },

    async _load() {
        const q = this._searchTerm;
        const filtre = this._activeFilter;
        // Forcer réinitialisation des filtres si pas d'établissement configuré
        if (filtre && !this._notreId) {
            this._activeFilter = '';
            document.querySelectorAll('#toggle-adultes-filtre .active').forEach(b => b.classList.remove('active'));
        }
        const params = new URLSearchParams();
        if (filtre && this._notreId) {
            params.set('filtre', filtre);
            params.set('notre_etablissement', this._notreId);
        }
        if (q) params.set('q', q);
        const qs = params.toString();
        try {
            this._adultes = await API.get('adultes.php' + (qs ? '?' + qs : ''));
            this._renderTable();
        } catch (e) {
            document.getElementById('tbody-adultes').innerHTML =
                `<tr><td colspan="11" class="empty" style="color:var(--danger)">Erreur : ${escapeHtml(e.message)}</td></tr>`;
        }
    },

    _sortData(data) {
        if (!this._sort.col) return data;
        const dir = this._sort.dir === 'asc' ? 1 : -1;
        return [...data].sort((a, b) => {
            if (this._sort.col === 'actif') return ((a.actif ? 1 : 0) - (b.actif ? 1 : 0)) * dir;
            const key = this._sort.col === 'classe_nom' ? 'classe_nom' : this._sort.col;
            const va = (a[key] ?? '').toString().toLowerCase();
            const vb = (b[key] ?? '').toString().toLowerCase();
            return va.localeCompare(vb) * dir;
        });
    },

    _renderTable() {
        const tbody = document.getElementById('tbody-adultes');
        const count = document.getElementById('adultes-count');
        if (count) count.textContent = this._adultes.length + ' adulte(s)';

        if (!this._adultes.length) {
            const hasFilter = this._searchTerm || this._activeFilter;
            const cta = (hasFilter || State.get('consultation')) ? ''
                : '<button class="btn btn-primary" onclick="FicheAdulte.open({})" style="margin-top:12px">+ Nouvel adulte</button>';
            tbody.innerHTML = `<tr><td colspan="11" class="empty">${hasFilter ? 'Aucun résultat trouvé.' : 'Aucun adulte enregistré.'}<br>${cta}</td></tr>`;
            return;
        }

        const sorted = this._sortData(this._adultes);
        tbody.innerHTML = sorted.map(a => {
            const estNotreEcole = this._estNotreEcole(a);
            const classeNom = a.classe_nom || '';
            // R9 (audit du 27/10/2026) : la fiche écrit le MÉTIER (libellé) et les RÔLES ;
            // l'ancienne clé technique ne sert plus qu'aux filtres et aux couleurs. On
            // affiche donc le métier, et les rôles en second — plus de cellule vide.
            const roleLabel = a.metier || this._formatRole(a.role || '');

            // Établissement : nom + badge "Notre école" si pertinent
            let etabStr = '<span class="text-muted">—</span>';
            if (a.liens_etablissements && a.liens_etablissements.length > 0) {
                const noms = a.liens_etablissements.map(e => e.nom || '').filter(Boolean);
                if (noms.length) etabStr = escapeHtml(noms.join(', '));
            }
            if (estNotreEcole) {
                etabStr += ' <span class="badge-notre-etab" style="font-size:10px;padding:1px 6px">🏫 Notre école</span>';
            }

            return `<tr>
                <td>${escapeHtml(a.civilite || '') || '<span class="text-muted">—</span>'}</td>
                <td><strong>${escapeHtml(a.nom || '')}</strong></td>
                <td>${escapeHtml(a.prenom || '')}</td>
                <td><span class="badge">${escapeHtml(roleLabel) || '<span class="text-muted">—</span>'}</span>${(a.roles || []).length ? '<br><span class="text-muted small">' + a.roles.map(r => escapeHtml(r)).join(' · ') + '</span>' : ''}</td>
                <td>${escapeHtml(this._formatFonction(a.fonction || '')) || '<span class="text-muted">—</span>'}</td>
                <td>${classeNom ? escapeHtml(classeNom) : '<span class="text-muted">—</span>'}</td>
                <td class="small">${etabStr}</td>
                <td class="small">
                    ${a.telephone ? '📞 ' + escapeHtml(a.telephone) : ''}
                    ${a.email ? (a.telephone ? '<br>' : '') + '✉ ' + escapeHtml(a.email) : ''}
                    ${!a.telephone && !a.email ? '<span class="text-muted">—</span>' : ''}
                </td>
                <td class="small" title="${escapeHtml(a.commentaires || '')}">${(a.commentaires || '').length > 40 ? escapeHtml((a.commentaires || '').substring(0, 40)) + '…' : escapeHtml(a.commentaires || '') || '<span class="text-muted">—</span>'}</td>
                <td>${a.actif === 1 ? '✅' : '<span class="badge badge-status-expired">Inactif</span>'}</td>
                <td style="white-space:nowrap">
                    <button class="btn-sm btn-edit" data-id="${a.id}" title="Modifier">Modifier</button>
                    <button class="btn-sm btn-del" data-id="${a.id}" title="Supprimer">Supprimer</button>
                    <button class="btn-sm btn-view" data-id="${a.id}" title="Fiche">Fiche</button>
                </td>
            </tr>`;
        }).join('');

        // Events
        tbody.querySelectorAll('.btn-edit').forEach(b => b.addEventListener('click', () => {
            const a = this._adultes.find(x => x.id === parseInt(b.dataset.id));
            if (a) this._openEdit(a);
        }));
        tbody.querySelectorAll('.btn-del').forEach(b => {
            b.addEventListener('click', () => this._delete(parseInt(b.dataset.id)));
        });
        tbody.querySelectorAll('.btn-view').forEach(b => b.addEventListener('click', () => {
            const a = this._adultes.find(x => x.id === parseInt(b.dataset.id));
            if (a) FicheAdulte.open(a, true);
        }));

        this._updateSortHeaders();
    },

    _exportCSV() {
        // R9 : le CSV dit le MÉTIER et les RÔLES (ce que l'utilisateur saisit), pas la clé
        // technique interne — qui serait vide ou « aeshco » dans un tableur.
        const headers = ['nom', 'prenom', 'metier', 'roles', 'fonction', 'actif'];
        const rows = this._adultes.map(a => ({
            ...a,
            metier: a.metier || this._formatRole(a.role || ''),
            roles: (a.roles || []).join(' · '),
            actif: a.actif ? 'Oui' : 'Non',
        }));
        exportCSV('adultes.csv', headers, rows);
    },

    _updateSortHeaders() {
        document.querySelectorAll('#table-adultes th.sortable').forEach(th => {
            if (!th.dataset.label) th.dataset.label = th.textContent;
            th.textContent = th.dataset.sort === this._sort.col
                ? th.dataset.label + (this._sort.dir === 'asc' ? ' ▲' : ' ▼')
                : th.dataset.label;
        });
    },

    _openEdit(adulte) {
        // Recharger les données complètes depuis l'API pour avoir tous les champs
        API.get('adultes.php?id=' + adulte.id).then(full => {
            FicheAdulte.open(full, false);
        }).catch(() => {
            FicheAdulte.open(adulte, false);
        });
    },

    async _delete(id) {
        const a = this._adultes.find(x => x.id === id);
        if (!a || !await Modal.confirm('Confirmer', `Supprimer ${a.prenom || ''} ${a.nom || ''} ?`)) return;
        try {
            await API.del('adultes.php?id=' + id);
            await this._load();
            State.emit('adultes:changed');
            Toast.success('Adulte supprimé');
        } catch (e) {
            Modal.alert('Erreur', e.message);
        }
    },

    _estNotreEcole(adulte) {
        if (!this._notreId) return false;
        if (adulte.etablissement_id === this._notreId) return true;
        const liens = adulte.liens_etablissements || [];
        return liens.some(l => l.etablissement_id === this._notreId);
    },

    _formatRole(role) {
        // Source unique : `libelleRole()` dans utils/format.js (partagée avec les statistiques).
        return libelleRole(role);
    },

    _formatFonction(f) {
        if (!f) return '';
        return f.split(/[_-]/).map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ');
    },
};
