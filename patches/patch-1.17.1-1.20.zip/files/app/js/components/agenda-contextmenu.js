/**
 * Calulis — Agenda Context Menu
 * Ajouté à Agenda via Object.assign
 */

Object.assign(Agenda, {

    _showContextMenu(cell, event) {
        this._hideContextMenu();
        if (State.get('consultation')) return;

        const cid = cell.dataset.id;
        const eleve = cell.dataset.eleve;
        const heure = cell.dataset.heure;
        const jour = cell.dataset.jour;
        const cellSelected = this._selection.cells.has(eleve + '_' + heure + '_' + jour);

        // Si la cellule cliquée n'est pas dans la sélection, la sélectionner seule
        if (!cellSelected) {
            this._selection = {
                anchor: { eleve, heure, jour },
                cells: new Map([[eleve + '_' + heure + '_' + jour, { eleve, heure, jour }]]),
            };
            this._highlightSelection();
        }

        const items = [];
        const selCount = this._selection.cells.size;
        const hasExistingCreneau = cid && !cell.classList.contains('agenda-slot-empty');
        const groupeId = cell.dataset.groupe || '';
        this._menuCible = { groupe: groupeId, id: cid };
        const creneauxSel = this._getSelectedCreneaux();
        const peutFusionner = !groupeId && creneauxSel.length >= 2 && this._peutFusionner(creneauxSel);

        if (groupeId) {
            // Bloc fusionné : on agit sur le GROUPE, jamais sur une seule de ses lignes.
            items.push({ label: '✏️ Modifier', action: 'edit' });
            items.push({ label: '🔗 Détacher les blocs', action: 'separer' });
            items.push({ label: '🗑️ Supprimer le bloc', action: 'supprimer-bloc', danger: true });
        } else if (hasExistingCreneau && selCount === 1) {
            items.push({ label: '✏️ Modifier', action: 'edit' });
            items.push({ label: '📋 Copier', action: 'copy' });
            items.push({ label: '✂️ Couper', action: 'cut' });
            items.push({ label: '🗑️ Supprimer', action: 'delete', danger: true });
        } else if (selCount > 0) {
            if (creneauxSel.length !== selCount) {
                items.push({ label: `✏️ Créer (${selCount} cellule${selCount > 1 ? 's' : ''})`, action: 'create' });
            }
            if (peutFusionner) {
                items.push({ label: '🔗 Fusionner en un bloc', action: 'fusionner' });
            }
        }

        if (this._clipboard) {
            if (items.length > 0) items.push({ sep: true });
            items.push({ label: `📌 Coller (${this._clipboard.creneaux.length})`, action: 'paste' });
        }

        if (items.length === 0) return;

        const backdrop = document.createElement('div');
        backdrop.className = 'ctx-menu-backdrop';
        backdrop.addEventListener('click', () => this._hideContextMenu());
        backdrop.addEventListener('contextmenu', (e) => { e.preventDefault(); this._hideContextMenu(); });

        const menu = document.createElement('div');
        menu.className = 'ctx-menu';
        menu.style.left = Math.min(event.clientX, window.innerWidth - 200) + 'px';
        menu.style.top = Math.min(event.clientY, window.innerHeight - items.length * 40) + 'px';

        items.forEach(item => {
            if (item.sep) {
                const sep = document.createElement('div');
                sep.className = 'ctx-sep';
                menu.appendChild(sep);
                return;
            }
            const btn = document.createElement('button');
            btn.className = 'ctx-menu-item' + (item.danger ? ' danger' : '');
            btn.textContent = item.label;
            btn.addEventListener('click', async () => {
                this._hideContextMenu();
                await this._handleContextAction(item.action);
            });
            menu.appendChild(btn);
        });

        backdrop.appendChild(menu);
        document.body.appendChild(backdrop);
    },

    _hideContextMenu() {
        document.querySelectorAll('.ctx-menu-backdrop').forEach(el => el.remove());
    },

    async _handleContextAction(action) {
        switch (action) {
            case 'edit': {
                const cell = document.querySelector('.agenda-slot.selected, .agenda-slot-empty.selected');
                if (cell) this._openEditModal(cell);
                break;
            }
            case 'delete': {
                const cell = document.querySelector('.agenda-slot.selected');
                const cid = cell?.dataset.id;
                if (!cid) break;
                // Un bloc AFFICHÉ peut être plusieurs créneaux identiques consécutifs (rowSpan
                // par ressemblance, sans regroupement_id). Le menu n'en supprimait qu'un : la
                // seconde ligne devenait invisible et inaccessible à la souris (défaut du
                // 26/10/2026). On supprime tout le bloc affiché.
                const cible = (this._creneaux || []).find(c => Number(c.id) === Number(cid));
                const ids = cible ? this._getMergedCreneauIds(cible) : [cid];
                const question = ids.length > 1
                    ? 'Supprimer les ' + ids.length + ' créneaux de ce bloc ?'
                    : 'Supprimer ce créneau ?';
                if (await Modal.confirm('Supprimer', question)) {
                    await Promise.all(ids.map(id => API.del('creneaux.php?id=' + id)));
                    await this._markModified();
                    this._clearSelection();
                    await this._rechargerCreneaux();
                    await this._nettoyerGroupes();
                }
                break;
            }
            case 'fusionner': {
                const liste = this._getSelectedCreneaux();
                if (!this._peutFusionner(liste)) {
                    if (typeof Toast !== 'undefined') Toast.info('Ces créneaux ne peuvent pas être fusionnés : même début, même durée et colonnes voisines sont nécessaires.');
                    return;
                }
                const token = this._nouveauToken();
                try {
                    await API.put('creneaux.php', { action: 'regroupement', ids: liste.map(c => c.id), regroupement_id: token });
                    await this._rechargerCreneaux();
                    this._clearSelection();
                    if (typeof Toast !== 'undefined') Toast.info('Bloc fusionné — « Détacher » pour revenir à un bloc par élève.');
                } catch (e) { Modal.alert('Erreur', e.message); }
                break;
            }
            case 'separer': {
                const token = this._menuCible?.groupe;
                const ids = (this._creneaux || []).filter(c => token && c.regroupement_id === token).map(c => c.id);
                if (!ids.length) return;
                try {
                    await API.put('creneaux.php', { action: 'regroupement', ids, regroupement_id: null });
                    await this._rechargerCreneaux();
                    if (typeof Toast !== 'undefined') Toast.info('Blocs détachés : un bloc par élève.');
                } catch (e) { Modal.alert('Erreur', e.message); }
                break;
            }
            case 'supprimer-bloc': {
                const token = this._menuCible?.groupe;
                const ids = (this._creneaux || []).filter(c => token && c.regroupement_id === token).map(c => c.id);
                if (!ids.length) return;
                if (!await Modal.confirm('Supprimer le bloc', `Supprimer les ${ids.length} créneaux de ce bloc ? Chaque élève perd son créneau.`)) return;
                try {
                    await Promise.all(ids.map(id => API.del('creneaux.php?id=' + id)));
                    // Sans ce marquage, « Appliquer le template aux semaines non modifiées »
                    // considérait la semaine comme vierge et RECRÉAIT les créneaux qu'on
                    // vient de supprimer (défaut du 26/10/2026).
                    await this._markModified();
                    await this._rechargerCreneaux();
                    this._clearSelection();
                    if (typeof Toast !== 'undefined') Toast.success(ids.length + ' créneaux supprimés.');
                } catch (e) { Modal.alert('Erreur', e.message); }
                break;
            }
            case 'copy':
                this._copySelection();
                break;
            case 'cut':
                await this._cutSelection();
                break;
            case 'paste':
                await this._pasteClipboard();
                break;
            case 'create': {
                const cell = document.querySelector('.agenda-slot.selected, .agenda-slot-empty.selected');
                if (cell) this._openEditModal(cell);
                break;
            }
        }
    },

});
