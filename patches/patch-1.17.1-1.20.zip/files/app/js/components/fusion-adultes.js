/**
 * Calulis — Fusion des fiches adulte en double (§ 16 des décisions du 27/10/2026)
 *
 * Une seule fiche doit porter « enseignant + coordonnateur ». Quand deux fiches
 * désignent la même personne, on les FUSIONNE : la fiche conservée porte tout
 * (rôles, structures, créneaux, classes, tâches), l'autre disparaît.
 *
 * Règles d'écran (§ 16) :
 *  - AUCUNE fiche pré-sélectionnée : on ne peut pas fusionner sans avoir désigné
 *    explicitement sur quelle fiche on s'appuie ;
 *  - une phrase en français AVEC LES CHIFFRES dit ce qui va se passer avant d'agir ;
 *  - « ce ne sont pas les mêmes personnes » existe (deux homonymes sont possibles) et
 *    il ENREGISTRE la paire (décision 16.7) : elle n'est plus proposée.
 *
 * Réécrit le 28/10/2026 (constats R10 et R11 de l'audit du 27/10) :
 *  - une fiche ne se désigne plus par un calcul d'index (« 1 - i » ne vaut que pour
 *    un groupe de DEUX, alors que trois fiches du même nom sont le cas courant) :
 *    tout se désigne par IDENTIFIANT, et chaque autre fiche a sa propre ligne ;
 *  - « ce n'est pas la même personne » appelle l'API au lieu de fermer la fenêtre en
 *    promettant un oubli qui n'avait lieu nulle part.
 */
const FusionAdultes = {

    _donnees: null,
    /** { g: index du groupe, id: identifiant de la fiche CONSERVÉE } */
    _enCours: null,

    async open() {
        let d;
        try {
            d = await API.get('adultes.php?doublons=1');
        } catch (e) {
            Toast.error('Impossible de vérifier les fiches en double : ' + (e.message || ''));
            return;
        }
        const groupes = (d && d.groupes) || [];
        if (!groupes.length) {
            Toast.success('Aucune fiche en double.');
            return;
        }
        this._donnees = groupes;
        this._enCours = null;
        this._afficher();
    },

    /** La fiche d'un groupe, retrouvée par son identifiant (jamais par un calcul d'index). */
    _fiche(g, id) {
        return (g.fiches || []).find(f => Number(f.id) === Number(id)) || null;
    },

    _label(f) {
        return ((f.nom || '') + ' ' + (f.prenom || '')).trim() + ' — ' + (f.metier || f.role || 'métier non renseigné');
    },

    _afficher() {
        const groupes = this._donnees || [];
        let html = '<p class="text-muted small">Ces fiches portent le <strong>même nom et le même prénom</strong>. ' +
            'Désignez la fiche à <strong>conserver</strong>, puis dites pour chaque autre fiche si elle désigne la même ' +
            'personne. Fusionner donne <strong>une seule fiche</strong> qui porte tout : rôles, structures, créneaux, ' +
            'classes et tâches vont sur la fiche conservée. Les valeurs qui diffèrent (deux téléphones, par exemple) ' +
            'sont écrites dans ses commentaires, précédées de « (fiche fusionnée) ».</p>';

        groupes.forEach((g, gi) => {
            html += '<div class="form-section" style="margin-top:14px">';
            html += '<div class="form-section-title">' + escapeHtml((g.fiches[0].nom || '') + ' ' + (g.fiches[0].prenom || '')) + '</div>';
            html += '<div style="display:flex;gap:12px;align-items:stretch">';
            g.fiches.forEach((f) => {
                const choisie = this._enCours && this._enCours.g === gi && Number(this._enCours.id) === Number(f.id);
                html += '<div style="flex:1;border:2px solid ' + (choisie ? '#2e7d32' : '#ddd') + ';border-radius:8px;padding:10px">';
                html += '<div><strong>' + escapeHtml(f.metier || f.role || 'Métier non renseigné') + '</strong></div>';
                html += '<div class="text-muted small">' + (f.fonction ? escapeHtml(f.fonction) : '&nbsp;') + '</div>';
                html += '<ul class="text-muted small" style="margin:8px 0 8px 18px;padding:0">';
                html += '<li>Créneaux d\'emploi du temps : <strong>' + (f.nb_creneaux || 0) + '</strong></li>';
                html += '<li>Classes enseignées : <strong>' + (f.nb_classes || 0) + '</strong></li>';
                html += '<li>Tâches : <strong>' + (f.nb_taches || 0) + '</strong></li>';
                html += '<li>Structures : <strong>' + (f.nb_structures || 0) + '</strong></li>';
                html += '<li>Compte de connexion : <strong>' + ((f.nb_comptes || 0) ? 'oui' : 'non') + '</strong></li>';
                html += '</ul>';
                html += '<button type="button" class="btn btn-sm ' + (choisie ? 'btn-primary' : 'btn-secondary') + '" ' +
                    'onclick="FusionAdultes.designer(' + gi + ',' + Number(f.id) + ')">' +
                    (choisie ? '✓ Fiche conservée' : 'Conserver celle-ci') + '</button>';
                html += '</div>';
            });
            html += '</div>';
            html += '</div>';
        });

        let pied = '<button type="button" class="btn btn-secondary" onclick="Modal.close()">Plus tard</button>';
        if (this._enCours) {
            const g = groupes[this._enCours.g];
            const garde = this._fiche(g, this._enCours.id);
            const autres = (g.fiches || []).filter(f => Number(f.id) !== Number(this._enCours.id));
            if (garde && autres.length) {
                pied = '<div class="text-muted small" style="margin-bottom:6px">Fiche <strong>conservée</strong> : « ' +
                    escapeHtml(this._label(garde)) + ' ». Que faire des autres fiches ?</div>' +
                    autres.map(f => '<div style="display:flex;gap:8px;align-items:center;flex-wrap:wrap;margin:6px 0;padding:6px;border:1px solid #eee;border-radius:6px">' +
                        '<span class="small" style="flex:1;min-width:220px">« ' + escapeHtml(this._label(f)) + ' » : ' +
                        (f.nb_creneaux || 0) + ' créneau(x), ' + (f.nb_classes || 0) + ' classe(s), ' +
                        (f.nb_taches || 0) + ' tâche(s)</span>' +
                        '<button type="button" class="btn btn-sm btn-primary" onclick="FusionAdultes.fusionnerAvec(' + Number(f.id) + ')">Fusionner</button>' +
                        '<button type="button" class="btn btn-sm btn-secondary" onclick="FusionAdultes.pasDoublons(' + Number(f.id) + ')">Ce n\'est pas la même personne</button>' +
                        '</div>').join('') +
                    '<button type="button" class="btn btn-secondary" style="margin-top:8px" onclick="Modal.close()">Plus tard</button>';
            }
        } else {
            pied += ' <span class="text-muted small" style="margin-left:8px">Désignez d\'abord la fiche à conserver.</span>';
        }

        Modal.open({ title: 'Fiches en double', body: html, footer: pied });
    },

    designer(gi, id) {
        this._enCours = { g: gi, id: Number(id) };
        this._afficher();
    },

    /** Fusionne la fiche conservée avec UNE autre fiche désignée par son identifiant. */
    async fusionnerAvec(idAutre) {
        if (!this._enCours) { return; }
        const g = this._donnees[this._enCours.g];
        const garde = this._fiche(g, this._enCours.id);
        const autre = this._fiche(g, idAutre);
        if (!garde || !autre) { return; }
        try {
            await API.post('adultes.php', { action: 'fusionner', garder: garde.id, fusionner: autre.id });
            Modal.close();
            Toast.success('Fiches fusionnées : la fiche de ' + (garde.nom || '') + ' porte désormais tout.');
            if (typeof AdultesList !== 'undefined' && AdultesList.render) { AdultesList.render(); }
        } catch (e) {
            Modal.alert('Fusion impossible', e.message || '');
        }
    },

    /**
     * Décision 16.7 : on ENREGISTRE la paire. Elle n'est plus proposée (ni à la
     * réouverture, ni dans le bandeau de l'annuaire), et les deux fiches restent.
     */
    async pasDoublons(idAutre) {
        if (!this._enCours) { return; }
        const gi = this._enCours.g;
        const g = this._donnees[gi];
        const garde = this._fiche(g, this._enCours.id);
        const autre = this._fiche(g, idAutre);
        if (!garde || !autre) { return; }
        try {
            await API.post('adultes.php', { action: 'non_doublons', a: garde.id, b: autre.id });
        } catch (e) {
            Modal.alert('Décision impossible à enregistrer', e.message || '');
            return;
        }
        // Le serveur ne la proposera plus : on retire la fiche du groupe affiché, sans
        // recharger tout l'écran (l'utilisateur peut encore trancher les autres paires).
        g.fiches = (g.fiches || []).filter(f => Number(f.id) !== Number(idAutre));
        this._enCours = null;
        if ((g.fiches || []).length < 2) {
            this._donnees = this._donnees.filter((_, i) => i !== gi);
        }
        Toast.success('Décision enregistrée : ces deux fiches ne seront plus proposées.');
        if (!this._donnees.length) {
            Modal.close();
            if (typeof AdultesList !== 'undefined' && AdultesList.render) { AdultesList.render(); }
            return;
        }
        this._afficher();
    }
};
