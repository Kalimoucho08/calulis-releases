
/**
 * Calulis — Lot 1 : Droit à l'image (consentements) dans la fiche élève
 * Greffé sur FicheEleve. Ajoute une section « Droit à l'image » dans l'onglet Médical.
 */
Object.assign(FicheEleve, {

  _loadDroitImage() {
    if (!this._eleve || !this._eleve.id) return;
    API.get('consentements.php?eleve_id=' + this._eleve.id + '&type=droit_image').then(items => {
      // L'API trie date_debut DESC, id DESC (Consentement::getByEleve) : la dernière
      // décision est donc l'élément 0. Lire le DERNIER affichait la plus ancienne —
      // sans effet tant que l'historique était effacé, faux depuis qu'il est conservé
      // (défaut trouvé le 26/10/2026).
      const latest = (items && items.length) ? items[0] : null;
      this._droitImageCharge = latest ? (latest.statut || '') : '';
      const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = (v || ''); };
      set('di-statut', latest ? latest.statut : '');
      set('di-date_debut', latest ? latest.date_debut : '');
      set('di-date_fin', latest ? latest.date_fin : '');
      set('di-document_reference', latest ? latest.document_reference : '');
      set('di-commentaires', latest ? latest.commentaires : '');
    }).catch(e => console.error('[FicheEleve] load droit image:', e));
  },

  _getDroitImageFromDOM() {
    const statut = (document.getElementById('di-statut') || {}).value || '';
    if (!statut) return null;
    return {
      type: 'droit_image',
      statut,
      date_debut: (document.getElementById('di-date_debut') || {}).value || '',
      date_fin: (document.getElementById('di-date_fin') || {}).value || '',
      document_reference: (document.getElementById('di-document_reference') || {}).value || '',
      commentaires: (document.getElementById('di-commentaires') || {}).value || '',
    };
  },

  async _saveDroitImage(eleveId) {
    // Ne JAMAIS effacer l'historique : un consentement est une décision DATÉE, et le
    // modèle est prévu pour plusieurs lignes (Consentement::current = la dernière).
    // Avant le 26/10/2026, chaque enregistrement supprimait tout l'historique du droit
    // à l'image. On ajoute donc une ligne SEULEMENT si la décision a changé.
    const existing = await API.get('consentements.php?eleve_id=' + eleveId + '&type=droit_image');
    const latest = (existing && existing.length) ? existing[0] : null;
    const di = this._getDroitImageFromDOM();
    if (!di || !di.statut) {
      // Vider le statut ne retire rien : l'historique est conservé. On l'explique
      // au lieu de ne rien faire — l'ancienne valeur réapparaissait sans un mot.
      if (this._droitImageCharge && typeof Toast !== 'undefined') {
        Toast.info('Pour retirer un droit à l’image, choisissez le statut « Retiré » : la décision reste datée dans l’historique.');
      }
      return;
    }
    const identique = latest
      && String(latest.statut || '') === String(di.statut || '')
      && String(latest.date_debut || '') === String(di.date_debut || '')
      && String(latest.date_fin || '') === String(di.date_fin || '')
      && String(latest.document_reference || '') === String(di.document_reference || '')
      && String(latest.commentaires || '') === String(di.commentaires || '');
    if (identique) return;
    await API.post('consentements.php', Object.assign({ eleve_id: eleveId }, di));
    this._droitImageCharge = di.statut;
  },

});
