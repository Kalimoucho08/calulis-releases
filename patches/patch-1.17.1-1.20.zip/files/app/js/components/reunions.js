/**
 * Calulis — Composant Réunions (liste + CRUD)
 */
const ReunionsList = {
    _reunions: [],
    _eleves: [],
    _typesReunions: {},
    _annees: [],
    /** Année affichée (id en chaîne) — l'année active par défaut (décision 4.2) */
    _annee: '',
    _typeLabels: { ESS: 'ESS', equipe_suivi: 'Équipe de suivi', equipe_educative: 'Équipe éducative', rdv_famille: 'RDV famille', partenariat: 'Partenariat', autre: 'Autre' },

    async render() {
        const view = document.getElementById('view-reunions');
        // Année affichée : l'année active par défaut (décision 4.2). Une réunion datée
        // après sa fin est rangée dans le bloc « à venir — année suivante ».
        if (!this._annee) {
            const active = (typeof State !== 'undefined' && State.get('annee_active'))
                ? State.get('annee_active') : null;
            this._annee = active ? String(active.id) : '';
        }
        // Charger données
        try {
            const [reunions, eleves, annees] = await Promise.all([
                API.get(this._urlReunions()),
                API.get('eleves.php'),
                API.get('annees_scolaires.php').catch(() => []),
            ]);
            this._reunions = Array.isArray(reunions) ? reunions : [];
            this._eleves = Array.isArray(eleves) ? eleves : [];
            this._annees = Array.isArray(annees) ? annees : [];
        } catch {
            this._reunions = [];
            this._eleves = [];
            this._annees = [];
        }
        // Récupérer les types de réunions paramétrés
        try {
            const params = await API.get('params.php');
            params.forEach(p => {
                if (p.cle === 'types_reunions') {
                    try { this._typesReunions = JSON.parse(p.valeur); } catch { this._typesReunions = {}; }
                }
            });
        } catch { this._typesReunions = {}; }

        const optionsAnnees = this._annees.map(a =>
            `<option value="${a.id}"${String(this._annee) === String(a.id) ? ' selected' : ''}>${escapeHtml(a.nom)}</option>`).join('')
            + `<option value=""${this._annee === '' ? ' selected' : ''}>Toutes les années</option>`;

        view.innerHTML = `
            <div class="toolbar" data-help="Réunions|Filtre par année, par type (ESS, équipe éducative...), par statut (prévue, réalisée, annulée) et par mot-clé (titre ou nom d'élève). Clique sur une ligne pour ouvrir la fiche complète d'une réunion. Les réunions déjà créées mais datées après la fin de l'année affichée apparaissent dans un bloc « À venir — année suivante ».">
                <button class="btn btn-primary" id="btn-new-reunion">+ Nouvelle réunion</button>
                <button class="btn btn-sm btn-secondary" id="btn-ics-reunions" title="Exporter les réunions affichées dans un fichier .ics (téléphone, Google Agenda, Outlook)" data-help="Exporter (.ics)|Fabrique un fichier que votre téléphone, Google Agenda ou Outlook savent ouvrir, avec les réunions AFFICHÉES (vos filtres font foi). Le fichier est fabriqué sur votre ordinateur : rien n'est envoyé sur Internet." style="margin-left:8px">📆 Exporter (.ics)</button>
                <div style="display:flex;gap:8px;align-items:center;margin-left:auto">
                    <select id="filter-reunion-annee" style="font-size:13px;max-width:170px" aria-label="Année affichée">
                        ${optionsAnnees}
                    </select>
                    <select id="filter-reunion-type" style="font-size:13px;max-width:180px">
                        <option value="">Tous les types</option>
                        ${Object.entries(this._typeLabels).map(([nom, label]) =>
                            `<option value="${escapeHtml(nom)}">${escapeHtml(label)}</option>`
                        ).join('')}
                    </select>
                    <select id="filter-reunion-statut" style="font-size:13px;max-width:150px">
                        <option value="">Tous statuts</option>
                        <option value="prevue">Prévue</option>
                        <option value="en_cours">En cours</option>
                        <option value="realisee">Réalisée</option>
                        <option value="terminee">Terminée</option>
                        <option value="annulee">Annulée</option>
                        <option value="reportee">Reportée</option>
                    </select>
                    <input type="text" id="filter-reunion-q" placeholder="Rechercher..." style="font-size:13px;width:180px">
                </div>
            </div>
            <div id="reunions-table-container"></div>
        `;

        document.getElementById('btn-new-reunion').addEventListener('click', () => this._openFiche({}));
        document.getElementById('btn-ics-reunions')?.addEventListener('click', () => this._exportICS());
        document.getElementById('filter-reunion-annee').addEventListener('change', async (ev) => {
            this._annee = ev.target.value;
            await this._recharger();
        });
        document.getElementById('filter-reunion-type').addEventListener('change', () => this._renderTable());
        document.getElementById('filter-reunion-statut').addEventListener('change', () => this._renderTable());
        document.getElementById('filter-reunion-q').addEventListener('input', () => this._renderTable());

        this._renderTable();
    },

    /** L'adresse de lecture : l'année affichée, ou toutes. */
    _urlReunions() {
        return 'reunions.php' + (this._annee ? '?annee_scolaire_id=' + this._annee : '');
    },

    /** Relit les réunions de l'année affichée et redessine (année changée, après un ajout). */
    async _recharger() {
        try {
            const reunions = await API.get(this._urlReunions());
            this._reunions = Array.isArray(reunions) ? reunions : [];
        } catch {
            this._reunions = [];
        }
        this._renderTable();
    },

    /** Les réunions telles que l'utilisateur les voit (filtres de la barre d'outils). */
    _reunionsFiltrees() {
        const typeFilter = document.getElementById('filter-reunion-type')?.value || '';
        const statutFilter = document.getElementById('filter-reunion-statut')?.value || '';
        const q = (document.getElementById('filter-reunion-q')?.value || '').toLowerCase();

        let filtered = this._reunions;
        if (typeFilter) filtered = filtered.filter(r => r.type === typeFilter);
        if (statutFilter) filtered = filtered.filter(r => r.statut === statutFilter);
        if (q) {
            filtered = filtered.filter(r =>
                (r.titre || '').toLowerCase().includes(q) ||
                (r.eleve_nom || '').toLowerCase().includes(q) ||
                (r.eleve_prenom || '').toLowerCase().includes(q) ||
                (r.type || '').toLowerCase().includes(q)
            );
        }
        return filtered;
    },

    /**
     * Export .ics des réunions AFFICHÉES (les filtres de la barre d'outils font foi) :
     * c'est ce qui permet de les retrouver sur un téléphone. Le fichier est fabriqué
     * dans le navigateur (`exportICS`).
     */
    _exportICS() {
        const reunions = this._reunionsFiltrees().filter(r => r.date_reunion);
        if (reunions.length === 0) {
            Toast.info('Aucune réunion datée à exporter.');
            return;
        }
        exportICS('reunions-calulis.ics', 'Réunions Calulis', reunions.map(r => ({
            uid: 'reunion-' + r.id + '@calulis',
            debut: r.date_reunion,
            heure: r.heure || null,
            duree: r.duree,
            titre: (this._typeLabels[r.type] ? this._typeLabels[r.type] + ' — ' : '') + (r.titre || 'Réunion'),
            lieu: r.lieu || '',
            description: [
                (r.eleve_prenom || r.eleve_nom) ? 'Élève : ' + [r.eleve_prenom, r.eleve_nom].filter(Boolean).join(' ') : '',
                r.participants ? 'Participants : ' + r.participants : '',
                r.notes || '',
            ].filter(Boolean).join('\n'),
        })));
        Toast.success(reunions.length + ' réunion(s) exportée(s).');
    },

    _renderTable() {
        const filtered = this._reunionsFiltrees();
        const typeFilter = document.getElementById('filter-reunion-type')?.value || '';
        const statutFilter = document.getElementById('filter-reunion-statut')?.value || '';
        const q = (document.getElementById('filter-reunion-q')?.value || '').toLowerCase();
        const hasFilter = typeFilter || statutFilter || q;

        // Décision 4.2 : une réunion déjà créée mais datée APRÈS la fin de l'année affichée
        // est rangée dans un bloc à part « à venir — année suivante ». Elle est donc visible
        // dès sa préparation, sans qu'on ait à changer d'année.
        const annee = this._annees.find(a => String(a.id) === String(this._annee)) || null;
        const aVenir = (annee && annee.date_fin)
            ? filtered.filter(r => r.date_reunion && r.date_reunion > annee.date_fin)
            : [];
        const principales = filtered.filter(r => !aVenir.includes(r));

        const container = document.getElementById('reunions-table-container');
        let html = '';
        if (principales.length) {
            html += this._tableauReunions(principales);
        }
        if (aVenir.length) {
            html += `<h3 style="margin:22px 0 4px;font-size:15px">À venir — année suivante
                        <span class="text-muted" style="font-weight:400;font-size:13px">(${aVenir.length})</span></h3>
                     <p class="text-muted" style="margin:0 0 10px;font-size:12.5px">
                        Ces réunions sont déjà créées mais se tiendront après la fin de l'année affichée.
                     </p>`;
            html += this._tableauReunions(aVenir);
        }
        if (!html) {
            html = hasFilter
                ? '<div style="text-align:center;padding:32px;color:var(--text-muted)">Aucun résultat trouvé.</div>'
                : `<div style="text-align:center;padding:32px;color:var(--text-muted)">Aucune réunion enregistrée.<br>
                   <button class="btn btn-primary" id="btn-empty-new-reunion" style="margin-top:12px">+ Nouvelle réunion</button></div>`;
        }
        container.innerHTML = html;

        // Bouton CTA dans l'état vide
        const emptyBtn = document.getElementById('btn-empty-new-reunion');
        if (emptyBtn) emptyBtn.addEventListener('click', () => this._openFiche({}));

        // Events (les deux tableaux, s'il y en a deux)
        container.querySelectorAll('[data-action="edit"]').forEach(btn => {
            btn.addEventListener('click', (e) => {
                e.stopPropagation();
                const id = parseInt(btn.dataset.id);
                const r = this._reunions.find(x => x.id === id);
                if (r) this._openFiche(r);
            });
        });
        container.querySelectorAll('[data-action="delete"]').forEach(btn => {
            btn.addEventListener('click', async (e) => {
                e.stopPropagation();
                const id = parseInt(btn.dataset.id);
                if (!await Modal.confirm('Confirmer', 'Supprimer cette réunion ?')) return;
                try {
                    await API.del('reunions.php?id=' + id);
                    this._reunions = this._reunions.filter(x => x.id !== id);
                    this._renderTable();
                } catch (err) {
                    Modal.alert('Erreur', err.message);
                }
            });
        });
        container.querySelectorAll('tr.clickable').forEach(row => {
            row.addEventListener('click', () => {
                const id = parseInt(row.dataset.id);
                const r = this._reunions.find(x => x.id === id);
                if (r) this._openFiche(r, true);
            });
        });
    },

    /** Le tableau d'un groupe de réunions (principal ou « à venir — année suivante »). */
    _tableauReunions(lignes) {
        const badge = (statut) => {
            const labels = { prevue: 'Prévue', realisee: 'Réalisée', annulee: 'Annulée', reportee: 'Reportée', en_cours: 'En cours', terminee: 'Terminée' };
            return `<span class="badge reunion-statut-${statut || 'prevue'}">${labels[statut] || statut || 'prévue'}</span>`;
        };
        const typesCouleurs = this._typesReunions || {};
        const typeBadge = (type) => {
            const couleur = typesCouleurs[type] || '#e0e0e0';
            const label = this._typeLabels[type] || type || '?';
            return `<span class="badge" style="background:${couleur};color:#000;font-size:11px">${escapeHtml(label)}</span>`;
        };
        return `<table class="data-table">
                <thead>
                    <tr>
                        <th>Date</th><th>Heure</th><th>Type</th><th>Titre</th><th>Élève</th><th>Statut</th><th style="width:80px"></th>
                    </tr>
                </thead>
                <tbody>
                    ${lignes.map(r => `
                        <tr class="clickable" data-id="${r.id}">
                            <td>${formatDate(r.date_reunion)}</td>
                            <td>${r.heure ? r.heure.substring(0,5) : '-'}</td>
                            <td>${typeBadge(r.type)}</td>
                            <td><strong>${escapeHtml(r.titre)}</strong>${r.compte_rendu ? ' <span title="Compte rendu rédigé" aria-label="Compte rendu rédigé">📝</span>' : ''}</td>
                            <td>${r.eleve_nom ? escapeHtml(r.eleve_prenom) + ' ' + escapeHtml(r.eleve_nom) : '<span class="text-muted">—</span>'}</td>
                            <td>${badge(r.statut)}</td>
                            <td>
                                <button class="btn-sm btn-edit" data-action="edit" data-id="${r.id}" title="Modifier">✏️</button>
                                <button class="btn-sm btn-del" data-action="delete" data-id="${r.id}" title="Supprimer">🗑️</button>
                            </td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>`;
    },

    _openFiche(data = {}, readonly = false) {
        const isNew = !data || !data.id;
        const r = isNew ? { type: '', titre: '', date_reunion: '', heure: '', duree: 60, eleve_id: null, lieu: '', participants: '', statut: 'prevue', notes: '', documents_lies: '' } : { ...data };

        const elevesOptions = this._eleves.map(e =>
            `<option value="${e.id}" ${r.eleve_id === e.id ? 'selected' : ''}>${escapeHtml(e.prenom)} ${escapeHtml(e.nom)} (${escapeHtml(e.classe || '')})</option>`
        ).join('');

        const typesOptions = Object.entries(this._typesReunions).map(([nom]) =>
            `<option value="${escapeHtml(nom)}" ${r.type === nom ? 'selected' : ''}>${escapeHtml(nom)}</option>`
        ).join('');

        const ro = readonly ? 'disabled' : '';

        Modal.open({
            title: isNew ? 'Nouvelle réunion' : (readonly ? 'Réunion : ' : 'Modifier : ') + escapeHtml(r.titre),
            body: `
                <div class="form-row">
                    <div class="form-group"><label>Type *</label>
                        <select id="fr-type" ${ro}><option value="">—</option>${typesOptions}</select>
                    </div>
                    <div class="form-group"><label>Statut</label>
                        <select id="fr-statut" ${ro}>
                            ${[
                                {v:'prevue', l:'Prévue'},
                                {v:'en_cours', l:'En cours'},
                                {v:'realisee', l:'Réalisée'},
                                {v:'terminee', l:'Terminée'},
                                {v:'annulee', l:'Annulée'},
                                {v:'reportee', l:'Reportée'}
                            ].map(s => `<option value="${s.v}" ${r.statut === s.v ? 'selected' : ''}>${s.l}</option>`).join('')}
                        </select>
                    </div>
                </div>
                <div class="form-group"><label>Titre *</label><input type="text" id="fr-titre" value="${escapeHtml(r.titre || '')}" ${ro}></div>
                <div class="form-row">
                    <div class="form-group"><label>Date *</label><input type="date" id="fr-date" value="${r.date_reunion || ''}" ${ro}></div>
                    <div class="form-group"><label>Heure</label><input type="time" id="fr-heure" value="${r.heure ? r.heure.substring(0,5) : ''}" ${ro}></div>
                    <div class="form-group"><label>Durée (min)</label><input type="number" id="fr-duree" value="${r.duree || 60}" min="15" step="15" ${ro}></div>
                </div>
                <div class="form-row">
                    <div class="form-group"><label>Élève</label>
                        <select id="fr-eleve" ${ro}><option value="">— Aucun —</option>${elevesOptions}</select>
                    </div>
                    <div class="form-group"><label>Lieu</label><input type="text" id="fr-lieu" value="${escapeHtml(r.lieu || '')}" ${ro}></div>
                </div>
                <div class="form-group"><label>Participants</label><input type="text" id="fr-participants" value="${escapeHtml(r.participants || '')}" placeholder="Noms séparés par des virgules" ${ro}></div>
                <div class="form-group"><label>Ordre du jour</label><textarea id="fr-ordre" rows="3" ${ro} placeholder="Les points à examiner…">${escapeHtml(r.ordre_du_jour || '')}</textarea></div>
                <div class="form-group"><label>Notes</label><textarea id="fr-notes" rows="3" ${ro}>${escapeHtml(r.notes || '')}</textarea></div>
                <div class="form-group"><label>Compte rendu</label><textarea id="fr-cr" rows="4" ${ro} placeholder="Ce qui a été dit et décidé…">${escapeHtml(r.compte_rendu || '')}</textarea></div>
                <div class="form-group"><label>Préconisations</label><textarea id="fr-preco" rows="2" ${ro}>${escapeHtml(r.preconisations || '')}</textarea></div>
            `,
            footer: readonly
                ? '<button class="btn btn-secondary" onclick="Modal.close()">Fermer</button>'
                : `<button class="btn btn-secondary" onclick="Modal.close()">Annuler</button>
                   <button class="btn btn-primary" id="btn-save-reunion">Enregistrer</button>`,
        });

        if (!readonly) {
            // Deux clics rapides ne doivent pas créer DEUX réunions (js/utils/actions.js).
            const boutonEnregistrer = document.getElementById('btn-save-reunion');
            boutonEnregistrer.addEventListener('click', () => Action.uneSeule(boutonEnregistrer, async () => {
                const data = {
                    type: document.getElementById('fr-type').value,
                    titre: document.getElementById('fr-titre').value,
                    date_reunion: document.getElementById('fr-date').value,
                    heure: document.getElementById('fr-heure').value || null,
                    duree: parseInt(document.getElementById('fr-duree').value) || 60,
                    eleve_id: document.getElementById('fr-eleve').value ? parseInt(document.getElementById('fr-eleve').value) : null,
                    lieu: document.getElementById('fr-lieu').value,
                    participants: document.getElementById('fr-participants').value,
                    statut: document.getElementById('fr-statut').value,
                    notes: document.getElementById('fr-notes').value,
                    ordre_du_jour: document.getElementById('fr-ordre').value,
                    compte_rendu: document.getElementById('fr-cr').value,
                    preconisations: document.getElementById('fr-preco').value,
                };
                if (!data.titre || !data.date_reunion || !data.type) {
                    Modal.alert('Erreur', 'Type, titre et date sont requis.');
                    return;
                }
                try {
                    if (isNew) {
                        await API.post('reunions.php', data);
                    } else {
                        await API.put('reunions.php?id=' + r.id, data);
                    }
                    Modal.close();
                    await this._recharger();
                    State.emit('reunions:changed');
                } catch (e) {
                    Modal.alert('Erreur', e.message);
                }
            }));
        }
    },
};
