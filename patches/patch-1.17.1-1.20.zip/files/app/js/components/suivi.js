/**
 * Calulis — Suivi des élèves
 *
 * Une note de suivi = un élève, une date, un type et un texte libre.
 * Le suivi ne concerne QUE des élèves (pas de note générale, pas d'auteur : monoposte).
 *
 * L'impression passe par l'aperçu PDF global (Print._showPreview), partagé avec
 * la page Impression : sélection par filtres, par cases cochées, ou tout.
 */
const Suivi = {

    /**
     * Types de notes — DONNÉE (table `types_notes`, décision 6.3 du 27/10/2026), chargée
     * à l'ouverture de l'écran. Renommer un type change son nom partout, y compris sur les
     * notes des années passées (la note garde la CLÉ, jamais le libellé).
     */
    _types: [],
    /** Repli si l'API des types ne répond pas : l'écran reste utilisable. */
    _typesRepli: [
        { cle: 'observation', libelle: 'Observation', couleur: 'observation' },
        { cle: 'objectif',    libelle: 'Objectif',    couleur: 'objectif' },
        { cle: 'reussite',    libelle: 'Réussite',    couleur: 'reussite' },
        { cle: 'alerte',      libelle: 'Alerte',      couleur: 'alerte' },
        { cle: 'action',      libelle: 'Action',      couleur: 'action' },
    ],

    _notes: [],
    _eleves: [],
    _annees: [],
    /** Année affichée (id en chaîne) — par défaut l'année active (décision 6.2) */
    _annee: '',
    /** Une note archivée sort de l'affichage courant, mais reste trouvable (décision 6.1) */
    _afficherArchivees: false,
    _filtres: { eleve_id: '', type: '', du: '', au: '', texte: '' },
    _coches: new Set(),

    /** L'adresse de lecture : l'année affichée et TOUTES les notes (les archivées sont
     *  filtrées à l'écran, pour que la case « Afficher les notes archivées » soit
     *  instantanée et ne dépende pas d'un aller-retour serveur). */
    _urlNotes() {
        const p = new URLSearchParams();
        if (this._annee) p.set('annee_scolaire_id', this._annee);
        p.set('archivees', 'toutes');
        return 'notes_suivi.php?' + p.toString();
    },

    async render() {
        const view = document.getElementById('view-suivi');
        view.innerHTML = '<p class="text-muted" style="padding:24px">Chargement du suivi…</p>';

        // Année par défaut : celle qui est active (décision 6.2), sinon toutes.
        if (!this._annee) {
            const active = (typeof State !== 'undefined' && State.get('annee_active'))
                ? State.get('annee_active') : null;
            this._annee = active ? String(active.id) : '';
        }

        try {
            const [notes, eleves, types, annees] = await Promise.all([
                API.get(this._urlNotes()),
                API.get('eleves.php'),
                API.get('types_notes.php').catch(() => []),
                API.get('annees_scolaires.php').catch(() => []),
            ]);
            this._notes = Array.isArray(notes) ? notes : [];
            this._types = (Array.isArray(types) && types.length) ? types : this._typesRepli.slice();
            this._annees = Array.isArray(annees) ? annees : [];
            this._eleves = (Array.isArray(eleves) ? eleves : [])
                .slice()
                .sort((a, b) => `${a.nom} ${a.prenom}`.localeCompare(`${b.nom} ${b.prenom}`, 'fr'));
        } catch (e) {
            console.error('[Suivi] chargement impossible:', e);
            view.innerHTML = '<p class="text-muted" style="padding:24px">Impossible de charger le suivi. ' +
                'Vérifiez que la base est démarrée.</p>';
            return;
        }

        this._coches = new Set();
        this._dessiner();
    },

    /* ------------------------------------------------------------------ */
    /* Affichage                                                           */
    /* ------------------------------------------------------------------ */

    _filtrees() {
        const f = this._filtres;
        const mot = (f.texte || '').trim().toLowerCase();
        return this._notes.filter(n => {
            // Décision 6.1 : archiver ne supprime rien, mais sort de l'affichage courant.
            if (!this._afficherArchivees && Number(n.archivee) === 1) return false;
            if (f.eleve_id && String(n.eleve_id) !== String(f.eleve_id)) return false;
            if (f.type && n.type !== f.type) return false;
            if (f.du && n.date_note < f.du) return false;
            if (f.au && n.date_note > f.au) return false;
            if (mot) {
                const dansTexte = (n.contenu || '').toLowerCase().includes(mot);
                const dansNom = this._nomEleve(n).toLowerCase().includes(mot);
                if (!dansTexte && !dansNom) return false;
            }
            return true;
        }).sort((a, b) => (b.date_note || '').localeCompare(a.date_note || '') || (b.id - a.id));
    },

    _nomEleve(n) {
        const complet = `${n.eleve_prenom || ''} ${n.eleve_nom || ''}`.trim();
        return complet || 'Élève inconnu';
    },

    _libelleType(cle) {
        const t = this._types.find(x => x.cle === cle);
        return t ? t.libelle : cle;
    },

    _dateFr(iso) {
        if (!iso) return '';
        try {
            return new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'long', year: 'numeric' })
                .format(new Date(iso + 'T00:00:00'));
        } catch { return iso; }
    },

    _dessiner() {
        const view = document.getElementById('view-suivi');
        const liste = this._filtrees();

        const optionsEleves = this._eleves.map(e =>
            `<option value="${e.id}"${String(this._filtres.eleve_id) === String(e.id) ? ' selected' : ''}>` +
            `${escapeHtml((e.prenom || '') + ' ' + (e.nom || ''))}</option>`).join('');

        const optionsTypes = this._types.map(t =>
            `<option value="${t.cle}"${this._filtres.type === t.cle ? ' selected' : ''}>${escapeHtml(t.libelle)}</option>`).join('');

        const optionsAnnees = this._annees.map(a =>
            `<option value="${a.id}"${String(this._annee) === String(a.id) ? ' selected' : ''}>${escapeHtml(a.nom)}</option>`).join('')
            + `<option value=""${this._annee === '' ? ' selected' : ''}>Toutes les années</option>`;

        const lignes = liste.map(n => {
            const type = this._types.find(x => x.cle === n.type) || this._types[0] || { libelle: n.type, couleur: 'neutre' };
            const couleur = type.couleur || 'neutre';
            const cochee = this._coches.has(n.id);
            const archivee = Number(n.archivee) === 1;
            return `
            <article class="suivi-note t-bord-${escapeAttr(couleur)}${cochee ? ' cochee' : ''}${archivee ? ' archivee' : ''}" data-id="${n.id}">
                <div class="suivi-choix">
                    <input type="checkbox" data-coche="${n.id}" ${cochee ? 'checked' : ''}
                           aria-label="Sélectionner la note du ${escapeAttr(this._dateFr(n.date_note))} pour ${escapeAttr(this._nomEleve(n))}">
                </div>
                <div class="suivi-corps">
                    <div class="suivi-tete">
                        <span class="suivi-eleve">${escapeHtml(this._nomEleve(n))}</span>
                        <span class="suivi-date">${escapeHtml(this._dateFr(n.date_note))}</span>
                        <span class="suivi-type t-${escapeAttr(couleur)}">${escapeHtml(type.libelle)}</span>
                        ${archivee ? '<span class="suivi-type t-neutre">Archivée</span>' : ''}
                    </div>
                    <p class="suivi-texte">${escapeHtml(n.contenu)}</p>
                </div>
                <div class="suivi-actions">
                    <button class="btn btn-sm" data-modifier="${n.id}">Modifier</button>
                    <button class="btn btn-sm" data-archiver="${n.id}"
                            title="${archivee ? 'Remettre cette note dans l\'affichage courant' : 'Archiver : la note reste, elle sort seulement de l\'affichage courant'}"
                    >${archivee ? 'Désarchiver' : 'Archiver'}</button>
                </div>
            </article>`;
        }).join('');

        view.innerHTML = `
        <div class="suivi-entete">
            <h2 style="margin:0">Suivi des élèves</h2>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
                <button class="btn btn-secondary" id="suivi-types">Types de notes…</button>
                <button class="btn btn-primary" id="suivi-nouvelle">+ Nouvelle note</button>
            </div>
        </div>

        <div class="card" style="margin:12px 0;display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
            <div class="form-group" style="margin:0">
                <label for="suivi-f-eleve">Élève</label>
                <select id="suivi-f-eleve"><option value="">Tous les élèves</option>${optionsEleves}</select>
            </div>
            <div class="form-group" style="margin:0">
                <label for="suivi-f-annee">Année</label>
                <select id="suivi-f-annee">${optionsAnnees}</select>
            </div>
            <div class="form-group" style="margin:0">
                <label for="suivi-f-type">Type</label>
                <select id="suivi-f-type"><option value="">Tous les types</option>${optionsTypes}</select>
            </div>
            <div class="form-group" style="margin:0">
                <label for="suivi-f-du">Du</label>
                <input type="date" id="suivi-f-du" value="${this._filtres.du}">
            </div>
            <div class="form-group" style="margin:0">
                <label for="suivi-f-au">Au</label>
                <input type="date" id="suivi-f-au" value="${this._filtres.au}">
            </div>
            <div class="form-group" style="margin:0;flex:1;min-width:180px">
                <label for="suivi-f-texte">Dans le texte</label>
                <input type="search" id="suivi-f-texte" placeholder="un mot…" value="${escapeAttr(this._filtres.texte)}">
            </div>
            <div class="form-group" style="margin:0">
                <label for="suivi-f-archivees" style="display:flex;align-items:center;gap:6px">
                    <input type="checkbox" id="suivi-f-archivees" ${this._afficherArchivees ? 'checked' : ''}>
                    Afficher les notes archivées
                </label>
            </div>
            <button class="btn btn-secondary" id="suivi-reinit">Réinitialiser</button>
        </div>

        <div style="display:flex;gap:14px;align-items:center;flex-wrap:wrap;margin-bottom:8px">
            <span class="text-muted"><strong>${liste.length}</strong> note(s) affichée(s)</span>
            <span class="text-muted">·</span>
            <span class="text-muted"><strong id="suivi-n-coches">${this._coches.size}</strong> cochée(s)</span>
            <button class="btn btn-sm" id="suivi-tout">Tout cocher</button>
            <button class="btn btn-sm" id="suivi-rien">Tout décocher</button>
        </div>

        <div class="card" style="margin-bottom:14px;display:flex;gap:12px;flex-wrap:wrap;align-items:flex-end">
            <div class="form-group" style="margin:0">
                <label for="suivi-i-quoi">Quoi imprimer</label>
                <select id="suivi-i-quoi">
                    <option value="filtre">Ce qui est affiché (filtres)</option>
                    <option value="coche">La sélection cochée</option>
                    <option value="tout">Toutes les notes de l'année</option>
                </select>
            </div>
            <div class="form-group" style="margin:0">
                <label for="suivi-i-groupe">Présentation</label>
                <select id="suivi-i-groupe">
                    <option value="eleve">Regroupées par élève</option>
                    <option value="date">Dans l'ordre des dates</option>
                </select>
            </div>
            <div class="form-group" style="margin:0">
                <label for="suivi-i-opt">Contenu</label>
                <select id="suivi-i-opt">
                    <option value="complet">Texte complet des notes</option>
                    <option value="court">Liste courte — SANS le texte des notes</option>
                </select>
            </div>
            <button class="btn btn-secondary" id="suivi-apercu">Aperçu</button>
            <button class="btn btn-primary" id="suivi-imprimer">🖨️ Imprimer / PDF</button>
        </div>

        <div class="suivi-liste" id="suivi-liste">
            ${lignes || '<p class="text-muted" style="padding:16px">Aucune note ne correspond à ces critères.</p>'}
        </div>`;

        this._brancher();
    },

    _brancher() {
        const view = document.getElementById('view-suivi');
        const relire = () => {
            this._filtres.eleve_id = view.querySelector('#suivi-f-eleve').value;
            this._filtres.type = view.querySelector('#suivi-f-type').value;
            this._filtres.du = view.querySelector('#suivi-f-du').value;
            this._filtres.au = view.querySelector('#suivi-f-au').value;
            this._filtres.texte = view.querySelector('#suivi-f-texte').value;
            this._dessiner();
        };
        ['#suivi-f-eleve', '#suivi-f-type', '#suivi-f-du', '#suivi-f-au'].forEach(sel =>
            view.querySelector(sel).addEventListener('change', relire));
        // Changer d'année relit les notes : la décision 6.2 dit « l'année en cours par
        // défaut, une autre au besoin, ou toutes ».
        view.querySelector('#suivi-f-annee').addEventListener('change', async (ev) => {
            this._annee = ev.target.value;
            this._coches.clear();
            await this._recharger();
        });
        view.querySelector('#suivi-f-archivees').addEventListener('change', (ev) => {
            this._afficherArchivees = ev.target.checked;
            this._dessiner();
        });
        view.querySelector('#suivi-types').addEventListener('click', () => this._ouvrirTypesNotes());
        view.querySelector('#suivi-f-texte').addEventListener('input', () => {
            clearTimeout(this._minuteur);
            this._minuteur = setTimeout(relire, 200);
        });
        view.querySelector('#suivi-reinit').addEventListener('click', () => {
            this._filtres = { eleve_id: '', type: '', du: '', au: '', texte: '' };
            this._dessiner();
        });

        view.querySelector('#suivi-tout').addEventListener('click', () => {
            this._filtrees().forEach(n => this._coches.add(n.id));
            this._dessiner();
        });
        view.querySelector('#suivi-rien').addEventListener('click', () => {
            this._coches.clear();
            this._dessiner();
        });

        view.querySelectorAll('[data-coche]').forEach(cb => {
            cb.addEventListener('change', () => {
                const id = Number(cb.dataset.coche);
                if (cb.checked) this._coches.add(id); else this._coches.delete(id);
                const compteur = document.getElementById('suivi-n-coches');
                if (compteur) compteur.textContent = this._coches.size;
                const carte = cb.closest('.suivi-note');
                if (carte) carte.classList.toggle('cochee', cb.checked);
            });
        });

        view.querySelectorAll('[data-modifier]').forEach(b =>
            b.addEventListener('click', () => this._ouvrirNote(Number(b.dataset.modifier))));
        view.querySelectorAll('[data-archiver]').forEach(b =>
            b.addEventListener('click', () => this._basculerArchivage(Number(b.dataset.archiver))));

        view.querySelector('#suivi-nouvelle').addEventListener('click', () => this._ouvrirNote(null));
        view.querySelector('#suivi-apercu').addEventListener('click', () => this._imprimer(true));
        view.querySelector('#suivi-imprimer').addEventListener('click', () => this._imprimer(false));
    },

    /* ------------------------------------------------------------------ */
    /* Création / modification / suppression                               */
    /* ------------------------------------------------------------------ */

    _ouvrirNote(id) {
        const note = id ? this._notes.find(n => n.id === id) : null;
        const optionsEleves = this._eleves.map(e =>
            `<option value="${e.id}"${note && String(note.eleve_id) === String(e.id) ? ' selected' : ''}>` +
            `${escapeHtml((e.prenom || '') + ' ' + (e.nom || ''))}</option>`).join('');
        const optionsTypes = this._types
            .filter(t => t.actif === undefined || Number(t.actif) !== 0 || (note && note.type === t.cle))
            .map(t => `<option value="${t.cle}"${note && note.type === t.cle ? ' selected' : ''}>${escapeHtml(t.libelle)}</option>`)
            .join('');
        const aujourdhui = new Date().toISOString().slice(0, 10);

        Modal.open({
            title: note ? 'Modifier la note' : 'Nouvelle note de suivi',
            body: `
                <div class="form-row">
                    <div class="form-group">
                        <label for="note-eleve">Élève</label>
                        <select id="note-eleve">${optionsEleves}</select>
                    </div>
                    <div class="form-group">
                        <label for="note-date">Date</label>
                        <input type="date" id="note-date" value="${note ? note.date_note : aujourdhui}">
                    </div>
                </div>
                <div class="form-group">
                    <label for="note-type">Type</label>
                    <select id="note-type">${optionsTypes}</select>
                </div>
                <div class="form-group">
                    <label for="note-contenu">Note</label>
                    <textarea id="note-contenu" rows="7" placeholder="Ce que vous avez observé, décidé, réussi…">${note ? escapeHtml(note.contenu) : ''}</textarea>
                </div>`,
            footer: `
                <button class="btn btn-secondary" id="note-annuler">Annuler</button>
                <button class="btn btn-primary" id="note-enregistrer">Enregistrer</button>`,
        });

        document.getElementById('note-annuler').addEventListener('click', () => Modal.close());
        // Modal.open place le focus sur le premier contrôle de la fenêtre (le bouton « fermer »)
        // après 100 ms : on reprend le focus sur le texte juste après.
        setTimeout(() => {
            const zone = document.getElementById('note-contenu');
            if (zone) zone.focus();
        }, 160);
        // Deux clics rapides ne doivent pas créer DEUX notes (js/utils/actions.js).
        const boutonEnregistrer = document.getElementById('note-enregistrer');
        boutonEnregistrer.addEventListener('click', () => Action.uneSeule(boutonEnregistrer, async () => {
            const donnees = {
                eleve_id: Number(document.getElementById('note-eleve').value),
                date_note: document.getElementById('note-date').value,
                type: document.getElementById('note-type').value,
                contenu: document.getElementById('note-contenu').value.trim(),
            };
            if (!donnees.contenu) {
                Toast.show('La note est vide.', 'error');
                return;
            }
            try {
                if (note) {
                    await API.put(`notes_suivi.php?id=${note.id}`, donnees);
                } else {
                    await API.post('notes_suivi.php', donnees);
                }
                Modal.close();
                Toast.show(note ? 'Note modifiée.' : 'Note ajoutée.', 'success');
                await this._recharger();
            } catch (e) {
                console.error('[Suivi] enregistrement impossible:', e);
                Toast.show('Enregistrement impossible : ' + (e.message || 'erreur inconnue'), 'error');
            }
        }));
    },

    /**
     * Archiver / désarchiver (décision 6.1). La note n'est JAMAIS supprimée : elle sort de
     * l'affichage courant et se retrouve par période, par type ou par mot en cochant
     * « Afficher les notes archivées ».
     */
    async _basculerArchivage(id) {
        const note = this._notes.find(n => n.id === id);
        if (!note) return;
        const archivee = Number(note.archivee) === 1 ? 0 : 1;
        try {
            await API.put(`notes_suivi.php?id=${id}`, { archivee });
            note.archivee = archivee;
            Toast.show(archivee ? 'Note archivée : elle reste consultable.' : 'Note remise dans l\'affichage courant.', 'success');
            this._dessiner();
        } catch (e) {
            console.error('[Suivi] archivage impossible:', e);
            Toast.show('Archivage impossible.', 'error');
        }
    },

    /** Recharge les notes sans reconstruire toute la page (filtres conservés) */
    async _recharger() {
        const notes = await API.get(this._urlNotes());
        this._notes = Array.isArray(notes) ? notes : [];
        this._dessiner();
    },

    /* ------------------------------------------------------------------ */
    /* Impression                                                          */
    /* ------------------------------------------------------------------ */

    _selectionPourImpression() {
        const quoi = document.getElementById('suivi-i-quoi').value;
        if (quoi === 'tout') return this._notes.slice();
        if (quoi === 'coche') return this._notes.filter(n => this._coches.has(n.id));
        return this._filtrees();
    },

    _sousTitre(selection) {
        const f = this._filtres;
        const quoi = document.getElementById('suivi-i-quoi').value;
        // « Toutes les notes de l'année » ignore les filtres de l'écran : le sous-titre ne
        // doit donc pas annoncer un élève ou une période que la sélection ne respecte pas.
        if (quoi === 'tout') return `toutes les notes de l'année — ${selection.length} note(s)`;
        const bouts = [];
        if (quoi === 'coche') bouts.push(`sélection de ${selection.length} note(s)`);
        if (f.eleve_id) {
            const e = this._eleves.find(x => String(x.id) === String(f.eleve_id));
            if (e) bouts.push(`${e.prenom || ''} ${e.nom || ''}`.trim());
        }
        if (f.type) bouts.push('type : ' + this._libelleType(f.type));
        if (f.du || f.au) bouts.push(`du ${f.du ? this._dateFr(f.du) : '…'} au ${f.au ? this._dateFr(f.au) : '…'}`);
        if (!bouts.length) bouts.push('toutes les notes de l\'année');
        return bouts.join(' · ') + ` — ${selection.length} note(s)`;
    },

    _docDef() {
        const selection = this._selectionPourImpression();
        const groupe = document.getElementById('suivi-i-groupe').value;
        const court = document.getElementById('suivi-i-opt').value === 'court';
        const sousTitre = this._sousTitre(selection);
        const contenu = [...Print._entetePage('Suivi des élèves', sousTitre)];

        const bloc = (titre, notes) => {
            if (titre) contenu.push({ text: titre, style: 'eleve' });
            for (const n of notes) {
                contenu.push({
                    text: `${this._dateFr(n.date_note)} · ${this._libelleType(n.type)}`,
                    style: 'noteTete',
                });
                if (!court) contenu.push({ text: n.contenu, style: 'noteTexte' });
            }
        };

        if (!selection.length) {
            contenu.push({ text: 'Aucune note à imprimer avec ces critères.', style: 'sousTitre' });
        } else if (groupe === 'eleve') {
            const parEleve = new Map();
            for (const n of selection) {
                const cle = this._nomEleve(n);
                if (!parEleve.has(cle)) parEleve.set(cle, []);
                parEleve.get(cle).push(n);
            }
            for (const [nom, notes] of [...parEleve.entries()].sort((a, b) => a[0].localeCompare(b[0], 'fr'))) {
                bloc(nom, notes.sort((a, b) => (a.date_note || '').localeCompare(b.date_note || '')));
            }
        } else {
            bloc(null, selection.slice().sort((a, b) => (a.date_note || '').localeCompare(b.date_note || '')));
        }

        // Le pied, les styles communs et la page viennent du socle (`Print._docListe`) :
        // tâches et suivi avaient deux copies de ce squelette (dette du 18/10/2026).
        return Print._docListe({
            cle: 'suivi',
            titre: 'Suivi des élèves',
            sousTitre,
            contenu,
            pied: 'Calulis — document de travail, imprimé depuis le suivi des élèves.',
            styles: {
                eleve: { fontSize: 12, bold: true, margin: [0, 8, 0, 4] },
                noteTete: { fontSize: 8.5, color: '#555555', margin: [0, 4, 0, 1] },
                noteTexte: { fontSize: 10, margin: [0, 0, 0, 2] },
            },
        });
    },

    /* ------------------------------------------------------------------ */
    /* Types de notes (décision 6.3)                                       */
    /* ------------------------------------------------------------------ */

    /** Éditeur des types : ajouter, renommer, colorer, désactiver, supprimer. */
    async _ouvrirTypesNotes() {
        const couleurs = [
            { cle: 'observation', libelle: 'Bleu' },
            { cle: 'objectif',    libelle: 'Violet' },
            { cle: 'reussite',    libelle: 'Vert' },
            { cle: 'alerte',      libelle: 'Rouge' },
            { cle: 'action',      libelle: 'Orange' },
            { cle: 'neutre',      libelle: 'Gris' },
        ];
        Modal.open({
            title: 'Types de notes',
            body: `
                <p class="text-muted" style="margin-top:0">
                    Cette liste est propre à votre établissement. Renommer un type change son nom
                    <strong>partout</strong>, y compris sur les notes déjà écrites — aucune note
                    n'est modifiée. Désactiver un type le retire de la saisie sans rendre les notes
                    illisibles. Un type encore utilisé ne peut pas être supprimé : réaffectez d'abord
                    ses notes.
                </p>
                <div id="suivi-types-corps"><p class="text-muted">Chargement…</p></div>
                <div class="form-row" style="margin-top:12px;align-items:flex-end">
                    <div class="form-group" style="flex:1">
                        <label for="suivi-type-nouveau">Ajouter un type</label>
                        <input type="text" id="suivi-type-nouveau" maxlength="120" placeholder="Ex. : Entretien famille">
                    </div>
                    <div class="form-group" style="flex:none">
                        <label for="suivi-type-couleur">Couleur</label>
                        <select id="suivi-type-couleur">
                            ${couleurs.map(c => `<option value="${c.cle}">${c.libelle}</option>`).join('')}
                        </select>
                    </div>
                    <div class="form-group" style="flex:none">
                        <button type="button" class="btn btn-primary" id="suivi-type-ajouter">＋ Ajouter</button>
                    </div>
                </div>`,
            footer: '<button type="button" class="btn btn-secondary" id="suivi-types-fermer">Fermer</button>',
        });

        document.getElementById('suivi-types-fermer').addEventListener('click', async () => {
            // Les libellés ont pu changer : on relit avant de redessiner l'écran.
            try {
                const types = await API.get('types_notes.php');
                if (Array.isArray(types) && types.length) this._types = types;
            } catch { /* on garde la liste en mémoire */ }
            Modal.close();
            this._dessiner();
        });
        document.getElementById('suivi-type-ajouter').addEventListener('click', () =>
            this._ajouterTypeNote().catch(e => console.error('[Suivi] ajout de type :', e)));
        document.getElementById('suivi-type-nouveau').addEventListener('keydown', (ev) => {
            if (ev.key === 'Enter') { ev.preventDefault(); this._ajouterTypeNote().catch(() => {}); }
        });
        document.getElementById('suivi-types-corps').addEventListener('click', (ev) => {
            const bouton = ev.target.closest('button[data-action]');
            if (!bouton) return;
            const id = parseInt(bouton.dataset.id, 10);
            if (bouton.dataset.action === 'enregistrer') {
                this._enregistrerTypeNote(id).catch(e => console.error('[Suivi] renommage :', e));
            }
            if (bouton.dataset.action === 'basculer') {
                this._basculerTypeNote(id).catch(e => console.error('[Suivi] activation :', e));
            }
            if (bouton.dataset.action === 'supprimer') {
                this._supprimerTypeNote(id).catch(e => console.error('[Suivi] suppression :', e));
            }
        });

        await this._chargerTypesNotes();
    },

    async _chargerTypesNotes() {
        const corps = document.getElementById('suivi-types-corps');
        if (!corps) return;
        try {
            const types = await API.get('types_notes.php');
            this._types = Array.isArray(types) ? types : [];
        } catch (e) {
            console.error('[Suivi] types :', e);
            corps.innerHTML = '<p class="text-muted">Impossible de charger les types de notes.</p>';
            return;
        }
        this._dessinerTypesNotes();
    },

    _dessinerTypesNotes() {
        const corps = document.getElementById('suivi-types-corps');
        if (!corps) return;
        const types = this._types || [];
        if (!types.length) {
            corps.innerHTML = '<p class="text-muted">Aucun type : ajoutez-en un ci-dessous.</p>';
            return;
        }
        const couleurs = ['observation', 'objectif', 'reussite', 'alerte', 'action', 'neutre'];
        const nomsCouleurs = { observation: 'Bleu', objectif: 'Violet', reussite: 'Vert', alerte: 'Rouge', action: 'Orange', neutre: 'Gris' };
        const lignes = types.map(t => {
            const n = parseInt(t.nb_notes || 0, 10) || 0;
            return `
            <tr data-id="${t.id}">
                <td>
                    <label class="sr-only" for="suivi-type-libelle-${t.id}">Nom du type</label>
                    <input type="text" id="suivi-type-libelle-${t.id}" data-id="${t.id}"
                           value="${escapeAttr(t.libelle)}" maxlength="120">
                </td>
                <td>
                    <label class="sr-only" for="suivi-type-couleur-${t.id}">Couleur du type</label>
                    <select id="suivi-type-couleur-${t.id}" data-id="${t.id}">
                        ${couleurs.map(c => `<option value="${c}"${String(t.couleur || 'neutre') === c ? ' selected' : ''}>${nomsCouleurs[c]}</option>`).join('')}
                    </select>
                </td>
                <td class="center text-muted" style="font-size:12px">${n ? `${n} note${n > 1 ? 's' : ''}` : '—'}</td>
                <td class="center">${Number(t.actif) ? '<span class="badge">actif</span>' : '<span class="badge badge-status-expired">désactivé</span>'}</td>
                <td style="white-space:nowrap">
                    <button type="button" class="btn btn-sm" data-action="enregistrer" data-id="${t.id}" title="Enregistrer">💾</button>
                    <button type="button" class="btn btn-sm" data-action="basculer" data-id="${t.id}"
                            title="${Number(t.actif) ? 'Ne plus proposer ce type' : 'Reproposer ce type'}">${Number(t.actif) ? '🚫' : '✅'}</button>
                    <button type="button" class="btn btn-sm btn-danger" data-action="supprimer" data-id="${t.id}" title="Supprimer ce type">🗑</button>
                </td>
            </tr>`;
        }).join('');

        corps.innerHTML = `
            <table class="data-table">
                <caption class="sr-only">Types de notes de cet établissement</caption>
                <thead>
                    <tr>
                        <th scope="col">Nom du type</th>
                        <th scope="col">Couleur</th>
                        <th scope="col">Utilisé par</th>
                        <th scope="col">État</th>
                        <th scope="col">Actions</th>
                    </tr>
                </thead>
                <tbody>${lignes}</tbody>
            </table>`;
    },

    async _ajouterTypeNote() {
        const champ = document.getElementById('suivi-type-nouveau');
        const libelle = (champ ? champ.value : '').trim();
        const couleur = document.getElementById('suivi-type-couleur')?.value || 'neutre';
        if (!libelle) {
            Toast.info('Donnez un nom au type de note.');
            if (champ) champ.focus();
            return;
        }
        try {
            await API.post('types_notes.php', { libelle, couleur });
        } catch (e) {
            Toast.error(e.message || 'Ajout impossible.');
            return;
        }
        if (champ) champ.value = '';
        Toast.success(`Type « ${libelle} » ajouté.`);
        await this._chargerTypesNotes();
    },

    async _enregistrerTypeNote(id) {
        const champ = document.getElementById('suivi-type-libelle-' + id);
        const libelle = (champ ? champ.value : '').trim();
        const couleur = document.getElementById('suivi-type-couleur-' + id)?.value || 'neutre';
        if (!libelle) {
            Toast.info('Le nom du type est obligatoire.');
            return;
        }
        try {
            await API.put('types_notes.php?id=' + id, { libelle, couleur });
        } catch (e) {
            Toast.error(e.message || 'Enregistrement impossible.');
            return;
        }
        Toast.success('Type enregistré. Les notes déjà écrites suivent.');
        await this._chargerTypesNotes();
    },

    async _basculerTypeNote(id) {
        const type = (this._types || []).find(t => parseInt(t.id, 10) === id);
        if (!type) return;
        const actif = Number(type.actif) ? 0 : 1;
        try {
            await API.put('types_notes.php?id=' + id, { actif });
        } catch (e) {
            Toast.error(e.message || 'Modification impossible.');
            return;
        }
        Toast.success(actif ? 'Type réactivé.' : 'Type désactivé : plus proposé, toujours lisible.');
        await this._chargerTypesNotes();
    },

    /** Suppression : refusée si le type porte des notes, avec réaffectation proposée. */
    async _supprimerTypeNote(id) {
        const type = (this._types || []).find(t => parseInt(t.id, 10) === id);
        if (!type) return;
        const n = parseInt(type.nb_notes || 0, 10) || 0;
        if (n > 0) {
            const autres = (this._types || []).filter(t => parseInt(t.id, 10) !== id);
            if (!autres.length) {
                Modal.alert('Suppression impossible',
                    'Ce type est utilisé et c\'est le seul : désactivez-le, ou créez d\'abord un autre type.');
                return;
            }
            const cible = await this._choisirTypeReprise(type, autres, n);
            if (!cible) return;
            try {
                const r = await API.post(
                    'types_notes.php?id=' + id + '&reaffecter=' + encodeURIComponent(cible), {});
                Toast.success(`${(r && r.notes_reaffectees) || n} note(s) réaffectée(s), type supprimé.`);
            } catch (e) {
                Toast.error(e.message || 'Réaffectation impossible.');
                return;
            }
        } else {
            const ok = await Modal.confirm('Supprimer ce type de note',
                `Supprimer « ${escapeHtml(type.libelle)} » ? Aucune note ne l'utilise.`,
                { okLabel: 'Supprimer' });
            if (!ok) return;
            try {
                await API.del('types_notes.php?id=' + id);
            } catch (e) {
                Toast.error(e.message || 'Suppression impossible.');
                return;
            }
            Toast.success('Type supprimé.');
        }
        await this._chargerTypesNotes();
    },

    /** Choix du type de reprise d'une suppression refusée. Rend la clé, ou null. */
    _choisirTypeReprise(type, autres, n) {
        return new Promise(resolve => {
            Modal.open({
                title: 'Supprimer ce type de note',
                body: `
                    <p>« <strong>${escapeHtml(type.libelle)}</strong> » est utilisé par
                        <strong>${n} note${n > 1 ? 's' : ''}</strong> : il ne peut pas être supprimé tel quel.</p>
                    <p>Réaffectez ces notes à un autre type, puis le type sera supprimé. Vous pouvez aussi
                        simplement le <strong>désactiver</strong> : il ne sera plus proposé, et les notes
                        déjà écrites resteront lisibles.</p>
                    <div class="form-group">
                        <label for="suivi-type-reaffecter">Réaffecter ses notes à</label>
                        <select id="suivi-type-reaffecter">
                            ${autres.map(t => `<option value="${escapeAttr(t.cle)}">${escapeHtml(t.libelle)}</option>`).join('')}
                        </select>
                    </div>`,
                footer: `
                    <button type="button" class="btn btn-secondary" id="suivi-reaff-annuler">Annuler</button>
                    <button type="button" class="btn btn-danger" id="suivi-reaff-ok">Réaffecter puis supprimer</button>`,
                onClose: () => resolve(null),
            });
            document.getElementById('suivi-reaff-annuler').addEventListener('click', () => {
                Modal._onClose = null;
                Modal.close();
                resolve(null);
            });
            document.getElementById('suivi-reaff-ok').addEventListener('click', () => {
                const cible = document.getElementById('suivi-type-reaffecter').value;
                Modal._onClose = null;
                Modal.close();
                resolve(cible);
            });
        });
    },

    _imprimer(apercuSeul) {
        Print._imprimerListe(apercuSeul, {
            cle: 'suivi',
            selection: this._selectionPourImpression(),
            messageVide: 'Rien à imprimer : aucune note ne correspond.',
            docDef: () => this._docDef(),
        });
    },
};