/* Calulis — utils/actions.js — la protection contre le double clic.
 *
 * POURQUOI (11/10/2026). Un bouton « Enregistrer » reste actif pendant que la demande part :
 * un second clic envoyait donc une SECONDE demande, et l'API créait deux fois la même ligne.
 * Mesuré au socle d'intégration : deux envois identiques font deux tâches (l'API ne dédouble
 * pas — ce n'est pas son rôle).
 *
 * `Action.uneSeule(bouton, action)` neutralise le bouton le temps de l'action :
 *   - le bouton est DÉSACTIVÉ : il devient visiblement inactif pendant l'enregistrement ;
 *   - un clic qui arrive pendant ce temps ne fait RIEN (il n'est pas mis en file : un clic
 *     de trop ne doit pas créer un second enregistrement plus tard) ;
 *   - le bouton retrouve son état précédent quoi qu'il arrive, succès comme erreur.
 *
 * L'action est rendue telle quelle : l'appelant garde son `try/catch` et ses messages.
 */
const Action = {
    uneSeule(bouton, action) {
        if (!bouton) return Promise.resolve(action());
        if (bouton.dataset.actionEnCours === '1') return Promise.resolve(null);
        bouton.dataset.actionEnCours = '1';
        const etaitDesactive = bouton.disabled;
        bouton.disabled = true;
        return Promise.resolve()
            .then(() => action())
            .finally(() => {
                bouton.dataset.actionEnCours = '0';
                bouton.disabled = etaitDesactive;
            });
    },
};
