-- Migration 028 : les PROJETS (ce que l'eleve a fait pendant sa scolarite)
--
-- Pourquoi. Un projet (chorale de l'ecole, piece de theatre, cross du college, Printemps
-- des poetes, Semaine de la science...) se decrit UNE fois, puis on coche qui y a
-- participe. Le but n'est pas de tenir une fiche de projet : c'est la MEMOIRE de ce que
-- l'eleve a fait, qu'on doit pouvoir relire des annees plus tard, sur sa fiche.
--
-- Ce qui est cree ici
--   projets          nom, type (texte libre), dates, description, obligatoire, evenement
--   projet_classes   le projet et les classes qui y ont participe (plusieurs possibles)
--   projet_adultes   le projet et les adultes (enseignant, intervenant...), role facultatif
--   eleve_projets    la PARTICIPATION : la seule chose que la fiche de l'eleve ajoute
--
-- Aucune annee scolaire n'est stockee : ce sont les DATES qui decident. Un projet qui va
-- de mai a octobre apparait dans les deux annees qu'il chevauche, sans rien a cocher.
-- Le rattachement a un evenement est FACULTATIF : s'il disparait, le projet reste.
--
-- ATTENTION : le lanceur de migrations decoupe le fichier sur chaque point-virgule, y
-- compris dans les commentaires : ne jamais mettre de point-virgule ailleurs qu'en fin
-- d'instruction.

CREATE TABLE IF NOT EXISTS projets (
  id INT NOT NULL AUTO_INCREMENT,
  nom VARCHAR(200) NOT NULL,
  type VARCHAR(80) DEFAULT NULL COMMENT 'Texte libre (culturel, sportif, institutionnel...) : autocompletion a la saisie',
  date_debut DATE DEFAULT NULL,
  date_fin DATE DEFAULT NULL,
  description TEXT DEFAULT NULL,
  est_obligatoire TINYINT(1) NOT NULL DEFAULT 0,
  evenement_id INT DEFAULT NULL COMMENT 'Rattachement facultatif a un evenement de l annee',
  created_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY pj_dates (date_debut, date_fin),
  KEY pj_type (type),
  KEY pj_evenement (evenement_id),
  CONSTRAINT pj_evenement_fk FOREIGN KEY (evenement_id) REFERENCES evenements(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS projet_classes (
  projet_id INT NOT NULL,
  classe_id INT NOT NULL,
  PRIMARY KEY (projet_id, classe_id),
  KEY pjc_classe (classe_id),
  CONSTRAINT pjc_projet_fk FOREIGN KEY (projet_id) REFERENCES projets(id) ON DELETE CASCADE,
  CONSTRAINT pjc_classe_fk FOREIGN KEY (classe_id) REFERENCES classes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS projet_adultes (
  projet_id INT NOT NULL,
  adulte_id INT NOT NULL,
  role VARCHAR(60) DEFAULT NULL COMMENT 'Enseignant, intervenant, AESH... : facultatif',
  PRIMARY KEY (projet_id, adulte_id),
  KEY pja_adulte (adulte_id),
  CONSTRAINT pja_projet_fk FOREIGN KEY (projet_id) REFERENCES projets(id) ON DELETE CASCADE,
  CONSTRAINT pja_adulte_fk FOREIGN KEY (adulte_id) REFERENCES adultes(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS eleve_projets (
  eleve_id INT NOT NULL,
  projet_id INT NOT NULL,
  PRIMARY KEY (eleve_id, projet_id),
  KEY epj_projet (projet_id),
  CONSTRAINT epj_eleve_fk FOREIGN KEY (eleve_id) REFERENCES eleves(id) ON DELETE CASCADE,
  CONSTRAINT epj_projet_fk FOREIGN KEY (projet_id) REFERENCES projets(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
