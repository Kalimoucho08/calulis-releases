-- Migration 027 : une occurrence de tache supprimee ne revient plus (R12)
--
-- Pourquoi. Une tache recurrente refabrique ses occurrences dues a partir de la derniere
-- qu'elle connait. Supprimer celle du jour disait donc « pas cette fois » — et elle
-- revenait a la lecture suivante : le geste ne produisait aucun effet visible.
--
-- Ce que fait cette migration : une petite table qui retient les dates SUPPRIMEES d'une
-- serie. La generation les saute (Tache::genererSuivantes). Rien d'existant n'est
-- modifie, aucune ligne n'est supprimee : la table nait vide, et la regle s'applique aux
-- suppressions suivantes.
--
-- Deux gestes distincts cote ecran : supprimer CE JOUR (la date est notee ici, les autres
-- dates continuent) ou ARRETER LA RECURRENCE (la serie perd sa regle, les occurrences a
-- venir disparaissent, l'historique reste).
--
-- Rejouable sans effet (CREATE TABLE IF NOT EXISTS, unicite serie+date).
--
-- ATTENTION : le lanceur de migrations decoupe le fichier sur chaque point-virgule, y
-- compris dans les commentaires — ne jamais en mettre ailleurs qu'en fin d'instruction.

CREATE TABLE IF NOT EXISTS taches_occurrences_supprimees (
  id int(11) NOT NULL AUTO_INCREMENT,
  serie_id int(11) NOT NULL,
  echeance date NOT NULL,
  supprime_le timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (id),
  UNIQUE KEY uk_serie_echeance (serie_id, echeance)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
