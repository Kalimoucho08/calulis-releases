-- Migration 029 : le lot 9 « hors ecole » — relier une PEC a SON creneau
--
-- Pourquoi. Une prise en charge (PEC) decrit une specialite, un organisme, une frequence...
-- mais elle ne dit PAS quand elle a lieu : ni jour, ni heure. L'emploi du temps, lui, a des
-- creneaux — et rien ne les reliait. Impossible, donc, de dire sur une case « hors ecole »
-- sans deviner de quelle PEC il s'agit. C'est cette lacune que la migration referme.
--
-- Ce qui est ajoute
--   pec_eleves.jour          le jour du creneau de la PEC (lundi...dimanche)
--   pec_eleves.heure_debut   l'heure de debut de ce creneau
--
-- Pourquoi un JOUR et une HEURE, et non un identifiant de creneau. Les lignes de
-- « creneaux » sont des SEMAINES (36 par eleve et par an) : un identifiant ne marquerait
-- qu'une seule semaine, alors qu'une PEC revient chaque semaine. Le couple (jour, heure)
-- est la case hebdomadaire — celle que l'on peint sur la grille et sur le papier.
--
-- Pourquoi aucune cle etrangere. Il n'y a pas de ligne a referencer. Si le creneau est
-- supprime ou deplace, la case ne correspond plus a rien : la PEC reste, la marque
-- disparait d'elle-meme. Rien a nettoyer, rien a casser.
--
-- ATTENTION : le lanceur de migrations decoupe le fichier sur chaque point-virgule, y
-- compris dans les commentaires : ne jamais mettre de point-virgule ailleurs qu'en fin
-- d'instruction.


-- Chaque instruction est gardee : une migration interrompue puis relancee doit passer sans
-- erreur (regle du projet, verifiee par tests/verif-migration-interrompue.sh).

-- pec_eleves.jour
SET @col_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pec_eleves' AND COLUMN_NAME = 'jour');
SET @sql = IF(@col_exists = 0, 'ALTER TABLE pec_eleves ADD COLUMN jour VARCHAR(10) DEFAULT NULL COMMENT ''Jour du creneau de la PEC (NULL = non reliee)'' AFTER lieu', 'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- pec_eleves.heure_debut
SET @col_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS
                   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pec_eleves' AND COLUMN_NAME = 'heure_debut');
SET @sql = IF(@col_exists = 0, 'ALTER TABLE pec_eleves ADD COLUMN heure_debut TIME DEFAULT NULL COMMENT ''Heure de debut du creneau de la PEC (NULL = non reliee)'' AFTER jour', 'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

-- l'index qui rend la recherche des marques supportable
SET @idx_exists = (SELECT COUNT(*) FROM information_schema.STATISTICS
                   WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'pec_eleves' AND INDEX_NAME = 'idx_pec_eleve_jour');
SET @sql = IF(@idx_exists = 0, 'CREATE INDEX idx_pec_eleve_jour ON pec_eleves (eleve_id, jour, heure_debut)', 'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
