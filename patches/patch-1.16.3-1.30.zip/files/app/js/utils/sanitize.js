/**
 * Calulis — Utilitaires sanitization + sélecteurs DOM
 */
function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str || '';
    return div.innerHTML;
}

/**
 * Échappement pour un CONTEXTE D'ATTRIBUT (value="…", aria-label="…", title="…").
 * `escapeHtml` passe par textContent → innerHTML : il échappe < > & mais PAS les guillemets.
 * Mesuré le 04/10/2026 : escapeHtml('a"b') === 'a"b' — dans un attribut, le guillemet ferme
 * la valeur et la suite devient du balisage. Ne jamais utiliser escapeHtml dans un attribut.
 */

/**
 * Un adulte porte-t-il le rôle « Enseignant référent » (ERSEH) ?
 *
 * L'enseignant référent n'est PAS l'enseignant de la classe de référence : c'est celui qui
 * suit le projet personnalisé de scolarisation (PPS), réunit et anime l'équipe de suivi de
 * la scolarisation (l'ESS), et fait le lien entre la famille, l'école et l'équipe
 * pluridisciplinaire de la MDPH. Le rôle vit dans `adultes_roles` (libellé « Enseignant
 * référent »), la colonne `role` ne portant que le métier.
 *
 * Une seule définition, utilisée par la fiche élève (qui le désigne) et par le GEVA-Sco
 * (qui l'imprime) : deux copies finiraient par diverger.
 */
function estEnseignantReferent(adulte) {
    if (!adulte) return false;
    const roles = Array.isArray(adulte.roles) ? adulte.roles.slice() : String(adulte.roles || '').split(',');
    roles.push(adulte.role || '');
    return roles.some(function (r) {
        const t = String(r).trim();
        return t === 'enseignant_referent' || /^enseignant\s*r[ée]f[ée]rent/i.test(t);
    });
}
function escapeAttr(str) {
    return String(str == null ? '' : str)
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#39;');
}

function $(selector, parent = document) {
    return parent.querySelector(selector);
}

function $$(selector, parent = document) {
    return Array.from(parent.querySelectorAll(selector));
}
