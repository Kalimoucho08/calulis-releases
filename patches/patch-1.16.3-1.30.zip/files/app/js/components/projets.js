/**
 * Calulis — Écran « Projets » (lot 4 de la 1.30)
 *
 * Un projet n'est pas une fiche à tenir : c'est la MÉMOIRE de ce que les élèves ont fait
 * (chorale, théâtre, cross, Printemps des poètes…). Il se décrit UNE fois ici — nom, type,
 * dates, classes, adultes — puis on coche qui y a participé. La fiche de l'élève ne fait
 * qu'ajouter la participation (`fiche-eleve-projets.js`).
 *
 * L'ANNÉE VIENT DES DATES : il n'y a pas de sélecteur d'année propre à cet écran, la liste
 * suit l'année choisie en haut de l'application, et un projet à cheval sur deux années
 * apparaît dans les deux.
 */
const ProjetsView = {
    _projets: [],
    _classes: [],
    _adultes: [],
    _eleves: [],
    _filtre: '',
    _typesConnus: [],

    async render() {
        const view = document.getElementById('view-projets');
        if (!view) return;
        view.innerHTML = `
            <div class="toolbar">
                <button class="btn btn-primary" id="btn-nouveau-projet"
                        data-help="Nouveau projet|Décrivez le projet une seule fois : son nom, son type (culturel, sportif, institutionnel…), ses dates, les classes et les adultes concernés. Ensuite, sur la fiche d'un élève, vous ne ferez que cocher sa participation.">+ Nouveau projet</button>
                <input type="search" id="projets-recherche" placeholder="Rechercher un projet…"
                       aria-label="Rechercher un projet" style="max-width:280px">
                <span class="text-muted" id="projets-compte" style="font-size:12px"></span>
                <span style="margin-left:auto;display:flex;gap:8px;align-items:center">
                    <button class="btn btn-secondary" id="btn-imprimer-projets"
                            data-help="Imprimer la liste|Imprime les projets AFFICHÉS, avec leur type, leurs dates, les classes concernées et le nombre d'élèves. La recherche en cours s'applique : ce qui est à l'écran est ce qui s'imprime. Le PDF s'ouvre en aperçu, puis « Télécharger le PDF ».">🖨️ Imprimer la liste</button>
                </span>
            </div>
            <div class="card" style="flex:1;overflow:auto;padding:0">
                <table class="data-table" id="table-projets">
                    <thead><tr>
                        <th data-sort="nom" class="sortable">Projet</th>
                        <th style="width:130px">Type</th>
                        <th style="width:180px">Classes</th>
                        <th style="width:190px">Dates</th>
                        <th style="width:80px">Élèves</th>
                        <th style="width:150px">Actions</th>
                    </tr></thead>
                    <tbody id="projets-corps"></tbody>
                </table>
            </div>`;
        document.getElementById('btn-nouveau-projet').addEventListener('click', () => this.ouvrir(null));
        document.getElementById('btn-imprimer-projets').addEventListener('click', () => this._imprimer(false));
        const recherche = document.getElementById('projets-recherche');
        recherche.addEventListener('input', () => {
            this._filtre = recherche.value;
            this._afficher();
        });
        await this.charger();
    },

    async charger() {
        const annee = State.get('annee_scolaire_id') || '';
        try {
            this._projets = await API.get('projets.php?annee_scolaire_id=' + encodeURIComponent(annee)) || [];
            this._typesConnus = await API.get('projets.php?types=1') || [];
        } catch (e) {
            this._projets = [];
            this._typesConnus = [];
        }
        this._afficher();
    },

    /**
     * Les projets RÉELLEMENT affichés : la recherche en cours s'applique. L'écran et
     * l'impression lisent la même fonction, donc on n'imprime jamais autre chose que ce
     * qu'on voit (défaut payé sur les tâches : la liste imprimée ignorait le filtre).
     */
    _listeAffichee() {
        const f = (this._filtre || '').trim().toLowerCase();
        return this._projets.filter(p => !f
            || String(p.nom || '').toLowerCase().includes(f)
            || String(p.type || '').toLowerCase().includes(f)
            || String(p.classes_noms || '').toLowerCase().includes(f));
    },

    _afficher() {
        const corps = document.getElementById('projets-corps');
        if (!corps) return;
        const liste = this._listeAffichee();
        const compte = document.getElementById('projets-compte');
        if (compte) {
            compte.textContent = liste.length + (liste.length > 1 ? ' projets' : ' projet')
                + (this._projets.length !== liste.length ? ' sur ' + this._projets.length : '');
        }
        if (!liste.length) {
            corps.innerHTML = '<tr><td colspan="6" class="empty">'
                + (this._projets.length
                    ? 'Aucun projet ne correspond à la recherche.'
                    : 'Aucun projet pour cette année. « + Nouveau projet » décrit une chorale, un cross, une pièce de théâtre… puis vous cocherez les élèves qui y ont participé.')
                + '</td></tr>';
            return;
        }
        corps.innerHTML = liste.map(p => {
            const classes = p.classes_noms ? escapeHtml(p.classes_noms) : '<span class="text-muted">—</span>';
            const type = p.type ? '<span class="etiquette">' + escapeHtml(p.type) + '</span>' : '<span class="text-muted">—</span>';
            const evenement = p.evenement_nom
                ? '<div class="text-muted" style="font-size:11px">📆 ' + escapeHtml(p.evenement_nom) + '</div>' : '';
            const obligatoire = Number(p.est_obligatoire) ? ' <span class="etiquette etiquette-neutre">obligatoire</span>' : '';
            return '<tr data-id="' + p.id + '">'
                + '<td><strong>' + escapeHtml(p.nom) + '</strong>' + obligatoire
                + (p.description ? '<div class="text-muted" style="font-size:12px">' + escapeHtml(p.description) + '</div>' : '')
                + evenement + '</td>'
                + '<td>' + type + '</td>'
                + '<td>' + classes + '</td>'
                + '<td>' + escapeHtml(datesLisibles(p.date_debut, p.date_fin)) + '</td>'
                + '<td>' + (Number(p.nb_eleves) || 0) + '</td>'
                + '<td>'
                + '<button class="btn-sm btn-edit" data-action="modifier" data-id="' + p.id + '" title="Ouvrir ce projet">✏️</button> '
                + '<button class="btn-sm btn-del" data-action="supprimer" data-id="' + p.id + '" title="Supprimer ce projet">✕</button>'
                + '</td></tr>';
        }).join('');
        corps.querySelectorAll('button[data-action]').forEach(btn => {
            btn.addEventListener('click', (ev) => {
                ev.stopPropagation();
                const id = Number(btn.dataset.id);
                if (btn.dataset.action === 'modifier') this.ouvrir(id);
                else this.supprimer(id);
            });
        });
        corps.querySelectorAll('tr[data-id]').forEach(tr => {
            tr.addEventListener('click', () => this.ouvrir(Number(tr.dataset.id)));
        });
    },

    /** Ouvre la fiche du projet (id null = création). */
    async ouvrir(id) {
        await this._chargerChoix();
        let p = { nom: '', type: '', date_debut: '', date_fin: '', description: '', est_obligatoire: 0,
                  evenement_id: '', classes: [], adultes: [], eleves: [] };
        if (id) {
            try {
                const trouve = await API.get('projets.php?id=' + id);
                if (trouve && trouve.id) p = Object.assign(p, trouve);
            } catch (e) {
                Toast.error('Ce projet n\'a pas pu être ouvert.');
                return;
            }
        }
        const classesCochees = (p.classes || []).map(c => Number(c.id));
        const elevesCoches = (p.eleves || []).map(e => Number(e.id));
        const corps = `
            <div class="form-row">
                <div class="form-group" style="flex:2">
                    <label for="pj-nom">Nom du projet *</label>
                    <input type="text" id="pj-nom" maxlength="200" value="${escapeAttr(p.nom || '')}"
                           placeholder="Chorale de l'école, cross du collège, Printemps des poètes…">
                </div>
                <div class="form-group">
                    <label for="pj-type">Type</label>
                    <input type="text" id="pj-type" maxlength="80" list="pj-types" value="${escapeAttr(p.type || '')}"
                           placeholder="Culturel, sportif…">
                    <datalist id="pj-types">${(this._typesConnus || []).map(t => '<option value="' + escapeAttr(t) + '"></option>').join('')}</datalist>
                </div>
                <div class="form-group" style="flex:0 0 170px">
                    <label for="pj-evenement">Événement <span class="text-muted">(facultatif)</span></label>
                    <select id="pj-evenement">
                        <option value="">— Aucun —</option>
                        ${(this._evenements || []).map(ev => '<option value="' + ev.id + '"' + (Number(p.evenement_id) === Number(ev.id) ? ' selected' : '') + '>' + escapeHtml(ev.nom) + '</option>').join('')}
                    </select>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group"><label for="pj-debut">Début</label>
                    <input type="date" id="pj-debut" value="${escapeAttr(p.date_debut || '')}"></div>
                <div class="form-group"><label for="pj-fin">Fin</label>
                    <input type="date" id="pj-fin" value="${escapeAttr(p.date_fin || '')}"></div>
                <div class="form-group" style="flex:0 0 200px;align-self:center">
                    <label style="display:flex;align-items:center;gap:6px;cursor:pointer">
                        <input type="checkbox" id="pj-obligatoire" ${Number(p.est_obligatoire) ? 'checked' : ''}>
                        Projet obligatoire
                    </label>
                </div>
            </div>
            <div class="form-group">
                <label for="pj-description">Description</label>
                <textarea id="pj-description" rows="2" placeholder="Ce qu'on doit se rappeler du projet…">${escapeHtml(p.description || '')}</textarea>
            </div>
            <div class="form-row" style="align-items:flex-start">
                <div class="form-group" style="flex:1">
                    <label>Classes concernées</label>
                    <div class="liste-cases" data-liste="classes">
                        ${(this._classes || []).map(c => '<label class="case"><input type="checkbox" value="' + c.id + '"'
                            + (classesCochees.includes(Number(c.id)) ? ' checked' : '') + '> ' + escapeHtml(c.nom) + '</label>').join('')
                            || '<span class="text-muted">Aucune classe enregistrée.</span>'}
                    </div>
                </div>
                <div class="form-group" style="flex:1">
                    <label>Adultes du projet</label>
                    <div class="liste-cases" data-liste="adultes">
                        ${(this._adultes || []).map(a => '<label class="case"><input type="checkbox" value="' + a.id + '"'
                            + ((p.adultes || []).some(x => Number(x.id) === Number(a.id)) ? ' checked' : '') + '> '
                            + escapeHtml((a.prenom || '') + ' ' + (a.nom || '')) + '</label>').join('')}
                    </div>
                </div>
            </div>
            <div class="form-group">
                <label for="pj-filtre-eleves">Élèves qui y ont participé</label>
                <input type="search" id="pj-filtre-eleves" placeholder="Filtrer les élèves…" style="max-width:280px">
                <div class="liste-cases liste-eleves" data-liste="eleves">
                    ${(this._eleves || []).map(e => '<label class="case"><input type="checkbox" value="' + e.id + '"'
                        + (elevesCoches.includes(Number(e.id)) ? ' checked' : '') + '> '
                        + escapeHtml((e.nom || '') + ' ' + (e.prenom || '')) + '</label>').join('')}
                </div>
            </div>`;
        Modal.open({
            title: id ? 'Projet — ' + (p.nom || '') : 'Nouveau projet',
            body: corps,
            footer: '<button class="btn btn-secondary" id="pj-annuler">Annuler</button>'
                + '<button class="btn btn-primary" id="pj-enregistrer">Enregistrer</button>',
        });
        document.getElementById('pj-annuler').addEventListener('click', () => Modal.close());
        const filtre = document.getElementById('pj-filtre-eleves');
        if (filtre) {
            filtre.addEventListener('input', () => {
                const f = filtre.value.trim().toLowerCase();
                document.querySelectorAll('.liste-eleves .case').forEach(lab => {
                    lab.style.display = !f || lab.textContent.toLowerCase().includes(f) ? '' : 'none';
                });
            });
        }
        const boutonEnregistrer = document.getElementById('pj-enregistrer');
        boutonEnregistrer.addEventListener('click', () => Action.uneSeule(boutonEnregistrer, () => this.enregistrer(id)));
    },

    async _chargerChoix() {
        if (this._classes.length && this._adultes.length && this._eleves.length) return;
        const lire = async (url, defaut) => { try { return await API.get(url) || defaut; } catch (e) { return defaut; } };
        const annee = State.get('annee_scolaire_id') || '';
        const [classes, adultes, eleves, evenements] = await Promise.all([
            lire('classes.php', []),
            lire('adultes.php', []),
            lire('eleves.php' + (annee ? '?annee_scolaire_id=' + encodeURIComponent(annee) : ''), []),
            lire('evenements.php' + (annee ? '?annee_scolaire_id=' + encodeURIComponent(annee) : ''), []),
        ]);
        this._classes = Array.isArray(classes) ? classes : [];
        this._adultes = Array.isArray(adultes) ? adultes : [];
        this._eleves = Array.isArray(eleves) ? eleves : [];
        this._evenements = Array.isArray(evenements) ? evenements : [];
    },

    _coches(liste) {
        const zone = document.querySelector('[data-liste="' + liste + '"]');
        if (!zone) return [];
        return Array.from(zone.querySelectorAll('input[type=checkbox]:checked')).map(i => Number(i.value));
    },

    async enregistrer(id) {
        const nom = (document.getElementById('pj-nom').value || '').trim();
        if (!nom) {
            Toast.warning('Donnez un nom au projet.');
            document.getElementById('pj-nom').focus();
            return;
        }
        const corps = {
            nom: nom,
            type: (document.getElementById('pj-type').value || '').trim(),
            date_debut: document.getElementById('pj-debut').value || '',
            date_fin: document.getElementById('pj-fin').value || '',
            description: document.getElementById('pj-description').value || '',
            est_obligatoire: document.getElementById('pj-obligatoire').checked ? 1 : 0,
            evenement_id: document.getElementById('pj-evenement').value || null,
            classes: this._coches('classes'),
            adultes: this._coches('adultes'),
            eleves: this._coches('eleves'),
        };
        try {
            if (id) await API.put('projets.php?id=' + id, corps);
            else await API.post('projets.php', corps);
            Modal.close();
            await this.charger();
            Toast.success(id ? 'Projet mis à jour.' : 'Projet créé.');
        } catch (e) {
            Toast.error(e && e.message ? e.message : 'Le projet n\'a pas pu être enregistré.');
        }
    },

    /** Le nom de l'année choisie, pour le sous-titre du document (« 2026-2027 »). */
    _nomAnnee() {
        const anneeId = String(State.get('annee_scolaire_id') || '');
        const an = (State.get('annees') || []).find(a => String(a.id) === anneeId);
        return an && an.nom ? String(an.nom) : '';
    },

    /**
     * Le document imprimé : la liste des projets AFFICHÉS, en tableau (une ligne par projet).
     * Le pied, les marges et la page viennent du socle (Print._docListe), comme les tâches
     * et les notes de suivi — un seul squelette à corriger.
     */
    _docDefProjets() {
        const liste = this._listeAffichee();
        const bouts = [];
        const annee = this._nomAnnee();
        if (annee) bouts.push('Année ' + annee);
        if ((this._filtre || '').trim()) bouts.push('recherche « ' + this._filtre.trim() + ' »');
        bouts.push(liste.length + (liste.length > 1 ? ' projets' : ' projet'));
        const sousTitre = bouts.join(' · ');
        const contenu = [...Print._entetePage('Projets', sousTitre)];

        if (!liste.length) {
            contenu.push({ text: 'Aucun projet à imprimer avec ces critères.', style: 'subheader' });
        } else {
            const corps = [[
                { text: 'Projet', style: 'thProjet' },
                { text: 'Type', style: 'th' },
                { text: 'Dates', style: 'th' },
                { text: 'Classes', style: 'th' },
                { text: 'Élèves', style: 'th' },
            ]];
            liste.forEach(p => corps.push([
                { text: String(p.nom || '') + (Number(p.est_obligatoire) ? ' (obligatoire)' : ''), style: 'projetNom' },
                { text: p.type || '—', style: 'cellule' },
                { text: datesLisibles(p.date_debut, p.date_fin), style: 'cellule' },
                { text: p.classes_noms || '—', style: 'cellule' },
                { text: String(Number(p.nb_eleves) || 0), style: 'cellule', alignment: 'center' },
            ]));
            contenu.push({ table: { headerRows: 1, widths: ['*', 70, 85, 95, 35], body: corps }, fontSize: 8.5 });
        }

        return Print._docListe({
            cle: 'projets',
            titre: 'Projets',
            sousTitre,
            contenu,
            pied: "Calulis — la mémoire des projets de l'année, imprimée depuis l'écran « Projets ».",
            styles: {
                th: { fontSize: 8, bold: true, fillColor: '#eeeeee', alignment: 'center' },
                thProjet: { fontSize: 8, bold: true, fillColor: '#eeeeee' },
                projetNom: { fontSize: 9, bold: true },
                cellule: { fontSize: 8.5 },
            },
        });
    },

    _imprimer(apercuSeul) {
        Print._imprimerListe(apercuSeul, {
            cle: 'projets',
            selection: this._listeAffichee(),
            messageVide: 'Rien à imprimer : aucun projet ne correspond à la recherche.',
            docDef: () => this._docDefProjets(),
        });
    },

    async supprimer(id) {
        const p = this._projets.find(x => Number(x.id) === Number(id));
        const nom = p ? p.nom : 'ce projet';
        const nb = p ? Number(p.nb_eleves) || 0 : 0;
        const suite = nb
            ? ' ' + nb + ' élève(s) ne l\'auront plus sur leur fiche.'
            : '';
        if (!await Modal.confirm('Supprimer le projet', 'Supprimer « ' + nom + ' » ?' + suite)) return;
        try {
            await API.del('projets.php?id=' + id);
            await this.charger();
            Toast.success('Projet supprimé.');
        } catch (e) {
            Toast.error('Le projet n\'a pas pu être supprimé.');
        }
    },
};

/** « 05/11/2026 → 12/06/2027 », ou « 05/11/2026 » quand il n'y a qu'une date. */
function datesLisibles(debut, fin) {
    const f = (d) => {
        if (!d) return '';
        const [a, m, j] = String(d).split('-');
        return j && m && a ? j + '/' + m + '/' + a : String(d);
    };
    const d = f(debut), e = f(fin);
    if (d && e && d !== e) return d + ' → ' + e;
    return d || e || '—';
}
