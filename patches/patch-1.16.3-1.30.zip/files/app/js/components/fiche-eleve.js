/**
 * Calulis — Composant Fiche Élève (formulaire à onglets)
 */
const FicheEleve = {
    _eleve: null,
    _isNew: false,
    _readonly: false,

    /* ---- Helpers (partagés avec les sous-fichiers via Object.assign) ---- */

    /** Helper input texte */
    _f(name, val = '') {
        const e = this._eleve;
        const ro = this._readonly ? 'disabled' : '';
        return `<input type="text" id="f-${name}" value="${escapeHtml(val || e[name] || '')}" ${maxLenAttr(name)} ${ro}>`;
    },

    /** Helper input date */
    _d(name, val = '') {
        const e = this._eleve;
        const ro = this._readonly ? 'disabled' : '';
        return `<input type="date" id="f-${name}" value="${escapeHtml(val || e[name] || '')}" ${ro}>`;
    },

    /** Helper select */
    _s(name, options) {
        const e = this._eleve;
        const ro = this._readonly ? 'disabled' : '';
        const opts = options.map(o => `<option value="${o}" ${e[name] === o ? 'selected' : ''}>${o}</option>`).join('');
        return `<select id="f-${name}" ${ro}><option value="">—</option>${opts}</select>`;
    },

    /** Sanitize URL: bloque javascript:, data:, vbscript: */
    _safeUrl(url) {
        if (!url) return '';
        const u = url.trim().toLowerCase();
        if (/^(javascript|data|vbscript|jar):/.test(u)) return '#';
        return url;
    },

    /** Ouvre la fiche (création si data est vide, édition sinon, readonly si demandé) */
    open(data = {}, readonly = false) {
        this._isNew = !data || !data.id;
        this._eleve = this._isNew ? {} : { ...data };
        this._readonly = readonly;

        Modal.open({
            title: this._isNew ? 'Nouvel élève' : (readonly ? 'Fiche : ' : 'Modifier : ') + (data.prenom || '') + ' ' + (data.nom || ''),
            body: this._buildHTML(),
            footer: readonly ? '<button class="btn btn-secondary" onclick="Modal.close()">Fermer</button>' :
                `<button class="btn btn-secondary" onclick="Modal.close()">Annuler</button>
                 <button class="btn btn-primary" id="btn-save-eleve">Enregistrer</button>`,
        });

        // Tabs (toujours actifs, y compris en lecture seule)
        document.querySelectorAll('#modal .tab').forEach(tab => {
            tab.addEventListener('click', () => this._switchTab(tab.dataset.tab));
        });

        if (!readonly) {
            // Deux clics rapides ne doivent pas envoyer DEUX enregistrements (js/utils/actions.js).
            const boutonEnregistrer = document.getElementById('btn-save-eleve');
            boutonEnregistrer.addEventListener('click', () => Action.uneSeule(boutonEnregistrer, () => this._save()));
            // Toggle affichage lien PAI
            const cbPai = document.getElementById('f-pai');
            const groupLien = document.getElementById('group-lien-pai');
            if (cbPai && groupLien) {
                cbPai.addEventListener('change', () => {
                    groupLien.style.display = cbPai.checked ? '' : 'none';
                });
            }
            // Toggle affichage précautions médicales
            const cbSuivi = document.getElementById('f-suivi_medical');
            const groupPrecautions = document.getElementById('group-precautions');
            if (cbSuivi && groupPrecautions) {
                cbSuivi.addEventListener('change', () => {
                    groupPrecautions.style.display = cbSuivi.checked ? '' : 'none';
                });
            }
            // Toggle affichage détails ASE
            const cbAse = document.getElementById('f-ase_place');
            const groupAse = document.getElementById('group-ase-details');
            if (cbAse && groupAse) {
                cbAse.addEventListener('change', () => {
                    groupAse.style.display = cbAse.checked ? '' : 'none';
                });
            }
            // Bouton "+ Créer" pour l'école d'origine
            const btnCreateEcole = document.getElementById('btn-create-ecole-origine');
            if (btnCreateEcole) {
                btnCreateEcole.addEventListener('click', () => {
                    const handler = () => {
                        this._loadEtablissements();
                        State.off('etablissements:changed', handler);
                    };
                    State.on('etablissements:changed', handler);
                    FicheEtablissement.open({}, false);
                });
            }
            // Bouton "+ Créer" pour l'établissement actuel
            const btnCreateEtablissement = document.getElementById('btn-create-etablissement');
            if (btnCreateEtablissement) {
                btnCreateEtablissement.addEventListener('click', () => {
                    const handler = () => {
                        this._loadEtablissements();
                        State.off('etablissements:changed', handler);
                    };
                    State.on('etablissements:changed', handler);
                    FicheEtablissement.open({}, false);
                });
            }
            // Toggle liens MDPH sur checkboxes notif
            document.querySelectorAll('.f-notif').forEach(cb => {
                cb.addEventListener('change', function() {
                    const liensDiv = this.closest('.notif-row')?.querySelector('.liens-mdph');
                    if (liensDiv) liensDiv.style.display = this.checked ? '' : 'none';
                });
            });
            // Ajouter un lien MDPH
            document.querySelectorAll('.add-lien-btn').forEach(btn => {
                btn.addEventListener('click', function() {
                    const liensDiv = this.closest('.liens-mdph');
                    const subRow = document.createElement('div');
                    subRow.className = 'sub-row';
                    subRow.style.marginBottom = '4px';
                    subRow.innerHTML = `
                        <input type="text" class="lien-label" placeholder="Libellé" style="flex:1;font-size:13px;padding:4px 8px;border:1px solid var(--border);border-radius:4px">
                        <input type="text" class="lien-url" placeholder="Lien ou chemin du document" style="flex:2;font-size:13px;padding:4px 8px;border:1px solid var(--border);border-radius:4px">
                        <button class="btn-sm btn-del" onclick="this.closest('.sub-row').remove()">x</button>
                    `;
                    liensDiv.insertBefore(subRow, this);
                });
            });
        }

        // Bouton « + Ajouter un groupe »
        const btnAddGroupe = document.getElementById('btn-add-groupe');
        if (btnAddGroupe) btnAddGroupe.addEventListener('click', function(){ this._addGroupeRow(); }.bind(this));

        // Bouton « + Rattacher un projet » (la participation s'écrit tout de suite)
        const btnAddProjet = document.getElementById('btn-add-projet');
        if (btnAddProjet) btnAddProjet.addEventListener('click', function(){ this._choisirProjet(); }.bind(this));

        // Bouton « Imprimer ses projets » : la mémoire de l'élève, sur une feuille à son nom
        const btnPrintProjets = document.getElementById('btn-print-projets');
        if (btnPrintProjets) btnPrintProjets.addEventListener('click', function(){ this._imprimerProjetsEleve(); }.bind(this));

        // Charger la liste des établissements pour le select
        this._loadEtablissements();
    },

    _switchTab(name) {
        document.querySelectorAll('#modal .tab').forEach(t => t.classList.toggle('active', t.dataset.tab === name));
        document.querySelectorAll('#modal .tab-panel').forEach(p => {
            p.style.display = p.dataset.tab === name ? '' : 'none';
        });
        if (name === 'aeshpec' && this._eleve && this._eleve.id) {
            this._loadAESH();
            this._loadPEC();
        }
        if (name === 'representants' && this._eleve && this._eleve.id) {
            this._loadRepresentants();
        }
        if (name === 'medical' && this._eleve && this._eleve.id) {
            this._loadDroitImage();
        }
        if (name === 'scolarite' && this._eleve && this._eleve.id) {
            this._loadGroupes();
            this._loadProjets();
        }
        if (name === 'mdph' && this._eleve && this._eleve.id) {
            this._loadReunions();
            this._chargerReferent();
            this._brancherGevasco();
        }
        if (name === 'documents' && this._eleve && this._eleve.id) {
            this._loadDocuments();
        }
    },

    /* ---- AESH, PEC, Représentants, MDPH → sous-fichiers fiche-eleve-*.js ---- */

    _buildHTML() {
        const e = this._eleve;
        const ro = this._readonly ? 'disabled' : '';
        const f = (name, val = '') => `<input type="text" id="f-${name}" value="${escapeHtml(val || e[name] || '')}" ${maxLenAttr(name)} ${ro}>`;
        const d = (name, val = '') => `<input type="date" id="f-${name}" value="${escapeHtml(val || e[name] || '')}" ${ro}>`;
        const c = (name) => `<input type="checkbox" id="f-${name}" ${e[name] ? 'checked' : ''} ${ro}>`;
        const s = (name, options) => {
            const opts = options.map(o => `<option value="${o}" ${e[name] === o ? 'selected' : ''}>${o}</option>`).join('');
            return `<select id="f-${name}" ${ro}><option value="">—</option>${opts}</select>`;
        };
        const txt = (name) => `<textarea id="f-${name}" rows="2" ${ro}>${escapeHtml(e[name] || '')}</textarea>`;

        return `
        <div class="tabs">
            <button class="tab active" data-tab="identite">Identité</button>
            <button class="tab" data-tab="scolarite">Scolarité</button>
            <button class="tab" data-tab="aeshpec">AESH & PEC</button>
            <button class="tab" data-tab="mdph">MDPH & Plans</button>
            <button class="tab" data-tab="medical">Médical</button>
            <button class="tab" data-tab="representants">Repr&eacute;sentants l&eacute;gaux</button>
            <button class="tab" data-tab="documents">Documents</button>
        </div>

        ${this._isNew ? `<div style="background:#e8eaf6;padding:8px 10px;border-left:4px solid var(--primary);border-radius:4px;margin-bottom:12px;font-size:13px">💡 <strong>Avant d'enregistrer l'élève :</strong> il est rattaché à un <strong>établissement</strong>, une <strong>classe</strong> et à l'<strong>année scolaire active</strong>. Si une liste est vide, crée-la d'abord (bouton « + Créer », ou menus <strong>Établissements</strong> / <strong>Classes</strong> ; l'année active se choisit dans <strong>Paramètres</strong>).</div>` : ''}

        <div class="tab-panel active" data-tab="identite" data-help="Identité|Coordonnées de l'élève. Le téléphone est celui de la famille. Le téléphone urgence vient des Représentants légaux. Le transport (bus scolaire, taxi...) détermine l'organisation des sorties. Décocher Élève actif = il quitte le dispositif (reste en base, n'apparaît plus par défaut).">
            <div class="form-row">
                <div class="form-group"><label>Nom *</label>${f('nom')}</div>
                <div class="form-group"><label>Prénom *</label>${f('prenom')}</div>
                <div class="form-group" style="max-width:80px"><label>N°</label><input type="number" id="f-numero" value="${e.numero || ''}" min="0" step="1" style="width:100%"></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Date de naissance</label>${d('date_naissance')}</div>
                <div class="form-group"><label>INE (Identifiant National Élève)</label>${f('ine')}</div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>T&eacute;l&eacute;phone urgence</label>
                    ${f('telephone_urgence')}
                    <small style="color:var(--text-muted)">Auto-rempli depuis l'onglet Repr&eacute;sentants l&eacute;gaux (contact &laquo;&nbsp;Urgence&nbsp;&raquo;).</small>
                </div>
                <div class="form-group"><label>Langue parlée à la maison</label>${f('langue_maison')}</div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Téléphone</label>${f('telephone')}</div>
                <div class="form-group"><label>Email (optionnel)</label>${f('email')}</div>
            </div>
            <div class="form-group"><label>Adresse</label>${txt('adresse')}</div>
            <div class="form-row">
                <div class="form-group"><label>Transport</label>${s('transport', ['Bus','Taxi','Bus scolaire','Bus de ville','Train','Autre','Aucun','Véhicule familial'])}</div>
                <div class="form-group"><label>Régime scolaire</label>${s('regime_scolaire', ['Demi-pensionnaire','Externe','Interne'])}</div>
            </div>
            <div class="form-row">
                <div class="form-group"><label style="display:flex;align-items:center;gap:8px;margin-top:4px">${c('cantine')} Cantine</label></div>
                <div class="form-group"><label style="display:flex;align-items:center;gap:8px;margin-top:4px">${c('bourse')} Boursier(e)</label></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Photo (chemin ou URL)</label>${f('photo_path')}</div>
                <div class="form-group"><label style="display:flex;align-items:center;gap:8px">${c('actif')} Élève actif</label></div>
            </div>
            <div class="form-section" style="margin-top:12px">
                <div class="form-section-title">Champs personnalisables</div>
                <div class="form-row">
                    <div class="form-group"><label>Champ libre 1</label>${f('champ_perso_1')}</div>
                    <div class="form-group"><label>Champ libre 2</label>${f('champ_perso_2')}</div>
                </div>
            </div>
        </div>

        <div class="tab-panel" data-tab="scolarite" style="display:none" data-help="Scolarité|Classe de référence = classe administrative (radar). L'histoire de la classe est datée : changer la classe puis enregistrer ouvre une nouvelle période et clôt la précédente la veille, ce qui garde la trace d'un changement en cours d'année. École d'origine = établissement précédent. Date entrée ULIS = date notification MDPH ou arrivée effective. Section ASE = élève placé Aide Sociale à l'Enfance.">
            <div class="form-row">
                <div class="form-group"><label>Classe de r&eacute;f&eacute;rence</label>
                    <select id="f-classe_id" ${ro} style="width:100%">
                        <option value="">— Sélectionner —</option>
                    </select>
                    <input type="hidden" id="f-classe" value="${escapeHtml(e.classe || '')}">
                </div>
                <div class="form-group"><label style="display:flex;align-items:center;gap:8px;margin-top:20px">${c('ulis')} Élève ULIS</label></div>
            </div>
            <div class="form-row">
                <div class="form-group"><label for="f-temps_scolarisation">Temps de scolarisation</label>
                    <select id="f-temps_scolarisation" ${ro}>
                        <option value="">— Non précisé —</option>
                        <option value="temps_plein" ${e.temps_scolarisation === 'temps_plein' ? 'selected' : ''}>Temps plein</option>
                        <option value="temps_partiel" ${e.temps_scolarisation === 'temps_partiel' ? 'selected' : ''}>Temps partiel</option>
                        <option value="decharge_horaire" ${e.temps_scolarisation === 'decharge_horaire' ? 'selected' : ''}>Décharge horaire</option>
                    </select>
                    <div class="text-muted small" style="margin-top:4px">Information de fiche. Les HEURES non scolarisées se disent dans l’emploi du temps, par un créneau de type « NON SCOLARISE ».</div>
                </div>
            </div>
            <div class="form-section" style="margin-top:8px">
                <div class="form-section-title">Histoire de la classe</div>
                <div id="f-classes-histoire" class="text-muted small">—</div>
            </div>
            <div class="form-row">
                <div class="form-section" style="margin-top:12px">
                    <div class="form-section-title">Projets</div>
                    <p class="text-muted small" style="margin:0 0 8px 0">La mémoire de ce que l'élève a fait : chorale, théâtre, cross, Printemps des poètes… Le projet se décrit une seule fois dans l'écran « Projets » ; ici, on dit seulement qui y a participé.</p>
                    <div id="fiche-projets-list"></div>
                    <button type="button" class="btn btn-sm btn-secondary" id="btn-add-projet" style="margin-top:6px">＋ Rattacher un projet</button>
                    <button type="button" class="btn btn-sm btn-secondary" id="btn-print-projets" style="margin-top:6px"
                            data-help="Projets imprimés|Imprime les projets de cet élève dans un document à son nom : de quoi joindre son parcours culturel et sportif à un dossier (ESS, bilan, équipe de suivi). S'il n'a aucun projet, l'impression le dit au lieu d'imprimer une page vide.">🖨️ Imprimer ses projets</button>
                </div>
            </div>
            <div class="form-row">
                <div class="form-section" style="margin-top:12px">
                    <div class="form-section-title">Groupes</div>
                    <p class="text-muted small" style="margin:0 0 8px 0">Plusieurs groupes possibles (ex. &laquo; Lecture 1 &raquo;, &laquo; Math 2 &raquo;, &laquo; Sortie piscine &raquo;). Ils servent &agrave; filtrer et composer vos listes.</p>
                    <div id="fiche-groupes-list"></div>
                    <button type="button" class="btn btn-sm btn-secondary" id="btn-add-groupe" style="margin-top:6px">＋ Ajouter un groupe</button>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group"><label style="display:flex;align-items:center;gap:6px">Établissement actuel${this._readonly ? '' : ' <button class="btn-xs btn-outline" id="btn-create-etablissement" title="Créer un établissement">+ Créer</button>'}</label>
                    <select id="f-etablissement_id" ${ro} style="width:100%">
                        <option value="">— Sélectionner —</option>
                    </select>
                    <div id="f-etablissement-hint" class="text-muted small" style="display:none;margin-top:4px;color:#e65100">
                        ⚠️ Aucun établissement enregistré. Clique « + Créer » pour ajouter ton établissement, puis sélectionne-le ici.
                    </div>
                </div>
                <div class="form-group"><label style="display:flex;align-items:center;gap:6px">École d'origine${this._readonly ? '' : ' <button class="btn-xs btn-outline" id="btn-create-ecole-origine" title="Créer un établissement">+ Créer</button>'}</label>
                    <div style="display:flex;gap:4px">
                        <select id="f-ecole_origine_id" ${ro} style="flex:1">
                            <option value="">— Sélectionner —</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="form-row">
                <div class="form-group"><label>Date entrée ULIS</label>${d('date_entree_ulis')}</div>
            </div>
            <div class="form-group"><label>Remarques</label>${txt('remarques')}</div>
            <div class="form-section" style="margin-top:16px">
                <div class="form-section-title">Placement ASE</div>
                <label style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
                    ${c('ase_place')} &Eacute;l&egrave;ve plac&eacute; ASE (Aide Sociale &agrave; l'Enfance)
                </label>
                <div id="group-ase-details" style="${e.ase_place ? '' : 'display:none'}">
                    <div class="form-section-title" style="font-size:13px;margin:4px 0">Lieu de vie</div>
                    <div class="form-row">
                        <div class="form-group"><label>Foyer / Famille d'accueil</label>${f('ase_structure_nom')}</div>
                        <div class="form-group"><label>Téléphone</label>${f('ase_structure_telephone')}</div>
                    </div>
                    <div class="form-group"><label>Adresse</label>${f('ase_structure_adresse')}</div>
                    <div class="form-section-title" style="font-size:13px;margin:8px 0 4px">Référent ASE</div>
                    <div class="form-row">
                        <div class="form-group"><label>Nom</label>${f('ase_referent_nom')}</div>
                        <div class="form-group"><label>Téléphone</label>${f('ase_referent_telephone')}</div>
                    </div>
                    <div class="form-row">
                        <div class="form-group"><label>Email</label>${f('ase_referent_email')}</div>
                        <div class="form-group"><label>Lien PPE</label>
                            <div style="display:flex;align-items:center;gap:8px">
                                <input type="text" id="f-ase_lien_ppe" value="${escapeHtml(e.ase_lien_ppe || '')}" placeholder="Lien ou chemin du PPE..." style="flex:1" ${ro}>
                                ${e.ase_lien_ppe ? `<a href="${escapeHtml(this._safeUrl(e.ase_lien_ppe))}" target="_blank" rel="noopener" title="Ouvrir">📄</a>` : ''}
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        ${this._buildAeshPecTab()}

        ${this._buildMdphTab()}

        <div class="tab-panel" data-tab="medical" style="display:none" data-help="Médical|Fiche urgence : coche PAI si l'élève a un Projet d'Accueil Individualisé, ajoute le lien du document. Suivi médical : allergies connues, régime particulier, précautions médicales utiles au quotidien (précautions pour la vie scolaire uniquement, pas de diagnostic).">
            <div class="form-section">
                <div class="form-section-title">Fiche urgence</div>
                <label style="display:flex;align-items:center;gap:8px;margin-bottom:8px">
                    ${c('pai')} PAI (Projet d'Accueil Individualisé)
                </label>
                <div class="form-group" id="group-lien-pai" style="${e.pai ? '' : 'display:none'}">
                    <label>Lien du document PAI</label>
                    <div style="display:flex;align-items:center;gap:8px">
                        <input type="text" id="f-lien_pai" value="${escapeHtml(e.lien_pai || '')}" ${ro}
                               placeholder="Lien ou chemin du document…" style="flex:1">
                        ${!ro && e.lien_pai ? `<a href="${escapeHtml(this._safeUrl(e.lien_pai))}" target="_blank" rel="noopener" title="Ouvrir le document">📄</a>` : ''}
                        ${ro && e.lien_pai ? `<a href="${escapeHtml(this._safeUrl(e.lien_pai))}" target="_blank" rel="noopener" class="btn btn-sm btn-secondary" style="margin-left:4px">📄 Ouvrir le PAI</a>` : ''}
                    </div>
                </div>
            </div>
            <div class="form-section">
                <div class="form-section-title">Suivi médical</div>
                <div class="form-group"><label>Allergies</label>${txt('allergies')}</div>
                <div class="form-group"><label>Régime alimentaire</label>${f('regime_alimentaire')}</div>
                <label style="display:flex;align-items:center;gap:8px;margin-bottom:4px">
                    ${c('suivi_medical')} Suivi médical en cours (dossier médical école)
                </label>
                <div class="form-group" id="group-precautions" style="${e.suivi_medical ? '' : 'display:none'}">
                    <label>Précautions pour la vie scolaire</label>
                    ${txt('precautions_medicales')}
                    <small style="color:var(--text-muted);display:block;margin-top:4px">
                        ⚠️ Indiquez uniquement les précautions pratiques (traitement en cours, aménagements).
                        Pas de diagnostic, pas de pathologie — ces informations relèvent du dossier médical de l'école.
                    </small>
                </div>
            </div>
            <div class="form-section">
                <div class="form-section-title">Droit à l'image</div>
                <p class="text-muted small" style="margin:0 0 8px 0">Autorisation de photographier ou diffuser l'image de l'élève (photos de classe, site de l'école, presse…). Suivi de consentement : demandé / reçu / refusé.</p>
                <div class="form-row">
                    <div class="form-group"><label>Statut</label>
                        <select id="di-statut" ${ro}><option value="">— Non renseigné</option><option value="autorise">✅ Autorisé</option><option value="refuse">⛔ Refusé</option><option value="limite">⚠️ Limité</option><option value="en_attente">⏳ En attente</option><option value="retire">↩️ Retiré</option></select>
                    </div>
                    <div class="form-group"><label>Date de début</label><input type="date" id="di-date_debut" ${ro}></div>
                    <div class="form-group"><label>Date de fin</label><input type="date" id="di-date_fin" ${ro}></div>
                </div>
                <div class="form-group"><label>Référence document signé</label><input type="text" id="di-document_reference" placeholder="N° de dossier, date…" ${ro}></div>
                <div class="form-group"><label>Commentaires</label><textarea id="di-commentaires" rows="2" ${ro}></textarea></div>
            </div>
        </div>

        ${this._buildRepresentantsTab()}
        ${this._buildDocumentsTab()}`;
    },

    async _save() {
        const data = this._collect();
        if (!data.nom || !data.prenom) {
            Modal.alert('Erreur', 'Nom et prénom sont requis.');
            return;
        }
        // Guidage : l'établissement est requis — Toast + focus sur le champ (on ne perd pas la saisie)
        if (!data.etablissement_id) {
            const hasEtablissements = (this._etablissements || []).some(e => e.actif !== 0);
            Toast.error(hasEtablissements
                ? "Sélectionne l'établissement de l'élève dans l'onglet « Scolarité » avant d'enregistrer."
                : "Aucun établissement enregistré. Clique « + Créer » à côté du champ « Établissement actuel » (onglet Scolarité).");
            this._switchTab('scolarite');
            const sel = document.getElementById('f-etablissement_id');
            if (sel) {
                sel.style.borderColor = '#c62828';
                sel.style.boxShadow = '0 0 0 2px rgba(198,40,40,.25)';
                sel.focus();
                setTimeout(() => { sel.style.borderColor = ''; sel.style.boxShadow = ''; }, 5000);
            }
            return;
        }
        // A13 : synchroniser telephone_urgence depuis le représentant marqué "Urgence"
        const repItems = this._getRepresentantsFromDOM();
        const urgenceRep = repItems.find(r => r.telephone_urgence && r.telephone);
        if (urgenceRep) {
            data.telephone_urgence = urgenceRep.telephone;
        }
        try {
            let eleveId = this._eleve.id;
            if (this._isNew) {
                const res = await API.post('eleves.php', data);
                eleveId = res.id;
            } else {
                await API.put('eleves.php?id=' + eleveId, data);
            }
            // Save AESH
            await API.del('aesh_eleves.php?eleve_id=' + eleveId);
            const aeshItems = this._getAESHFromDOM();
            for (const item of aeshItems) {
                await API.post('aesh_eleves.php', { ...item, eleve_id: eleveId });
            }
            // Save PEC
            await API.del('pec_eleves.php?eleve_id=' + eleveId);
            const pecItems = this._getPECFromDOM();
            for (const item of pecItems) {
                await API.post('pec_eleves.php', { ...item, eleve_id: eleveId });
            }
            // Save Représentants
            await API.del('representants.php?eleve_id=' + eleveId);
            for (const item of repItems) {
                await API.post('representants.php', { ...item, eleve_id: eleveId, adresse: item.adresse || '' });
            }
            // Save Droit à l'image (consentement)
            await this._saveDroitImage(eleveId);
            // Save Groupes (multi-groupes libres)
            await this._saveGroupes(eleveId);
            Modal.close();
            await ElevesList._load();
            State.emit('eleves:changed');
            Toast.success(this._isNew ? 'Élève créé' : 'Élève modifié');
        } catch (e) {
            Modal.alert('Erreur', e.message);
        }
    },

    _collect() {
        const data = {};
        // Champs texte
        ['nom','prenom','date_naissance','ine','classe','ecole_origine','ecole_origine_id','etablissement_id',
         'date_entree_ulis',
         'transport','telephone','email','adresse','allergies',
         'regime_alimentaire','precautions_medicales','lien_pai','remarques',
         'langue_maison','regime_scolaire','photo_path','champ_perso_1','champ_perso_2','telephone_urgence',
         'ase_structure_nom','ase_structure_adresse','ase_structure_telephone',
         'ase_referent_nom','ase_referent_telephone','ase_referent_email','ase_lien_ppe',
         'mdph_ulis_date_fin','mdph_ulis_statut','mdph_sessad_date_fin','mdph_sessad_statut',
         'mdph_aesh_date_fin','mdph_aesh_statut','mdph_transport_date_fin','mdph_transport_statut',
         'mdph_autre_date_fin','mdph_autre_statut','mdph_autre_libelle']
        .forEach(f => { const el = document.getElementById('f-' + f); if (el) data[f] = el.value; });

        // numero : entier optionnel
        const numeroEl = document.getElementById('f-numero');
        data.numero = numeroEl && numeroEl.value !== '' ? parseInt(numeroEl.value) : null;

        // classe_id : lire le select, sync le texte classe pour backward compat
        const classeSelect = document.getElementById('f-classe_id');
        if (classeSelect && classeSelect.value) {
            data.classe_id = parseInt(classeSelect.value);
            // Nom COURT de la classe (pas le texte complet de l'option qui peut
            // dépasser la limite SQL varchar(20) → « data too long »)
            data.classe = classeSelect.options[classeSelect.selectedIndex]?.dataset?.nom || '';
        } else {
            data.classe_id = null;
            data.classe = document.getElementById('f-classe')?.value || '';
        }

        // ecole_origine_id : auto-sync le nom texte pour backward compat
        const eoSelect = document.getElementById('f-ecole_origine_id');
        if (eoSelect && eoSelect.value) {
            data.ecole_origine = eoSelect.options[eoSelect.selectedIndex]?.text || '';
        }

        // Temps de scolarisation (information de fiche, décision 9.3)
        const tempsScol = document.getElementById('f-temps_scolarisation');
        if (tempsScol) data.temps_scolarisation = tempsScol.value || '';

        // Checkboxes
        data.ulis = document.getElementById('f-ulis')?.checked ? 1 : 0;
        data.cantine = document.getElementById('f-cantine')?.checked ? 1 : 0;
        data.bourse = document.getElementById('f-bourse')?.checked ? 1 : 0;
        data.pai = document.getElementById('f-pai')?.checked ? 1 : 0;
        data.ase_place = document.getElementById('f-ase_place')?.checked ? 1 : 0;
        data.suivi_medical = document.getElementById('f-suivi_medical')?.checked ? 1 : 0;
        data.actif = document.getElementById('f-actif')?.checked ? 1 : 0;

        // Notifications
        const notifs = [];
        document.querySelectorAll('.f-notif:checked').forEach(cb => notifs.push(cb.dataset.type));
        data.notifications = JSON.stringify(notifs);

        // Liens MDPH
        const liensMdph = {};
        document.querySelectorAll('.liens-mdph').forEach(div => {
            const liens = [];
            div.querySelectorAll('.sub-row').forEach(row => {
                const label = row.querySelector('.lien-label')?.value?.trim();
                const url = row.querySelector('.lien-url')?.value?.trim();
                if (url) liens.push({ label: label || '', url });
            });
            if (liens.length) liensMdph[div.dataset.type] = liens;
        });
        data.liens_mdph = JSON.stringify(liensMdph);

        // L'enseignant référent (ERSEH) : une fiche adulte, pas un texte libre.
        const refEl = document.getElementById('f-enseignant_referent_id');
        if (refEl) {
            data.enseignant_referent_id = refEl.value === '' ? null : parseInt(refEl.value, 10);
        }

        return data;
    },

    async _loadEtablissements() {
        const remplirSelect = (selectId, currentId) => {
            const select = document.getElementById(selectId);
            if (!select) return;
            select.innerHTML = '<option value="">— Sélectionner —</option>' +
                this._etablissements.filter(e => e.actif !== 0).map(e =>
                    `<option value="${e.id}" ${e.id === currentId ? 'selected' : ''}>${escapeHtml(e.nom)}${e.ville ? ' (' + escapeHtml(e.ville) + ')' : ''}</option>`
                ).join('');
        };

        try {
            this._etablissements = await API.get('etablissements.php');
        } catch {
            this._etablissements = [];
        }

        const currentEtablissement = this._eleve && this._eleve.etablissement_id;
        remplirSelect('f-etablissement_id', currentEtablissement);

        const currentOrigine = this._eleve && this._eleve.ecole_origine_id;
        remplirSelect('f-ecole_origine_id', currentOrigine);

        // Aide : aucun établissement enregistré → inviter à en créer un
        const hint = document.getElementById('f-etablissement-hint');
        if (hint) {
            const actifs = this._etablissements.filter(e => e.actif !== 0);
            hint.style.display = actifs.length ? 'none' : '';
        }

        // Classes de référence
        try {
            const classes = await API.get('classes.php');
            const classeSelect = document.getElementById('f-classe_id');
            if (classeSelect) {
                classeSelect.innerHTML = '<option value="">— Sélectionner —</option>' +
                    classes.map(c => {
                        let niveauxLabel = '';
                        try { const n = JSON.parse(c.niveaux || '[]'); if (n.length) niveauxLabel = ' [' + n.map(x => NIVEAU_LABELS[x] || x).join('+') + ']'; } catch {}
                        return `<option value="${c.id}" data-nom="${escapeHtml(c.nom)}" ${(this._eleve && this._eleve.classe_id === c.id) ? 'selected' : ''}>${escapeHtml(c.nom)}${niveauxLabel}${(c.enseignants || []).length ? ' — ' + escapeHtml((c.enseignants || []).map(a => ((a.prenom || '') + ' ' + (a.nom || '')).trim()).filter(Boolean).join(' · ')) : ''}</option>`;
                    }).join('');
            }
        } catch (e) {
            // Sans les classes, le sélecteur « Classe de référence » resterait vide :
            // l'utilisateur croirait qu'aucune classe n'existe (revue du 29/09/2026 —
            // un écran vide ressemble à une perte de données). On le dit, sans bloquer
            // le reste de la fiche.
            Toast.error('Impossible de charger la liste des classes : ' + (e.message || ''));
        }
        this._afficherHistoireClasses();
    },

    /** Histoire datée de la classe (décision 3.3 du 27/10/2026) — lecture seule.
     *  L'API l'écrit toute seule quand la classe change ; on ne fait que la montrer,
     *  pour que l'utilisateur voie que SON changement a été daté. */
    async _afficherHistoireClasses() {
        const zone = document.getElementById('f-classes-histoire');
        if (!zone) return;
        if (!this._eleve || !this._eleve.id || this._isNew) {
            zone.innerHTML = '<em>L&#39;histoire de la classe commence à l&#39;enregistrement.</em>';
            return;
        }
        try {
            const d = await API.get('eleve_classes.php?eleve_id=' + this._eleve.id);
            const h = (d && d.historique) || [];
            if (!h.length) {
                zone.innerHTML = '<em>Aucune période enregistrée : la classe sera datée au prochain enregistrement.</em>';
                return;
            }
            zone.innerHTML = '<ul style="margin:0;padding-left:18px">' + h.map(p => {
                const nom = escapeHtml(p.classe_nom || '(classe non renseignée)');
                const debut = this._dateFr(p.date_debut);
                const fin = p.date_fin ? this._dateFr(p.date_fin) : 'aujourd&#39;hui';
                return '<li>' + nom + ' — du ' + debut + ' au ' + fin + '</li>';
            }).join('') + '</ul>';
        } catch (e) {
            zone.innerHTML = '<em>Histoire indisponible : ' + escapeHtml(e.message || '') + '</em>';
        }
    },

    _dateFr(d) {
        if (!d) return '';
        const p = String(d).substring(0, 10).split('-');
        return p.length === 3 ? p[2] + '/' + p[1] + '/' + p[0] : String(d);
    },
};