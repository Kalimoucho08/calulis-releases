/**
 * Calulis — Projets d'un élève (lot 4 de la 1.30)
 * Greffé sur FicheEleve. Section « Projets » dans l'onglet Scolarité.
 *
 * LA PARTICIPATION S'APPLIQUE TOUT DE SUITE : contrairement aux groupes, qui partent avec
 * l'enregistrement de la fiche, cocher un projet écrit immédiatement (POST/DELETE
 * eleve_projets.php). On peut donc ajouter un projet à un élève depuis sa fiche sans
 * toucher au reste, et sans risque de perdre la saisie en cours.
 *
 * Ici on ne CRÉE pas de projet : il n'y a qu'une façon de décrire un projet, l'écran
 * « Projets ». La fiche ne fait que rattacher l'élève à un projet existant.
 */
Object.assign(FicheEleve, {

    _loadProjets() {
        const box = document.getElementById('fiche-projets-list');
        if (!box) return;
        if (!this._eleve || !this._eleve.id) { this._renderProjets([]); return; }
        API.get('eleve_projets.php?eleve_id=' + this._eleve.id).then(items => {
            this._renderProjets(items || []);
        }).catch(() => this._renderProjets([]));
    },

    _renderProjets(items) {
        this._projetsEleve = items || [];
        const box = document.getElementById('fiche-projets-list');
        if (!box) return;
        if (!items.length) {
            box.innerHTML = '<div class="text-muted small">Aucun projet pour cet élève.</div>';
            return;
        }
        const f = (d) => {
            if (!d) return '';
            const [a, m, j] = String(d).split('-');
            return j && m && a ? j + '/' + m + '/' + a : String(d);
        };
        box.innerHTML = items.map(p => {
            const dates = [f(p.date_debut), f(p.date_fin)].filter(Boolean).join(' → ');
            return '<div class="sub-row projet-row" data-id="' + p.id + '" style="display:flex;gap:8px;align-items:center;margin-bottom:4px">'
                + '<span style="flex:1"><strong>' + escapeHtml(p.nom) + '</strong>'
                + (p.type ? ' <span class="etiquette">' + escapeHtml(p.type) + '</span>' : '')
                + (dates ? ' <span class="text-muted small">' + escapeHtml(dates) + '</span>' : '')
                + '</span>'
                + (this._readonly ? '' : '<button type="button" class="btn-sm btn-del" data-retirer="' + p.id + '" title="Retirer ce projet à cet élève">✕</button>')
                + '</div>';
        }).join('');
        if (!this._readonly) {
            box.querySelectorAll('button[data-retirer]').forEach(btn => {
                btn.addEventListener('click', () => this._retirerProjet(Number(btn.dataset.retirer)));
            });
        }
    },

    async _retirerProjet(projetId) {
        if (!this._eleve || !this._eleve.id) return;
        try {
            await API.del('eleve_projets.php?eleve_id=' + this._eleve.id + '&projet_id=' + projetId);
            Toast.success('Projet retiré à cet élève.');
            this._loadProjets();
        } catch (e) {
            Toast.error('Le projet n\'a pas pu être retiré.');
        }
    },

    /** Choix parmi les projets de l'année : on ne décrit pas un projet ici, on le rattache. */
    async _choisirProjet() {
        if (!this._eleve || !this._eleve.id) return;
        let dejaLa = [];
        try {
            dejaLa = (await API.get('eleve_projets.php?eleve_id=' + this._eleve.id) || []).map(p => Number(p.id));
        } catch (e) { dejaLa = []; }
        const annee = State.get('annee_scolaire_id') || '';
        let projets = [];
        try {
            projets = await API.get('projets.php?annee_scolaire_id=' + encodeURIComponent(annee)) || [];
        } catch (e) { projets = []; }
        const dispo = projets.filter(p => !dejaLa.includes(Number(p.id)));
        if (!dispo.length) {
            Toast.info(projets.length
                ? 'Cet élève est déjà rattaché à tous les projets de l\'année.'
                : 'Aucun projet pour cette année : décrivez-le d\'abord dans l\'écran « Projets ».');
            return;
        }
        const html = '<div class="form-group"><label for="pj-choix-filtre">Rechercher</label>'
            + '<input type="search" id="pj-choix-filtre" placeholder="Nom ou type de projet…" style="width:100%"></div>'
            + '<div class="liste-cases" id="pj-choix-liste">'
            + dispo.map(p => '<label class="case" data-nom="' + escapeAttr((p.nom + ' ' + (p.type || '')).toLowerCase()) + '">'
                + '<input type="radio" name="pj-choix" value="' + p.id + '"> ' + escapeHtml(p.nom)
                + (p.type ? ' <span class="etiquette">' + escapeHtml(p.type) + '</span>' : '') + '</label>').join('')
            + '</div>';
        Modal.open({
            title: 'Rattacher un projet à ' + (this._eleve.prenom || '') + ' ' + (this._eleve.nom || ''),
            body: html,
            footer: '<button class="btn btn-secondary" id="pj-choix-annuler">Annuler</button>'
                + '<button class="btn btn-primary" id="pj-choix-ok">Rattacher</button>',
        });
        const filtre = document.getElementById('pj-choix-filtre');
        if (filtre) {
            filtre.addEventListener('input', () => {
                const f = filtre.value.trim().toLowerCase();
                document.querySelectorAll('#pj-choix-liste .case').forEach(lab => {
                    lab.style.display = !f || (lab.dataset.nom || '').includes(f) ? '' : 'none';
                });
            });
        }
        document.getElementById('pj-choix-annuler').addEventListener('click', () => Modal.close());
        document.getElementById('pj-choix-ok').addEventListener('click', async () => {
            const choix = document.querySelector('input[name="pj-choix"]:checked');
            if (!choix) { Toast.warning('Choisissez un projet dans la liste.'); return; }
            try {
                await API.post('eleve_projets.php', { eleve_id: this._eleve.id, projet_id: Number(choix.value) });
                Modal.close();
                Toast.success('Projet rattaché à l\'élève.');
                this._loadProjets();
            } catch (e) {
                Toast.error('Le projet n\'a pas pu être rattaché.');
            }
        });
    },

    /**
     * Les projets de CET élève sur une feuille à son nom. Rien n'est inventé : la liste vient
     * de ce que la section affiche déjà (_projetsEleve), donc l'impression ne peut pas montrer
     * autre chose que ce que l'on voit.
     */
    _imprimerProjetsEleve() {
        const items = this._projetsEleve || [];
        Print._imprimerListe(false, {
            cle: 'projets_eleve',
            selection: items,
            messageVide: 'Rien à imprimer : cet élève n\'a aucun projet.',
            docDef: () => this._docProjetsEleve(items),
        });
    },

    _docProjetsEleve(items) {
        const el = this._eleve || {};
        const nom = [el.prenom, el.nom].filter(Boolean).join(' ');
        const bouts = [nom || 'Élève'];
        if (el.classe_nom || el.classe) bouts.push('classe ' + (el.classe_nom || el.classe));
        bouts.push(items.length + (items.length > 1 ? ' projets' : ' projet'));
        const sousTitre = bouts.join(' · ');
        const contenu = [...Print._entetePage('Projets de l\'élève', sousTitre)];
        items.forEach(p => {
            // datesLisibles() : même rendu que l'écran, et une seule date quand début = fin.
            const dates = datesLisibles(p.date_debut, p.date_fin);
            contenu.push({
                columns: [
                    { text: String(p.nom || ''), style: 'projetNom', width: '*' },
                    { text: dates, style: 'cellule', width: 'auto', alignment: 'right' },
                ],
                margin: [0, 0, 0, 1],
            });
            const infos = [];
            if (p.type) infos.push(p.type);
            if (p.classes_noms) infos.push('classes ' + p.classes_noms);
            if (infos.length) contenu.push({ text: infos.join(' · '), style: 'cellule', margin: [0, 0, 0, 8] });
            else contenu.push({ text: '', margin: [0, 0, 0, 7] });
        });
        return Print._docListe({
            cle: 'projets_eleve',
            titre: 'Projets de l\'élève',
            sousTitre,
            contenu,
            pied: "Calulis — les projets de l'élève, imprimés depuis sa fiche.",
            styles: {
                projetNom: { fontSize: 10, bold: true },
                cellule: { fontSize: 8.5, color: '#555555' },
            },
        });
    },

});
