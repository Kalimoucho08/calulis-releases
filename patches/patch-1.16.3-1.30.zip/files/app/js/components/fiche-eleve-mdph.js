/**
 * Calulis — Fiche Élève : onglet MDPH & Plans
 * Attaché à FicheEleve via Object.assign
 */

Object.assign(FicheEleve, {

    _buildMdphTab() {
        const e = this._eleve;
        const ro = this._readonly ? 'disabled' : '';
        // Lecture seule : une liste déroulante grisée a l'air cliquable et ne s'ouvre jamais.
        // On lit donc les coordonnées en clair ; la liste n'apparaît qu'en modification.
        const champReferent = ro
            ? '<p id="referent-lecture" class="small" style="margin:0">—</p>'
            : '<select id="f-enseignant_referent_id" class="form-input" data-help="Enseignant référent|La liste ne propose que les fiches adultes qui portent le rôle « Enseignant référent » (onglet Adultes). Le désigner ici remplit automatiquement son nom, son téléphone et son courriel dans le GEVA-Sco."><option value="">— Aucun —</option></select>';
        const d = this._d.bind(this);
        const f = this._f.bind(this);
        const s = this._s.bind(this);

        const mdph = (code, label) => `
            <div class="form-row">
                <div class="form-group">
                    <label>${label} — Date fin</label>
                    ${d('mdph_' + code + '_date_fin')}
                </div>
                <div class="form-group">
                    <label>Statut</label>
                    ${s('mdph_' + code + '_statut', ['notifie','en_attente','renouvellement','refuse'])}
                </div>
            </div>`;

        const liensMdph = (() => { try { return JSON.parse(e.liens_mdph || '{}'); } catch { return {}; } })();
        const typesNotifs = ['PPS','PAI','PAP','PPRE','ESS','notif_mdph'];
        const notifLabels = { PPS: 'PPS (MOPPS)', PAI: 'PAI', PAP: 'PAP', PPRE: 'PPRE', ESS: 'ESS (GEVASCO)', notif_mdph: 'Notif. MDPH' };

        return `
        <div class="tab-panel" data-tab="mdph" style="display:none" data-help="MDPH & Plans|Gérez les droits MDPH de l'élève et les documents associés. Dates de droits : ULIS, SESSAD, AESH, Transport — renseignez les dates de fin pour que Calulis vous alerte quand un droit arrive à expiration (pastille ⚠️ sur le tableau de bord). Notifications : cochez les documents officiels (PPS, PAI, PAP, PPRE, ESS/GEVASCO) et attachez les fichiers correspondants. La section Réunions liées en bas de l'onglet liste les ESS et équipes éducatives de l'élève.">
            <div class="aide-note" style="margin-bottom:12px">
                <strong>⚖️ Cadre légal</strong> — Les données MDPH sont collectées dans le cadre du suivi des notifications CDAPH (Commission des Droits et de l'Autonomie des Personnes Handicapées), conformément aux articles L.112-1 et suivants du code de l'éducation.
                Ces informations sont nécessaires à l'organisation du dispositif ULIS et ne doivent pas préciser la nature du handicap ou de la pathologie (recommandation Eduscol).
                <br><span style="font-size:12px;opacity:0.7">Base légale : mission d'intérêt public (RGPD art. 6.1.e) — Voir <a href="#mentions-rgpd" onclick="Router.go('mentions-rgpd');return false" style="text-decoration:underline">Mentions RGPD</a>.</span>
            </div>
            <div class="form-section">
                <div class="form-section-title">Droits MDPH</div>
                ${mdph('ulis', 'ULIS')}
                ${mdph('sessad', 'SESSAD')}
                ${mdph('aesh', 'AESH')}
                ${mdph('transport', 'Transport')}
                <div class="form-row">
                    <div class="form-group"><label>Autre droit — Date fin</label>${d('mdph_autre_date_fin')}</div>
                    <div class="form-group"><label>Statut</label>${s('mdph_autre_statut', ['notifie','en_attente','renouvellement','refuse'])}</div>
                </div>
                <div class="form-group"><label>Libellé autre droit</label>${f('mdph_autre_libelle')}</div>
            </div>
            <div class="form-section">
                <div class="form-section-title">Notifications / Plans de suivi</div>
                ${typesNotifs.map(type => {
                    const checked = (e.notifications || '').includes(type);
                    const liens = liensMdph[type] || [];
                    return `
                    <div class="notif-row" style="margin-bottom:8px">
                        <label style="display:flex;align-items:center;gap:4px;font-size:14px;cursor:pointer;margin-bottom:4px">
                            <input type="checkbox" class="f-notif" data-type="${type}" ${checked ? 'checked' : ''} ${ro}> ${notifLabels[type]}
                        </label>
                        <div class="liens-mdph" data-type="${type}" style="${checked ? '' : 'display:none'}; margin-left:24px">
                            ${liens.map((l, i) => `
                                <div class="sub-row" style="margin-bottom:4px">
                                    <input type="text" class="lien-label" value="${escapeHtml(l.label || '')}" placeholder="Libellé" style="flex:1" ${ro}>
                                    <input type="text" class="lien-url" value="${escapeHtml(l.url || '')}" placeholder="Lien ou chemin du document" style="flex:2" ${ro}>
                                    ${l.url ? `<a href="${escapeHtml(this._safeUrl(l.url))}" target="_blank" rel="noopener" title="Ouvrir" style="font-size:16px;text-decoration:none">📄</a>` : ''}
                                    ${!ro ? '<button class="btn-sm btn-del" onclick="this.closest(\'.sub-row\').remove()">x</button>' : ''}
                                </div>
                            `).join('')}
                            ${!ro ? `<button class="btn-sm btn-secondary add-lien-btn" data-type="${type}" style="margin-top:2px;font-size:11px">+ Lien</button>` : ''}
                        </div>
                    </div>`;
                }).join('')}
            </div>
            <div class="form-section">
                <div class="form-section-title">👤 Enseignant référent (ERSEH)</div>
                <p class="text-muted small" style="margin:0 0 8px">
                    Ce n'est <strong>pas</strong> l'enseignant de la classe de référence. L'enseignant référent
                    suit le <strong>PPS</strong>, réunit et anime l'<strong>équipe de suivi de la scolarisation</strong>
                    (l'ESS), et fait le lien entre la famille, l'école et l'équipe pluridisciplinaire de la
                    <strong>MDPH</strong>. C'est lui que le GEVA-Sco nomme dans « Nom et coordonnées de
                    l'enseignant référent du secteur ».
                </p>
                <div class="form-group">
                    <label for="f-enseignant_referent_id">Enseignant référent du secteur</label>
                    ${champReferent}
                </div>
                <p id="referent-etat" class="text-muted small" style="margin:0"></p>
            </div>
            <div class="form-section">
                <div class="form-section-title">📄 GEVA-Sco (réexamen)</div>
                <p class="text-muted small" style="margin:0 0 8px">
                    Le formulaire officiel « réexamen » (version 2 — février 2016) est livré avec Calulis.
                    Calulis vous <strong>propose</strong> une valeur par case (identité, adresse, classe, établissement,
                    enseignant référent, date de l'ESS) : vous corrigez, vous décochez ce que vous ne voulez pas,
                    puis vous fabriquez le PDF — il reste modifiable, les cases non remplies vous attendent.
                    Aucune donnée ne quitte l'ordinateur.
                </p>
                <button class="btn btn-sm btn-secondary" id="btn-gevasco" data-help="GEVA-Sco|Prépare le formulaire officiel de réexamen avec les informations de l'élève, son emploi du temps compris. Chaque case est proposée, jamais imposée : corrigez la valeur, décochez la ligne pour la laisser vide, puis fabriquez le PDF. L'emploi du temps se répartit par moment de COMMENCEMENT du créneau (matin avant 12 h, midi de 12 h à 13 h 30, après-midi ensuite). Les zones de texte libre restent à écrire dans le PDF ou à copier depuis la fiche.">📄 Pré-remplir le formulaire</button>
                <div id="gevasco-zone" style="margin-top:10px"></div>
            </div>
            <div class="form-section">
                <div class="form-section-title">🤝 Réunions liées</div>
                <div id="fiche-reunions-list"><p class="text-muted small">Chargement...</p></div>
                <button class="btn btn-sm btn-secondary" id="btn-new-reunion-from-fiche" style="margin-top:6px">+ Nouvelle réunion</button>
            </div>
        </div>`;
    },

    /** Branche le bouton GEVA-Sco de l'onglet MDPH (une seule fois par ouverture de fiche). */
    _brancherGevasco() {
        const btn = document.getElementById('btn-gevasco');
        if (!btn || btn.dataset.branche === '1') return;
        btn.dataset.branche = '1';
        btn.addEventListener('click', () => {
            if (typeof Gevasco === 'undefined') {
                if (typeof Toast !== 'undefined') Toast.error('Le module GEVA-Sco n\'est pas chargé.');
                return;
            }
            Gevasco.afficher('gevasco-zone', this._eleve);
        });
    },


    /**
     * Propose les adultes qui portent le rôle « Enseignant référent » (ERSEH).
     * L'enseignant référent n'est pas l'enseignant de la classe de référence : c'est celui
     * qui suit le PPS, réunit et anime l'ESS, et relie la famille, l'école et la MDPH.
     */
    async _chargerReferent() {
        const sel = document.getElementById('f-enseignant_referent_id');
        const lu = document.getElementById('referent-lecture');
        if (!sel && !lu) return;
        if (sel && sel.dataset.charge === '1') return;
        const etat = document.getElementById('referent-etat');
        const dire = (t) => { if (etat) etat.textContent = t; };
        const courant = Number(this._eleve && this._eleve.enseignant_referent_id) || 0;
        const porteLeRole = (a) => (typeof estEnseignantReferent === 'function'
            ? estEnseignantReferent(a) : String(a.role || '') === 'enseignant_referent');
        // Le nom de l'établissement où se trouve son bureau : utile pour distinguer deux référents.
        const bureau = (a) => {
            const liens = Array.isArray(a.liens_etablissements) ? a.liens_etablissements : [];
            const nom = liens.length ? (liens[0].nom || '') : '';
            return nom ? ' — ' + nom : '';
        };
        const coordonnees = (a) => {
            const nom = [a.prenom, a.nom].filter(Boolean).join(' ');
            const tel = a.telephone ? ' — ' + a.telephone : '';
            const courriel = a.email ? ' — ' + a.email : '';
            return nom + tel + courriel;
        };
        try {
            const adultes = (await API.get('adultes.php')) || [];
            // La règle du rôle est écrite UNE fois (utils/sanitize.js) : elle sert aussi au GEVA-Sco.
            const liste = adultes.filter(porteLeRole);
            // L'élève peut pointer vers une personne qui n'a pas (ou plus) le rôle : on la garde.
            if (courant && !liste.some((a) => Number(a.id) === courant)) {
                const un = await API.get('adultes.php?id=' + courant);
                const a = Array.isArray(un) ? un[0] : un;
                if (a && a.id) liste.push(a);
            }
            const nombre = liste.filter(porteLeRole).length;
            const choisi = liste.find((a) => Number(a.id) === courant);
            // Lecture seule : rien à choisir, on lit ce que la fiche désigne.
            if (lu) {
                lu.textContent = choisi ? coordonnees(choisi) + bureau(choisi)
                    : (courant ? 'La fiche désigne un enseignant référent (n° ' + courant + ') absent de la liste des adultes.'
                        : 'Aucun enseignant référent désigné sur cette fiche.');
                return;
            }
            sel.innerHTML = '<option value="">— Aucun —</option>' + liste.map((a) => {
                const nom = [a.prenom, a.nom].filter(Boolean).join(' ');
                const tel = a.telephone ? ' — ' + a.telephone : '';
                return '<option value="' + a.id + '"' + (Number(a.id) === courant ? ' selected' : '') + '>'
                    + escapeHtml(nom + tel + bureau(a)) + '</option>';
            }).join('');
            sel.dataset.charge = '1';
            if (liste.length === 0) {
                dire("Aucune fiche adulte ne porte le rôle « Enseignant référent » : cochez ce rôle sur la fiche de la personne, dans Adultes.");
            } else if (!courant && nombre > 1) {
                // Plusieurs référents peuvent intervenir : la fiche de l'élève dit lequel suit SON secteur.
                dire(nombre + ' fiches portent le rôle « Enseignant référent » : désignez celle du secteur de cet élève, c\'est elle que le GEVA-Sco nomme.');
            } else if (!courant && nombre === 1) {
                dire('Une seule fiche porte le rôle : elle est proposée au GEVA-Sco, même sans désignation ici.');
            } else {
                dire('');
            }
        } catch (e) {
            dire("La liste des adultes n'a pas pu être chargée.");
            if (lu) lu.textContent = '—';
        }
    },

    async _loadReunions() {
        const container = document.getElementById('fiche-reunions-list');
        if (!container) return;
        try {
            const reunions = await API.get('reunions.php?eleve_id=' + this._eleve.id);
            if (!reunions || !reunions.length) {
                container.innerHTML = '<p class="text-muted small">Aucune réunion enregistrée pour cet élève.</p>';
            } else {
                container.innerHTML = reunions.map(r => `
                    <div class="reunion-mini" style="padding:4px 0;border-bottom:1px solid var(--border);font-size:13px;cursor:pointer"
                         data-id="${r.id}">
                        <span style="font-weight:600">${formatDate(r.date_reunion)}</span>
                        ${r.heure ? ' · ' + r.heure.substring(0,5) : ''}
                        <span class="badge reunion-statut-${r.statut || 'prevue'}" style="margin-left:4px">${r.statut || 'prévue'}</span>
                        <strong>${escapeHtml(r.titre)}</strong>
                    </div>
                `).join('');
            }
        } catch {
            container.innerHTML = '<p class="text-muted small">Impossible de charger les réunions.</p>';
        }

        const btn = document.getElementById('btn-new-reunion-from-fiche');
        if (btn) {
            btn.onclick = () => {
                ReunionsList._openFiche({ eleve_id: this._eleve.id }, false);
            };
        }
    },

});