/**
 * Calulis — Impression : socle commun (page, bandeaux, grille, couleurs, répartition)
 *
 * Source unique de la mise en page des documents imprimés. Aucun builder (emplois du temps,
 * statistiques, fiches, listes, tâches, suivi) ne doit plus décider seul de ses marges, de sa
 * police, de son pied de page ou de sa pagination.
 *
 * Règles (docs/impression-specification-2026-10-18.md) :
 *  - A4, marges de 10 mm : le contenu reste toujours dans une zone de sécurité, aucune
 *    imprimante courante ne rogne dedans ;
 *  - bandeaux haut/bas facultatifs, dessinés DANS les marges, jamais dans la grille ;
 *  - hauteurs de lignes fixes : le temps redevient proportionnel ;
 *  - « tenir sur une page » : police 6,5 pt → 6 pt → une seule ligne → page 2 ;
 *  - quand une page ne suffit pas : RÉPARTIR (matin/après-midi, colonnes égales), jamais remplir ;
 *  - aucun emoji : un caractère absent de Roboto sort en carré vide.
 */

const PRINT_MARGE_MM    = 10;    // marge de sécurité (spec § 2.3)
const PRINT_BANDEAU_MM  = 6;     // hauteur d'un bandeau, prise dans la marge
const PRINT_COL_MIN     = 44;    // largeur minimale d'une colonne de personne (pt)
const PRINT_TITRE_PT    = 40;    // titre + sous-titre (hauteur réelle mesurée au PDF)
// Réserve de la légende. Depuis le 28/10/2026 elle vit dans le PIED DE PAGE (donc dans la
// marge basse), plus dans le flux du contenu : c'est cette place dans le flux qui faisait
// partir la légende seule sur une page et doublait le document (4 jours = 8 pages).
// La réserve est en MILLIMÈTRES comme le reste des marges : la mettre en points dans une
// expression convertie ensuite par PT_PAR_MM donnait 54 mm (153 pt) au lieu de 54 pt —
// mesuré au PDF le 28/10/2026 (marge basse à 198 pt au lieu de 99).
const PRINT_LEGENDE_MM  = 16;    // la légende SEULE, dans la marge (le bandeau s'ajoute)
const PRINT_ENTETE_PT   = 17;    // ligne d'en-tête du tableau
const PT_PAR_MM         = 2.83465;
const PRINT_GOUTTIERE_PT = 34;   // colonne « Heure » + traits de la grille horaire
const PRINT_CELL_PAD_PT  = 10;   // padding/marges d'une cellule pdfmake (4+4 de padding, 1+1 de marge)

/**
 * Nom de fichier de chaque sortie (dette du 18/10/2026 : dix conventions différentes).
 * Cette table est la source unique : `_nomFichier()` et un contrôle des tests s'y appuient.
 */
const PRINT_NOM_FICHIER = {
    edt_semaine_eleve:    'edt-eleve',
    edt_semaine_adulte:   'edt-adulte',
    edt_jour_eleves:      'edt-jour-eleves',
    edt_jour_adultes:     'edt-jour-adultes',
    statistiques:         'statistiques',
    fiche_urgence:        'fiches-urgence',
    fiche_renseignements: 'fiches-renseignements',
    fiche_eleve:          'fiche-eleve',
    liste_eleves:         'liste-eleves',
    taches:               'taches',
    suivi:                'suivi',
    projets:              'projets',
    reunions:             'reunions',
    projets_eleve:        'projets-eleve',
};

/** Réglages par défaut, par document (phase 1 : pas encore d'écran de réglages). */
const PRINT_DEFAUTS = {
    edt_semaine_eleve:    { bas: { actif: true, elements: ['nom', 'semaine'], texte: '' } },
    edt_semaine_adulte:   { bas: { actif: true, elements: ['nom', 'semaine'], texte: '' } },
    edt_jour_eleves:      { bas: { actif: true, elements: ['jour', 'semaine'], texte: '' } },
    edt_jour_adultes:     { bas: { actif: true, elements: ['jour', 'semaine'], texte: '' } },
    // Phase 3 : les six autres sorties. Les statistiques enchaînent leurs blocs par défaut
    // (spec § 1, décision 10) ; les fiches portent déjà leur nom, donc pas de pied par défaut.
    statistiques:         { blocsParPage: 'enchaines', bas: { actif: true, elements: ['date'], texte: '' } },
    fiche_urgence:        { bas: { actif: false, elements: [], texte: '' } },
    fiche_renseignements: { bas: { actif: false, elements: [], texte: '' } },
    // La fiche élève porte déjà son nom en tête : pas de pied par défaut, comme les autres fiches.
    fiche_eleve:          { bas: { actif: false, elements: [], texte: '' } },
    liste_eleves:         { bas: { actif: true, elements: ['date'], texte: '' } },
    taches:               { bas: { actif: true, elements: ['date'], texte: '' } },
    suivi:                { bas: { actif: true, elements: ['date'], texte: '' } },
    // Les projets (lot 4) : une liste de l'écran et une feuille par élève. Le pied porte la
    // date ; « nom » et « semaine » n'auraient aucun sens ici (le sous-titre porte déjà qui
    // et quelle année).
    projets:              { bas: { actif: true, elements: ['date'], texte: '' } },
    projets_eleve:        { bas: { actif: true, elements: ['date'], texte: '' } },
    reunions:             { bas: { actif: true, elements: ['date'], texte: '' } },
};
const PRINT_DEFAUT_GENERAL = {
    marges: PRINT_MARGE_MM,
    haut: { actif: false, elements: [], texte: '' },
    bas: { actif: true, elements: ['nom', 'semaine'], texte: '' },
    tenirSurUnePage: true,
};

Object.assign(Print, {

    /* ═══════════════════════════════════════════
       Réglages et contexte
       ═══════════════════════════════════════════ */

    /** Réglages d'un document : défauts du document ← défauts généraux ← valeurs enregistrées. */
    _reglagesImpression(cle) {
        const perso = (this._params && this._params.impression && this._params.impression[cle]) || {};
        const base = { ...PRINT_DEFAUT_GENERAL, ...(PRINT_DEFAUTS[cle] || {}) };
        return {
            ...base,
            ...perso,
            haut: { ...base.haut, ...(perso.haut || {}) },
            bas: { ...base.bas, ...(perso.bas || {}) },
            marges: perso.marges || base.marges,
        };
    },

    /** Couleurs des types : celles de l'écran, complétées par les défauts (pauses incluses). */
    _couleursDoc() {
        return { ...COULEURS_TYPES_DEFAUT, ...((this._params && this._params.couleurs_types) || {}) };
    },

    /** Établissement principal (facultatif) et année scolaire en cours (facultatif). */
    _contexteEtablissement() {
        const etab = (this._etablissements || []).find(e => e.id === this._notreEtablissementId);
        return {
            etablissement: (etab && etab.nom) || '',
            annee: (this._anneeLibelle || ''),
        };
    },

    /* ═══════════════════════════════════════════
       Bandeaux (en-tête et pied de page)
       ═══════════════════════════════════════════ */

    _elementBandeau(cle, ctx) {
        switch (cle) {
            case 'nom':    return ctx.nom || '';
            case 'jour':    return ctx.jour || '';
            case 'semaine': return ctx.semaine || '';
            case 'classe': return ctx.classe || '';
            case 'titre':  return ctx.titre || '';
            case 'etablissement': return ctx.etablissement || '';
            case 'annee':  return ctx.annee || '';
            case 'date':   return new Date().toLocaleDateString('fr-FR');
            default:       return '';
        }
    },

    /** Un bandeau : éléments cochés + texte libre à gauche, « page X / Y » à droite si demandé. */
    _bandeauNoeud(cote, reglages, ctx) {
        const conf = reglages[cote] || {};
        const elements = conf.elements || [];
        const morceaux = elements.filter(e => e !== 'page').map(e => this._elementBandeau(e, ctx)).filter(Boolean);
        if (conf.texte) morceaux.push(conf.texte);
        const texte = morceaux.join(' · ');
        const numero = elements.includes('page') ? `page ${ctx.page} / ${ctx.total}` : '';
        if (!texte && !numero) return { text: '' };
        const marge = reglages.marges || PRINT_MARGE_MM;
        const margeP = marge * PT_PAR_MM;
        // pdfmake pose l'en-tête à y=0 (bord papier) et le pied au DÉBUT de la marge basse :
        // il faut donc les décaler DANS la marge. Sans cela, le bandeau haut sortait à ~3 mm
        // du bord, hors de la zone d'impression promise (mesuré au PDF le 18/10/2026).
        return {
            margin: cote === 'haut'
                ? [margeP, margeP, margeP, 0]
                : [margeP, 0, margeP, 2],
            columns: [
                { text: texte, fontSize: 7, color: '#666666' },
                { text: numero, fontSize: 7, color: '#666666', alignment: 'right', width: 'auto' },
            ],
        };
    },

    /* ═══════════════════════════════════════════
       Page et mise en page
       ═══════════════════════════════════════════ */

    /** Cette légende produit-elle au moins une entrée (les couleurs blanches sont écartées) ? */
    _aLegende(legende) {
        return !!legende && Object.entries(legende).some(([, c]) => c && c !== '#fff');
    },

    /** Hauteur utile (pt) pour la grille, bandeaux et titre déduits. */
    _hauteurUtile(reglages, orientation, reserveLegende) {
        const pageH = orientation === 'landscape' ? 595.28 : 841.89;
        const margeHaut = (reglages.marges || PRINT_MARGE_MM) + (reglages.haut.actif ? PRINT_BANDEAU_MM : 0);
        const margeBas = (reglages.marges || PRINT_MARGE_MM) + (reglages.bas.actif ? PRINT_BANDEAU_MM : 0)
            + (reserveLegende ? PRINT_LEGENDE_MM : 0);
        return pageH - (margeHaut + margeBas) * PT_PAR_MM - PRINT_TITRE_PT - PRINT_ENTETE_PT - 6;
    },

    /**
     * Combien de lignes par page, quelle hauteur, quelle police.
     * pages = 1 quand ça tient ; au-delà, la journée est RÉPARTIE (spec § 2.5).
     */
    _miseEnPage(reglages, orientation, nbLignes, reserveLegende) {
        const dispo = this._hauteurUtile(reglages, orientation, reserveLegende);
        // Hauteur réelle d'une ligne pdfmake : interligne + marges de cellule et traits.
        // MESURÉE au PDF le 28/10/2026 (pdfmake 0.2.12) : 14,03 pt pour une ligne de 6 pt,
        // soit 6 x 1,15 + 7,1. L'ancienne constante (x 1,11 + 6 = 12,66) sous-estimait de
        // 1,4 pt par ligne : 32 lignes annoncées sur une page en occupaient 449 pt et
        // pdfmake en poussait la fin sur une seconde page (4 jours = 8 pages).
        const hauteurPour = (c) => (c.deuxLignes ? 2 : 1) * c.police * 1.15 + 7.1;
        // « Tenir sur une page » décoché : on ne rétrécit pas, on répartit sur plusieurs pages.
        const candidats = reglages.tenirSurUnePage === false
            ? [{ deuxLignes: true, police: 6.5 }]
            : [
                { deuxLignes: true,  police: 6.5 },   // le plus confortable
                { deuxLignes: true,  police: 6 },     // deux lignes encore lisibles
                { deuxLignes: false, police: 7 },
                { deuxLignes: false, police: 6.5 },
                { deuxLignes: false, police: 6 },     // le plus petit accepté
            ];
        // On retient le candidat qui produit le MOINS de pages, puis le plus confortable
        // à égalité. L'ancienne boucle rendait dès qu'un candidat tenait en une page, et
        // quand aucun ne tenait elle prenait le DERNIER (police 6, une seule ligne) : une
        // journée de 32 lignes sur deux pages perdait le nom de l'adulte et le type, alors
        // que deux pages permettaient de garder deux lignes par case (revu le 28/10/2026).
        let meilleur = null;
        for (const c of candidats) {
            const hauteurLigne = hauteurPour(c);
            const maxParPage = Math.max(1, Math.floor(dispo / hauteurLigne));
            const pages = Math.ceil(nbLignes / maxParPage);
            if (!meilleur || pages < meilleur.pages) meilleur = { pages, maxParPage, hauteurLigne, ...c };
        }
        return meilleur;
    },

    /** Répartition équilibrée en `pages` parts (10 → 5+5, 40 en 3 → 14+13+13). */
    _decouper(n, pages) {
        const base = Math.floor(n / pages), reste = n % pages;
        return Array.from({ length: pages }, (_, i) => base + (i < reste ? 1 : 0));
    },

    /* ═══════════════════════════════════════════
       Dimensions (une seule source de largeur)
       ═══════════════════════════════════════════ */

    /** Largeur de la feuille A4 (pt) selon l'orientation. */
    _largeurFeuille(orientation) {
        return orientation === 'landscape' ? 841.89 : 595.28;
    },

    /** Largeur réellement imprimable (pt) : la feuille moins les deux marges du socle, en mm. */
    _largeurImprimable(reglages, orientation) {
        return this._largeurFeuille(orientation) - (reglages.marges || PRINT_MARGE_MM) * 2 * PT_PAR_MM;
    },

    /** Largeur utile d'une grille horaire : l'imprimable moins la colonne « Heure ». */
    _largeurGrille(reglages, orientation) {
        return this._largeurImprimable(reglages, orientation) - PRINT_GOUTTIERE_PT;
    },

    /** Largeur d'une colonne de personne dans une grille horaire (pt). */
    _largeurColonne(reglages, orientation, nbColonnes) {
        return this._largeurGrille(reglages, orientation) / Math.max(1, nbColonnes) - PRINT_CELL_PAD_PT;
    },

    /** Combien de colonnes de personnes par page, et combien de pages. */
    _colonnesParPage(reglages, orientation, nbColonnes) {
        const dispoW = this._largeurGrille(reglages, orientation);
        const max = Math.max(2, Math.floor(dispoW / PRINT_COL_MIN));
        const pages = Math.max(1, Math.ceil(nbColonnes / max));
        return { pages, tailles: this._decouper(nbColonnes, pages) };
    },

    /* ═══════════════════════════════════════════
       Coupe de la journée (matin / après-midi)
       ═══════════════════════════════════════════ */

    _estPauseCreneau(c) {
        return /RECREATION|PAUSE MIDI|REPAS|PAUSE/i.test(c && c.regroupement_type || '');
    },

    /** Vrai si l'index de créneau tombe à l'intérieur d'un créneau (on ne coupe pas dedans). */
    _indexDansCreneau(index, creneaux, slots, pas) {
        const p = pas || 15;
        return (creneaux || []).some(c => {
            const debut = (slots || []).indexOf(c.heure_debut);
            if (debut < 0) return false;
            const fin = debut + Math.max(1, Math.round((c.duree || p) / p));
            return index > debut && index < fin;
        });
    },

    /**
     * Points de coupe de la journée : on vise le milieu, on préfère une coupure naturelle
     * (fin de la pause du midi), et on ne coupe jamais à l'intérieur d'un créneau.
     * `maxParPage` borne la coupe à ce que la page peut réellement contenir : sans cette
     * borne, une coupure naturelle à +4 lignes faisait déborder pdfmake sur une page en plus.
     */
    _pointsDeCoupe(slots, creneaux, tailles, pas, maxParPage) {
        const points = [];
        let curseur = 0;
        const bloqueur = (index) => (creneaux || []).find(c => {
            const debut = slots.indexOf(c.heure_debut);
            if (debut < 0) return false;
            const p = pas || 15;
            const fin = debut + Math.max(1, Math.round((c.duree || p) / p));
            return index > debut && index < fin;
        });
        for (let i = 0; i < tailles.length - 1; i++) {
            const cible = curseur + tailles[i];
            // Candidats naturels : fin d'une pause (midi d'abord, puis récréation).
            const naturels = [];
            (creneaux || []).forEach(c => {
                if (!this._estPauseCreneau(c)) return;
                const debut = slots.indexOf(c.heure_debut);
                if (debut < 0) return;
                const p = pas || 15;
                naturels.push({
                    n: debut + Math.max(1, Math.round((c.duree || p) / p)),
                    midi: /PAUSE MIDI|REPAS/i.test(c.regroupement_type || ''),
                });
            });
            let retenu = cible;
            const proches = naturels.filter(x => Math.abs(x.n - cible) <= 4)
                .sort((a, b) => (a.midi === b.midi)
                    ? Math.abs(a.n - cible) - Math.abs(b.n - cible)
                    : (a.midi ? -1 : 1));
            if (proches.length) retenu = proches[0].n;
            // Ne jamais viser au-delà de la capacité réelle de la page.
            if (maxParPage) retenu = Math.min(retenu, curseur + maxParPage);
            // Décaler si l'on tombe dans un créneau.
            let essai = retenu;
            while (essai < slots.length && this._indexDansCreneau(essai, creneaux, slots, pas)) essai++;
            if (essai >= slots.length) {
                // Le créneau qui bloque va jusqu'au bout de la journée : reculer à son début
                // plutôt que de couper au milieu d'une case (la page 1 s'arrête avant lui).
                const b = bloqueur(retenu);
                const debut = b ? slots.indexOf(b.heure_debut) : retenu;
                essai = Math.max(curseur + 1, debut);
            }
            points.push(essai);
            curseur = essai;
        }
        return points;
    },

    /** Découpe une liste de lignes selon des points de coupe. */
    _partsSelonPoints(liste, points) {
        const parts = [];
        let debut = 0;
        points.forEach(p => { parts.push(liste.slice(debut, p)); debut = p; });
        parts.push(liste.slice(debut));
        return parts.filter(p => p.length);
    },

    /* ═══════════════════════════════════════════
       Couleurs et grille
       ═══════════════════════════════════════════ */

    /** Couleur de texte lisible sur un fond (hex, rgb() ou nom connu). */
    _textColor(bg) {
        if (!bg || bg === '#fff' || bg === '#ffffff' || bg === 'white') return '#333333';
        let hex = String(bg).trim();
        if (/^#[0-9a-f]{3}$/i.test(hex)) hex = '#' + hex[1] + hex[1] + hex[2] + hex[2] + hex[3] + hex[3];
        if (!/^#[0-9a-f]{6}$/i.test(hex)) return '#333333';   // couleur nommée : texte sombre, toujours lisible
        const r = parseInt(hex.substring(1, 3), 16);
        const g = parseInt(hex.substring(3, 5), 16);
        const b = parseInt(hex.substring(5, 7), 16);
        return (r * 0.299 + g * 0.587 + b * 0.114) > 150 ? '#333333' : '#ffffff';
    },

    /** Couleur d'une case : override du créneau, sinon type, sinon gris clair (jamais blanc). */
    _couleurCase(creneau, couleurs) {
        return (creneau && creneau.couleur_override) || couleurs[creneau && creneau.regroupement_type] || '#e0e0e0';
    },

    /** Tronque chaque ligne d'un texte multi-lignes (ellipse plutôt que débordement). */
    _tronquerLignes(texte, maxParLigne, maxLignes) {
        const lignes = String(texte || '').split('\n').slice(0, maxLignes || 1);
        return lignes.map(l => this._tronquer(l, maxParLigne)).join('\n');
    },

    /** Coupe un texte trop long pour la case (une ellipse plutôt qu'un débordement). */
    _tronquer(texte, max) {
        const t = String(texte || '');
        if (!max || t.length <= max) return t;
        return t.slice(0, Math.max(1, max - 1)).trimEnd() + '…';
    },

    /**
     * Tableau de grille : en-tête + une ligne par créneau, hauteurs FIXES, couleurs,
     * rowSpan borné à la page. Renvoie le nœud pdfmake.
     */
    _tableauGrille({ entetes, lignes, cellule, hauteurLigne, police, deuxLignes, maxChars }) {
        const entete = [{ text: 'Heure', style: { fontSize: police, bold: true, fillColor: '#eeeeee', alignment: 'center' } }];
        entetes.forEach(t => entete.push({ text: t, style: { fontSize: police, bold: true, fillColor: '#eeeeee', alignment: 'center' } }));
        const body = [entete];

        lignes.forEach((libelle, r) => {
            const row = [{ text: libelle, fontSize: police, bold: true, alignment: 'center', fillColor: '#fafafa', margin: [1, 1] }];
            entetes.forEach((_, c) => {
                const cell = cellule(c, r);
                if (cell) {
                    const brut = deuxLignes ? (cell.texte || cell.texteCourt) : (cell.texteCourt || cell.texte);
                    row.push({
                        text: this._tronquerLignes(brut, maxChars, deuxLignes ? 2 : 1),
                        fillColor: cell.couleur,
                        color: this._textColor(cell.couleur),
                        fontSize: police,
                        alignment: 'center',
                        margin: [1, 1],
                        ...(cell.span > 1 ? { rowSpan: cell.span } : {}),
                    });
                } else {
                    row.push({ text: '', fontSize: police });
                }
            });
            body.push(row);
        });

        // Les lignes couvertes par un rowSpan doivent rester vides (pdfmake l'exige).
        lignes.forEach((_, r) => {
            entetes.forEach((_, c) => {
                const cell = cellule(c, r);
                if (cell && cell.span > 1) {
                    for (let s = 1; s < cell.span && r + s < body.length - 1; s++) {
                        body[r + 1 + s][c + 1] = { text: '', fontSize: police };
                    }
                }
            });
        });

        return {
            table: {
                headerRows: 1,
                dontBreakRows: true,
                widths: ['auto', ...entetes.map(() => '*')],
                // pdfmake ajoute ~5 pt de marges de cellule à la hauteur demandée : on les retire ici
                // pour que la ligne fasse réellement `hauteurLigne` (mesuré le 18/10/2026).
                heights: (i) => (i === 0 ? Math.max(8, PRINT_ENTETE_PT - 5) : Math.max(6, hauteurLigne - 5.1)),
                body,
            },
        };
    },

    /** Légende des couleurs (même rendu qu'avant). */
    _legendParts(couleurs) {
        const entries = Object.entries(couleurs).filter(([, c]) => c && c !== '#fff');
        if (!entries.length) return [];
        return [
            { text: 'Légende :', style: 'legendTitle', margin: [0, 8, 0, 2] },
            {
                table: {
                    body: [entries.map(([type, c]) => ({
                        text: ` ${type} `, fillColor: c, color: this._textColor(c),
                        alignment: 'center', margin: [3, 1], fontSize: 7,
                    }))],
                },
                layout: 'noBorders',
                margin: [0, 0, 0, 8],
            },
        ];
    },

    /* ═══════════════════════════════════════════
       Document
       ═══════════════════════════════════════════ */

    /**
     * Enveloppe standard : page A4, marges, bandeaux, métadonnées, styles.
     * `contenu` est le contenu de la page (titre et grilles) ; la LÉGENDE des couleurs n'en
     * fait plus partie : elle est passée par `legende` et vit dans le pied de page (28/10/2026).
     * `styles` complète les styles de base sans les remplacer (fiches, tâches, suivi).
     */
    _docStandard({ cle, titre, sousTitre, orientation, contenu, contexte, styles, legende }) {
        const reglages = this._reglagesImpression(cle);
        const marge = reglages.marges || PRINT_MARGE_MM;
        const haut = marge + (reglages.haut.actif ? PRINT_BANDEAU_MM : 0);
        // La légende des couleurs occupe la marge basse : la place qu'elle prend est donc
        // EXACTE (une marge se compte, un bloc de contenu se devine). Le contenu ne peut plus
        // être poussé par elle, et elle ne peut plus se retrouver seule sur une page.
        // Une légende VIDE (ou dont toutes les couleurs sont blanches, que `_legendParts`
        // écarte) ne réserve rien et n'ouvre pas de pied de page : la réserve et le footer
        // doivent lire la MÊME condition, sinon une marge fantôme change la pagination.
        const aLegende = this._aLegende(legende);
        const bas = marge + (reglages.bas.actif ? PRINT_BANDEAU_MM : 0) + (aLegende ? PRINT_LEGENDE_MM : 0);
        const etab = this._contexteEtablissement();
        const ctx = {
            nom: '', classe: '', semaine: '', annee: etab.annee, etablissement: etab.etablissement,
            ...(contexte || {}), titre: contexte && contexte.titre ? contexte.titre : titre,
        };
        const def = {
            pageSize: 'A4',
            pageOrientation: reglages.orientation || orientation || 'portrait',
            // pdfmake compte les marges en POINTS : le réglage de l'utilisateur est en mm.
            // Sans cette conversion, « 10 mm » donnait 10 pt, soit 3,5 mm réels (corrigé le
            // 18/10/2026 — la zone de sécurité annoncée n'existait pas).
            pageMargins: [marge * PT_PAR_MM, haut * PT_PAR_MM, marge * PT_PAR_MM, bas * PT_PAR_MM],
            info: {
                title: titre + (sousTitre ? ' — ' + sousTitre : ''),
                author: 'Calulis',
                subject: 'Calulis — document de vie scolaire',
                creator: 'Calulis',
            },
            language: 'fr-FR',
            content: contenu,
            defaultStyle: { fontSize: 9 },
            styles: { ...BASE_STYLES, ...(styles || {}) },
        };
        // Ne garder que les éléments que CE document sait remplir : `classe` n'est fourni
        // par aucun builder, et `nom`/`semaine` n'ont pas de valeur partout. Une case cochée
        // qui ne produit rien est un réglage qui ment (constat de revue du 18/10/2026).
        const permis = typeof this._elementsBandeau === 'function' ? this._elementsBandeau(cle) : null;
        const filtrerBandeau = (conf) => ({
            ...conf,
            elements: (conf.elements || []).filter(e => !permis || permis.includes(e)),
        });
        const bandes = { ...reglages, haut: filtrerBandeau(reglages.haut), bas: filtrerBandeau(reglages.bas) };
        if (reglages.haut.actif) {
            def.header = (page, total) => this._bandeauNoeud('haut', bandes, { ...ctx, page, total });
        }
        if (reglages.bas.actif || aLegende) {
            def.footer = (page, total) => {
                const bandeau = reglages.bas.actif
                    ? this._bandeauNoeud('bas', bandes, { ...ctx, page, total })
                    : null;
                const legendeParts = aLegende ? this._legendParts(legende) : [];
                if (!legendeParts.length) return bandeau;
                // Le pied de page est posé à x=0 (bord papier) : sans cette marge, la légende
                // s'imprimait collée au bord, hors de la zone de sécurité (mesuré au PDF le
                // 28/10/2026 : xMin = 0 pt).
                return {
                    stack: [
                        { stack: legendeParts, margin: [marge * PT_PAR_MM, 0, marge * PT_PAR_MM, 0] },
                        ...(bandeau && bandeau.columns ? [bandeau] : []),
                    ],
                };
            };
        }
        return def;
    },

    /** Bloc titre + sous-titre d'une page de document. */
    _entetePage(titre, sousTitre) {
        const bloc = [{ text: titre, style: 'header' }];
        if (sousTitre) bloc.push({ text: sousTitre, style: 'subheader' });
        return bloc;
    },

    /* ═══════════════════════════════════════════
       Nom du fichier (une seule convention)
       ═══════════════════════════════════════════ */

    /** Date du jour AAAA-MM-JJ en heure LOCALE : `toISOString()` datait la veille après minuit. */
    _dateISO() {
        const d = new Date();
        const p = (n) => String(n).padStart(2, '0');
        return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
    },

    /** Fragment de nom de fichier : minuscules, sans accent, séparé par des tirets. */
    _slug(txt) {
        return String(txt || 'document').normalize('NFD').replace(/[\u0300-\u036f]/g, '')
            .toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'document';
    },

    /**
     * Nom de fichier commun aux dix sorties :
     *   calulis-<document>-<détail>-<semaine>-AAAA-MM-JJ.<extension>
     * ASCII seulement (ni accent, ni espace, ni « (2) ») : un nom qui reste lisible dans un
     * dossier partagé et qui ne dépend pas du navigateur. Le préfixe commun les range ensemble.
     */
    _nomFichier(cle, { detail = '', semaine = '', extension = 'pdf' } = {}) {
        const morceaux = [
            'calulis',
            PRINT_NOM_FICHIER[cle] || this._slug(cle),
            detail && this._slug(detail).slice(0, 60),
            semaine && this._slug(semaine),
            this._dateISO(),
        ];
        return morceaux.filter(Boolean).join('-') + '.' + extension;
    },

    /* ═══════════════════════════════════════════
       Document « liste » (tâches, suivi)
       ═══════════════════════════════════════════ */

    /**
     * Document de type LISTE : mêmes styles communs, même pied, même page que le socle.
     * Tâches et suivi avaient deux copies de ce squelette (dette du 18/10/2026) : une
     * correction de mise en page devait être faite deux fois, ou était oubliée une fois.
     */
    _docListe({ cle, titre, sousTitre, contenu, styles, pied }) {
        if (pied) contenu.push({ text: pied, style: 'pied' });
        return this._docStandard({
            cle,
            titre,
            sousTitre,
            orientation: 'portrait',
            contenu,
            styles: {
                // `_entetePage` pose le style `subheader` : une clé `sousTitre` ici ne
                // s'appliquait à rien (relevé par la revue du 18/10/2026).
                subheader: { fontSize: 9, color: '#555555', margin: [0, 0, 0, 12] },
                pied: { fontSize: 8, color: '#777777', margin: [0, 16, 0, 0] },
                ...(styles || {}),
            },
        });
    },

    /**
     * Bouton d'impression d'un document « liste » : sélection vide signalée, aperçu nommé,
     * message d'aide identique. Le même geste, écrit une fois.
     */
    _imprimerListe(apercuSeul, { cle, selection, messageVide, docDef }) {
        if (!selection.length) {
            Toast.show(messageVide, 'error');
            return;
        }
        const def = typeof docDef === 'function' ? docDef() : docDef;
        Print._showPreview(def, Print._nomFichier(cle));
        if (!apercuSeul) {
            Toast.show('Aperçu prêt : le bouton « Télécharger le PDF » se trouve en bas de la fenêtre.', 'success');
        }
    },

    /**
     * Saut de page explicite, avec changement d'orientation si demandé.
     * pdfmake change réellement de format quand le nœud qui porte `pageBreak: 'before'`
     * porte aussi `pageOrientation` (vérifié dans le moteur livré, 18/10/2026) — c'est ce
     * qui permet aux statistiques d'être portrait OU paysage SELON LE BLOC.
     */
    _sautPage(orientation) {
        return orientation
            ? { text: '', pageBreak: 'before', pageOrientation: orientation }
            : { text: '', pageBreak: 'before' };
    },

    /* ═══════════════════════════════════════════
       Helpers de grille
       ═══════════════════════════════════════════ */

    _genTimeSlots(debut, fin, interval) {
        const slots = [];
        const [dh, dm] = debut.split(':').map(Number);
        const [fh, fm] = fin.split(':').map(Number);
        let min = dh * 60 + dm;
        const endMin = fh * 60 + fm;
        while (min < endMin) {
            slots.push(`${String(Math.floor(min / 60)).padStart(2, '0')}:${String(min % 60).padStart(2, '0')}`);
            min += interval;
        }
        return slots;
    },

    _horaires() {
        return (this._params && this._params.horaires) || { debut: '08:30', fin: '16:30', duree_creneau: 15 };
    },

    /** « Semaine 12 · 06/10 → 10/10 » (le numéro scolaire, pas l'identifiant de base). */
    _semaineLabel(semaineId) {
        if (!semaineId) return 'Semaine type';
        const s = (this._semaines || []).find(x => x.id === semaineId);
        if (!s) return 'Semaine type';   // jamais l'identifiant de base dans un document
        let n = null;
        try { n = getSchoolWeekNumber(s, this._semaines); } catch (e) { n = null; }
        let dates = '';
        if (s.date_debut && s.date_fin) {
            // « du 30/11 au 04/12 » quand les deux dates sont dans la même année (spec) ;
            // l'année n'est répétée que si la semaine chevauche deux années.
            const memeAnnee = String(s.date_debut).slice(0, 4) === String(s.date_fin).slice(0, 4);
            const court = (d) => {
                const f = formatDate(d);
                return memeAnnee ? f.replace(/\/\d{4}$/, '') : f;
            };
            dates = ` · du ${court(s.date_debut)} au ${court(s.date_fin)}`;
        }
        return (n ? `Semaine ${n}` : 'Semaine') + dates;
    },

});
