/**
 * Calulis — Fiches de renseignements / urgence (documents de la page Impression)
 * Greffé sur l'objet Print. Génère un PDF A4 portrait par élève (ou en lot, une fiche par page).
 *
 * Depuis la phase 3 (18/10/2026), la page, les marges, les bandeaux et les métadonnées
 * viennent du socle (`print-socle.js`) : ce fichier ne décide plus que du CONTENU d'une fiche.
 */
Object.assign(Print, {

  async _generateFiches(typeForce, demande) {
    if (demande == null) demande = this._invaliderApercu();
    // Le type vient du document choisi dans la liste (fiche d'urgence / fiche de renseignements).
    const type = typeForce || 'urgence';
    const sel = document.getElementById('print-fiche-eleves');
    if (!sel) return;
    const ids = Array.from(sel.selectedOptions).map(o => parseInt(o.value));
    if (!ids.length) { Modal.alert('Erreur', 'Sélectionnez au moins un élève.'); return; }

    const btn = document.getElementById('btn-print-generate');
    btn.disabled = true; btn.textContent = '⏳ Génération…';
    try {
      const eleves = await API.get('listes.php?ids=' + ids.join(','));
      if (demande !== this._demande) return;   // une autre génération a pris la main
      const ordered = ids.map(id => (eleves || []).find(e => e.id === id)).filter(Boolean);
      if (!ordered.length) { Modal.alert('Erreur', 'Aucun élève trouvé.'); return; }
      // La fiche élève a besoin de ce que listes.php ne porte pas : PEC, réunions, projets.
      const tout = !!(document.getElementById('print-fiche-tout')?.checked);
      const extras = type === 'eleve' ? await this._ficheEleveExtras(ordered, tout) : null;
      if (demande !== this._demande) return;
      const def = this._buildFichesDoc(type, ordered, extras);
      const fname = this._nomFichier(type === 'eleve' ? 'fiche_eleve'
        : (type === 'urgence' ? 'fiche_urgence' : 'fiche_renseignements'));
      if (def) this._showPreview(def, fname);
    } catch (e) {
      // Sans ce catch, un échec de `listes.php` laissait l'ancien aperçu à l'écran, sans un mot.
      if (demande !== this._demande) return;
      console.error('[Print] fiches error:', e);
      if (typeof Modal !== 'undefined' && Modal.alert) {
        Modal.alert('Erreur', 'Impossible de générer les fiches : ' + (e.message || 'Erreur inconnue'));
      }
    } finally {
      btn.disabled = false; btn.textContent = '↻ Actualiser';
    }
  },

  _buildFichesDoc(type, eleves, extras) {
    const contenu = [];
    eleves.forEach((e, i) => {
      if (i > 0) contenu.push(this._sautPage('portrait'));
      if (type === 'eleve') contenu.push(this._buildFicheEleve(e, (extras || [])[i]));
      else contenu.push(type === 'urgence' ? this._buildFicheUrgence(e) : this._buildFicheRenseignement(e));
    });
    const TITRES = { urgence: 'Fiche d\'urgence', renseignement: 'Fiche de renseignements', eleve: 'Fiche élève (une page)' };
    const CLES = { urgence: 'fiche_urgence', renseignement: 'fiche_renseignements', eleve: 'fiche_eleve' };
    const titre = TITRES[type] || TITRES.urgence;
    const seule = eleves.length === 1 ? [eleves[0].prenom, eleves[0].nom].filter(Boolean).join(' ') : '';
    const def = this._docStandard({
      cle: CLES[type] || 'fiche_urgence',
      titre,
      sousTitre: seule || `${eleves.length} fiches`,
      orientation: 'portrait',
      contenu,
      contexte: { nom: seule, titre },
      styles: {
        header: { fontSize: 15, bold: true, alignment: 'center' },
        name: { fontSize: 12, bold: true, alignment: 'center', margin: [0, 2, 0, 6] },
        muted: { fontSize: 8, italics: true, color: '#777', alignment: 'center', margin: [0, 0, 0, 8] },
        sectionTitle: { fontSize: 10, bold: true, margin: [0, 10, 0, 3], color: '#2c3e50' },
        kvLabel: { fontSize: 9, bold: true, color: '#555' },
        kvValue: { fontSize: 9 },
        th: { fontSize: 8, bold: true, fillColor: '#eee', alignment: 'center' },
      },
    });
    // Une fiche est TOUJOURS en portrait (spec) : un ancien réglage « paysage » ne doit pas
    // donner un PDF à orientation mixte (page 1 paysage, suivantes portrait).
    def.pageOrientation = 'portrait';
    return def;
  },

  _kv(label, value) {
    return { columns: [ { text: label, style: 'kvLabel', width: 110 }, { text: value || '—', style: 'kvValue', width: '*' } ], margin: [0, 1, 0, 1] };
  },

  _repsFor(e) {
    const reps = e.representants || [];
    if (!reps.length) return { text: 'Aucun représentant renseigné.', style: 'muted', alignment: 'left' };
    const body = [[
      { text: 'Nom', style: 'th' }, { text: 'Lien', style: 'th' }, { text: 'Téléphone', style: 'th' }, { text: 'Urgence', style: 'th' },
    ]];
    reps.forEach(r => body.push([
      { text: (r.prenom ? r.prenom + ' ' : '') + (r.nom || '') },
      { text: r.lien || '' },
      { text: (r.telephone && r.telephone !== '0') ? r.telephone : '' },
      { text: (r.telephone_urgence && r.telephone_urgence !== '0') ? 'Oui' : '' },
    ]));
    return { table: { headerRows: 1, widths: [90, 60, 80, 40], body }, fontSize: 8 };
  },

  _droitText(d) {
    const m = { autorise: 'Autorisé', refuse: 'Refusé', limite: 'Limité', en_attente: 'En attente', retire: 'Retiré' };
    return d ? (m[d.statut] || d.statut) : 'Non renseigné';
  },

  /* ---- Fiche élève en une page (31/10/2026) ---------------------------------
     Règles de contenu arrêtées avec Jérôme, jamais devinées :
     — ESS : les DEUX DERNIÈRES et la PROCHAINE (les autres restent sur la fiche MDPH) ;
     — projets : ceux qui courent et ceux de l’année écoulée, avec l’option
       « Tout le parcours » qui montre tout depuis l’entrée ;
     — « personnes à prévenir » : les téléphones d’URGENCE des représentants légaux,
       et rien d’autre (ni adresse, ni courriel, ni téléphone fixe).
     Une donnée absente ne s’invente pas : la ligne se tait et le dit. */

  /** Ce que listes.php ne porte pas : PEC, réunions, projets, annuaire des adultes. */
  async _ficheEleveExtras(eleves, toutLeParcours) {
    if (!this._adultesParId) {
      let adultes = [];
      try { adultes = (await API.get('adultes.php')) || []; } catch (e) { adultes = []; }
      this._adultesParId = {};
      adultes.forEach(a => { this._adultesParId[a.id] = a; });
    }
    const extras = [];
    for (const e of eleves) {
      // Un endpoint muet ne doit pas vider la fiche : chaque appel tombe sur une liste vide.
      // Les réunions et les projets se lisent SANS le filtre d'année : « les deux dernières
      // ESS » peuvent appartenir à l'année précédente, et un projet court sur deux années.
      // La PEC, elle, reste celle de l'année en cours (une PEC de l'an dernier n'est plus vraie).
      const [pec, reus, projets, aesh] = await Promise.all([
        API.get('pec_eleves.php?eleve_id=' + e.id).catch(() => []),
        API.get('reunions.php?eleve_id=' + e.id, { sansAnnee: true }).catch(() => []),
        API.get('eleve_projets.php?eleve_id=' + e.id, { sansAnnee: true }).catch(() => []),
        API.get('aesh_eleves.php?eleve_id=' + e.id, { sansAnnee: true }).catch(() => []),
      ]);
      extras.push({ pec: pec || [], reus: reus || [], projets: projets || [], aesh: aesh || [],
                    adultes: this._adultesParId, tout: !!toutLeParcours });
    }
    return extras;
  },

  /** Les ESS d’un élève : les deux dernières passées, la prochaine. */
  _essDe(reus, aujourdhui) {
    const auj = aujourdhui || new Date().toISOString().slice(0, 10);
    const ess = (reus || [])
      .filter(r => String(r.type || '').trim().toUpperCase() === 'ESS')
      .map(r => ({
        date: String(r.date_reunion || '').slice(0, 10),
        heure: r.heure ? String(r.heure).slice(0, 5) : '',
        lieu: r.lieu || '',
      }))
      .filter(r => /^\d{4}-\d{2}-\d{2}$/.test(r.date))
      .sort((a, b) => (a.date < b.date ? -1 : (a.date > b.date ? 1 : 0)));
    return {
      passees: ess.filter(r => r.date <= auj).slice(-2),
      prochaine: ess.find(r => r.date > auj) || null,
    };
  },

  /** Les projets à montrer : ce qui court et l’année écoulée — ou tout le parcours. */
  _projetsDe(projets, tout, aujourdhui) {
    const auj = aujourdhui || new Date().toISOString().slice(0, 10);
    const ilYaUnAn = new Date(new Date(auj + 'T00:00:00Z').getTime() - 365 * 86400000).toISOString().slice(0, 10);
    const liste = (projets || [])
      .map(p => ({
        nom: p.nom || p.projet_nom || '',
        debut: String(p.date_debut || '').slice(0, 10),
        fin: String(p.date_fin || '').slice(0, 10),
      }))
      .filter(p => p.nom)
      .sort((a, b) => (a.debut < b.debut ? 1 : (a.debut > b.debut ? -1 : 0)));
    if (tout) return liste;
    return liste.filter(p => !p.fin || p.fin >= ilYaUnAn);
  },

  /** « 12/03/2026 à 14:00 — salle 2 » : une date d’ESS, lisible. */
  _dateEss(r) {
    return formatDate(r.date) + (r.heure ? ' à ' + r.heure : '') + (r.lieu ? ' — ' + r.lieu : '');
  },

  /** Une rubrique de la fiche : ses lignes, ou le mot qui dit qu’il n’y en a pas. */
  _rubriqueFiche(titre, lignes, vide) {
    const items = (lignes || []).filter(Boolean);
    if (!items.length) return [{ text: titre, style: 'sectionTitle' }, { text: vide || '—', fontSize: 9, color: '#777' }];
    return [{ text: titre, style: 'sectionTitle' }, { ul: items, fontSize: 9, margin: [10, 0, 0, 0] }];
  },

  _buildFicheEleve(e, x) {
    const d = x || { pec: [], reus: [], projets: [], adultes: {}, tout: false };
    const ess = this._essDe(d.reus);
    const projets = this._projetsDe(d.projets, d.tout);

    // Adultes : les AESH de la fiche (tableau aesh_eleves) ; à défaut, les champs hérités de
    // l'élève. Le 31/10/2026 la démo l'a montré : lire les seuls champs hérités laissait la
    // rubrique « Qui accompagne » VIDE alors que l'AESH était bien saisie.
    const adultes = [];
    const aeshTable = (d.aesh || []).map(a => ((a.type ? a.type + ' — ' : '') + (a.nom || '')
      + (a.heures ? ' (' + a.heures + ')' : '')).trim()).filter(Boolean);
    if (aeshTable.length) adultes.push(...aeshTable);
    else if (e.aesh_nom) {
      adultes.push((e.aesh_type ? e.aesh_type + ' — ' : '') + e.aesh_nom
        + (e.aesh_heures ? ' (' + e.aesh_heures + ')' : ''));
    }
    const ref = (d.adultes || {})[e.enseignant_referent_id];
    const refNom = ref ? [ref.prenom, ref.nom].filter(Boolean).join(' ') : '';
    if (refNom) adultes.push('Enseignant référent — ' + refNom);

    // PEC : spécialité · organisme · fréquence · durée, puis le créneau s’il est relié.
    const pec = (d.pec || []).map(p => {
      let t = [p.specialite, p.organisme, p.frequence, p.duree].filter(Boolean).join(' · ');
      if (!t) t = 'Prise en charge';
      if (p.jour && p.heure_debut) {
        const jour = String(p.jour);
        t += ' — ' + jour.charAt(0).toUpperCase() + jour.slice(1) + ' ' + String(p.heure_debut).slice(0, 5);
      }
      if (Number(p.quitte_etablissement) === 1) t += ' (hors école)';
      return t;
    });

    // Projets : au plus huit lignes, pour que la fiche tienne sur une page.
    const projetsLignes = projets.slice(0, 8).map(p => {
      let quand = 'en cours';
      if (p.fin) quand = 'du ' + formatDate(p.debut) + ' au ' + formatDate(p.fin);
      else if (p.debut) quand = 'depuis le ' + formatDate(p.debut) + ' — en cours';
      return p.nom + ' (' + quand + ')';
    });
    if (projets.length > 8) projetsLignes.push('… et ' + (projets.length - 8) + ' autres');

    // Personnes à prévenir : uniquement les numéros d’URGENCE des représentants légaux.
    const prevenir = (e.representants || [])
      .filter(r => r.telephone_urgence && String(r.telephone_urgence) !== '0')
      .map(r => {
        const nom = [r.prenom, r.nom].filter(Boolean).join(' ');
        return (nom || 'Représentant légal') + (r.lien ? ' (' + r.lien + ')' : '') + ' — ' + r.telephone_urgence;
      });

    return {
      stack: [
        { text: 'FICHE ÉLÈVE', style: 'header' },
        { text: [e.prenom, e.nom].filter(Boolean).join(' '), style: 'name' },
        { text: 'Une page pour la vie scolaire. Ne remplace ni le PPS ni le GEVA-Sco.', style: 'muted' },
        this._kv('Naissance', formatDate(e.date_naissance)),
        this._kv('Classe', e.classe_nom || e.classe),
        this._kv('ULIS', e.ulis ? 'Oui' : 'Non'),
        this._kv('Entrée ULIS', e.date_entree_ulis ? formatDate(e.date_entree_ulis) : ''),
        this._kv('N° dossier MDPH', e.numero_dossier_mdph),
        ...this._rubriqueFiche('Qui accompagne', adultes, 'Aucun accompagnant renseigné.'),
        ...this._rubriqueFiche('Prises en charge (PEC)', pec, 'Aucune prise en charge renseignée.'),
        { text: 'Équipes de suivi (ESS)', style: 'sectionTitle' },
        ess.passees.length
          ? { ul: ess.passees.map(r => 'Passée — ' + this._dateEss(r)), fontSize: 9, margin: [10, 0, 0, 0] }
          : { text: 'Aucune ESS passée enregistrée.', fontSize: 9, color: '#777' },
        { text: ess.prochaine ? 'Prochaine — ' + this._dateEss(ess.prochaine) : 'Prochaine — aucune programmée',
          fontSize: 9, bold: !!ess.prochaine, margin: [10, 1, 0, 0] },
        ...this._rubriqueFiche('Projets', projetsLignes, 'Aucun projet en cours ni l’année écoulée.'),
        { text: d.tout ? 'Tout le parcours.' : 'Projets en cours et de l’année écoulée — l’option « Tout le parcours » montre les précédents.',
          fontSize: 7.5, italics: true, color: '#777', margin: [10, 1, 0, 0] },
        ...this._rubriqueFiche('Personnes à prévenir', prevenir, 'Aucun téléphone d’urgence renseigné.'),
        { text: 'Téléphones d’urgence des représentants légaux uniquement — ni adresse ni courriel sur cette fiche.',
          fontSize: 7.5, italics: true, color: '#777', margin: [10, 1, 0, 0] },
      ],
    };
  },

  _buildFicheUrgence(e) {
    return {
      stack: [
        { text: 'FICHE D\'URGENCE', style: 'header' },
        { text: (e.nom || '') + ' ' + (e.prenom || ''), style: 'name' },
        { text: 'Document confidentiel — précautions pour la vie scolaire uniquement. À détruire en fin d\'année.', style: 'muted' },
        this._kv('Classe', e.classe_nom || e.classe),
        this._kv('Naissance', formatDate(e.date_naissance)),
        this._kv('Groupe', e.groupe),
        { text: 'Représentants légaux', style: 'sectionTitle' },
        this._repsFor(e),
        { text: 'Santé & vie scolaire', style: 'sectionTitle' },
        this._kv('Allergies', e.allergies),
        this._kv('Régime alimentaire', e.regime_alimentaire),
        this._kv('PAI', e.pai ? 'Oui' : 'Non'),
        this._kv('Précautions', e.precautions_medicales),
        this._kv('Transport', e.transport),
        this._kv('Cantine', e.cantine ? 'Oui' : 'Non'),
        this._kv('Droit à l\'image', this._droitText(e.droit_image)),
      ],
      unbreakable: true,
    };
  },

  _buildFicheRenseignement(e) {
    const reps = e.representants || [];
    const repEmail = reps.map(r => r.email).filter(Boolean).join(', ');
    return {
      stack: [
        { text: 'FICHE DE RENSEIGNEMENTS', style: 'header' },
        { text: (e.nom || '') + ' ' + (e.prenom || ''), style: 'name' },
        { text: 'Année scolaire en cours — à compléter et signer par la famille.', style: 'muted' },
        { text: 'Identité', style: 'sectionTitle' },
        this._kv('Nom', e.nom), this._kv('Prénom', e.prenom),
        this._kv('Date de naissance', formatDate(e.date_naissance)),
        this._kv('Numéro INE', e.ine), this._kv('N° dossier MDPH', e.numero_dossier_mdph),
        { text: 'Scolarité', style: 'sectionTitle' },
        this._kv('Classe', e.classe_nom || e.classe), this._kv('Établissement', e.etablissement_nom),
        this._kv('ULIS', e.ulis ? 'Oui' : 'Non'), this._kv('Groupe', e.groupe),
        { text: 'Représentants légaux', style: 'sectionTitle' },
        this._repsFor(e),
        this._kv('Email (représentants)', repEmail),
        this._kv('Adresse', e.adresse),
        { text: 'Divers', style: 'sectionTitle' },
        this._kv('Droit à l\'image', this._droitText(e.droit_image)),
      ],
      unbreakable: true,
    };
  },
});