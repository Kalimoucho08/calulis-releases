/**
 * Calulis — Calendrier unique de l'année (décisions 8.1 à 8.5 et 15.2)
 *
 * POURQUOI CET ÉCRAN. Périodes, vacances et événements vivaient séparément. Ici ils sont
 * réunis sur une page pleine, l'année entière visible, avec le calendrier officiel à côté
 * pour comparer (8.1).
 *
 * CE QU'UN JOUR PEUT DIRE (15.2)
 *   - UN SEUL statut officiel : scolaire, vacances, férié, fermeture. Il décide des calculs.
 *   - PLUSIEURS activités superposables, sur une liste fermée : stage, réunion,
 *     commémoration, sortie, banalisée, autre — à la journée ou à la demi-journée. Elles
 *     s'affichent et s'impriment, elles ne changent rien aux calculs (8.3).
 *   - UN commentaire libre.
 * Le statut absent se DÉDUIT des semaines de vacances et des jours fériés : une année
 * vierge s'affiche sans qu'on ait à saisir 365 lignes.
 *
 * TROIS ENTRÉES (8.4) : le calendrier officiel (avec Internet), un fichier .ics, la saisie
 * manuelle complète. Un même fichier .ics importé deux fois ne crée aucun doublon.
 */
const Calendrier = {

    _annee: '',
    _annees: [],
    _donnees: null,

    _moisFr: ['janvier', 'février', 'mars', 'avril', 'mai', 'juin',
              'juillet', 'août', 'septembre', 'octobre', 'novembre', 'décembre'],
    _joursFr: ['lun', 'mar', 'mer', 'jeu', 'ven', 'sam', 'dim'],

    _statuts: [
        { cle: 'scolaire',  libelle: 'Scolaire' },
        { cle: 'vacances',  libelle: 'Vacances' },
        { cle: 'ferie',     libelle: 'Férié' },
        { cle: 'fermeture', libelle: 'Fermeture' },
    ],

    /** Liste FERMÉE des activités (15.2). */
    _typesActivite: [
        { cle: 'stage',        libelle: 'Stage',        icone: '🧰' },
        { cle: 'reunion',      libelle: 'Réunion',      icone: '🤝' },
        { cle: 'commemoration', libelle: 'Commémoration', icone: '🏛️' },
        { cle: 'sortie',       libelle: 'Sortie',       icone: '🚌' },
        { cle: 'banalisee',    libelle: 'Journée banalisée', icone: '📌' },
        { cle: 'autre',        libelle: 'Autre',        icone: '•' },
    ],

    _demiJournees: [
        { cle: '',           libelle: 'Toute la journée' },
        { cle: 'matin',      libelle: 'Matin' },
        { cle: 'apres_midi', libelle: 'Après-midi' },
    ],

    async render() {
        const view = document.getElementById('view-calendrier');
        view.innerHTML = '<p class="text-muted" style="padding:24px">Chargement du calendrier…</p>';

        if (!this._annee) {
            const active = (typeof State !== 'undefined' && State.get('annee_active')) ? State.get('annee_active') : null;
            this._annee = active ? String(active.id) : '';
        }

        try {
            const [annees, donnees] = await Promise.all([
                API.get('annees_scolaires.php'),
                this._annee ? API.get(this._url()) : Promise.resolve(null),
            ]);
            this._annees = Array.isArray(annees) ? annees : [];
            if (!this._annee && this._annees.length) {
                this._annee = String(this._annees[0].id);
                this._donnees = await API.get(this._url());
            } else {
                this._donnees = donnees;
            }
        } catch (e) {
            console.error('[Calendrier] chargement impossible:', e);
            view.innerHTML = '<p class="text-muted" style="padding:24px">Impossible de charger le calendrier. ' +
                'Vérifiez que la base est démarrée.</p>';
            return;
        }
        this._dessiner();
    },

    _url() {
        return 'calendrier.php?annee_scolaire_id=' + encodeURIComponent(this._annee);
    },

    async _charger() {
        if (!this._annee) return;
        this._donnees = await API.get(this._url());
        this._dessiner();
    },

    /* ------------------------------------------------------------------ */
    /* Ce qu'un jour contient — statut déduit, activités, événements        */
    /* ------------------------------------------------------------------ */

    _dansVacances(date) {
        const v = (this._donnees && this._donnees.vacances) || [];
        return v.some(x => date >= x.date_debut && date <= x.date_fin);
    },

    _evenementsDe(date) {
        const e = (this._donnees && this._donnees.evenements) || [];
        return e.filter(x => x.date_debut && x.date_fin && x.date_debut <= date && x.date_fin >= date);
    },

    _estFerie(date) {
        return this._evenementsDe(date).some(x => String(x.categorie || '').toLowerCase().includes('feri'));
    },

    _activitesDe(date) {
        const a = (this._donnees && this._donnees.activites) || [];
        return a.filter(x => x.date_jour === date);
    },

    /**
     * Un jour NON TRAVAILLÉ de l'établissement (samedi, dimanche, et le mercredi quand il
     * est décoché dans Paramètres → Jours affichés). L'écran ne le distinguait pas : le
     * réglage était ignoré ici alors qu'il pilote l'emploi du temps (défaut du 28/10/2026).
     */
    _nonTravaille(date) {
        const ref = this._donnees && this._donnees.jours_travailles;
        // Même repli que le réglage par défaut de l'application (calulis-vierge.sql, setup.php) :
        // le mercredi n'est pas travaillé tant que l'école ne l'a pas coché (revue 28/10/2026).
        const jours = (Array.isArray(ref) && ref.length) ? ref
            : ['lundi', 'mardi', 'jeudi', 'vendredi'];
        const noms = ['dimanche', 'lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi'];
        const d = new Date(date + 'T00:00:00');
        return !jours.includes(noms[d.getDay()]);
    },

    /** Le jour où l'on est — mis en évidence, et ANNONCÉ (jamais par la couleur seule). */
    _estAujourdhui(date) {
        const n = new Date();
        const iso = n.getFullYear() + '-' + String(n.getMonth() + 1).padStart(2, '0') + '-' + String(n.getDate()).padStart(2, '0');
        return date === iso;
    },

    /** Le statut d'un jour : la ligne écrite d'abord, sinon la déduction. */
    _statutDe(date) {
        const jours = (this._donnees && this._donnees.jours) || [];
        const j = jours.find(x => x.date_jour === date);
        if (j && j.statut) return j.statut;
        if (this._dansVacances(date)) return 'vacances';
        if (this._estFerie(date)) return 'ferie';
        return 'scolaire';
    },

    _commentaireDe(date) {
        const jours = (this._donnees && this._donnees.jours) || [];
        const j = jours.find(x => x.date_jour === date);
        return (j && j.commentaire) || '';
    },

    _libelleStatut(cle) {
        const s = this._statuts.find(x => x.cle === cle);
        return s ? s.libelle : cle;
    },

    _libelleActivite(cle) {
        const t = this._typesActivite.find(x => x.cle === cle);
        return t ? t.libelle : cle;
    },

    _iconeActivite(cle) {
        const t = this._typesActivite.find(x => x.cle === cle);
        return t ? t.icone : '•';
    },

    _dateFr(iso, long = false) {
        if (!iso) return '';
        const d = new Date(iso + 'T00:00:00');
        if (isNaN(d.getTime())) return iso;
        return long
            ? new Intl.DateTimeFormat('fr-FR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' }).format(d)
            : new Intl.DateTimeFormat('fr-FR', { day: 'numeric', month: 'long' }).format(d);
    },

    /* ------------------------------------------------------------------ */
    /* Dessin                                                              */
    /* ------------------------------------------------------------------ */

    _dessiner() {
        const view = document.getElementById('view-calendrier');
        if (!this._donnees || !this._donnees.annee) {
            view.innerHTML = '<p class="text-muted" style="padding:24px">Aucune année scolaire à afficher. ' +
                'Créez-en une dans Paramètres.</p>';
            return;
        }
        const optionsAnnees = this._annees.map(a =>
            '<option value="' + a.id + '"' + (String(this._annee) === String(a.id) ? ' selected' : '') + '>' +
            escapeHtml(a.nom) + '</option>').join('');

        view.innerHTML = `
        <div class="cal-entete">
            <h2 style="margin:0">Calendrier de l’année</h2>
            <div class="cal-outils">
                <label for="cal-annee" class="sr-only">Année scolaire</label>
                <select id="cal-annee" aria-label="Année scolaire">${optionsAnnees}</select>
                <button type="button" class="btn btn-secondary" id="cal-importer"
                        data-help="Importer un .ics|Un fichier .ics (vacances officielles, calendrier d’une autre application) devient des événements datés dans Calulis. Importer deux fois le même fichier ne crée aucun doublon : chaque événement garde son identifiant.">📥 Importer un .ics</button>
                <input type="file" id="cal-fichier" accept=".ics,text/calendar" hidden>
                <button type="button" class="btn btn-secondary" id="cal-aide-officiel">🌐 Calendrier officiel</button>
            </div>
        </div>

        <div class="cal-legende" aria-label="Légende des statuts">
            <span class="cal-legende-item cal-statut-scolaire">Scolaire</span>
            <span class="cal-legende-item cal-statut-vacances">Vacances</span>
            <span class="cal-legende-item cal-statut-ferie">Férié</span>
            <span class="cal-legende-item cal-statut-fermeture">Fermeture</span>
            <span class="text-muted">— cliquer sur un jour pour le modifier</span>
        </div>

        <div class="cal-corps">
            <div class="cal-grille">${this._grilleHtml()}</div>
            <aside class="cal-officiel" id="cal-officiel" aria-live="polite">
                <h3>Calendrier officiel</h3>
                <p class="text-muted">Le calendrier officiel se récupère quand Internet est disponible. Il s’affiche ici pour comparer ; « Créer les semaines » reprend ses vacances pour l’année (une année qui a déjà des semaines n’est jamais écrasée).</p>
                <div class="form-group">
                    <label for="cal-zone">Zone</label>
                    <select id="cal-zone">
                        <option value="Zone A">Zone A</option>
                        <option value="Zone B" selected>Zone B</option>
                        <option value="Zone C">Zone C</option>
                    </select>
                </div>
                <div style="display:flex;gap:8px;flex-wrap:wrap">
                    <button type="button" class="btn btn-sm btn-secondary" id="cal-officiel-charger">Récupérer</button>
                    <button type="button" class="btn btn-sm" id="cal-officiel-semaines">Créer les semaines</button>
                </div>
                <div id="cal-officiel-liste" style="margin-top:10px"></div>
            </aside>
        </div>`;

        view.querySelector('#cal-annee').addEventListener('change', async (ev) => {
            this._annee = ev.target.value;
            await this._charger();
        });
        view.querySelector('#cal-importer').addEventListener('click', () => {
            view.querySelector('#cal-fichier').click();
        });
        view.querySelector('#cal-fichier').addEventListener('change', (ev) => {
            const f = ev.target.files && ev.target.files[0];
            if (f) this._importerIcs(f).catch(e => console.error('[Calendrier] import .ics :', e));
            ev.target.value = '';
        });
        view.querySelector('#cal-aide-officiel').addEventListener('click', () => {
            const aside = document.getElementById('cal-officiel');
            if (aside) aside.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
        });
        view.querySelector('#cal-officiel-charger').addEventListener('click', () =>
            this._chargerOfficiel().catch(e => console.error('[Calendrier] officiel :', e)));
        view.querySelector('#cal-officiel-semaines').addEventListener('click', () =>
            this._creerSemaines().catch(e => console.error('[Calendrier] semaines :', e)));

        view.querySelectorAll('.cal-jour').forEach(b =>
            b.addEventListener('click', () => this._ouvrirJour(b.dataset.date)));
    },

    /** Les douze mois de l'année, lundi en premier. */
    _grilleHtml() {
        const debut = new Date(this._donnees.annee.date_debut + 'T00:00:00');
        const fin = new Date(this._donnees.annee.date_fin + 'T00:00:00');
        let curseur = new Date(debut.getFullYear(), debut.getMonth(), 1);
        const mois = [];
        while (curseur <= fin) {
            mois.push(new Date(curseur));
            curseur = new Date(curseur.getFullYear(), curseur.getMonth() + 1, 1);
        }
        return mois.map(premier => {
            const an = premier.getFullYear();
            const m = premier.getMonth();
            const nbJours = new Date(an, m + 1, 0).getDate();
            const decalage = (new Date(an, m, 1).getDay() + 6) % 7; // lundi = 0
            const cases = [];
            for (let i = 0; i < decalage; i++) cases.push('<span class="cal-vide" aria-hidden="true"></span>');
            for (let j = 1; j <= nbJours; j++) {
                const iso = an + '-' + String(m + 1).padStart(2, '0') + '-' + String(j).padStart(2, '0');
                cases.push(this._jourHtml(iso, j));
            }
            return `<section class="cal-mois">
                <h3>${this._moisFr[m]} ${an}</h3>
                <div class="cal-semaine-tete">${this._joursFr.map(j => '<span>' + j + '</span>').join('')}</div>
                <div class="cal-mois-grille">${cases.join('')}</div>
            </section>`;
        }).join('');
    },

    _jourHtml(iso, numero) {
        const statut = this._statutDe(iso);
        const aujourdhui = this._estAujourdhui(iso);
        const nonTravaille = this._nonTravaille(iso);
        const activites = this._activitesDe(iso);
        const evenements = this._evenementsDe(iso).filter(x => !String(x.categorie || '').toLowerCase().includes('feri'));
        const marques = activites.map(a =>
            '<span class="cal-marque cal-marque-activite" title="' + escapeAttr(this._libelleActivite(a.type)) + '">' +
            this._iconeActivite(a.type) + '</span>').join('')
            + evenements.slice(0, 2).map(e =>
                '<span class="cal-marque cal-marque-evenement" title="' + escapeAttr(e.nom) + '"></span>').join('');
        const description = (aujourdhui ? 'Aujourd\'hui — ' : '') + this._dateFr(iso, true) + ' — ' + this._libelleStatut(statut)
            + (nonTravaille ? ' — jour non travaillé' : '')
            + (activites.length ? ' — ' + activites.map(a => this._libelleActivite(a.type)).join(', ') : '')
            + (evenements.length ? ' — ' + evenements.map(e => e.nom).join(', ') : '');
        const marqueAuj = aujourdhui ? '<span class="cal-marque-jour" title="Aujourd\'hui">auj.</span>' : '';
        return `<button type="button" class="cal-jour cal-statut-${statut}${activites.length ? ' a-activite' : ''}${nonTravaille ? ' cal-non-travaille' : ''}${aujourdhui ? ' cal-aujourdhui' : ''}"
                        data-date="${iso}"${aujourdhui ? ' aria-current="date"' : ''} aria-label="${escapeAttr(description)}" title="${escapeAttr(description)}">
                    <span class="cal-num">${numero}</span>
                    <span class="cal-marques">${marqueAuj}${marques}</span>
                </button>`;
    },

    /* ------------------------------------------------------------------ */
    /* Modifier un jour                                                    */
    /* ------------------------------------------------------------------ */

    _ouvrirJour(date) {
        const statut = this._statutDe(date);
        const explicite = ((this._donnees.jours || []).find(x => x.date_jour === date) || {}).statut || '';
        const commentaire = this._commentaireDe(date);
        const activites = this._activitesDe(date);
        const evenements = this._evenementsDe(date);

        const optionsStatut = '<option value="">Automatique (déduit)</option>' + this._statuts.map(s =>
            '<option value="' + s.cle + '"' + (explicite === s.cle ? ' selected' : '') + '>' +
            escapeHtml(s.libelle) + '</option>').join('');

        const lignesActivites = activites.length
            ? activites.map(a => `<li class="cal-act-ligne">
                    <span>${this._iconeActivite(a.type)} <strong>${escapeHtml(this._libelleActivite(a.type))}</strong>
                        ${a.demi_journee ? '· ' + escapeHtml(a.demi_journee === 'matin' ? 'matin' : 'après-midi') : '· toute la journée'}
                        ${a.libelle ? ' — ' + escapeHtml(a.libelle) : ''}</span>
                    <button type="button" class="btn btn-sm btn-danger" data-act-suppr="${a.id}"
                            aria-label="Supprimer cette activité">🗑</button>
                </li>`).join('')
            : '<li class="text-muted">Aucune activité ce jour-là.</li>';

        const optionsType = this._typesActivite.map(t =>
            '<option value="' + t.cle + '">' + escapeHtml(t.libelle) + '</option>').join('');
        const optionsDemi = this._demiJournees.map(d =>
            '<option value="' + d.cle + '">' + escapeHtml(d.libelle) + '</option>').join('');

        const evenementsHtml = evenements.length
            ? '<p class="text-muted" style="margin:0">' +
              evenements.map(e => escapeHtml(e.nom) + (e.categorie ? ' (' + escapeHtml(e.categorie) + ')' : '')).join(' · ') + '</p>'
            : '';

        Modal.open({
            title: this._dateFr(date, true),
            body: `
                <p class="text-muted" style="margin-top:0">Statut déduit actuellement : <strong>${this._libelleStatut(statut)}</strong>.
                    Un statut choisi ici est un choix explicite ; « Automatique » l’efface.</p>
                ${evenementsHtml}
                <div class="form-row">
                    <div class="form-group">
                        <label for="cal-jour-statut">Statut du jour</label>
                        <select id="cal-jour-statut">${optionsStatut}</select>
                    </div>
                </div>
                <div class="form-group">
                    <label for="cal-jour-fin">Jusqu’au (facultatif)</label>
                    <input type="date" id="cal-jour-fin" value="">
                    <small class="text-muted">Pour poser ce statut et ce commentaire sur plusieurs jours d’affilée — une semaine de vacances, une fermeture de trois jours.</small>
                </div>
                <div class="form-group">
                    <label for="cal-jour-commentaire">Commentaire</label>
                    <textarea id="cal-jour-commentaire" rows="2" maxlength="2000">${escapeHtml(commentaire)}</textarea>
                </div>
                <fieldset class="cal-activites">
                    <legend>Activités officielles (superposables)</legend>
                    <ul class="cal-act-liste" id="cal-act-liste">${lignesActivites}</ul>
                    <div class="form-row" style="align-items:flex-end">
                        <div class="form-group"><label for="cal-act-type">Type</label>
                            <select id="cal-act-type">${optionsType}</select></div>
                        <div class="form-group"><label for="cal-act-demi">Quand</label>
                            <select id="cal-act-demi">${optionsDemi}</select></div>
                        <div class="form-group" style="flex:2"><label for="cal-act-libelle">Libellé (facultatif)</label>
                            <input type="text" id="cal-act-libelle" maxlength="200" placeholder="Ex. : stage en entreprise"></div>
                        <div class="form-group" style="flex:none">
                            <button type="button" class="btn btn-secondary" id="cal-act-ajouter">＋ Ajouter</button></div>
                    </div>
                </fieldset>`,
            footer: `
                <button type="button" class="btn btn-secondary" id="cal-jour-annuler">Annuler</button>
                <button type="button" class="btn btn-primary" id="cal-jour-enregistrer">Enregistrer</button>`,
        });

        document.getElementById('cal-jour-annuler').addEventListener('click', () => Modal.close());
        // Deux clics rapides ne doivent pas envoyer DEUX enregistrements
        // (js/utils/actions.js) : le bouton est neutralisé pendant la demande.
        const boutonEnregistrer = document.getElementById('cal-jour-enregistrer');
        boutonEnregistrer.addEventListener('click', () => Action.uneSeule(boutonEnregistrer, () =>
            this._enregistrerJour(date).catch(e => console.error('[Calendrier] jour :', e))));
        document.getElementById('cal-act-ajouter').addEventListener('click', () =>
            this._ajouterActivite(date).catch(e => console.error('[Calendrier] activité :', e)));
        document.querySelectorAll('[data-act-suppr]').forEach(b =>
            b.addEventListener('click', () => this._supprimerActivite(Number(b.dataset.actSuppr), date)
                .catch(e => console.error('[Calendrier] suppression activité :', e))));
    },

    async _enregistrerJour(date) {
        const statut = document.getElementById('cal-jour-statut').value;
        const commentaire = document.getElementById('cal-jour-commentaire').value.trim();
        const dateFin = document.getElementById('cal-jour-fin').value;
        if (dateFin && dateFin < date) {
            Toast.show('La fin de la période précède le début.', 'error');
            return;
        }
        try {
            await API.post('calendrier.php?action=jour', {
                date, date_fin: dateFin || '', statut, commentaire,
            });
            Modal.close();
            Toast.show(dateFin && dateFin !== date ? 'Jours enregistrés.' : 'Jour enregistré.', 'success');
            await this._charger();
        } catch (e) {
            console.error('[Calendrier] enregistrement du jour :', e);
            Toast.show('Enregistrement impossible : ' + (e.message || 'erreur inconnue'), 'error');
        }
    },

    async _ajouterActivite(date) {
        const type = document.getElementById('cal-act-type').value;
        const demi_journee = document.getElementById('cal-act-demi').value;
        const libelle = document.getElementById('cal-act-libelle').value.trim();
        try {
            await API.post('calendrier.php?action=activite', { date, type, demi_journee, libelle });
            Modal.close();
            await this._charger();
            this._ouvrirJour(date);
        } catch (e) {
            console.error('[Calendrier] ajout d’activité :', e);
            Toast.show('Ajout impossible : ' + (e.message || 'erreur inconnue'), 'error');
        }
    },

    async _supprimerActivite(id, date) {
        try {
            await API.del('calendrier.php?action=activite&id=' + id);
            Modal.close();
            await this._charger();
            this._ouvrirJour(date);
        } catch (e) {
            console.error('[Calendrier] suppression d’activité :', e);
            Toast.show('Suppression impossible.', 'error');
        }
    },

    /* ------------------------------------------------------------------ */
    /* Import .ics                                                         */
    /* ------------------------------------------------------------------ */

    async _importerIcs(fichier) {
        const contenu = await fichier.text();
        if (!contenu.trim()) {
            Toast.show('Ce fichier est vide.', 'error');
            return;
        }
        try {
            const r = await API.post('calendrier.php?action=importer-ics', {
                annee_scolaire_id: this._annee ? Number(this._annee) : null,
                contenu,
            });
            const importes = (r && r.importes) || 0;
            const ignores = (r && r.ignores) || 0;
            const erreurs = (r && r.erreurs) || 0;
            // S10 (audit du 27/10/2026) : un import PARTIEL ne se présente jamais comme un
            // succès. L'API distingue « déjà présent » (normal, réimport) d'« échec » (dit).
            let message = importes + ' événement(s) importé(s)'
                + (ignores ? ', ' + ignores + ' déjà présent(s)' : '')
                + (erreurs ? ', ' + erreurs + ' NON importé(s)' : '') + '.';
            const details = (r && r.messages) || [];
            if (details.length) { message += ' ' + details.slice(0, 3).join(' '); }
            Toast.show(message, erreurs ? 'error' : 'success');
            await this._charger();
        } catch (e) {
            console.error('[Calendrier] import .ics :', e);
            Toast.show('Import impossible : ' + (e.message || 'fichier illisible'), 'error');
        }
    },

    /* ------------------------------------------------------------------ */
    /* Calendrier officiel (Internet)                                      */
    /* ------------------------------------------------------------------ */

    async _chargerOfficiel() {
        const zone = document.getElementById('cal-zone').value;
        const liste = document.getElementById('cal-officiel-liste');
        if (!this._donnees || !this._donnees.annee) return;
        liste.innerHTML = '<p class="text-muted">Interrogation du ministère…</p>';
        try {
            const v = await API.get('calendrier-scolaire.php?annee=' + encodeURIComponent(this._donnees.annee.nom) +
                '&zone=' + encodeURIComponent(zone));
            const items = Array.isArray(v) ? v : [];
            liste.innerHTML = items.length
                ? '<ul class="cal-officiel-liste">' + items.map(x =>
                    '<li>' + escapeHtml(x.description || 'Vacances') + ' — du ' +
                    escapeHtml(this._dateFr(String(x.date_debut).substring(0, 10))) + ' au ' +
                    escapeHtml(this._dateFr(String(x.date_fin).substring(0, 10))) + '</li>').join('') + '</ul>'
                : '<p class="text-muted">Aucune période de vacances renvoyée pour cette année et cette zone.</p>';
        } catch (e) {
            liste.innerHTML = '<p class="text-muted">Calendrier officiel indisponible : ' +
                escapeHtml(e.message || 'connexion impossible') + '. La saisie manuelle reste possible.</p>';
        }
    },

    async _creerSemaines() {
        if (!this._donnees || !this._donnees.annee) return;
        const zone = document.getElementById('cal-zone').value;
        const ok = await Modal.confirm('Créer les semaines de l’année',
            'Reprendre le calendrier officiel (' + escapeHtml(zone) + ') pour créer les semaines scolaires et de vacances de ' +
            escapeHtml(this._donnees.annee.nom) + ' ? Calulis refuse si cette année a déjà des semaines : rien n’est écrasé.');
        if (!ok) return;
        try {
            const r = await API.post('calendrier-scolaire.php', {
                annee_scolaire_id: Number(this._annee),
                zone,
            });
            Toast.show(((r && r.semaines_creees) || 0) + ' semaines créées.', 'success');
            await this._charger();
        } catch (e) {
            console.error('[Calendrier] semaines :', e);
            Toast.show(e.message || 'Import du calendrier officiel impossible.', 'error');
        }
    },
};
