/**
 * Calulis — L'écran de verrouillage (lot 8).
 *
 * POURQUOI CE FICHIER
 * Décision de Jérôme (31/10/2026) : un mot de passe OPTIONNEL à l'ouverture, désactivé par
 * défaut, avec une remise à zéro documentée. Ce fichier ne décide de RIEN : c'est le routeur
 * PHP qui refuse l'API (401 + en-tête X-Calulis-Verrou) quand le mot de passe est posé et
 * que le cookie de session manque. Ici, on ne fait que demander le mot et rejouer le geste.
 *
 * CE QU'IL FAUT SAVOIR
 * - `garder()` est appelé AVANT le premier rendu : si Calulis est verrouillé, l'écran de
 *   verrouillage s'affiche seul, sans barre latérale ni données derrière ;
 * - une session expirée en cours d'usage (12 h) produit le même écran, puis la requête est
 *   rejouée UNE fois (API._fetch) : l'utilisateur ne perd pas ce qu'il faisait ;
 * - le message d'oubli dit la VÉRITÉ : supprimer un fichier retire le mot de passe et ne
 *   touche à aucune donnée.
 */
const Verrou = {
    /** État courant, sans secret : actif, déverrouillé, pause en cours. */
    async etat() {
        return await API.get('verrou.php');
    },

    /**
     * Barrière d'entrée. Rend `true` si l'application peut s'ouvrir.
     */
    async garder() {
        let etat = null;
        try {
            etat = await this.etat();
        } catch (e) {
            // Serveur muet : ce n'est pas le verrou qui bloque, l'application dira
            // elle-même qu'elle est hors ligne. On ne prétend pas avoir vérifié.
            return true;
        }
        if (!etat || !etat.actif || etat.deverrouille) return true;
        return await this.demander(etat);
    },

    /**
     * Affiche l'écran de verrouillage et attend le mot de passe.
     * @returns {Promise<boolean>} true quand le serveur a accepté.
     */
    demander(etatConnu) {
        return new Promise((resolve) => {
            if (document.getElementById('calulis-verrou')) {
                // Déjà affiché (deux requêtes simultanées) : on ne superpose pas deux écrans.
                return resolve(false);
            }
            const voile = document.createElement('div');
            voile.id = 'calulis-verrou';
            voile.className = 'verrou-voile';
            voile.setAttribute('role', 'dialog');
            voile.setAttribute('aria-modal', 'true');
            voile.setAttribute('aria-labelledby', 'verrou-titre');

            const carte = document.createElement('form');
            carte.className = 'verrou-carte';
            carte.setAttribute('novalidate', 'novalidate');

            const titre = document.createElement('h2');
            titre.id = 'verrou-titre';
            titre.textContent = '🔒 Calulis est verrouillé';

            const explication = document.createElement('p');
            explication.className = 'verrou-texte';
            explication.textContent = 'Entrez le mot de passe pour ouvrir l\'application.';

            const etiquette = document.createElement('label');
            etiquette.setAttribute('for', 'verrou-mot');
            etiquette.textContent = 'Mot de passe';

            const champ = document.createElement('input');
            champ.type = 'password';
            champ.id = 'verrou-mot';
            champ.name = 'mot';
            champ.autocomplete = 'current-password';
            champ.setAttribute('autocapitalize', 'off');
            champ.setAttribute('spellcheck', 'false');

            const bouton = document.createElement('button');
            bouton.type = 'submit';
            bouton.className = 'btn btn-primary';
            bouton.textContent = 'Ouvrir';

            const message = document.createElement('p');
            message.className = 'verrou-message';
            message.setAttribute('role', 'status');

            const oubli = document.createElement('p');
            oubli.className = 'verrou-oubli';
            oubli.textContent = 'Mot de passe oublié ? Fermez Calulis, puis supprimez le fichier '
                + this._cheminFichier(etatConnu) + ' : le mot de passe est retiré et vos données restent intactes.';

            carte.append(titre, explication, etiquette, champ, bouton, message, oubli);
            voile.append(carte);
            document.body.append(voile);
            // Le reste de l'application est inerte derrière (le routeur refuse de toute façon).
            document.body.classList.add('verrou-actif');
            setTimeout(() => champ.focus(), 30);

            const fermer = (ouvert) => {
                voile.remove();
                document.body.classList.remove('verrou-actif');
                resolve(ouvert);
            };

            const envoyer = async () => {
                const mot = champ.value;
                if (mot === '') { message.textContent = 'Entrez le mot de passe.'; return; }
                bouton.disabled = true;
                bouton.textContent = 'Vérification...';
                message.textContent = '';
                try {
                    await API.post('verrou.php', { action: 'deverrouiller', mot });
                    fermer(true);
                } catch (e) {
                    champ.value = '';
                    champ.focus();
                    message.textContent = (e && e.message) ? e.message : 'Mot de passe incorrect.';
                    bouton.disabled = false;
                    bouton.textContent = 'Ouvrir';
                }
            };

            carte.addEventListener('submit', (ev) => { ev.preventDefault(); envoyer(); });
        });
    },

    /** Le chemin montrable du fichier à supprimer (celui que le serveur connaît). */
    _cheminFichier(etat) {
        // Le chemin vient du SERVEUR : c'est celui qu'il lit vraiment, pas une supposition.
        if (etat && typeof etat.dossier === 'string' && etat.dossier !== '') return etat.dossier;
        return 'runtime\\securite\\mot-de-passe.json';
    },

    /** Verrouiller tout de suite (bouton des Paramètres) — l'écran de verrouillage revient. */
    async verrouiller() {
        const reponse = await API.post('verrou.php', { action: 'verrouiller' });
        location.reload();
        return reponse;
    },
};