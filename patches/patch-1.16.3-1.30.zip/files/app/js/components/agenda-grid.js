/**
 * Calulis — Agenda Grid : rendu CSS grid + rebuild
 * Ajouté à Agenda via Object.assign
 */

Object.assign(Agenda, {

    /* ─── Rendu principal ─── */

    _buildGrid(heures, jours, couleurs, _unused) {
        this._heures = heures;
        this._filteredEleves = this._getFilteredEleves();

        if (this._viewMode === 'adultes') {
            this._buildAdultGrid(heures, jours, couleurs);
        } else {
            this._buildEleveGrid(heures, jours, couleurs);
        }
    },

    _buildEleveGrid(heures, jours, couleurs) {
        const container = document.getElementById('agenda-grid-css');
        const jour = this._currentDay;
        const dureePas = this._params?.horaires?.duree_creneau || 15;
        const eleves = this._filteredEleves;
        const nEleves = eleves.length;

        container.style.gridTemplateColumns = `55px repeat(${nEleves}, 1fr)`;
        container.style.setProperty('--agenda-cols', nEleves);

        const creneauxByEleve = {};
        eleves.forEach(e => {
            creneauxByEleve[e.id] = this._creneaux.filter(c => c.eleve_id === e.id && c.jour === jour);
        });

        // Fusion FACULTATIVE (choix de l'utilisatrice, jamais automatique) : plusieurs
        // créneaux portant le même `regroupement_id` s'affichent en un seul bloc.
        // Valide seulement si même début, même durée, et colonnes ADJACENTES à l'écran.
        // Sinon on retombe sur un bloc par élève — le comportement par défaut.
        const colIndex = {};
        eleves.forEach((e, i) => { colIndex[e.id] = i; });
        const parToken = {};
        (this._creneaux || []).forEach(c => {
            if (c.jour !== jour || !c.regroupement_id) return;
            (parToken[c.regroupement_id] = parToken[c.regroupement_id] || []).push(c);
        });
        const groupesValides = new Map();
        Object.values(parToken).forEach(liste => {
            if (liste.length < 2) return;
            const debut = String(liste[0].heure_debut || '').substring(0, 5);
            const duree = Number(liste[0].duree || dureePas);
            const identiques = liste.every(c => String(c.heure_debut || '').substring(0, 5) === debut
                && Number(c.duree || dureePas) === duree);
            if (!identiques) return;
            const cols = [...new Set(liste.map(c => colIndex[c.eleve_id]))].sort((a, b) => a - b);
            if (cols.length !== liste.length || cols.some(col => col === undefined)) return;
            if (cols.some((col, i) => i > 0 && col !== cols[i - 1] + 1)) return;
            groupesValides.set(debut + '|' + cols[0], { creneaux: liste, span: cols.length, duree });
        });

        const slotCovered = new Set();
        let html = '';

        // Ligne d'en-tête
        html += '<div class="agenda-header-row">';
        html += '<div class="agenda-gh-hour">Heure</div>';
        eleves.forEach(e => {
            html += `<div class="agenda-gh-cell" data-eleve="${e.id}" draggable="true">${e.numero ? e.numero + '. ' : ''}${escapeHtml(e.prenom)}<span class="nom">${escapeHtml(e.nom)}</span></div>`;
        });
        html += '</div>';

        // Lignes de données
        for (let hIdx = 0; hIdx < heures.length; hIdx++) {
            html += '<div class="agenda-row">';
            html += `<div class="agenda-hour-cell" data-heure="${heures[hIdx]}">${formatHeure(heures[hIdx])}</div>`;

            eleves.forEach((eleve, eIdx) => {
                if (slotCovered.has(hIdx + '_' + eIdx)) return;

                // Bloc fusionné : il commence ici et couvre `span` colonnes.
                const groupe = groupesValides.get(heures[hIdx] + '|' + eIdx);
                if (groupe) {
                    const cg = groupe.creneaux[0];
                    const rowSpanG = Math.max(1, Math.floor(Number(cg.duree || dureePas) / dureePas));
                    for (let s = 0; s < rowSpanG; s++) {
                        for (let k = 0; k < groupe.span; k++) {
                            slotCovered.add((hIdx + s) + '_' + (eIdx + k));
                        }
                    }
                    const colorG = cg.couleur_override || couleurs[cg.regroupement_type] || '#e0e0e0';
                    const nomsG = groupe.creneaux.map(cc => {
                        const e = eleves.find(x => x.id === cc.eleve_id);
                        return e ? e.prenom : '?';
                    }).join(', ');
                    html += `<div class="agenda-slot agenda-slot-groupe" style="grid-row:span ${rowSpanG};grid-column:span ${groupe.span};background:${colorG};color:#000"
                        data-id="${cg.id || ''}" data-groupe="${escapeHtml(cg.regroupement_id)}" data-eleve="${cg.eleve_id}" data-heure="${heures[hIdx]}" data-jour="${jour}"
                        title="${escapeHtml(cg.matiere || '')}${cg.adulte ? ' - ' + escapeHtml(cg.adulte) : ''} · bloc fusionné">
                        <strong>${escapeHtml(cg.matiere || '')}</strong>
                        ${cg.adulte ? `<small>${escapeHtml(cg.adulte)}</small>` : ''}
                        <small>👥 ${escapeHtml(nomsG)}</small>
                    </div>`;
                    return;
                }

                const c = (creneauxByEleve[eleve.id] || []).find(cc => cc.heure_debut === heures[hIdx]);

                if (c) {
                    let rowSpan = Math.max(1, Math.floor((c.duree || dureePas) / dureePas));
                    for (let j = hIdx + 1; j < heures.length && j < hIdx + rowSpan + 5; j++) {
                        const next = creneauxByEleve[eleve.id]?.find(cc => cc.heure_debut === heures[j]);
                        if (next && next.matiere === c.matiere && next.groupe === c.groupe &&
                            next.adulte === c.adulte && next.regroupement_type === c.regroupement_type) {
                            rowSpan = Math.max(rowSpan, j - hIdx + 1);
                        } else if (j < hIdx + rowSpan) {
                            rowSpan = Math.max(rowSpan, j - hIdx + 1);
                        } else break;
                    }
                    for (let s = 1; s < rowSpan; s++) slotCovered.add((hIdx + s) + '_' + eIdx);

                    const color = c.couleur_override || couleurs[c.regroupement_type] || '#e0e0e0';
                    const slotClass = 'agenda-slot';
                    html += `<div class="${slotClass}" style="grid-row:span ${rowSpan};background:${color};color:#000"
                        data-id="${c.id || ''}" data-eleve="${eleve.id}" data-heure="${heures[hIdx]}" data-jour="${jour}"
                        title="${escapeHtml(c.matiere || '')}${c.adulte ? ' - ' + escapeHtml(c.adulte) : ''}${c.pec_hors_ecole ? ' · hors école : ' + escapeHtml(c.pec_hors_ecole) : ''}">
                        <strong>${escapeHtml(c.matiere || '')}</strong>
                        ${c.adulte ? `<small>${escapeHtml(c.adulte)}</small>` : ''}
                        ${c.groupe ? `<small>${escapeHtml(c.groupe)}</small>` : ''}
                        ${c.pec_hors_ecole ? `<small class="agenda-slot-hors-ecole">🏥 hors école · ${escapeHtml(c.pec_hors_ecole)}</small>` : ''}
                    </div>`;
                } else {
                    html += `<div class="agenda-slot-empty"
                        data-eleve="${eleve.id}" data-heure="${heures[hIdx]}" data-jour="${jour}"></div>`;
                }
            });

            html += '</div>';
        }

        container.innerHTML = html;
    },

    _buildAdultGrid(heures, jours, couleurs) {
        const container = document.getElementById('agenda-grid-css');
        const jour = this._currentDay;
        const dureePas = this._params?.horaires?.duree_creneau || 15;
        const adultes = this._extractAdultes();
        const nAdultes = adultes.length;

        if (nAdultes === 0) {
            container.innerHTML = '<p style="padding:32px;text-align:center;color:var(--text-muted);grid-column:1/-1">Aucun adulte référencé dans les créneaux.</p>';
            return;
        }

        container.style.gridTemplateColumns = `55px repeat(${nAdultes}, 1fr)`;
        container.style.setProperty('--agenda-cols', nAdultes);

        const slotsParAdulte = {};
        const adultePrefixMap = {};
        adultes.forEach(a => { adultePrefixMap[a.name] = a.name; slotsParAdulte[a.name] = []; });
        this._creneaux.forEach(c => {
            if (!c.adulte || !c.adulte.trim() || c.jour !== jour) return;
            // Comparaison NORMALISÉE (civilité et ponctuation retirées), la même
            // que le contrôle de conflit : « Dr. Mercier » (fiche) et « Dr Mercier »
            // (créneau) sont la même personne — l'ancien endsWith les séparait, et
            // la colonne restait vide (défaut trouvé le 26/10/2026).
            const nomsCreneau = this._nomsAdultes(c.adulte);
            for (const a of adultes) {
                const cible = this._nomsAdultes(a.name)[0];
                if (cible && nomsCreneau.includes(cible)) {
                    if (!adultePrefixMap[a.name] || adultePrefixMap[a.name] === a.name) {
                        adultePrefixMap[a.name] = c.adulte.trim();
                    }
                    slotsParAdulte[a.name].push(c);
                    break;
                }
            }
        });

        const eleveMap = {};
        this._eleves.forEach(e => { eleveMap[e.id] = e; });

        const slotCovered = new Set();
        let html = '';

        html += '<div class="agenda-header-row">';
        html += '<div class="agenda-gh-hour">Heure</div>';
        adultes.forEach(a => {
            const roleLabel = a.role ? (roleLabels[a.role] || a.role) : '';
            html += `<div class="agenda-gh-cell" data-adulte-id="${a.id}" draggable="true">${escapeHtml(a.name)}${roleLabel ? `<span class="nom">${escapeHtml(roleLabel)}</span>` : ''}</div>`;
        });
        html += '</div>';

        for (let hIdx = 0; hIdx < heures.length; hIdx++) {
            html += '<div class="agenda-row">';
            html += `<div class="agenda-hour-cell" data-heure="${heures[hIdx]}">${formatHeure(heures[hIdx])}</div>`;

            adultes.forEach((adulte, aIdx) => {
                if (slotCovered.has(hIdx + '_' + aIdx)) return;

                const creneauxList = this._slotsAuCreneau(slotsParAdulte[adulte.name] || [], heures[hIdx], dureePas);

                if (creneauxList.length > 0) {
                    const c = creneauxList[0];
                    // La case couvre la PLUS LONGUE fin du groupe — y compris un créneau
                    // qui COMMENCE PENDANT la case (10:30 dans 10:00-10:45). Avant, ce
                    // second créneau était masqué par le rowSpan : invisible à l'écran et
                    // à l'impression (défaut relevé le 26/10/2026).
                    const debutCell = this._heureToMin(heures[hIdx]);
                    const finCell = creneauxList.reduce(
                        (max, cc) => Math.max(max, this._heureToMin(cc.heure_debut) + (cc.duree || dureePas)),
                        debutCell);
                    const rowSpan = Math.max(1, Math.ceil((finCell - debutCell) / dureePas));
                    for (let s = 1; s < rowSpan; s++) slotCovered.add((hIdx + s) + '_' + aIdx);

                    const color = c.couleur_override || couleurs[c.regroupement_type] || '#e0e0e0';
                    const details = creneauxList.map(cc => {
                        const e = eleveMap[cc.eleve_id];
                        const debut = String(cc.heure_debut || '').substring(0, 5);
                        const fin = this._minToHeure(this._heureToMin(debut) + (cc.duree || dureePas));
                        return { nom: e ? (e.prenom || e.nom) : '?', debut, fin };
                    });
                    const elevesNoms = details.map(d => d.nom).join(', ');
                    // Les horaires ne sont affichés que s'ils DIFFÈRENT : sinon, le nom
                    // suffit (cas courant du binôme de même durée).
                    const horairesDifferents = new Set(details.map(d => d.debut + '-' + d.fin)).size > 1;
                    const detailHoraires = horairesDifferents
                        ? details.map(d => escapeHtml(d.nom + ' ' + d.debut + '–' + d.fin)).join(' · ')
                        : '';

                    html += `<div class="agenda-slot" style="grid-row:span ${rowSpan};background:${color};color:#000"
                        data-adulte="${escapeHtml(adultePrefixMap[adulte.name] || adulte.name)}" data-heure="${heures[hIdx]}" data-jour="${jour}">
                        <strong>${elevesNoms}</strong>
                        ${detailHoraires ? `<small>${detailHoraires}</small>` : ''}
                        ${creneauxList[0].matiere ? `<small>${escapeHtml(creneauxList[0].matiere)}</small>` : ''}
                    </div>`;
                } else {
                    html += `<div class="agenda-slot-empty" data-adulte="${escapeHtml(adultePrefixMap[adulte.name] || adulte.name)}" data-heure="${heures[hIdx]}" data-jour="${jour}"></div>`;
                }
            });

            html += '</div>';
        }

        container.innerHTML = html;
    },

    /**
     * Durée que doit couvrir la case d'un adulte : la PLUS LONGUE des créneaux du
     * groupe. Une professionnelle peut rester 45 min avec l'un et 30 min avec l'autre
     * (cas décrit par l'utilisatrice le 26/10/2026) ; se fier au premier créneau
     * coupait la case trop tôt. Méthode séparée pour que le test puisse réintroduire
     * l'ancien calcul en mode --negatif.
     */
    /**
     * Créneaux d'un adulte qui couvrent une case ouverte à « heure » : ceux qui commencent à
     * cette heure, puis ceux qui commencent PENDANT la plage déjà couverte. Sans cela, un
     * 10:30-11:00 était masqué par un 10:00-10:45 commencé plus tôt (défaut du 26/10/2026).
     */
    _slotsAuCreneau(liste, heure, dureePas) {
        const debut = this._heureToMin(heure);
        let fin = debut + dureePas;
        const retenus = [];
        let ajout = true;
        while (ajout) {
            ajout = false;
            for (const c of (liste || [])) {
                if (retenus.includes(c)) continue;
                const d = this._heureToMin(c.heure_debut);
                if (d >= debut && d < fin) {
                    retenus.push(c);
                    const f = d + (c.duree || dureePas);
                    if (f > fin) { fin = f; ajout = true; }
                }
            }
        }
        return retenus;
    },

    _rebuildGrid() {
        const horaires = this._params?.horaires || { debut: '08:30', fin: '16:30', duree_creneau: 15 };
        const couleurs = { ...COULEURS_TYPES_DEFAUT, ...(this._params?.couleurs_types || {}) };
        const jours = this._params?.jours_affiches || ['lundi', 'mardi', 'jeudi', 'vendredi'];
        const { heures } = this._computeGridHeures(horaires);

        this._buildGrid(heures, jours, couleurs, []);
        this._bindGridEvents();
    },

});
