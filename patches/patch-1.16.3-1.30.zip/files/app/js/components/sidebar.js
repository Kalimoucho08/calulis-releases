/**
 * Calulis — Sidebar de navigation
 * Les écrans sont rangés en TROIS FAMILLES repliables (+ le pied), une seule source :
 * `_familles` donne les titres, `_items` donne l'ordre, la famille et la bulle de chaque
 * entrée. Une entrée qui n'ouvre rien ne doit jamais figurer ici (règle du 29/09/2026).
 *
 * Révision du 30/10/2026 (lot 2 de la 1.30, maquette acceptée) : la barre passe à 232 px,
 * les familles se replient, la famille de l'écran ouvert reste ouverte, et les rangées
 * font 30 px en mode rail pour que « Aide » et la version tiennent à l'écran.
 */
const Sidebar = {
    /** Les trois familles du corps, dans l'ordre affiché. */
    _familles: [
        { id: 'jour',  titre: 'Tous les jours', aide: 'Tous les jours|Les écrans que vous ouvrez le plus souvent : tableau de bord, emploi du temps, notes de suivi, tâches, élèves, listes, documents, réunions et impression (PDF). Cliquez sur le titre de la famille pour la replier ou la déplier : elle se rouvre toute seule sur l\'écran que vous consultez.' },
        { id: 'annee', titre: 'L\'année scolaire', aide: 'L\'année scolaire|Le calendrier, les événements et les statistiques : ce qui se règle année par année. Cliquez sur le titre de la famille pour la replier ou la déplier ; elle reste ouverte dès que l\'écran affiché s\'y trouve.' },
        { id: 'lieux', titre: 'Personnes et lieux', aide: 'Personnes et lieux|Les personnes (annuaire, adultes) et les lieux (classes, établissements). Cliquez sur le titre de la famille pour la replier ou la déplier ; elle reste ouverte dès que l\'écran affiché s\'y trouve.' },
    ],

    /** Clé de mémoire des familles repliées (par navigateur, comme le repli de la barre). */
    _CLE: 'calulis_familles',

    _items: [
        // — Tous les jours —
        { id: 'dashboard', icon: '📋', famille: 'jour', label: 'Tableau de bord', help: 'Tableau de bord|Vue d\'ensemble de votre année scolaire. Vous voyez d\'un coup d\'œil : le nombre d\'élèves et de classes, les prochaines réunions, la semaine en cours dans l\'emploi du temps, et l\'échéancier « À relancer » : les droits MDPH expirés ou proches de l\'échéance, les ESS à programmer et les documents à compléter. Cliquez sur une ligne pour ouvrir la fiche de l\'élève ; le bouton « + N autre(s)… » déplie la liste complète. C\'est la page d\'accueil.' },
        { id: 'agenda',    icon: '📅', famille: 'jour', label: 'Emploi du temps', help: 'Emploi du temps|Le cœur de Calulis : l\'emploi du temps de la semaine. Double-cliquez dans une case vide pour créer un créneau (activité, élèves, adultes). Glissez-déposez pour déplacer un créneau. Ctrl+glisser pour le copier. Clic droit pour couper/copier/coller. Si le même élève est déjà là, Calulis demande avant d\'écrire : Annuler, Ignorer les occupées ou Écraser (qui n\'efface que ses propres créneaux). Si c\'est un adulte déjà occupé avec un autre élève, il propose simplement « Ajouter quand même », sans rien supprimer. La barre du haut permet de changer de semaine (flèches ◀▶), de basculer entre vue Élèves et vue Adultes, et de filtrer par élève, groupe ou intervenant. L\'ordre des colonnes est celui que vous choisissez : glissez les en-têtes, ou utilisez le bouton « Trier par N° » pour les ranger dans l\'ordre des numéros d\'élève. Un clic droit sur une sélection de créneaux permet aussi de les réunir en un seul bloc (jamais automatique) — et « Détacher les blocs » pour revenir à un bloc par élève. Clic droit sur le bloc puis « Modifier » : les champs communs s\'appliquent à tous ses élèves ; changer l\'heure ou la durée le détache. Une case peut porter 🏥 hors école : la prise en charge de l\'élève est alors reliée à ce créneau, dans sa fiche (onglet AESH et PEC, champ Créneau). Sans lien, rien n\'est marqué.' },
        { id: 'suivi',     icon: '📝', famille: 'jour', label: 'Notes de suivi', help: 'Notes de suivi|Les notes de suivi de vos élèves : ce que vous observez, les objectifs que vous fixez, les réussites, les alertes et les actions décidées. Chaque note est datée et rattachée à un élève, et reçoit son année d’après sa date. L’écran montre l’année en cours ; le sélecteur permet d’en choisir une autre ou de tout voir. Une note ne se supprime pas : elle s’archive et reste retrouvable (case « Afficher les notes archivées »). Les types de notes sont les vôtres : renommer, colorer, ajouter — le bouton « Types de notes… ». Filtrez, cochez, puis imprimez en PDF pour préparer une ESS.' },
        { id: 'taches',    icon: '✅', famille: 'jour', label: 'Tâches', help: 'Tâches|Vos tâches, en tableau de cartes ou en liste : à faire, plus tard, en cours, fait, annulé. Une tâche peut concerner un élève, un adulte, ou personne. Elle a une échéance, une priorité, une couleur, une précision courte et, si besoin, une RÉPÉTITION (chaque jour, chaque semaine, en fin de période, en fin ou en début d’année). Les occurrences dues sont créées avec leur vraie date ; une occurrence manquée n’est jamais effacée. Supprimer une tâche répétée propose deux gestes : ce jour seulement (la date ne revient plus) ou arrêter la récurrence (les dates à venir disparaissent). Fermer une tâche écrit sa date de clôture : elle compte alors dans l’année de sa création ET dans celle de sa fermeture. Cochez les tâches à emporter, puis imprimez-les en PDF.' },
        { id: 'eleves',    icon: '👥', famille: 'jour', label: 'Élèves', help: 'Élèves|Liste de tous les élèves suivis en ULIS cette année. En haut, des filtres pour affiner : par niveau (CP, CE1…), par classe précise, ou par statut (ULIS / non ULIS, actif / inactif). Les colonnes Âge et Années ULIS sont calculées automatiquement. Cliquez sur un en-tête pour trier. Les boutons : Fiche = consulter sans pouvoir modifier, Modifier = éditer la fiche, Supprimer = retirer de l\'année en cours.' },
        { id: 'listes',    icon: '📋', famille: 'jour', label: 'Listes', help: 'Listes|Générez vos listes d’élèves en un clic : filtrez par niveau, classe, groupe, ULIS, cantine, transport, PAI, allergies, droit à l’image, cochez vos élèves, choisissez les colonnes et exportez en PDF paysage ou CSV. Un MODÈLE de liste mémorise filtres + colonnes + mise en page + tri, sans aucun élève : il se garde d’une année sur l’autre (bouton « Enregistrer comme nouveau modèle »). Après « Appliquer », la sélection part vide : cochez les élèves de cette année. Les listes, elles, se refont chaque année.' },
        { id: 'documents', icon: '📁', famille: 'jour', label: 'Documents', help: 'Documents|Les documents des élèves, rapatriés DANS Calulis : notification MDPH, PPS, GEVA-Sco, compte rendu d\'ESS, PAI, document médical, bilan d\'un professionnel, courrier, bulletin… Déposez un document (PDF, image, Word, texte), rattachez-le à un élève et à un type, et retrouvez-le à tout moment même si l\'original a été déplacé ou supprimé. Filtrez par élève, par type ou par recherche ; ouvrez l\'aperçu intégré (rien à installer) ; remplacez un document par sa version à jour, ou supprimez-le. Le fichier reste sur votre ordinateur, dans le dossier de l\'application : rien ne part sur Internet.' },
        { id: 'reunions',  icon: '🤝', famille: 'jour', label: 'Réunions', help: 'Réunions|Toutes les réunions liées au dispositif : ESS, équipes éducatives, rendez-vous avec les familles, réunions partenariales. La liste affiche l’année en cours ; le sélecteur d’année permet d’en changer ou de tout voir. Une réunion préparée pour l’an prochain apparaît tout de suite dans un bloc « À venir — année suivante ». Chaque réunion a un type, une date, un statut et peut être liée à un élève ; l’ordre du jour, le compte rendu et les préconisations s’écrivent dans la fiche. Le bouton « Exporter (.ics) » met les réunions affichées dans votre agenda, et « Imprimer la liste » en fait un tableau papier (date, type, objet, élève, statut).' },
        { id: 'print',     icon: '🖨️', famille: 'jour', label: 'Imprimer (PDF)', help: 'Imprimer (PDF)|Tous vos documents en PDF, sur un seul écran. À gauche, la liste des documents : emplois du temps (semaine d’un élève ou d’un adulte, journée de plusieurs élèves ou adultes — plusieurs jours cochés donnent UN document avec une section par jour ; chaque journée commence sur sa page et une journée chargée peut en occuper plusieurs, avec la légende des couleurs au pied de chaque page), statistiques et fiches. La « Semaine type (modèle) » s’imprime pour un élève comme pour un adulte. Pour les statistiques, cochez les blocs : ils s’enchaînent 2 à 3 par page, ou un par page si vous préférez, et un bloc large ouvre une page en paysage. Les fiches d’urgence et de renseignements sortent une par page. Réglez les bandeaux (nom, semaine, date, numéro de page, texte libre) et les marges : l’aperçu à droite se met à jour à chaque changement. Puis Imprimer ou Télécharger. L’aperçu fonctionne sans Internet.' },
        // — L'année scolaire —
        { id: 'calendrier', icon: '🗓️', famille: 'annee', label: 'Calendrier', help: 'Calendrier|Le calendrier unique de l’année : les périodes, les vacances et les événements réunis sur une page, l’année entière visible, avec le calendrier officiel à côté pour comparer. Chaque jour a UN statut officiel (scolaire, vacances, férié, fermeture) et peut porter plusieurs activités superposables (stage, réunion, commémoration, sortie, journée banalisée, autre), à la journée ou à la demi-journée, plus un commentaire libre. Cliquez sur un jour pour le modifier. Trois entrées : le calendrier officiel quand Internet est là, un fichier .ics (importer deux fois le même ne crée aucun doublon ; chaque événement est rangé dans l’année de sa date, et l’import dit ce qu’il n’a pas pu importer), la saisie manuelle. Le statut absent se déduit des semaines de vacances et des jours fériés. Le jour d’aujourd’hui est encadré et écrit « auj. », les jours non travaillés sont hachurés, une période de vacances va du samedi d’avant au dimanche d’après, et un pont de trois jours ou moins est posé en jours fériés — sans jamais écraser un statut écrit à la main.' },
        { id: 'evenements', icon: '📆', famille: 'annee', label: 'Événements', help: 'Événements|Calendrier des événements de l\'année scolaire. 60 modèles prédéfinis (jours fériés, vacances, examens, semaines thématiques) que vous activez d\'un simple clic. Le bouton 🎂 génère automatiquement les anniversaires des élèves. Vous pouvez aussi créer vos propres événements (sortie, spectacle, conseil d\'école…). Filtrez par catégorie pour vous y retrouver. Le bouton « Exporter (.ics) » met les événements affichés dans l\'agenda de votre téléphone — le fichier est fabriqué sur votre ordinateur, rien n\'est envoyé sur Internet.' },
        { id: 'projets',   icon: '🧭', famille: 'annee', label: 'Projets', help: 'Projets|La mémoire de ce que les élèves ont fait : chorale, pièce de théâtre, cross, tournoi, Printemps des poètes, Semaine de la science… Un projet se décrit UNE fois — nom, type libre (culturel, sportif…), dates, classes et adultes concernés — puis on coche les élèves qui y ont participé, depuis la fiche de chaque élève (onglet Scolarité). L\'année n\'est pas choisie à la main : ce sont les dates qui décident, et un projet à cheval sur deux années apparaît dans les deux. Un projet peut être rattaché à un événement du calendrier (facultatif) : son nom et ses dates servent alors de repère. Deux impressions : « Imprimer la liste » sort les projets affichés en tableau, et sur la fiche d\'un élève, « Imprimer ses projets » fait une feuille à son nom.' },
        { id: 'stats',     icon: '📊', famille: 'annee', label: 'Statistiques', help: 'Statistiques|Temps de présence des élèves par type de regroupement, calculé à partir de l’emploi du temps. L’inclusion suit la formule du 27/10/2026 : temps d’école prévu − ULIS − prise en charge − non scolarisé. Un élève à temps plein sans créneau ULIS sort donc à 100 %, le décloisonnement compte comme de l’inclusion, et le temps non scolarisé se déclare par un créneau de type NON SCOLARISE (la fiche dit « temps partiel »). Le pourcentage se calcule sur le temps d’école effectif (temps commun moins le non scolarisé) ; une prise en charge réduit l’inclusion, pas ce temps effectif ; tout est recalculé, y compris les années passées. Les données sont exportables en PDF.' },
        // — Personnes et lieux —
        { id: 'annuaire',  icon: '📖', famille: 'lieux', label: 'Annuaire', help: 'Annuaire|Annuaire complet et interrogeable. Tapez un nom, un prénom ou un établissement dans la barre de recherche pour trouver instantanément un élève, un adulte ou une structure. Cliquez sur Fiche pour voir tous les détails. Pratique pour retrouver un contact rapidement.' },
        { id: 'adultes',   icon: '👩‍🏫', famille: 'lieux', label: 'Adultes', help: 'Adultes|Tous les adultes qui interviennent auprès des élèves : enseignants, AESH, orthophonistes, psychomotriciens, éducateurs… Filtrez par catégorie : 👩‍🏫 enseignants de l\'école, 👥 autre personnel (AESH, directeur), 🌍 intervenants extérieurs (libéraux, SESSAD, ASE). Un adulte peut être rattaché à plusieurs établissements. Le bouton « ＋ Depuis l\'emploi du temps » crée la fiche de chaque nom cité dans un créneau mais absent de la liste, sans le dupliquer. Chaque adulte a un <strong>métier</strong> choisi dans une liste et peut porter plusieurs <strong>rôles</strong> (coordonnateur ULIS, directeur…) : une personne = une seule fiche. La liste affiche le métier puis les rôles. Deux fiches du même nom sont signalées : on désigne celle qui reste, puis on tranche pour CHAQUE autre fiche (fusionner, ou « ce n&#39;est pas la même personne » — cette décision est retenue). Il a aussi des dates d\'arrivée et de départ.' },
        { id: 'classes',   icon: '🏷️', famille: 'lieux', label: 'Classes', help: 'Classes|Les classes de votre école. Chaque classe a un nom (ex: CE1), un niveau, un enseignant et un établissement. Les élèves ULIS sont rattachés à leur classe de référence — c\'est une obligation légale. Cela permet de savoir dans quelle classe chaque élève est inscrit administrativement. Les classes de votre établissement (réglé dans Paramètres → Notre établissement) sont classées en tête et repérées par un liseré bleu.' },
        { id: 'etablissements', icon: '🏫', famille: 'lieux', label: 'Établissements', help: 'Établissements|Tous les établissements partenaires : votre école (repérée par le badge 🏫 NOTRE ÉCOLE), les autres écoles, les collèges, les structures médico-sociales (CMP, CMPP, SESSAD, IME), l\'Aide Sociale à l\'Enfance… Double-cliquez sur une ligne pour voir la fiche détaillée avec les intervenants rattachés.' },
        // — Pied de la barre —
        { id: 'params',    icon: '⚙️', famille: 'pied', label: 'Paramètres', help: 'Paramètres|Configurez Calulis selon votre école : choisissez les couleurs des types de regroupement, les horaires (début, fin, durée d\'un créneau), les jours travaillés, les APC, et votre établissement principal. Les pauses (récréation, pause du midi) se placent dans l\'emploi du temps avec le bouton « ⏸️ Pause ». Les modifications s\'appliquent immédiatement dans l\'emploi du temps. En bas, la liste des années scolaires : « Vider l\'emploi du temps » n\'enlève que les semaines et les créneaux de l\'année — élèves, adultes, établissements, réunions, documents, notes et calendrier restent intacts et consultables en activant l\'année. « Sauvegarder maintenant » fabrique une seule archive qui contient la base et les documents joints ; « Restaurer une sauvegarde » les remet tous les deux en place, après une sauvegarde de secours faite automatiquement. Un mot de passe d\'ouverture FACULTATIF (désactivé par défaut) peut arrêter une personne devant l\'écran : il ne protège pas les fichiers, et s\'oublie sans rien perdre en supprimant runtime\\securite\\mot-de-passe.json.' },
        { id: 'aide',      icon: '📖', famille: 'pied', label: 'Aide', help: 'Aide|Guide complet de Calulis. Vous y trouverez : un pas-à-pas pour démarrer, des explications détaillées sur chaque module, des scénarios concrets (préparer la rentrée, organiser une ESS, vérifier la charge d\'un AESH…), la liste des raccourcis clavier, et des astuces pour gagner du temps au quotidien.' },
        { id: 'mentions-rgpd', icon: '📄', famille: 'pied', label: 'Mentions RGPD', help: 'Mentions RGPD|Informations légales sur le traitement des données personnelles dans Calulis. Finalités, base légale, durée de conservation, destinataires, droits des personnes, coordonnées du DPD académique. Conformité RGPD et réglementation Éducation nationale.' },
        { id: 'don',       icon: '❤️', famille: 'pied', label: 'Soutenir', help: 'Soutenir|Si Calulis vous est utile, vous pouvez soutenir son développement par un don PayPal. Le logiciel reste gratuit et libre.' },
    ],

    init() {
        const nav = document.getElementById('sidebar-nav');

        // Une famille = un vrai bouton de titre (état annoncé) + un groupe d'entrées.
        nav.innerHTML = this._familles.map(f => {
            const items = this._items.filter(i => i.famille === f.id);
            return `
            <div class="famille" data-famille="${f.id}">
                <button type="button" class="famille-entete" id="tete-${f.id}"
                        aria-expanded="false" aria-controls="corps-${f.id}"
                        data-help="${escapeAttr(f.aide)}">
                    <span class="titre">${escapeHtml(f.titre)}</span>
                    <span class="compte">${items.length}</span>
                    <span class="ici" aria-hidden="true"></span>
                    <span class="chev" aria-hidden="true">▶</span>
                </button>
                <div class="corps" id="corps-${f.id}" role="group" aria-labelledby="tete-${f.id}">
                    ${items.map(i => this._bouton(i)).join('')}
                </div>
            </div>`;
        }).join('');

        nav.querySelectorAll('.famille-entete').forEach(entete => {
            entete.addEventListener('click', () => this._basculer(entete.closest('.famille')));
        });

        nav.querySelectorAll('.sidebar-item').forEach(btn => {
            btn.addEventListener('click', () => Router.go(btn.dataset.view));
        });

        // État de départ : ce que l'utilisateur a laissé la dernière fois ; sinon la
        // famille de l'écran ouvert reste la seule dépliée (sinon la liste déborde).
        let memoire = null;
        try { memoire = JSON.parse(localStorage.getItem(this._CLE) || 'null'); } catch { memoire = null; }
        const actuelle = this._familleDe(Router.current);
        this._familles.forEach(f => {
            const ouverte = memoire && Object.prototype.hasOwnProperty.call(memoire, f.id)
                ? !!memoire[f.id]
                : f.id === actuelle;
            this._poserOuverte(document.querySelector('.famille[data-famille="' + f.id + '"]'), ouverte);
        });

        // Synchroniser l'état actif avec le routeur
        State.on('currentView:changed', (data) => this._setActive(data.value));
        this._setActive(Router.current);

        // Pied de la barre : Paramètres, Aide, Mentions RGPD et Soutenir (mêmes bulles et
        // mêmes écrans qu'avant), puis le lien Facebook et la version réelle.
        document.getElementById('sidebar-footer').innerHTML = `
            <div class="sidebar-pied">${this._items.filter(i => i.famille === 'pied').map(i => this._bouton(i)).join('')}</div>
            <div class="sidebar-liens">
                <a href="https://www.facebook.com/profile.php?id=61575316486226" target="_blank" rel="noopener" title="Facebook" aria-label="Facebook de Calulis" style="text-decoration:none">📘</a>
            </div>
            <div class="sidebar-version" id="sidebar-version">Calulis v1</div>
        `;
        document.querySelectorAll('.sidebar-pied .sidebar-item').forEach(btn => {
            btn.addEventListener('click', () => Router.go(btn.dataset.view));
        });

        // Version réelle (silencieux si indisponible)
        API.get('version.php').then(v => {
            const el = document.getElementById('sidebar-version');
            if (el && v && v.appVersion) el.textContent = 'Calulis v' + v.appVersion;
        }).catch(() => {});
    },

    _bouton(item) {
        // Contexte d'ATTRIBUT : escapeAttr (escapeHtml ne protège pas les guillemets).
        return `<button type="button" class="sidebar-item" data-view="${escapeAttr(item.id)}" data-help="${escapeAttr(item.help || '')}"
                    title="${escapeAttr(item.label)}" aria-label="${escapeAttr(item.label)}">
                    <span class="icon" aria-hidden="true">${item.icon}</span>
                    <span class="label">${escapeHtml(item.label)}</span>
                </button>`;
    },

    _familleDe(vue) {
        const item = this._items.find(i => i.id === vue);
        return item ? item.famille : this._familles[0].id;
    },

    /** Ouvre ou ferme une famille (état visuel + annonce aux lecteurs d'écran). */
    _poserOuverte(famille, ouverte) {
        if (!famille) return;
        famille.classList.toggle('ouverte', !!ouverte);
        const entete = famille.querySelector('.famille-entete');
        if (entete) entete.setAttribute('aria-expanded', ouverte ? 'true' : 'false');
    },

    _basculer(famille) {
        const ouverte = !famille.classList.contains('ouverte');
        this._poserOuverte(famille, ouverte);
        let memoire = {};
        try { memoire = JSON.parse(localStorage.getItem(this._CLE) || '{}') || {}; } catch { memoire = {}; }
        memoire[famille.dataset.famille] = ouverte;
        try { localStorage.setItem(this._CLE, JSON.stringify(memoire)); } catch {}
        this._majIci();
    },

    /** Nom de l'écran ouvert, rappelé dans le titre des familles repliées. */
    _majIci(actif) {
        const vue = actif || Router.current;
        document.querySelectorAll('.famille').forEach(famille => {
            const span = famille.querySelector('.ici');
            if (!span) return;
            const dedans = this._items.some(i => i.famille === famille.dataset.famille && i.id === vue);
            const item = this._items.find(i => i.id === vue);
            span.textContent = dedans && item ? item.label : '';
        });
    },

    _setActive(name) {
        document.querySelectorAll('.sidebar-item').forEach(btn => {
            const actif = btn.dataset.view === name;
            btn.classList.toggle('active', actif);
            if (actif) btn.setAttribute('aria-current', 'page');
            else btn.removeAttribute('aria-current');
        });
        // La famille de l'écran ouvert se déplie : sinon la navigation cache l'écran demandé.
        const famille = document.querySelector('.famille[data-famille="' + this._familleDe(name) + '"]');
        if (famille) this._poserOuverte(famille, true);
        this._majIci(name);
    },
};
