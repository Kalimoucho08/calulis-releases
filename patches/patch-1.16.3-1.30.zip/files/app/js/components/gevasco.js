/**
 * Calulis — GEVA-Sco (réexamen) : pré-remplir le formulaire officiel
 *
 * Le formulaire officiel (version 2 — février 2016, 8 pages, 190 champs) est livré dans
 * `app/data/formulaires/`. La table `…mapping.json` dit, case par case, d'où vient chaque valeur ;
 * `…champs.json` est la liste des cases telles que le moteur de remplissage les voit. Les deux
 * sont mesurées dans les deux sens par `tests/verif-gevasco.sh` : une case annoncée qui n'existe pas,
 * ou une case du PDF oubliée, fait rougir le test.
 *
 * RÈGLE DU LOT (décision de Jérôme, 31/10/2026) : rien ne part sans relecture. Calulis PROPOSE
 * une valeur par case ; l'enseignant la corrige, la vide ou décoche la ligne ; le PDF ne sort
 * qu'après son clic. Les zones de texte libre ne sont JAMAIS écrites d'office dans le
 * formulaire — elles sont proposées à côté, à copier-coller.
 *
 * Le remplissage se fait DANS le navigateur (pdf-lib, `app/vendor/`) : aucune donnée d'élève ne
 * sort de l'ordinateur.
 */
const Gevasco = {

    FORMULAIRE: 'data/formulaires/gevasco-reexamen-v2-2016.pdf',
    MAPPING: 'data/formulaires/gevasco-reexamen-v2-2016.mapping.json',

    _mapping: null,
    _modele: null,
    _lignes: [],
    _eleve: null,

    /* ── Chargement (une seule fois par session) ─────────────────────────────── */

    async _table() {
        if (this._mapping) return this._mapping;
        const r = await fetch(this.MAPPING);
        if (!r.ok) throw new Error('table de remplissage introuvable (HTTP ' + r.status + ')');
        this._mapping = await r.json();
        return this._mapping;
    },

    async _vierge() {
        if (this._modele) return this._modele;
        const r = await fetch(this.FORMULAIRE);
        if (!r.ok) throw new Error('formulaire GEVA-Sco introuvable (HTTP ' + r.status + ')');
        this._modele = new Uint8Array(await r.arrayBuffer());
        return this._modele;
    },

    /* ── Le contexte : d'où viennent les valeurs ──────────────────────────────── */

    async _contexte(eleve) {
        const ctx = {
            eleve: eleve || {},
            etablissement: null,
            referent: null,
            ess: null,
            creneaux: [],
            annee: (typeof State !== 'undefined' && State.get('annee_active')) || null,
        };

        if (eleve && eleve.etablissement_id) {
            try {
                const etabs = (await API.get('etablissements.php')) || [];
                ctx.etablissement = etabs.find((e) => Number(e.id) === Number(eleve.etablissement_id)) || null;
            } catch (e) { ctx.etablissement = null; }
        }

        if (eleve && eleve.enseignant_referent_id) {
            try {
                const a = await API.get('adultes.php?id=' + eleve.enseignant_referent_id);
                ctx.referent = Array.isArray(a) ? (a[0] || null) : (a || null);
            } catch (e) { ctx.referent = null; }
        }

        // Aucun référent désigné sur la fiche : s'il n'y a QU'UN adulte portant le rôle
        // « Enseignant référent » (ERSEH), c'est lui. Plusieurs candidats : on ne devine
        // pas — la case reste vide et vous la remplissez à la main.
        if (!ctx.referent) {
            try {
                const adultes = (await API.get('adultes.php')) || [];
                const referents = adultes.filter((a) => (typeof estEnseignantReferent === 'function'
                    ? estEnseignantReferent(a) : String(a.role || '') === 'enseignant_referent'));
                if (referents.length === 1) ctx.referent = referents[0];
            } catch (e) { /* la case restera vide */ }
        }

        if (eleve && eleve.id) {
            try {
                const tous = (await API.get('creneaux.php?eleve_id=' + eleve.id)) || [];
                // L'API rend tous les créneaux de l'année : on ne garde que ceux de CET élève.
                ctx.creneaux = tous.filter((c) => Number(c.eleve_id) === Number(eleve.id));
            } catch (e) { ctx.creneaux = []; }
        }

        if (eleve && eleve.id) {
            try {
                const reus = (await API.get('reunions.php?eleve_id=' + eleve.id)) || [];
                const ess = reus
                    .filter((r) => /ess|équipe de suivi|equipe de suivi/i.test(String(r.type || '')))
                    .sort((a, b) => String(b.date_reunion || b.date || '').localeCompare(String(a.date_reunion || a.date || '')));
                ctx.ess = ess[0] || null;
            } catch (e) { ctx.ess = null; }
        }

        return ctx;
    },

    /* ── Mise en forme des valeurs ────────────────────────────────────────────── */

    _t(x) {
        return x === null || x === undefined ? '' : String(x).trim();
    },

    /** « 2015-03-04 » → « 04 » / « 03 » / « 2015 ». Rien d'inventé : une date illisible reste vide. */
    _partieDate(iso, partie) {
        const m = this._t(iso).match(/^(\d{4})-(\d{2})-(\d{2})/);
        if (!m) return '';
        if (partie === 'jour') return m[3];
        if (partie === 'mois') return m[2];
        if (partie === 'annee') return m[1];
        // Le formulaire imprime « 20 __ » : ces cases n'acceptent que deux chiffres.
        if (partie === 'annee_courte') return m[1].slice(-2);
        return '';
    },

    /**
     * Découpe une adresse française en rue / code postal / ville.
     * Seul un code postal à CINQ CHIFFRES suivi de la ville, en fin d'adresse, est reconnu :
     * dans le doute on ne coupe pas et la rue garde l'adresse entière (l'enseignant corrige).
     */
    _partieAdresse(texte, partie) {
        const s = this._t(texte);
        if (!s) return '';
        const m = s.match(/(\d{5})\s+([^,]+)\s*$/);
        if (!m) return partie === 'rue' ? s : '';
        const rue = s.slice(0, m.index).replace(/[,\s]+$/, '').trim();
        if (partie === 'rue') return rue;
        if (partie === 'code_postal') return m[1];
        if (partie === 'ville') return m[2].trim();
        return '';
    },

    _adresseComplete(entite) {
        // Une adresse ne se répète pas : quand la rue porte déjà « 16700 Ruffec », on ne
        // rajoute ni le code postal ni la ville — sinon on imprime « Ruffec Ruffec ».
        if (!entite) return '';
        const rue = this._t(entite.adresse);
        const cp = this._t(entite.code_postal);
        const ville = this._t(entite.ville);
        const nu = rue.toLowerCase();
        const aCp = cp !== '' && nu.indexOf(cp) !== -1;
        const aVille = ville !== '' && nu.indexOf(ville.toLowerCase()) !== -1;
        return [rue, aCp ? '' : cp, aVille ? '' : ville].filter(Boolean).join(' ');
    },

    /** Année scolaire : « 2025-2026 » → début 2025, fin 2026. */
    _partieAnneeScolaire(annee, partie) {
        if (!annee) return '';
        let debut = this._t(annee.date_debut).slice(0, 4);
        let fin = this._t(annee.date_fin).slice(0, 4);
        if (!debut || !fin) {
            const m = this._t(annee.libelle || annee.nom).match(/(\d{4})\D+(\d{4})/);
            if (m) { debut = m[1]; fin = m[2]; }
        }
        if (!debut && !fin) return '';
        if (partie === 'debut') return debut;
        if (partie === 'fin') return fin;
        // « 20 __ » sur le papier : deux chiffres seulement, et on ne confond pas le début et la fin.
        if (partie === 'debut_court') return debut.slice(-2);
        if (partie === 'fin_courte') return fin.slice(-2);
        if (partie === 'annee_courte') return (debut || fin).slice(-2);
        return '';
    },

    /** Une valeur de la table : la SOURCE est nommée, jamais devinée. */
    _valeur(origine, partie, ctx) {
        const e = ctx.eleve || {};
        switch (origine) {
            case 'eleve.nom_prenom':
                return [this._t(e.nom), this._t(e.prenom)].filter(Boolean).join(' ');
            case 'eleve.date_naissance':
                return this._partieDate(e.date_naissance, partie);
            case 'eleve.adresse':
                return this._partieAdresse(e.adresse, partie);
            case 'eleve.telephone':
                return this._t(e.telephone);
            case 'eleve.email':
                return this._t(e.email);
            case 'eleve.numero_dossier_mdph':
                return this._t(e.numero_dossier_mdph);
            case 'eleve.classe_nom':
                return this._t(e.classe_nom || e.classe);
            case 'eleve.niveau_scolaire':
                return this._t(e.niveau_scolaire);
            case 'annee_scolaire':
                return this._partieAnneeScolaire(ctx.annee, partie);
            case 'etablissement.nom':
                return this._t(ctx.etablissement && ctx.etablissement.nom);
            case 'etablissement.adresse':
                return this._partieAdresse(this._adresseComplete(ctx.etablissement), partie);
            case 'enseignant_referent.nom':
                return [this._t(ctx.referent && ctx.referent.prenom), this._t(ctx.referent && ctx.referent.nom)]
                    .filter(Boolean).join(' ');
            case 'enseignant_referent.telephone':
                return this._t(ctx.referent && (ctx.referent.telephone || ctx.referent.tel));
            case 'enseignant_referent.courriel':
                return this._t(ctx.referent && (ctx.referent.email || ctx.referent.courriel));
            case 'emploi_du_temps':
                return this._partieEmploiDuTemps(ctx.creneaux, partie);
            case 'ess.derniere_date':
                return this._partieDate(ctx.ess && (ctx.ess.date_reunion || ctx.ess.date), partie);
            default:
                return '';
        }
    },

    /* ── L'écran de relecture ─────────────────────────────────────────────────── */

    /** Prépare les lignes à partir de l'élève, sans rien écrire nulle part. */
    async preparer(eleve) {
        const table = await this._table();
        const ctx = await this._contexte(eleve);
        this._eleve = eleve;
        this._lignes = (table.champs || []).map((c) => ({
            cle: c.cle,
            libelle: c.libelle || c.cle,
            groupe: c.groupe || '',
            origine: c.origine || '',
            valeur: this._valeur(c.origine, c.partie, ctx),
            garder: true,
        }));
        // Les zones qui n'ont pas de champ à remplir : on prépare un texte à recopier.
        this._textes = this._textePropose(ctx);
        return this._lignes;
    },

    /**
     * Ce que le formulaire ne peut pas recevoir tout seul.
     *
     * La grille des participants de l'ESS (page 8, 15 lignes) n'a pas de champ « liste » :
     * il y a 15 cases « Participant » et 15 cases « Fonction ». Calulis sait QUI était là
     * (la réunion ESS de l'élève), pas qui est un nom et qui est une fonction — il ne le
     * devine pas : il donne la liste telle qu'elle a été saisie, prête à recopier.
     */
    _textePropose(ctx) {
        const blocs = [];
        const ess = ctx.ess || null;
        const brut = ess && ess.participants ? ess.participants : '';
        let noms = Array.isArray(brut)
            ? brut.map((x) => (typeof x === 'string' ? x : (x && (x.nom || x.label)) || ''))
            : String(brut).split(/[;,\n\/]+/);
        noms = noms.map((s) => this._t(s)).filter(Boolean);
        if (noms.length) {
            const gardes = noms.slice(0, 15);
            blocs.push({
                titre: 'Participants à l\'ESS — page 8, colonne « Participant »',
                note: (gardes.length < noms.length
                    ? 'Le formulaire n\'a que 15 lignes : les premières sont proposées, les autres sont à ajouter à la main. '
                    : 'Un participant par ligne. ')
                    + 'Les fonctions, elles, restent à écrire : Calulis ne les devine pas.',
                texte: gardes.join('\n'),
            });
        }
        return blocs;
    },

    _html() {
        const TITRES = {
            noyau: 'Le formulaire — année scolaire et réunion',
            eleve: 'L\'élève et sa scolarité',
            ess: 'L\'équipe de suivi',
            parcours: 'Parcours de scolarisation',
            emploi_du_temps: 'Emploi du temps (page 3) — le moment d\'un créneau est celui où il commence : '
                + 'matin avant 12 h, midi de 12 h à 13 h 30, après-midi à partir de 13 h 30',
        };
        const remplies = this._lignes.filter((l) => l.valeur).length;
        let groupeVu = null;
        const lignes = this._lignes.map((l, i) => {
            const titre = (l.groupe && l.groupe !== groupeVu && TITRES[l.groupe])
                ? '<tr><th colspan="3" style="text-align:left;padding:12px 0 4px;font-size:12px;'
                  + 'letter-spacing:.03em;text-transform:uppercase;color:var(--text-muted)">'
                  + escapeHtml(TITRES[l.groupe]) + '</th></tr>'
                : '';
            if (l.groupe) groupeVu = l.groupe;
            return titre + '<tr>'
                + '<td style="vertical-align:top;padding:3px 8px 3px 0">'
                + '<label for="gevasco-v-' + i + '" style="font-size:13px;cursor:pointer">' + escapeHtml(l.libelle) + '</label>'
                + '</td>'
                + '<td style="padding:3px 8px 3px 0">'
                // Une case d'emploi du temps porte plusieurs lignes : un champ d'une seule
                // ligne les collerait bout à bout (le navigateur retire les retours).
                + (l.groupe === 'emploi_du_temps'
                    ? '<textarea id="gevasco-v-' + i + '" class="gevasco-valeur" data-i="' + i + '"'
                        + ' rows="' + Math.max(2, Math.min(6, String(l.valeur || '').split('\n').length)) + '"'
                        + ' style="width:100%;font-family:inherit;font-size:13px;resize:vertical"'
                        + ' placeholder="(vide — à remplir à la main)">' + escapeHtml(l.valeur) + '</textarea>'
                    : '<input type="text" id="gevasco-v-' + i + '" class="gevasco-valeur" data-i="' + i + '"'
                        + ' value="' + escapeHtml(l.valeur) + '" style="width:100%"'
                        + (l.valeur ? '' : ' placeholder="' + (l.origine === 'enseignant_referent.nom'
                            ? '(aucun enseignant référent désigné sur la fiche)'
                            : '(vide — à remplir à la main)') + '"') + '>')
                + '</td>'
                + '<td style="text-align:center;padding:3px 0" title="Remplir cette case">'
                + '<input type="checkbox" class="gevasco-garder" data-i="' + i + '"'
                + ' aria-label="Remplir la case ' + escapeHtml(l.libelle) + '"'
                + (l.garder ? ' checked' : '') + '>'
                + '</td>'
                + '</tr>';
        }).join('');

        // Ce que le formulaire ne reçoit pas tout seul : prêt à recopier.
        const textesHtml = (this._textes || []).length
            ? '<div style="margin-top:14px;border-top:1px solid var(--border,#ddd);padding-top:10px">'
                + '<div class="form-section-title" style="margin-bottom:2px">À recopier à la main dans le PDF</div>'
                + '<p class="text-muted small" style="margin:0 0 6px">Ces cases du formulaire n\'ont pas de champ : '
                + 'le texte ci-dessous est prêt, il ne reste qu\'à le coller au bon endroit.</p>'
                + this._textes.map((b, i) => '<div style="margin-top:8px">'
                    + '<label for="gevasco-t-' + i + '" style="font-size:13px;font-weight:600">' + escapeHtml(b.titre) + '</label>'
                    + '<p class="text-muted small" style="margin:2px 0 4px">' + escapeHtml(b.note) + '</p>'
                    + '<textarea readonly id="gevasco-t-' + i + '" data-copie="' + i + '" rows="'
                        + Math.max(2, Math.min(8, String(b.texte).split('\n').length)) + '"'
                        + ' style="width:100%;font-family:inherit;font-size:13px">' + escapeHtml(b.texte) + '</textarea>'
                    + '<button type="button" class="btn-sm btn-secondary btn-copier" data-copie="' + i + '"'
                        + ' style="margin-top:4px">📋 Copier</button>'
                    + '</div>').join('')
                + '</div>'
            : '';
        return '<div class="aide-note" style="margin-bottom:8px">'
            + '<strong>' + this._lignes.length + ' cases</strong> — ' + remplies + ' avec une valeur proposée, '
            + (this._lignes.length - remplies) + ' vide(s) à remplir à la main. '
            + 'Corrigez ce qui doit l\'être, décochez ce que vous ne voulez pas voir écrit, '
            + 'puis fabriquez le PDF : il reste modifiable dans Acrobat (les autres cases vous attendent).'
            + '</div>'
            + '<div style="max-height:46vh;overflow:auto">'
            + '<table style="width:100%;border-collapse:collapse"><tbody>' + lignes + '</tbody></table>'
            + '</div>'
            + textesHtml
            + '<div style="margin-top:10px;display:flex;gap:8px;align-items:center;flex-wrap:wrap">'
            + '<button class="btn btn-primary" id="btn-gevasco-fabriquer">📄 Fabriquer le PDF</button>'
            + '<span id="gevasco-etat" class="text-muted small"></span>'
            + '</div>';
    },

    /** Affiche la relecture dans la zone de l'onglet MDPH (pas de modale dans la modale). */
    async afficher(zoneId, eleve) {
        const zone = document.getElementById(zoneId);
        if (!zone) return;
        zone.innerHTML = '<p class="text-muted small">Préparation…</p>';
        try {
            await this.preparer(eleve);
            zone.innerHTML = this._html();
            zone.querySelectorAll('.gevasco-valeur').forEach((input) => {
                input.addEventListener('input', () => {
                    this._lignes[Number(input.dataset.i)].valeur = input.value;
                });
            });
            zone.querySelectorAll('.gevasco-garder').forEach((cb) => {
                cb.addEventListener('change', () => {
                    this._lignes[Number(cb.dataset.i)].garder = cb.checked;
                });
            });
            // Le texte à recopier : un bouton par bloc, qui copie exactement ce qui est affiché.
            zone.querySelectorAll('.btn-copier').forEach((b) => {
                b.addEventListener('click', async () => {
                    const bloc = (this._textes || [])[Number(b.dataset.copie)];
                    if (!bloc) return;
                    try {
                        await navigator.clipboard.writeText(bloc.texte);
                    } catch (e) {
                        // Presse-papiers refusé (page non sécurisée, navigateur ancien) :
                        // on sélectionne le texte, la personne fait Ctrl+C.
                        const t = zone.querySelector('textarea[data-copie="' + b.dataset.copie + '"]');
                        if (t) { t.focus(); t.select(); }
                    }
                    Toast.success('Texte copié — collez-le dans le formulaire.');
                });
            });
            document.getElementById('btn-gevasco-fabriquer')
                .addEventListener('click', (ev) => Action.uneSeule(ev.currentTarget, () => this.fabriquer()));
        } catch (e) {
            zone.innerHTML = '<p class="text-danger small">Le formulaire n\'a pas pu être préparé : '
                + escapeHtml(e && e.message ? e.message : String(e)) + '</p>';
        }
    },

    /* ── La fabrication du PDF ────────────────────────────────────────────────── */

    /**
     * L'emploi du temps du formulaire : six jours, trois moments (matin, midi, après-midi).
     *
     * La règle des moments est simple et se lit à l'écran avant d'être écrite : le matin
     * s'arrête à 12 h, le midi va de 12 h à 13 h 30 (la pause), l'après-midi commence à
     * 13 h 30. Un créneau appartient au moment où il COMMENCE — un créneau de 11 h 30 à
     * 12 h 30 reste donc le matin, là où l'élève l'a commencé.
     *
     * Chaque ligne porte l'horaire, l'activité et le lieu : « (ULIS) » quand l'élève est
     * dans le dispositif, la classe sinon — c'est ce que le GEVA-Sco demande
     * (« temps de scolarisation, … lieux »).
     */
    _partieEmploiDuTemps(creneaux, partie) {
        const m = /^([a-z]+)-(matin|midi|apres-midi)$/.exec(String(partie || ''));
        if (!m) return '';
        const jour = m[1];
        const moment = m[2] === 'apres-midi' ? 'après-midi' : m[2];
        const bornes = {
            'matin': [0, 12 * 60],
            'midi': [12 * 60, 13 * 60 + 30],
            'après-midi': [13 * 60 + 30, 24 * 60],
        };
        const [debut, fin] = bornes[moment] || [0, 24 * 60];
        const enMinutes = (h) => {
            const p = String(h || '').split(':');
            const hh = Number(p[0]); const mm = Number(p[1]);
            if (isNaN(hh)) return null;
            return hh * 60 + (isNaN(mm) ? 0 : mm);
        };
        const hhmm = (n) => {
            const h = Math.floor(n / 60); const mn = n % 60;
            return (h < 10 ? '0' : '') + h + ':' + (mn < 10 ? '0' : '') + mn;
        };
        return (creneaux || [])
            .filter((c) => String(c.jour || '').toLowerCase() === jour)
            .map((c) => ({ c, d: enMinutes(c.heure_debut) }))
            .filter((x) => x.d !== null && x.d >= debut && x.d < fin)
            .sort((x, y) => x.d - y.d)
            .map((x) => {
                const duree = Number(x.c.duree) > 0 ? Number(x.c.duree) : 0;
                const texte = hhmm(x.d) + '–' + hhmm(x.d + duree) + ' ' + this._t(x.c.matiere);
                const groupe = this._t(x.c.groupe);
                return groupe ? texte + ' (' + groupe + ')' : texte;
            })
            .join('\n');
    },

    /**
     * Une case laissée en taille AUTOMATIQUE écrit la valeur à la hauteur de la case :
     * dans le grand rectangle « Niveau d'enseignement dans les apprentissages », « CP »
     * sortait en lettres de 60 points, comme un titre. On force donc une taille de texte
     * dans toute case haute ou multiligne — le reste (dates, code postal, « 26 ») garde
     * l'automatique, qui s'ajuste proprement aux petites cases.
     */
    _tailleLisible(champ, valeur) {
        try {
            const widgets = champ.acroField.getWidgets ? champ.acroField.getWidgets() : [];
            if (!widgets.length) return;
            const r = widgets[0].getRectangle();
            const multi = champ.isMultiline ? champ.isMultiline() : false;
            if (!multi && r.height <= 26) return;
            const lignes = String(valeur).split('\n');
            // Le plus grand corps qui tient : on essaie 9, 8, 7… et on garde le premier qui
            // ne déborde ni en hauteur ni en largeur (Helvetica ≈ 0,5 point par caractère).
            for (let taille = 9; taille >= 5; taille--) {
                const parLigne = Math.max(1, Math.floor((r.width - 6) / (taille * 0.5)));
                let n = 0;
                for (const l of lignes) n += Math.max(1, Math.ceil(l.length / parLigne));
                if (n * (taille * 1.3) <= r.height - 6) {
                    if (champ.setFontSize) champ.setFontSize(taille);
                    return;
                }
            }
            if (champ.setFontSize) champ.setFontSize(5);
        } catch (e) { /* la valeur reste écrite, seule la taille n'a pas pu être fixée */ }
    },

    /**
     * Une case remplie dessine son cadre : collé dans une cellule du tableau de l'emploi du
     * temps, ce rectangle ressemble à une erreur de mise en page sur un document officiel.
     * On met la bordure de la case à zéro — la valeur s'imprime, le cadre disparaît.
     */
    _sansBordure(doc, champ) {
        try {
            const widgets = champ.acroField.getWidgets ? champ.acroField.getWidgets() : [];
            if (!widgets.length || typeof PDFLib.PDFName === 'undefined') return;
            const zero = doc.context.obj({ S: PDFLib.PDFName.of('S'), W: 0 });
            widgets.forEach((w) => w.dict.set(PDFLib.PDFName.of('BS'), zero));
        } catch (e) { /* la valeur reste écrite ; seule la bordure peut subsister */ }
    },

    async fabriquer() {
        const etat = document.getElementById('gevasco-etat');
        const dire = (t) => { if (etat) etat.textContent = t; };

        if (typeof PDFLib === 'undefined') {
            dire('Le moteur de remplissage (pdf-lib) n\'est pas chargé.');
            if (typeof Toast !== 'undefined') Toast.error('Moteur de remplissage absent : rechargez Calulis.');
            return;
        }

        const poses = this._lignes.filter((l) => l.garder && l.valeur !== '');
        if (!poses.length) { dire('Aucune case à remplir : décochez moins, ou saisissez au moins une valeur.'); return; }

        dire('Fabrication…');
        try {
            const doc = await PDFLib.PDFDocument.load(await this._vierge());
            const form = doc.getForm();
            const ecrites = [];
            const absentes = [];
            const tropLongues = [];
            for (const l of poses) {
                try {
                    const champ = form.getTextField(l.cle);
                    // Garde-fou : une case qui n'a pas la place ne reçoit rien. Couper la valeur
                    // en silence écrirait « 20 » pour l'année 2026.
                    const place = champ.getMaxLength ? champ.getMaxLength() : null;
                    if (place && l.valeur.length > place) {
                        tropLongues.push(l.cle + ' (' + l.valeur.length + ' > ' + place + ')');
                        continue;
                    }
                    champ.setText(l.valeur);
                    this._tailleLisible(champ, l.valeur);
                    this._sansBordure(doc, champ);
                    ecrites.push(l.cle);
                } catch (e) {
                    absentes.push(l.cle);
                }
            }
            if (tropLongues.length) {
                dire('Trop long pour la case : ' + tropLongues.join(', '));
                if (typeof Toast !== 'undefined') {
                    Toast.error('Ces cases n\'ont pas la place : ' + tropLongues.join(', ') + '. Raccourcissez la valeur.');
                }
                return;
            }
            if (!ecrites.length) {
                dire('Aucune case n\'a pu être écrite.');
                if (typeof Toast !== 'undefined') Toast.error('Le formulaire livré ne correspond plus à la table de remplissage.');
                return;
            }
            form.updateFieldAppearances();
            const octets = await doc.save();
            this._telecharger(octets, this._nomFichier());

            const mot = ecrites.length + ' case(s) remplie(s)'
                + (absentes.length ? ' — ' + absentes.length + ' refusée(s) par le formulaire (' + absentes.join(', ') + ')' : '');
            dire(mot);
            if (typeof Toast !== 'undefined') Toast.success('GEVA-Sco fabriqué : ' + mot);
        } catch (e) {
            dire('Échec : ' + (e && e.message ? e.message : String(e)));
            if (typeof Toast !== 'undefined') Toast.error('GEVA-Sco : ' + (e && e.message ? e.message : String(e)));
        }
    },

    _nomFichier() {
        const e = this._eleve || {};
        const brut = [e.nom, e.prenom].map((x) => this._t(x)).filter(Boolean).join('_') || 'eleve';
        const propre = brut.replace(/[^A-Za-z0-9_-]+/g, '_').replace(/^_+|_+$/g, '');
        const jour = new Date().toISOString().slice(0, 10);
        return 'GEVA-Sco_reexamen_' + propre + '_' + jour + '.pdf';
    },

    _telecharger(octets, nom) {
        const blob = new Blob([octets], { type: 'application/pdf' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = nom;
        a.click();
        URL.revokeObjectURL(url);
    },
};
