<?php
/**
 * Calulis — Point d'entrée API / Router CLI server
 * Utilisé comme router : php -S localhost:8081 api/router.php
 * Laisse passer les fichiers statiques, route les /api/* vers les controllers
 */
// Serveur intégré : servir les fichiers statiques
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
if (php_sapi_name() === 'cli-server') {
    $filePath = __DIR__ . '/..' . $uri;
    if ($uri === '/' && is_dir(__DIR__ . '/..')) {
        return false; // index.html automatique
    }
    if (is_file($filePath)) {
        return false; // fichier statique (JS, CSS, etc.)
    }
}

require_once __DIR__ . '/config.php';

// ── En-têtes de sécurité (S9, audit du 27/10/2026) ─────────────────────────────
// Calulis est une application LOCALE : la réponse n'a aucune raison d'être encadrée,
// devinée ou interprétée comme autre chose que ce qu'elle est. La version de PHP n'est
// pas une information à publier.
header_remove('X-Powered-By');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('Referrer-Policy: no-referrer');
header('Permissions-Policy: geolocation=(), microphone=(), camera=(), payment=()');
// Une réponse d'API est du JSON, pas une page : rien ne doit s'y charger ni s'y exécuter.
header("Content-Security-Policy: default-src 'none'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'");

// ─────────────────────────────────────────────────────────────────
// Erreurs TOUJOURS lisibles : réponse JSON + log fichier pour le support.
// Sans ça, un fatal PHP répond 500 avec un corps non-JSON et le frontend
// affiche le statusText HTTP brut (ex. « Internal Server Error »).
//
// calulis_log_error() est définie dans config.php (socle commun, donc aussi
// disponible en développement) : ne pas la redéfinir ici.
// ─────────────────────────────────────────────────────────────────

// Le message d'erreur envoyé au navigateur ne porte AUCUN détail brut : celui-ci peut
// citer une valeur d'élève (« Duplicate entry 'DUPONT Jean' »), et l'interface le
// conserve puis le recopie dans le signalement de bug (constat C de la revue RGPD du
// 08/10/2026). Le détail complet reste dans le journal, sur le poste. Un paramètre
// unique rend la fuite impossible : il n'y a plus rien à passer.
function calulis_erreur_json(string $message): void
{
    if (headers_sent()) { return; }
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['error' => calulis_message_sur($message)], JSON_UNESCAPED_UNICODE);
}

// Auto-réparation du schéma : applique les migrations en attente une fois par processus.
// Voir calulis_auto_migrate() dans config.php (partagé avec dev-router.php).
calulis_auto_migrate();

// 1) Exceptions non rattrapées (PDO, Error, TypeError…) → JSON + log
set_exception_handler(function (Throwable $e): void {
    calulis_log_error('EXCEPTION ' . get_class($e) . ': ' . $e->getMessage()
        . ' @ ' . $e->getFile() . ':' . $e->getLine() . "
" . $e->getTraceAsString());
    calulis_erreur_json('Erreur technique. Le détail est enregistré dans les logs (bouton « Ouvrir les logs » du lanceur).');
    exit(1);
});

// 2) Erreurs fatales (fonction inconnue, extension manquante…) → JSON + log
register_shutdown_function(function (): void {
    $err = error_get_last();
    if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
        calulis_log_error('FATAL ' . $err['message'] . ' @ ' . $err['file'] . ':' . $err['line']);
        calulis_erreur_json('Erreur technique du serveur. Le détail est enregistré dans les logs (bouton « Ouvrir les logs » du lanceur).');
    }
});

// ── CORS : UNE seule origine autorisée, celle que sert le paquet portable.
//
// Avant le 05/10/2026, tout `http://127.0.0.1:<n'importe quel port>` était reflété :
// une page ouverte dans le même navigateur sur un autre port local (par exemple un
// site servi par un outil quelconque) pouvait donc lire les réponses de l'API Calulis
// — qui manipule des données nominatives d'élèves, sans aucun mot de passe.
//
// L'application elle-même est servie en same-origin (ses appels sont relatifs) :
// elle n'a besoin d'aucun en-tête CORS. Une origine non listée n'en reçoit aucun,
// et le navigateur bloque la lecture.
$calulisOriginesAutorisees = ['http://127.0.0.1:8088'];
$calulisOrigin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (in_array($calulisOrigin, $calulisOriginesAutorisees, true)) {
    header('Access-Control-Allow-Origin: ' . $calulisOrigin);
    header('Vary: Origin');
}
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Calulis-App');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

// ── Contrôle de l'HÔTE : le rempart contre le « DNS rebinding » ───────────────
//
// Vérifier que l'appelant vient de la boucle locale (`REMOTE_ADDR`, dans config.php)
// NE SUFFIT PAS. Une page web quelconque dont le domaine résout vers 127.0.0.1
// atteint Calulis avec l'adresse de la boucle locale, et le jeton anti-CSRF posé
// plus bas n'est que la constante « 1 » — publique dans api.js. Dans ce scénario,
// le navigateur considère la requête comme same-origin : ni CORS ni préflight ne
// s'y opposent, et une page visitée pourrait lire des données nominatives d'élèves.
//
// Le seul élément que l'attaquant ne peut PAS falsifier est le nom qu'il a fait
// résoudre : on refuse donc tout Hôte qui n'est pas la boucle locale (le port est
// libre — le serveur de développement et les tests en changent).
$calulisHote = strtolower(trim((string)($_SERVER['HTTP_HOST'] ?? '')));
$calulisNomHote = (string)preg_replace('/:\d+$/', '', $calulisHote);
if ($calulisHote !== '' && !in_array($calulisNomHote, ['127.0.0.1', 'localhost', '[::1]', '::1'], true)) {
    calulis_log_error('Requête refusée : hôte non local (' . $calulisNomHote . ')');
    jsonError('Requête refusée : Calulis ne répond qu\'à cette machine.', 403);
}
// Même règle pour l'origine déclarée, quand il y en a une.
if ($calulisOrigin !== '') {
    $calulisNomOrigine = strtolower((string)(parse_url($calulisOrigin, PHP_URL_HOST) ?? ''));
    if (!in_array($calulisNomOrigine, ['127.0.0.1', 'localhost', '[::1]', '::1'], true)) {
        jsonError('Requête refusée : origine non locale.', 403);
    }
}

// (L'anti-CSRF est vérifié plus bas, APRÈS le calcul de la route : l'exemption doit porter
// sur le contrôleur qui va s'exécuter, jamais sur un paramètre de requête.)

// Router les requêtes /api/* vers les controllers
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
$uri = rtrim($uri, '/');

if (strpos($uri, '/api/') === false) {
    if (php_sapi_name() === 'cli-server') return false;
    jsonError('Route non trouvée', 404);
}

$parts = explode('/', trim($uri, '/'));
$resource = $parts[count($parts) - 1] ?? '';
$resource = str_replace('.php', '', $resource);

// ── Anti-CSRF : l'API n'accepte que les requêtes portant le jeton interne (posé par l'app via
// le wrapper fetch global). Les requêtes cross-site ne peuvent pas poser d'en-tête custom sans
// préflight (refusé plus haut).
// L'exemption porte sur la ROUTE QUI VA S'EXÉCUTER : /api/migrate, appelée par le lanceur
// (MigrationService) pendant une mise à jour, sans l'en-tête. Elle ne doit PAS dépendre d'un
// paramètre : avec « ?r=/api/migrate », Caddy ajoute {query} et PHP retient le DERNIER r, si
// bien qu'une requête visant eleves.php passait pour une migration et échappait au jeton
// (constat S3 de l'audit du 27/10/2026).
if (($_SERVER['HTTP_X_CALULIS_APP'] ?? '') !== '1' && $resource !== 'migrate') {
    jsonError('Requête refusée (jeton anti-CSRF manquant). Rechargez l\'application.', 403);
}


// ── LE VERROU D'OUVERTURE (lot 8, décision du 31/10/2026) ──────────────────────
// Un mot de passe OPTIONNEL à l'ouverture, désactivé par défaut. Il arrête une personne
// devant l'écran ; il ne protège PAS les fichiers : qui a la main sur le disque lit la base
// et `runtime/documents` sans lui — c'est écrit dans l'aide, et le code ne prétend pas autre
// chose. La porte est ICI et pas seulement dans l'écran : une requête qui ne vient pas de la
// page (curl, autre onglet resté ouvert, script) est refusée comme les autres.
//
// Restent ouvertes les routes sans lesquelles on ne pourrait plus jamais entrer le mot de
// passe, ni vérifier que le serveur répond : `verrou`, `ping`, et `migrate` (appelée par le
// lanceur pendant une mise à jour, qui ne peut pas taper de mot de passe).
$calulisRoutesLibres = ['verrou', 'ping', 'migrate'];
if (!in_array($resource, $calulisRoutesLibres, true)) {
    require_once __DIR__ . '/models/Verrou.php';
    if (Verrou::actif() && !Verrou::sessionValide($_COOKIE['calulis_verrou'] ?? null)) {
        header('X-Calulis-Verrou: 1');
        jsonError('Calulis est verrouillé : entrez le mot de passe pour continuer.', 401);
    }
}
// ── Plafond de corps AVANT toute lecture (S4, audit du 27/10/2026) ────────────
// Sans plafond, un envoi énorme est lu ENTIÈREMENT en mémoire avant d'être refusé par le
// contrôle métier (l'import .ics vérifie ses 2 Mo APRÈS avoir tout reçu). On refuse donc
// sur la taille ANNONCÉE, avant d'ouvrir le corps. Deux limites, parce que les deux cas
// n'ont rien à voir : un envoi de fichier (multipart) peut être gros — il est déjà borné
// par post_max_size et écrit sur disque ; un corps JSON est lu en mémoire, et
// memory_limit=128M interdit de le laisser grossir.
$calulisType = strtolower((string)($_SERVER['CONTENT_TYPE'] ?? ''));
$calulisEstFichier = str_starts_with($calulisType, 'multipart/form-data');
$calulisPlafond = 16 * 1024 * 1024; // 16 Mo pour un corps JSON
if ($calulisEstFichier) {
    $calulisBrut = trim((string) ini_get('post_max_size'));
    $calulisFacteurs = ['k' => 1024, 'm' => 1048576, 'g' => 1073741824];
    $calulisPlafond = ($calulisBrut === '') ? 100 * 1024 * 1024
        : (int)$calulisBrut * ($calulisFacteurs[strtolower(substr($calulisBrut, -1))] ?? 1);
}
// L'import .ics a son propre contrat : 2 Mo de contenu, donc une enveloppe JSON de 4 Mo.
if ($resource === 'calendrier') { $calulisPlafond = 4 * 1024 * 1024; }
$calulisTaille = (int)($_SERVER['CONTENT_LENGTH'] ?? 0);
if ($calulisTaille > $calulisPlafond) {
    calulis_log_error('Corps de requête refusé : ' . $calulisTaille . ' octets > ' . $calulisPlafond . ' (' . $resource . ')');
    jsonError(
        'Envoi trop volumineux : ' . round($calulisTaille / 1048576, 1) . ' Mo, la limite pour cette action est de '
        . round($calulisPlafond / 1048576) . ' Mo. Rien n\'a été modifié.',
        413
    );
}

$controllerFile = __DIR__ . '/controllers/' . $resource . '.php';
if (file_exists($controllerFile)) {
    // 2e barrière : un contrôleur marqué « développement » n'est JAMAIS exécuté
    // en production. Il est aussi retiré du paquet à la construction
    // (scripts/build-portable.ps1) : si on le retrouve ici, c'est qu'il a été
    // recopié à la main ou livré par erreur — on refuse.
    // Le marqueur vit dans le fichier lui-même : une seule source de la liste.
    if (getenv('CALULIS_ENV') === 'production') {
        $tete = (string) @file_get_contents($controllerFile, false, null, 0, 2048);
        if (str_contains($tete, '@calulis-controleur-dev')) {
            calulis_log_error('Contrôleur de développement refusé en production : ' . $resource);
            jsonError('Route non trouvée : ' . $resource, 404);
        }
    }
    require_once $controllerFile;
} else {
    jsonError('Route non trouvée : ' . $resource, 404);
}
