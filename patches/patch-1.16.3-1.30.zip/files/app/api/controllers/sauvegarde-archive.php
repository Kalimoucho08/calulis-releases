<?php
/**
 * Calulis — Sauvegarde complète : UNE archive (base + documents) — lot 7.
 *
 * GET  /api/sauvegarde-archive.php          → les archives présentes sur le disque
 * GET  …?fichier=<nom>                      → envoie une archive existante au navigateur
 * POST /api/sauvegarde-archive.php          → en fabrique une, et rend son compte rendu (JSON)
 *
 * POURQUOI
 * Avant le 31/10/2026, une sauvegarde n'emportait que la base : les documents
 * rapatriés (runtime/documents) n'étaient dans AUCUNE sauvegarde. Décision de
 * Jérôme : une seule archive, et la restauration dans le même lot.
 *
 * POURQUOI LE TÉLÉCHARGEMENT EST UN GET À PART
 * Fabriquer l'archive et l'envoyer dans la même réponse obligeait le navigateur à
 * télécharger sans savoir ce qui avait été fabriqué (nom, taille, nombre de
 * documents) : on ne pouvait donc rien dire à l'écran. Ici, le POST fabrique et
 * répond en JSON ; le GET sert ensuite le fichier déjà écrit, par son nom, sans
 * jamais accepter un chemin (le nom est rapproché de la liste réelle).
 *
 * CE QUE CE CONTRÔLEUR NE FAIT PAS
 * Il ne restaure rien (voir restauration-archive.php) et ne supprime aucune archive.
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/SauvegardeArchive.php';
require_once __DIR__ . '/../models/Sauvegarde.php';

$methode = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($methode === 'GET') {
    // ── Servir une archive déjà présente ───────────────────────────────────────
    $fichier = trim((string) ($_GET['fichier'] ?? ''));
    if ($fichier !== '') {
        $nom = basename($fichier);
        $trouve = null;
        foreach (SauvegardeArchive::lister() as $a) {
            if ($a['nom'] === $nom && $a['dossier'] !== '' && is_file($a['chemin'])) {
                $trouve = $a;
                break;
            }
        }
        if ($trouve === null) {
            jsonError('Cette sauvegarde n\'est pas dans le dossier des sauvegardes.', 404);
            return;
        }
        // Le nom du fichier proposé au navigateur porte la DATE du dossier d'archive
        // (2026-10-31_12-48-06) : deux sauvegardes du même jour ne s'écrasent pas.
        $jour = substr(basename(dirname($trouve['chemin'])), 0, 10);
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $jour)) {
            $jour = date('Y-m-d');
        }
        $propose = 'Calulis-sauvegarde-' . $jour . '.zip';
        header('Content-Type: application/zip');
        header('Content-Disposition: attachment; filename="' . $propose . '"');
        header('Content-Length: ' . (string) $trouve['octets']);
        header('Cache-Control: no-store');
        readfile($trouve['chemin']);
        return;
    }

    // ── La liste ──────────────────────────────────────────────────────────────
    try {
        $archives = SauvegardeArchive::lister();
        jsonResponse([
            'dossier'  => Sauvegarde::cheminAffichable(SauvegardeArchive::dossierArchives()),
            'archives' => array_map(static fn($a) => [
                'nom'     => $a['nom'],
                'dossier' => $a['dossier'],
                'octets'  => $a['octets'],
                'taille'  => Stockage::tailleLisible($a['octets']),
            ], $archives),
        ]);
    } catch (Throwable $e) {
        calulis_log_error('LISTE DES ARCHIVES ÉCHOUÉE : ' . $e->getMessage());
        jsonError('Les archives n\'ont pas pu être listées.', 500);
    }
    return;
}

if ($methode !== 'POST') {
    jsonError('Méthode non supportée', 405);
}

try {
    $pdo = getDB();
    $resultat = SauvegardeArchive::creer($pdo, 'sauvegarde');
} catch (Throwable $e) {
    calulis_log_error('CRÉATION D\'ARCHIVE ÉCHOUÉE : ' . $e->getMessage());
    jsonError('La sauvegarde n\'a pas pu être faite : ' . $e->getMessage(), 500);
    return;
}

jsonResponse([
    'ok'        => true,
    'fichier'   => basename($resultat['chemin']),
    'dossier'   => Sauvegarde::cheminAffichable(dirname($resultat['chemin'])),
    'octets'    => $resultat['octets'],
    'taille'    => Stockage::tailleLisible($resultat['octets']),
    'tables'    => $resultat['tables'],
    'lignes'    => $resultat['lignes'],
    'documents' => $resultat['documents'],
], 201);
