<?php
/**
 * Calulis — Controller « Projets d'un élève » (la participation, lot 4 de la 1.30)
 *
 * C'est la seule chose que la fiche de l'élève ajoute au projet : le projet se décrit
 * une fois (controller projets.php), ici on dit seulement qui y a participé.
 *
 * GET    /api/eleve_projets.php?eleve_id=5        → les projets de cet élève
 * POST   /api/eleve_projets.php                   → {eleve_id, projet_id} : ajoute
 * DELETE /api/eleve_projets.php?eleve_id=5&projet_id=3 → retire
 */
require_once __DIR__ . '/../models/Projet.php';

$method = $_SERVER['REQUEST_METHOD'];
$eleveId = isset($_GET['eleve_id']) ? (int)$_GET['eleve_id'] : 0;
$projetId = isset($_GET['projet_id']) ? (int)$_GET['projet_id'] : 0;

function eleve_projets_entree(): array
{
    $json = json_decode((string)file_get_contents('php://input'), true);
    return is_array($json) ? $json : [];
}

try {
    switch ($method) {
        case 'GET':
            if ($eleveId <= 0) {
                jsonError('Paramètre eleve_id manquant', 400);
            }
            jsonResponse(Projet::parEleve($eleveId));

        case 'POST':
            $entree = eleve_projets_entree();
            $eleveId = (int)($entree['eleve_id'] ?? $eleveId);
            $projetId = (int)($entree['projet_id'] ?? $projetId);
            if ($eleveId <= 0 || $projetId <= 0) {
                jsonError('eleve_id et projet_id sont requis', 400);
            }
            Projet::participer($eleveId, $projetId);
            jsonResponse(['ok' => true], 201);

        case 'DELETE':
            $entree = eleve_projets_entree();
            $eleveId = (int)($entree['eleve_id'] ?? $eleveId);
            $projetId = (int)($entree['projet_id'] ?? $projetId);
            if ($eleveId <= 0 || $projetId <= 0) {
                jsonError('eleve_id et projet_id sont requis', 400);
            }
            Projet::retirer($eleveId, $projetId);
            jsonResponse(['ok' => true]);

        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (InvalidArgumentException $e) {
    jsonError($e->getMessage(), 400);
} catch (Throwable $e) {
    calulis_handle_error($e);
}
