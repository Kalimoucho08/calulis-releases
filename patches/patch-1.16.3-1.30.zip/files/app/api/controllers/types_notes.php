<?php
/**
 * Calulis — Controller Types de notes (décision 6.3 du 27/10/2026)
 *
 * Routes :
 *   GET    /api/types_notes.php                       la liste, avec le nombre de notes
 *                                                     qui utilise chaque type
 *   POST   /api/types_notes.php                       créer (libelle, couleur, ordre facultatif)
 *   PUT    /api/types_notes.php?id=N                  renommer / recolorer / réordonner / activer
 *   DELETE /api/types_notes.php?id=N                  supprimer — REFUSÉ si des notes l'utilisent
 *   POST   /api/types_notes.php?id=N&reaffecter=K     réaffecter ses notes au type de clé K,
 *                                                     PUIS supprimer le type
 *
 * LA CLÉ NE SE MODIFIE JAMAIS (voir TypeNote) : une note l'enregistre, et la changer
 * rendrait illisibles les notes déjà écrites. Renommer change le libellé, donc l'affichage
 * partout, y compris sur les notes des années passées.
 */
require_once __DIR__ . '/../models/TypeNote.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$reaffecterVers = isset($_GET['reaffecter']) ? trim((string)$_GET['reaffecter']) : '';

/** Corps de requête JSON. */
function types_notes_entree(): array
{
    $json = json_decode((string)file_get_contents('php://input'), true);
    return is_array($json) ? $json : [];
}

/** Un type enrichi de son nombre d'utilisations — ce que l'écran d'édition doit dire. */
function types_notes_avec_compteur(array $type): array
{
    $type['nb_notes'] = TypeNote::compterNotes((string)$type['cle']);
    return $type;
}

try {
    // Les cas terminent la requête par jsonResponse()/jsonError(), qui s'arrêtent là :
    // un « break » après eux serait du code mort (remarque PHPStan corrigée le
    // 30/10/2026, lot 3).
    switch ($method) {

        case 'GET':
            jsonResponse(array_map('types_notes_avec_compteur', TypeNote::tous(false)));

        case 'POST':
            // ── Réaffecter puis supprimer : la porte de sortie d'une suppression refusée ──
            if ($id > 0 && $reaffecterVers !== '') {
                $type = TypeNote::find($id);
                if (!$type) {
                    jsonError('Type de note non trouvé', 404);
                }
                if ($reaffecterVers === (string)$type['cle']) {
                    throw new InvalidArgumentException('Choisissez un autre type que celui que vous supprimez.');
                }
                if (TypeNote::parCle($reaffecterVers) === null) {
                    throw new InvalidArgumentException('Le type de destination est inconnu.');
                }
                $pdo = getDB();
                $pdo->beginTransaction();
                try {
                    $deplacees = TypeNote::reaffecter((string)$type['cle'], $reaffecterVers);
                    TypeNote::supprimer($id);
                    $pdo->commit();
                } catch (\Throwable $e) {
                    $pdo->rollBack();
                    throw $e;
                }
                jsonResponse(['ok' => true, 'notes_reaffectees' => $deplacees, 'vers' => $reaffecterVers]);
            }

            $entree = types_notes_entree();
            $libelle = trim((string)($entree['libelle'] ?? ''));
            $couleur = isset($entree['couleur']) ? (string)$entree['couleur'] : null;
            $ordre = isset($entree['ordre']) && $entree['ordre'] !== '' ? (int)$entree['ordre'] : null;
            $nouvelId = TypeNote::creer($libelle, $couleur, $ordre);
            jsonResponse(['ok' => true, 'id' => $nouvelId, 'type' => TypeNote::find($nouvelId)], 201);

        case 'PUT':
            if ($id <= 0) {
                jsonError('Identifiant du type manquant', 400);
            }
            if (!TypeNote::modifier($id, types_notes_entree())) {
                jsonError('Type de note non trouvé', 404);
            }
            jsonResponse(['ok' => true, 'id' => $id, 'type' => TypeNote::find($id)]);

        case 'DELETE':
            if ($id <= 0) {
                jsonError('Identifiant du type manquant', 400);
            }
            $type = TypeNote::find($id);
            if (!$type) {
                jsonError('Type de note non trouvé', 404);
            }
            $utilise = TypeNote::compterNotes((string)$type['cle']);
            if ($utilise > 0) {
                jsonError(
                    sprintf(
                        'Ce type est utilisé par %d note%s : réaffectez-%s à un autre type, '
                        . 'ou désactivez-le (il ne sera plus proposé, mais les notes déjà '
                        . 'écrites resteront lisibles).',
                        $utilise,
                        $utilise > 1 ? 's' : '',
                        $utilise > 1 ? 'les' : 'la'
                    ),
                    409
                );
            }
            // Constat R19 : sans aucun type, créer une note devient impossible (le type par
            // défaut n'existe plus). On refuse donc la suppression du dernier.
            if (TypeNote::compter() <= 1) {
                jsonError(
                    'Il faut garder au moins un type de note : créez-en un autre avant de '
                    . 'supprimer celui-ci. Sans type, aucune note ne peut plus être écrite.',
                    409
                );
            }
            TypeNote::supprimer($id);
            jsonResponse(['ok' => true, 'id' => $id, 'libelle' => (string)$type['libelle']]);

        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (InvalidArgumentException $e) {
    jsonError($e->getMessage(), 400);
} catch (RuntimeException $e) {
    jsonError($e->getMessage(), 409);
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
