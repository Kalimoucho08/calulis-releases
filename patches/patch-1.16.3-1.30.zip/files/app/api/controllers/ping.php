<?php
/** Calulis — Endpoint ping (test connexion) */
require_once __DIR__ . '/../config.php';
try {
    $pdo = getDB();
    jsonResponse(['ok' => true, 'mode' => USE_MYSQL ? 'MySQL' : 'SQLite']);
} catch (Exception $e) {
    calulis_log_error('[ping] ' . $e->getMessage());
    jsonError('Connexion échouée : ' . $e->getMessage(), 500);
}
