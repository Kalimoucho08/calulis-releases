<?php
/**
 * Calulis — Restauration d'une archive unique (base + documents) — lot 7.
 *
 * POST /api/restauration-archive.php
 *   champ « confirmation » : le mot RESTAURER, écrit par la personne
 *   champ « archive »      : le nom d'une archive présente dans le dossier des
 *                            archives (restauration d'une sauvegarde déjà faite)
 *   ou fichier « archivezip » : une archive choisie sur le poste
 *
 * CE QUE CE CONTRÔLEUR GARANTIT
 * Rien n'est remplacé si le mot de confirmation manque, si l'archive est illisible,
 * ou si la sauvegarde préalable de l'état actuel échoue. Le compte rendu dit ce qui
 * a été remplacé et où se trouve la sauvegarde de secours.
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Sauvegarde.php';
require_once __DIR__ . '/../models/SauvegardeArchive.php';
require_once __DIR__ . '/../models/Restauration.php';

if (($_SERVER['REQUEST_METHOD'] ?? 'GET') !== 'POST') {
    jsonError('Méthode non supportée', 405);
}

if (calulis_est_heberge() && getenv('CALULIS_ALLOW_IMPORT') !== '1') {
    jsonError('Restauration désactivée sur un déploiement hébergé', 403);
}

$confirmation = trim((string) ($_POST['confirmation'] ?? ''));
if ($confirmation === '') {
    jsonError('Restauration refusée : le mot de confirmation est vide. Rien n\'a été modifié.', 400);
}

// D'où vient l'archive : un fichier envoyé, ou une archive déjà présente sur le poste.
$chemin = '';
$temporaire = '';
$envoye = $_FILES['archivezip'] ?? null;
if ($envoye && ($envoye['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_OK) {
    $temporaire = (string) $envoye['tmp_name'];
    $chemin = $temporaire;
} else {
    $nom = basename((string) ($_POST['archive'] ?? ''));
    if ($nom === '' || !str_ends_with(strtolower($nom), '.zip')) {
        jsonError('Choisissez une archive (.zip) à restaurer : rien n\'a été modifié.', 400);
    }
    foreach (SauvegardeArchive::lister() as $a) {
        if ($a['nom'] === $nom && $a['dossier'] !== '' && is_file($a['chemin'])) {
            $chemin = $a['chemin'];
            break;
        }
    }
    if ($chemin === '') {
        jsonError('Cette archive n\'est pas dans le dossier des sauvegardes : rien n\'a été modifié.', 404);
        return;
    }
}

try {
    $pdo = getDB();
    $compte = Restauration::restaurer($pdo, $chemin, $confirmation);
    jsonResponse(['ok' => true] + $compte, 200);
} catch (Throwable $e) {
    calulis_log_error('RESTAURATION D\'ARCHIVE ÉCHOUÉE : ' . $e->getMessage());
    jsonError($e->getMessage(), 400);
} finally {
    // Le fichier envoyé (PHP l'a déposé dans /tmp) ne doit pas rester après usage.
    if ($temporaire !== '' && is_file($temporaire) && str_starts_with(str_replace('\\', '/', $temporaire), rtrim(sys_get_temp_dir(), '/'))) {
        @unlink($temporaire);
    }
}
