<?php
/**
 * Calulis — Le verrou d'ouverture (lot 8).
 *
 * GET  /api/verrou.php   → l'état : un mot de passe est-il posé, suis-je déverrouillé ?
 * POST /api/verrou.php   → {action: 'deverrouiller' | 'definir' | 'retirer' | 'verrouiller'}
 *
 * CE QUE CE CONTRÔLEUR NE FAIT PAS
 * Il ne dit jamais si un mot de passe est « bon » en dehors de la vérification demandée,
 * et il ne renvoie jamais l'empreinte ni le contenu du fichier. Une réponse ne contient
 * que : actif, déverrouillé, date de modification, chemin montrable, pause en cours.
 *
 * LA VRAIE BARRIÈRE EST AILLEURS
 * C'est le routeur (`router.php`) qui refuse TOUTE l'API quand le mot de passe est posé et
 * que le cookie de session manque. Ce contrôleur ne fait qu'ouvrir et fermer la porte.
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../models/Verrou.php';

const CALULIS_COOKIE_VERROU = 'calulis_verrou';

/** Pose le cookie de session : sans date d'expiration, il meurt avec le navigateur. */
function calulis_poser_cookie(string $jeton): void
{
    $options = [
        'expires'  => 0,
        'path'     => '/',
        'httponly' => true,
        'samesite' => 'Strict',
    ];
    if (!empty($_SERVER['HTTPS'])) { $options['secure'] = true; }
    setcookie(CALULIS_COOKIE_VERROU, $jeton, $options);
    $_COOKIE[CALULIS_COOKIE_VERROU] = $jeton;
}

function calulis_effacer_cookie(): void
{
    $options = ['expires' => time() - 3600, 'path' => '/', 'httponly' => true, 'samesite' => 'Strict'];
    if (!empty($_SERVER['HTTPS'])) { $options['secure'] = true; }
    setcookie(CALULIS_COOKIE_VERROU, '', $options);
    unset($_COOKIE[CALULIS_COOKIE_VERROU]);
}

function calulis_jeton_courant(): string
{
    $jeton = $_COOKIE[CALULIS_COOKIE_VERROU] ?? '';
    return is_string($jeton) ? $jeton : '';
}

function calulis_etat_verrou(): array
{
    $etat = Verrou::etat();
    $etat['deverrouille'] = !$etat['actif'] || Verrou::sessionValide(calulis_jeton_courant());
    return $etat;
}

$methode = $_SERVER['REQUEST_METHOD'] ?? 'GET';

if ($methode === 'GET') {
    jsonResponse(calulis_etat_verrou());
}

if ($methode !== 'POST') {
    jsonError('Méthode non supportée', 405);
}

$corps = json_decode((string) file_get_contents('php://input'), true);
if (!is_array($corps)) {
    $corps = $_POST;
}
$action = (string) ($corps['action'] ?? '');
$mot = (string) ($corps['mot'] ?? '');
$actuel = (string) ($corps['actuel'] ?? '');

switch ($action) {
    case 'deverrouiller':
        if (!Verrou::actif()) {
            jsonResponse(['ok' => true, 'message' => 'Aucun mot de passe : Calulis est ouvert.'] + calulis_etat_verrou());
        }
        $essai = Verrou::verifier($mot);
        if (!$essai['ok']) {
            header('X-Calulis-Verrou: 1');
            jsonResponse(['ok' => false, 'error' => $essai['message'], 'pause' => $essai['pause']] + calulis_etat_verrou(), 401);
        }
        $jeton = Verrou::ouvrirSession();
        calulis_poser_cookie($jeton);
        jsonResponse(['ok' => true, 'message' => 'Déverrouillé.'] + calulis_etat_verrou());
        break;

    case 'definir':
        $resultat = Verrou::definir($mot, $actuel);
        if (!$resultat['ok']) {
            jsonError($resultat['message'], 400);
        }
        // Celui qui vient de poser le mot de passe n'a pas à le retaper aussitôt.
        $jeton = Verrou::ouvrirSession();
        calulis_poser_cookie($jeton);
        jsonResponse(['ok' => true, 'message' => $resultat['message']] + calulis_etat_verrou());
        break;

    case 'retirer':
        $resultat = Verrou::retirer($mot);
        if (!$resultat['ok']) {
            jsonError($resultat['message'], 400);
        }
        calulis_effacer_cookie();
        jsonResponse(['ok' => true, 'message' => $resultat['message']] + calulis_etat_verrou());
        break;

    case 'verrouiller':
        Verrou::fermerSession(calulis_jeton_courant());
        calulis_effacer_cookie();
        jsonResponse(['ok' => true, 'message' => 'Calulis est verrouillé.'] + calulis_etat_verrou());
        break;

    default:
        jsonError('Action inconnue.', 400);
}