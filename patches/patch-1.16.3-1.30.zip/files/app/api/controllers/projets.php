<?php
/**
 * Calulis — Controller Projets (lot 4 de la 1.30, migration 028)
 *
 * GET    /api/projets.php                          → les projets de l'année (?annee_scolaire_id)
 *                                                   avec ?q=… pour chercher
 * GET    /api/projets.php?types=1                  → les types déjà saisis (autocomplétion)
 * GET    /api/projets.php?evenement_id=12          → les projets d'un événement (lecture seule)
 * GET    /api/projets.php?id=3                     → un projet et ses liens
 * POST   /api/projets.php                          → crée (nom, type, dates, classes, adultes, élèves)
 * PUT    /api/projets.php?id=3                     → remplace la fiche et ses liens
 * DELETE /api/projets.php?id=3                     → supprime (liens et participations compris)
 */
require_once __DIR__ . '/../models/Projet.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$anneeId = isset($_GET['annee_scolaire_id']) ? (int)$_GET['annee_scolaire_id'] : 0;

function projets_entree(): array
{
    $json = json_decode((string)file_get_contents('php://input'), true);
    return is_array($json) ? $json : [];
}

try {
    switch ($method) {
        case 'GET':
            // Les types d'abord : c'est une liste de chaînes, pas une liste de projets.
            if (!empty($_GET['types'])) {
                jsonResponse(Projet::types(isset($_GET['q']) ? (string)$_GET['q'] : null));
            }
            if (!empty($_GET['evenement_id'])) {
                jsonResponse(Projet::parEvenement((int)$_GET['evenement_id']));
            }
            if ($id > 0) {
                $projet = Projet::find($id);
                if (!$projet) {
                    jsonError('Projet introuvable', 404);
                }
                jsonResponse($projet);
            }
            jsonResponse(Projet::tous($anneeId > 0 ? $anneeId : null, (string)($_GET['q'] ?? '')));

        case 'POST':
            $nouvelId = Projet::creer(projets_entree());
            jsonResponse(['ok' => true, 'id' => $nouvelId, 'projet' => Projet::find($nouvelId)], 201);

        case 'PUT':
            $entree = projets_entree();
            $cible = $id > 0 ? $id : (int)($entree['id'] ?? 0);
            if ($cible <= 0) {
                jsonError('Identifiant du projet manquant', 400);
            }
            if (!Projet::modifier($cible, $entree)) {
                jsonError('Projet introuvable', 404);
            }
            jsonResponse(['ok' => true, 'projet' => Projet::find($cible)]);

        case 'DELETE':
            if ($id <= 0) {
                jsonError('Identifiant du projet manquant', 400);
            }
            if (!Projet::supprimer($id)) {
                jsonError('Projet introuvable', 404);
            }
            jsonResponse(['ok' => true, 'id' => $id]);

        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (InvalidArgumentException $e) {
    jsonError($e->getMessage(), 400);
} catch (\RuntimeException $e) {
    jsonError($e->getMessage(), 409);
} catch (Throwable $e) {
    calulis_handle_error($e);
}
