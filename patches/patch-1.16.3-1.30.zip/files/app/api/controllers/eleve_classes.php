<?php
/** Calulis — Controller « Histoire datée de la classe d'un élève » (décision 3.3)
 *
 *  GET    api/eleve_classes.php?eleve_id=…   → les périodes, de la plus ancienne à la plus récente
 *                                              (et `courante` = celle qui est encore ouverte)
 *  POST   api/eleve_classes.php              (body JSON : eleve_id, classe_id, date_debut)
 *                                              → ouvre une période ; la précédente est close la veille
 *  PUT    api/eleve_classes.php?id=…         (body JSON : date_fin)
 *                                              → clôt une période (l'élève quitte la classe)
 *
 *  Pas de DELETE : effacer une période laisserait un trou dans l'histoire d'un élève.
 *  Pour corriger une erreur de saisie, on reclôt la période à la bonne date.
 */
require_once __DIR__ . '/../models/EleveClasse.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

try {
    // Les cas terminent la requête par jsonResponse()/jsonError(), qui s'arrêtent là :
    // un « break » après eux serait du code mort (remarque PHPStan corrigée le
    // 30/10/2026, lot 3).
    switch ($method) {

        case 'GET':
            $eleveId = isset($_GET['eleve_id']) ? (int)$_GET['eleve_id'] : 0;
            if ($eleveId <= 0) { jsonError('Paramètre eleve_id manquant'); }
            jsonResponse([
                'historique' => EleveClasse::historique($eleveId),
                'courante'   => EleveClasse::courante($eleveId),
            ]);

        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true) ?: [];
            $eleveId = (int)($input['eleve_id'] ?? 0);
            if ($eleveId <= 0) { jsonError("Identifiant d'élève manquant"); }
            $classeId = isset($input['classe_id']) && $input['classe_id'] !== ''
                ? (int)$input['classe_id'] : null;
            $dateDebut = (string)($input['date_debut'] ?? calulis_aujourdhui());
            $anneeId = isset($input['annee_scolaire_id']) && $input['annee_scolaire_id'] !== ''
                ? (int)$input['annee_scolaire_id'] : null;
            $newId = EleveClasse::ouvrir($eleveId, $classeId, $dateDebut, $anneeId);
            jsonResponse(['ok' => true, 'id' => $newId, 'historique' => EleveClasse::historique($eleveId)], 201);

        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true) ?: [];
            $cible = $id ?: (int)($input['id'] ?? 0);
            if ($cible <= 0) { jsonError('Identifiant de période manquant'); }
            $dateFin = (string)($input['date_fin'] ?? '');
            if ($dateFin === '') { jsonError('Date de fin manquante'); }
            EleveClasse::clore($cible, $dateFin);
            jsonResponse(['ok' => true]);

        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (InvalidArgumentException $e) {
    jsonError($e->getMessage(), 400);
} catch (Throwable $e) {
    calulis_handle_error($e);
}
