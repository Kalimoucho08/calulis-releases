<?php
/** Calulis — Controller Groupes d'élèves enregistrés */
require_once __DIR__ . '/../models/Groupe.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

try {
    switch ($method) {
        case 'GET':
            if ($id) {
                $g = Groupe::find($id);
                if (!$g) jsonError('Groupe non trouvé', 404);
                jsonResponse($g);
            }
            jsonResponse(Groupe::all());
        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (empty($input['nom'])) jsonError('Nom du groupe requis');
            $newId = Groupe::create($input);
            jsonResponse(['ok' => true, 'id' => $newId], 201);
        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            if (!$id) jsonError('ID requis');
            Groupe::update($id, $input);
            jsonResponse(['ok' => true]);
        case 'DELETE':
            if (!$id) jsonError('ID requis');
            Groupe::delete($id);
            jsonResponse(['ok' => true]);
        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
