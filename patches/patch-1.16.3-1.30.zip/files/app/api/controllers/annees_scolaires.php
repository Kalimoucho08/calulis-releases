<?php
/** Calulis — Controller Années Scolaires (CRUD REST) */
require_once __DIR__ . '/../models/AnneeScolaire.php';
require_once __DIR__ . '/../models/Sauvegarde.php';

$method = $_SERVER['REQUEST_METHOD'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : null;

try {
    switch ($method) {

        case 'GET':
            // ?compte=1&id=N : ce que l'année porte (annoncer avant d'agir).
            if (isset($_GET['compte']) && $id) {
                $annee = AnneeScolaire::find($id);
                if (!$annee) jsonError('Année non trouvée', 404);
                jsonResponse(AnneeScolaire::contenu($id));
            }
            // ?avec_comptes=1 : la liste avec, pour chaque année, son emploi du temps et
            // le total de ses données. L'écran s'en sert pour ne proposer « Supprimer »
            // que sur une année VIDE, et « Vider l'emploi du temps » que s'il existe.
            if (isset($_GET['avec_comptes'])) {
                $annees = AnneeScolaire::all();
                foreach ($annees as &$a) {
                    $c = AnneeScolaire::contenu((int) $a['id']);
                    $a['edt'] = $c['edt'];
                    $a['donnees'] = $c['donnees'];
                    $a['semaines'] = $c['semaines'];
                    $a['creneaux'] = $c['creneaux'];
                }
                unset($a);
                jsonResponse($annees);
            }
            if ($id) {
                $annee = AnneeScolaire::find($id);
                if (!$annee) jsonError('Année non trouvée', 404);
                jsonResponse($annee);
            }
            if (isset($_GET['active'])) {
                $active = AnneeScolaire::getActive();
                jsonResponse($active ?: null);
            }
            jsonResponse(AnneeScolaire::all());

        case 'POST':
            $input = json_decode(file_get_contents('php://input'), true);
            if (empty($input['nom']) || empty($input['date_debut']) || empty($input['date_fin'])) {
                jsonError('Nom, date_debut et date_fin requis');
            }
            $newId = AnneeScolaire::create($input);
            jsonResponse(['ok' => true, 'id' => $newId], 201);

        case 'PUT':
            $input = json_decode(file_get_contents('php://input'), true);
            if (($input['action'] ?? '') === 'activate' && $id) {
                AnneeScolaire::setActive($id);
                jsonResponse(['ok' => true, 'id' => $id]);
            }
            if (!$id) jsonError('ID requis');
            AnneeScolaire::update($id, $input);
            jsonResponse(['ok' => true]);

        case 'DELETE':
            if (!$id) jsonError('ID requis');
            $annee = AnneeScolaire::find($id);
            if (!$annee) jsonError('Année non trouvée', 404);
            if ((int) ($annee['est_active'] ?? 0) === 1) {
                jsonError('Impossible de toucher à l’année active : activez d’abord une autre année.', 409);
            }
            $compte = AnneeScolaire::contenu($id);

            // ── ?action=vider-edt : vider l'EMPLOI DU TEMPS (le seul contenu jetable) ──
            // Décision du 27/10/2026 : supprimer une année, c'est supprimer son emploi du
            // temps — rien d'autre. Élèves, adultes, établissements, liens, réunions,
            // documents, tâches, notes, événements, périodes et vacances sont CONSERVÉS.
            if (($_GET['action'] ?? '') === 'vider-edt') {
                $confirme = isset($_GET['confirmer']) ? (int) $_GET['confirmer'] : -1;
                if ($confirme !== (int) $compte['edt']) {
                    jsonError(
                        'Vidage non confirmé : il supprimerait ' . $compte['edt'] . ' ligne(s) d’emploi du temps ('
                        . $compte['semaines'] . ' semaines, ' . $compte['creneaux'] . ' créneaux). '
                        . 'Tout le reste est conservé. Renvoyez la demande avec ?action=vider-edt&confirmer=' . $compte['edt'] . '.',
                        409
                    );
                }
                if ($compte['edt'] === 0) {
                    jsonResponse(['ok' => true, 'semaines' => 0, 'creneaux' => 0, 'message' => 'Aucun emploi du temps à vider']);
                }
                $sauvegarde = Sauvegarde::ecrireFichier(getDB(), 'avant-vidage-emploi-du-temps');
                $fait = AnneeScolaire::viderEmploiDuTemps($id);
                jsonResponse([
                    'ok' => true,
                    'semaines' => $fait['semaines'],
                    'creneaux' => $fait['creneaux'],
                    'conserve' => $compte['donnees'] - $compte['edt'],
                    'sauvegarde' => Sauvegarde::cheminAffichable($sauvegarde['chemin']),
                ]);
            }

            // ── Suppression de la LIGNE d'année : réservée à une année VIDE ──
            // Une année qui porte la moindre donnée n'est jamais supprimée : elle rend ses
            // données annuelles consultables (le sélecteur permet de l'activer). Le refus
            // dit ce qu'elle contient et renvoie vers le seul geste destructeur autorisé.
            if ($compte['donnees'] > 0) {
                jsonError(
                    'Suppression refusée : cette année contient encore ' . $compte['donnees'] . ' ligne(s) ('
                    . $compte['semaines'] . ' semaines, ' . $compte['creneaux'] . ' créneaux, '
                    . $compte['eleve_annees'] . ' fiches élève de l’année, '
                    . $compte['adultes_etablissements'] . ' liens adulte-établissement, '
                    . $compte['reunions'] . ' réunions, ' . $compte['documents'] . ' documents, '
                    . $compte['taches'] . ' tâches, ' . $compte['notes_suivi'] . ' notes de suivi). '
                    . 'Rien n’est supprimé : ces données restent consultables en activant l’année. '
                    . 'Pour retirer seulement l’emploi du temps, utilisez « Vider l’emploi du temps » ('
                    . $compte['edt'] . ' ligne(s)).',
                    409
                );
            }
            $confirme = isset($_GET['confirmer']) ? (int) $_GET['confirmer'] : null;
            if ($confirme !== 0) {
                jsonError(
                    'Suppression non confirmée : cette année est vide (aucune donnée dans aucune table). '
                    . 'Renvoyez la demande avec ?confirmer=0.',
                    409
                );
            }
            $sauvegarde = Sauvegarde::ecrireFichier(getDB(), 'avant-suppression-annee');
            AnneeScolaire::delete($id);
            jsonResponse(['ok' => true, 'sauvegarde' => Sauvegarde::cheminAffichable($sauvegarde['chemin'])]);

        default:
            jsonError('Méthode non supportée', 405);
    }
} catch (\Throwable $e) {
    calulis_handle_error($e);
}
