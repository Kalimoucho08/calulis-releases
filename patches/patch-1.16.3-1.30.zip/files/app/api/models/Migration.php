<?php
/** Calulis — Gestionnaire de migrations DB versionnées
 *
 *  Parcourt data/migrations/, applique les fichiers non encore exécutés
 *  dans l'ordre lexical, et les enregistre dans schema_migrations.
 *
 *  Formats supportés :
 *    - .sql   : exécuté via PDO::exec (requêtes SQL pures)
 *    - .php   : inclus (le script reçoit $pdo et doit gérer ses propres requêtes)
 *
 *  Usage :
 *    $m = new Migration();
 *    $applied = $m->run();        // applique les migrations en attente
 *    $pending = $m->pending();    // liste les migrations non appliquées
 *    $all     = $m->status();     // état complet
 */

require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/ImportSql.php';

class Migration {

    private PDO $pdo;
    private string $migrationsDir;

    public function __construct(?PDO $pdo = null) {
        $this->pdo = $pdo ?? getDB();
        $this->migrationsDir = __DIR__ . '/../../data/migrations';
        $this->ensureTable();
    }

    /** Crée la table schema_migrations si elle n'existe pas */
    private function ensureTable(): void {
        $this->pdo->exec("
            CREATE TABLE IF NOT EXISTS schema_migrations (
                id INT AUTO_INCREMENT PRIMARY KEY,
                version VARCHAR(50) NOT NULL,
                filename VARCHAR(255) NOT NULL,
                applied_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
                UNIQUE KEY uq_filename (filename)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
        ");
    }

    /** Liste les migrations non appliquées */
    public function pending(): array {
        $files = $this->scanMigrations();
        $applied = $this->appliedFilenames();
        return array_values(array_filter($files, fn($f) => !in_array($f['filename'], $applied, true)));
    }

    /** Applique toutes les migrations en attente. Retourne le compte rendu. */
    public function run(): array {
        // L'auto-migration tourne à CHAQUE requête et l'interface en lance plusieurs en
        // parallèle : sans verrou, deux requêtes pouvaient appliquer la même migration.
        // GET_LOCK est propre à la session MySQL et se libère à la fin de la requête ;
        // on le relâche explicitement pour ne pas le garder sur une connexion persistante.
        $verrou = (int) $this->pdo->query("SELECT GET_LOCK('calulis_migration', 5)")->fetchColumn();
        if ($verrou !== 1) {
            // Ne pas laisser croire qu'il n'y avait rien à appliquer : le verrou a expiré.
            if (function_exists('calulis_log_error')) {
                calulis_log_error('Migration non exécutée : verrou calulis_migration indisponible après 5 s.');
            }
            return [
                'applied' => 0,
                'errors'  => 0,
                'details' => [],
                'verrou'  => false,
            ];
        }

        try {
            $pending = $this->pending();
            $results = [];

            foreach ($pending as $m) {
                try {
                    $this->applyOne($m);
                    $this->record($m);
                    $results[] = ['version' => $m['version'], 'filename' => $m['filename'], 'status' => 'ok'];
                } catch (\Throwable $e) {
                    $results[] = ['version' => $m['version'], 'filename' => $m['filename'], 'status' => 'error', 'error' => calulis_message_sur($e->getMessage())];
                    break; // Arrêt immédiat en cas d'erreur
                }
            }

            return [
                'applied' => count(array_filter($results, fn($r) => $r['status'] === 'ok')),
                'errors'  => count(array_filter($results, fn($r) => $r['status'] === 'error')),
                'details' => $results,
                'verrou'  => true,
            ];
        } finally {
            $this->pdo->query("SELECT RELEASE_LOCK('calulis_migration')");
        }
    }

    /** État complet : migrations appliquées + en attente */
    public function status(): array {
        $all = $this->scanMigrations();
        $applied = $this->appliedFilenames();
        $list = [];
        foreach ($all as $m) {
            $list[] = ['version' => $m['version'], 'filename' => $m['filename'], 'applied' => in_array($m['filename'], $applied, true)];
        }
        return [
            'total'   => count($list),
            'applied' => count(array_filter($list, fn($l) => $l['applied'])),
            'pending' => count(array_filter($list, fn($l) => !$l['applied'])),
            'migrations' => $list,
        ];
    }

    /** Enregistre une migration comme déjà appliquée (sans l'exécuter) */
    public function registerApplied(string $version, string $filename): void {
        $stmt = $this->pdo->prepare(
            'INSERT IGNORE INTO schema_migrations (version, filename, applied_at) VALUES (:v, :f, NOW())'
        );
        $stmt->execute(['v' => $version, 'f' => $filename]);
    }

    // ── Interne ─────────────────────────────────────────────

    private function scanMigrations(): array {
        if (!is_dir($this->migrationsDir)) return [];
        $files = scandir($this->migrationsDir);
        $migrations = [];
        foreach ($files as $f) {
            if (preg_match('/^(\d+)_(.+?)\.(sql|php)$/', $f, $m)) {
                $migrations[] = ['version' => $m[1], 'filename' => $f, 'ext' => $m[3]];
            }
        }
        usort($migrations, fn($a, $b) => $a['version'] <=> $b['version']);
        return $migrations;
    }

    private function appliedFilenames(): array {
        $stmt = $this->pdo->query('SELECT filename FROM schema_migrations ORDER BY id');
        return $stmt->fetchAll(PDO::FETCH_COLUMN);
    }

    private function applyOne(array $migration): void {
        $path = $this->migrationsDir . '/' . $migration['filename'];
        if ($migration['ext'] === 'sql') {
            $sql = file_get_contents($path);
            if ($sql === false || trim($sql) === '') {
                throw new \RuntimeException("Fichier SQL vide : {$migration['filename']}");
            }
            // Découper en instructions séparées (les migrations peuvent contenir
            // plusieurs statements : CREATE TABLE + INSERT, ALTER + UPDATE, etc.).
            // On utilise le découpeur d'ImportSql, qui respecte les chaînes, les
            // identifiants et les commentaires — explode(';') coupait au premier « ; »
            // dans une valeur (défaut relevé le 26/10/2026).
            $statements = array_filter(
                array_map('trim', ImportSql::decouper($sql)),
                fn($s) => $s !== ''
            );
            foreach ($statements as $statement) {
                $isSelect = preg_match('/^\s*SELECT\b/i', $statement);
                if ($isSelect) {
                    // query() pour les SELECT (consomme le curseur)
                    $stmt = $this->pdo->query($statement);
                    if ($stmt && $stmt->columnCount() > 0) {
                        $stmt->fetchAll();
                    }
                    $stmt?->closeCursor();
                } else {
                    // exec() pour DDL/DML (supporte multi-statements natifs MySQL)
                    $this->pdo->exec($statement . ';');
                }
            }
        } elseif ($migration['ext'] === 'php') {
            $pdo = $this->pdo;
            $result = (require $path);
            if ($result === false) {
                throw new \RuntimeException("Script PHP a retourné false : {$migration['filename']}");
            }
        }
    }

    private function record(array $migration): void {
        $this->registerApplied($migration['version'], $migration['filename']);
    }
}
