<?php
/**
 * Calulis — La restauration d'une archive unique (lot 7), avec ses garde-fous.
 *
 * CE QUI SE PASSE, DANS CET ORDRE, ET RIEN D'AUTRE
 *   1. la demande est CONFIRMÉE par écrit (le mot « RESTAURER ») — sans lui, on ne touche à rien ;
 *   2. l'archive est ANALYSÉE (manifeste, format, base.sql présent, empreintes vérifiées) ;
 *   3. une sauvegarde AUTOMATIQUE de l'état actuel est faite ; si elle échoue, on s'arrête là ;
 *   4. la base de l'archive est importée (même moteur que l'import .sql existant) ;
 *   5. les documents sont extraits dans un dossier NEUF, puis échangés avec l'ancien —
 *      l'ancien n'est jamais supprimé : il est renommé et le compte rendu le nomme.
 *
 * CE QU'ELLE NE PROMET PAS
 * Si l'étape 4 casse au milieu, la base peut être partielle : c'est pourquoi l'étape 3
 * existe et que son chemin est rendu dans le compte rendu. Aucune restauration ne se
 * fait sans sauvegarde préalable réussie.
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/Archive.php';
require_once __DIR__ . '/ImportSql.php';
require_once __DIR__ . '/Sauvegarde.php';
require_once __DIR__ . '/SauvegardeArchive.php';

class Restauration
{
    /** Le mot à écrire pour que la restauration soit acceptée. Comparé sans casse ni espaces. */
    public const MOT_CONFIRMATION = 'RESTAURER';

    /**
     * Restaure une archive. Ne rend rien tant que tout n'est pas fait : l'appelant
     * reçoit un compte rendu de ce qui a été remplacé, ou une exception et RIEN n'est
     * présenté comme restauré.
     *
     * @return array{base:array,documents:array,sauvegarde:string,archive:string}
     */
    public static function restaurer(PDO $pdo, string $chemin, string $confirmation): array
    {
        // 1. Confirmation écrite.
        $mot = strtoupper(trim($confirmation));
        if ($mot !== self::MOT_CONFIRMATION) {
            throw new RuntimeException(
                "Restauration refusée : il faut écrire « " . self::MOT_CONFIRMATION
                . " » pour accepter de remplacer vos données actuelles. Rien n'a été modifié."
            );
        }

        // 2. Analyse : on refuse AVANT de sauvegarder quoi que ce soit d'inutile.
        $analyse = SauvegardeArchive::analyser($chemin);

        // 3. Sauvegarde de l'état actuel — obligatoire.
        try {
            $sauvegarde = SauvegardeArchive::creer($pdo, 'avant-restauration');
        } catch (Throwable $e) {
            throw new RuntimeException(
                "Restauration annulée : la sauvegarde de vos données actuelles a échoué ("
                . $e->getMessage() . "). Rien n'a été modifié."
            );
        }

        // 4. La base de l'archive, dans un fichier temporaire.
        $sql = '';
        $fichierSql = (string) tempnam(sys_get_temp_dir(), 'calulis-restauration-');
        try {
            Archive::extraire($chemin, SauvegardeArchive::BASE, $fichierSql);
            $sql = (string) @file_get_contents($fichierSql);
        } finally {
            @unlink($fichierSql);
        }
        if (trim($sql) === '') {
            throw new RuntimeException("La base de cette archive est vide : rien n'a été modifié.");
        }
        // Le fichier ne doit pas viser une AUTRE base que la base courante.
        ImportSql::verifier($pdo, $sql);

        $avant = calulis_compter_base($pdo);

        // 5. Documents : extraits dans un dossier NEUF, à côté — jamais par-dessus.
        $racineDocuments = SauvegardeArchive::dossierDocuments();
        $horodatage = date('Y-m-d_H-i-s');
        $nouveauDossier = $racineDocuments . '.restauration-' . $horodatage;
        $ancienDossier = $racineDocuments . '.avant-restauration-' . $horodatage;
        $documentsExtraits = 0;
        if ($analyse['documents'] > 0) {
            self::creerDossier($nouveauDossier);
            foreach (Archive::entrees($chemin) as $nom => $meta) {
                if (!str_starts_with($nom, SauvegardeArchive::DOSSIER_DOCUMENTS)) {
                    continue;
                }
                $relatif = substr($nom, strlen(SauvegardeArchive::DOSSIER_DOCUMENTS));
                if ($relatif === '' || str_ends_with($nom, '/')) {
                    continue;
                }
                $relatif = self::cheminSur($relatif);
                $cible = $nouveauDossier . '/' . $relatif;
                self::creerDossier(dirname($cible));
                Archive::extraire($chemin, $nom, $cible);
                $documentsExtraits++;
            }
        }

        // 6. Import de la base.
        try {
            $resultat = ImportSql::executer($pdo, $sql);
        } catch (Throwable $e) {
            // La base peut être partielle : on le DIT, et la sauvegarde préalable est nommée.
            self::supprimerDossier($nouveauDossier);
            throw new RuntimeException(
                "La base de l'archive n'a pas pu être importée (" . $e->getMessage()
                . "). Vos données actuelles ont été sauvegardées avant : " . Sauvegarde::cheminAffichable($sauvegarde['chemin'])
                . ". Les documents n'ont pas été remplacés."
            );
        }
        if (count($resultat['erreurs'] ?? []) > 0) {
            self::supprimerDossier($nouveauDossier);
            throw new RuntimeException(
                "L'import de la base s'est arrêté sur " . count($resultat['erreurs']) . " erreur(s) ("
                . ImportSql::decrire($resultat['erreurs'][0]) . "). Vos données actuelles ont été sauvegardées avant : "
                . Sauvegarde::cheminAffichable($sauvegarde['chemin']) . "."
            );
        }

        // 7. Échange des dossiers de documents : l'ancien est renommé, jamais effacé.
        $ancienRenomme = '';
        if ($analyse['documents'] > 0) {
            if (is_dir($racineDocuments) && !@rename($racineDocuments, $ancienDossier)) {
                self::supprimerDossier($nouveauDossier);
                throw new RuntimeException(
                    "La base a été restaurée, mais le dossier des documents n'a pas pu être mis de côté : "
                    . "les documents de l'archive sont dans « " . basename($nouveauDossier) . " »."
                );
            }
            if (!@rename($nouveauDossier, $racineDocuments)) {
                if (is_dir($ancienDossier)) { @rename($ancienDossier, $racineDocuments); }
                throw new RuntimeException(
                    "La base a été restaurée, mais les documents n'ont pas pu être remis en place. "
                    . "Le dossier précédent a été replacé."
                );
            }
            $ancienRenomme = $ancienDossier;
        }

        return [
            'base' => [
                'avant'  => $avant,
                'apres'  => calulis_compter_base($pdo),
                'erreurs' => count($resultat['erreurs'] ?? []),
            ],
            'documents' => [
                'extraits' => $documentsExtraits,
                'ancien'   => $ancienRenomme,
            ],
            'sauvegarde' => Sauvegarde::cheminAffichable($sauvegarde['chemin']),
            'archive'    => basename($chemin),
        ];
    }

    /** Un chemin relatif d'archive, rendu sûr (ni « .. », ni lecture hors du dossier). */
    private static function cheminSur(string $relatif): string
    {
        $morceaux = [];
        foreach (preg_split('#[/\\\\]+#', $relatif) ?: [] as $morceau) {
            $morceau = trim((string) preg_replace('/[\x00-\x1F\x7F]/u', '', $morceau));
            if ($morceau === '' || $morceau === '.' || $morceau === '..') {
                continue;
            }
            $morceaux[] = $morceau;
        }
        return implode('/', $morceaux);
    }

    private static function creerDossier(string $chemin): void
    {
        if (!is_dir($chemin) && !@mkdir($chemin, 0777, true) && !is_dir($chemin)) {
            throw new RuntimeException("Le dossier « " . basename($chemin) . " » n'a pas pu être créé.");
        }
    }

    /** Supprime un dossier de travail (le dossier des documents d'origine n'est jamais visé ici). */
    private static function supprimerDossier(string $chemin): void
    {
        if (!is_dir($chemin)) {
            return;
        }
        $parcours = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($chemin, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ($parcours as $element) {
            /** @var SplFileInfo $element */
            if ($element->isDir() && !$element->isLink()) {
                @rmdir($element->getPathname());
            } else {
                @unlink($element->getPathname());
            }
        }
        @rmdir($chemin);
    }
}
