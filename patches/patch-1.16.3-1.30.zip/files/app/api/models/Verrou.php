<?php
/**
 * Calulis — Mot de passe d'ouverture (lot 8).
 *
 * POURQUOI CE MODÈLE EXISTE
 * Décision de Jérôme (31/10/2026) : un mot de passe **optionnel** à l'ouverture,
 * **désactivé par défaut**, avec une remise à zéro simple et documentée en cas d'oubli.
 * Il arrête une personne devant l'écran ; il ne protège PAS les fichiers : qui a la main
 * sur le disque lit `runtime/documents` et la base sans ce mot de passe. C'est écrit dans
 * l'aide, et ce fichier ne prétend pas autre chose.
 *
 * OÙ VIT LE SECRET
 * `runtime/securite/mot-de-passe.json` — PAS dans la base. Trois raisons :
 *   1. la remise à zéro devient « supprimez ce fichier » (aucun outil, aucune requête SQL) ;
 *   2. une sauvegarde restaurée sur un autre poste n'emporte pas le mot de passe, donc un
 *      oubli ne condamne jamais une archive ;
 *   3. le dossier `runtime/` est celui que les mises à jour ne remplacent pas.
 *
 * CE QUI EST ÉCRIT DANS LE FICHIER
 * L'empreinte `password_hash()` (bcrypt), jamais le mot. Aucune donnée d'élève. Le nombre
 * de tentatives ratées et l'instant de la pause y sont aussi, pour que le ralentissement
 * survive au rechargement de la page.
 *
 * LES SESSIONS
 * `runtime/securite/sessions.json` ne contient que des empreintes SHA-256 des jetons :
 * le jeton en clair ne vit que dans le cookie du navigateur. Un cookie d'onglet (sans date
 * d'expiration) ferme la session quand le navigateur se ferme — c'est bien « à l'ouverture ».
 * Une session expire aussi au bout de 12 h, même onglet ouvert.
 */
require_once __DIR__ . '/Stockage.php';

class Verrou
{
    public const FICHIER = 'mot-de-passe.json';
    public const SESSIONS = 'sessions.json';

    /** 6 caractères : une règle courte, dite à l'écran, plutôt qu'une règle de complexité
     *  que personne ne retient et que tout le monde contourne avec « Calulis1! ». */
    public const LONGUEUR_MIN = 6;

    /** 12 h : au-delà, le mot de passe est redemandé même si l'onglet est resté ouvert. */
    public const SESSION_SECONDES = 43200;

    /** 5 essais ratés, puis 30 s de pause : de quoi décourager le tâtonnement, sans
     *  enfermer dehors celui qui se trompe une fois de plus. */
    public const TENTATIVES_AVANT_PAUSE = 5;
    public const PAUSE_SECONDES = 30;


    /** Longueur en CARACTÈRES, sans mbstring (le paquet n'en dépend pas) : on retire les
     *  octets de continuation UTF-8 (10xxxxxx) et on compte ce qui reste. */
    private static function longueur(string $texte): int
    {
        return strlen((string) preg_replace('/[\x80-\xBF]/', '', $texte));
    }

    /** Le dossier du secret (variable d'environnement pour les tests). */
    public static function dossier(): string
    {
        $force = getenv('CALULIS_SECURITE_DIR');
        if (is_string($force) && $force !== '') {
            return rtrim(str_replace('\\', '/', $force), '/');
        }
        return Stockage::racineInstallation() . '/runtime/securite';
    }

    public static function cheminMotDePasse(): string
    {
        return self::dossier() . '/' . self::FICHIER;
    }

    /** Chemin montrable à l'écran : « runtime\securite\mot-de-passe.json ». */
    public static function cheminAffichable(): string
    {
        return 'runtime' . DIRECTORY_SEPARATOR . 'securite' . DIRECTORY_SEPARATOR . self::FICHIER;
    }

    public static function actif(): bool
    {
        $etat = self::lire();
        return $etat !== null && isset($etat['empreinte']) && is_string($etat['empreinte']) && $etat['empreinte'] !== '';
    }

    /**
     * Ce que l'écran a le droit de savoir : jamais l'empreinte, jamais un mot.
     * @return array{actif:bool,modifie_le:?string,dossier:string,pause:int,tentatives:int,sessions:int}
     */
    public static function etat(): array
    {
        $etat = self::lire();
        $pause = 0;
        if ($etat !== null && isset($etat['blocage_jusqua']) && (int) $etat['blocage_jusqua'] > time()) {
            $pause = (int) $etat['blocage_jusqua'] - time();
        }
        return [
            'actif'       => self::actif(),
            'modifie_le'  => $etat['modifie_le'] ?? null,
            'dossier'     => self::cheminAffichable(),
            'pause'       => $pause,
            'tentatives'  => (int) ($etat['tentatives'] ?? 0),
            'sessions'    => count(self::sessions()),
        ];
    }

    /**
     * Pose (ou change) le mot de passe. Si un mot de passe existe déjà, l'actuel est exigé.
     * @return array{ok:bool,message:string}
     */
    public static function definir(string $mot, string $actuel = ''): array
    {
        $mot = (string) $mot;
        if (self::longueur($mot) < self::LONGUEUR_MIN) {
            return ['ok' => false, 'message' => 'Le mot de passe doit faire au moins ' . self::LONGUEUR_MIN . ' caractères. Rien n\'a été changé.'];
        }
        if (self::actif()) {
            $controle = self::verifier($actuel);
            if (!$controle['ok']) {
                // Pendant une pause, le refus n'est pas « faux mot » mais « attendez » : on dit
                // la vraie raison, sinon on laisse croire à un mot oublié alors que c'est un délai.
                $motif = ($controle['pause'] ?? 0) > 0
                    ? $controle['message']
                    : 'Le mot de passe actuel est faux : rien n\'a été changé.';
                return ['ok' => false, 'message' => $motif];
            }
        }

        $empreinte = password_hash($mot, PASSWORD_DEFAULT);
        if (!is_string($empreinte) || $empreinte === '') {
            return ['ok' => false, 'message' => 'Le mot de passe n\'a pas pu être enregistré.'];
        }
        $etat = [
            'version'       => 1,
            'empreinte'     => $empreinte,
            'cree_le'       => (self::lire()['cree_le'] ?? date('c')),
            'modifie_le'    => date('c'),
            'tentatives'    => 0,
            'blocage_jusqua' => 0,
        ];
        if (!self::ecrire($etat)) {
            return ['ok' => false, 'message' => 'Le dossier runtime/securite n\'est pas accessible en écriture.'];
        }
        // Un changement de mot de passe ferme les sessions ouvertes ailleurs : c'est
        // exactement ce qu'on attend d'un changement de mot de passe.
        self::fermerToutesLesSessions();
        calulis_log_error('MOT DE PASSE : posé (Calulis s\'ouvrira désormais avec).');
        return ['ok' => true, 'message' => 'Mot de passe enregistré : Calulis le demandera à l\'ouverture.'];
    }

    /**
     * Vérifie un mot. Compte les échecs et impose une pause après plusieurs essais ratés.
     * @return array{ok:bool,message:string,pause:int,tentatives:int}
     */
    public static function verifier(string $mot): array
    {
        $etat = self::lire();
        if ($etat === null || !isset($etat['empreinte']) || $etat['empreinte'] === '') {
            return ['ok' => true, 'message' => 'Aucun mot de passe : Calulis est ouvert.', 'pause' => 0, 'tentatives' => 0];
        }
        $pause = max(0, (int) ($etat['blocage_jusqua'] ?? 0) - time());
        if ($pause > 0) {
            return ['ok' => false, 'message' => 'Trop d\'essais : attendez ' . $pause . ' seconde(s) avant de réessayer.', 'pause' => $pause, 'tentatives' => (int) ($etat['tentatives'] ?? 0)];
        }

        $bon = $mot !== '' && password_verify($mot, (string) $etat['empreinte']);
        if (!$bon) {
            $tentatives = (int) ($etat['tentatives'] ?? 0) + 1;
            $etat['tentatives'] = $tentatives;
            if ($tentatives >= self::TENTATIVES_AVANT_PAUSE) {
                $etat['blocage_jusqua'] = time() + self::PAUSE_SECONDES;
                $etat['tentatives'] = 0;
            }
            self::ecrire($etat);
            calulis_log_error('MOT DE PASSE : essai refusé (' . $tentatives . ').');
            return ['ok' => false, 'message' => 'Mot de passe incorrect.', 'pause' => 0, 'tentatives' => $tentatives];
        }

        if ((int) ($etat['tentatives'] ?? 0) !== 0 || (int) ($etat['blocage_jusqua'] ?? 0) !== 0) {
            $etat['tentatives'] = 0;
            $etat['blocage_jusqua'] = 0;
            self::ecrire($etat);
        }
        return ['ok' => true, 'message' => 'Mot de passe accepté.', 'pause' => 0, 'tentatives' => 0];
    }

    /** @return array{ok:bool,message:string} */
    public static function retirer(string $mot): array
    {
        if (!self::actif()) {
            return ['ok' => true, 'message' => 'Aucun mot de passe n\'était posé.'];
        }
        $controle = self::verifier($mot);
        if (!$controle['ok']) {
            $motif = ($controle['pause'] ?? 0) > 0
                ? $controle['message']
                : 'Mot de passe incorrect : rien n\'a été changé.';
            return ['ok' => false, 'message' => $motif];
        }
        $chemin = self::cheminMotDePasse();
        if (is_file($chemin) && !@unlink($chemin)) {
            return ['ok' => false, 'message' => 'Le fichier du mot de passe n\'a pas pu être supprimé.'];
        }
        self::fermerToutesLesSessions();
        calulis_log_error('MOT DE PASSE : retiré (Calulis s\'ouvre sans mot de passe).');
        return ['ok' => true, 'message' => 'Mot de passe retiré : Calulis s\'ouvre désormais sans rien demander.'];
    }

    /** Ouvre une session et rend le jeton EN CLAIR (le seul moment où il existe). */
    public static function ouvrirSession(): string
    {
        $jeton = bin2hex(random_bytes(32));
        $sessions = self::sessions();
        $sessions[self::empreinteJeton($jeton)] = time() + self::SESSION_SECONDES;
        self::ecrireSessions($sessions);
        return $jeton;
    }

    public static function sessionValide(?string $jeton): bool
    {
        if (!is_string($jeton) || strlen($jeton) < 32) { return false; }
        $sessions = self::sessions();
        $cle = self::empreinteJeton($jeton);
        if (!isset($sessions[$cle])) { return false; }
        if ((int) $sessions[$cle] < time()) {
            unset($sessions[$cle]);
            self::ecrireSessions($sessions);
            return false;
        }
        return true;
    }

    public static function fermerSession(?string $jeton): void
    {
        if (!is_string($jeton) || $jeton === '') { return; }
        $sessions = self::sessions();
        unset($sessions[self::empreinteJeton($jeton)]);
        self::ecrireSessions($sessions);
    }

    public static function fermerToutesLesSessions(): void
    {
        self::ecrireSessions([]);
    }

    private static function empreinteJeton(string $jeton): string
    {
        return hash('sha256', $jeton);
    }

    /** @return array<string,int> empreinte du jeton => instant d'expiration */
    private static function sessions(): array
    {
        $chemin = self::dossier() . '/' . self::SESSIONS;
        $brut = @file_get_contents($chemin);
        if (!is_string($brut) || $brut === '') { return []; }
        $lu = json_decode($brut, true);
        if (!is_array($lu)) { return []; }
        $maintenant = time();
        $propres = [];
        foreach ($lu as $cle => $expire) {
            if (is_string($cle) && strlen($cle) === 64 && (int) $expire > $maintenant) {
                $propres[$cle] = (int) $expire;
            }
        }
        return $propres;
    }

    private static function ecrireSessions(array $sessions): void
    {
        self::ecrireFichier(self::dossier() . '/' . self::SESSIONS, json_encode($sessions, JSON_UNESCAPED_SLASHES));
    }

    /** @return array<string,mixed>|null */
    private static function lire(): ?array
    {
        $brut = @file_get_contents(self::cheminMotDePasse());
        if (!is_string($brut) || $brut === '') { return null; }
        $lu = json_decode($brut, true);
        return is_array($lu) ? $lu : null;
    }

    private static function ecrire(array $etat): bool
    {
        return self::ecrireFichier(self::cheminMotDePasse(), json_encode($etat, JSON_UNESCAPED_SLASHES | JSON_PRETTY_PRINT));
    }

    /**
     * Écriture atomique et privée : dossier créé au besoin, fichier en 0600 (POSIX) ;
     * sous Windows, le dossier de l'utilisateur est déjà protégé par sa session.
     */
    private static function ecrireFichier(string $chemin, string $contenu): bool
    {
        $dossier = dirname($chemin);
        if (!is_dir($dossier) && !@mkdir($dossier, 0700, true) && !is_dir($dossier)) {
            calulis_log_error('SÉCURITÉ : dossier impossible à créer (' . $dossier . ')');
            return false;
        }
        $temporaire = $chemin . '.part';
        if (@file_put_contents($temporaire, $contenu) === false) { return false; }
        @chmod($temporaire, 0600);
        if (!@rename($temporaire, $chemin)) {
            @unlink($temporaire);
            return false;
        }
        return true;
    }
}