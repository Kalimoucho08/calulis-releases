<?php
/** Calulis — Model Statistiques
 *  Toutes les méthodes retournent des tableaux associatifs prêts à être JSON-sérialisés.
 *  Chaque méthode prend un PDO en paramètre.
 *
 *  Les stats sont ANNUELLES (pas cumulatives sur plusieurs années).
 *  $anneeId = null → utilise l'année active.
 */
class Stats {

    // ── KPI ──

    public static function kpi(PDO $pdo, ?int $anneeId): array {
        if (!$anneeId) {
            $anneeId = (int)$pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
            if (!$anneeId) $anneeId = 1;
        }

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE annee_scolaire_id = ?');
        $stmt->execute([$anneeId]); $total = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE ulis = 1 AND annee_scolaire_id = ?');
        $stmt->execute([$anneeId]); $ulis = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE cantine = 1 AND annee_scolaire_id = ?');
        $stmt->execute([$anneeId]); $cantine = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleve_annees WHERE transport LIKE '%taxi%' AND annee_scolaire_id = ?");
        $stmt->execute([$anneeId]); $taxi = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT COUNT(DISTINCT eleve_id) FROM pec_eleves WHERE specialite IS NOT NULL AND specialite != '' AND annee_scolaire_id = ?");
        $stmt->execute([$anneeId]); $pec = (int)$stmt->fetchColumn();

        return ['total' => $total, 'ulis' => $ulis, 'cantine' => $cantine, 'taxi' => $taxi, 'pec' => $pec];
    }

    // ── Inclusion (décision 9.1 du 27/10/2026) ──

    /** Type de créneau qui dit le temps NON SCOLARISÉ (décision 9.3). */
    public const TYPE_NON_SCOLARISE = 'NON SCOLARISE';

    /**
     * Décision 9.1 : l'inclusion est le temps PRÉVU dans la classe de référence —
     * temps d'école prévu, moins le temps ULIS, moins la prise en charge, moins le temps
     * non scolarisé. On ne compte donc plus les seuls créneaux marqués « INCLUSION » :
     * un élève à temps plein sans aucun créneau ULIS sort à 100 %, et c'est voulu.
     *
     * Le temps non scolarisé se dit par un créneau de type NON SCOLARISE (décision 9.3) :
     * la fiche porte l'information « scolarisé à temps partiel », le créneau porte les
     * heures. Le décloisonnement n'est PAS soustrait : l'élève est dans une classe ordinaire.
     *
     * Le pourcentage se calcule sur le temps d'école EFFECTIF de l'élève (temps commun moins
     * son temps non scolarisé) : un élève à temps partiel ne peut pas dépasser son temps de
     * présence. Les heures ULIS et PEC, elles, se déduisent du numérateur — une PRISE EN CHARGE
     * n'est donc PAS du hors scolaire : elle réduit l'inclusion, pas le temps effectif
     * (précision de Jérôme, 27/10/2026).
     */
    private static function _inclusionDonnees(PDO $pdo, int $anneeId): array
    {
        $minutesEcole = self::_getHeuresEcoleSemaine($pdo) * 60;

        $stmt = $pdo->prepare('SELECT id, numero, date_debut, date_fin, est_vacances
                                 FROM semaines WHERE annee_scolaire_id = ? ORDER BY numero');
        $stmt->execute([$anneeId]);
        $semaines = $stmt->fetchAll();
        $semainesScolaires = [];
        foreach ($semaines as $s) {
            if (!(int)$s['est_vacances']) {
                $semainesScolaires[] = (int)$s['id'];
            }
        }

        $stmt = $pdo->prepare('SELECT ea.eleve_id, ea.classe_id, e.nom, e.prenom
                                 FROM eleve_annees ea JOIN eleves e ON e.id = ea.eleve_id
                                WHERE ea.annee_scolaire_id = ? ORDER BY e.nom, e.prenom');
        $stmt->execute([$anneeId]);
        $eleves = $stmt->fetchAll();

        // Sommes par élève et par semaine. Un créneau absent vaut zéro : c'est la règle
        // « inclusion par défaut » qui le veut.
        // R28 (audit du 27/10/2026) : le type non scolarisé vient de la CONSTANTE, en paramètre
        // lié — une seule valeur à changer le jour où le libellé évolue, et aucun texte inséré
        // dans la requête. (Le premier correctif avait interpolé du PHP DANS la chaîne SQL :
        // la comparaison ne matchait plus rien et le temps non scolarisé tombait à zéro —
        // vu par verif-inclusion, corrigé ici.)
        $stmt = $pdo->prepare(
            "SELECT c.eleve_id, c.semaine_id,
                    SUM(CASE WHEN c.regroupement_type = 'ULIS' THEN c.duree ELSE 0 END) AS ulis,
                    SUM(CASE WHEN c.regroupement_type = 'PEC' THEN c.duree ELSE 0 END) AS pec,
                    SUM(CASE WHEN UPPER(REPLACE(TRIM(c.regroupement_type), '_', ' ')) = :typeNonsco
                             THEN c.duree ELSE 0 END) AS nonsco,
                    COUNT(*) AS nb_creneaux
               FROM creneaux c
               JOIN semaines s ON s.id = c.semaine_id
              WHERE s.annee_scolaire_id = :annee AND s.est_vacances = 0
              GROUP BY c.eleve_id, c.semaine_id"
        );
        $stmt->execute(['annee' => $anneeId, 'typeNonsco' => self::TYPE_NON_SCOLARISE]);
        $bruts = [];
        foreach ($stmt->fetchAll() as $r) {
            $bruts[(int)$r['eleve_id']][(int)$r['semaine_id']] = $r;
        }

        $parEleve = [];
        foreach ($eleves as $e) {
            $eid = (int)$e['eleve_id'];
            $parEleve[$eid] = [
                'eleve_id' => $eid, 'nom' => $e['nom'], 'prenom' => $e['prenom'],
                'classe_id' => $e['classe_id'] === null ? null : (int)$e['classe_id'],
                'inclusion_min' => 0.0, 'ecole_min' => 0.0, 'nonsco_min' => 0.0,
                'ulis_min' => 0.0, 'pec_min' => 0.0, 'nb_creneaux' => 0,
                'par_semaine' => [],
            ];
        }
        $parSemaine = [];
        foreach ($semainesScolaires as $sid) {
            $parSemaine[$sid] = ['inclusion_min' => 0.0, 'nb_eleves_inclus' => 0, 'nb_creneaux' => 0];
        }

        foreach ($parEleve as $eid => &$eleve) {
            foreach ($semainesScolaires as $sid) {
                $r = $bruts[$eid][$sid] ?? ['ulis' => 0, 'pec' => 0, 'nonsco' => 0, 'nb_creneaux' => 0];
                $ulis = (float)$r['ulis'];
                $pec = (float)$r['pec'];
                $nonsco = (float)$r['nonsco'];
                $inclusion = max(0.0, $minutesEcole - $ulis - $pec - $nonsco);
                $effectif = max(0.0, $minutesEcole - $nonsco);

                $eleve['inclusion_min'] += $inclusion;
                $eleve['ecole_min'] += $effectif;
                $eleve['nonsco_min'] += $nonsco;
                $eleve['ulis_min'] += $ulis;
                $eleve['pec_min'] += $pec;
                $eleve['nb_creneaux'] += (int)$r['nb_creneaux'];
                $eleve['par_semaine'][$sid] = [
                    'inclusion' => $inclusion, 'ecole' => $effectif,
                    'nb_creneaux' => (int)$r['nb_creneaux'],
                ];

                $parSemaine[$sid]['inclusion_min'] += $inclusion;
                $parSemaine[$sid]['nb_creneaux'] += (int)$r['nb_creneaux'];
                if ($inclusion > 0) {
                    $parSemaine[$sid]['nb_eleves_inclus']++;
                }
            }
        }
        unset($eleve);

        return [
            'minutes_ecole_semaine' => $minutesEcole,
            'semaines' => $semaines,
            'semaines_scolaires' => $semainesScolaires,
            'eleves' => $parEleve,
            'par_semaine' => $parSemaine,
        ];
    }

    /** Les données d'inclusion de l'année, filtrées sur une classe quand elle est donnée. */
    private static function _inclusionFiltree(array $donnees, ?int $classeId): array
    {
        if (!$classeId) {
            return $donnees['eleves'];
        }
        return array_filter($donnees['eleves'], fn($e) => (int)$e['classe_id'] === $classeId);
    }

    public static function inclusion(PDO $pdo, ?int $anneeId, ?int $classeId = null): array {
        $anneeId = self::_anneeOuActive($pdo, $anneeId);
        $d = self::_inclusionDonnees($pdo, $anneeId);
        $nbSemaines = max(count($d['semaines_scolaires']), 1);

        $parEleve = [];
        $totalInclusion = 0.0;
        $totalEcole = 0.0;
        foreach (self::_inclusionFiltree($d, $classeId) as $e) {
            $h = round($e['inclusion_min'] / 60, 1);
            $ecole = round($e['ecole_min'] / 60, 1);
            $parEleve[] = [
                'eleve_id' => $e['eleve_id'],
                'nom' => $e['nom'],
                'prenom' => $e['prenom'],
                'total_heures' => $h,
                'heures_par_semaine' => round($h / $nbSemaines, 1),
                'nb_creneaux' => $e['nb_creneaux'],
                'heures_ecole' => $ecole,
                'heures_non_scolarisees' => round($e['nonsco_min'] / 60, 1),
                'heures_ulis' => round($e['ulis_min'] / 60, 1),
                'heures_pec' => round($e['pec_min'] / 60, 1),
                'pourcentage_inclusion' => $ecole > 0 ? round($h / $ecole * 100, 1) : 0,
            ];
            $totalInclusion += $e['inclusion_min'];
            $totalEcole += $e['ecole_min'];
        }
        usort($parEleve, fn($a, $b) => $b['total_heures'] <=> $a['total_heures']);

        $totalH = round($totalInclusion / 60, 1);
        $nbEleves = count($parEleve);

        return [
            'total_heures_annee' => $totalH,
            'heures_par_semaine' => round($totalH / $nbSemaines, 1),
            'moyenne_heures_eleve' => $nbEleves > 0 ? round($totalH / $nbSemaines / $nbEleves, 1) : 0,
            'nb_semaines_scolaires' => $nbSemaines,
            'heures_ecole_semaine' => round($d['minutes_ecole_semaine'] / 60, 1),
            'total_heures_ecole' => round($totalEcole / 60, 1),
            'pourcentage_temps_total' => $totalEcole > 0 ? round($totalInclusion / $totalEcole * 100, 1) : 0,
            'par_eleve' => $parEleve,
        ];
    }

    // ── Par adulte (enseignant, AESH…) ──

    /**
     * Statistiques PAR ADULTE : heures par semaine, nombre d'élèves suivis, et répartition
     * des heures par type d'accompagnement (demandé le 01/10/2026).
     *
     * Mêmes conventions que inclusion() : `duree` est en MINUTES, seules les semaines de
     * l'année scolaire comptent, et « par semaine » divise par le nombre de semaines non
     * vacantes. Aucune formule inventée : mêmes règles que le reste du module.
     *
     * ⚠️ Le créneau stocke le NOM de l'adulte (`creneaux.adulte`), jamais son identifiant :
     * deux homonymes sont indiscernables (même limite que le contrôle de conflit de l'agenda).
     * Les créneaux SANS adulte nommé ne sont pas perdus — ils sont rendus à part
     * (`sans_adulte`), pour que le total des heures reste vérifiable.
     *
     * Les types d'accompagnement sont ceux RÉELLEMENT présents dans l'année (jamais une liste
     * figée), ordonnés par volume d'heures décroissant.
     */
    public static function adultes(PDO $pdo, ?int $anneeId): array {
        if (!$anneeId) {
            $anneeId = (int)$pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
            if (!$anneeId) $anneeId = 1;
        }

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM semaines WHERE annee_scolaire_id = ? AND est_vacances = 0');
        $stmt->execute([$anneeId]);
        $nbSemaines = (int)$stmt->fetchColumn();
        if ($nbSemaines < 1) $nbSemaines = 1;

        $semainesAnnee = 'c.semaine_id IN (SELECT id FROM semaines WHERE annee_scolaire_id = ?)';
        // Le nom est DÉTOURÉ partout (« MARTIN » et « MARTIN  » sont la même personne).
        $avecAdulte = "{$semainesAnnee} AND c.adulte IS NOT NULL AND TRIM(c.adulte) != ''";

        // ⚠️ Un adulte peut accompagner PLUSIEURS élèves dans le MÊME créneau horaire (groupe
        // ULIS, co-intervention) : additionner les durées compterait plusieurs fois la même
        // heure — mesuré sur la base de démo le 01/10/2026 : « M. Dupont, 179 h/semaine », ce
        // qui est impossible. On ne compte donc qu'UNE fois chaque créneau HORAIRE distinct
        // (semaine + jour + heure de début), avec la durée la plus longue des accompagnements
        // simultanés : c'est le TEMPS DE SERVICE de l'adulte.
        $creneauxDistincts = "FROM creneaux c WHERE {$avecAdulte}
                  GROUP BY TRIM(c.adulte), c.semaine_id, c.jour, c.heure_debut";

        // 1. Rôles et élèves suivis (ces deux-là ne se comptent pas deux fois)
        $stmt = $pdo->prepare("SELECT TRIM(c.adulte) AS adulte,
                GROUP_CONCAT(DISTINCT c.role_adulte ORDER BY c.role_adulte SEPARATOR ', ') AS roles,
                COUNT(DISTINCT c.eleve_id) AS nb_eleves
            FROM creneaux c
            WHERE {$avecAdulte}
            GROUP BY TRIM(c.adulte)");
        $stmt->execute([$anneeId]);
        $infos = [];
        foreach ($stmt->fetchAll() as $r) $infos[$r['adulte']] = $r;

        // 2. Temps de service par adulte (créneaux horaires distincts)
        $stmt = $pdo->prepare("SELECT t.adulte, COUNT(*) AS nb_creneaux,
                ROUND(SUM(t.duree) / 60, 1) AS total_heures
            FROM (SELECT TRIM(c.adulte) AS adulte, MAX(c.duree) AS duree
                  {$creneauxDistincts}) t
            GROUP BY t.adulte");
        $stmt->execute([$anneeId]);
        $heures = [];
        foreach ($stmt->fetchAll() as $r) $heures[$r['adulte']] = $r;

        // 3. Répartition par type d'accompagnement (mêmes créneaux distincts, par type)
        $stmt = $pdo->prepare("SELECT t.adulte, t.regroupement_type, ROUND(SUM(t.duree) / 60, 1) AS heures
            FROM (SELECT TRIM(c.adulte) AS adulte, c.regroupement_type, MAX(c.duree) AS duree
                  FROM creneaux c WHERE {$avecAdulte}
                  GROUP BY TRIM(c.adulte), c.regroupement_type, c.semaine_id, c.jour, c.heure_debut) t
            GROUP BY t.adulte, t.regroupement_type");
        $stmt->execute([$anneeId]);

        $parAdulte = [];
        $parType = [];
        foreach ($stmt->fetchAll() as $r) {
            $type = ($r['regroupement_type'] !== null && $r['regroupement_type'] !== '')
                ? $r['regroupement_type'] : 'NON PRÉCISÉ';
            $parAdulte[$r['adulte']][$type] = (float)$r['heures'];
            $parType[$type] = ($parType[$type] ?? 0) + (float)$r['heures'];
        }
        arsort($parType);

        // 4. Créneaux sans adulte nommé (mêmes règles : créneaux horaires distincts)
        $stmt = $pdo->prepare("SELECT COUNT(*) AS nb_creneaux, ROUND(COALESCE(SUM(t.duree), 0) / 60, 1) AS total_heures
            FROM (SELECT MAX(c.duree) AS duree
                  FROM creneaux c
                  WHERE {$semainesAnnee} AND (c.adulte IS NULL OR TRIM(c.adulte) = '')
                  GROUP BY c.semaine_id, c.jour, c.heure_debut) t");
        $stmt->execute([$anneeId]);
        $sansAdulte = $stmt->fetch() ?: ['nb_creneaux' => 0, 'total_heures' => 0];

        $adultes = [];
        foreach ($heures as $nom => $h) {
            $total = (float)$h['total_heures'];
            $adultes[] = [
                'adulte' => $nom,
                'roles' => $infos[$nom]['roles'] ?? '',
                'total_heures' => $total,
                'heures_par_semaine' => round($total / $nbSemaines, 1),
                'nb_eleves' => (int)($infos[$nom]['nb_eleves'] ?? 0),
                'nb_creneaux' => (int)$h['nb_creneaux'],
                'par_type' => $parAdulte[$nom] ?? [],
            ];
        }
        usort($adultes, function ($a, $b) {
            return $b['total_heures'] <=> $a['total_heures'] ?: strcmp($a['adulte'], $b['adulte']);
        });

        return [
            'nb_semaines_scolaires' => $nbSemaines,
            'types' => array_keys($parType),
            'total_heures' => round(array_sum($parType), 1),
            'par_adulte' => $adultes,
            'sans_adulte' => [
                'nb_creneaux' => (int)($sansAdulte['nb_creneaux'] ?? 0),
                'total_heures' => (float)($sansAdulte['total_heures'] ?? 0),
            ],
        ];
    }

    // ── PEC ──

    public static function pec(PDO $pdo, ?int $anneeId): array {
        if (!$anneeId) {
            $anneeId = (int)$pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
            if (!$anneeId) $anneeId = 1;
        }

        $stmt = $pdo->prepare("SELECT p.organisme AS pec_organisme,
                GROUP_CONCAT(DISTINCT p.specialite ORDER BY p.specialite SEPARATOR ', ') AS pec_specialites,
                COUNT(DISTINCT p.eleve_id) AS nb_eleves,
                GROUP_CONCAT(DISTINCT CONCAT(e.prenom, ' ', e.nom) ORDER BY e.nom SEPARATOR ', ') AS eleves_noms
            FROM pec_eleves p
            JOIN eleves e ON e.id = p.eleve_id
            WHERE p.specialite IS NOT NULL AND p.specialite != '' AND p.annee_scolaire_id = ?
            GROUP BY p.organisme
            ORDER BY nb_eleves DESC");
        $stmt->execute([$anneeId]);
        $parSpecialite = $stmt->fetchAll();
        $total = 0;
        foreach ($parSpecialite as $ps) $total += (int)$ps['nb_eleves'];
        return ['total_avec_pec' => $total, 'par_specialite' => $parSpecialite];
    }

    // ── Cantine & Transport ──

    public static function cantineTransport(PDO $pdo, ?int $anneeId): array {
        if (!$anneeId) {
            $anneeId = (int)$pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
            if (!$anneeId) $anneeId = 1;
        }

        $stmt = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE annee_scolaire_id = ?');
        $stmt->execute([$anneeId]); $total = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleve_annees WHERE cantine = 1 AND annee_scolaire_id = ?");
        $stmt->execute([$anneeId]); $cantine = (int)$stmt->fetchColumn();

        $stmt = $pdo->prepare("SELECT transport, COUNT(*) AS nb FROM eleve_annees WHERE transport != '' AND transport IS NOT NULL AND annee_scolaire_id = ? GROUP BY transport ORDER BY nb DESC");
        $stmt->execute([$anneeId]); $transport = $stmt->fetchAll();

        return ['total' => $total, 'cantine' => $cantine, 'cantine_pourcent' => $total > 0 ? round($cantine / $total * 100, 1) : 0, 'transport' => $transport];
    }

    // ── MDPH ──

    public static function mdph(PDO $pdo, ?int $anneeId): array {
        $types = ['ULIS' => 'mdph_ulis', 'AESH' => 'mdph_aesh', 'Transport' => 'mdph_transport', 'SESSAD' => 'mdph_sessad', 'Autre' => 'mdph_autre'];
        $result = [];
        $auj = calulis_aujourdhui();
        $dans60 = date('Y-m-d', strtotime($auj . ' +60 day'));
        foreach ($types as $label => $prefix) {
            $sf = "{$prefix}_statut"; $df = "{$prefix}_date_fin";
            $cond = $anneeId ? ' AND id IN (SELECT eleve_id FROM eleve_annees WHERE annee_scolaire_id = ?)' : '';

            $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleves WHERE {$sf} IS NOT NULL AND {$sf} != ''{$cond}");
            $stmt->execute($anneeId ? [$anneeId] : []); $notifies = (int)$stmt->fetchColumn();

            // Seuil UNIQUE de 60 jours, comme le tableau de bord et l'aide. Il valait 90 ici
            // et 60 là : deux réponses pour la même question (défaut relevé le 26/10/2026).
            // Bornes calculées par l'APPLICATION : CURDATE() suivait l'horloge du serveur
            // MySQL, qui peut être ailleurs (le jour de l'école est celui du poste —
            // calulis_aujourdhui()). Le seuil reste 60 jours, ici comme dans l'aide.
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleves WHERE {$sf} IS NOT NULL AND {$sf} != '' AND {$df} BETWEEN ? AND ?{$cond}");
            $stmt->execute(array_merge([$auj, $dans60], $anneeId ? [$anneeId] : [])); $echeance = (int)$stmt->fetchColumn();

            $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleves WHERE {$sf} IS NOT NULL AND {$sf} != '' AND {$df} < ?{$cond}");
            $stmt->execute(array_merge([$auj], $anneeId ? [$anneeId] : [])); $expires = (int)$stmt->fetchColumn();

            $result[$label] = ['notifies' => $notifies, 'echeance' => $echeance, 'expires' => $expires];
        }
        return $result;
    }

    // ── Ancienneté ──

    public static function anciennete(PDO $pdo, ?int $anneeId): array {
        // Ancienneté alignée sur le per-élève (v1.11) : mois calendaires depuis date_entree_ulis (aujourd'hui).
        // Périmètre : élèves ayant une affectation (cumulée jusqu'à $anneeId si fourni, sinon toutes).
        $sql = 'SELECT e.id AS eleve_id, e.date_entree_ulis'
                . ' FROM eleves e'
                . ' JOIN eleve_annees ea ON ea.eleve_id = e.id'
                . ($anneeId ? ' WHERE ea.annee_scolaire_id <= ?' : '')
                . ' GROUP BY e.id';
        $stmt = $anneeId ? $pdo->prepare($sql) : $pdo->query($sql);
        if ($anneeId) $stmt->execute([$anneeId]);
        $rows = $stmt->fetchAll();

        $total = count($rows);
        $avecDate = 0;
        $sumMois = 0;
        $parEleve = [];
        $repartition = ['moins1' => 0, 1 => 0, 2 => 0, 3 => 0, '4plus' => 0];
        $today = new DateTime(calulis_aujourdhui());

        foreach ($rows as $r) {
            if (empty($r['date_entree_ulis'])) continue;
            $entree = new DateTime($r['date_entree_ulis']);
            $mois = ((int)$today->format('Y') - (int)$entree->format('Y')) * 12
                  + ((int)$today->format('n') - (int)$entree->format('n'));
            if ((int)$today->format('j') < (int)$entree->format('j')) $mois--;
            $mois = max(0, $mois);

            $avecDate++;
            $sumMois += $mois;
            $parEleve[] = ['eleve_id' => (int)$r['eleve_id'], 'mois' => $mois];

            $ans = intdiv($mois, 12);
            if ($ans === 0) $repartition['moins1']++;
            elseif ($ans === 1) $repartition[1]++;
            elseif ($ans === 2) $repartition[2]++;
            elseif ($ans === 3) $repartition[3]++;
            else $repartition['4plus']++;
        }

        $moyenneMois = $avecDate > 0 ? (int)round($sumMois / $avecDate) : 0;
        $moyenne = $avecDate > 0 ? self::_fmtMois($moyenneMois) : '—';

        return [
            'total' => $total,
            'total_avec_date' => $avecDate,
            'moyenne_mois' => $moyenneMois,
            'moyenne' => $moyenne,
            'repartition' => $repartition,
            'par_eleve' => $parEleve,
        ];
    }

    /** Formate un nombre de mois en « X an(s) et Y mois » (aligné sur _fmtAnneesUlis du front). */
    private static function _fmtMois(int $mois): string {
        if ($mois <= 0) return '0 mois';
        $ans = intdiv($mois, 12);
        $reste = $mois % 12;
        $ansTxt = $ans > 0 ? $ans . ' an' . ($ans > 1 ? 's' : '') : '';
        $moisTxt = $reste > 0 ? $reste . ' mois' : '';
        if ($ansTxt !== '' && $moisTxt !== '') return $ansTxt . ' et ' . $moisTxt;
        return $ansTxt !== '' ? $ansTxt : $moisTxt;
    }

    // ── Écoles d'origine ──

    public static function ecolesOrigine(PDO $pdo, ?int $anneeId): array {
        if (!$anneeId) {
            $anneeId = (int)$pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
            if (!$anneeId) $anneeId = 1;
        }

        $sql = 'SELECT et.id AS ecole_origine_id, et.nom AS ecole_nom, et.type AS ecole_type, COUNT(DISTINCT ea.eleve_id) AS nb_eleves
                FROM eleve_annees ea
                JOIN eleves e ON e.id = ea.eleve_id
                LEFT JOIN etablissements et ON et.id = e.ecole_origine_id
                WHERE e.ecole_origine_id IS NOT NULL AND ea.annee_scolaire_id = ?
                GROUP BY et.id ORDER BY nb_eleves DESC';
        $stmt = $pdo->prepare($sql); $stmt->execute([$anneeId]);
        return ['ecoles' => $stmt->fetchAll()];
    }

    // ── Entrées / Sorties ──

    public static function entreesSorties(PDO $pdo, ?int $anneeId): array {
        $annees = $pdo->query('SELECT id, nom, date_debut, date_fin FROM annees_scolaires ORDER BY date_debut DESC LIMIT 5')->fetchAll();
        $result = ['par_annee' => []];
        foreach ($annees as $a) {
            $aid = (int)$a['id'];
            $s1 = $pdo->prepare("SELECT COUNT(*) FROM eleves WHERE date_entree_ulis BETWEEN ? AND ?");
            $s1->execute([$a['date_debut'], $a['date_fin']]); $entrees = (int)$s1->fetchColumn();

            $s2 = $pdo->prepare("SELECT COUNT(*) FROM eleves WHERE date_sortie_ulis BETWEEN ? AND ?");
            $s2->execute([$a['date_debut'], $a['date_fin']]); $sorties = (int)$s2->fetchColumn();

            $s3 = $pdo->prepare("SELECT COUNT(*) FROM eleve_annees WHERE annee_scolaire_id = ?");
            $s3->execute([$aid]); $effectif = (int)$s3->fetchColumn();

            $result['par_annee'][] = ['annee_id' => $aid, 'nom' => $a['nom'], 'entrees' => $entrees, 'sorties' => $sorties, 'effectif' => $effectif];
        }
        return $result;
    }

    // ── Évolution multi-année ──

    public static function evolution(PDO $pdo, ?int $currentAnneeId): array {
        $annees = $pdo->query('SELECT id, nom, date_debut, date_fin FROM annees_scolaires ORDER BY date_debut')->fetchAll();
        if (empty($annees)) return ['par_annee' => [], 'pec_par_annee' => [], 'ecoles_par_annee' => []];

        $parAnnee = [];
        $pecParAnnee = [];
        $ecolesParAnnee = [];

        foreach ($annees as $a) {
            $aid = (int)$a['id'];

            // KPI
            $stmt = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE annee_scolaire_id = ?');
            $stmt->execute([$aid]); $total = (int)$stmt->fetchColumn();

            $stmt = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE ulis = 1 AND annee_scolaire_id = ?');
            $stmt->execute([$aid]); $ulis = (int)$stmt->fetchColumn();

            $stmt = $pdo->prepare('SELECT COUNT(*) FROM eleve_annees WHERE cantine = 1 AND annee_scolaire_id = ?');
            $stmt->execute([$aid]); $cantine = (int)$stmt->fetchColumn();

            $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleve_annees WHERE transport LIKE '%taxi%' AND annee_scolaire_id = ?");
            $stmt->execute([$aid]); $taxi = (int)$stmt->fetchColumn();

            $stmt = $pdo->prepare("SELECT COUNT(DISTINCT eleve_id) FROM pec_eleves WHERE specialite IS NOT NULL AND specialite != '' AND annee_scolaire_id = ?");
            $stmt->execute([$aid]); $pec = (int)$stmt->fetchColumn();

            // Inclusion (décision 9.1) : temps d'école prévu moins ULIS, PEC et non scolarisé.
            $dInclusion = self::_inclusionDonnees($pdo, $aid);
            $inclusionHeures = round(array_sum(array_column($dInclusion['par_semaine'], 'inclusion_min')) / 60, 1);

            // MDPH
            $mdphTotal = 0;
            $mdphExpires = 0;
            $types = ['ulis', 'aesh', 'transport', 'sessad', 'autre'];
            // Même règle que ci-dessus : le jour vient de l'application, pas de MySQL.
            $auj = calulis_aujourdhui();
            foreach ($types as $t) {
                $sf = "mdph_{$t}_statut";
                $df = "mdph_{$t}_date_fin";
                $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleves e
                    JOIN eleve_annees ea ON ea.eleve_id = e.id AND ea.annee_scolaire_id = ?
                    WHERE e.{$sf} IS NOT NULL AND e.{$sf} != ''");
                $stmt->execute([$aid]); $mdphTotal += (int)$stmt->fetchColumn();

                $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleves e
                    JOIN eleve_annees ea ON ea.eleve_id = e.id AND ea.annee_scolaire_id = ?
                    WHERE e.{$sf} IS NOT NULL AND e.{$sf} != '' AND e.{$df} < ?");
                $stmt->execute([$aid, $auj]); $mdphExpires += (int)$stmt->fetchColumn();
            }

            // Entrées / Sorties
            $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleves WHERE date_entree_ulis BETWEEN ? AND ?");
            $stmt->execute([$a['date_debut'], $a['date_fin']]); $entrees = (int)$stmt->fetchColumn();

            $stmt = $pdo->prepare("SELECT COUNT(*) FROM eleves WHERE date_sortie_ulis BETWEEN ? AND ?");
            $stmt->execute([$a['date_debut'], $a['date_fin']]); $sorties = (int)$stmt->fetchColumn();

            $parAnnee[] = [
                'annee_id' => $aid, 'nom' => $a['nom'], 'total' => $total, 'ulis' => $ulis,
                'cantine' => $cantine, 'taxi' => $taxi, 'pec' => $pec,
                'inclusion_heures' => $inclusionHeures, 'mdph_total' => $mdphTotal,
                'mdph_expires' => $mdphExpires, 'entrees' => $entrees, 'sorties' => $sorties,
            ];

            // PEC par spécialité
            $stmtPec = $pdo->prepare("SELECT specialite AS pec_specialite, COUNT(DISTINCT eleve_id) AS nb
                FROM pec_eleves WHERE specialite IS NOT NULL AND specialite != '' AND annee_scolaire_id = ?
                GROUP BY specialite");
            $stmtPec->execute([$aid]);
            foreach ($stmtPec->fetchAll() as $row) {
                $spec = $row['pec_specialite'];
                if (!isset($pecParAnnee[$spec])) $pecParAnnee[$spec] = [];
                $pecParAnnee[$spec][$aid] = (int)$row['nb'];
            }

            // Écoles d'origine
            $stmtEco = $pdo->prepare("SELECT et.nom AS ecole_nom, COUNT(DISTINCT ea.eleve_id) AS nb
                FROM eleve_annees ea
                JOIN eleves e ON e.id = ea.eleve_id
                LEFT JOIN etablissements et ON et.id = e.ecole_origine_id
                WHERE e.ecole_origine_id IS NOT NULL AND ea.annee_scolaire_id = ?
                GROUP BY et.id ORDER BY nb DESC");
            $stmtEco->execute([$aid]);
            foreach ($stmtEco->fetchAll() as $row) {
                $nom = $row['ecole_nom'] ?: 'Inconnue';
                if (!isset($ecolesParAnnee[$nom])) $ecolesParAnnee[$nom] = [];
                $ecolesParAnnee[$nom][$aid] = (int)$row['nb'];
            }
        }

        // Formater PEC
        $pecFormatted = [];
        foreach ($pecParAnnee as $spec => $byAnnee) {
            $values = [];
            foreach ($annees as $a) {
                $values[] = ['annee_id' => (int)$a['id'], 'nom' => $a['nom'], 'nb' => $byAnnee[(int)$a['id']] ?? 0];
            }
            $pecFormatted[] = ['specialite' => $spec, 'values' => $values];
        }

        // Formater Écoles
        $ecolesFormatted = [];
        foreach ($ecolesParAnnee as $nom => $byAnnee) {
            $values = [];
            foreach ($annees as $a) {
                $values[] = ['annee_id' => (int)$a['id'], 'nom' => $a['nom'], 'nb' => $byAnnee[(int)$a['id']] ?? 0];
            }
            $ecolesFormatted[] = ['ecole_nom' => $nom, 'values' => $values];
        }

        return [
            'par_annee' => $parAnnee,
            'pec_par_annee' => $pecFormatted,
            'ecoles_par_annee' => $ecolesFormatted,
        ];
    }

    // ── Inclusion par semaine ──

    public static function inclusionParSemaine(PDO $pdo, ?int $anneeId): array {
        $anneeId = self::_anneeOuActive($pdo, $anneeId);
        $d = self::_inclusionDonnees($pdo, $anneeId);

        $result = [];
        foreach ($d['semaines'] as $s) {
            $sid = (int)$s['id'];
            if ((int)$s['est_vacances']) {
                $result[] = ['numero' => (int)$s['numero'], 'date_debut' => $s['date_debut'],
                    'est_vacances' => true, 'heures_inclusion' => 0, 'nb_creneaux' => 0,
                    'nb_eleves_inclus' => 0];
                continue;
            }
            $w = $d['par_semaine'][$sid] ?? ['inclusion_min' => 0, 'nb_creneaux' => 0, 'nb_eleves_inclus' => 0];
            $result[] = ['numero' => (int)$s['numero'], 'date_debut' => $s['date_debut'],
                'est_vacances' => false, 'heures_inclusion' => round($w['inclusion_min'] / 60, 1),
                'nb_creneaux' => (int)$w['nb_creneaux'], 'nb_eleves_inclus' => (int)$w['nb_eleves_inclus']];
        }
        return $result;
    }

    // ── Inclusion par élève × année ──

    public static function inclusionEleveEvolution(PDO $pdo, int $eleveId): array {
        $annees = $pdo->query('SELECT id, nom FROM annees_scolaires ORDER BY date_debut')->fetchAll();

        $result = [];
        foreach ($annees as $a) {
            $aid = (int)$a['id'];
            $d = self::_inclusionDonnees($pdo, $aid);
            $e = $d['eleves'][$eleveId] ?? null;
            $nbSemaines = max(count($d['semaines_scolaires']), 1);
            $heures = $e ? round($e['inclusion_min'] / 60, 1) : 0.0;
            $ecole = $e ? round($e['ecole_min'] / 60, 1) : 0.0;

            $result[] = ['annee_id' => $aid, 'nom' => $a['nom'], 'heures' => $heures,
                'heures_par_semaine' => round($heures / $nbSemaines, 1),
                'nb_creneaux' => $e ? $e['nb_creneaux'] : 0, 'nb_semaines' => $nbSemaines,
                'pourcentage_inclusion' => $ecole > 0 ? round($heures / $ecole * 100, 1) : 0];
        }
        return $result;
    }

    // ── Inclusion par élève × périodes ──

    public static function inclusionElevePeriodes(PDO $pdo, ?int $anneeId, int $eleveId): array {
        $anneeId = self::_anneeOuActive($pdo, $anneeId);
        $d = self::_inclusionDonnees($pdo, $anneeId);
        $e = $d['eleves'][$eleveId] ?? null;
        $periodes = self::_getPeriodes($pdo, $anneeId);
        $result = [];

        foreach ($periodes as $num => $semaineIds) {
            if (empty($semaineIds)) continue;
            $inc = 0.0; $eco = 0.0; $nb = 0;
            foreach ($semaineIds as $sid) {
                $s = $e['par_semaine'][(int)$sid] ?? null;
                if ($s) { $inc += $s['inclusion']; $eco += $s['ecole']; $nb += $s['nb_creneaux']; }
            }
            $total = round($inc / 60, 1);
            $nbSemaines = count($semaineIds);
            $result[] = ['periode' => $num, 'nb_semaines' => $nbSemaines, 'total_heures' => $total,
                'heures_par_semaine' => $nbSemaines > 0 ? round($total / $nbSemaines, 1) : 0,
                'nb_creneaux' => $nb,
                'pourcentage_inclusion' => $eco > 0 ? round($inc / $eco * 100, 1) : 0];
        }
        return $result;
    }

    // ── Inclusion tous élèves × périodes ──

    public static function inclusionTousElevesPeriodes(PDO $pdo, ?int $anneeId): array {
        $anneeId = self::_anneeOuActive($pdo, $anneeId);
        $d = self::_inclusionDonnees($pdo, $anneeId);
        $periodes = self::_getPeriodes($pdo, $anneeId);
        $result = [];

        foreach ($periodes as $num => $semaineIds) {
            if (empty($semaineIds)) continue;
            $nbSemaines = count($semaineIds);
            foreach ($d['eleves'] as $eid => $e) {
                $inc = 0.0; $eco = 0.0; $nb = 0;
                foreach ($semaineIds as $sid) {
                    $s = $e['par_semaine'][(int)$sid] ?? null;
                    if ($s) { $inc += $s['inclusion']; $eco += $s['ecole']; $nb += $s['nb_creneaux']; }
                }
                if (!isset($result[$eid])) $result[$eid] = [];
                $total = round($inc / 60, 1);
                $result[$eid][] = ['periode' => $num, 'nb_semaines' => $nbSemaines,
                    'total_heures' => $total,
                    'heures_par_semaine' => $nbSemaines > 0 ? round($total / $nbSemaines, 1) : 0,
                    'nb_creneaux' => $nb,
                    'pourcentage_inclusion' => $eco > 0 ? round($inc / $eco * 100, 1) : 0];
            }
        }
        return $result;
    }

    // ── Inclusion par groupe/classe ──

    public static function inclusionGroupe(PDO $pdo, ?int $anneeId, ?int $classeId): array {
        $anneeId = self::_anneeOuActive($pdo, $anneeId);
        $d = self::_inclusionDonnees($pdo, $anneeId);
        $eleves = self::_inclusionFiltree($d, $classeId);
        $effectif = count($eleves);

        $nomGroupe = 'ULIS entière';
        if ($classeId) {
            $stmtNom = $pdo->prepare('SELECT nom FROM classes WHERE id = ?');
            $stmtNom->execute([$classeId]);
            $nomGroupe = $stmtNom->fetchColumn() ?: 'Groupe';
        }

        if ($effectif === 0) {
            return ['nom_groupe' => $nomGroupe, 'effectif' => 0, 'total_heures_annee' => 0,
                'heures_par_semaine' => 0, 'pourcentage_inclusion' => 0, 'par_periode' => [], 'par_annee' => []];
        }

        $nbSemaines = max(count($d['semaines_scolaires']), 1);
        $heuresEcole = round($d['minutes_ecole_semaine'] / 60, 1);

        $totalMin = 0.0; $ecoleMin = 0.0;
        foreach ($eleves as $e) { $totalMin += $e['inclusion_min']; $ecoleMin += $e['ecole_min']; }
        $totalHeures = round($totalMin / 60, 1);
        $pourcentInclusion = $ecoleMin > 0 ? round($totalMin / $ecoleMin * 100, 1) : 0;

        // Par période
        $periodes = self::_getPeriodes($pdo, $anneeId);
        $parPeriode = [];
        foreach ($periodes as $num => $semaineIds) {
            if (empty($semaineIds)) continue;
            $inc = 0.0; $eco = 0.0; $nb = 0;
            foreach ($eleves as $e) {
                foreach ($semaineIds as $sid) {
                    $s = $e['par_semaine'][(int)$sid] ?? null;
                    if ($s) { $inc += $s['inclusion']; $eco += $s['ecole']; $nb += $s['nb_creneaux']; }
                }
            }
            $nbSemP = count($semaineIds);
            $totalP = round($inc / 60, 1);
            $parPeriode[] = ['periode' => $num, 'nb_semaines' => $nbSemP, 'total_heures' => $totalP,
                'heures_par_semaine' => $nbSemP > 0 ? round($totalP / $nbSemP, 1) : 0,
                'pourcentage_inclusion' => $eco > 0 ? round($inc / $eco * 100, 1) : 0,
                'nb_creneaux' => $nb];
        }

        // Par année (historique), avec la même formule : rien n'est figé (décision 9.5).
        $annees = $pdo->query('SELECT id, nom, date_debut, date_fin FROM annees_scolaires ORDER BY date_debut')->fetchAll();
        $parAnnee = [];
        foreach ($annees as $a) {
            $aid = (int)$a['id'];
            $da = self::_inclusionDonnees($pdo, $aid);
            $ea = self::_inclusionFiltree($da, $classeId);
            $nbSemAnnee = max(count($da['semaines_scolaires']), 1);
            $incA = 0.0; $ecoA = 0.0;
            foreach ($ea as $e) { $incA += $e['inclusion_min']; $ecoA += $e['ecole_min']; }
            $totalA = round($incA / 60, 1);
            $parAnnee[] = ['annee_id' => $aid, 'nom' => $a['nom'], 'effectif' => count($ea),
                'nb_semaines' => $nbSemAnnee, 'total_heures' => $totalA,
                'heures_par_semaine' => round($totalA / $nbSemAnnee, 1),
                'pourcentage_inclusion' => $ecoA > 0 ? round($incA / $ecoA * 100, 1) : 0];
        }

        return ['nom_groupe' => $nomGroupe, 'effectif' => $effectif,
            'nb_semaines_scolaires' => $nbSemaines, 'heures_ecole_semaine' => $heuresEcole,
            'total_heures_annee' => $totalHeures,
            'heures_par_semaine' => round($totalHeures / $nbSemaines, 1),
            'pourcentage_inclusion' => $pourcentInclusion,
            'par_periode' => $parPeriode, 'par_annee' => $parAnnee];
    }

    // ── Inclusion par période (global) ──

    public static function inclusionPeriodes(PDO $pdo, ?int $anneeId): array {
        $anneeId = self::_anneeOuActive($pdo, $anneeId);
        $d = self::_inclusionDonnees($pdo, $anneeId);
        $periodes = self::_getPeriodes($pdo, $anneeId);
        $result = [];

        foreach ($periodes as $num => $semaineIds) {
            if (empty($semaineIds)) continue;
            $inc = 0.0; $eco = 0.0; $nb = 0;
            foreach ($d['eleves'] as $e) {
                foreach ($semaineIds as $sid) {
                    $s = $e['par_semaine'][(int)$sid] ?? null;
                    if ($s) { $inc += $s['inclusion']; $eco += $s['ecole']; $nb += $s['nb_creneaux']; }
                }
            }
            $nbSemaines = count($semaineIds);
            $total = round($inc / 60, 1);
            $result[] = ['periode' => $num, 'nb_semaines' => $nbSemaines, 'total_heures' => $total,
                'heures_par_semaine' => $nbSemaines > 0 ? round($total / $nbSemaines, 1) : 0,
                'nb_creneaux' => $nb,
                'pourcentage_inclusion' => $eco > 0 ? round($inc / $eco * 100, 1) : 0];
        }
        return $result;
    }

    // ── Helpers privés ──

    /** L'année demandée, sinon l'année active, sinon 1 — règle unique du module. */
    private static function _anneeOuActive(PDO $pdo, ?int $anneeId): int {
        if ($anneeId) return $anneeId;
        $id = (int)$pdo->query('SELECT id FROM annees_scolaires WHERE est_active = 1 LIMIT 1')->fetchColumn();
        return $id ?: 1;
    }

    /** Heures école / semaine depuis paramètres */
    private static function _getHeuresEcoleSemaine(PDO $pdo): float {
        $heuresParJour = 6;
        $nbJours = 4;

        try {
            $stmt = $pdo->prepare("SELECT valeur FROM parametres WHERE cle = 'horaires'");
            $stmt->execute();
            $horaires = json_decode($stmt->fetchColumn(), true);

            if ($horaires && !empty($horaires['debut']) && !empty($horaires['fin'])) {
                if (!empty($horaires['fin_matin']) && !empty($horaires['debut_aprem'])) {
                    $debutMatin = strtotime($horaires['debut']);
                    $finMatin = strtotime($horaires['fin_matin']);
                    $debutAprem = strtotime($horaires['debut_aprem']);
                    $finAprem = strtotime($horaires['fin']);
                    $heuresParJour = ($finMatin - $debutMatin + $finAprem - $debutAprem) / 3600;
                } else {
                    $debut = strtotime($horaires['debut']);
                    $fin = strtotime($horaires['fin']);
                    $heuresParJour = ($fin - $debut) / 3600;
                    if ($heuresParJour >= 8) $heuresParJour -= 2;
                }
            }

            $stmt = $pdo->prepare("SELECT valeur FROM parametres WHERE cle = 'jours_affiches'");
            $stmt->execute();
            $jours = json_decode($stmt->fetchColumn(), true);
            if (is_array($jours) && count($jours) > 0) {
                $nbJours = count($jours);
            }
        } catch (\Throwable $e) {
            // fallback sur les valeurs par défaut
        }

        return (float)($heuresParJour * $nbJours);
    }

    /** Détecte les blocs de semaines scolaires séparés par des vacances */
    private static function _getPeriodes(PDO $pdo, int $anneeId): array {
        $stmt = $pdo->prepare('SELECT id, numero, est_vacances FROM semaines WHERE annee_scolaire_id = ? ORDER BY numero');
        $stmt->execute([$anneeId]);
        $semaines = $stmt->fetchAll();

        $periodes = [];
        $periode = 0;
        $inPeriode = false;

        foreach ($semaines as $s) {
            if (!$s['est_vacances']) {
                if (!$inPeriode) { $periode++; $periodes[$periode] = []; $inPeriode = true; }
                $periodes[$periode][] = (int)$s['id'];
            } else {
                $inPeriode = false;
            }
        }
        return $periodes;
    }
}
