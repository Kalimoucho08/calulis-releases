<?php
/** Calulis — Model Adulte */
require_once __DIR__ . '/../config.php';

class Adulte {
    /** Les rôles sont une liste FERMÉE (décision 15.6) : une personne peut en porter plusieurs. */
    public const ROLES = ['Coordonnateur ULIS', 'Directeur', 'Enseignant référent', "Membre de l'ESS", 'Intervenant extérieur'];

    /**
     * MÉTIER (libellé de la fiche) → ancienne clé technique `role` (R9, audit du 27/10/2026).
     *
     * La fiche n'écrit plus `role` depuis la migration 016 : elle écrit `metier` + `roles`.
     * Or la clé technique porte encore les FILTRES de la liste et la couleur du créneau. Un
     * nouvel enseignant tombait donc dans « Personnel / Autres » et sa cellule « Rôle » était
     * vide. On DÉRIVE la clé du métier — même correspondance que la migration 016, dans
     * l'autre sens. Un métier inconnu est une spécialité (orthophoniste…), donc un spécialiste.
     */
    private const ROLE_PAR_METIER = [
        'enseignant'         => 'enseignant',
        'aesh co'            => 'aeshco',
        'aesh individuel'    => 'aeshi',
        'aesh mutualisé'     => 'aeshm',
        'aesh mutualise'     => 'aeshm',
        'éducateur'          => 'educateur',
        'educateur'          => 'educateur',
        'assistant familial' => 'assistant_familial',
        'spécialiste'        => 'specialiste',
        'specialiste'        => 'specialiste',
        'autre'              => 'autre',
    ];

    /** La clé technique déduite d'un métier ; null si le métier est vide (on n'efface rien). */
    public static function roleDepuisMetier(string $metier): ?string {
        $cle = mb_strtolower(trim($metier));
        if ($cle === '') { return null; }
        return self::ROLE_PAR_METIER[$cle] ?? 'specialiste';
    }

    public static function all(): array {
        $pdo = getDB();
        $rows = $pdo->query('SELECT a.*, c.nom AS classe_nom, c.id AS classe_id
            FROM adultes a
            LEFT JOIN classes c ON c.enseignant_id = a.id AND c.actif = 1
            WHERE a.actif = 1 ORDER BY a.ordre, a.nom')->fetchAll();
        return self::_attacherRoles($rows);
    }

    /**
     * Attache les rôles en UNE requête (pas de N+1), et TOUJOURS.
     *
     * Pourquoi c'est vital : l'écran de la fiche adulte envoie la liste des rôles cochés.
     * Sans cette liste, il enverrait une liste VIDE et enregistrerait la suppression des
     * rôles existants — une perte de données invisible, au simple fait d'ouvrir puis
     * d'enregistrer une fiche ouverte depuis la liste.
     */
    private static function _attacherRoles(array $adultes): array {
        if (empty($adultes)) { return $adultes; }
        $ids = array_map('intval', array_column($adultes, 'id'));
        $pdo = getDB();
        $stmt = $pdo->query('SELECT adulte_id, role FROM adultes_roles WHERE adulte_id IN (' . implode(',', $ids) . ') ORDER BY role');
        $map = [];
        foreach ($stmt->fetchAll() as $r) { $map[(int)$r['adulte_id']][] = $r['role']; }
        foreach ($adultes as &$a) { $a['roles'] = $map[(int)$a['id']] ?? []; }
        return $adultes;
    }

    /** Recherche filtrée par catégorie (enseignant_notre, personnel_notre, autres) + recherche textuelle */
    public static function getFiltered(?string $filtre = null, ?int $notreEtabId = null, ?string $q = null): array {
        $pdo = getDB();
        $sql = "SELECT a.*, c.nom AS classe_nom, c.id AS classe_id
                FROM adultes a
                LEFT JOIN classes c ON c.enseignant_id = a.id AND c.actif = 1
                WHERE a.actif = 1";
        $params = [];

        if ($filtre && $notreEtabId) {
            if ($filtre === 'enseignant_notre') {
                $sql .= " AND a.role = 'enseignant' AND (a.etablissement_id = :ne1 OR EXISTS (SELECT 1 FROM adultes_etablissements ae WHERE ae.adulte_id = a.id AND ae.etablissement_id = :ne2))";
                $params['ne1'] = $notreEtabId;
                $params['ne2'] = $notreEtabId;
            } elseif ($filtre === 'personnel_notre') {
                $sql .= " AND a.role != 'enseignant' AND (a.etablissement_id = :ne1 OR EXISTS (SELECT 1 FROM adultes_etablissements ae WHERE ae.adulte_id = a.id AND ae.etablissement_id = :ne2))";
                $params['ne1'] = $notreEtabId;
                $params['ne2'] = $notreEtabId;
            } elseif ($filtre === 'autres') {
                $sql .= " AND (a.etablissement_id IS NULL OR a.etablissement_id != :ne1) AND NOT EXISTS (SELECT 1 FROM adultes_etablissements ae WHERE ae.adulte_id = a.id AND ae.etablissement_id = :ne2)";
                $params['ne1'] = $notreEtabId;
                $params['ne2'] = $notreEtabId;
            }
        }

        if ($q) {
            $sql .= " AND (a.nom LIKE :q1 OR a.prenom LIKE :q2)";
            $safe = addcslashes($q, '%_');
            $params['q1'] = "%$safe%";
            $params['q2'] = "%$safe%";
        }

        $sql .= " ORDER BY FIELD(a.role,'enseignant','aeshco','aeshi','aeshm','specialiste','educateur','assistant_familial','autre'), a.ordre, a.nom";
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return self::_attacherRoles($stmt->fetchAll());
    }

    /** Recherche par nom/prénom */
    public static function search(string $q): array {
        $pdo = getDB();
        $stmt = $pdo->prepare(
            'SELECT a.*, c.nom AS classe_nom, c.id AS classe_id
             FROM adultes a
             LEFT JOIN classes c ON c.enseignant_id = a.id AND c.actif = 1
             WHERE a.actif = 1 AND (a.nom LIKE :q OR a.prenom LIKE :q2)
             ORDER BY a.ordre, a.nom'
        );
        $safe = addcslashes($q, '%_');
        $stmt->execute(['q' => "%$safe%", 'q2' => "%$safe%"]);
        return self::_attacherRoles($stmt->fetchAll());
    }

    /**
     * Fiches qui portent le même nom ET le même prénom (décision 15.7, § 16 des décisions).
     *
     * On ne fusionne RIEN ici : on liste. La fusion se fait sur accord explicite, fiche par
     * fiche, parce qu'elle déplace des liens et supprime une fiche.
     * Les compteurs disent laquelle porte la vie réelle (créneaux, classes, tâches).
     */
    public static function doublons(): array {
        $pdo = getDB();
        $rows = $pdo->query(
            "SELECT a.id, a.nom, a.prenom, a.role, a.fonction, a.date_arrivee, a.date_depart, a.actif,
                    (SELECT COUNT(*) FROM creneaux c WHERE c.adulte_id = a.id) AS nb_creneaux,
                    (SELECT COUNT(*) FROM classe_enseignants ce WHERE ce.adulte_id = a.id AND ce.date_fin IS NULL) AS nb_classes,
                    (SELECT COUNT(*) FROM taches t WHERE t.adulte_id = a.id) AS nb_taches,
                    (SELECT COUNT(*) FROM adultes_etablissements ae WHERE ae.adulte_id = a.id) AS nb_structures,
                    (SELECT COUNT(*) FROM utilisateurs u WHERE u.adulte_id = a.id) AS nb_comptes
             FROM adultes a WHERE a.actif = 1 ORDER BY a.nom, a.prenom, a.id"
        )->fetchAll();

        $groupes = [];
        foreach ($rows as $r) {
            $nom = self::_normaliserNom((string)$r['nom']);
            $prenom = mb_strtolower(trim((string)$r['prenom']));
            // Un nom sans prénom n'est pas un doublon : deux « DUPONT » peuvent être deux
            // personnes. On ne signale que ce qui est vraiment le même nom complet.
            if ($nom === '' || $prenom === '') { continue; }
            $groupes[$nom . '|' . $prenom][] = $r;
        }

        // Décision 16.7 : une paire déclarée « ce ne sont pas les mêmes personnes » n'est
        // plus proposée. Un groupe n'est retiré que si TOUTES ses paires ont été tranchées —
        // une troisième fiche du même nom rouvre donc la question, ce qui est le but.
        $paires = self::nonDoublons();

        $out = [];
        foreach ($groupes as $cle => $fiches) {
            if (count($fiches) > 1 && !self::_toutesPairesDeclarees($fiches, $paires)) {
                $out[] = ['cle' => $cle, 'fiches' => $fiches, 'nombre' => count($fiches)];
            }
        }
        return $out;
    }

    /** Les paires déclarées « ce ne sont pas les mêmes personnes », clé « a-b » ordonnée. */
    public static function nonDoublons(): array {
        $pdo = getDB();
        $out = [];
        foreach ($pdo->query('SELECT adulte_a, adulte_b FROM adultes_non_doublons')->fetchAll() as $r) {
            $out[(int)$r['adulte_a'] . '-' . (int)$r['adulte_b']] = true;
        }
        return $out;
    }

    /**
     * Enregistre qu'une paire de fiches ne désigne PAS la même personne (décision 16.7).
     *
     * La paire est ordonnée : c'est la même décision dans les deux sens de lecture.
     * Déclarer deux fois la même paire ne fait rien (et ne lève pas d'erreur) : un clic
     * répété ne doit pas faire échouer l'écran.
     */
    public static function declarerNonDoublons(int $a, int $b): bool {
        if ($a <= 0 || $b <= 0 || $a === $b) {
            throw new InvalidArgumentException('Deux fiches différentes doivent être désignées.');
        }
        $pdo = getDB();
        $st = $pdo->prepare('SELECT COUNT(*) FROM adultes WHERE id IN (:a, :b)');
        $st->execute(['a' => $a, 'b' => $b]);
        if ((int)$st->fetchColumn() !== 2) {
            throw new InvalidArgumentException('Une des deux fiches est introuvable.');
        }
        $min = min($a, $b);
        $max = max($a, $b);
        $pdo->prepare('INSERT IGNORE INTO adultes_non_doublons (adulte_a, adulte_b) VALUES (:a, :b)')
            ->execute(['a' => $min, 'b' => $max]);
        return true;
    }

    /** Vrai si CHAQUE paire de fiches du groupe a été déclarée « pas les mêmes personnes ». */
    private static function _toutesPairesDeclarees(array $fiches, array $paires): bool {
        $ids = array_map(static fn($f) => (int)$f['id'], $fiches);
        $n = count($ids);
        for ($i = 0; $i < $n; $i++) {
            for ($j = $i + 1; $j < $n; $j++) {
                $cle = min($ids[$i], $ids[$j]) . '-' . max($ids[$i], $ids[$j]);
                if (!isset($paires[$cle])) { return false; }
            }
        }
        return true;
    }


    /**
     * FUSION de deux fiches qui désignent la même personne (§ 16 du 27/10/2026).
     *
     * Une seule fiche reste ; elle porte TOUT le contenu des deux. L'autre est supprimée,
     * mais seulement après un contrôle : le nombre de liens déplacés doit être celui attendu,
     * sinon on annule et on le dit — jamais une suppression « presque bonne ».
     *
     * Ce qui ne peut pas être repris automatiquement est écrit dans les commentaires :
     * deux téléphones différents, deux emails différents.
     *
     * @param int $garder    fiche qui subsiste (doit être désignée explicitement)
     * @param int $fusionner fiche absorbée puis supprimée
     * @return array{deplace: array<string,int>}
     */
    public static function fusionner(int $garder, int $fusionner): array {
        if ($garder === $fusionner || $garder <= 0 || $fusionner <= 0) {
            throw new InvalidArgumentException('Deux fiches différentes doivent être désignées.');
        }
        $pdo = getDB();
        $a = self::find($garder);
        $b = self::find($fusionner);
        if (!$a || !$b) { throw new InvalidArgumentException('Une des deux fiches est introuvable.'); }

        // Ce que la fiche absorbée porte, AVANT toute modification.
        $compter = function (string $sql, int $id) use ($pdo): int {
            $st = $pdo->prepare($sql); $st->execute(['id' => $id]); return (int)$st->fetchColumn();
        };
        // R8 (audit du 27/10/2026) : le TITULARIAT d'une classe (classes.enseignant_id) est un
        // lien comme un autre. Il n'était pas compté ni déplacé : si la fiche absorbée était
        // titulaire, la classe perdait son enseignant en silence (la ligne classe_enseignants,
        // elle, était bien déplacée). Et le compte de connexion ne peut pas être dupliqué :
        // s'il en existe déjà un sur la fiche conservée, il n'y a rien à déplacer — on le DIT.
        $compteG = $compter('SELECT COUNT(*) FROM utilisateurs WHERE adulte_id = :id', $garder);
        $compteF = $compter('SELECT COUNT(*) FROM utilisateurs WHERE adulte_id = :id', $fusionner);
        $attendu = [
            'creneaux'   => $compter('SELECT COUNT(*) FROM creneaux WHERE adulte_id = :id', $fusionner),
            'classes'    => $compter('SELECT COUNT(*) FROM classe_enseignants WHERE adulte_id = :id', $fusionner),
            'titulariat' => $compter('SELECT COUNT(*) FROM classes WHERE enseignant_id = :id', $fusionner),
            'taches'     => $compter('SELECT COUNT(*) FROM taches WHERE adulte_id = :id', $fusionner),
            'comptes'    => $compteG === 0 ? $compteF : 0,
        ];

        $pdo->beginTransaction();
        try {
            // 1. Rôles : union.
            $pdo->prepare('INSERT IGNORE INTO adultes_roles (adulte_id, role) SELECT :g, role FROM adultes_roles WHERE adulte_id = :f')
                ->execute(['g' => $garder, 'f' => $fusionner]);

            // 2. Structures : union (la clé est (adulte, établissement, année)).
            $pdo->prepare('INSERT IGNORE INTO adultes_etablissements (adulte_id, etablissement_id, role, annee_scolaire_id, date_debut, date_fin)
                           SELECT :g, etablissement_id, role, annee_scolaire_id, date_debut, date_fin
                           FROM adultes_etablissements WHERE adulte_id = :f')
                ->execute(['g' => $garder, 'f' => $fusionner]);

            // 3. Dates : la plus ancienne arrivée et le plus tardif départ.
            $pdo->prepare('UPDATE adultes SET
                    date_arrivee = LEAST(COALESCE(date_arrivee, :da), :db),
                    date_depart  = GREATEST(COALESCE(date_depart, :ea), :eb)
                WHERE id = :g')
                ->execute([
                    'da' => $b['date_arrivee'], 'db' => $b['date_arrivee'] ?? '9999-12-31',
                    'ea' => $b['date_depart'],  'eb' => $b['date_depart'] ?? '0001-01-01',
                    'g'  => $garder,
                ]);

            // 4. Liens : on les déplace vers la fiche conservée.
            $deplace = [];
            foreach ([
                'creneaux'   => 'UPDATE creneaux SET adulte_id = :g WHERE adulte_id = :f',
                'classes'    => 'UPDATE classe_enseignants SET adulte_id = :g WHERE adulte_id = :f',
                'titulariat' => 'UPDATE classes SET enseignant_id = :g WHERE enseignant_id = :f',
                'taches'     => 'UPDATE taches SET adulte_id = :g WHERE adulte_id = :f',
            ] as $cle => $sql) {
                $st = $pdo->prepare($sql);
                $st->execute(['g' => $garder, 'f' => $fusionner]);
                $deplace[$cle] = $st->rowCount();
            }
            // Compte de connexion : un seul peut subsister ; on déplace s'il n'y en a pas.
            $deuxComptes = ($compteG > 0 && $compteF > 0);
            if ($compteG === 0) {
                $st = $pdo->prepare('UPDATE utilisateurs SET adulte_id = :g WHERE adulte_id = :f');
                $st->execute(['g' => $garder, 'f' => $fusionner]);
                $deplace['comptes'] = $st->rowCount();
            } else {
                $deplace['comptes'] = 0;
            }
            $pdo->prepare('DELETE FROM adultes_etablissements WHERE adulte_id = :f')->execute(['f' => $fusionner]);
            $pdo->prepare('DELETE FROM adultes_roles WHERE adulte_id = :f')->execute(['f' => $fusionner]);

            // 5. Champs divergents : rien ne se perd, l'autre valeur part dans les commentaires.
            $notes = [];
            if ($deuxComptes) {
                $notes[] = 'un second compte de connexion existait sur l\'autre fiche ; il n\'est plus rattaché à une personne';
            }
            // Rattachement principal (adultes.etablissement_id) : repris quand la fiche
            // conservée n'en avait pas (R8). Deux établissements principaux différents ne
            // peuvent pas coexister : l'autre est CONSIGNÉ, jamais écrasé en silence.
            $etabA = $a['etablissement_id'] ?? null;
            $etabB = $b['etablissement_id'] ?? null;
            if (($etabA === null || (int)$etabA === 0) && $etabB !== null && (int)$etabB !== 0) {
                $pdo->prepare('UPDATE adultes SET etablissement_id = :v WHERE id = :g')->execute(['v' => (int)$etabB, 'g' => $garder]);
            } elseif ($etabA !== null && (int)$etabA !== 0 && $etabB !== null && (int)$etabB !== 0 && (int)$etabA !== (int)$etabB) {
                $nomEtab = $pdo->prepare('SELECT nom FROM etablissements WHERE id = :id');
                $nomEtab->execute(['id' => (int)$etabB]);
                $notes[] = 'établissement principal de l\'autre fiche : ' . (string)($nomEtab->fetchColumn() ?: ('#' . $etabB));
            }
            foreach (['telephone' => 'téléphone', 'email' => 'email', 'civilite' => 'civilité'] as $champ => $libelle) {
                $va = trim((string)($a[$champ] ?? ''));
                $vb = trim((string)($b[$champ] ?? ''));
                if ($vb !== '' && $va !== '' && $va !== $vb) {
                    $notes[] = $libelle . ' de l\'autre fiche : ' . $vb;
                } elseif ($va === '' && $vb !== '') {
                    $pdo->prepare("UPDATE adultes SET $champ = :v WHERE id = :g")->execute(['v' => $vb, 'g' => $garder]);
                }
            }
            if ($notes) {
                $commentaire = trim((string)($a['commentaires'] ?? ''));
                $commentaire .= ($commentaire === '' ? '' : "\n") . '(fiche fusionnée) ' . implode(' · ', $notes);
                $pdo->prepare('UPDATE adultes SET commentaires = :c WHERE id = :g')->execute(['c' => $commentaire, 'g' => $garder]);
            }

            // 6. Contrôle AVANT la suppression (décision 16.6) : le nombre de liens DÉPLACÉS
            // doit être exactement celui ATTENDU, et il ne doit plus rien rester sur la fiche
            // absorbée. Les deux contrôles, parce qu'ils ne disent pas la même chose : un lien
            // peut disparaître sans être déplacé (c'était le défaut R8 du titulariat).
            foreach ($attendu as $cle => $n) {
                // Les cinq clés sont TOUJOURS remplies (les quatre liens, puis « comptes ») :
                // pas de « ?? 0 », qui laissait croire à un trou (remarque PHPStan du 30/10/2026).
                $d = (int)$deplace[$cle];
                if ($d !== (int)$n) {
                    throw new \RuntimeException("Fusion annulée : $d lien(s) « $cle » déplacés au lieu de $n.");
                }
            }
            $restants = [
                'creneaux'   => $compter('SELECT COUNT(*) FROM creneaux WHERE adulte_id = :id', $fusionner),
                'classes'    => $compter('SELECT COUNT(*) FROM classe_enseignants WHERE adulte_id = :id', $fusionner),
                'titulariat' => $compter('SELECT COUNT(*) FROM classes WHERE enseignant_id = :id', $fusionner),
                'taches'     => $compter('SELECT COUNT(*) FROM taches WHERE adulte_id = :id', $fusionner),
            ];
            foreach ($restants as $cle => $n) {
                if ($n !== 0) {
                    throw new \RuntimeException("Fusion annulée : $n lien(s) « $cle » n'ont pas pu être déplacés.");
                }
            }

            // 7. La fiche absorbée disparaît — ses données sont désormais dans l'autre.
            $del = $pdo->prepare('DELETE FROM adultes WHERE id = :f');
            $del->execute(['f' => $fusionner]);
            if ($del->rowCount() !== 1) {
                throw new \RuntimeException('Fusion annulée : la fiche absorbée n\'a pas pu être supprimée.');
            }

            $pdo->commit();
            return ['deplace' => $deplace, 'attendu' => $attendu];
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM adultes WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        if ($row) { $row['roles'] = self::roles((int)$row['id']); }
        return $row ?: null;
    }

    /**
     * Crée les fiches des adultes cités dans les créneaux mais absents de la table.
     *
     * Réécrit le 26/10/2026 : l'ancienne version utilisait `INSERT IGNORE` avec une
     * sous-requête dans `VALUES` (refusée par MySQL) et sans clé unique sur `nom` —
     * elle n'ignorait donc rien et aurait dupliqué les fiches à chaque clic.
     * Ici : comparaison des noms NORMALISÉS (civilité, ponctuation, casse), un nom
     * composé (« Mme A, M. B ») est découpé, et le rôle du créneau est repris s'il
     * est connu. Aucune ligne de l'emploi du temps n'est modifiée.
     *
     * @return int nombre de fiches créées
     */
    public static function syncFromCreneaux(): int {
        $pdo = getDB();
        $roleValides = ['enseignant','aeshco','aeshi','aeshm','specialiste','educateur','coordo_ulis','assistant_familial','autre'];

        $existants = [];
        foreach ($pdo->query('SELECT nom FROM adultes')->fetchAll(PDO::FETCH_COLUMN) as $nom) {
            $existants[self::_normaliserNom((string)$nom)] = true;
        }

        $rows = $pdo->query("SELECT DISTINCT adulte, role_adulte FROM creneaux WHERE adulte IS NOT NULL AND TRIM(adulte) <> ''")->fetchAll();
        $ordre = (int)$pdo->query('SELECT COALESCE(MAX(ordre), 0) FROM adultes')->fetchColumn();
        $insert = $pdo->prepare('INSERT INTO adultes (nom, role, ordre, actif) VALUES (:nom, :role, :ordre, 1)');

        $count = 0;
        foreach ($rows as $r) {
            $role = trim((string)($r['role_adulte'] ?? ''));
            if (strpos($role, ',') !== false) $role = trim(explode(',', $role)[0]);
            if (!in_array($role, $roleValides, true)) $role = 'autre';
            foreach (preg_split('/,/', (string)$r['adulte']) as $morceau) {
                $nom = trim($morceau);
                $cle = self::_normaliserNom($nom);
                if ($nom === '' || $cle === '' || isset($existants[$cle])) continue;
                $insert->execute(['nom' => $nom, 'role' => $role, 'ordre' => ++$ordre]);
                $existants[$cle] = true;
                $count++;
            }
        }
        return $count;
    }

    /** « Mme MARTIN », « Dr. Mercier » et « martin » désignent la même personne. */
    private static function _normaliserNom(string $nom): string {
        $n = trim($nom);
        $n = preg_replace('/^(M\.|Mme|Mlle|Dr\.?|Pr\.?)\s+/iu', '', $n);
        $n = preg_replace('/[^a-z0-9]+/iu', ' ', mb_strtolower($n));
        return trim(preg_replace('/\s+/u', ' ', (string)$n));
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO adultes (nom, prenom, civilite, role, fonction, metier, telephone, email, etablissement_id, commentaires, date_arrivee, date_depart)
            VALUES (:nom, :prenom, :civilite, :role, :fonction, :metier, :telephone, :email, :etablissement_id, :commentaires, :date_arrivee, :date_depart)');
        $params = self::_bind($data, false);
        unset($params['ordre'], $params['actif']);
        // R9 : une fiche créée avec un métier reçoit AUSSI sa clé technique, sinon elle
        // n'apparaît dans aucun filtre de la liste et son créneau n'a pas de couleur.
        if (trim((string)$params['role']) === '') {
            $params['role'] = (string)self::roleDepuisMetier((string)($data['metier'] ?? ''));
        }
        $stmt->execute($params);
        $nouvelId = (int)$pdo->lastInsertId();
        self::_saveRoles($nouvelId, $data['roles'] ?? null);
        return $nouvelId;
    }

    /**
     * Modification d'une fiche adulte.
     *
     * ⚠️ On n'écrit QUE les champs REÇUS (mesure du 27/10/2026) : l'ancienne version
     * reprenait tous les champs avec '' par défaut, si bien qu'un envoi partiel —
     * par exemple {"roles":[…]}, ou une correction de téléphone — RÉÉCRIVAIT nom et
     * prénom à vide. Une donnée d'utilisateur ne s'efface pas parce qu'un appel
     * n'en parlait pas.
     */
    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        if (array_key_exists('nom', $data) && trim((string)$data['nom']) === '') {
            throw new InvalidArgumentException('Le nom est obligatoire.');
        }
        $pdo = getDB();
        $champsTexte = ['nom','prenom','civilite','role','fonction','metier','telephone','email','commentaires'];
        $champsDate = ['date_arrivee','date_depart'];
        $champsInt = ['etablissement_id','ordre','actif'];

        $sets = [];
        $params = [];
        foreach ($champsTexte as $c) {
            if (!array_key_exists($c, $data)) { continue; }
            $sets[] = "$c = :$c";
            $params[$c] = trim((string)$data[$c]);
        }
        foreach ($champsDate as $c) {
            if (!array_key_exists($c, $data)) { continue; }
            $sets[] = "$c = :$c";
            $params[$c] = ((string)$data[$c]) === '' ? null : (string)$data[$c];
        }
        foreach ($champsInt as $c) {
            if (!array_key_exists($c, $data)) { continue; }
            $sets[] = "$c = :$c";
            $params[$c] = ($data[$c] === '' || $data[$c] === null) ? null : (int)$data[$c];
        }
        // R9 : changer le MÉTIER met à jour la clé technique qui porte les filtres et la
        // couleur du créneau. Un `role` envoyé explicitement reste prioritaire.
        if (array_key_exists('metier', $data) && !array_key_exists('role', $data)) {
            $derive = self::roleDepuisMetier((string)$data['metier']);
            if ($derive !== null) { $sets[] = 'role = :role'; $params['role'] = $derive; }
        }
        if (empty($sets)) {
            $ok = true;
        } else {
            $params['id'] = $id;
            $stmt = $pdo->prepare('UPDATE adultes SET ' . implode(', ', $sets) . ', updated_at = CURRENT_TIMESTAMP WHERE id = :id');
            $ok = $stmt->execute($params);
        }
        if ($ok && array_key_exists('roles', $data)) {
            self::_saveRoles($id, $data['roles']);
        }
        return $ok;
    }

    /** Les rôles d'un adulte. */
    public static function roles(int $adulteId): array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT role FROM adultes_roles WHERE adulte_id = :id ORDER BY role');
        $stmt->execute(['id' => $adulteId]);
        return array_column($stmt->fetchAll(), 'role');
    }

    /**
     * Remplace les rôles d'un adulte. Un rôle hors de la liste fermée est IGNORÉ plus
     * que refusé : une saisie ancienne ne doit pas faire échouer l'enregistrement d'une fiche.
     */
    private static function _saveRoles(int $adulteId, $roles): void {
        if ($roles === null) { return; }
        if (is_string($roles)) {
            $d = json_decode($roles, true);
            $roles = is_array($d) ? $d : ($roles === '' ? [] : [$roles]);
        }
        if (!is_array($roles)) { $roles = []; }
        $pdo = getDB();
        $pdo->prepare('DELETE FROM adultes_roles WHERE adulte_id = :id')->execute(['id' => $adulteId]);
        $ins = $pdo->prepare('INSERT IGNORE INTO adultes_roles (adulte_id, role) VALUES (:id, :role)');
        foreach ($roles as $r) {
            $r = trim((string)$r);
            if (in_array($r, self::ROLES, true)) { $ins->execute(['id' => $adulteId, 'role' => $r]); }
        }
    }

    public static function reorder(array $ordres): bool {
        $pdo = getDB();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('UPDATE adultes SET ordre = :ordre WHERE id = :id');
            foreach ($ordres as $o) {
                $stmt->execute(['id' => (int)$o['id'], 'ordre' => (int)$o['ordre']]);
            }
            $pdo->commit();
            return true;
        } catch (\Exception $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    private static function _bind(array $data, bool $includeId = true): array {
        $strFields = ['nom', 'prenom', 'civilite', 'role', 'fonction', 'metier', 'telephone', 'email', 'commentaires', 'etablissement_id', 'date_arrivee', 'date_depart'];
        $intFields = ['ordre', 'actif'];
        if ($includeId) $intFields[] = 'id';
        $params = [];
        foreach ($strFields as $f) {
            $params[$f] = isset($data[$f]) ? trim($data[$f]) : '';
        }
        $intDefaults = ['ordre' => 0, 'actif' => 1, 'id' => 0];
        foreach ($intFields as $f) {
            $params[$f] = isset($data[$f]) ? (int)$data[$f] : ($intDefaults[$f] ?? 0);
        }
        // etablissement_id : string → nullable int
        if ($params['etablissement_id'] !== '') $params['etablissement_id'] = (int)$params['etablissement_id'];
        else $params['etablissement_id'] = null;
        // Les deux dates sont FACULTATIVES : une chaîne vide vaut NULL (MySQL refuse '' dans un DATE).
        foreach (['date_arrivee', 'date_depart'] as $champDate) {
            $params[$champDate] = ($params[$champDate] ?? '') === '' ? null : $params[$champDate];
        }
        if ($includeId) $params['id'] = isset($data['id']) ? (int)$data['id'] : 0;
        return $params;
    }
}
