<?php
/**
 * Calulis — Modèle « Calendrier de l'année » (décisions 8.1 à 8.5 et 15.2)
 *
 * UN SEUL CALENDRIER. Les périodes (table periodes), les vacances (semaines
 * est_vacances) et les événements (table evenements) existaient séparément : ce modèle
 * les réunit pour l'écran, et ajoute ce qui manquait au JOUR :
 *
 *   1. un SEUL statut officiel : scolaire, vacances, ferie, fermeture (15.2) ;
 *   2. plusieurs ACTIVITÉS officielles superposables, sur une liste fermée, à la journée
 *      ou à la demi-journée — elles s'affichent, elles ne calculent rien (8.3) ;
 *   3. un COMMENTAIRE libre.
 *
 * LE STATUT ABSENT SE DÉDUIT. On n'écrit pas 365 lignes pour ne rien dire : si le jour
 * n'a pas de ligne, le statut se déduit des semaines marquées « vacances » et des
 * événements de catégorie « ferie ». L'écran peut donc afficher une année entière sans
 * aucune saisie, et toute ligne écrite est un choix explicite de l'utilisateur.
 *
 * L'IMPORT .ICS est idempotent : chaque événement importé garde son UID dans
 * evenements.uid_ics (index unique), donc importer deux fois le même fichier ne crée
 * aucun doublon.
 */
require_once __DIR__ . '/../config.php';

class JourCalendrier
{
    /** Le statut officiel d'un jour (15.2) — un seul par jour. */
    public const STATUTS = ['scolaire', 'vacances', 'ferie', 'fermeture'];

    /** Les activités officielles superposables (15.2) — liste fermée. */
    public const ACTIVITES = ['stage', 'reunion', 'commemoration', 'sortie', 'banalisee', 'autre'];

    /** Une activité peut être posée sur une demi-journée, sans changer le statut du jour. */
    public const DEMI_JOURNEES = ['matin', 'apres_midi'];

    private static function pdo(): PDO
    {
        return getDB();
    }

    /**
     * Les VACANCES, en PÉRIODES et non en semaines (défaut du 28/10/2026).
     *
     * `semaines` ne connaît que des semaines de classe (lundi-vendredi). Tel quel, le
     * samedi 17 octobre — premier jour des vacances de la Toussaint — s'affichait comme
     * un jour d'ÉCOLE, et le week-end entre deux semaines de vacances aussi.
     *
     * Ici : deux semaines voisines (séparées d'un week-end au plus) sont réunies en UNE
     * période, et chaque période est étendue au SAMEDI d'avant et au DIMANCHE d'après —
     * ce que dit le calendrier officiel. Les semaines qui ne commencent pas un lundi (donnée
     * ancienne) sont laissées telles quelles, sans extension inventée.
     *
     * @param array $semaines lignes ['date_debut','date_fin'] des semaines est_vacances
     * @return array liste de ['date_debut','date_fin'] (périodes, dans l'ordre)
     */
    /** Les jours travaillés (réglage « Jours affichés »), en clés minuscules. */
    public static function joursTravailles(): array
    {
        $stmt = self::pdo()->prepare("SELECT valeur FROM parametres WHERE cle = 'jours_affiches'");
        $stmt->execute();
        $brut = (string)($stmt->fetchColumn() ?: '');
        $jours = json_decode($brut, true);
        if (!is_array($jours) || !$jours) {
            // Même repli que le réglage par défaut de l'application (calulis-vierge.sql, setup.php) :
            // le mercredi n'est pas travaillé tant que l'école ne l'a pas coché.
            return ['lundi', 'mardi', 'jeudi', 'vendredi'];
        }
        return array_values(array_map(static fn($j) => mb_strtolower(trim((string)$j)), $jours));
    }

    public static function periodesVacances(array $semaines): array
    {
        if (!$semaines) { return []; }
        usort($semaines, static fn($a, $b) => strcmp((string)$a['date_debut'], (string)$b['date_debut']));
        $blocs = [];
        foreach ($semaines as $s) {
            if (empty($s['date_debut']) || empty($s['date_fin'])) { continue; }
            $debut = new \DateTimeImmutable((string)$s['date_debut']);
            $fin = new \DateTimeImmutable((string)$s['date_fin']);
            if ($fin < $debut) { continue; }
            $dernier = count($blocs) - 1;
            if ($dernier >= 0) {
                $ecart = (int)$blocs[$dernier]['fin']->diff($debut)->days;
                if ($debut <= $blocs[$dernier]['fin'] || $ecart <= 3) {
                    if ($fin > $blocs[$dernier]['fin']) { $blocs[$dernier]['fin'] = $fin; }
                    continue;
                }
            }
            $blocs[] = ['debut' => $debut, 'fin' => $fin];
        }
        $out = [];
        foreach ($blocs as $b) {
            $debut = $b['debut'];
            $fin = $b['fin'];
            // Étendre au samedi d'avant et au dimanche d'après, quand la borne est bien
            // un lundi / un vendredi (jour de classe).
            // L'extension suppose une semaine LUNDI-VENDREDI : une donnée ancienne qui
            // commence un mercredi ne reçoit aucune extension, ni avant ni après (la fin
            // était étendue seule, ce qui inventait un « mercredi → dimanche » — revue du
            // 28/10/2026).
            $debutNormal = (int)$debut->format('N') === 1;
            if ($debutNormal) { $debut = $debut->modify('-2 days'); }
            if ($debutNormal && (int)$fin->format('N') === 5) { $fin = $fin->modify('+2 days'); }
            $out[] = ['date_debut' => $debut->format('Y-m-d'), 'date_fin' => $fin->format('Y-m-d')];
        }
        return $out;
    }

    /**
     * Tout ce qu'il faut pour dessiner l'année : jours renseignés, activités, événements,
     * semaines de vacances, et les bornes de l'année.
     */
    public static function annee(int $anneeId): array
    {
        $annee = self::anneeScolaire($anneeId);
        if (!$annee) {
            throw new InvalidArgumentException('Année scolaire introuvable');
        }
        $debut = (string)$annee['date_debut'];
        $fin = (string)$annee['date_fin'];

        $stmt = self::pdo()->prepare(
            "SELECT date_jour, statut, commentaire FROM jours_calendrier
              WHERE date_jour BETWEEN :debut AND :fin ORDER BY date_jour"
        );
        $stmt->execute(['debut' => $debut, 'fin' => $fin]);
        $jours = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmt = self::pdo()->prepare(
            "SELECT id, date_jour, type, demi_journee, libelle FROM jour_activites
              WHERE date_jour BETWEEN :debut AND :fin ORDER BY date_jour, id"
        );
        $stmt->execute(['debut' => $debut, 'fin' => $fin]);
        $activites = $stmt->fetchAll(PDO::FETCH_ASSOC);

        // Les événements de l'année ET les événements sans année (modèles datés) qui
        // chevauchent la période : un jour férié posé sur l'année scolaire doit se voir.
        $stmt = self::pdo()->prepare(
            "SELECT id, nom, description, date_debut, date_fin, categorie, couleur, est_modele
               FROM evenements
              WHERE date_debut IS NOT NULL AND date_fin IS NOT NULL
                AND date_debut <= :fin2 AND date_fin >= :debut2
                AND (annee_scolaire_id = :annee OR annee_scolaire_id IS NULL)
              ORDER BY date_debut, nom"
        );
        $stmt->execute(['fin2' => $fin, 'debut2' => $debut, 'annee' => $anneeId]);
        $evenements = $stmt->fetchAll(PDO::FETCH_ASSOC);

        $stmt = self::pdo()->prepare(
            "SELECT date_debut, date_fin FROM semaines
              WHERE annee_scolaire_id = :annee AND est_vacances = 1
              ORDER BY date_debut"
        );
        $stmt->execute(['annee' => $anneeId]);
        $vacances = $stmt->fetchAll(PDO::FETCH_ASSOC);

        return [
            'annee'      => $annee,
            'jours'      => $jours,
            'activites'  => $activites,
            'evenements' => $evenements,
            // Des PÉRIODES (week-ends compris) et non les semaines brutes : c'est ce que
            // l'écran doit colorier (voir periodesVacances()).
            'vacances'   => self::periodesVacances($vacances),
            // Les jours travaillés de l'établissement (Paramètres → Jours affichés) :
            // l'écran s'en sert pour distinguer un mercredi ou un samedi non travaillé.
            'jours_travailles' => self::joursTravailles(),
        ];
    }

    public static function anneeScolaire(int $anneeId): ?array
    {
        $stmt = self::pdo()->prepare(
            'SELECT id, nom, date_debut, date_fin, est_active FROM annees_scolaires WHERE id = :id'
        );
        $stmt->execute(['id' => $anneeId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /**
     * Crée les SEMAINES d'une année à partir du calendrier officiel (décision 8.4).
     *
     * Règle des dates : l'API donne le DERNIER JOUR DE CLASSE comme début ; les congés
     * commencent donc le LENDEMAIN. Une semaine (lundi-vendredi) qui chevauche une période
     * de vacances est marquée « vacances ».
     *
     * Un PONT N'EST PAS UNE SEMAINE (28/10/2026) : une entrée de 3 jours ou moins (pont de
     * l'Ascension, journée isolée) ne bascule plus cinq jours de classe en « vacances » ;
     * ses jours sont écrits comme FÉRIÉS, et seulement s'ils n'ont pas déjà un statut choisi.
     *
     * @param array $vacances liste de ['description','date_debut','date_fin'] (API)
     * @return array{semaines:int, jours_feries:int}
     */
    public static function genererSemaines(int $anneeId, array $annee, array $vacances): array
    {
        foreach (['date_debut', 'date_fin', 'nom'] as $cle) {
            if (!isset($annee[$cle]) || (string)$annee[$cle] === '') {
                throw new InvalidArgumentException("Année scolaire incomplète : « $cle » manque.");
            }
        }
        $pdo = self::pdo();
        $debut = new \DateTime((string)$annee['date_debut']);
        $debut->modify('monday this week');
        $fin = new \DateTime((string)$annee['date_fin']);
        $fin->modify('+7 days');

        $periodes = [];
        $joursFeries = [];
        foreach ($vacances as $v) {
            if (empty($v['date_debut']) || empty($v['date_fin'])) { continue; }
            $debutBrut = new \DateTime((string)$v['date_debut']);
            $finBrut = new \DateTime((string)$v['date_fin']);
            if ($finBrut < $debutBrut) { continue; }
            // Le décalage « lendemain du dernier jour de classe » ne vaut que pour une
            // VACANCES. Un PONT est une entrée courte dont la date EST le jour férié
            // (« Pont de l'Ascension — du 6 mai au 6 mai ») : le décaler donnerait le
            // lendemain du jour férié, donc plus rien.
            $dureeBrute = (int)$debutBrut->diff($finBrut)->days + 1;
            if ($dureeBrute <= 3) {
                $joursFeries[] = [$debutBrut, $finBrut];
            } else {
                $vd = (clone $debutBrut)->modify('+1 day');
                $periodes[] = [$vd, $finBrut];
            }
        }

        $insert = $pdo->prepare('INSERT INTO semaines (annee_scolaire_id, numero, date_debut, date_fin, est_vacances) VALUES (?,?,?,?,?)');
        $num = 1;
        $count = 0;
        while ($debut < $fin) {
            $vendredi = clone $debut;
            $vendredi->modify('+4 days');
            $estVacances = 0;
            foreach ($periodes as [$pd, $pf]) {
                if (!($vendredi < $pd || $debut > $pf)) { $estVacances = 1; break; }
            }
            $insert->execute([$anneeId, $num, $debut->format('Y-m-d'), $vendredi->format('Y-m-d'), $estVacances]);
            $debut->modify('+7 days');
            $num++;
            $count++;
        }

        $ecrits = 0;
        if ($joursFeries) {
            $insJour = $pdo->prepare("INSERT IGNORE INTO jours_calendrier (date_jour, statut) VALUES (?, 'ferie')");
            foreach ($joursFeries as [$pd, $pf]) {
                for ($j = clone $pd; $j <= $pf; $j->modify('+1 day')) {
                    $insJour->execute([$j->format('Y-m-d')]);
                    $ecrits += $insJour->rowCount();
                }
            }
        }
        return ['semaines' => $count, 'jours_feries' => $ecrits];
    }

    /**
     * Écrit (ou efface) le statut et le commentaire d'un jour.
     * Statut vide ET commentaire vide = on efface la ligne : le jour revient à la
     * déduction automatique, sans laisser une ligne vide qui ferait croire à un choix.
     */
    public static function definir(string $date, ?string $statut, ?string $commentaire): ?array
    {
        self::validerDate($date);
        $statut = trim((string)$statut);
        if ($statut === '') {
            $statut = null;
        } elseif (!in_array($statut, self::STATUTS, true)) {
            throw new InvalidArgumentException('Statut de jour inconnu : ' . $statut);
        }
        $commentaire = trim((string)$commentaire);

        if ($statut === null && $commentaire === '') {
            $stmt = self::pdo()->prepare('DELETE FROM jours_calendrier WHERE date_jour = :date');
            $stmt->execute(['date' => $date]);
            return null;
        }

        $stmt = self::pdo()->prepare(
            'INSERT INTO jours_calendrier (date_jour, statut, commentaire)
             VALUES (:date, :statut, :commentaire)
             ON DUPLICATE KEY UPDATE statut = VALUES(statut), commentaire = VALUES(commentaire)'
        );
        $stmt->execute([
            'date'        => $date,
            'statut'      => $statut,
            'commentaire' => $commentaire === '' ? null : $commentaire,
        ]);

        $stmt = self::pdo()->prepare(
            'SELECT date_jour, statut, commentaire FROM jours_calendrier WHERE date_jour = :date'
        );
        $stmt->execute(['date' => $date]);
        return $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
    }

    /**
     * Le même statut/commentaire sur PLUSIEURS jours d'affilée — une semaine de vacances,
     * une fermeture de trois jours. C'est la saisie manuelle « complète » (décision 8.4) :
     * jour par jour, ce serait quatorze gestes pour une période de vacances.
     *
     * @return int nombre de jours écrits (ou effacés si statut et commentaire sont vides)
     */
    public static function definirPlage(string $debut, string $fin, ?string $statut, ?string $commentaire): int
    {
        self::validerDate($debut);
        self::validerDate($fin);
        if ($fin < $debut) {
            throw new InvalidArgumentException('La fin de la période précède son début.');
        }
        $d = new DateTimeImmutable($debut);
        $f = new DateTimeImmutable($fin);
        // Garde-fou : une année scolaire entière (370 jours) suffit largement, et une
        // faute de frappe dans l'année ne doit pas écrire dix mille lignes.
        if ($d->diff($f)->days > 370) {
            throw new InvalidArgumentException('La période dépasse 370 jours.');
        }

        $pdo = self::pdo();
        $pdo->beginTransaction();
        $n = 0;
        try {
            while ($d <= $f) {
                if (self::definir($d->format('Y-m-d'), $statut, $commentaire) !== null) {
                    $n++;
                }
                $d = $d->modify('+1 day');
            }
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
        return $n;
    }

    public static function ajouterActivite(array $data): int
    {
        $propre = self::validerActivite($data, true);
        $stmt = self::pdo()->prepare(
            'INSERT INTO jour_activites (date_jour, type, demi_journee, libelle)
             VALUES (:date, :type, :demi, :libelle)'
        );
        $stmt->execute($propre);
        return (int)self::pdo()->lastInsertId();
    }

    public static function modifierActivite(int $id, array $data): bool
    {
        $stmt = self::pdo()->prepare('SELECT date_jour, type, demi_journee, libelle FROM jour_activites WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $existant = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$existant) {
            return false;
        }
        $propre = self::validerActivite(array_merge($existant, $data), true);
        $stmt = self::pdo()->prepare(
            'UPDATE jour_activites SET date_jour = :date, type = :type, demi_journee = :demi, libelle = :libelle
              WHERE id = :id'
        );
        return $stmt->execute($propre + ['id' => $id]);
    }

    public static function supprimerActivite(int $id): bool
    {
        $stmt = self::pdo()->prepare('DELETE FROM jour_activites WHERE id = :id');
        $stmt->execute(['id' => $id]);
        return $stmt->rowCount() > 0;
    }

    private static function validerActivite(array $data, bool $creation): array
    {
        $date = trim((string)($data['date_jour'] ?? $data['date'] ?? ''));
        self::validerDate($date);

        $type = trim((string)($data['type'] ?? ''));
        if (!in_array($type, self::ACTIVITES, true)) {
            throw new InvalidArgumentException('Activité inconnue : ' . $type);
        }

        $demi = trim((string)($data['demi_journee'] ?? ''));
        if ($demi === '') {
            $demi = null;
        } elseif (!in_array($demi, self::DEMI_JOURNEES, true)) {
            throw new InvalidArgumentException('Demi-journée inconnue : ' . $demi);
        }

        $libelle = trim((string)($data['libelle'] ?? ''));
        if (mb_strlen($libelle) > 200) {
            throw new InvalidArgumentException('Le libellé de l\'activité ne doit pas dépasser 200 caractères');
        }

        return [
            'date'   => $date,
            'type'   => $type,
            'demi'   => $demi,
            'libelle' => $libelle === '' ? null : $libelle,
        ];
    }

    private static function validerDate(string $date): void
    {
        if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
            throw new InvalidArgumentException('Date invalide : ' . $date);
        }
        $d = DateTimeImmutable::createFromFormat('Y-m-d', $date);
        if (!$d || $d->format('Y-m-d') !== $date) {
            throw new InvalidArgumentException('Date invalide : ' . $date);
        }
    }

    /**
     * Importe un fichier .ics (décision 8.4) : chaque VEVENT devient un événement daté,
     * rattaché à l'année qui contient sa date. Idempotent par UID.
     *
     * @return array{importes:int, ignores:int, total:int}
     */
    public static function importerIcs(string $contenu, ?int $anneeId = null): array
    {
        $contenu = str_replace(["\r\n", "\r"], "\n", trim($contenu));
        if ($contenu === '' || mb_strlen($contenu) > 2_000_000) {
            throw new InvalidArgumentException('Fichier .ics vide ou trop volumineux (2 Mo maximum).');
        }
        // S10 (audit du 27/10/2026) : une année INEXISTANTE ne se découvre plus au moment de
        // l'INSERT (où la clé étrangère échouait en silence). On refuse AVANT, en le disant.
        if ($anneeId !== null && $anneeId > 0 && self::anneeScolaire($anneeId) === null) {
            throw new InvalidArgumentException('Année scolaire introuvable : aucun événement n\'a été importé.');
        }
        // Pliage RFC 5545 : une ligne qui commence par un espace ou une tabulation
        // continue la précédente.
        $contenu = preg_replace("/\n[ \t]/", '', $contenu) ?? $contenu;

        $blocs = [];
        if (preg_match_all('/BEGIN:VEVENT(.*?)END:VEVENT/s', $contenu, $m)) {
            $blocs = $m[1];
        }
        if (!$blocs) {
            throw new InvalidArgumentException('Aucun événement (VEVENT) dans ce fichier .ics.');
        }

        $importes = 0;
        $ignores = 0;
        $erreurs = 0;
        $messages = [];
        $pdo = self::pdo();
        // Plus d'INSERT IGNORE (S10) : il avalait TOUTE erreur — une clé étrangère absente,
        // un UID trop long — et la comptait comme « déjà présent ». Un doublon (clé unique
        // uid_ics) est maintenant distingué d'un échec, et un échec est DIT à l'utilisateur.
        $stmt = $pdo->prepare(
            'INSERT INTO evenements
                (annee_scolaire_id, nom, description, date_debut, date_fin, est_recurrent,
                 categorie, est_modele, uid_ics)
             VALUES (:annee, :nom, :description, :debut, :fin, 0, \'importe\', 0, :uid)'
        );

        foreach ($blocs as $bloc) {
            $props = self::proprietesIcs($bloc);
            $debut = self::dateIcs($props['DTSTART'] ?? null);
            if ($debut === null) {
                $ignores++;
                continue;
            }
            $fin = self::dateIcs($props['DTEND'] ?? null, true);
            if ($fin === null || $fin < $debut) {
                $fin = $debut;
            }
            $nom = self::texteIcs($props['SUMMARY'] ?? '');
            if ($nom === '') {
                $nom = 'Événement importé';
            }
            $uid = self::texteIcs($props['UID'] ?? '');
            if ($uid === '') {
                // Pas d'UID : on en fabrique un stable à partir du contenu, pour que
                // réimporter le même fichier ne crée pas de doublon.
                $uid = 'ics-' . sha1($nom . '|' . $debut . '|' . $fin);
            }
            // S10 : la colonne accepte 200 caractères. Une troncature SILENCIEUSE ferait
            // entrer en collision deux UID qui ne diffèrent qu'après le 200ᵉ caractère, et
            // le second événement serait « déjà présent ». On raccourcit donc en GARDANT
            // une empreinte du texte entier : même UID → même valeur (idempotent), deux UID
            // différents → deux valeurs différentes.
            $uid = self::uidCourt($uid);
            // R27 (audit du 27/10/2026) : la DOCUMENTATION de cette méthode dit « rattaché à
            // l'année qui contient sa date » ; le code, lui, posait l'année CHOISIE à l'écran
            // sur TOUS les événements du fichier. Un .ics à cheval sur deux années rangeait
            // donc tout dans une seule. C'est la date qui décide ; l'année demandée ne sert
            // plus que de secours quand aucune année ne contient la date.
            $annee = self::anneeDeDate($debut) ?? $anneeId;
            if ($annee === null) {
                $erreurs++;
                if (count($messages) < 5) {
                    $messages[] = 'Événement du ' . $debut . ' : aucune année scolaire ne contient cette date.';
                }
                continue;
            }

            try {
                $stmt->execute([
                    'annee'       => $annee,
                    'nom'         => calulis_substr($nom, 255),
                    'description' => calulis_substr(self::texteIcs($props['DESCRIPTION'] ?? ''), 2000) ?: null,
                    'debut'       => $debut,
                    'fin'         => $fin,
                    'uid'         => $uid,
                ]);
                $importes++;
            } catch (\PDOException $e) {
                // 23000 = violation de contrainte : ici, la clé unique uid_ics. C'est le SEUL
                // cas qui veut dire « déjà importé ». Tout le reste est un échec, compté et dit.
                if ((string)$e->getCode() === '23000') {
                    $ignores++;
                } else {
                    $erreurs++;
                    if (count($messages) < 5) {
                        $messages[] = 'Événement « ' . $nom . ' » du ' . $debut . ' : enregistrement impossible.';
                    }
                }
            }
        }

        return [
            'importes' => $importes,
            'ignores'  => $ignores,
            'total'    => count($blocs),
            'erreurs'  => $erreurs,
            'messages' => $messages,
        ];
    }

    /**
     * Un identifiant .ics qui tient dans les 200 caractères de la colonne, SANS jamais
     * tronquer en silence (S10) : les 150 premiers octets (coupés sur une frontière de
     * caractère) suivis d'une empreinte du texte ENTIER.
     */
    private static function uidCourt(string $uid): string
    {
        if (strlen($uid) <= 200) { return $uid; }
        return mb_strcut($uid, 0, 150, 'UTF-8') . '#' . sha1($uid);
    }

    /** Propriétés d'un bloc VEVENT : nom (sans paramètres) => valeur brute. */
    private static function proprietesIcs(string $bloc): array
    {
        $props = [];
        foreach (explode("\n", $bloc) as $ligne) {
            $ligne = trim($ligne);
            if ($ligne === '' || str_starts_with($ligne, 'BEGIN:') || str_starts_with($ligne, 'END:')) {
                continue;
            }
            $sep = strpos($ligne, ':');
            if ($sep === false) {
                continue;
            }
            $nom = strtoupper(explode(';', substr($ligne, 0, $sep))[0]);
            if (!isset($props[$nom])) {
                $props[$nom] = substr($ligne, $sep + 1);
            }
        }
        return $props;
    }

    /** Date d'une propriété ICS (20261015 ou 20261015T090000Z). Fin exclusive des journées. */
    private static function dateIcs(?string $valeur, bool $finExclusive = false): ?string
    {
        if ($valeur === null) {
            return null;
        }
        if (!preg_match('/^(\d{4})(\d{2})(\d{2})/', trim($valeur), $m)) {
            return null;
        }
        $date = $m[1] . '-' . $m[2] . '-' . $m[3];
        // En ICS, une journée entière a un DTEND EXCLUSIF : le 16 signifie « jusqu'au 15 ».
        if ($finExclusive && strlen(trim($valeur)) === 8) {
            $d = DateTimeImmutable::createFromFormat('Y-m-d', $date);
            if ($d) {
                $date = $d->modify('-1 day')->format('Y-m-d');
            }
        }
        return $date;
    }

    /** Texte ICS : échappements \, \; \n et \\ — sans toucher au reste. */
    private static function texteIcs(string $valeur): string
    {
        $valeur = str_replace(['\\N', '\\n'], "\n", $valeur);
        $valeur = str_replace(['\\,', '\\;', '\\\\'], [',', ';', '\\'], $valeur);
        return trim($valeur);
    }

    public static function anneeDeDate(string $date): ?int
    {
        $stmt = self::pdo()->prepare(
            'SELECT id FROM annees_scolaires WHERE :date BETWEEN date_debut AND date_fin
              ORDER BY date_debut DESC LIMIT 1'
        );
        $stmt->execute(['date' => $date]);
        $id = $stmt->fetchColumn();
        return $id === false ? null : (int)$id;
    }
}