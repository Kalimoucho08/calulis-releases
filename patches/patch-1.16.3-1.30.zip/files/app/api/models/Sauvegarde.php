<?php
/**
 * Calulis — Sauvegarde de la base, côté application.
 *
 * POURQUOI CE FICHIER
 * Charger une base de démonstration, repartir d'une base vierge et restaurer un
 * fichier .sql remplacent TOUTES les données. Jusqu'au 05/10/2026 ces trois
 * opérations n'avaient aucun filet : un fichier abîmé, une coupure, et les
 * données de l'utilisateur étaient perdues (constat B3/B4 de AUDIT-1.15.1.md).
 *
 * OÙ SONT LES SAUVEGARDES
 * `<racine>/runtime/backups/db/<horodatage>/<motif>.sql` — le MÊME dossier que
 * les sauvegardes du lanceur (`pre-update.sql`, écrites par BackupService.cs).
 * Une seule porte de restauration les retrouve donc toutes.
 *
 * Une seule implémentation du dump : ce modèle, utilisé par l'export au
 * navigateur (db-export.php) ET par les sauvegardes automatiques.
 */
class Sauvegarde
{
    /** Pied de fichier d'une sauvegarde COMPLÈTE. On reconnaît une sauvegarde à son
     *  marqueur de fin, jamais à sa taille : une écriture courte peut avoir la bonne
     *  taille, et un arrêt brutal laisse un fichier qui « ressemble » à une sauvegarde. */
    public const MARQUEUR_FIN = '-- FIN DE LA SAUVEGARDE';

    /** Racine d'installation (…/runtime est à côté de app/, launcher/, mysql/). */
    public static function racine(): string
    {
        return dirname(__DIR__, 3);
    }

    /**
     * Dossier des sauvegardes. Surchargeable par CALULIS_BACKUP_DIR : c'est ce
     * qui permet aux tests de travailler dans un dossier jetable SANS jamais
     * écrire ni supprimer quoi que ce soit dans une installation réelle.
     */
    public static function dossierBackups(): string
    {
        $force = getenv('CALULIS_BACKUP_DIR');
        if ($force !== false && $force !== '') {
            return rtrim($force, '/\\');
        }
        return self::racine() . '/runtime/backups/db';
    }

    /**
     * Rend un chemin de sauvegarde AFFICHABLE : relatif à la racine de
     * l'installation, jamais absolu (constat S7 de l'audit du 28/10/2026 — un
     * « C:\Users\<compte>… » dans une réponse révèle le compte Windows, et ce
     * texte finit dans le rapport de bug).
     *
     * Le dossier réel reste retrouvable : « runtime/backups/db/2026-10-30_…/x.sql ».
     * Hors racine (tests, CALULIS_BACKUP_DIR), on ne montre que le nom du fichier.
     */
    public static function cheminAffichable(string $chemin): string {
        $racine = rtrim(str_replace('\\', '/', self::racine()), '/') . '/';
        $normalise = str_replace('\\', '/', $chemin);
        if (str_starts_with($normalise, $racine)) {
            return substr($normalise, strlen($racine));
        }
        return basename($normalise);
    }

    /**
     * Écrit un dump SQL complet de la base courante dans un fichier daté.
     *
     * @param string $motif nom court, sans accent ni espace (ex. « avant-restauration »)
     * @return array{chemin:string,octets:int,tables:int,lignes:int}
     * @throws RuntimeException si le dossier ou le fichier ne peuvent pas être écrits
     *         (l'appelant DOIT alors annuler l'opération destructrice)
     */
    public static function ecrireFichier(PDO $pdo, string $motif = 'sauvegarde'): array
    {
        $motif = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $motif) ?? 'sauvegarde');
        $motif = trim($motif, '-') ?: 'sauvegarde';

        $dossier = self::dossierBackups() . '/' . date('Y-m-d_H-i-s');
        if (!is_dir($dossier) && !@mkdir($dossier, 0777, true) && !is_dir($dossier)) {
            throw new RuntimeException("Impossible de créer le dossier de sauvegarde : " . self::cheminAffichable($dossier));
        }

        $chemin = $dossier . '/' . $motif . '.sql';
        for ($i = 2; is_file($chemin) && $i < 100; $i++) {
            $chemin = $dossier . '/' . $motif . "-$i.sql";
        }
        return self::ecrireDans($pdo, $chemin);
    }

    /**
     * Écrit un dump complet À UN CHEMIN DONNÉ (même travail que ecrireFichier, dont le
     * chemin est choisi ici par l'appelant) : c'est ce qui permet à l'archive du lot 7
     * de porter sa base.sql sans en recopier le code.
     *
     * @return array{chemin:string,octets:int,tables:int,lignes:int}
     * @throws RuntimeException si le fichier ne peut pas être écrit ou s'il est incomplet
     */
    public static function ecrireDans(PDO $pdo, string $chemin): array
    {
        $part = $chemin . '.part';

        $flux = @fopen($part, 'wb');
        if (!$flux) {
            throw new RuntimeException("Impossible d'écrire la sauvegarde : " . self::cheminAffichable($chemin));
        }

        try {
            $stats = self::ecrireFlux($pdo, $flux);
            // Pied de fichier : c'est lui qui prouve que le dump est ALLÉ AU BOUT.
            fwrite($flux, self::MARQUEUR_FIN . "\n");
            @fflush($flux);
            // fsync force l'écriture sur le disque : sans lui, un arrêt brutal peut
            // laisser le fichier dans le cache du système et non sur le disque.
            if (function_exists('fsync')) {
                @fsync($flux);
            }
            $position = ftell($flux);
        } catch (Throwable $e) {
            // Un dump interrompu ne doit pas rester sur le disque : il aurait l'air d'une
            // sauvegarde valide alors qu'il manque la fin.
            @fclose($flux);
            @unlink($part);
            throw $e;
        }
        fclose($flux);

        clearstatcache(true, $part);
        $octets = @filesize($part) ?: 0;
        $complet = $octets > 0
            && ($position === false || $octets === $position)
            && self::finEstMarquee($part);
        if (!$complet) {
            @unlink($part);
            throw new RuntimeException("La sauvegarde est incomplète : $chemin");
        }
        if (!@rename($part, $chemin)) {
            @unlink($part);
            throw new RuntimeException("Impossible de finaliser la sauvegarde : $chemin");
        }

        return [
            'chemin'  => $chemin,
            'octets'  => $octets,
            'tables'  => $stats['tables'],
            'lignes'  => $stats['lignes'],
        ];
    }

    /**
     * La sauvegarde se termine-t-elle par son marqueur de fin ?
     * On lit les derniers octets : un fichier tronqué ne l'a pas.
     */
    private static function finEstMarquee(string $chemin): bool
    {
        $taille = @filesize($chemin) ?: 0;
        if ($taille <= 0) {
            return false;
        }
        $flux = @fopen($chemin, 'rb');
        if (!$flux) {
            return false;
        }
        $lire = min($taille, strlen(self::MARQUEUR_FIN) + 8);
        @fseek($flux, -$lire, SEEK_END);
        $fin = (string) @fread($flux, $lire);
        @fclose($flux);
        return str_contains($fin, self::MARQUEUR_FIN);
    }

    /**
     * Écrit le dump complet vers un flux déjà ouvert (export au navigateur).
     *
     * @param resource $flux
     * @return array{tables:int,lignes:int}
     */
    public static function ecrireFlux(PDO $pdo, $flux): array
    {
        $tables = 0;
        $lignes = 0;

        self::ecrire($flux, "-- Calulis — sauvegarde du " . date('Y-m-d H:i:s') . "\n");
        self::ecrire($flux, "-- Fichier produit sur le poste : aucune donnée n'est envoyée sur Internet.\n");
        self::ecrire($flux, "SET FOREIGN_KEY_CHECKS = 0;\n\n");

        $noms = $pdo->query('SHOW TABLES')->fetchAll(PDO::FETCH_COLUMN);
        foreach ($noms as $table) {
            $create = $pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_NUM);
            if (!$create) { continue; }
            $tables++;

            self::ecrire($flux, "DROP TABLE IF EXISTS `$table`;\n");
            self::ecrire($flux, $create[1] . ";\n\n");

            $rows = $pdo->query("SELECT * FROM `$table`");
            $nbCols = $rows->columnCount();
            if ($nbCols === 0) { continue; }

            $cols = [];
            for ($i = 0; $i < $nbCols; $i++) {
                $meta = $rows->getColumnMeta($i);
                $cols[] = $meta['name'];
            }

            while (($row = $rows->fetch(PDO::FETCH_NUM)) !== false) {
                $values = array_map(static function ($v) use ($pdo) {
                    return $v === null ? 'NULL' : $pdo->quote($v);
                }, $row);
                self::ecrire($flux, "INSERT INTO `$table` (`" . implode('`,`', $cols) . "`) VALUES (" . implode(',', $values) . ");\n");
                $lignes++;
            }
            self::ecrire($flux, "\n");
        }

        self::ecrire($flux, "SET FOREIGN_KEY_CHECKS = 1;\n");

        return ['tables' => $tables, 'lignes' => $lignes];
    }

    /** @param resource $flux */
    private static function ecrire($flux, string $bloc): void
    {
        // fwrite() rend le nombre d'octets écrits, pas seulement true/false : une écriture
        // COURTE (disque plein) passait pour réussie et laissait un dump tronqué.
        $ecrit = fwrite($flux, $bloc);
        if ($ecrit === false || $ecrit !== strlen($bloc)) {
            throw new RuntimeException("Écriture interrompue : il n'y a plus assez de place sur le disque ?");
        }
    }

}
