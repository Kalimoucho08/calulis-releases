<?php
/**
 * Calulis — Archive ZIP minimale, en PHP pur (module Documents, 1.16).
 *
 * POURQUOI CE FICHIER EXISTE
 * Quand on supprime un élève, l'application doit d'abord PROPOSER d'emporter ses
 * documents (décision de Jérôme, 08/10/2026) : c'est le seul moyen de tenir à la
 * fois le droit à l'effacement et le besoin de retrouver un dossier des années
 * plus tard. Il fallait donc fabriquer un ZIP.
 *
 * POURQUOI PAS ZipArchive
 * L'extension `zip` n'est PAS active dans le runtime livré : `frankenphp/php.ini`
 * porte `;extension=zip` (la DLL `php_zip.dll` est bien livrée, mais non chargée),
 * et le PHP de développement de ce poste ne l'a pas davantage. L'activer
 * modifierait le runtime pour tout le reste ; écrire le ZIP ici laisse le paquet
 * tel quel ET rend la fonction prouvable en local (`unzip` vérifie l'archive).
 *
 * CE QU'IL ÉCRIT
 * Un ZIP « stored » (méthode 0, aucune compression) : les documents sont des PDF
 * et des images, déjà compressés — recompresser ne gagnerait presque rien et
 * coûterait du processeur. Le drapeau UTF-8 (bit 11) est posé : les noms
 * accentués s'affichent correctement dans l'Explorateur Windows comme dans `unzip`.
 *
 * MÉMOIRE
 * Tout passe par `php://temp` : au-delà de 2 Mo, PHP bascule seul sur un fichier
 * temporaire. Chaque fichier est lu en FLUX (32 Kio à la fois) et son CRC est
 * calculé par `hash_file`, qui lit aussi en flux : un fichier plus gros que
 * `memory_limit` (128 Mo dans le paquet) ne fait donc pas tomber PHP — c'était le
 * cas d'un `file_get_contents` (relevé par la revue de code du 08/10/2026).
 *
 * PAS DE ZIP64, ET C'EST DIT
 * Le format sans ZIP64 plafonne à 65 535 entrées et 4 Gio. Ces bornes sont
 * VÉRIFIÉES avant d'écrire (`verifierBornes`) : au-delà, on refuse avec un message
 * clair au lieu de produire une archive que Windows ouvrirait de travers (le
 * nombre d'entrées est écrit sur 16 bits, l'offset sur 32 : l'erreur est
 * silencieuse dans le fichier, d'où ce refus explicite).
 *
 * Ce fichier emprunte `Stockage::tronquer()` (troncature UTF-8 sans mbstring) : la
 * seule source de cette logique reste `Stockage.php`, on ne la recopie pas ici.
 */
require_once __DIR__ . '/Stockage.php';

class Archive
{
    /**
     * Bornes du format sans ZIP64, avec une marge : au-delà de 65 535 entrées ou de
     * 4 Gio, les champs 16 et 32 bits débordent et l'archive devient illisible.
     */
    public const ENTREES_MAX = 65000;
    public const TAILLE_MAX = 4294901760; // 4 Gio − 64 Kio

    /** @var resource Flux d'écriture (mémoire puis fichier temporaire). */
    private $flux;

    /** @var array<int,array{nom:string,offset:int,taille:int,crc:int,heure:int,date:int}> */
    private array $entrees = [];

    /** Noms déjà pris, en minuscules : deux documents peuvent porter le même nom. */
    private array $nomsPris = [];

    /** Octets déjà écrits — l'offset du prochain en-tête local. */
    private int $offset = 0;

    /** Le répertoire central n'est écrit qu'une fois, même si l'on demande taille() puis envoyer(). */
    private bool $termine = false;

    /** Taille des blocs de lecture d'un fichier, en octets. */
    private const BLOC = 32768;

    public function __construct()
    {
        $flux = fopen('php://temp/maxmemory:2097152', 'w+b');
        if ($flux === false) {
            throw new RuntimeException("L'archive n'a pas pu être préparée (mémoire temporaire indisponible)");
        }
        $this->flux = $flux;
    }

    public function __destruct()
    {
        if (is_resource($this->flux)) {
            fclose($this->flux);
        }
    }

    /** Nombre d'entrées déjà ajoutées (borné par ENTREES_MAX). */
    public function nombreEntrees(): int
    {
        return count($this->entrees);
    }

    /**
     * Ajoute un fichier du disque sous le nom voulu dans l'archive, en le lisant en flux.
     * @return string Le nom RÉELLEMENT écrit (il peut avoir été dédoublonné).
     * @throws RuntimeException si le fichier ne peut pas être lu, ou si l'archive dépasse les bornes du format
     */
    public function ajouterFichier(string $nom, string $cheminAbsolu, bool $garderDossiers = false): string
    {
        $taille = @filesize($cheminAbsolu);
        $crc = @hash_file('crc32b', $cheminAbsolu);
        if ($taille === false || $crc === false) {
            throw new RuntimeException("Un fichier du dossier n'a pas pu être lu pour l'archive.");
        }
        $this->verifierBornes((int)$taille);

        $nom = $garderDossiers ? $this->nomArchiveChemin($nom) : $this->nomArchive($nom);
        $quand = getdate(@filemtime($cheminAbsolu) ?: time());
        $this->ecrireEntete($nom, (int)$taille, (int)hexdec($crc), $this->heureDos($quand), $this->dateDos($quand));

        $entree = @fopen($cheminAbsolu, 'rb');
        if ($entree === false) {
            throw new RuntimeException("Un fichier du dossier n'a pas pu être lu pour l'archive.");
        }
        while (!feof($entree)) {
            $bloc = fread($entree, self::BLOC);
            if ($bloc === false) {
                fclose($entree);
                throw new RuntimeException("Un fichier du dossier n'a pas pu être lu pour l'archive.");
            }
            if ($bloc !== '') {
                $this->ecrire($bloc);
            }
        }
        fclose($entree);

        $this->retenir($nom, (int)$taille, (int)hexdec($crc), $this->heureDos($quand), $this->dateDos($quand));
        return $nom;
    }

    /**
     * Ajoute un contenu déjà en mémoire (l'index de l'archive, par exemple).
     * @return string Le nom réellement écrit.
     */
    public function ajouterContenu(string $nom, string $contenu, ?int $mtime = null): string
    {
        $this->verifierBornes(strlen($contenu));
        $nom = $this->nomArchive($nom);
        $quand = getdate($mtime ?? time());
        $this->ecrireEntete($nom, strlen($contenu), (int)crc32($contenu), $this->heureDos($quand), $this->dateDos($quand));
        $this->ecrire($contenu);
        $this->retenir($nom, strlen($contenu), (int)crc32($contenu), $this->heureDos($quand), $this->dateDos($quand));
        return $nom;
    }

    /**
     * Réserve un nom pour l'index, AVANT d'ajouter les documents : l'index garde ainsi
     * toujours le nom annoncé par l'aide et la page RGPD (`documents.txt`), même si un
     * document porte ce nom — c'est le document qui est renommé, pas l'index.
     */
    public function reserverNom(string $nom): void
    {
        $this->nomsPris[$this->cleNom($nom)] = true;
    }

    /**
     * Ajoute une entrée sous un nom DÉJÀ réservé (`reserverNom`) : pas de dédoublonnage,
     * le nom est celui qu'on a promis.
     */
    public function ajouterIndex(string $nom, string $contenu): void
    {
        $this->reserverNom($nom);
        $this->verifierBornes(strlen($contenu));
        $quand = getdate();
        $this->ecrireEntete($nom, strlen($contenu), (int)crc32($contenu), $this->heureDos($quand), $this->dateDos($quand));
        $this->ecrire($contenu);
        $this->retenir($nom, strlen($contenu), (int)crc32($contenu), $this->heureDos($quand), $this->dateDos($quand));
    }

    /** Écrit le répertoire central : sans lui, l'archive n'est pas lisible. */
    public function terminer(): void
    {
        if ($this->termine) {
            return;
        }
        $this->termine = true;
        $debut = $this->offset;
        $repertoire = '';
        foreach ($this->entrees as $e) {
            $repertoire .= pack(
                'VvvvvvvVVVvvvvvVV',
                0x02014b50,
                20,                 // version ayant fabriqué l'entrée
                20,                 // version nécessaire pour extraire
                0x0800,
                0,
                $e['heure'],
                $e['date'],
                $e['crc'],
                $e['taille'],
                $e['taille'],
                strlen($e['nom']),
                0, 0, 0, 0,         // extra, commentaire, disque, attributs internes
                0,                  // attributs externes
                $e['offset']
            ) . $e['nom'];
        }
        $this->ecrire($repertoire);
        $this->ecrire(pack(
            'VvvvvVVv',
            0x06054b50,
            0, 0,
            count($this->entrees),
            count($this->entrees),
            strlen($repertoire),
            $debut,
            0
        ));
    }

    /**
     * Termine l'archive et l'envoie sur la sortie (le contrôleur a déjà posé ses
     * en-têtes HTTP). À appeler UNE fois.
     */
    public function envoyer(): void
    {
        $this->terminer();
        rewind($this->flux);
        fpassthru($this->flux);
        fclose($this->flux);
    }

    /** Taille du ZIP terminé, sans l'envoyer (pour « Content-Length »). */
    public function taille(): int
    {
        $this->terminer();
        $stat = fstat($this->flux);
        return (int)($stat['size'] ?? 0);
    }

    /**
     * Refuse AVANT d'écrire ce que le format sans ZIP64 ne sait pas représenter :
     * l'excès ne lève aucune erreur à l'écriture, il produit une archive que Windows
     * ouvre de travers (nombre d'entrées tronqué à 16 bits, offset à 32 bits).
     */
    private function verifierBornes(int $tailleSupplementaire): void
    {
        if (count($this->entrees) + 1 > self::ENTREES_MAX) {
            throw new RuntimeException(
                "Ce dossier contient trop de documents pour tenir dans une archive (" . self::ENTREES_MAX . " au maximum)."
            );
        }
        if ($this->offset + $tailleSupplementaire > self::TAILLE_MAX) {
            throw new RuntimeException(
                "Ce dossier est trop volumineux pour tenir dans une archive (4 Go au maximum)."
            );
        }
    }

    private function ecrireEntete(string $nom, int $taille, int $crc, int $heure, int $date): void
    {
        $this->ecrire(pack(
            'VvvvvvVVVvv',
            0x04034b50,
            20,          // version nécessaire pour extraire
            0x0800,      // drapeau : noms en UTF-8
            0,           // méthode : stored (aucune compression)
            $heure,
            $date,
            $crc,
            $taille,
            $taille,
            strlen($nom),
            0            // pas de champ « extra »
        ) . $nom);
    }

    private function retenir(string $nom, int $taille, int $crc, int $heure, int $date): void
    {
        $this->entrees[] = [
            'nom'    => $nom,
            // L'offset de l'en-tête local = position courante − nom − taille − 30 octets d'en-tête.
            'offset' => $this->offset - $taille - strlen($nom) - 30,
            'taille' => $taille,
            'crc'    => $crc,
            'heure'  => $heure,
            'date'   => $date,
        ];
    }

    private function heureDos(array $quand): int
    {
        return (($quand['hours'] & 0x1F) << 11) | (($quand['minutes'] & 0x3F) << 5) | (($quand['seconds'] >> 1) & 0x1F);
    }

    private function dateDos(array $quand): int
    {
        return ((max(1980, $quand['year']) - 1980) << 9) | (($quand['mon'] & 0x0F) << 5) | ($quand['mday'] & 0x1F);
    }

    private function ecrire(string $octets): void
    {
        $ecrits = fwrite($this->flux, $octets);
        if ($ecrits === false || $ecrits !== strlen($octets)) {
            throw new RuntimeException("L'archive n'a pas pu être écrite (disque temporaire plein ?)");
        }
        $this->offset += $ecrits;
    }

    /**
     * Nom d'entrée sûr et unique : ni chemin, ni `..`, ni caractère de contrôle.
     * Un document peut s'appeler comme un autre : le second devient « nom (2).pdf ».
     */
    /**
     * Nom d'archive qui GARDE l'arborescence (documents/eleve-7/bilan.txt).
     *
     * `nomArchive()` aplatit volontairement les noms — c'est ce qu'il faut quand on
     * exporte les documents d'un élève dans un dossier unique. Pour une sauvegarde
     * COMPLÈTE, aplatir mélangerait les documents de tous les élèves dans une seule
     * archive illisible et écraserait les homonymes : on garde donc les dossiers,
     * segment par segment, en refusant tout ce qui pourrait sortir de l'archive.
     */
    private function nomArchiveChemin(string $nom): string
    {
        $nom = str_replace('\\', '/', $nom);
        $morceaux = [];
        foreach (explode('/', $nom) as $morceau) {
            $morceau = (string) preg_replace('/[\x00-\x1F\x7F]/u', '', $morceau);
            $morceau = trim($morceau);
            if ($morceau === '' || $morceau === '.' || $morceau === '..') {
                continue;
            }
            $morceaux[] = Stockage::tronquer($morceau, 120);
        }
        if ($morceaux === []) {
            $morceaux[] = 'document';
        }

        $essai = implode('/', $morceaux);
        $suffixe = 2;
        while (isset($this->nomsPris[$this->cleNom($essai)])) {
            $extension = pathinfo((string) end($morceaux), PATHINFO_EXTENSION);
            $base = pathinfo((string) end($morceaux), PATHINFO_FILENAME);
            $morceaux[count($morceaux) - 1] = $base . ' (' . $suffixe . ')' . ($extension !== '' ? '.' . $extension : '');
            $essai = implode('/', $morceaux);
            $suffixe++;
        }
        $this->nomsPris[$this->cleNom($essai)] = true;
        return $essai;
    }
    private function nomArchive(string $nom): string
    {
        $nom = str_replace('\\', '/', $nom);
        $nom = (string)preg_replace('#(^|/)\.\.?(/|$)#', '/', $nom);
        $position = strrpos($nom, '/');
        if ($position !== false) {
            $nom = substr($nom, $position + 1);
        }
        $nom = (string)preg_replace('/[\x00-\x1F\x7F]/u', '', $nom);
        $nom = trim($nom);
        if ($nom === '' || $nom === '.' || $nom === '..') {
            $nom = 'document';
        }
        $nom = Stockage::tronquer($nom, 200);

        $essai = $nom;
        $suffixe = 2;
        while (isset($this->nomsPris[$this->cleNom($essai)])) {
            $extension = pathinfo($nom, PATHINFO_EXTENSION);
            $base = pathinfo($nom, PATHINFO_FILENAME);
            $essai = $base . ' (' . $suffixe . ')' . ($extension !== '' ? '.' . $extension : '');
            $suffixe++;
        }
        $this->nomsPris[$this->cleNom($essai)] = true;
        return $essai;
    }

    /**
     * Clé de comparaison des noms. `strtolower` ne connaît que l'ASCII : « École.pdf »
     * et « école.pdf » seraient considérés différents puis extraits sur le même nom
     * sous Windows. `mb_strtolower` n'existe pas dans le PHP de développement de ce
     * poste (constaté le 08/10/2026) : d'où le repli.
     */
    private function cleNom(string $nom): string
    {
        return function_exists('mb_strtolower') ? mb_strtolower($nom, 'UTF-8') : strtolower($nom);
    }
    /* ══ LIRE UNE ARCHIVE (restauration) ═════════════════════════════════════════
     *
     * La même contrainte que pour l'écriture : pas d'extension « zip ». Le lecteur
     * vit donc ici, à côté de l'écrivain, et ne lit QUE ce que l'écrivain produit
     * ou ce qu'un ZIP standard contient (méthode 0 « stored » et méthode 8
     * « deflate »). Ni ZIP64, ni chiffrement, ni multi-disque : on refuse
     * franchement plutôt que de deviner.
     */

    /** Signature de fin de répertoire central. */
    private const EOCD = 0x06054b50;
    /** Signature d'une entrée du répertoire central. */
    private const CENTRAL = 0x02014b50;
    /** Signature d'un en-tête local. */
    private const LOCAL = 0x04034b50;

    /**
     * Entrées de l'archive, lues dans le répertoire central.
     *
     * @return array<string,array{octets:int,taille:int,methode:int,debut:int,crc:int}>
     * @throws RuntimeException si le fichier n'est pas une archive lisible
     *         (tronquée, ZIP64, ou pas un ZIP du tout) — jamais d'analyse partielle.
     */
    /**
     * Entrées de l'archive, lues dans le répertoire central.
     *
     * @return array<string,array{octets:int,taille:int,methode:int,debut:int,crc:int}>
     * @throws RuntimeException si le fichier n'est pas une archive lisible
     *         (tronquée, ZIP64, ou pas un ZIP du tout) — jamais d'analyse partielle.
     */
    public static function entrees(string $chemin): array
    {
        $taille = @filesize($chemin);
        $flux = @fopen($chemin, 'rb');
        if ($taille === false || $flux === false || $taille < 22) {
            if (is_resource($flux)) { fclose($flux); }
            throw new RuntimeException("Ce fichier n'est pas une archive lisible.");
        }

        // Le répertoire central se termine par sa signature : on la cherche dans les
        // 64 Kio de fin (taille maximale d'un commentaire d'archive).
        $queue = min($taille, 65557);
        fseek($flux, -$queue, SEEK_END);
        $fin = (string) fread($flux, $queue);
        $position = strrpos($fin, pack('V', self::EOCD));
        if ($position === false) {
            fclose($flux);
            throw new RuntimeException("Ce fichier n'est pas une archive lisible (fin de répertoire absente).");
        }
        $eocd = unpack(
            'Vsig/vdisque/vdisque_cd/vnb_disque/vnb_total/Vtaille_cd/Vdebut_cd/vcommentaire',
            substr($fin, $position, 22)
        );
        if ($eocd === false) {
            fclose($flux);
            throw new RuntimeException("Ce fichier n'est pas une archive lisible (fin de répertoire incomplète).");
        }
        if ($eocd['nb_total'] === 0xFFFF || $eocd['debut_cd'] === 0xFFFFFFFF) {
            fclose($flux);
            throw new RuntimeException("Cette archive est au format ZIP64, que Calulis ne sait pas lire.");
        }
        if ($eocd['debut_cd'] <= 0 || $eocd['nb_total'] === 0) {
            fclose($flux);
            throw new RuntimeException("Cette archive est vide.");
        }

        // DEUX PASSES : la première lit le répertoire central (noms, tailles, offsets), la
        // seconde ouvre chaque en-tête LOCAL pour savoir où commencent VRAIMENT les données.
        // Les mélanger dans une seule boucle faisait perdre le fil du répertoire central
        // (défaut trouvé le 31/10/2026 : « entrée de répertoire illisible » dès la 2e entrée).
        fseek($flux, (int) $eocd['debut_cd']);
        $bruts = [];
        for ($i = 0; $i < (int) $eocd['nb_total']; $i++) {
            $bloc = fread($flux, 46);
            if ($bloc === false || strlen($bloc) < 46) {
                fclose($flux);
                throw new RuntimeException("Cette archive est abîmée (répertoire central tronqué).");
            }
            $e = unpack(
                'Vsig/vfabrique/vbesoin/vdrapeau/vmethode/vheure/vdate/Vcrc/Voctets/Vtaille'
                . '/vnom/vextra/vcommentaire/vdisque/vinterne/Vexterne/Vdebut',
                $bloc
            );
            if ($e === false || $e['sig'] !== self::CENTRAL) {
                fclose($flux);
                throw new RuntimeException("Cette archive est abîmée (entrée de répertoire illisible).");
            }
            $nom = (string) fread($flux, (int) $e['nom']);
            if ((int) $e['extra'] > 0) { fseek($flux, (int) $e['extra'], SEEK_CUR); }
            if ((int) $e['commentaire'] > 0) { fseek($flux, (int) $e['commentaire'], SEEK_CUR); }
            if ($e['methode'] !== 0 && $e['methode'] !== 8) {
                fclose($flux);
                throw new RuntimeException("Cette archive utilise une compression que Calulis ne sait pas lire.");
            }
            $bruts[] = ['nom' => $nom, 'bloc' => $e];
        }

        $entrees = [];
        foreach ($bruts as $brut) {
            $e = $brut['bloc'];
            // Les données commencent après l'en-tête LOCAL, dont les longueurs peuvent
            // différer du répertoire : c'est la norme, ne pas s'y fier.
            fseek($flux, (int) $e['debut']);
            $local = (string) fread($flux, 30);
            $l = strlen($local) === 30
                ? unpack('Vsig/vbesoin/vdrapeau/vmethode/vheure/vdate/Vcrc/Voctets/Vtaille/vnom/vextra', $local)
                : false;
            if ($l === false || $l['sig'] !== self::LOCAL) {
                fclose($flux);
                throw new RuntimeException("Cette archive est abîmée (en-tête local absent).");
            }
            $entrees[$brut['nom']] = [
                'octets'  => (int) $e['octets'],
                'taille'  => (int) $e['taille'],
                'methode' => (int) $e['methode'],
                'debut'   => (int) $e['debut'] + 30 + (int) $l['nom'] + (int) $l['extra'],
                'crc'     => (int) $e['crc'],
            ];
        }
        fclose($flux);
        return $entrees;
    }
    /**
     * Extrait UNE entrée vers un fichier, en flux (une archive de 300 Mo ne passe
     * jamais entièrement en mémoire), puis vérifie son empreinte CRC.
     *
     * @throws RuntimeException si l'entrée est absente, illisible ou corrompue
     */
    public static function extraire(string $chemin, string $nom, string $destination): void
    {
        $entrees = self::entrees($chemin);
        if (!isset($entrees[$nom])) {
            throw new RuntimeException("Cette archive ne contient pas « " . $nom . " ».");
        }
        $e = $entrees[$nom];
        $flux = @fopen($chemin, 'rb');
        $sortie = @fopen($destination . '.part', 'wb');
        if ($flux === false || $sortie === false) {
            if (is_resource($flux)) { fclose($flux); }
            if (is_resource($sortie)) { fclose($sortie); }
            @unlink($destination . '.part');
            throw new RuntimeException("L'extraction n'a pas pu être écrite : le disque est peut-être plein.");
        }
        fseek($flux, $e['debut']);
        $reste = $e['octets'];
        $contexte = $e['methode'] === 8 ? inflate_init(ZLIB_ENCODING_RAW) : null;
        $crc = hash_init('crc32b');
        try {
            while ($reste > 0) {
                $bloc = fread($flux, min(32768, $reste));
                if ($bloc === false || $bloc === '') {
                    throw new RuntimeException("Cette archive est abîmée (données tronquées).");
                }
                $reste -= strlen($bloc);
                $ecrit = $contexte === null ? $bloc : inflate_add($contexte, $bloc, ZLIB_SYNC_FLUSH);
                if ($ecrit === false) {
                    throw new RuntimeException("Cette archive est abîmée (données illisibles).");
                }
                hash_update($crc, $ecrit);
                if (fwrite($sortie, $ecrit) !== strlen($ecrit)) {
                    throw new RuntimeException("L'extraction n'a pas pu être écrite : le disque est peut-être plein.");
                }
            }
        } catch (Throwable $erreur) {
            fclose($flux);
            fclose($sortie);
            @unlink($destination . '.part');
            throw $erreur;
        }
        fclose($flux);
        fclose($sortie);
        if ((int) hexdec(hash_final($crc)) !== $e['crc']) {
            @unlink($destination . '.part');
            throw new RuntimeException("« " . $nom . " » ne correspond pas à son empreinte : l'archive est abîmée.");
        }
        if (!@rename($destination . '.part', $destination)) {
            @unlink($destination . '.part');
            throw new RuntimeException("L'extraction n'a pas pu être finalisée.");
        }
    }
    /**
     * Termine l'archive et l'écrit dans un FICHIER (au lieu de la sortie HTTP).
     * Écriture sur un nom temporaire puis renommage : un arrêt brutal ne laisse
     * jamais un fichier partiel portant le nom d'une sauvegarde valide.
     *
     * @return int nombre d'octets écrits
     * @throws RuntimeException si le disque refuse l'écriture
     */
    public function ecrireVers(string $chemin): int
    {
        $this->terminer();
        rewind($this->flux);
        $part = $chemin . '.part';
        $sortie = @fopen($part, 'wb');
        if ($sortie === false) {
            throw new RuntimeException("L'archive n'a pas pu être écrite : le disque est peut-être plein.");
        }
        $octets = stream_copy_to_stream($this->flux, $sortie);
        @fflush($sortie);
        if (function_exists('fsync')) {
            @fsync($sortie);
        }
        fclose($sortie);
        if ($octets === false || $octets !== $this->taille() || !@rename($part, $chemin)) {
            @unlink($part);
            throw new RuntimeException("L'archive n'a pas pu être finalisée : le disque est peut-être plein.");
        }
        return (int) $octets;
    }
}
