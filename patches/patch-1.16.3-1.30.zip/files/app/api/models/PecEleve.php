<?php
/** Calulis — Model PEC Élève (multi-année, multi-spécialités) */
require_once __DIR__ . '/../config.php';

class PecEleve {
    /**
     * Toutes les PEC d'un élève (filtrées par année si fournie).
     *
     * Décision 15.3 : une PEC qui ENJAMBE deux années apparaît dans les DEUX. On lit donc
     * aussi celles dont la période chevauche l'année demandée, et pas seulement celles qui
     * portent son identifiant : une PEC du 01/06 au 15/10 n'était visible que dans l'année
     * de sa création (constat R7 de la revue du 27/10/2026).
     */
    public static function getByEleve(int $eleveId, ?int $anneeId = null): array {
        $pdo = getDB();
        $sql = 'SELECT * FROM pec_eleves WHERE eleve_id = :eid';
        $params = ['eid' => $eleveId];
        if ($anneeId !== null) {
            $bornes = self::_bornesAnnee($anneeId);
            if ($bornes) {
                // Une PEC SANS ANNÉE n'est pas datée : l'exclure la faisait disparaître de la
                // fiche pour toujours (mesuré le 31/10/2026 : les quatre PEC de la
                // démonstration, saisies sans année, n'étaient visibles nulle part — le
                // formulaire n'envoyait pas l'année). Une ligne sans année s'affiche donc
                // dans toutes les années, comme celles dont la période chevauche.
                $sql .= ' AND (annee_scolaire_id = :aid
                          OR annee_scolaire_id IS NULL
                          OR (date_debut IS NOT NULL AND date_debut <= :fin_annee
                              AND (date_fin IS NULL OR date_fin >= :debut_annee)))';
                $params['aid'] = $anneeId;
                $params['fin_annee'] = $bornes['date_fin'];
                $params['debut_annee'] = $bornes['date_debut'];
            } else {
                $sql .= ' AND (annee_scolaire_id = :aid OR annee_scolaire_id IS NULL)';
                $params['aid'] = $anneeId;
            }
        }
        $sql .= ' ORDER BY ordre, specialite';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    public static function find(int $id): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM pec_eleves WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    public static function create(array $data): int {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $stmt = $pdo->prepare('INSERT INTO pec_eleves
            (eleve_id, annee_scolaire_id, adulte_id, date_debut, date_fin, quitte_etablissement,
             specialite, organisme, frequence, lieu, jour, heure_debut, duree, commentaires, ordre)
            VALUES (:eleve_id, :annee_scolaire_id, :adulte_id, :date_debut, :date_fin, :quitte_etablissement,
             :specialite, :organisme, :frequence, :lieu, :jour, :heure_debut, :duree, :commentaires, :ordre)');
        $stmt->execute(self::_bind($data, false));
        return (int)$pdo->lastInsertId();
    }

    public static function update(int $id, array $data): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $data['id'] = $id;
        $stmt = $pdo->prepare('UPDATE pec_eleves SET
            eleve_id=:eleve_id, annee_scolaire_id=:annee_scolaire_id,
            adulte_id=:adulte_id, date_debut=:date_debut, date_fin=:date_fin,
            quitte_etablissement=:quitte_etablissement,
            specialite=:specialite, organisme=:organisme,
            frequence=:frequence, lieu=:lieu, jour=:jour, heure_debut=:heure_debut,
            duree=:duree, commentaires=:commentaires,
            ordre=:ordre, updated_at=CURRENT_TIMESTAMP
            WHERE id=:id');
        return $stmt->execute(self::_bind($data));
    }

    public static function delete(int $id): bool {
        $pdo = getDB();
        $stmt = $pdo->prepare('DELETE FROM pec_eleves WHERE id = :id');
        return $stmt->execute(['id' => $id]);
    }

    /** Supprime toutes les PEC d'un élève (pour une année si fournie) */
    public static function deleteByEleve(int $eleveId, ?int $anneeId = null): bool {
        $pdo = getDB();
        $sql = 'DELETE FROM pec_eleves WHERE eleve_id = :eid';
        $params = ['eid' => $eleveId];
        if ($anneeId !== null) {
            $sql .= ' AND annee_scolaire_id = :aid';
            $params['aid'] = $anneeId;
        }
        $stmt = $pdo->prepare($sql);
        return $stmt->execute($params);
    }

    /** Stats PEC : comptage par spécialité + noms élèves (filtré par année) */
    public static function statsParSpecialite(?int $anneeId): array {
        $pdo = getDB();
        $sql = "SELECT p.specialite, p.organisme, COUNT(DISTINCT p.eleve_id) AS nb_eleves,
                GROUP_CONCAT(DISTINCT CONCAT(e.prenom, ' ', e.nom) ORDER BY e.nom SEPARATOR ', ') AS eleves_noms
                FROM pec_eleves p
                JOIN eleves e ON e.id = p.eleve_id
                WHERE p.specialite IS NOT NULL AND p.specialite != ''";
        $params = [];
        if ($anneeId !== null) {
            // Même règle que getByEleve : une PEC à cheval sur deux années compte dans les deux.
            $bornes = self::_bornesAnnee($anneeId);
            if ($bornes) {
                $sql .= ' AND (p.annee_scolaire_id = ?
                          OR (p.date_debut IS NOT NULL AND p.date_debut <= ?
                              AND (p.date_fin IS NULL OR p.date_fin >= ?)))';
                $params[] = $anneeId;
                $params[] = $bornes['date_fin'];
                $params[] = $bornes['date_debut'];
            } else {
                $sql .= ' AND p.annee_scolaire_id = ?';
                $params[] = $anneeId;
            }
        }
        $sql .= ' GROUP BY p.specialite, p.organisme ORDER BY nb_eleves DESC';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Les bornes de l'année scolaire demandée (null si elle n'existe pas). */
    private static function _bornesAnnee(int $anneeId): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT date_debut, date_fin FROM annees_scolaires WHERE id = :id');
        $stmt->execute(['id' => $anneeId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }

    private static function _bind(array $data, bool $includeId = true): array {
        $strFields = ['specialite', 'organisme', 'frequence', 'lieu', 'duree', 'commentaires'];
        $intFields = ['eleve_id', 'annee_scolaire_id', 'ordre', 'adulte_id', 'quitte_etablissement'];
        if ($includeId) $intFields[] = 'id';
        $params = [];
        foreach ($strFields as $f) {
            $params[$f] = isset($data[$f]) ? trim($data[$f]) : '';
        }
        $intDefaults = ['eleve_id' => 0, 'annee_scolaire_id' => null, 'ordre' => 0,
                        'adulte_id' => null, 'quitte_etablissement' => 0];
        foreach ($intFields as $f) {
            $params[$f] = isset($data[$f]) && $data[$f] !== '' && $data[$f] !== null
                ? (int)$data[$f]
                : ($intDefaults[$f] ?? null);
        }
        // Dates facultatives : une chaîne vide vaut NULL (MySQL refuse '' dans un DATE).
        foreach (['date_debut', 'date_fin'] as $champDate) {
            $v = isset($data[$champDate]) ? trim((string)$data[$champDate]) : '';
            $params[$champDate] = $v === '' ? null : substr($v, 0, 10);
            if ($params[$champDate] !== null && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $params[$champDate])) {
                throw new InvalidArgumentException('Date invalide (format attendu AAAA-MM-JJ).');
            }
        }
        // Le créneau de la PEC : une valeur vide vaut NULL (aucun lien), jamais une chaîne vide.
        // Un jour ou une heure INVENTÉS sont refusés (400) au lieu de tomber en silence sur NULL :
        // un lien mal saisi qui disparaît sans un mot laisserait la case muette sans raison visible.
        $jours = ['lundi', 'mardi', 'mercredi', 'jeudi', 'vendredi', 'samedi', 'dimanche'];
        $jour = isset($data['jour']) ? strtolower(trim((string)$data['jour'])) : '';
        if ($jour !== '' && !in_array($jour, $jours, true)) {
            throw new InvalidArgumentException('Jour du créneau invalide (lundi, mardi, mercredi, jeudi, vendredi, samedi ou dimanche).');
        }
        $params['jour'] = $jour === '' ? null : $jour;
        $heure = isset($data['heure_debut']) ? trim((string)$data['heure_debut']) : '';
        $params['heure_debut'] = null;
        if ($heure !== '') {
            if (!preg_match('/^(\d{1,2}):(\d{2})(?::\d{2})?$/', $heure, $m)
                || (int)$m[1] > 23 || (int)$m[2] > 59) {
                throw new InvalidArgumentException('Heure du créneau invalide (format attendu HH:MM, de 00:00 à 23:59).');
            }
            $params['heure_debut'] = sprintf('%02d:%s', (int)$m[1], $m[2]);
        }
        if ($includeId) $params['id'] = isset($data['id']) ? (int)$data['id'] : 0;
        return $params;
    }
}
