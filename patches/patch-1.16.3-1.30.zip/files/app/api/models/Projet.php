<?php
/**
 * Calulis — Modèle « Projets » (tables `projets`, `projet_classes`, `projet_adultes`,
 * `eleve_projets` — migration 028, lot 4 de la 1.30)
 *
 * CE QUE C'EST, ET CE QUE CE N'EST PAS
 * Ce n'est pas une fiche de projet à tenir : c'est la MÉMOIRE de ce que l'élève a fait
 * pendant sa scolarité — une chorale, une pièce de théâtre, un cross, le Printemps des
 * poètes. Le projet se décrit UNE fois (nom, type, dates, classes, adultes), puis on
 * coche qui y a participé : c'est `eleve_projets`, la seule chose que la fiche de
 * l'élève ajoute.
 *
 * L'ANNÉE N'EST PAS STOCKÉE : CE SONT LES DATES QUI DÉCIDENT
 * Comme un projet peut chevaucher deux années (mai → octobre), il n'y a pas de colonne
 * « année scolaire ». Un projet apparaît dans chaque année qu'il chevauche (voir
 * `tous()`), ce qui évite les deux pièges : le projet saisi en juillet pour la rentrée
 * qui tombe dans la mauvaise année, et le projet à cheval invisible la seconde année.
 *
 * UN PROJET SANS DATE
 * Rien n'oblige à saisir des dates, mais un projet sans date n'a pas d'année : on le
 * range alors sur l'année de sa création (COALESCE dans `tous()`), pour qu'il ne
 * disparaisse pas de la liste.
 */
require_once __DIR__ . '/../config.php';

class Projet
{
    /** Longueur maximale des champs libres, comme les autres tables de l'application. */
    private const LONG_NOM = 200;
    private const LONG_TYPE = 80;

    /**
     * Les projets d'une année, avec le nombre de classes, d'adultes et d'élèves.
     * $anneeId null = toutes les années (les plus récents d'abord).
     */
    public static function tous(?int $anneeId = null, string $recherche = ''): array
    {
        $pdo = getDB();
        $sql = 'SELECT p.*,
                       (SELECT COUNT(*) FROM projet_classes pc WHERE pc.projet_id = p.id) AS nb_classes,
                       (SELECT COUNT(*) FROM projet_adultes pa WHERE pa.projet_id = p.id) AS nb_adultes,
                       (SELECT COUNT(*) FROM eleve_projets ep WHERE ep.projet_id = p.id) AS nb_eleves,
                       ev.nom AS evenement_nom,
                       (SELECT GROUP_CONCAT(c.nom ORDER BY c.nom SEPARATOR \' · \') FROM projet_classes pc
                          JOIN classes c ON c.id = pc.classe_id WHERE pc.projet_id = p.id) AS classes_noms
                  FROM projets p
                  LEFT JOIN evenements ev ON ev.id = p.evenement_id';
        $params = [];
        $conditions = [];
        if ($anneeId !== null && $anneeId > 0) {
            $annee = self::bornesAnnee($anneeId);
            if ($annee !== null) {
                $conditions[] = 'COALESCE(p.date_debut, p.date_fin, DATE(p.created_at)) <= :annee_fin';
                $conditions[] = 'COALESCE(p.date_fin, p.date_debut, DATE(p.created_at)) >= :annee_debut';
                $params['annee_fin'] = $annee['date_fin'];
                $params['annee_debut'] = $annee['date_debut'];
            }
        }
        $recherche = trim($recherche);
        if ($recherche !== '') {
            $conditions[] = '(p.nom LIKE :q OR p.type LIKE :q OR p.description LIKE :q)';
            $params['q'] = '%' . $recherche . '%';
        }
        if ($conditions) {
            $sql .= ' WHERE ' . implode(' AND ', $conditions);
        }
        $sql .= ' ORDER BY COALESCE(p.date_debut, p.date_fin, DATE(p.created_at)) DESC, p.nom';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll();
    }

    /** Un projet et ses liens, ou null. */
    public static function find(int $id): ?array
    {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM projets WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $projet = $stmt->fetch();
        if (!$projet) {
            return null;
        }
        $projet['classes'] = self::liens($pdo, 'projet_classes', 'classe_id', 'classes', 'nom', $id);
        $projet['adultes'] = self::adultes($pdo, $id);
        $projet['eleves'] = self::eleves($pdo, $id);
        $projet['evenement_nom'] = null;
        if (!empty($projet['evenement_id'])) {
            $stmt = $pdo->prepare('SELECT nom FROM evenements WHERE id = :id');
            $stmt->execute(['id' => (int)$projet['evenement_id']]);
            $nom = $stmt->fetchColumn();
            $projet['evenement_nom'] = $nom === false ? null : (string)$nom;
        }
        return $projet;
    }

    /** Les types déjà saisis (autocomplétion de la saisie : on retape les mêmes noms). */
    public static function types(?string $recherche = null): array
    {
        $pdo = getDB();
        $sql = 'SELECT DISTINCT type FROM projets WHERE type IS NOT NULL AND TRIM(type) <> \'\'';
        $params = [];
        if ($recherche !== null && trim($recherche) !== '') {
            $sql .= ' AND type LIKE :q';
            $params['q'] = '%' . trim($recherche) . '%';
        }
        $sql .= ' ORDER BY type';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        return array_map('strval', $stmt->fetchAll(PDO::FETCH_COLUMN));
    }

    /** Les projets rattachés à un événement (lecture seule, sur l'écran de l'événement). */
    public static function parEvenement(int $evenementId): array
    {
        $stmt = getDB()->prepare(
            'SELECT id, nom, type, date_debut, date_fin FROM projets
              WHERE evenement_id = :id
              ORDER BY COALESCE(date_debut, date_fin) DESC, nom'
        );
        $stmt->execute(['id' => $evenementId]);
        return $stmt->fetchAll();
    }

    /**
     * Crée un projet et ses liens. Le nom est obligatoire ; les dates sont facultatives
     * mais doivent être cohérentes (fin après début), sinon la fiche mentirait.
     */
    public static function creer(array $data): int
    {
        $champs = self::champs($data);
        $pdo = getDB();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare(
                'INSERT INTO projets (nom, type, date_debut, date_fin, description, est_obligatoire, evenement_id)
                 VALUES (:nom, :type, :date_debut, :date_fin, :description, :est_obligatoire, :evenement_id)'
            );
            $stmt->execute($champs);
            $id = (int)$pdo->lastInsertId();
            self::ecrireLiens($pdo, $id, $data);
            $pdo->commit();
            return $id;
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    /** Met à jour la fiche et REMPLACE ses liens (l'écran envoie toujours la liste complète). */
    public static function modifier(int $id, array $data): bool
    {
        $existant = self::find($id);
        if ($existant === null) {
            return false;
        }
        // Les champs absents du corps gardent leur valeur actuelle (l'écran envoie tout,
        // mais un appel partiel ne doit pas effacer une description par omission).
        $champs = self::champs(array_merge($existant, $data));
        $champs['id'] = $id;
        $pdo = getDB();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare(
                'UPDATE projets SET nom = :nom, type = :type, date_debut = :date_debut,
                        date_fin = :date_fin, description = :description,
                        est_obligatoire = :est_obligatoire, evenement_id = :evenement_id
                  WHERE id = :id'
            );
            $stmt->execute($champs);
            $pdo->prepare('DELETE FROM projet_classes WHERE projet_id = :id')->execute(['id' => $id]);
            $pdo->prepare('DELETE FROM projet_adultes WHERE projet_id = :id')->execute(['id' => $id]);
            self::ecrireLiens($pdo, $id, $data);
            $pdo->commit();
            return true;
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    /** Supprime le projet : ses liens et les participations partent avec lui (cascade). */
    public static function supprimer(int $id): bool
    {
        $stmt = getDB()->prepare('DELETE FROM projets WHERE id = :id');
        $stmt->execute(['id' => $id]);
        return $stmt->rowCount() > 0;
    }

    // ── Participation ────────────────────────────────────────────────────────

    /** Les projets auxquels un élève a participé (pour sa fiche). */
    public static function parEleve(int $eleveId): array
    {
        $stmt = getDB()->prepare(
            'SELECT p.*,
                    (SELECT GROUP_CONCAT(c.nom ORDER BY c.nom SEPARATOR \' · \') FROM projet_classes pc
                       JOIN classes c ON c.id = pc.classe_id WHERE pc.projet_id = p.id) AS classes_noms,
                    ev.nom AS evenement_nom
               FROM projets p
               JOIN eleve_projets ep ON ep.projet_id = p.id
               LEFT JOIN evenements ev ON ev.id = p.evenement_id
              WHERE ep.eleve_id = :eleve
              ORDER BY COALESCE(p.date_debut, p.date_fin, DATE(p.created_at)) DESC, p.nom'
        );
        $stmt->execute(['eleve' => $eleveId]);
        return $stmt->fetchAll();
    }

    /** Inscrit une participation. Rejouable : réinscrire ne crée pas de doublon. */
    public static function participer(int $eleveId, int $projetId): bool
    {
        $pdo = getDB();
        $verif = $pdo->prepare('SELECT COUNT(*) FROM eleves WHERE id = :id');
        $verif->execute(['id' => $eleveId]);
        if ((int)$verif->fetchColumn() === 0) {
            throw new InvalidArgumentException('Élève introuvable.');
        }
        if (self::find($projetId) === null) {
            throw new InvalidArgumentException('Projet introuvable.');
        }
        $stmt = $pdo->prepare('INSERT IGNORE INTO eleve_projets (eleve_id, projet_id) VALUES (:e, :p)');
        return $stmt->execute(['e' => $eleveId, 'p' => $projetId]);
    }

    public static function retirer(int $eleveId, int $projetId): bool
    {
        $stmt = getDB()->prepare('DELETE FROM eleve_projets WHERE eleve_id = :e AND projet_id = :p');
        $stmt->execute(['e' => $eleveId, 'p' => $projetId]);
        return $stmt->rowCount() > 0;
    }

    // ── Interne ──────────────────────────────────────────────────────────────

    /** Nettoie et valide les champs d'un projet (les identifiants de liens sont traités à part). */
    private static function champs(array $data): array
    {
        $nom = trim((string)($data['nom'] ?? ''));
        if ($nom === '') {
            throw new InvalidArgumentException('Donnez un nom au projet.');
        }
        $type = trim((string)($data['type'] ?? ''));
        $debut = self::dateOuNull($data['date_debut'] ?? null);
        $fin = self::dateOuNull($data['date_fin'] ?? null);
        if ($debut !== null && $fin !== null && $fin < $debut) {
            throw new InvalidArgumentException('La date de fin ne peut pas précéder la date de début.');
        }
        $evenementId = null;
        if (!empty($data['evenement_id'])) {
            $verif = getDB()->prepare('SELECT COUNT(*) FROM evenements WHERE id = :id');
            $verif->execute(['id' => (int)$data['evenement_id']]);
            $evenementId = (int)$verif->fetchColumn() > 0 ? (int)$data['evenement_id'] : null;
        }
        return [
            'nom'            => calulis_substr($nom, self::LONG_NOM),
            'type'           => $type === '' ? null : calulis_substr($type, self::LONG_TYPE),
            'date_debut'     => $debut,
            'date_fin'       => $fin,
            'description'    => trim((string)($data['description'] ?? '')) === ''
                ? null : (string)$data['description'],
            'est_obligatoire'=> !empty($data['est_obligatoire']) ? 1 : 0,
            'evenement_id'   => $evenementId,
        ];
    }

    private static function dateOuNull($valeur): ?string
    {
        $valeur = trim((string)($valeur ?? ''));
        if ($valeur === '') {
            return null;
        }
        $d = DateTime::createFromFormat('Y-m-d', $valeur);
        if (!$d || $d->format('Y-m-d') !== $valeur) {
            throw new InvalidArgumentException('Date invalide : ' . $valeur . ' (attendu AAAA-MM-JJ).');
        }
        return $valeur;
    }

    /** Écrit les liens classes / adultes / participations (ids inconnus ignorés, pas d'erreur 500). */
    private static function ecrireLiens(PDO $pdo, int $projetId, array $data): void
    {
        $classes = self::idsExistants($pdo, 'classes', $data['classes'] ?? $data['classe_ids'] ?? []);
        $stmt = $pdo->prepare('INSERT IGNORE INTO projet_classes (projet_id, classe_id) VALUES (:p, :c)');
        foreach ($classes as $classeId) {
            $stmt->execute(['p' => $projetId, 'c' => $classeId]);
        }
        $adultes = self::idsExistants($pdo, 'adultes', $data['adultes'] ?? $data['adulte_ids'] ?? []);
        $stmt = $pdo->prepare('INSERT IGNORE INTO projet_adultes (projet_id, adulte_id) VALUES (:p, :a)');
        foreach ($adultes as $adulteId) {
            $stmt->execute(['p' => $projetId, 'a' => $adulteId]);
        }
        $eleves = self::idsExistants($pdo, 'eleves', $data['eleves'] ?? $data['eleve_ids'] ?? []);
        $stmt = $pdo->prepare('INSERT IGNORE INTO eleve_projets (eleve_id, projet_id) VALUES (:e, :p)');
        foreach ($eleves as $eleveId) {
            $stmt->execute(['e' => $eleveId, 'p' => $projetId]);
        }
    }

    /** Ne garde que les identifiants qui existent vraiment (une liste périmée ne casse rien). */
    private static function idsExistants(PDO $pdo, string $table, $ids): array
    {
        $propres = [];
        foreach ((array)$ids as $id) {
            $id = (int)$id;
            if ($id > 0) {
                $propres[$id] = $id;
            }
        }
        if (!$propres) {
            return [];
        }
        $marques = implode(',', array_fill(0, count($propres), '?'));
        $stmt = $pdo->prepare('SELECT id FROM ' . $table . ' WHERE id IN (' . $marques . ')');
        $stmt->execute(array_values($propres));
        return array_map('intval', $stmt->fetchAll(PDO::FETCH_COLUMN));
    }

    /** Les identifiants liés à un projet, avec leur nom (classes). */
    private static function liens(PDO $pdo, string $table, string $colonne, string $cible, string $champNom, int $projetId): array
    {
        $stmt = $pdo->prepare(
            'SELECT t.id, t.' . $champNom . ' AS nom FROM ' . $table . ' l
               JOIN ' . $cible . ' t ON t.id = l.' . $colonne . '
              WHERE l.projet_id = :id ORDER BY t.' . $champNom
        );
        $stmt->execute(['id' => $projetId]);
        return $stmt->fetchAll();
    }

    /** Les adultes d'un projet (nom, prénom, rôle sur le projet). */
    private static function adultes(PDO $pdo, int $projetId): array
    {
        $stmt = $pdo->prepare(
            'SELECT a.id, a.nom, a.prenom, pa.role
               FROM projet_adultes pa JOIN adultes a ON a.id = pa.adulte_id
              WHERE pa.projet_id = :id ORDER BY a.nom, a.prenom'
        );
        $stmt->execute(['id' => $projetId]);
        return $stmt->fetchAll();
    }

    /** Les élèves participants (nom, prénom, classe de référence si elle est connue). */
    private static function eleves(PDO $pdo, int $projetId): array
    {
        $stmt = $pdo->prepare(
            'SELECT e.id, e.nom, e.prenom
               FROM eleve_projets ep JOIN eleves e ON e.id = ep.eleve_id
              WHERE ep.projet_id = :id ORDER BY e.nom, e.prenom'
        );
        $stmt->execute(['id' => $projetId]);
        return $stmt->fetchAll();
    }

    /** Les bornes d'une année scolaire, ou null si elle n'existe pas. */
    private static function bornesAnnee(int $anneeId): ?array
    {
        $stmt = getDB()->prepare('SELECT date_debut, date_fin FROM annees_scolaires WHERE id = :id');
        $stmt->execute(['id' => $anneeId]);
        $row = $stmt->fetch();
        return $row ?: null;
    }
}
