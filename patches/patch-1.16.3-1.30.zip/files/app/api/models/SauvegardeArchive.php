<?php
/**
 * Calulis — L'archive unique : la base ET les documents, dans un seul fichier (lot 7).
 *
 * POURQUOI CE FICHIER
 * Jusqu'au 31/10/2026 une sauvegarde ne contenait QUE la base (`.sql`). Les documents
 * rapatriés vivaient dans `runtime/documents/`, et **aucune** sauvegarde ne les
 * emportait : restaurer une base laissait des lignes pointant vers des fichiers
 * disparus, ou des fichiers que plus rien ne nommait. La décision de Jérôme
 * (31/10/2026) est une **seule archive** : base + tous les documents.
 *
 * CE QU'ELLE CONTIENT
 *   manifeste.json   ce que l'archive porte (format, date, tables, documents)
 *   base.sql         le dump complet, terminé par le marqueur de fin de Sauvegarde
 *   documents/...    l'arborescence de `runtime/documents`, telle quelle
 *
 * OÙ ELLE VIT
 * `<racine>/runtime/backups/archives/<horodatage>/<motif>.zip` — à côté des dumps
 * `runtime/backups/db/`, dans le dossier que les mises à jour ne remplacent pas.
 * `CALULIS_ARCHIVE_DIR` déplace la racine (les tests écrivent dans un dossier jetable).
 *
 * CE QU'ELLE NE FAIT PAS
 * Elle ne restaure rien : c'est `Restauration.php`. Ici, seulement l'écriture, la
 * liste et l'analyse d'une archive — sans jamais rien supprimer.
 */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/Archive.php';
require_once __DIR__ . '/Sauvegarde.php';
require_once __DIR__ . '/Stockage.php';

class SauvegardeArchive
{
    /** Version du format d'archive. Une archive d'un format inconnu n'est pas restaurée. */
    public const FORMAT = 1;

    public const MANIFESTE = 'manifeste.json';
    public const BASE = 'base.sql';
    public const DOSSIER_DOCUMENTS = 'documents/';

    /** Dossier des archives, surchargeable par CALULIS_ARCHIVE_DIR (tests). */
    public static function dossierArchives(): string
    {
        $force = getenv('CALULIS_ARCHIVE_DIR');
        if ($force !== false && $force !== '') {
            return rtrim($force, '/\\');
        }
        return Sauvegarde::racine() . '/runtime/backups/archives';
    }

    /** Dossier des documents (même source que le module Documents). */
    public static function dossierDocuments(): string
    {
        return Stockage::racine();
    }

    /**
     * Fabrique une archive complète : manifeste, dump de la base, puis chaque
     * document du disque. Rien n'est supprimé, rien n'est déplacé.
     *
     * @param string $motif nom court, sans accent ni espace (« sauvegarde », « avant-restauration »)
     * @return array{chemin:string,octets:int,tables:int,lignes:int,documents:int}
     * @throws RuntimeException si le dump ou l'archive n'ont pas pu être écrits
     */
    public static function creer(PDO $pdo, string $motif = 'sauvegarde'): array
    {
        $motif = strtolower(preg_replace('/[^a-z0-9]+/i', '-', $motif) ?? 'sauvegarde');
        $motif = trim($motif, '-') ?: 'sauvegarde';

        $dossier = self::dossierArchives() . '/' . date('Y-m-d_H-i-s');
        if (!is_dir($dossier) && !@mkdir($dossier, 0777, true) && !is_dir($dossier)) {
            throw new RuntimeException("Impossible de créer le dossier des archives.");
        }
        $chemin = $dossier . '/' . $motif . '.zip';
        for ($i = 2; is_file($chemin) && $i < 100; $i++) {
            $chemin = $dossier . '/' . $motif . '-' . $i . '.zip';
        }

        // Le dump de la base passe par un fichier temporaire : une base de 50 Mo ne
        // doit pas tenir en mémoire simplement pour entrer dans l'archive.
        $temporaire = (string) tempnam(sys_get_temp_dir(), 'calulis-base-');
        try {
            $base = Sauvegarde::ecrireDans($pdo, $temporaire);
            $documents = self::fichiers(self::dossierDocuments());

            $archive = new Archive();
            $archive->reserverNom(self::MANIFESTE);
            $archive->ajouterFichier(self::BASE, $temporaire);
            foreach ($documents as $relatif => $absolu) {
                $archive->ajouterFichier(self::DOSSIER_DOCUMENTS . $relatif, $absolu, true);
            }
            $manifeste = [
                'format'      => self::FORMAT,
                'application' => 'Calulis',
                'date'        => date('c'),
                'motif'       => $motif,
                'base'        => [
                    'fichier' => self::BASE,
                    'tables'  => $base['tables'],
                    'lignes'  => $base['lignes'],
                    'octets'  => $base['octets'],
                ],
                'documents'   => [
                    'dossier' => self::DOSSIER_DOCUMENTS,
                    'nombre'  => count($documents),
                ],
            ];
            $archive->ajouterIndex(
                self::MANIFESTE,
                json_encode($manifeste, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n"
            );
            $octets = $archive->ecrireVers($chemin);
        } finally {
            @unlink($temporaire);
        }

        return [
            'chemin'    => $chemin,
            'octets'    => $octets,
            'tables'    => (int) $base['tables'],
            'lignes'    => (int) $base['lignes'],
            'documents' => count($documents),
        ];
    }

    /**
     * Tous les fichiers d'un dossier, en récursif : chemin relatif (barres obliques)
     * => chemin absolu. Les liens symboliques sont ignorés (une archive ne doit pas
     * pouvoir sortir du dossier qu'elle sauvegarde).
     *
     * @return array<string,string>
     */
    public static function fichiers(string $racine): array
    {
        $racine = rtrim($racine, '/\\');
        if ($racine === '' || !is_dir($racine)) {
            return [];
        }
        $trouves = [];
        $parcours = new RecursiveIteratorIterator(
            new RecursiveDirectoryIterator($racine, FilesystemIterator::SKIP_DOTS),
            RecursiveIteratorIterator::LEAVES_ONLY
        );
        foreach ($parcours as $fichier) {
            /** @var SplFileInfo $fichier */
            if (!$fichier->isFile() || $fichier->isLink()) {
                continue;
            }
            $absolu = str_replace('\\', '/', $fichier->getPathname());
            $prefixe = str_replace('\\', '/', $racine) . '/';
            if (!str_starts_with($absolu, $prefixe)) {
                continue;
            }
            $trouves[substr($absolu, strlen($prefixe))] = $fichier->getPathname();
        }
        ksort($trouves);
        return $trouves;
    }

    /** Les archives présentes sur le disque, la plus récente d'abord. */
    public static function lister(): array
    {
        $dossier = self::dossierArchives();
        if (!is_dir($dossier)) {
            return [];
        }
        $liste = [];
        foreach (glob($dossier . '/*/*.zip') ?: [] as $chemin) {
            $liste[] = [
                'nom'    => basename($chemin),
                'dossier' => basename(dirname($chemin)),
                'octets' => (int) (@filesize($chemin) ?: 0),
                'chemin' => $chemin,
            ];
        }
        usort($liste, static fn($a, $b) => strcmp($b['dossier'], $a['dossier']) ?: strcmp($a['nom'], $b['nom']));
        return $liste;
    }

    /**
     * Lit une archive SANS RIEN MODIFIER, et dit ce qu'elle porte.
     *
     * @return array{format:int,date:string,motif:string,tables:int,lignes:int,documents:int,octets:int,entrees:int,base:bool}
     * @throws RuntimeException si l'archive n'est pas lisible, pas du bon format, ou
     *         si sa base est incomplète — l'appelant ne restaure alors rien.
     */
    public static function analyser(string $chemin): array
    {
        if (!is_file($chemin)) {
            throw new RuntimeException("Cette archive est introuvable.");
        }
        $entrees = Archive::entrees($chemin);
        if (!isset($entrees[self::MANIFESTE])) {
            throw new RuntimeException("Ce fichier n'est pas une archive Calulis : son manifeste manque.");
        }
        if (!isset($entrees[self::BASE])) {
            throw new RuntimeException("Cette archive ne contient pas sa base (base.sql) : rien à restaurer.");
        }

        $json = '';
        $temporaire = (string) tempnam(sys_get_temp_dir(), 'calulis-manifeste-');
        try {
            Archive::extraire($chemin, self::MANIFESTE, $temporaire);
            $json = (string) @file_get_contents($temporaire);
        } finally {
            @unlink($temporaire);
        }
        $manifeste = json_decode($json, true);
        if (!is_array($manifeste)) {
            throw new RuntimeException("Le manifeste de cette archive est illisible.");
        }
        if ((int) ($manifeste['format'] ?? 0) !== self::FORMAT) {
            throw new RuntimeException(
                "Cette archive est au format " . (int) ($manifeste['format'] ?? 0)
                . ", que cette version de Calulis ne sait pas restaurer (format attendu : " . self::FORMAT . ")."
            );
        }

        $documents = 0;
        foreach (array_keys($entrees) as $nom) {
            if (str_starts_with($nom, self::DOSSIER_DOCUMENTS) && !str_ends_with($nom, '/')) {
                $documents++;
            }
        }

        return [
            'format'    => (int) $manifeste['format'],
            'date'      => (string) ($manifeste['date'] ?? ''),
            'motif'     => (string) ($manifeste['motif'] ?? ''),
            'tables'    => (int) ($manifeste['base']['tables'] ?? 0),
            'lignes'    => (int) ($manifeste['base']['lignes'] ?? 0),
            'documents' => $documents,
            'octets'    => (int) (@filesize($chemin) ?: 0),
            'entrees'   => count($entrees),
            'base'      => true,
        ];
    }
}
