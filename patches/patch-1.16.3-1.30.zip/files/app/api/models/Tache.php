<?php
/** Calulis — Modèle « Tâches »
 *
 *  Une tâche est une chose à faire, avec une échéance. Elle peut être liée à un élève
 *  (`eleve_id`) et/ou à un adulte (`adulte_id`) — les deux sont facultatifs : les tâches
 *  générales (« commander du matériel ») ont leur place.
 *
 *  Convention arrêtée le 04/10/2026 : il n'y a PAS de colonne « titre ». La PREMIÈRE LIGNE
 *  de `description` fait office de titre, le reste est le détail. La composition et la
 *  lecture se font ici, pour que tous les appelants partagent la même règle.
 *
 *  Statuts : a_faire, plus_tard, en_cours, fait, annule.
 *  Monoposte : pas de responsable d'exécution ; `precision_libre` est un champ libre court.
 */

require_once __DIR__ . '/../config.php';

class Tache {

    public const STATUTS   = ['a_faire', 'plus_tard', 'en_cours', 'fait', 'annule'];

    /** Statuts qui FERMENT une tâche : ils posent la date de clôture (décision 7.2). */
    public const STATUTS_FERMES = ['fait', 'annule'];

    /**
     * Récurrences admises (décision 7.3) : par jour, par semaine, en fin de période, en fin
     * d'année, en début d'année. Une occurrence est une VRAIE tâche : elle n'est jamais
     * effacée parce qu'une autre est arrivée (décision 7.4).
     */
    public const RECURRENCES = ['jour', 'semaine', 'fin_periode', 'fin_annee', 'debut_annee'];
    public const PRIORITES = ['haute', 'moyenne', 'basse'];
    public const COULEURS  = ['jaune', 'vert', 'bleu', 'rose', 'violet', 'orange'];

    private static function pdo(): PDO {
        return getDB();
    }

    /* ------------------------------------------------------------------ */
    /* Convention titre / détail (première ligne = titre)                  */
    /* ------------------------------------------------------------------ */

    /** Compose la description stockée à partir du titre et du détail */
    public static function composer(string $titre, string $detail = ''): string {
        $titre = trim($titre);
        $detail = trim($detail);
        return $detail === '' ? $titre : $titre . "\n" . $detail;
    }

    /** Première ligne = titre */
    public static function titre(string $description): string {
        $lignes = preg_split('/\R/', trim($description));
        return $lignes[0] ?? '';
    }

    /** Le reste = détail */
    public static function detail(string $description): string {
        $lignes = preg_split('/\R/', trim($description));
        array_shift($lignes);
        return trim(implode("\n", $lignes));
    }

    /* ------------------------------------------------------------------ */
    /* Lecture                                                             */
    /* ------------------------------------------------------------------ */

    /**
     * Liste des tâches, filtrée.
     * @param int|null $anneeId Année scolaire active
     * @param array $filtres statut, eleve_id, adulte_id, du, au, a_venir
     */
    public static function all(?int $anneeId, array $filtres = []): array {
        $sql = "SELECT t.id, t.annee_scolaire_id, t.description, t.eleve_id, t.adulte_id, t.reunion_id,
                       t.date_creation, t.echeance, t.date_cloture, t.priorite, t.statut, t.couleur, t.precision_libre, t.notes,
                       t.recurrence, t.serie_id,
                       e.nom AS eleve_nom, e.prenom AS eleve_prenom,
                       a.nom AS adulte_nom, a.prenom AS adulte_prenom, a.civilite AS adulte_civilite
                  FROM taches t
             LEFT JOIN eleves  e ON e.id = t.eleve_id
             LEFT JOIN adultes a ON a.id = t.adulte_id
                 WHERE 1 = 1";
        $params = [];

        if ($anneeId) {
            // Décision 7.2 : une tâche FERMÉE se lit dans l'année de sa création ET dans
            // celle de sa fermeture. Sans cette seconde branche, fermer en septembre une
            // tâche née en juin la ferait disparaître de l'année en cours.
            $bornes = self::anneeBornes($anneeId);
            if ($bornes) {
                $sql .= " AND (t.annee_scolaire_id = :annee_id
                                OR (t.date_cloture IS NOT NULL
                                    AND t.date_cloture BETWEEN :annee_debut AND :annee_fin))";
                $params['annee_id'] = $anneeId;
                $params['annee_debut'] = $bornes['date_debut'];
                $params['annee_fin'] = $bornes['date_fin'];
            } else {
                $sql .= " AND t.annee_scolaire_id = :annee_id";
                $params['annee_id'] = $anneeId;
            }
        }
        if (!empty($filtres['statut']) && in_array($filtres['statut'], self::STATUTS, true)) {
            $sql .= " AND t.statut = :statut";
            $params['statut'] = $filtres['statut'];
        }
        if (!empty($filtres['eleve_id'])) {
            $sql .= " AND t.eleve_id = :eleve_id";
            $params['eleve_id'] = (int)$filtres['eleve_id'];
        }
        if (!empty($filtres['adulte_id'])) {
            $sql .= " AND t.adulte_id = :adulte_id";
            $params['adulte_id'] = (int)$filtres['adulte_id'];
        }
        if (!empty($filtres['du'])) {
            $sql .= " AND t.echeance >= :du";
            $params['du'] = $filtres['du'];
        }
        if (!empty($filtres['au'])) {
            $sql .= " AND t.echeance <= :au";
            $params['au'] = $filtres['au'];
        }
        if (!empty($filtres['a_venir'])) {
            $sql .= " AND t.statut IN ('a_faire', 'plus_tard', 'en_cours')";
        }

        // Par échéance croissante ; les tâches sans échéance à la fin
        $sql .= " ORDER BY (t.echeance IS NULL), t.echeance ASC, t.id DESC";

        $stmt = self::pdo()->prepare($sql);
        $stmt->execute($params);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public static function find(int $id): ?array {
        $stmt = self::pdo()->prepare(
            "SELECT t.id, t.annee_scolaire_id, t.description, t.eleve_id, t.adulte_id, t.reunion_id,
                    t.date_creation, t.echeance, t.date_cloture, t.priorite, t.statut, t.couleur, t.precision_libre, t.notes,
                       t.recurrence, t.serie_id,
                    e.nom AS eleve_nom, e.prenom AS eleve_prenom,
                    a.nom AS adulte_nom, a.prenom AS adulte_prenom, a.civilite AS adulte_civilite
               FROM taches t
          LEFT JOIN eleves  e ON e.id = t.eleve_id
          LEFT JOIN adultes a ON a.id = t.adulte_id
              WHERE t.id = :id"
        );
        $stmt->execute(['id' => $id]);
        $t = $stmt->fetch(PDO::FETCH_ASSOC);
        return $t ?: null;
    }

    /* ------------------------------------------------------------------ */
    /* Écriture                                                            */
    /* ------------------------------------------------------------------ */

    public static function create(array $data, ?int $anneeId): int {
        $propre = self::_valider($data, true);

        // Une tâche récurrente a besoin d'une PREMIÈRE échéance : sans elle, aucune
        // occurrence ne pourrait être calculée. On la déduit de la récurrence, jamais au
        // hasard — et on refuse si le calendrier ne permet pas de la calculer.
        if (!empty($propre['recurrence']) && empty($propre['echeance'])) {
            $premiere = self::prochaineEcheance((string)$propre['recurrence'], calulis_aujourdhui());
            if ($premiere === null) {
                throw new InvalidArgumentException(
                    'Aucune période ni année scolaire ne permet de calculer la première '
                    . 'échéance de cette récurrence : enregistrez d\'abord le calendrier.'
                );
            }
            $propre['echeance'] = $premiere;
        }

        // Une tâche créée DÉJÀ fermée porte sa date de clôture : sans elle, elle
        // n'apparaîtrait dans aucune année par sa fermeture (décision 7.2).
        $cloture = in_array($propre['statut'], self::STATUTS_FERMES, true) ? calulis_aujourdhui() : null;

        $stmt = self::pdo()->prepare(
            "INSERT INTO taches (annee_scolaire_id, description, eleve_id, adulte_id, date_creation,
                                 echeance, date_cloture, priorite, statut, couleur, precision_libre, notes,
                                 recurrence, serie_id)
             VALUES (:annee_id, :description, :eleve_id, :adulte_id, :date_creation,
                     :echeance, :date_cloture, :priorite, :statut, :couleur, :precision_libre, :notes,
                     :recurrence, :serie_id)"
        );
        $stmt->execute([
            'annee_id'        => $anneeId,
            'description'     => $propre['description'],
            'eleve_id'        => $propre['eleve_id'],
            'adulte_id'       => $propre['adulte_id'],
            'date_creation'   => $propre['date_creation'],
            'echeance'        => $propre['echeance'],
            'date_cloture'    => $cloture,
            'priorite'        => $propre['priorite'],
            'statut'          => $propre['statut'],
            'couleur'         => $propre['couleur'],
            'precision_libre' => $propre['precision_libre'],
            'notes'           => $propre['notes'],
            'recurrence'      => $propre['recurrence'] ?? null,
            'serie_id'        => null,
        ]);
        $id = (int)self::pdo()->lastInsertId();
        if (!empty($propre['recurrence'])) {
            // L'occurrence d'origine EST la série : les suivantes s'y rattachent.
            // Ne JAMAIS réutiliser un paramètre nommé (PDO natif refuse ":id" deux fois).
            $stmt = self::pdo()->prepare("UPDATE taches SET serie_id = id WHERE id = :id");
            $stmt->execute(['id' => $id]);
        }
        return $id;
    }

    public static function update(int $id, array $data): bool {
        $propre = self::_valider($data, false);
        $existant = self::find($id);
        if (!$existant) {
            return false;
        }
        // La date de clôture suit le STATUT, jamais la main de l'utilisateur :
        //   • on ferme (fait / annule) → la date du jour est écrite si elle manque ;
        //   • on rouvre → elle est effacée (une tâche ouverte n'a pas de fermeture).
        // Une tâche déjà fermée sans date (antérieure à la migration 019) en reçoit une
        // à la première modification de son statut, jamais une date fabriquée à la reprise.
        $fermeeAvant = in_array((string)$existant['statut'], self::STATUTS_FERMES, true);
        $fermeeApres = in_array((string)($propre['statut'] ?? $existant['statut']), self::STATUTS_FERMES, true);
        if ($fermeeApres && !$fermeeAvant) {
            $propre['date_cloture'] = calulis_aujourdhui();
        } elseif (!$fermeeApres && $fermeeAvant) {
            $propre['date_cloture'] = null;
        }

        // La récurrence est une règle de SÉRIE : la changer depuis une occurrence la change
        // pour toutes, sinon la même tâche se répéterait à deux rythmes différents.
        if (array_key_exists('recurrence', $propre) && !empty($existant['serie_id'])) {
            $stmt = self::pdo()->prepare("UPDATE taches SET recurrence = :r WHERE serie_id = :serie");
            $stmt->execute(['r' => $propre['recurrence'], 'serie' => (int)$existant['serie_id']]);
        }
        // Une tâche qui devient récurrente entre dans sa propre série.
        if (!empty($propre['recurrence']) && empty($existant['serie_id'])) {
            $propre['serie_id'] = $id;
        }
        if (!$propre) {
            return false;
        }
        $sets = [];
        $params = ['id' => $id];
        foreach ($propre as $colonne => $valeur) {
            $sets[] = "$colonne = :$colonne";
            $params[$colonne] = $valeur;
        }
        $stmt = self::pdo()->prepare("UPDATE taches SET " . implode(', ', $sets) . " WHERE id = :id");
        $stmt->execute($params);
        return $stmt->rowCount() >= 0;
    }

    /**
     * Supprime une tâche, en distinguant DEUX gestes quand elle appartient à une série (R12) :
     *
     *   • `jour` (défaut) — « pas cette fois » : la date est notée dans
     *     taches_occurrences_supprimees, donc la génération ne la recrée plus, et les autres
     *     dates de la série continuent leur vie.
     *   • `serie` — « arrêter la récurrence » : les occurrences À VENIR de la série
     *     disparaissent, la série perd sa règle (recurrence = NULL) et ne se régénère plus.
     *     Les occurrences passées restent : c'est l'histoire, on ne la réécrit pas.
     */
    public static function delete(int $id, string $portee = 'jour'): bool {
        $tache = self::find($id);
        if (!$tache) {
            return false;
        }
        $serieId = $tache['serie_id'] !== null ? (int)$tache['serie_id'] : 0;
        $enSerie = $serieId > 0 && !empty($tache['recurrence']);
        $pdo = self::pdo();
        $pdo->beginTransaction();
        try {
            if ($enSerie && $portee === 'serie') {
                $stmt = $pdo->prepare("DELETE FROM taches WHERE serie_id = :serie AND echeance > :auj AND id <> :id");
                $stmt->execute(['serie' => $serieId, 'auj' => calulis_aujourdhui(), 'id' => $id]);
                $stmt = $pdo->prepare("DELETE FROM taches WHERE id = :id");
                $stmt->execute(['id' => $id]);
                $stmt = $pdo->prepare("UPDATE taches SET recurrence = NULL WHERE serie_id = :serie");
                $stmt->execute(['serie' => $serieId]);
            } else {
                // « Ce jour seulement » sur la DERNIÈRE ligne d'une série : la supprimer
                // effacerait la série elle-même, puisque la génération repart de la dernière
                // échéance qu'elle connaît — la tâche récurrente disparaissait donc pour de
                // bon (revue du 30/10/2026). La ligne AVANCE à la date suivante : la série
                // continue, la date sautée reste notée et ne sera pas recréée.
                $suivante = null;
                if ($enSerie && $tache['echeance'] !== null) {
                    $stmt = $pdo->prepare("SELECT COUNT(*) FROM taches WHERE serie_id = :serie");
                    $stmt->execute(['serie' => $serieId]);
                    if ((int)$stmt->fetchColumn() <= 1) {
                        $suivante = self::prochaineEcheance((string)$tache['recurrence'], (string)$tache['echeance']);
                    }
                    $stmt = $pdo->prepare(
                        "INSERT INTO taches_occurrences_supprimees (serie_id, echeance) VALUES (:serie, :ech)\n" .
                        "ON DUPLICATE KEY UPDATE supprime_le = CURRENT_TIMESTAMP"
                    );
                    $stmt->execute(['serie' => $serieId, 'ech' => $tache['echeance']]);
                }
                if ($suivante !== null) {
                    $stmt = $pdo->prepare(
                        "UPDATE taches SET echeance = :ech, annee_scolaire_id = :annee,
                                           statut = 'a_faire', date_cloture = NULL
                          WHERE id = :id"
                    );
                    $stmt->execute(['ech' => $suivante, 'annee' => self::anneeDeDate($suivante), 'id' => $id]);
                } else {
                    $stmt = $pdo->prepare("DELETE FROM taches WHERE id = :id");
                    $stmt->execute(['id' => $id]);
                }
            }
            $pdo->commit();
            return true;
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    /* ------------------------------------------------------------------ */
    /* Récurrences (décisions 7.3 et 7.4)                                  */
    /* ------------------------------------------------------------------ */

    /**
     * La première occurrence d'une récurrence STRICTEMENT APRÈS une date.
     * Rend null quand le calendrier ne permet pas de la calculer (aucune période, aucune
     * année) : on ne devine jamais une date.
     */
    public static function prochaineEcheance(string $recurrence, string $depuis): ?string {
        $depart = date_create_immutable($depuis);
        if (!$depart) {
            return null;
        }
        switch ($recurrence) {
            case 'jour':
                return $depart->modify('+1 day')->format('Y-m-d');
            case 'semaine':
                return $depart->modify('+7 days')->format('Y-m-d');
            case 'fin_periode':
                $stmt = self::pdo()->prepare(
                    "SELECT MIN(date_fin) FROM periodes WHERE date_fin > :depuis"
                );
                break;
            case 'fin_annee':
                $stmt = self::pdo()->prepare(
                    "SELECT MIN(date_fin) FROM annees_scolaires WHERE date_fin > :depuis"
                );
                break;
            case 'debut_annee':
                $stmt = self::pdo()->prepare(
                    "SELECT MIN(date_debut) FROM annees_scolaires WHERE date_debut > :depuis"
                );
                break;
            default:
                return null;
        }
        $stmt->execute(['depuis' => $depart->format('Y-m-d')]);
        $date = $stmt->fetchColumn();
        return ($date === false || $date === null || $date === '') ? null : (string)$date;
    }

    /**
     * Matérialise les occurrences DUES de toutes les séries, jusqu'à aujourd'hui.
     *
     * Appelée à la lecture de la liste : une occurrence manquée n'est PAS effacée ni sautée
     * (décision 7.4), elle est créée avec sa vraie date. On voit donc deux lignes et on
     * tranche à la main. L'index unique (serie_id, echeance) rend l'appel rejouable.
     *
     * @return int nombre d'occurrences créées
     */
    public static function genererSuivantes(?string $aujourdhui = null): int {
        $aujourdhui = $aujourdhui ?: calulis_aujourdhui();
        $sql = "SELECT t.id, t.serie_id, t.recurrence, t.echeance, t.description, t.eleve_id,
                       t.adulte_id, t.priorite, t.couleur, t.precision_libre, t.notes
                  FROM taches t
                  JOIN (SELECT serie_id, MAX(echeance) AS echeance
                          FROM taches
                         WHERE serie_id IS NOT NULL AND recurrence IS NOT NULL AND echeance IS NOT NULL
                         GROUP BY serie_id) d
                    ON d.serie_id = t.serie_id AND d.echeance = t.echeance";
        $series = self::pdo()->query($sql)->fetchAll(PDO::FETCH_ASSOC);

        $crees = 0;
        foreach ($series as $t) {
            $next = self::prochaineEcheance((string)$t['recurrence'], (string)$t['echeance']);
            // Garde-fou : une récurrence doit AVANCER. Sans ce test, une date figée
            // ferait une boucle infinie.
            $essais = 0;
            while ($next !== null && $next <= $aujourdhui && $essais < 60) {
                $essais++;
                // Une date que l'utilisateur a SUPPRIMEE n'est jamais recréée (R12) : sans ce
                // test, supprimer l'occurrence du jour ne produisait aucun effet, elle revenait
                // à la lecture suivante.
                if (!self::_occurrenceExiste((int)$t['serie_id'], $next)
                    && !self::_occurrenceSupprimee((int)$t['serie_id'], $next)) {
                    self::_creerOccurrence($t, $next, $aujourdhui);
                    $crees++;
                }
                $suivant = self::prochaineEcheance((string)$t['recurrence'], $next);
                if ($suivant === null || $suivant <= $next) {
                    break;
                }
                $next = $suivant;
            }
        }
        return $crees;
    }

    private static function _occurrenceExiste(int $serieId, string $echeance): bool {
        $stmt = self::pdo()->prepare(
            "SELECT COUNT(*) FROM taches WHERE serie_id = :serie AND echeance = :echeance"
        );
        $stmt->execute(['serie' => $serieId, 'echeance' => $echeance]);
        return (int)$stmt->fetchColumn() > 0;
    }

    /** Une date de cette série a-t-elle été SUPPRIMEE par l'utilisateur ? (R12) */
    private static function _occurrenceSupprimee(int $serieId, string $echeance): bool {
        $stmt = self::pdo()->prepare(
            "SELECT COUNT(*) FROM taches_occurrences_supprimees WHERE serie_id = :serie AND echeance = :echeance"
        );
        $stmt->execute(['serie' => $serieId, 'echeance' => $echeance]);
        return (int)$stmt->fetchColumn() > 0;
    }

    /** Crée une occurrence à partir de la précédente : même contenu, statut remis à faire. */
    private static function _creerOccurrence(array $modele, string $echeance, string $aujourdhui): void {
        $stmt = self::pdo()->prepare(
            "INSERT INTO taches (annee_scolaire_id, description, eleve_id, adulte_id, date_creation,
                                 echeance, priorite, statut, couleur, precision_libre, notes,
                                 recurrence, serie_id)
             VALUES (:annee_id, :description, :eleve_id, :adulte_id, :date_creation,
                     :echeance, :priorite, 'a_faire', :couleur, :precision_libre, :notes,
                     :recurrence, :serie_id)"
        );
        $stmt->execute([
            'annee_id'        => self::anneeDeDate($echeance),
            'description'     => $modele['description'],
            'eleve_id'        => $modele['eleve_id'],
            'adulte_id'       => $modele['adulte_id'],
            'date_creation'   => $aujourdhui,
            'echeance'        => $echeance,
            'priorite'        => $modele['priorite'],
            'couleur'         => $modele['couleur'],
            'precision_libre' => $modele['precision_libre'],
            'notes'           => $modele['notes'],
            'recurrence'      => $modele['recurrence'],
            'serie_id'        => $modele['serie_id'],
        ]);
    }

    /* ------------------------------------------------------------------ */
    /* Année                                                               */
    /* ------------------------------------------------------------------ */

    /** L'année scolaire qui contient une date, ou null. */
    public static function anneeDeDate(string $date): ?int {
        $stmt = self::pdo()->prepare(
            "SELECT id FROM annees_scolaires WHERE :date BETWEEN date_debut AND date_fin
              ORDER BY date_debut DESC LIMIT 1"
        );
        $stmt->execute(['date' => $date]);
        $id = $stmt->fetchColumn();
        return $id === false ? null : (int)$id;
    }

    /** Les bornes d'une année scolaire, ou null si elle n'existe pas. */
    private static function anneeBornes(int $anneeId): ?array {
        $stmt = self::pdo()->prepare("SELECT date_debut, date_fin FROM annees_scolaires WHERE id = :id");
        $stmt->execute(['id' => $anneeId]);
        $row = $stmt->fetch(PDO::FETCH_ASSOC);
        return $row ?: null;
    }

    /* ------------------------------------------------------------------ */
    /* Validation                                                          */
    /* ------------------------------------------------------------------ */

    private static function _valider(array $data, bool $creation): array {
        $propre = [];
        $champ = fn(string $cle) => array_key_exists($cle, $data);

        // Le titre est obligatoire : c'est la première ligne de la description
        if ($creation || $champ('description') || $champ('titre')) {
            $description = (string)($data['description'] ?? '');
            // Le client peut envoyer titre + detail séparément : on compose ici
            if ($champ('titre') && !$champ('description')) {
                $description = self::composer((string)$data['titre'], (string)($data['detail'] ?? ''));
            }
            $description = trim($description);
            if ($description === '') {
                throw new InvalidArgumentException('Il faut au moins un titre pour la tâche');
            }
            // Le titre et le détail tiennent dans une seule colonne de 500 caractères : on REFUSE
            // au lieu de couper en silence (la revue du 04/10/2026 a relevé l'incohérence avec la
            // précision, qui, elle, refusait déjà). Un message vaut mieux qu'une perte de texte.
            if (mb_strlen($description) > 500) {
                throw new InvalidArgumentException(
                    'La tâche est trop longue : 500 caractères au maximum, titre et détail compris'
                );
            }
            $propre['description'] = $description;
        }

        foreach (['eleve_id', 'adulte_id'] as $lien) {
            if ($creation || $champ($lien)) {
                $valeur = $data[$lien] ?? null;
                $propre[$lien] = ($valeur === null || $valeur === '' || (int)$valeur === 0) ? null : (int)$valeur;
            }
        }

        if ($creation || $champ('precision_libre')) {
            $precision = trim((string)($data['precision_libre'] ?? ''));
            if (mb_strlen($precision) > 100) {
                throw new InvalidArgumentException('La précision ne doit pas dépasser 100 caractères');
            }
            $propre['precision_libre'] = $precision === '' ? null : $precision;
        }

        if ($creation || $champ('notes')) {
            $propre['notes'] = trim((string)($data['notes'] ?? '')) ?: null;
        }

        if ($creation || $champ('echeance')) {
            $echeance = trim((string)($data['echeance'] ?? ''));
            if ($echeance !== '' && !preg_match('/^\d{4}-\d{2}-\d{2}$/', $echeance)) {
                throw new InvalidArgumentException('Échéance invalide : ' . $echeance);
            }
            $propre['echeance'] = $echeance === '' ? null : $echeance;
        }

        if ($creation || $champ('date_creation')) {
            $date = trim((string)($data['date_creation'] ?? ''));
            if ($date === '') {
                $date = calulis_aujourdhui();
            }
            if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
                throw new InvalidArgumentException('Date de création invalide : ' . $date);
            }
            $propre['date_creation'] = $date;
        }

        if ($creation || $champ('statut')) {
            $statut = (string)($data['statut'] ?? 'a_faire');
            if (!in_array($statut, self::STATUTS, true)) {
                throw new InvalidArgumentException('Statut inconnu : ' . $statut);
            }
            $propre['statut'] = $statut;
        }

        if ($creation || $champ('priorite')) {
            $priorite = (string)($data['priorite'] ?? 'moyenne');
            if (!in_array($priorite, self::PRIORITES, true)) {
                throw new InvalidArgumentException('Priorité inconnue : ' . $priorite);
            }
            $propre['priorite'] = $priorite;
        }

        if ($creation || $champ('recurrence')) {
            $recurrence = trim((string)($data['recurrence'] ?? ''));
            if ($recurrence !== '' && !in_array($recurrence, self::RECURRENCES, true)) {
                throw new InvalidArgumentException('Récurrence inconnue : ' . $recurrence);
            }
            $propre['recurrence'] = $recurrence === '' ? null : $recurrence;
        }

        if ($creation || $champ('couleur')) {
            $couleur = (string)($data['couleur'] ?? 'jaune');
            if (!in_array($couleur, self::COULEURS, true)) {
                throw new InvalidArgumentException('Couleur inconnue : ' . $couleur);
            }
            $propre['couleur'] = $couleur;
        }

        return $propre;
    }
}