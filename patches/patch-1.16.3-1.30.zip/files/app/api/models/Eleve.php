<?php
/** Calulis — Model Élève (multi-année)
 *  Split : identité stable → eleves, données versionnées → eleve_annees */
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/EleveAnnee.php';
require_once __DIR__ . '/DossierDocuments.php';

class Eleve {
    /** Champs d'identité (stables, stockés dans eleves) */
    private const IDENTITY_FIELDS = [
        'nom', 'prenom', 'date_naissance',
        'ine', 'photo_path', 'langue_maison', 'bourse', 'regime_scolaire',
        'numero_dossier_mdph',
        'ecole_origine', 'ecole_origine_id', 'date_entree_ulis', 'suivi_par',
        'telephone_urgence', 'telephone', 'email', 'adresse',
        'allergies', 'regime_alimentaire', 'suivi_medical', 'precautions_medicales', 'pai', 'lien_pai',
        'liens_mdph', 'remarques', 'notifications',
        'champ_perso_1', 'champ_perso_2',
        'mdph_ulis_date_debut', 'mdph_ulis_date_fin', 'mdph_ulis_statut',
        'mdph_sessad_date_debut', 'mdph_sessad_date_fin', 'mdph_sessad_statut',
        'mdph_aesh_date_debut', 'mdph_aesh_date_fin', 'mdph_aesh_statut',
        'mdph_transport_date_debut', 'mdph_transport_date_fin', 'mdph_transport_statut',
        'mdph_autre_date_debut', 'mdph_autre_date_fin', 'mdph_autre_statut', 'mdph_autre_libelle',
        'ase_place', 'ase_structure_nom', 'ase_structure_adresse', 'ase_structure_telephone',
        'ase_referent_nom', 'ase_referent_telephone', 'ase_referent_email', 'ase_lien_ppe',
        'etablissement_id', 'classe_id',
        // L'enseignant référent (ERSEH) n'est PAS l'enseignant de la classe de référence :
        // c'est celui qui suit le PPS, réunit et anime l'équipe de suivi (ESS) et fait le
        // lien entre la famille, l'école et l'équipe pluridisciplinaire de la MDPH. Il est
        // désigné sur la fiche de l'élève et repris par le GEVA-Sco.
        'enseignant_referent_id',
        'actif', 'ordre', 'numero',
    ];

    /** Champs versionnés (stockés dans eleve_annees) */
    private const VERSIONED_FIELDS = [
        'classe', 'classe_id', 'ulis', 'groupe', 'niveau_scolaire', 'etablissement_id',
        'aesh_type', 'aesh_nom', 'aesh_heures', 'aesh_mutualise_avec',
        'temps_scolarisation',
        'transport', 'cantine',
    ];  // A4 : pec_specialite retiré — le système multi-PEC utilise la table pec_eleves

    /**
     * Complète les résultats avec les données versionnées depuis eleve_annees
     * et le nom de classe depuis la table classes.
     */
    private static function _augment(array $rows, ?int $anneeId): array {
        if (empty($rows) || $anneeId === null) return $rows;
        $pdo = getDB();
        $ids = array_column($rows, 'id');
        $placeholders = implode(',', array_fill(0, count($ids), '?'));

        // Récupérer les données versionnées
        $stmt = $pdo->prepare(
            "SELECT ea.* FROM eleve_annees ea
             WHERE ea.eleve_id IN ($placeholders) AND ea.annee_scolaire_id = ?"
        );
        $stmt->execute(array_merge(array_map('intval', $ids), [$anneeId]));
        $versions = $stmt->fetchAll();
        $verByEleve = [];
        foreach ($versions as $v) {
            $verByEleve[(int)$v['eleve_id']] = $v;
        }

        // Récupérer les noms de classe
        $classStmt = $pdo->prepare(
            "SELECT c.id, c.nom FROM classes c"
        );
        $classStmt->execute();
        $classes = [];
        foreach ($classStmt->fetchAll() as $c) {
            $classes[(int)$c['id']] = $c['nom'];
        }

        foreach ($rows as &$row) {
            $eid = (int)$row['id'];
            if (isset($verByEleve[$eid])) {
                foreach (self::VERSIONED_FIELDS as $f) {
                    if (array_key_exists($f, $verByEleve[$eid])) {
                        $row[$f] = $verByEleve[$eid][$f];
                    }
                }
            }
            // Ajouter classe_nom depuis classes
            $cid = isset($row['classe_id']) ? (int)$row['classe_id'] : 0;
            $row['classe_nom'] = $cid > 0 && isset($classes[$cid]) ? $classes[$cid] : ($row['classe'] ?? '');
            // Forcer la cohérence : si classe_id pointe vers une classe connue, classe = classe_nom
            if ($cid > 0 && isset($classes[$cid])) {
                $row['classe'] = $row['classe_nom'];
            }
        }
        return $rows;
    }

    /**
     * Ajoute à chaque élève le nombre de documents qui lui sont rattachés
     * (`nb_documents`). La liste des élèves l'affiche : on voit d'un coup d'œil qui a un
     * dossier documentaire, et on ouvre sa fiche au bon endroit (demande de Jérôme,
     * 08/10/2026).
     *
     * Le comptage porte sur TOUTES les années : un élève sorti du dispositif garde ses
     * documents, et sa fiche les montre tous (règle du 04/10/2026). Une seule requête
     * pour toute la liste — jamais une par élève.
     */
    public static function avecCompteurDocuments(array $rows): array {
        if (empty($rows)) return $rows;
        $ids = array_values(array_unique(array_map('intval', array_column($rows, 'id'))));
        if ($ids === []) return $rows;
        $pdo = getDB();
        $marques = implode(',', array_fill(0, count($ids), '?'));
        $stmt = $pdo->prepare(
            "SELECT eleve_id, COUNT(*) AS nb FROM documents
             WHERE eleve_id IN ($marques) GROUP BY eleve_id"
        );
        $stmt->execute($ids);
        $compte = [];
        foreach ($stmt->fetchAll() as $ligne) {
            $compte[(int)$ligne['eleve_id']] = (int)$ligne['nb'];
        }
        foreach ($rows as &$row) {
            $row['nb_documents'] = $compte[(int)$row['id']] ?? 0;
        }
        unset($row);
        return $rows;
    }

    /** Liste tous les élèves (filtrés par année si fournie) */
    public static function all(bool $inclureInactifs = false, ?int $anneeId = null): array {
        $pdo = getDB();
        if ($anneeId !== null) {
            // Filtrer par année : seuls les élèves avec une entrée dans eleve_annees pour cette année
            $sql = 'SELECT e.* FROM eleves e'
                 . ' INNER JOIN eleve_annees ea ON ea.eleve_id = e.id AND ea.annee_scolaire_id = :annee_id';
            if (!$inclureInactifs) $sql .= ' WHERE e.actif = 1';
            $sql .= ' ORDER BY e.ordre, e.nom, e.prenom';
            $stmt = $pdo->prepare($sql);
            $stmt->execute(['annee_id' => $anneeId]);
            $rows = $stmt->fetchAll();
        } else {
            $sql = 'SELECT * FROM eleves';
            if (!$inclureInactifs) $sql .= ' WHERE actif = 1';
            $sql .= ' ORDER BY ordre, nom, prenom';
            $rows = $pdo->query($sql)->fetchAll();
        }
        return self::avecCompteurDocuments(self::_augment($rows, $anneeId));
    }

    /** Recherche avec filtres
     * @param string $classe   Niveau scolaire (ex: "CP", "CE1") — filtre par c.niveaux
     * @param int|null $classeId ID de la classe spécifique — filtre par ea.classe_id
     */
    public static function search(string $q = '', string $classe = '', ?bool $ulis = null, ?bool $actif = null, ?int $anneeId = null, ?int $classeId = null): array {
        $pdo = getDB();
        $conditions = [];
        $params = [];
        if ($q !== '') {
            $conditions[] = '(e.nom LIKE :q OR e.prenom LIKE :q2)';
            $params['q'] = "%$q%";
            $params['q2'] = "%$q%";
        }
        $joinClasse = false;
        if ($classe !== '') {
            // Filtrer par niveau (c.niveaux) — ex: "CP" matche toutes les classes de CP
            $joinClasse = true;
            $conditions[] = 'c.niveaux = :classe';
            $params['classe'] = $classe;
        }
        if ($classeId !== null && $classeId > 0) {
            // Filtrer par classe spécifique (ea.classe_id)
            if (!$joinClasse) {
                // Le JOIN classes n'est pas encore fait, ne pas le faire juste pour classe_id
                // Utiliser directement ea.classe_id (déjà présent via eleve_annees)
            }
            $conditions[] = 'ea.classe_id = :classe_id';
            $params['classe_id'] = $classeId;
        }
        if ($ulis !== null) {
            $conditions[] = 'ea.ulis = :ulis';
            $params['ulis'] = $ulis ? 1 : 0;
        }
        if ($actif !== null) {
            $conditions[] = 'e.actif = :actif';
            $params['actif'] = $actif ? 1 : 0;
        }
        $needsEaJoin = $anneeId !== null || $classe !== '' || $ulis !== null || $classeId !== null;
        $sql = 'SELECT e.* FROM eleves e';
        if ($needsEaJoin) {
            $sql .= ' JOIN eleve_annees ea ON ea.eleve_id = e.id';
            if ($joinClasse) {
                $sql .= ' JOIN classes c ON c.id = ea.classe_id';
            }
            if ($anneeId !== null) {
                $conditions[] = 'ea.annee_scolaire_id = :annee_id';
                $params['annee_id'] = $anneeId;
            }
        }
        if ($conditions) $sql .= ' WHERE ' . implode(' AND ', $conditions);
        $sql .= ' ORDER BY e.ordre, e.nom, e.prenom';
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);
        $rows = $stmt->fetchAll();
        return self::avecCompteurDocuments(self::_augment($rows, $anneeId));
    }

    /** Trouve un élève par ID */
    public static function find(int $id, ?int $anneeId = null): ?array {
        $pdo = getDB();
        $stmt = $pdo->prepare('SELECT * FROM eleves WHERE id = :id');
        $stmt->execute(['id' => $id]);
        $row = $stmt->fetch();
        if (!$row) return null;
        $rows = self::avecCompteurDocuments(self::_augment([$row], $anneeId));
        return $rows[0] ?? null;
    }

    /** Crée un élève + sa version année, retourne l'ID */
    public static function create(array $data, ?int $anneeId = null): int {
        $data = calulis_truncate($data); // troncature varchar (classe incluse)
        $pdo = getDB();
        // Un nouvel élève arrive en FIN de liste des colonnes de l'emploi du temps.
        // Sans ce calcul, `ordre` valait 0 et le nouvel élève passait devant tout le
        // monde (constaté le 26/10/2026) : l'ordre des colonnes est désormais une
        // donnée, il ne doit pas être bousculé par une création.
        if (!isset($data['ordre']) || $data['ordre'] === '') {
            $data['ordre'] = (int)$pdo->query('SELECT COALESCE(MAX(ordre), -1) + 1 FROM eleves')->fetchColumn();
        }
        $pdo->beginTransaction();
        try {
            // 1. Insérer identité
            $identityData = array_intersect_key($data, array_flip(self::IDENTITY_FIELDS));
            $identityCols = array_keys($identityData);
            $identityVals = array_map(fn($c) => ":$c", $identityCols);
            $sql = 'INSERT INTO eleves (' . implode(', ', $identityCols) . ') VALUES (' . implode(', ', $identityVals) . ')';
            $stmt = $pdo->prepare($sql);
            $stmt->execute(self::_bindIdentity($identityData, false, $identityCols));
            $eleveId = (int)$pdo->lastInsertId();

            // 2. Créer version année si anneeId fourni
            if ($anneeId !== null) {
                $versionedData = array_intersect_key($data, array_flip(self::VERSIONED_FIELDS));
                $versionedData = array_merge($versionedData, $data); // merge full data for fallback
                EleveAnnee::upsert($eleveId, $anneeId, $data);
            }

            // 3. Backward compat : écrire les champs versionnés aussi dans eleves (cohérent avec update())
            // A4 : PEC retiré — géré par la table pec_eleves (multi-spécialités)
            $backwardFields = ['classe', 'ulis', 'groupe', 'niveau_scolaire',
                'aesh_type', 'aesh_nom', 'aesh_heures', 'aesh_mutualise_avec',
                'transport', 'cantine'];
            $backwardData = array_intersect_key($data, array_flip($backwardFields));
            if (!empty($backwardData)) {
                $sets = [];
                $params = ['id' => $eleveId];
                foreach ($backwardFields as $f) {
                    if (array_key_exists($f, $data)) {
                        $sets[] = "$f = :$f";
                        $params[$f] = $data[$f];
                    }
                }
                if (!empty($sets)) {
                    $sql = 'UPDATE eleves SET ' . implode(', ', $sets) . ' WHERE id = :id';
                    $stmt = $pdo->prepare($sql);
                    $stmt->execute($params);
                }
            }

            $pdo->commit();
            return $eleveId;
        } catch (\Exception $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    /** Met à jour un élève (split identité/versionné) */
    public static function update(int $id, array $data, ?int $anneeId = null): bool {
        $data = calulis_truncate($data);
        $pdo = getDB();
        $existing = self::find($id);
        if (!$existing) return false;
        // Sécurité : classe est varchar(20) — tronquer (cf. EleveAnnee::_normalize)
        if (array_key_exists('classe', $data) && $data['classe'] !== null) {
            $data['classe'] = mb_substr((string)$data['classe'], 0, 20);
        }

        // 1. Mettre à jour l'identité dans eleves
        $identityData = array_intersect_key($data, array_flip(self::IDENTITY_FIELDS));
        if (!empty($identityData)) {
            $sets = [];
            $bindFields = ['id']; // toujours inclure id
            foreach (self::IDENTITY_FIELDS as $f) {
                if (array_key_exists($f, $identityData)) {
                    $sets[] = "$f = :$f";
                    $bindFields[] = $f;
                }
            }
            $data['id'] = $id;
            $params = self::_bindIdentity($data, true, $bindFields);
            $sql = 'UPDATE eleves SET ' . implode(', ', $sets) . ', updated_at = CURRENT_TIMESTAMP WHERE id = :id';
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
        }

        // 2. Mettre à jour les champs versionnés dans eleve_annees
        $versionedData = [];
        foreach (self::VERSIONED_FIELDS as $f) {
            if (array_key_exists($f, $data)) {
                $versionedData[$f] = $data[$f];
            }
        }
        if (!empty($versionedData) && $anneeId !== null) {
            EleveAnnee::upsert($id, $anneeId, $versionedData);
        }

        // 3. Backward compat : mettre à jour les champs versionnés aussi dans eleves
        // A4 : PEC retiré — géré par la table pec_eleves (multi-spécialités)
        $backwardFields = ['classe', 'ulis', 'groupe', 'niveau_scolaire',
            'aesh_type', 'aesh_nom', 'aesh_heures', 'aesh_mutualise_avec',
            'transport', 'cantine'];
        $backwardData = array_intersect_key($data, array_flip($backwardFields));
        if (!empty($backwardData)) {
            $data['id'] = $id;
            $sets = ['updated_at = CURRENT_TIMESTAMP'];
            $params = ['id' => $id];
            foreach ($backwardFields as $f) {
                if (array_key_exists($f, $data)) {
                    $sets[] = "$f = :$f";
                    $params[$f] = $data[$f];
                }
            }
            $sql = 'UPDATE eleves SET ' . implode(', ', $sets) . ' WHERE id = :id';
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);
        }

        return true;
    }

    /**
     * Supprime un élève.
     *
     * ⚠️ `$avecDocuments` n'a PAS de valeur par défaut, et c'est volontaire : jusqu'au
     * 08/10/2026 cette méthode supprimait la ligne en laissant les documents et leurs
     * fichiers sur le disque, sans que rien ne le dise. Un appelant doit maintenant
     * DIRE ce qu'il veut — et le contrôleur refuse une requête qui ne le dit pas
     * (`DELETE eleves.php?id=N&documents=supprimer`).
     *
     * L'effacement des documents a lieu DANS LA MÊME TRANSACTION que la suppression de
     * l'élève : après celle-ci, plus aucune ligne ne dit à qui ils appartenaient
     * (`documents.eleve_id` passe à NULL) — et un `DELETE FROM eleves` qui échoue ne
     * doit pas laisser un élève dont les documents ont déjà disparu (défaut relevé par
     * la revue de code du 08/10/2026). Les FICHIERS, eux, partent après le commit : un
     * disque qui refuse ne doit pas annuler une suppression déjà enregistrée.
     *
     * @param bool $avecDocuments TRUE : efface aussi ses documents, ses fichiers et son dossier.
     * @return array{documents:int,fichiers:int,fichiers_restants:int,dossier_supprime:bool}|null
     */
    public static function delete(int $id, bool $avecDocuments): ?array {
        $pdo = getDB();
        $lignes = ['documents' => 0, 'fichiers' => []];
        $pdo->beginTransaction();
        try {
            if ($avecDocuments) {
                $lignes = DossierDocuments::supprimerLignes($id);
            }
            $stmt = $pdo->prepare('DELETE FROM eleves WHERE id = :id');
            $stmt->execute(['id' => $id]);
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        if (!$avecDocuments) {
            return null;
        }
        $effacement = DossierDocuments::purgerFichiers($lignes['fichiers'], $id);
        $effacement['documents'] = $lignes['documents'];
        return $effacement;
    }

    /**
     * Purge les élèves inactifs dont la dernière inscription est antérieure à une date.
     *
     * Les documents partent avec eux, exactement comme pour une suppression à l'unité :
     * c'est la même promesse (la page « Mentions RGPD » annonce l'effacement des données
     * d'un élève sorti), et rien ne justifierait qu'une purge automatique laisse sur le
     * disque ce qu'une suppression manuelle emporte. Comme pour la suppression à l'unité,
     * les lignes partent dans la transaction, les fichiers après le commit.
     *
     * ⚠️ Contrairement à la suppression d'un élève depuis la liste, **aucune archive
     * n'est proposée** : une purge groupée ne peut pas poser la question élève par élève.
     * C'est dit dans la fenêtre de confirmation et sur la page « Mentions RGPD ».
     *
     * @return array{eleves:int,documents:int,fichiers:int,fichiers_restants:int,dossiers_restants:int}
     */
    public static function purgeInactifsAvant(string $dateLimite): array {
        $pdo = getDB();

        // Les deux conditions vivent ici EN UN SEUL exemplaire : elles servent d'abord à
        // LISTER les élèves à purger (pour effacer leurs documents avant de perdre le
        // lien), puis à les supprimer. Deux copies divergentes laisseraient des élèves
        // dont les documents auraient déjà été effacés — ou l'inverse.
        $conditionAvecDates = 'e.actif = 0
             AND (SELECT MAX(ea.annee_scolaire_id) FROM eleve_annees ea WHERE ea.eleve_id = e.id) IS NOT NULL
             AND (SELECT MAX(a.date_fin) FROM eleve_annees ea
                  JOIN annees_scolaires a ON a.id = ea.annee_scolaire_id
                  WHERE ea.eleve_id = e.id) < :date_limite';
        $conditionSansAnnee = 'actif = 0 AND id NOT IN (SELECT DISTINCT eleve_id FROM eleve_annees)';

        $aPurger = [];
        $sel = $pdo->prepare("SELECT e.id FROM eleves e WHERE $conditionAvecDates");
        $sel->execute(['date_limite' => $dateLimite]);
        foreach ($sel->fetchAll(PDO::FETCH_COLUMN) as $identifiant) {
            $aPurger[(int)$identifiant] = true;
        }
        foreach ($pdo->query("SELECT id FROM eleves WHERE $conditionSansAnnee")->fetchAll(PDO::FETCH_COLUMN) as $identifiant) {
            $aPurger[(int)$identifiant] = true;
        }

        // UNE transaction pour toute la purge : si un seul DELETE échoue, rien n'est
        // effacé — ni élèves, ni documents.
        $lignes = [];
        $pdo->beginTransaction();
        try {
            foreach (array_keys($aPurger) as $identifiant) {
                $lignes[$identifiant] = DossierDocuments::supprimerLignes((int)$identifiant);
            }
            $stmt = $pdo->prepare("DELETE e FROM eleves e WHERE $conditionAvecDates");
            $stmt->execute(['date_limite' => $dateLimite]);
            $count = $stmt->rowCount();

            $stmt2 = $pdo->prepare("DELETE FROM eleves WHERE $conditionSansAnnee");
            $stmt2->execute();
            $count += $stmt2->rowCount();
            $pdo->commit();
        } catch (\Throwable $e) {
            $pdo->rollBack();
            throw $e;
        }

        // Le disque APRÈS le commit.
        $documents = 0;
        $fichiers = 0;
        $restants = 0;
        $dossiersRestants = 0;
        foreach ($lignes as $identifiant => $recense) {
            $effacement = DossierDocuments::purgerFichiers($recense['fichiers'], (int)$identifiant);
            $documents  += $recense['documents'];
            $fichiers   += $effacement['fichiers'];
            $restants   += $effacement['fichiers_restants'];
            if (!$effacement['dossier_supprime']) {
                $dossiersRestants++;
            }
        }

        return [
            'eleves'             => $count,
            'documents'          => $documents,
            'fichiers'           => $fichiers,
            'fichiers_restants'  => $restants,
            'dossiers_restants'  => $dossiersRestants,
        ];
    }

    /** Réordonne les élèves (batch update des champs ordre) */
    public static function reorder(array $ordres): bool {
        $pdo = getDB();
        $pdo->beginTransaction();
        try {
            $stmt = $pdo->prepare('UPDATE eleves SET ordre = :ordre WHERE id = :id');
            foreach ($ordres as $o) {
                $stmt->execute(['id' => (int)$o['id'], 'ordre' => (int)$o['ordre']]);
            }
            $pdo->commit();
            return true;
        } catch (\Exception $e) {
            $pdo->rollBack();
            throw $e;
        }
    }

    /** Lie les champs d'identité aux paramètres SQL.
     *  Si $onlyFields est fourni, ne retourne que les params pour ces champs
     *  (nécessaire car PDO emulated_prepares=false refuse les params superflus). */
    private static function _bindIdentity(array $data, bool $includeId = true, ?array $onlyFields = null): array {
        $strFields = ['nom','prenom','date_naissance',
            'ine','photo_path','langue_maison','regime_scolaire',
            'ecole_origine','ecole_origine_id','date_entree_ulis','suivi_par',
            'telephone_urgence','telephone','email','adresse',
            'allergies','regime_alimentaire','suivi_medical','precautions_medicales','lien_pai','liens_mdph','remarques','notifications',
            'champ_perso_1','champ_perso_2',
            'numero_dossier_mdph',
            'mdph_ulis_date_debut','mdph_ulis_date_fin','mdph_ulis_statut',
            'mdph_sessad_date_debut','mdph_sessad_date_fin','mdph_sessad_statut',
            'mdph_aesh_date_debut','mdph_aesh_date_fin','mdph_aesh_statut',
            'mdph_transport_date_debut','mdph_transport_date_fin','mdph_transport_statut',
            'mdph_autre_date_debut','mdph_autre_date_fin','mdph_autre_statut','mdph_autre_libelle',
            'ase_structure_nom','ase_structure_adresse','ase_structure_telephone',
            'ase_referent_nom','ase_referent_telephone','ase_referent_email','ase_lien_ppe',
            'etablissement_id','classe_id'];
        $dateFields = ['date_naissance','date_entree_ulis',
            'mdph_ulis_date_debut','mdph_ulis_date_fin',
            'mdph_sessad_date_debut','mdph_sessad_date_fin',
            'mdph_aesh_date_debut','mdph_aesh_date_fin',
            'mdph_transport_date_debut','mdph_transport_date_fin',
            'mdph_autre_date_debut','mdph_autre_date_fin'];
        $intFields = ['pai','ase_place','actif','ordre','numero','bourse'];
        if ($includeId) $intFields[] = 'id';
        $params = [];
        foreach ($strFields as $f) {
            // Si filtre actif, sauter les champs non demandés
            if ($onlyFields !== null && !in_array($f, $onlyFields, true)) continue;
            $v = isset($data[$f]) ? trim((string)$data[$f]) : null;
            if ($v === '' && in_array($f, $dateFields, true)) $v = null;
            $params[$f] = $v;
        }
        $intDefaults = ['actif' => 1, 'ordre' => 0, 'pai' => 0, 'ase_place' => 0];
        foreach ($intFields as $f) {
            if ($onlyFields !== null && !in_array($f, $onlyFields, true)) continue;
            $params[$f] = isset($data[$f]) ? (int)$data[$f] : ($intDefaults[$f] ?? 0);
        }
        // FK nullable — la valeur peut venir de $data directement (cas de
        // enseignant_referent_id, qui n'est pas un champ texte) ; sans ça elle serait
        // remise à NULL à chaque enregistrement.
        foreach (['etablissement_id', 'ecole_origine_id', 'classe_id', 'enseignant_referent_id'] as $fk) {
            if ($onlyFields !== null && !in_array($fk, $onlyFields, true)) continue;
            $brut = array_key_exists($fk, $data) ? $data[$fk] : ($params[$fk] ?? null);
            if ($brut !== null && $brut !== '') {
                $params[$fk] = (int)$brut;
            } else {
                $params[$fk] = null;
            }
        }
        if ($includeId && ($onlyFields === null || in_array('id', $onlyFields, true))) {
            $params['id'] = isset($data['id']) ? (int)$data['id'] : 0;
        }
        return $params;
    }
}