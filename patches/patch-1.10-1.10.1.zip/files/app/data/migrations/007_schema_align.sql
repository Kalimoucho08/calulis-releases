-- Migration 007 : ajoute la colonne numero manquante sur eleves.
-- Le réalignement des dumps de référence (03/09) a enregistré les migrations 001-006
-- comme appliquées, mais a omis la colonne numero ajoutée par la migration 003.
-- On la ré-ajoute ici, de façon idempotente.

SET @col_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'eleves' AND COLUMN_NAME = 'numero');
SET @sql = IF(@col_exists = 0, 'ALTER TABLE eleves ADD COLUMN numero INT NULL AFTER ordre', 'DO 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
