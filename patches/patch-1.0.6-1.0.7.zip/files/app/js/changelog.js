/**
 * Calulis — Changelog (Nouveautés)
 * Résumé des nouveautés depuis la v1.0. À mettre à jour à CHAQUE release
 * (voir scripts/release-checklist.sh — étape « quoi de neuf »).
 * NOTE : utiliser l'apostrophe typographique ' (U+2019) dans les textes —
 * jamais l'apostrophe droite ' qui casse les chaînes JS.
 */
const Changelog = {
    /** Dernière version connue (mise à jour à chaque release) */
    latest: '1.0.7',
    /** Entrées de la plus récente à la plus ancienne */
    entries: [
        {
            version: '1.0.7', date: '27 août 2026',
            items: [
                'Mise à jour plus fiable : le lanceur peut se mettre à jour depuis un second serveur (pCloud) si le premier est indisponible',
                'Le lanceur se réduit dans la barre d’état système (en bas à droite) — Calulis continue de tourner',
                'Messages plus simples et plus rassurants, moins de jargon technique',
                'Un bouton « Vérifier la mise à jour » permet de rechercher une version sans redémarrer',
                'Les champs de saisie limitent automatiquement leur longueur (plus d’erreur « données non enregistrées »)',
                'Accessibilité améliorée : les champs sont correctement étiquetés pour les lecteurs d’écran',
            ],
        },
        {
            version: '1.0.6', date: '26 août 2026',
            items: [
                'Protection renforcée : vos données ne peuvent plus être modifiées par une page web externe (sécurité CSRF)',
                'Sauvegarde plus fiable : plus d’erreurs d’enregistrement mystérieuses quand un champ est trop long (ils sont tronqués proprement)',
                'Les erreurs techniques sont maintenant journalisées pour un dépannage plus rapide',
                'Correction de l’affichage de la version (1.0.5 s’affichait à tort)',
            ],
        },
        {
            version: '1.0.5', date: '26 août 2026',
            items: [
                'Rattachement d’un élève à une classe corrigé (l’enregistrement échouait avec une erreur de base de données)',
            ],
        },
        {
            version: '1.0.4', date: '19 août 2026',
            items: [
                'Messages d’erreur enfin compréhensibles : plus de « Internal Server Error », Calulis explique quoi faire',
                'Bouton « Signaler un bug » sur les écrans d’erreur (infos techniques envoyées à l’équipe)',
                'Lanceur : bouton « Copier le rapport », aide intégrée, erreurs de démarrage claires',
                'Le lanceur se met à jour automatiquement, comme l’application',
                'Version de l’application affichée + cette page « Quoi de neuf »',
            ],
        },
        {
            version: '1.0.3', date: '17 août 2026',
            items: [
                'Calendrier scolaire (vacances) réparé sur toutes les machines Windows',
                'Messages d’erreur qui guident (connexion, certificat, DNS…)',
                'Les pages se rafraîchissent correctement après chaque mise à jour',
            ],
        },
        {
            version: '1.0.2', date: '17 août 2026',
            items: [
                'Établissements : ensembles scolaires, statut public/privé',
                'Tous les niveaux : maternelle, élémentaire, collège (6e→3e), lycée, lycée professionnel',
                'Création d’élève guidée (bouton « + Créer » pour l’établissement manquant)',
            ],
        },
        {
            version: '1.0.1', date: '16 août 2026',
            items: [
                'Correction du bug « ID requis » (modification/suppression élève, adulte, classe)',
            ],
        },
        {
            version: '1.0.0', date: '10 août 2026',
            items: [
                'Première version portable, sans installation : élèves, emploi du temps, réunions, annuaire, impression PDF',
                'Mises à jour automatiques, sauvegarde/restauration des données',
            ],
        },
    ],
};