/**
 * Calulis — Utilitaires formatage
 */

/** Convertit des minutes en format "XhYY" */
function formatMinutesToHours(minutes) {
    if (!minutes || minutes <= 0) return '0h';
    const h = Math.floor(minutes / 60);
    const m = minutes % 60;
    return m > 0 ? `${h}h${String(m).padStart(2, '0')}` : `${h}h`;
}

/** Calcule un pourcentage par rapport à un total */
function calculatePercentage(value, total) {
    if (!total || total <= 0) return 0;
    return Math.round((value / total) * 100);
}

/** Exporte un tableau de données en CSV avec BOM UTF-8 */
function exportCSV(filename, headers, rows) {
    const BOM = '﻿';
    const csv = [headers.join(','), ...rows.map(r => headers.map(h => {
        const v = (r[h] ?? '').toString();
        return /[,"\n\r]/.test(v) ? '"' + v.replace(/"/g, '""') + '"' : v;
    }).join(','))].join('\n');
    const blob = new Blob([BOM + csv], { type: 'text/csv;charset=utf-8' });
    const a = document.createElement('a');
    a.href = URL.createObjectURL(blob);
    a.download = filename;
    a.click();
    URL.revokeObjectURL(a.href);
}

// ── Limites de longueur des champs (miroir de l'API CALULIS_VARCHAR_LIMITS) ──
// maxlength à la saisie pour éviter les erreurs « data too long » (MySQL strict).
const CALULIS_MAXLEN = {
    // Champs « identité / contact » : largeur généreuse (= colonne), jamais trop courte
    nom: 100, prenom: 100, email: 100, ecole_origine: 100, motif_sortie: 100,
    suivi_par: 100, aesh_nom: 100, transport: 100, langue_maison: 100,
    orientation_demandee: 100, orientation_obtenue: 100, commentaire: 100,
    // Champs courts (colonnes varchar courtes du schéma)
    ine: 15, classe: 20, niveau_scolaire: 20, aesh_type: 10, aesh_heures: 20,
    groupe: 50, temps_scolarisation: 30, telephone: 20, telephone_urgence: 20,
    telephone2: 20, uai: 8, code_postal: 10, departement: 50,
    numero_dossier_mdph: 50, numero_dossier: 50, ase_structure_telephone: 20,
    ase_referent_telephone: 20, fonction: 50, role: 50, civilite: 10, lien: 50,
    specialite: 100, pec_specialite: 50, pec_organisme: 50, pec_frequence: 30,
    pec_lieu: 50, pec_duree: 20,
};
/** Retourne l'attribut maxlength si le champ est dans la table, sinon '' */
function maxLenAttr(name) {
    const n = CALULIS_MAXLEN[name];
    return n ? 'maxlength="' + n + '"' : '';
}

/** Accessibilité : relie chaque <label> sans for au champ suivant du même groupe de formulaire */
function linkLabels(container) {
    if (!container) return;
    container.querySelectorAll('.form-group').forEach(group => {
        const label = group.querySelector(':scope > label');
        if (!label || label.getAttribute('for')) return;
        const input = Array.from(group.children).find(el => /^(INPUT|SELECT|TEXTAREA)$/.test(el.tagName));
        if (!input) return;
        if (!input.id) input.id = 'f-' + label.textContent.trim().replace(/\s+/g, '-').toLowerCase();
        label.setAttribute('for', input.id);
    });
}
